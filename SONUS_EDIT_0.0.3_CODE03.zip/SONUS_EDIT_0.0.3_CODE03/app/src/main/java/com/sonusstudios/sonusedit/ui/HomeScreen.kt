package com.sonusstudios.sonusedit.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonusstudios.sonusedit.R
import com.sonusstudios.sonusedit.catalog.PCloudAsset
import com.sonusstudios.sonusedit.catalog.PCloudMusicRepository
import com.sonusstudios.sonusedit.catalog.StreamHistoryStore
import com.sonusstudios.sonusedit.catalog.StreamSuggestionEngine
import com.sonusstudios.sonusedit.catalog.StreamMetadataStore
import com.sonusstudios.sonusedit.designsystem.SonusEditColors
import com.sonusstudios.sonusedit.create.AudioMetadata
import com.sonusstudios.sonusedit.lyrics.LrclibLyricsProvider
import com.sonusstudios.sonusedit.lyrics.LyricsMetadata

private val homeMusicExtensions = setOf("mp3", "wav", "flac", "m4a", "aac", "ogg", "opus")

@Composable
fun HomeScreen(
    onCreate: () -> Unit,
    onUseSuggestion: (PCloudAsset) -> Unit,
) {
    val context = LocalContext.current
    val repository = remember { PCloudMusicRepository(context.applicationContext) }
    val history = remember { StreamHistoryStore(context.applicationContext) }
    val metadataStore = remember { StreamMetadataStore(context.applicationContext) }
    val lrclib = remember { LrclibLyricsProvider() }
    var suggestion by remember { mutableStateOf<PCloudAsset?>(null) }
    var suggestionMetadata by remember { mutableStateOf<AudioMetadata?>(null) }
    var suggestionHasLyrics by remember { mutableStateOf<Boolean?>(null) }

    LaunchedEffect(Unit) {
        val cached = repository.cached().filter { it.extension in homeMusicExtensions }
        if (cached.isNotEmpty()) suggestion = StreamSuggestionEngine.suggest(cached, history.recent())
        val fresh = repository.refresh().filter { it.extension in homeMusicExtensions }
        if (fresh.isNotEmpty()) suggestion = StreamSuggestionEngine.suggest(fresh, history.recent())
    }

    LaunchedEffect(suggestion) {
        val asset = suggestion ?: return@LaunchedEffect
        suggestionHasLyrics = null
        val meta = runCatching { metadataStore.resolve(asset, repository) }.getOrNull()
        suggestionMetadata = meta
        if (meta != null) {
            suggestionHasLyrics = runCatching {
                if (!meta.artist.isNullOrBlank()) {
                    lrclib.bestMatch(
                        LyricsMetadata(meta.title, meta.artist, meta.album, (meta.durationMs / 1000L).toInt().takeIf { it > 0 })
                    )?.hasSyncedLyrics == true
                } else lrclib.search(meta.title, null).any { it.hasSyncedLyrics }
            }.getOrDefault(false)
        }
    }

    Column(
        Modifier.fillMaxSize().background(SonusEditColors.Black).padding(horizontal = 20.dp, vertical = 28.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.sonus_edit_logo), "Sonus Edit", Modifier.size(82.dp))
            Spacer(Modifier.size(14.dp))
            Column {
                Text("Sonus Edit", fontSize = 36.sp, fontWeight = FontWeight.ExtraBold)
                Text("0.0.3 • code03", color = SonusEditColors.TextMuted, fontSize = 11.sp)
            }
        }

        Text("Escolha. Revise. O Sonus Edit monta e exporta sozinho.", color = SonusEditColors.TextMuted, fontSize = 17.sp)

        suggestion?.let { asset ->
            Card(
                Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = SonusEditColors.Violet.copy(alpha = .22f)),
            ) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("SUGESTÃO PARA O PRÓXIMO VÍDEO", color = SonusEditColors.Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text(suggestionMetadata?.title ?: asset.name.substringBeforeLast('.'), fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(listOfNotNull(suggestionMetadata?.artist, suggestionMetadata?.genre ?: asset.genre).joinToString(" • "), color = SonusEditColors.TextMuted, modifier = Modifier.weight(1f))
                        val dot = when (suggestionHasLyrics) { true -> androidx.compose.ui.graphics.Color(0xFF20C86B); false -> androidx.compose.ui.graphics.Color(0xFFE94F64); null -> SonusEditColors.TextMuted }
                        Box(Modifier.size(9.dp).background(dot, androidx.compose.foundation.shape.CircleShape))
                    }
                    Button(onClick = { onUseSuggestion(asset) }, colors = ButtonDefaults.buttonColors(containerColor = SonusEditColors.Violet)) {
                        Icon(Icons.Default.MusicNote, null)
                        Text("  USAR ESTA MÚSICA")
                    }
                }
            }
        }

        Card(
            Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = SonusEditColors.Surface),
        ) {
            Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AutoAwesome, null, tint = SonusEditColors.Cyan)
                    Spacer(Modifier.size(10.dp))
                    Text("Criar vídeo automático", fontWeight = FontWeight.Bold, fontSize = 21.sp)
                }
                Text("Assinatura + música → imagens → estilo/letra → revisão → exportação automática.", color = SonusEditColors.TextMuted)
                Button(onClick = onCreate, colors = ButtonDefaults.buttonColors(containerColor = SonusEditColors.Violet)) {
                    Icon(Icons.Default.PlayArrow, null)
                    Text("  CRIAR VÍDEO")
                }
            }
        }
        Spacer(Modifier.weight(1f))
        Text("by SONUS STUDIOS - RΛFΛ亗", color = SonusEditColors.TextMuted.copy(alpha = .65f), fontSize = 9.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
    }
}
