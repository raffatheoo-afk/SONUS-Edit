package com.sonusstudios.sonusedit.media

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.DefaultGainProvider
import androidx.media3.common.audio.GainProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.sonusstudios.sonusedit.create.CreateProjectDraft
import com.sonusstudios.sonusedit.create.MediaDistributionPlanner
import java.io.File
import kotlin.math.abs

@OptIn(UnstableApi::class)
class AutomaticVideoExporter(private val context: Context) {
    private val main = Handler(Looper.getMainLooper())
    private var transformer: Transformer? = null
    private var tempFile: File? = null

    fun start(
        draft: CreateProjectDraft,
        onCompleted: (Uri) -> Unit,
        onError: (Throwable) -> Unit,
    ) {
        require(draft.imageUris.isNotEmpty()) { "Selecione ao menos uma imagem." }
        require(draft.aspectRatio == "9:16") { "A exportação automática desta versão é vertical 9:16." }
        require(draft.exportFps in setOf(30, 60, 90)) { "FPS inválido." }
        cancel()

        val durationSeconds = (draft.segmentDurationMs / 1_000L).toInt()
        val durations = MediaDistributionPlanner.durationsMs(durationSeconds, draft.imageUris.size)
        check(durations.sum() == draft.segmentDurationMs) {
            "A timeline de imagens não fecha a duração total do vídeo."
        }

        val visualItems = draft.imageUris.zip(durations).map { (uriString, durationMs) ->
            val mediaItem = MediaItem.Builder()
                .setUri(Uri.parse(uriString))
                .setImageDurationMs(durationMs)
                .build()

            val visualEffects = mutableListOf<Effect>()
            visualEffects += Presentation.createForWidthAndHeight(
                draft.exportResolution.width,
                draft.exportResolution.height,
                Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP,
            )
            VideoVisualEffects.filterEffect(draft.filterPreset)?.let(visualEffects::add)
            visualEffects += VideoVisualEffects.imageFadeOverlay(
                durationMs = durationMs,
                fadeInMs = draft.imageFadeInMs.coerceAtMost(durationMs / 2),
                fadeOutMs = draft.imageFadeOutMs.coerceAtMost(durationMs / 2),
            )

            EditedMediaItem.Builder(mediaItem)
                .setFrameRate(draft.exportFps)
                .setEffects(Effects(emptyList(), visualEffects))
                .build()
        }
        val videoSequence = EditedMediaItemSequence.withVideoFrom(visualItems)

        val endMs = draft.segmentStartMs + draft.segmentDurationMs
        val audioItem = MediaItem.Builder()
            .setUri(Uri.parse(draft.audioUri))
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(draft.segmentStartMs)
                    .setEndPositionMs(endMs)
                    .build()
            )
            .build()

        val durationUs = draft.segmentDurationMs * 1_000L
        val fadeInUs = (draft.audioFadeInMs * 1_000L).coerceAtMost(durationUs / 2)
        val fadeOutUs = (draft.audioFadeOutMs * 1_000L).coerceAtMost(durationUs / 2)
        val gain = DefaultGainProvider.Builder(1f)
            .addFadeAt(0L, fadeInUs.coerceAtLeast(2L), DefaultGainProvider.FADE_IN_EQUAL_POWER)
            .addFadeAt(
                (durationUs - fadeOutUs).coerceAtLeast(0L),
                fadeOutUs.coerceAtLeast(2L),
                DefaultGainProvider.FADE_OUT_EQUAL_POWER,
            )
            .build()
        val audioEffects = Effects(listOf(GainProcessor(gain)), emptyList())
        val audioSequence = EditedMediaItemSequence.withAudioFrom(
            listOf(EditedMediaItem.Builder(audioItem).setEffects(audioEffects).build())
        )

        val composition = Composition.Builder(videoSequence, audioSequence)
            .setEffects(Effects(emptyList(), listOf(VideoVisualEffects.globalOverlay(context, draft))))
            .build()

        val output = File(context.cacheDir, "sonus_edit_${System.currentTimeMillis()}.mp4")
        tempFile = output

        val localTransformer = Transformer.Builder(context)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    runCatching { validateRealOutput(draft, exportResult) }
                        .onFailure { error ->
                            output.delete()
                            main.post { onError(error) }
                            return
                        }
                    Thread {
                        runCatching { saveToGallery(output, draft.exportTitle.ifBlank { draft.audioTitle }) }
                            .onSuccess { uri -> main.post { onCompleted(uri) } }
                            .onFailure { error -> main.post { onError(error) } }
                    }.start()
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException,
                ) {
                    onError(exportException)
                }
            })
            .build()
        transformer = localTransformer
        localTransformer.start(composition, output.absolutePath)
    }

    private fun validateRealOutput(draft: CreateProjectDraft, result: ExportResult) {
        if (result.width != draft.exportResolution.width || result.height != draft.exportResolution.height) {
            error(
                "O aparelho não entregou ${draft.exportResolution.label} 9:16 real. " +
                    "Saída: ${result.width}x${result.height}; esperado: " +
                    "${draft.exportResolution.width}x${draft.exportResolution.height}."
            )
        }
        val durationMs = result.approximateDurationMs.takeIf { it > 0 } ?: draft.segmentDurationMs
        if (result.videoFrameCount > 0 && durationMs > 0) {
            val actualFps = result.videoFrameCount * 1_000.0 / durationMs
            if (abs(actualFps - draft.exportFps) > 2.0) {
                error(
                    "O aparelho não entregou ${draft.exportFps} FPS reais " +
                        "(resultado aproximado: %.1f FPS).".format(actualFps)
                )
            }
        }
    }

    fun progressPercent(): Int? {
        val local = transformer ?: return null
        val holder = ProgressHolder()
        val state = local.getProgress(holder)
        return if (state == Transformer.PROGRESS_STATE_AVAILABLE) holder.progress else null
    }

    fun cancel() {
        transformer?.cancel()
        transformer = null
        tempFile?.takeIf { it.exists() }?.delete()
        tempFile = null
    }

    private fun saveToGallery(source: File, title: String): Uri {
        val safe = title.replace(Regex("[^\\p{L}\\p{N}_\\- ]"), "").trim().ifBlank { "Sonus_Edit" }
        val fileName = "${safe.take(48)}_${System.currentTimeMillis()}.mp4"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Sonus Edit")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: error("Não foi possível criar o vídeo na galeria.")
            try {
                resolver.openOutputStream(uri, "w")!!.use { out -> source.inputStream().use { it.copyTo(out) } }
                values.clear()
                values.put(MediaStore.Video.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                source.delete()
                return uri
            } catch (t: Throwable) {
                resolver.delete(uri, null, null)
                throw t
            }
        }

        val dir = File(context.getExternalFilesDir(Environment.DIRECTORY_MOVIES), "Sonus Edit").apply { mkdirs() }
        val target = File(dir, fileName)
        source.copyTo(target, overwrite = true)
        source.delete()
        return Uri.fromFile(target)
    }
}
