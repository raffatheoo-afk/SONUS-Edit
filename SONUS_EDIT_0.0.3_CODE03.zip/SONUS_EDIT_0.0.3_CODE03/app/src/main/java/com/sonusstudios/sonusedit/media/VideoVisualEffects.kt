package com.sonusstudios.sonusedit.media

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.media3.common.Effect
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.CanvasOverlay
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.OverlayEffect
import com.sonusstudios.sonusedit.R
import com.sonusstudios.sonusedit.create.CreateProjectDraft
import com.sonusstudios.sonusedit.create.FilterPresetId
import com.sonusstudios.sonusedit.create.FontPresetId
import com.sonusstudios.sonusedit.editor.LrcLine
import com.sonusstudios.sonusedit.editor.LrcParser
import kotlin.math.floor

@OptIn(UnstableApi::class)
object VideoVisualEffects {
    fun filterEffect(filter: FilterPresetId): Effect? = when (filter) {
        FilterPresetId.ORIGINAL -> null
        FilterPresetId.CINEMATIC -> HslAdjustment.Builder().adjustSaturation(-12f).adjustLightness(-4f).adjustHue(-3f).build()
        FilterPresetId.SUNSET -> HslAdjustment.Builder().adjustSaturation(18f).adjustLightness(3f).adjustHue(-14f).build()
        FilterPresetId.VINTAGE_FILM -> HslAdjustment.Builder().adjustSaturation(-25f).adjustLightness(4f).adjustHue(7f).build()
        FilterPresetId.NIGHT_CITY -> HslAdjustment.Builder().adjustSaturation(22f).adjustLightness(-13f).adjustHue(16f).build()
        FilterPresetId.NATURAL_PLUS -> HslAdjustment.Builder().adjustSaturation(8f).adjustLightness(2f).build()
        FilterPresetId.SOFT_LIGHT -> HslAdjustment.Builder().adjustSaturation(-5f).adjustLightness(9f).build()
        FilterPresetId.WARM_NATURAL -> HslAdjustment.Builder().adjustSaturation(7f).adjustLightness(3f).adjustHue(-7f).build()
        FilterPresetId.COOL_NATURAL -> HslAdjustment.Builder().adjustSaturation(3f).adjustLightness(1f).adjustHue(8f).build()
        FilterPresetId.SOFT_CONTRAST -> HslAdjustment.Builder().adjustSaturation(6f).adjustLightness(-2f).build()
        FilterPresetId.CINEMA_CLEAN -> HslAdjustment.Builder().adjustSaturation(-8f).adjustLightness(2f).adjustHue(2f).build()
        FilterPresetId.GOLDEN -> HslAdjustment.Builder().adjustSaturation(16f).adjustLightness(5f).adjustHue(-10f).build()
        FilterPresetId.CLEAN_NIGHT -> HslAdjustment.Builder().adjustSaturation(7f).adjustLightness(-9f).adjustHue(10f).build()
        FilterPresetId.PASTEL_NATURAL -> HslAdjustment.Builder().adjustSaturation(-18f).adjustLightness(11f).build()
        FilterPresetId.CLARITY_PLUS -> HslAdjustment.Builder().adjustSaturation(12f).adjustLightness(1f).build()
    }

    fun globalOverlay(context: Context, draft: CreateProjectDraft): OverlayEffect =
        OverlayEffect(listOf(SonusCanvasOverlay(context, draft)))

    fun imageFadeOverlay(durationMs: Long, fadeInMs: Long, fadeOutMs: Long): OverlayEffect =
        OverlayEffect(listOf(ImageFadeOverlay(durationMs, fadeInMs, fadeOutMs)))
}

@OptIn(UnstableApi::class)
private class ImageFadeOverlay(
    private val durationMs: Long,
    private val fadeInMs: Long,
    private val fadeOutMs: Long,
) : CanvasOverlay(true) {
    private val black = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
    private var firstTimestampUs: Long? = null

    override fun onDraw(canvas: Canvas, presentationTimeUs: Long) {
        canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
        // Media3 may expose a composition timestamp. Anchor the first frame of EACH image clip
        // and always calculate fades in clip-local time. This prevents the old 5s/global-time
        // bug where later images became fully transparent/black.
        val baseUs = firstTimestampUs ?: presentationTimeUs.also { firstTimestampUs = it }
        val t = ((presentationTimeUs - baseUs).coerceAtLeast(0L)) / 1_000L
        val alpha = when {
            fadeInMs > 0 && t < fadeInMs -> ((1f - t.toFloat() / fadeInMs) * 255).toInt()
            fadeOutMs > 0 && t > durationMs - fadeOutMs -> (((t - (durationMs - fadeOutMs)).toFloat() / fadeOutMs) * 255).toInt()
            else -> 0
        }.coerceIn(0, 255)
        if (alpha > 0) {
            black.alpha = alpha
            canvas.drawRect(0f, 0f, canvas.width.toFloat(), canvas.height.toFloat(), black)
        }
    }
}

@OptIn(UnstableApi::class)
private class SonusCanvasOverlay(
    private val context: Context,
    private val draft: CreateProjectDraft,
) : CanvasOverlay(true) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val lyrics: List<LrcLine> = draft.syncedLyrics?.let { raw ->
        LrcParser.sliceAndShift(
            LrcParser.parse(raw),
            draft.segmentStartMs,
            draft.segmentStartMs + draft.segmentDurationMs,
        )
    }.orEmpty()
    private val signatureBitmap: Bitmap? = draft.signaturePhotoUri?.let { value ->
        runCatching {
            context.contentResolver.openInputStream(Uri.parse(value))?.use { BitmapFactory.decodeStream(it) }
        }.getOrNull()
    }
    private val atlas: Bitmap? = BitmapFactory.decodeResource(context.resources, atlasResource(draft.automaticEffectId))
    private val atlasCols = 9
    private val atlasRows = 5
    private val atlasFrames = 45
    private val effectFps = 3f
    private val colors = intArrayOf(
        Color.rgb(0, 232, 255), Color.rgb(112, 255, 112), Color.rgb(255, 79, 163),
        Color.rgb(255, 224, 64), Color.rgb(184, 92, 255), Color.rgb(255, 78, 78),
        Color.rgb(70, 140, 255),
    )

    override fun onDraw(canvas: Canvas, presentationTimeUs: Long) {
        canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
        drawAnimatedEffect(canvas, presentationTimeUs)
        drawSignature(canvas)
        drawLyrics(canvas, presentationTimeUs / 1_000L)
        drawMetadata(canvas)
    }

    private fun drawAnimatedEffect(canvas: Canvas, timeUs: Long) {
        val bitmap = atlas ?: return
        val cellW = bitmap.width / atlasCols
        val cellH = bitmap.height / atlasRows
        if (cellW <= 0 || cellH <= 0) return
        val frameFloat = ((timeUs / 1_000_000f) * effectFps) % atlasFrames
        val first = floor(frameFloat).toInt().coerceIn(0, atlasFrames - 1)
        val next = (first + 1) % atlasFrames
        val mix = frameFloat - floor(frameFloat)
        val dst = RectF(0f, 0f, canvas.width.toFloat(), canvas.height.toFloat())
        drawAtlasFrame(canvas, bitmap, first, cellW, cellH, dst, ((1f - mix) * 185f).toInt())
        drawAtlasFrame(canvas, bitmap, next, cellW, cellH, dst, (mix * 185f).toInt())
    }

    private fun drawAtlasFrame(canvas: Canvas, bitmap: Bitmap, index: Int, cellW: Int, cellH: Int, dst: RectF, alpha: Int) {
        val col = index % atlasCols
        val row = index / atlasCols
        val src = Rect(col * cellW, row * cellH, (col + 1) * cellW, (row + 1) * cellH)
        paint.alpha = alpha.coerceIn(0, 255)
        canvas.drawBitmap(bitmap, src, dst, paint)
    }

    private fun drawSignature(canvas: Canvas) {
        val w = canvas.width.toFloat()
        val top = canvas.height * 0.055f
        val hasText = draft.signatureText.isNotBlank()
        val image = signatureBitmap
        if (image != null) {
            val maxW = w * 0.14f
            val maxH = canvas.height * 0.075f
            val scale = minOf(maxW / image.width, maxH / image.height)
            val dw = image.width * scale
            val dh = image.height * scale
            val left = w * 0.5f - dw / 2f
            val rect = RectF(left, top, left + dw, top + dh)
            paint.alpha = 235
            canvas.drawBitmap(image, null, rect, paint)
        }
        if (hasText) {
            val y = if (image != null) top + canvas.height * 0.085f else top + canvas.height * 0.035f
            textPaint.reset()
            textPaint.isAntiAlias = true
            textPaint.color = Color.WHITE
            textPaint.textAlign = Paint.Align.CENTER
            textPaint.typeface = Typeface.create("cursive", Typeface.ITALIC)
            textPaint.textSize = w * 0.043f
            textPaint.setShadowLayer(w * 0.005f, 0f, w * 0.002f, Color.BLACK)
            val max = w * 0.78f
            while (textPaint.measureText(draft.signatureText) > max && textPaint.textSize > w * 0.024f) {
                textPaint.textSize *= 0.92f
            }
            canvas.drawText(draft.signatureText, w / 2f, y, textPaint)
        }
    }

    private fun drawLyrics(canvas: Canvas, timeMs: Long) {
        if (lyrics.isEmpty()) return
        val index = lyrics.indexOfLast { it.timeMs <= timeMs }
        if (index < 0) return
        val line = lyrics[index].text.trim()
        if (line.isBlank()) return
        val maxWidth = (canvas.width * 0.84f).toInt()
        val maxSize = canvas.width * 0.052f
        val minSize = canvas.width * 0.030f
        textPaint.reset()
        textPaint.isAntiAlias = true
        textPaint.color = colors[index % colors.size]
        textPaint.typeface = lyricTypeface(draft.fontPreset)
        textPaint.setShadowLayer(canvas.width * 0.006f, 0f, canvas.width * 0.002f, Color.argb(220, 0, 0, 0))
        var size = maxSize
        var layout: StaticLayout
        while (true) {
            textPaint.textSize = size
            layout = StaticLayout.Builder.obtain(line, 0, line.length, textPaint, maxWidth)
                .setAlignment(Layout.Alignment.ALIGN_CENTER)
                .setIncludePad(false)
                .setMaxLines(2)
                .build()
            val complete = layout.lineCount <= 2 && layout.getLineEnd(layout.lineCount - 1) >= line.length
            if (complete || size <= minSize) break
            size *= 0.91f
        }
        val safeTop = canvas.height * 0.27f
        val safeBottom = canvas.height * 0.72f
        val centerY = canvas.height * 0.49f
        val top = (centerY - layout.height / 2f).coerceIn(safeTop, safeBottom - layout.height)
        canvas.save()
        canvas.translate((canvas.width - maxWidth) / 2f, top)
        layout.draw(canvas)
        canvas.restore()
    }

    private fun drawMetadata(canvas: Canvas) {
        val w = canvas.width.toFloat()
        val title = draft.exportTitle.trim().ifBlank { draft.audioTitle }
        val artist = draft.exportArtist.trim().ifBlank { draft.audioArtist.orEmpty() }
        textPaint.reset()
        textPaint.isAntiAlias = true
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        textPaint.setShadowLayer(w * 0.004f, 0f, w * 0.002f, Color.BLACK)
        textPaint.color = Color.rgb(255, 220, 45)
        textPaint.textSize = w * 0.036f
        shrinkToWidth(title, w * 0.84f, w * 0.026f)
        canvas.drawText(title, w / 2f, canvas.height * 0.885f, textPaint)
        if (artist.isNotBlank()) {
            textPaint.color = Color.WHITE
            textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
            textPaint.textSize = w * 0.027f
            shrinkToWidth(artist, w * 0.84f, w * 0.021f)
            canvas.drawText(artist, w / 2f, canvas.height * 0.922f, textPaint)
        }
    }

    private fun shrinkToWidth(value: String, maxWidth: Float, minSize: Float) {
        while (textPaint.measureText(value) > maxWidth && textPaint.textSize > minSize) {
            textPaint.textSize *= 0.92f
        }
    }

    private fun lyricTypeface(font: FontPresetId): Typeface = when (font) {
        FontPresetId.DEFAULT -> Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        FontPresetId.MODERN -> Typeface.create("sans-serif-light", Typeface.NORMAL)
        FontPresetId.ELEGANT -> Typeface.create(Typeface.SERIF, Typeface.ITALIC)
        FontPresetId.IMPACT -> Typeface.create("sans-serif-black", Typeface.BOLD)
        FontPresetId.HANDWRITTEN -> Typeface.create("cursive", Typeface.ITALIC)
        FontPresetId.MINIMAL -> Typeface.create("sans-serif-thin", Typeface.NORMAL)
        FontPresetId.NEON -> Typeface.create("sans-serif", Typeface.BOLD)
        FontPresetId.RETRO -> Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
    }

    private fun atlasResource(id: String): Int = when (id) {
        EffectIds.BOKEH_SOFT -> R.drawable.effect_bokeh_soft
        EffectIds.FLOATING_BUBBLES -> R.drawable.effect_floating_bubbles
        EffectIds.MAGIC_GLOW -> R.drawable.effect_magic_glow
        EffectIds.TWINKLE_STARS -> R.drawable.effect_twinkle_stars
        EffectIds.DISTANT_LIGHTS -> R.drawable.effect_distant_lights
        EffectIds.LIGHT_DUST -> R.drawable.effect_light_dust
        EffectIds.ETHEREAL_WAVES -> R.drawable.effect_ethereal_waves
        EffectIds.GOLDEN_SPARKS -> R.drawable.effect_golden_sparks
        EffectIds.LIGHT_SNOW -> R.drawable.effect_light_snow
        EffectIds.SUBTLE_DUST -> R.drawable.effect_subtle_dust
        EffectIds.LIGHT_FRAGMENTS -> R.drawable.effect_light_fragments
        EffectIds.NEON_STARS -> R.drawable.effect_neon_stars
        else -> R.drawable.effect_minimal_particles
    }
}
