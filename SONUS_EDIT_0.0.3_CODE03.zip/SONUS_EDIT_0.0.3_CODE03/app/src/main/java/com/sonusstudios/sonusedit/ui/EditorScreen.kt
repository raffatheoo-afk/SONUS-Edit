package com.sonusstudios.sonusedit.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonusstudios.sonusedit.catalog.PCloudAsset
import com.sonusstudios.sonusedit.catalog.StreamHistoryStore
import com.sonusstudios.sonusedit.create.AudioSource
import com.sonusstudios.sonusedit.create.CreateProjectDraft
import com.sonusstudios.sonusedit.designsystem.SonusEditColors
import com.sonusstudios.sonusedit.integration.IncomingIntentRouter
import com.sonusstudios.sonusedit.media.AutomaticVideoExporter
import kotlinx.coroutines.delay

private enum class ExportState { EXPORTING, SAVED, ERROR, CANCELLED }

@Composable
fun EditorScreen(
    incomingRoute: IncomingIntentRouter.Route?,
    draft: CreateProjectDraft?,
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    val exporter = remember { AutomaticVideoExporter(context.applicationContext) }
    var state by remember { mutableStateOf(ExportState.EXPORTING) }
    var progress by remember { mutableIntStateOf(0) }
    var outputUri by remember { mutableStateOf<Uri?>(null) }
    var errorText by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(draft) {
        if (draft == null) {
            state = ExportState.ERROR
            errorText = "Projeto automático indisponível."
            return@LaunchedEffect
        }
        state = ExportState.EXPORTING
        exporter.start(
            draft = draft,
            onCompleted = { uri ->
                outputUri = uri
                progress = 100
                state = ExportState.SAVED
                if (draft.audioSource == AudioSource.SONUS_STREAM) {
                    val id = draft.sourceTrackId?.toLongOrNull()
                    if (id != null) {
                        StreamHistoryStore(context).record(
                            PCloudAsset(fileId = id, name = draft.audioTitle, folderPath = draft.sourceGenre.orEmpty(), sourcePublicCode = draft.sourcePublicCode)
                        )
                    }
                }
            },
            onError = { error ->
                errorText = error.message ?: "Falha ao exportar vídeo."
                state = ExportState.ERROR
            },
        )
    }

    LaunchedEffect(state) {
        while (state == ExportState.EXPORTING) {
            exporter.progressPercent()?.let { progress = it }
            delay(250)
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            if (state == ExportState.EXPORTING) exporter.cancel()
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().background(SonusEditColors.Black).padding(22.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        when (state) {
            ExportState.EXPORTING -> {
                Text("Criando seu vídeo", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(8.dp))
                Text(exportStage(progress), color = SonusEditColors.TextMuted)
                Spacer(Modifier.height(26.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.cardColors(containerColor = SonusEditColors.Surface),
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text("${progress.coerceIn(0, 100)}%", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = SonusEditColors.Cyan)
                        Spacer(Modifier.height(12.dp))
                        LinearProgressIndicator(
                            progress = { progress.coerceIn(0, 100) / 100f },
                            modifier = Modifier.fillMaxWidth().height(12.dp),
                            color = SonusEditColors.Cyan,
                            trackColor = SonusEditColors.Violet.copy(alpha = .25f),
                        )
                        Spacer(Modifier.height(12.dp))
                        Text("Sonus Edit • exportação automática 9:16", color = SonusEditColors.TextMuted, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(22.dp))
                OutlinedButton(onClick = {
                    exporter.cancel()
                    state = ExportState.CANCELLED
                }) { Text("Cancelar") }
            }

            ExportState.SAVED -> {
                Text("✓", color = SonusEditColors.Cyan, fontSize = 58.sp, fontWeight = FontWeight.Bold)
                Text("Vídeo salvo na galeria", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(10.dp))
                Text("A próxima sugestão do Stream será atualizada pelo seu histórico.", color = SonusEditColors.TextMuted)
                Spacer(Modifier.height(24.dp))
                Button(
                    onClick = {
                        outputUri?.let { uri ->
                            context.startActivity(Intent(Intent.ACTION_VIEW).apply {
                                setDataAndType(uri, "video/mp4")
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            })
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = SonusEditColors.Violet),
                ) {
                    androidx.compose.material3.Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(Modifier.height(2.dp))
                    Text("ASSISTIR")
                }
                Spacer(Modifier.height(10.dp))
                OutlinedButton(
                    onClick = {
                        outputUri?.let { uri ->
                            context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                                type = "video/mp4"
                                putExtra(Intent.EXTRA_STREAM, uri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }, "Compartilhar vídeo"))
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    androidx.compose.material3.Icon(Icons.Default.Share, contentDescription = null)
                    Text(" Compartilhar")
                }
                Spacer(Modifier.height(10.dp))
                OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Criar outro") }
            }

            ExportState.ERROR -> {
                androidx.compose.material3.Icon(Icons.Default.Close, contentDescription = null, tint = androidx.compose.ui.graphics.Color.Red)
                Spacer(Modifier.height(12.dp))
                Text("Não foi possível criar o vídeo", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text(errorText.orEmpty(), color = SonusEditColors.TextMuted)
                Spacer(Modifier.height(18.dp))
                Button(onClick = onBack) { Text("Voltar") }
            }

            ExportState.CANCELLED -> {
                Text("Exportação cancelada", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(14.dp))
                Button(onClick = onBack) { Text("Voltar") }
            }
        }
    }
}

private fun exportStage(progress: Int): String = when (progress) {
    in 0..9 -> "Preparando mídia…"
    in 10..24 -> "Sincronizando projeto…"
    in 25..49 -> "Montando imagens…"
    in 50..94 -> "Renderizando vídeo…"
    else -> "Salvando na galeria…"
}
