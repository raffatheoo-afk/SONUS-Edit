package com.sonusstudios.sonusedit.lyrics

/**
 * Contract for the real SONUS Stream synchronized-lyrics source.
 *
 * CODE02 deliberately does not redirect SONUS tracks to LRCLIB. The concrete resolver must be
 * wired to the same source currently used by com.sonusstudios.streampulse once that module/code is
 * supplied. This keeps timestamps/source semantics compatible instead of inventing a second source.
 */
interface SonusLyricsResolver {
    suspend fun syncedLyrics(trackId: String): String?
}

object UnavailableSonusLyricsResolver : SonusLyricsResolver {
    override suspend fun syncedLyrics(trackId: String): String? = null
}

class LyricsRepository(
    private val sonus: SonusLyricsResolver,
    private val external: LyricsProvider,
) {
    suspend fun forSonusTrack(trackId: String): String? = sonus.syncedLyrics(trackId)

    suspend fun forExternalTrack(metadata: LyricsMetadata): String? =
        external.bestMatch(metadata)?.syncedLyrics
}
