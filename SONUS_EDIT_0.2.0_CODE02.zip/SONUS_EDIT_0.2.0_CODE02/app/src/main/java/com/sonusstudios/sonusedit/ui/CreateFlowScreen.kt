package com.sonusstudios.sonusedit.ui

import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Style
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.sonusstudios.sonusedit.R
import com.sonusstudios.sonusedit.catalog.PCloudAsset
import com.sonusstudios.sonusedit.catalog.PCloudImageRepository
import com.sonusstudios.sonusedit.catalog.PCloudMusicRepository
import com.sonusstudios.sonusedit.catalog.StreamHistoryStore
import com.sonusstudios.sonusedit.catalog.StreamSuggestionEngine
import com.sonusstudios.sonusedit.create.AudioMetadata
import com.sonusstudios.sonusedit.create.AudioMetadataReader
import com.sonusstudios.sonusedit.create.AudioSource
import com.sonusstudios.sonusedit.create.CreateProjectDraft
import com.sonusstudios.sonusedit.create.DurationPreset
import com.sonusstudios.sonusedit.create.EditPreferences
import com.sonusstudios.sonusedit.create.FilterPresetId
import com.sonusstudios.sonusedit.create.FontPresetId
import com.sonusstudios.sonusedit.create.LyricsPolicy
import com.sonusstudios.sonusedit.create.MediaDistributionPlanner
import com.sonusstudios.sonusedit.create.SavedEditPreferences
import com.sonusstudios.sonusedit.create.UriPermissionHelper
import com.sonusstudios.sonusedit.designsystem.SonusEditColors
import com.sonusstudios.sonusedit.integration.IncomingIntentRouter
import java.net.HttpURLConnection
import java.net.URI
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToLong

private enum class CreateStep(val label: String) {
    MUSIC("Música"), IMAGES("Imagens"), STYLE("Estilo"), REVIEW("Revisão")
}

private val musicExt = setOf("mp3", "wav", "flac", "m4a", "aac", "ogg", "opus")
private val imageExt = setOf("jpg", "jpeg", "png", "webp")

@Composable
fun CreateFlowScreen(
    incomingRoute: IncomingIntentRouter.Route?,
    preselectedStreamAsset: PCloudAsset? = null,
    onBack: () -> Unit,
    onCreateDraft: (CreateProjectDraft) -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val preferences = remember { EditPreferences(context.applicationContext) }
    val savedPreferences by preferences.values.collectAsState(initial = SavedEditPreferences())
    val musicRepo = remember { PCloudMusicRepository(context.applicationContext) }
    val imageRepo = remember { PCloudImageRepository(context.applicationContext) }
    val historyStore = remember { StreamHistoryStore(context.applicationContext) }

    var step by remember { mutableStateOf(CreateStep.MUSIC) }
    var signatureText by remember { mutableStateOf("") }
    var signaturePhotoUri by remember { mutableStateOf<Uri?>(null) }
    var saveSignatureDefault by remember { mutableStateOf(true) }

    var audioUri by remember { mutableStateOf<Uri?>(null) }
    var audioSource by remember { mutableStateOf(AudioSource.LOCAL) }
    var selectedStreamAsset by remember { mutableStateOf<PCloudAsset?>(null) }
    var metadata by remember { mutableStateOf<AudioMetadata?>(null) }
    var selectedDuration by remember { mutableStateOf(DurationPreset.all[1]) }
    var segmentStartMs by remember { mutableStateOf(0L) }
    var isPlaying by remember { mutableStateOf(false) }

    var musicCatalog by remember { mutableStateOf<List<PCloudAsset>>(emptyList()) }
    var imageCatalog by remember { mutableStateOf<List<PCloudAsset>>(emptyList()) }
    var showStreamPicker by remember { mutableStateOf(false) }
    var showSonusGallery by remember { mutableStateOf(true) }
    var musicSearch by remember { mutableStateOf("") }
    var selectedGenre by remember { mutableStateOf("Todos") }
    var catalogsLoading by remember { mutableStateOf(false) }

    var imageUris by remember { mutableStateOf<List<String>>(emptyList()) }
    var selectedRemoteImages by remember { mutableStateOf<Set<Long>>(emptySet()) }
    var remoteImageUrls by remember { mutableStateOf<Map<Long, String>>(emptyMap()) }
    var fontPreset by remember { mutableStateOf(FontPresetId.DEFAULT) }
    var filterPreset by remember { mutableStateOf(FilterPresetId.ORIGINAL) }
    var saveFontDefault by remember { mutableStateOf(true) }
    var notice by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(savedPreferences) {
        if (signatureText.isBlank()) signatureText = savedPreferences.signatureText
        if (signaturePhotoUri == null) signaturePhotoUri = savedPreferences.signaturePhotoUri?.let(Uri::parse)
        if (fontPreset == FontPresetId.DEFAULT) fontPreset = savedPreferences.fontPreset
    }

    LaunchedEffect(Unit) {
        catalogsLoading = true
        musicCatalog = musicRepo.cached().filter { it.extension in musicExt }
        imageCatalog = imageRepo.cached().filter { it.extension in imageExt }
        val freshMusic = musicRepo.refresh().filter { it.extension in musicExt }
        val freshImages = imageRepo.refresh().filter { it.extension in imageExt }
        if (freshMusic.isNotEmpty()) musicCatalog = freshMusic
        if (freshImages.isNotEmpty()) imageCatalog = freshImages
        catalogsLoading = false
    }

    LaunchedEffect(preselectedStreamAsset) {
        val asset = preselectedStreamAsset ?: return@LaunchedEffect
        if (audioUri != null) return@LaunchedEffect
        val url = musicRepo.downloadUrl(asset)
        if (url != null) {
            selectedStreamAsset = asset
            audioSource = AudioSource.SONUS_STREAM
            metadata = AudioMetadata(
                title = asset.name.substringBeforeLast('.'),
                artist = asset.folderPath.substringAfterLast('/').takeIf { it.isNotBlank() } ?: "SONUS Stream",
                durationMs = asset.durationMs ?: 0L,
            )
            audioUri = Uri.parse(url)
        } else {
            notice = "Não foi possível abrir a música sugerida."
        }
    }

    LaunchedEffect(incomingRoute) {
        when (val route = incomingRoute) {
            is IncomingIntentRouter.Route.SharedMedia -> {
                val audio = route.uris.firstOrNull { context.contentResolver.getType(it)?.startsWith("audio/") == true }
                if (audio != null) {
                    UriPermissionHelper.persistRead(context, audio)
                    audioSource = AudioSource.SHARED
                    audioUri = audio
                }
                val images = route.uris.filter { context.contentResolver.getType(it)?.startsWith("image/") == true }
                images.forEach { UriPermissionHelper.persistRead(context, it) }
                imageUris = (imageUris + images.map { it.toString() }).distinct()
            }
            is IncomingIntentRouter.Route.SonusTrack -> {
                audioSource = AudioSource.SONUS_STREAM
                notice = "Faixa recebida do SONUS: ${route.trackId}. A letra deve usar a mesma origem do Stream por trackId."
                route.durationMs?.takeIf { it > 0 }?.let { ms ->
                    selectedDuration = DurationPreset.all.lastOrNull { it.seconds * 1_000L <= ms } ?: DurationPreset.all.first()
                }
                route.startMs?.let { segmentStartMs = it.coerceAtLeast(0L) }
            }
            else -> Unit
        }
    }

    LaunchedEffect(musicCatalog, incomingRoute) {
        val route = incomingRoute as? IncomingIntentRouter.Route.SonusTrack ?: return@LaunchedEffect
        if (audioUri != null || musicCatalog.isEmpty()) return@LaunchedEffect
        val asset = route.trackId.toLongOrNull()?.let { id -> musicCatalog.firstOrNull { it.fileId == id } }
        if (asset != null) {
            val url = musicRepo.downloadUrl(asset)
            if (url != null) {
                selectedStreamAsset = asset
                audioSource = AudioSource.SONUS_STREAM
                metadata = AudioMetadata(
                    title = asset.name.substringBeforeLast('.'),
                    artist = asset.folderPath.substringAfterLast('/').takeIf { it.isNotBlank() } ?: "SONUS Stream",
                    durationMs = asset.durationMs ?: 0L,
                )
                audioUri = Uri.parse(url)
            }
        }
    }

    val player = remember { ExoPlayer.Builder(context).build() }
    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY && audioSource == AudioSource.SONUS_STREAM && player.duration > 0) {
                    val old = metadata
                    metadata = AudioMetadata(
                        title = old?.title ?: selectedStreamAsset?.name?.substringBeforeLast('.') ?: "SONUS Stream",
                        artist = old?.artist ?: "SONUS Stream",
                        durationMs = player.duration,
                    )
                }
            }
        }
        player.addListener(listener)
        onDispose {
            player.removeListener(listener)
            player.release()
        }
    }

    LaunchedEffect(audioUri) {
        isPlaying = false
        player.stop()
        val uri = audioUri ?: run { metadata = null; return@LaunchedEffect }
        if (audioSource != AudioSource.SONUS_STREAM) {
            metadata = withContext(Dispatchers.IO) { runCatching { AudioMetadataReader.read(context, uri) }.getOrNull() }
        }
        player.setMediaItem(MediaItem.fromUri(uri))
        player.prepare()
        segmentStartMs = segmentStartMs.coerceAtLeast(0L)
    }

    val segmentDurationMs = selectedDuration.seconds * 1_000L
    val imageLimit = MediaDistributionPlanner.maxImages(selectedDuration.seconds)
    val musicReady = audioUri != null && (metadata?.durationMs ?: 0L) >= segmentDurationMs
    val imagesReady = imageUris.isNotEmpty() && imageUris.size <= imageLimit
    val signatureReady = signatureText.isNotBlank() || signaturePhotoUri != null
    val canContinue = when (step) {
        CreateStep.MUSIC -> musicReady && signatureReady
        CreateStep.IMAGES -> imagesReady
        CreateStep.STYLE -> true
        CreateStep.REVIEW -> musicReady && signatureReady && imagesReady
    }

    LaunchedEffect(isPlaying, segmentStartMs, segmentDurationMs) {
        if (!isPlaying) return@LaunchedEffect
        val end = segmentStartMs + segmentDurationMs
        while (isPlaying) {
            if (player.currentPosition >= end) {
                player.pause(); player.seekTo(segmentStartMs); isPlaying = false; break
            }
            delay(100)
        }
    }

    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            UriPermissionHelper.persistRead(context, it)
            audioSource = AudioSource.LOCAL
            selectedStreamAsset = null
            audioUri = it
        }
    }
    val signaturePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { UriPermissionHelper.persistRead(context, it); signaturePhotoUri = it }
    }
    val localImagesPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { UriPermissionHelper.persistRead(context, it) }
        val merged = (imageUris + uris.map { it.toString() }).distinct()
        if (merged.size > imageLimit) {
            imageUris = merged.take(imageLimit)
            notice = "Foram mantidas $imageLimit imagens para ${selectedDuration.label}."
        } else imageUris = merged
    }

    fun applyDuration(preset: DurationPreset) {
        val duration = metadata?.durationMs ?: 0L
        if (duration > 0 && preset.seconds * 1_000L > duration) {
            notice = "A música é menor que ${preset.label}."
            return
        }
        selectedDuration = preset
        val maxStart = (duration - preset.seconds * 1_000L).coerceAtLeast(0L)
        segmentStartMs = segmentStartMs.coerceAtMost(maxStart)
        val limit = MediaDistributionPlanner.maxImages(preset.seconds)
        if (imageUris.size > limit) imageUris = imageUris.take(limit)
    }

    Column(Modifier.fillMaxSize().background(SonusEditColors.Black).padding(top = 14.dp)) {
        CreateHeader(onBack)
        StepTabs(step) { if (it.ordinal <= step.ordinal) step = it }
        notice?.let {
            Card(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
                colors = CardDefaults.cardColors(containerColor = SonusEditColors.Violet.copy(alpha = .16f)),
            ) {
                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(it, Modifier.weight(1f), color = SonusEditColors.Text, fontSize = 12.sp)
                    IconButton(onClick = { notice = null }) { Icon(Icons.Default.Close, null) }
                }
            }
        }

        if (showStreamPicker) {
            StreamPicker(
                assets = musicCatalog,
                loading = catalogsLoading,
                search = musicSearch,
                selectedGenre = selectedGenre,
                history = historyStore.recent(),
                onSearch = { musicSearch = it },
                onGenre = { selectedGenre = it },
                onBack = { showStreamPicker = false },
                onSelect = { asset ->
                    scope.launch {
                        notice = "Preparando ${asset.name}…"
                        val url = musicRepo.downloadUrl(asset)
                        if (url == null) {
                            notice = "Não foi possível abrir esta faixa do SONUS Stream."
                        } else {
                            selectedStreamAsset = asset
                            audioSource = AudioSource.SONUS_STREAM
                            metadata = AudioMetadata(
                                title = asset.name.substringBeforeLast('.'),
                                artist = asset.folderPath.substringAfterLast('/').takeIf { it.isNotBlank() } ?: "SONUS Stream",
                                durationMs = asset.durationMs ?: 0L,
                            )
                            audioUri = Uri.parse(url)
                            showStreamPicker = false
                            notice = "Música selecionada. Letra do Stream: usar mesma origem SONUS por trackId/fileId quando o bridge real estiver disponível."
                        }
                    }
                },
            )
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                item {
                    when (step) {
                        CreateStep.MUSIC -> MusicAndSignatureStep(
                            signatureText = signatureText,
                            signaturePhotoUri = signaturePhotoUri,
                            saveSignature = saveSignatureDefault,
                            onSignatureText = { signatureText = it },
                            onSignaturePhoto = { signaturePicker.launch(arrayOf("image/*")) },
                            onRemoveSignaturePhoto = { signaturePhotoUri = null },
                            onSaveSignature = { saveSignatureDefault = it },
                            metadata = metadata,
                            audioSource = audioSource,
                            selectedDuration = selectedDuration,
                            segmentStartMs = segmentStartMs,
                            isPlaying = isPlaying,
                            onStream = { showStreamPicker = true },
                            onLocal = { audioPicker.launch(arrayOf("audio/*")) },
                            onDuration = ::applyDuration,
                            onStartChange = { segmentStartMs = it },
                            onFine = { seconds ->
                                val duration = metadata?.durationMs ?: 0L
                                val maxStart = (duration - segmentDurationMs).coerceAtLeast(0L)
                                segmentStartMs = (segmentStartMs + seconds * 1_000L).coerceIn(0L, maxStart)
                                if (isPlaying) player.seekTo(segmentStartMs)
                            },
                            onPlayPause = {
                                if (audioUri != null) {
                                    if (isPlaying) { player.pause(); isPlaying = false }
                                    else { player.seekTo(segmentStartMs); player.play(); isPlaying = true }
                                }
                            },
                        )
                        CreateStep.IMAGES -> ImagesStep(
                            localOrRemoteUris = imageUris,
                            selectedRemoteIds = selectedRemoteImages,
                            remoteAssets = imageCatalog,
                            remoteMode = showSonusGallery,
                            limit = imageLimit,
                            loading = catalogsLoading,
                            imageRepo = imageRepo,
                            onRemoteMode = { showSonusGallery = it },
                            onLocal = { localImagesPicker.launch(arrayOf("image/*")) },
                            onRemoteToggle = { asset ->
                                scope.launch {
                                    if (asset.fileId in selectedRemoteImages) {
                                        selectedRemoteImages = selectedRemoteImages - asset.fileId
                                        remoteImageUrls[asset.fileId]?.let { stored -> imageUris = imageUris - stored }
                                        remoteImageUrls = remoteImageUrls - asset.fileId
                                    } else if (imageUris.size < imageLimit) {
                                        val url = imageRepo.downloadUrl(asset)
                                        if (url != null) {
                                            selectedRemoteImages = selectedRemoteImages + asset.fileId
                                            remoteImageUrls = remoteImageUrls + (asset.fileId to url)
                                            imageUris = imageUris + url
                                        }
                                    } else notice = "Limite de $imageLimit imagens para ${selectedDuration.label}."
                                }
                            },
                            onRemoveUri = { imageUris = imageUris - it },
                        )
                        CreateStep.STYLE -> StyleStep(
                            fontPreset = fontPreset,
                            filterPreset = filterPreset,
                            saveFont = saveFontDefault,
                            onFont = { fontPreset = it },
                            onFilter = { filterPreset = it },
                            onSaveFont = { saveFontDefault = it },
                            lyricsStatus = if (audioSource == AudioSource.SONUS_STREAM) "Fonte SONUS por trackId/fileId" else "Busca externa automática (LRCLIB)",
                        )
                        CreateStep.REVIEW -> ReviewStep(
                            metadata = metadata,
                            selectedDuration = selectedDuration,
                            segmentStartMs = segmentStartMs,
                            imageCount = imageUris.size,
                            signatureText = signatureText,
                            signaturePhoto = signaturePhotoUri != null,
                            font = fontPreset,
                            filter = filterPreset,
                            lyrics = if (audioSource == AudioSource.SONUS_STREAM) "SONUS Stream" else "Automática externa",
                        )
                    }
                }
            }

            BottomFlowBar(
                step = step,
                canContinue = canContinue,
                onPrevious = { if (step == CreateStep.MUSIC) onBack() else step = CreateStep.entries[step.ordinal - 1] },
                onNext = {
                    when (step) {
                        CreateStep.MUSIC -> {
                            if (saveSignatureDefault) scope.launch { preferences.saveSignature(signatureText, signaturePhotoUri?.toString()) }
                            step = CreateStep.IMAGES
                        }
                        CreateStep.IMAGES -> step = CreateStep.STYLE
                        CreateStep.STYLE -> {
                            if (saveFontDefault) scope.launch { preferences.saveFont(fontPreset) }
                            step = CreateStep.REVIEW
                        }
                        CreateStep.REVIEW -> {
                            val meta = metadata
                            val uri = audioUri
                            if (meta != null && uri != null) {
                                onCreateDraft(
                                    CreateProjectDraft(
                                        audioUri = uri.toString(),
                                        audioTitle = meta.title,
                                        audioArtist = meta.artist,
                                        audioDurationMs = meta.durationMs,
                                        audioSource = audioSource,
                                        sourceTrackId = selectedStreamAsset?.fileId?.toString()
                                            ?: (incomingRoute as? IncomingIntentRouter.Route.SonusTrack)?.trackId,
                                        sourceGenre = selectedStreamAsset?.genre,
                                        segmentStartMs = segmentStartMs,
                                        segmentDurationMs = segmentDurationMs,
                                        signatureText = signatureText.trim(),
                                        signaturePhotoUri = signaturePhotoUri?.toString(),
                                        imageUris = imageUris,
                                        fontPreset = fontPreset,
                                        filterPreset = filterPreset,
                                        lyricsPolicy = if (audioSource == AudioSource.SONUS_STREAM) LyricsPolicy.SONUS_ONLY else LyricsPolicy.EXTERNAL_ALLOWED,
                                    )
                                )
                            }
                        }
                    }
                }
            )
        }
    }
}

@Composable
private fun CreateHeader(onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar") }
        Image(painterResource(R.drawable.sonus_edit_logo), "SONUS Edit", Modifier.size(54.dp).clip(RoundedCornerShape(14.dp)))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("SONUS Edit", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
            Text("Automático • vertical 9:16", color = SonusEditColors.TextMuted, fontSize = 12.sp)
        }
        Card(colors = CardDefaults.cardColors(containerColor = SonusEditColors.SurfaceRaised)) {
            Text("0.2.0", Modifier.padding(horizontal = 10.dp, vertical = 7.dp), fontWeight = FontWeight.Bold, fontSize = 11.sp)
        }
    }
}

@Composable
private fun StepTabs(current: CreateStep, onSelect: (CreateStep) -> Unit) {
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        CreateStep.entries.forEachIndexed { index, step ->
            val selected = step == current
            Card(
                modifier = Modifier.clickable(enabled = step.ordinal <= current.ordinal) { onSelect(step) },
                colors = CardDefaults.cardColors(containerColor = if (selected) SonusEditColors.Violet else SonusEditColors.SurfaceRaised),
                shape = RoundedCornerShape(18.dp),
            ) {
                Text("${index + 1} ${step.label}", Modifier.padding(horizontal = 12.dp, vertical = 9.dp), fontSize = 12.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium)
            }
        }
    }
}

@Composable
private fun Section(title: String, subtitle: String, content: @Composable () -> Unit) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = SonusEditColors.Surface)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = SonusEditColors.TextMuted, fontSize = 12.sp)
            content()
        }
    }
}

@Composable
private fun MusicAndSignatureStep(
    signatureText: String,
    signaturePhotoUri: Uri?,
    saveSignature: Boolean,
    onSignatureText: (String) -> Unit,
    onSignaturePhoto: () -> Unit,
    onRemoveSignaturePhoto: () -> Unit,
    onSaveSignature: (Boolean) -> Unit,
    metadata: AudioMetadata?,
    audioSource: AudioSource,
    selectedDuration: DurationPreset,
    segmentStartMs: Long,
    isPlaying: Boolean,
    onStream: () -> Unit,
    onLocal: () -> Unit,
    onDuration: (DurationPreset) -> Unit,
    onStartChange: (Long) -> Unit,
    onFine: (Int) -> Unit,
    onPlayPause: () -> Unit,
) {
    Section("Assinatura", "Fica junto da música e pode ser reutilizada automaticamente.") {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(72.dp).clip(CircleShape).background(SonusEditColors.SurfaceRaised).clickable(onClick = onSignaturePhoto),
                contentAlignment = Alignment.Center,
            ) {
                if (signaturePhotoUri != null) UriThumbnail(signaturePhotoUri, Modifier.fillMaxSize(), ContentScale.Crop)
                else Icon(Icons.Default.AddPhotoAlternate, "Selecionar foto", tint = SonusEditColors.Cyan)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                OutlinedTextField(signatureText, onSignatureText, Modifier.fillMaxWidth(), label = { Text("Nome / usuário") }, singleLine = true)
                if (signaturePhotoUri != null) Text("Remover foto", Modifier.clickable(onClick = onRemoveSignaturePhoto).padding(top = 5.dp), color = SonusEditColors.Cyan, fontSize = 12.sp)
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(saveSignature, onSaveSignature)
            Spacer(Modifier.width(8.dp))
            Text("Usar como assinatura padrão", fontSize = 13.sp)
        }
    }

    Spacer(Modifier.height(14.dp))
    Section("Escolher música", "SONUS Stream simplificado ou música do aparelho.") {
        Button(onClick = onStream, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = SonusEditColors.Violet)) {
            Icon(Icons.Default.AutoAwesome, null); Text("  SONUS STREAM")
        }
        OutlinedButton(onClick = onLocal, Modifier.fillMaxWidth()) { Icon(Icons.Default.MusicNote, null); Text("  Música local") }
        metadata?.let {
            Card(colors = CardDefaults.cardColors(containerColor = SonusEditColors.SurfaceRaised)) {
                Column(Modifier.fillMaxWidth().padding(13.dp)) {
                    Text(it.title, fontWeight = FontWeight.Bold)
                    Text(it.artist ?: if (audioSource == AudioSource.SONUS_STREAM) "SONUS Stream" else "Artista não informado", color = SonusEditColors.TextMuted, fontSize = 12.sp)
                    Text(if (it.durationMs > 0) "${formatTime(it.durationMs)} • ${sourceLabel(audioSource)}" else "Carregando duração…", color = SonusEditColors.Cyan, fontSize = 12.sp)
                }
            }
        }
    }

    Spacer(Modifier.height(14.dp))
    Section("Trecho", "Ajuste claro e horizontal. O play toca exatamente o intervalo escolhido.") {
        Text("Duração", fontWeight = FontWeight.SemiBold)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DurationPreset.all.forEach { preset ->
                FilterChip(selectedDuration == preset, onClick = { onDuration(preset) }, label = { Text(preset.label) })
            }
        }
        val trackMs = metadata?.durationMs ?: 0L
        val segmentMs = selectedDuration.seconds * 1_000L
        val maxStart = (trackMs - segmentMs).coerceAtLeast(0L)
        Slider(
            value = segmentStartMs.coerceAtMost(maxStart).toFloat(),
            onValueChange = { onStartChange(it.roundToLong()) },
            valueRange = 0f..maxStart.coerceAtLeast(1L).toFloat(),
            enabled = trackMs > 0 && maxStart > 0,
        )
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onPlayPause, enabled = trackMs > 0, modifier = Modifier.size(52.dp).background(SonusEditColors.Cyan.copy(alpha = .16f), CircleShape)) {
                Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "Preview", tint = SonusEditColors.Cyan)
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text("${formatTime(segmentStartMs)} → ${formatTime(segmentStartMs + segmentMs)}", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                Text("Início → fim", color = SonusEditColors.TextMuted, fontSize = 11.sp)
            }
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            listOf(-10, -5, -1, 1, 5, 10).forEach { seconds ->
                OutlinedButton(onClick = { onFine(seconds) }) { Text(if (seconds > 0) "+${seconds}s" else "${seconds}s", fontWeight = FontWeight.Bold) }
            }
        }
    }
}

@Composable
private fun StreamPicker(
    assets: List<PCloudAsset>,
    loading: Boolean,
    search: String,
    selectedGenre: String,
    history: List<StreamHistoryStore.Entry>,
    onSearch: (String) -> Unit,
    onGenre: (String) -> Unit,
    onBack: () -> Unit,
    onSelect: (PCloudAsset) -> Unit,
) {
    val suggestion = remember(assets, history) { StreamSuggestionEngine.suggest(assets, history) }
    val genres = remember(assets) { listOf("Todos", "Mais usados") + assets.map { it.genre }.filter { it.isNotBlank() && it != "Outros" }.distinct().sorted() }
    val topGenre = history.groupingBy { it.genre }.eachCount().maxByOrNull { it.value }?.key
    val filtered = assets.filter { asset ->
        val q = search.trim().lowercase()
        val matchesSearch = q.isBlank() || asset.name.lowercase().contains(q) || asset.genre.lowercase().contains(q)
        val matchesGenre = when (selectedGenre) {
            "Todos" -> true
            "Mais usados" -> topGenre == null || asset.genre.equals(topGenre, true)
            else -> asset.genre.equals(selectedGenre, true)
        }
        matchesSearch && matchesGenre
    }

    Column(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar") }
            Text("SONUS Stream", fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
        }
        OutlinedTextField(
            search, onSearch, Modifier.fillMaxWidth(),
            leadingIcon = { Icon(Icons.Default.Search, null) },
            placeholder = { Text("Buscar música, artista ou gênero") },
            singleLine = true,
        )
        Spacer(Modifier.height(12.dp))
        suggestion?.let {
            Card(colors = CardDefaults.cardColors(containerColor = SonusEditColors.Violet.copy(alpha = .22f)), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Text("Sugestão para seu próximo vídeo", color = SonusEditColors.Cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text(it.name.substringBeforeLast('.'), fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                    Text(it.genre, color = SonusEditColors.TextMuted)
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { onSelect(it) }, colors = ButtonDefaults.buttonColors(containerColor = SonusEditColors.Violet)) { Text("USAR ESTA MÚSICA") }
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            genres.forEach { genre -> FilterChip(selected = selectedGenre == genre, onClick = { onGenre(genre) }, label = { Text(genre) }) }
        }
        Spacer(Modifier.height(8.dp))
        if (loading && assets.isEmpty()) Text("Atualizando catálogo…", color = SonusEditColors.TextMuted)
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            items(filtered.size) { index ->
                val asset = filtered[index]
                Card(
                    Modifier.fillMaxWidth().clickable { onSelect(asset) },
                    colors = CardDefaults.cardColors(containerColor = SonusEditColors.SurfaceRaised),
                ) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(44.dp).background(SonusEditColors.Violet.copy(alpha = .25f), RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.MusicNote, null, tint = SonusEditColors.Cyan)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(asset.name.substringBeforeLast('.'), fontWeight = FontWeight.Bold, maxLines = 1)
                            Text(asset.genre, color = SonusEditColors.TextMuted, fontSize = 11.sp)
                        }
                        Icon(Icons.Default.PlayArrow, null, tint = SonusEditColors.Cyan)
                    }
                }
            }
        }
    }
}

@Composable
private fun ImagesStep(
    localOrRemoteUris: List<String>,
    selectedRemoteIds: Set<Long>,
    remoteAssets: List<PCloudAsset>,
    remoteMode: Boolean,
    limit: Int,
    loading: Boolean,
    imageRepo: PCloudImageRepository,
    onRemoteMode: (Boolean) -> Unit,
    onLocal: () -> Unit,
    onRemoteToggle: (PCloudAsset) -> Unit,
    onRemoveUri: (String) -> Unit,
) {
    Section("Escolher imagens", "Só escolha as imagens. O SONUS Edit calcula duração, crop 9:16 e distribuição sozinho.") {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(remoteMode, onClick = { onRemoteMode(true) }, label = { Text("SONUS Gallery") })
            FilterChip(!remoteMode, onClick = { onRemoteMode(false) }, label = { Text("Local") })
        }
        Text("${localOrRemoteUris.size} / $limit selecionadas", color = SonusEditColors.Cyan, fontWeight = FontWeight.Bold)
        if (!remoteMode) {
            Button(onClick = onLocal, Modifier.fillMaxWidth()) { Icon(Icons.Default.AddPhotoAlternate, null); Text("  Adicionar da galeria") }
            localOrRemoteUris.chunked(3).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { value ->
                        val uri = Uri.parse(value)
                        Box(Modifier.weight(1f).aspectRatio(1f).clip(RoundedCornerShape(14.dp)).background(SonusEditColors.SurfaceRaised).clickable { onRemoveUri(value) }) {
                            if (uri.scheme == "content" || uri.scheme == "file") UriThumbnail(uri, Modifier.fillMaxSize(), ContentScale.Crop)
                            else Icon(Icons.Default.Image, null, Modifier.align(Alignment.Center), tint = SonusEditColors.Cyan)
                            Icon(Icons.Default.Close, "Remover", Modifier.align(Alignment.TopEnd).padding(4.dp).background(Color.Black.copy(alpha=.55f), CircleShape), tint = Color.White)
                        }
                    }
                    repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        } else {
            if (loading && remoteAssets.isEmpty()) Text("Atualizando Sonus Gallery…", color = SonusEditColors.TextMuted)
            remoteAssets.take(30).chunked(3).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { asset ->
                        val selected = asset.fileId in selectedRemoteIds
                        Box(
                            Modifier.weight(1f).aspectRatio(1f).clip(RoundedCornerShape(14.dp))
                                .border(if (selected) 3.dp else 1.dp, if (selected) SonusEditColors.Cyan else SonusEditColors.SurfaceRaised, RoundedCornerShape(14.dp))
                                .clickable { onRemoteToggle(asset) }
                        ) {
                            RemoteAssetThumbnail(asset, imageRepo, Modifier.fillMaxSize())
                            if (selected) Icon(Icons.Default.CheckCircle, "Selecionada", Modifier.align(Alignment.TopEnd).padding(5.dp), tint = SonusEditColors.Cyan)
                        }
                    }
                    repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
    }
}

@Composable
private fun StyleStep(
    fontPreset: FontPresetId,
    filterPreset: FilterPresetId,
    saveFont: Boolean,
    onFont: (FontPresetId) -> Unit,
    onFilter: (FilterPresetId) -> Unit,
    onSaveFont: (Boolean) -> Unit,
    lyricsStatus: String,
) {
    Section("Fonte da letra", "Cada opção mostra sua própria personalidade visual.") {
        FontPresetId.entries.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { preset ->
                    FontPreviewCard(preset, fontPreset == preset, Modifier.weight(1f)) { onFont(preset) }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) { Switch(saveFont, onSaveFont); Text("  Usar como padrão") }
    }
    Spacer(Modifier.height(14.dp))
    Section("Letra sincronizada", "No Stream, a fonte deve ser a mesma usada pelo SONUS; música local usa fallback externo.") {
        Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.CheckCircle, null, tint = SonusEditColors.Cyan); Text("  $lyricsStatus", fontWeight = FontWeight.Bold) }
        Text("Paleta por linha: ciano • verde • rosa • amarelo • roxo • vermelho • azul", color = SonusEditColors.TextMuted, fontSize = 12.sp)
        NeonLyricsPreview()
    }
    Spacer(Modifier.height(14.dp))
    Section("Filtro", "Presets compatíveis com o Social Edit, sem painel técnico.") {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterPresetId.entries.forEach { preset -> FilterChip(filterPreset == preset, onClick = { onFilter(preset) }, label = { Text(preset.label) }) }
        }
    }
}

@Composable
private fun FontPreviewCard(preset: FontPresetId, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val style = fontPreviewStyle(preset)
    Card(
        modifier.clickable(onClick = onClick).border(if (selected) 2.dp else 0.dp, SonusEditColors.Cyan, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = SonusEditColors.SurfaceRaised),
        shape = RoundedCornerShape(16.dp),
    ) {
        Column(Modifier.fillMaxWidth().padding(12.dp)) {
            Text(preset.label, color = SonusEditColors.TextMuted, fontSize = 10.sp)
            Text("SONUS", style = style, maxLines = 1)
        }
    }
}

private fun fontPreviewStyle(preset: FontPresetId): TextStyle = when (preset) {
    FontPresetId.DEFAULT -> TextStyle(fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
    FontPresetId.MODERN -> TextStyle(fontSize = 18.sp, fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Light, letterSpacing = 2.sp)
    FontPresetId.ELEGANT -> TextStyle(fontSize = 19.sp, fontFamily = FontFamily.Serif, fontStyle = FontStyle.Italic)
    FontPresetId.CLASSIC -> TextStyle(fontSize = 18.sp, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold)
    FontPresetId.MINIMAL -> TextStyle(fontSize = 16.sp, fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Thin, letterSpacing = 3.sp)
    FontPresetId.IMPACT -> TextStyle(fontSize = 21.sp, fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Black)
    FontPresetId.HANDWRITTEN -> TextStyle(fontSize = 21.sp, fontFamily = FontFamily.Cursive, fontStyle = FontStyle.Italic)
    FontPresetId.RETRO -> TextStyle(fontSize = 18.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
    FontPresetId.NEON -> TextStyle(fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Color.Cyan, shadow = Shadow(Color.Magenta, Offset(0f, 0f), 14f))
    FontPresetId.EDITORIAL -> TextStyle(fontSize = 20.sp, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Medium, letterSpacing = .5.sp)
}

@Composable
private fun NeonLyricsPreview() {
    val lines = listOf(
        "A música encontra a imagem" to Color.Cyan,
        "cada linha muda de cor" to Color(0xFFFF4FA3),
        "sem perder a leitura" to Color(0xFFB8FF4F),
    )
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF050711))) {
        Column(Modifier.fillMaxWidth().padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            lines.forEach { (line, color) -> Text(line, color = color, style = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.Bold, shadow = Shadow(color, Offset.Zero, 9f))) }
        }
    }
}

@Composable
private fun ReviewStep(
    metadata: AudioMetadata?,
    selectedDuration: DurationPreset,
    segmentStartMs: Long,
    imageCount: Int,
    signatureText: String,
    signaturePhoto: Boolean,
    font: FontPresetId,
    filter: FilterPresetId,
    lyrics: String,
) {
    Section("Revisão", "Confira. Ao tocar Criar vídeo, a exportação começa imediatamente.") {
        ReviewLine("Música", metadata?.title ?: "—")
        ReviewLine("Artista", metadata?.artist ?: "—")
        ReviewLine("Trecho", "${formatTime(segmentStartMs)} → ${formatTime(segmentStartMs + selectedDuration.seconds * 1_000L)}")
        ReviewLine("Duração", selectedDuration.label)
        ReviewLine("Imagens", imageCount.toString())
        ReviewLine("Letra", lyrics)
        ReviewLine("Fonte", font.label)
        ReviewLine("Filtro", filter.label)
        ReviewLine("Assinatura", if (signatureText.isNotBlank() || signaturePhoto) "Ativa" else "Desativada")
        ReviewLine("Formato", "9:16 • 1080x1920")
    }
}

@Composable
private fun ReviewLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(label, Modifier.weight(1f), color = SonusEditColors.TextMuted)
        Text(value, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun BottomFlowBar(step: CreateStep, canContinue: Boolean, onPrevious: () -> Unit, onNext: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(SonusEditColors.Surface).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedButton(onClick = onPrevious) { Text(if (step == CreateStep.MUSIC) "Voltar" else "Anterior") }
        Spacer(Modifier.weight(1f))
        Button(onClick = onNext, enabled = canContinue, colors = ButtonDefaults.buttonColors(containerColor = SonusEditColors.Violet)) {
            Text(if (step == CreateStep.REVIEW) "CRIAR VÍDEO" else "AVANÇAR")
        }
    }
}

@Composable
private fun UriThumbnail(uri: Uri, modifier: Modifier, contentScale: ContentScale) {
    val context = LocalContext.current
    val bitmap by produceState<ImageBitmap?>(null, uri) {
        value = withContext(Dispatchers.IO) {
            runCatching { context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it)?.asImageBitmap() } }.getOrNull()
        }
    }
    if (bitmap != null) Image(bitmap!!, null, modifier, contentScale = contentScale)
    else Box(modifier.background(SonusEditColors.SurfaceRaised), contentAlignment = Alignment.Center) { Icon(Icons.Default.Image, null, tint = SonusEditColors.Cyan) }
}

@Composable
private fun RemoteAssetThumbnail(asset: PCloudAsset, repository: PCloudImageRepository, modifier: Modifier) {
    val bitmap by produceState<ImageBitmap?>(null, asset.fileId) {
        value = withContext(Dispatchers.IO) {
            val url = repository.thumbnailUrl(asset) ?: return@withContext null
            runCatching {
                val connection = URI.create(url).toURL().openConnection() as HttpURLConnection
                connection.connectTimeout = 7_000; connection.readTimeout = 10_000
                try { connection.inputStream.use { BitmapFactory.decodeStream(it)?.asImageBitmap() } } finally { connection.disconnect() }
            }.getOrNull()
        }
    }
    if (bitmap != null) Image(bitmap!!, asset.name, modifier, contentScale = ContentScale.Crop)
    else Box(modifier.background(SonusEditColors.SurfaceRaised), contentAlignment = Alignment.Center) { Icon(Icons.Default.Image, null, tint = SonusEditColors.Cyan) }
}

private fun sourceLabel(source: AudioSource): String = when (source) {
    AudioSource.LOCAL -> "Local"
    AudioSource.SONUS_STREAM -> "SONUS Stream"
    AudioSource.SHARED -> "Compartilhada"
}

private fun formatTime(ms: Long): String {
    val total = (ms.coerceAtLeast(0L) / 1_000L)
    val minutes = total / 60
    val seconds = total % 60
    return "%02d:%02d".format(minutes, seconds)
}
