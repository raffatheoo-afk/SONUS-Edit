package com.sonusstudios.sonusedit.media

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.sonusstudios.sonusedit.create.CreateProjectDraft
import com.sonusstudios.sonusedit.create.MediaDistributionPlanner
import java.io.File

@OptIn(UnstableApi::class)
class AutomaticVideoExporter(private val context: Context) {
    private val main = Handler(Looper.getMainLooper())
    private var transformer: Transformer? = null
    private var tempFile: File? = null

    fun start(
        draft: CreateProjectDraft,
        onCompleted: (Uri) -> Unit,
        onError: (Throwable) -> Unit,
    ) {
        require(draft.imageUris.isNotEmpty()) { "Selecione ao menos uma imagem." }
        cancel()

        val durations = MediaDistributionPlanner.durationsMs(
            (draft.segmentDurationMs / 1_000L).toInt(),
            draft.imageUris.size,
        )
        val cropToVertical: List<Effect> = listOf(
            Presentation.createForWidthAndHeight(
                1080,
                1920,
                Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP,
            )
        )
        val visualItems = draft.imageUris.zip(durations).map { (uriString, durationMs) ->
            val mediaItem = MediaItem.Builder()
                .setUri(Uri.parse(uriString))
                .setImageDurationMs(durationMs)
                .build()
            EditedMediaItem.Builder(mediaItem)
                .setFrameRate(30)
                .setEffects(Effects(emptyList(), cropToVertical))
                .build()
        }
        val videoSequence = EditedMediaItemSequence.withVideoFrom(visualItems)

        val endMs = draft.segmentStartMs + draft.segmentDurationMs
        val audioItem = MediaItem.Builder()
            .setUri(Uri.parse(draft.audioUri))
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(draft.segmentStartMs)
                    .setEndPositionMs(endMs)
                    .build()
            )
            .build()
        val audioSequence = EditedMediaItemSequence.withAudioFrom(
            listOf(EditedMediaItem.Builder(audioItem).build())
        )
        val composition = Composition.Builder(videoSequence, audioSequence).build()
        val output = File(context.cacheDir, "sonus_edit_${System.currentTimeMillis()}.mp4")
        tempFile = output

        val localTransformer = Transformer.Builder(context)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    Thread {
                        runCatching { saveToGallery(output, draft.audioTitle) }
                            .onSuccess { uri -> main.post { onCompleted(uri) } }
                            .onFailure { error -> main.post { onError(error) } }
                    }.start()
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException,
                ) {
                    onError(exportException)
                }
            })
            .build()
        transformer = localTransformer
        localTransformer.start(composition, output.absolutePath)
    }

    fun progressPercent(): Int? {
        val local = transformer ?: return null
        val holder = ProgressHolder()
        val state = local.getProgress(holder)
        return if (state == Transformer.PROGRESS_STATE_AVAILABLE) holder.progress else null
    }

    fun cancel() {
        transformer?.cancel()
        transformer = null
        tempFile?.takeIf { it.exists() }?.delete()
        tempFile = null
    }

    private fun saveToGallery(source: File, title: String): Uri {
        val safe = title.replace(Regex("[^A-Za-z0-9_\\- ]"), "").trim().ifBlank { "SONUS_Edit" }
        val fileName = "${safe.take(48)}_${System.currentTimeMillis()}.mp4"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/SONUS Edit")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: error("Não foi possível criar o vídeo na galeria.")
            try {
                resolver.openOutputStream(uri, "w")!!.use { out -> source.inputStream().use { it.copyTo(out) } }
                values.clear()
                values.put(MediaStore.Video.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                source.delete()
                return uri
            } catch (t: Throwable) {
                resolver.delete(uri, null, null)
                throw t
            }
        }

        val dir = File(context.getExternalFilesDir(Environment.DIRECTORY_MOVIES), "SONUS Edit").apply { mkdirs() }
        val target = File(dir, fileName)
        source.copyTo(target, overwrite = true)
        source.delete()
        return Uri.fromFile(target)
    }
}
