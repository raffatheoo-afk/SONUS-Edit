package com.sonusstudios.sonusedit.catalog

import android.content.Context

class StreamHistoryStore(context: Context) {
    private val prefs = context.getSharedPreferences("sonus_edit_stream_history", Context.MODE_PRIVATE)

    data class Entry(val fileId: Long, val genre: String)

    fun recent(limit: Int = 20): List<Entry> = prefs.getString("recent", "")
        .orEmpty()
        .split(';')
        .mapNotNull { token ->
            val parts = token.split('|', limit = 2)
            val id = parts.getOrNull(0)?.toLongOrNull() ?: return@mapNotNull null
            Entry(id, parts.getOrNull(1).orEmpty())
        }
        .take(limit)

    fun record(asset: PCloudAsset) {
        val updated = (listOf(Entry(asset.fileId, asset.genre)) + recent(30).filterNot { it.fileId == asset.fileId })
            .take(30)
        prefs.edit().putString("recent", updated.joinToString(";") { "${it.fileId}|${it.genre}" }).apply()
    }
}

object StreamSuggestionEngine {
    fun suggest(catalog: List<PCloudAsset>, history: List<StreamHistoryStore.Entry>): PCloudAsset? {
        if (catalog.isEmpty()) return null
        val genreCounts = history.groupingBy { it.genre.lowercase() }.eachCount()
        val topGenre = genreCounts.maxByOrNull { it.value }?.key
        val last = history.firstOrNull()
        val recentIds = history.take(8).map { it.fileId }.toSet()

        return catalog.maxByOrNull { asset ->
            var score = 0
            val genre = asset.genre.lowercase()
            if (genre.isNotBlank() && genre == topGenre) score += 5
            if (last != null && genre == last.genre.lowercase()) score += 4
            if (asset.fileId !in recentIds) score += 2
            if (asset.fileId == last?.fileId) score -= 5
            score -= history.count { it.fileId == asset.fileId } * 3
            score
        }
    }
}
