package com.sonusstudios.sonusedit.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonusstudios.sonusedit.R
import com.sonusstudios.sonusedit.catalog.PCloudAsset
import com.sonusstudios.sonusedit.catalog.PCloudMusicRepository
import com.sonusstudios.sonusedit.catalog.StreamHistoryStore
import com.sonusstudios.sonusedit.catalog.StreamSuggestionEngine
import com.sonusstudios.sonusedit.designsystem.SonusEditColors

private val homeMusicExtensions = setOf("mp3", "wav", "flac", "m4a", "aac", "ogg", "opus")

@Composable
fun HomeScreen(
    onCreate: () -> Unit,
    onUseSuggestion: (PCloudAsset) -> Unit,
) {
    val context = LocalContext.current
    val repository = remember { PCloudMusicRepository(context.applicationContext) }
    val history = remember { StreamHistoryStore(context.applicationContext) }
    var suggestion by remember { mutableStateOf<PCloudAsset?>(null) }

    LaunchedEffect(Unit) {
        val cached = repository.cached().filter { it.extension in homeMusicExtensions }
        if (cached.isNotEmpty()) suggestion = StreamSuggestionEngine.suggest(cached, history.recent())
        val fresh = repository.refresh().filter { it.extension in homeMusicExtensions }
        if (fresh.isNotEmpty()) suggestion = StreamSuggestionEngine.suggest(fresh, history.recent())
    }

    Column(
        Modifier.fillMaxSize().background(SonusEditColors.Black).padding(horizontal = 20.dp, vertical = 28.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.sonus_edit_logo), "SONUS Edit", Modifier.size(82.dp))
            Spacer(Modifier.size(14.dp))
            Column {
                Text("SONUS", fontSize = 13.sp, color = SonusEditColors.Cyan, fontWeight = FontWeight.Bold)
                Text("Edit", fontSize = 36.sp, fontWeight = FontWeight.ExtraBold)
                Text("0.2.0 • code02", color = SonusEditColors.TextMuted, fontSize = 11.sp)
            }
        }

        Text("Escolha. Revise. O SONUS Edit monta e exporta sozinho.", color = SonusEditColors.TextMuted, fontSize = 17.sp)

        suggestion?.let { asset ->
            Card(
                Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = SonusEditColors.Violet.copy(alpha = .22f)),
            ) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("SUGESTÃO PARA O PRÓXIMO VÍDEO", color = SonusEditColors.Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text(asset.name.substringBeforeLast('.'), fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                    Text(asset.genre, color = SonusEditColors.TextMuted)
                    Button(onClick = { onUseSuggestion(asset) }, colors = ButtonDefaults.buttonColors(containerColor = SonusEditColors.Violet)) {
                        Icon(Icons.Default.MusicNote, null)
                        Text("  USAR ESTA MÚSICA")
                    }
                }
            }
        }

        Card(
            Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = SonusEditColors.Surface),
        ) {
            Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AutoAwesome, null, tint = SonusEditColors.Cyan)
                    Spacer(Modifier.size(10.dp))
                    Text("Criar vídeo automático", fontWeight = FontWeight.Bold, fontSize = 21.sp)
                }
                Text("Assinatura + música → imagens → estilo/letra → revisão → exportação automática.", color = SonusEditColors.TextMuted)
                Button(onClick = onCreate, colors = ButtonDefaults.buttonColors(containerColor = SonusEditColors.Violet)) {
                    Icon(Icons.Default.PlayArrow, null)
                    Text("  CRIAR VÍDEO")
                }
            }
        }
    }
}
