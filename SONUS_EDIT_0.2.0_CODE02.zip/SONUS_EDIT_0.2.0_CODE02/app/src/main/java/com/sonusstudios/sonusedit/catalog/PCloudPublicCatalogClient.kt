package com.sonusstudios.sonusedit.catalog

import java.net.HttpURLConnection
import java.net.URI
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.longOrNull
import kotlinx.serialization.json.doubleOrNull

class PCloudPublicCatalogClient(
    private val json: Json = Json { ignoreUnknownKeys = true },
) {
    private val bases = listOf("https://api.pcloud.com", "https://eapi.pcloud.com")

    suspend fun listAssets(publicCode: String): List<PCloudAsset> = withContext(Dispatchers.IO) {
        val body = request("showpublink", mapOf("code" to publicCode)) ?: return@withContext emptyList()
        val root = runCatching { json.parseToJsonElement(body).jsonObject }.getOrNull() ?: return@withContext emptyList()
        val metadata = root["metadata"]?.jsonObject ?: return@withContext emptyList()
        buildList { walk(metadata, "", this) }.distinctBy { it.fileId }
    }

    suspend fun resolveDownloadUrl(publicCode: String, fileId: Long): String? = withContext(Dispatchers.IO) {
        val body = request("getpublinkdownload", mapOf("code" to publicCode, "fileid" to fileId.toString()))
            ?: return@withContext null
        val root = runCatching { json.parseToJsonElement(body).jsonObject }.getOrNull() ?: return@withContext null
        val host = root["hosts"]?.jsonArray?.firstOrNull()?.jsonPrimitive?.content ?: return@withContext null
        val path = root["path"]?.jsonPrimitive?.content ?: return@withContext null
        "https://$host$path"
    }

    suspend fun resolveThumbnailUrl(publicCode: String, fileId: Long): String? = withContext(Dispatchers.IO) {
        val body = request(
            "getpubthumblink",
            mapOf("code" to publicCode, "fileid" to fileId.toString(), "size" to "512x512", "crop" to "1")
        ) ?: return@withContext null
        val root = runCatching { json.parseToJsonElement(body).jsonObject }.getOrNull() ?: return@withContext null
        val host = root["hosts"]?.jsonArray?.firstOrNull()?.jsonPrimitive?.content ?: return@withContext null
        val path = root["path"]?.jsonPrimitive?.content ?: return@withContext null
        "https://$host$path"
    }

    private fun walk(node: JsonObject, parent: String, out: MutableList<PCloudAsset>) {
        val isFolder = node["isfolder"]?.jsonPrimitive?.booleanOrNull == true
        val name = node["name"]?.jsonPrimitive?.content.orEmpty()
        val currentPath = if (name.isBlank()) parent else listOf(parent, name).filter { it.isNotBlank() }.joinToString("/")
        if (!isFolder) {
            val fileId = node["fileid"]?.jsonPrimitive?.longOrNull ?: return
            out += PCloudAsset(
                fileId = fileId,
                name = name,
                size = node["size"]?.jsonPrimitive?.longOrNull ?: 0,
                contentType = node["contenttype"]?.jsonPrimitive?.contentOrNull,
                folderPath = parent,
                modified = node["modified"]?.jsonPrimitive?.contentOrNull,
                durationMs = node["duration"]?.jsonPrimitive?.doubleOrNull?.let { (it * 1000.0).toLong() },
            )
            return
        }
        val contents = node["contents"] as? JsonArray ?: return
        contents.forEach { child -> (child as? JsonObject)?.let { walk(it, currentPath, out) } }
    }

    private fun request(endpoint: String, params: Map<String, String>): String? {
        for (base in bases) {
            val query = params.entries.joinToString("&") { (k, v) -> "${enc(k)}=${enc(v)}" }
            val connection = (URI.create("$base/$endpoint?$query").toURL().openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 8_000
                readTimeout = 12_000
                setRequestProperty("Accept", "application/json")
                setRequestProperty("User-Agent", "SONUS-Edit/0.2.0 Android")
            }
            try {
                if (connection.responseCode == HttpURLConnection.HTTP_OK) {
                    return connection.inputStream.bufferedReader().use { it.readText() }
                }
            } catch (_: Throwable) {
                // Try the tolerant alternate pCloud API base.
            } finally {
                connection.disconnect()
            }
        }
        return null
    }

    private fun enc(value: String): String = URLEncoder.encode(value, StandardCharsets.UTF_8.toString())
}

private val kotlinx.serialization.json.JsonPrimitive.contentOrNull: String?
    get() = runCatching { content }.getOrNull()
