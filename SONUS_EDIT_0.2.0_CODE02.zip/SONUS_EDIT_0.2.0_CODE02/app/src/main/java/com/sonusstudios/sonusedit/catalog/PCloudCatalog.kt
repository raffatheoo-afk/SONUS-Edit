package com.sonusstudios.sonusedit.catalog

import kotlinx.serialization.Serializable

object SonusPublicCatalogs {
    const val IMAGE_PUBLIC_CODE = "kZspB4JZmPJsxI5SKzQ1dgJWSicA2bQzFJhX"
    const val MUSIC_PUBLIC_CODE = "kZoiqzJZYKnSUcvcE3yhv2kogYMgtzmoSLyX"
}

@Serializable
data class PCloudAsset(
    val fileId: Long,
    val name: String,
    val size: Long = 0,
    val contentType: String? = null,
    val folderPath: String = "",
    val modified: String? = null,
    val durationMs: Long? = null,
) {
    val extension: String get() = name.substringAfterLast('.', "").lowercase()
    val genre: String get() = folderPath.split('/').lastOrNull { it.isNotBlank() } ?: "Outros"
}

@Serializable
data class CatalogSnapshot(
    val updatedAtMs: Long,
    val assets: List<PCloudAsset>,
)
