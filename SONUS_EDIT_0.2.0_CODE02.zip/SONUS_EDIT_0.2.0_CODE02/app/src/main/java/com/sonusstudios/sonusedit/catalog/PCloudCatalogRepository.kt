package com.sonusstudios.sonusedit.catalog

import android.content.Context
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

open class PCloudCatalogRepository(
    context: Context,
    private val publicCode: String,
    cacheName: String,
    private val client: PCloudPublicCatalogClient = PCloudPublicCatalogClient(),
    private val json: Json = Json { ignoreUnknownKeys = true },
) {
    private val cacheFile = File(context.filesDir, "catalog_$cacheName.json")

    suspend fun cached(): List<PCloudAsset> = withContext(Dispatchers.IO) {
        runCatching {
            if (!cacheFile.exists()) return@runCatching emptyList()
            json.decodeFromString<CatalogSnapshot>(cacheFile.readText()).assets
        }.getOrDefault(emptyList())
    }

    suspend fun refresh(): List<PCloudAsset> = withContext(Dispatchers.IO) {
        val fresh = client.listAssets(publicCode)
        if (fresh.isNotEmpty()) {
            runCatching { cacheFile.writeText(json.encodeToString(CatalogSnapshot(System.currentTimeMillis(), fresh))) }
            fresh
        } else cached()
    }

    suspend fun downloadUrl(asset: PCloudAsset): String? = client.resolveDownloadUrl(publicCode, asset.fileId)
    suspend fun thumbnailUrl(asset: PCloudAsset): String? = client.resolveThumbnailUrl(publicCode, asset.fileId)
}

class PCloudMusicRepository(context: Context) : PCloudCatalogRepository(
    context = context,
    publicCode = SonusPublicCatalogs.MUSIC_PUBLIC_CODE,
    cacheName = "music",
)

class PCloudImageRepository(context: Context) : PCloudCatalogRepository(
    context = context,
    publicCode = SonusPublicCatalogs.IMAGE_PUBLIC_CODE,
    cacheName = "images",
)
