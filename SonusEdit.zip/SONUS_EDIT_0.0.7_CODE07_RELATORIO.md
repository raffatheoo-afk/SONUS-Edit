# Sonus Edit 0.0.7 — CODE 07

## Objetivo

Corrigir regressões visuais e tipográficas do CODE 06, usando o código efetivamente fornecido na versão 0.0.5 — CODE 05 como referência para fontes. Preservar as melhorias de cores, estilos de legenda e filtros que o usuário aprovou.

## Fontes — restauração do CODE 05

- Restaurado `CaptionFontPool` aprovado no CODE 05: 11 opções selecionáveis, sendo 10 arquivos tipográficos personalizados e a opção Sans-serif.
- Restaurado o resolvedor de fontes do CODE 05 e a pré-visualização que carrega os arquivos TTF/OTF de `app/src/main/assets/fonts`.
- Os 10 arquivos de fontes foram comparados por SHA-256 com os arquivos do ZIP CODE 05 fornecido; todos são idênticos.
- Os 30 IDs genéricos de fontes de sistema introduzidos no CODE 06 continuam no enum para leitura de rascunhos antigos, mas não aparecem mais como opções. Eles são convertidos para opções reais do catálogo restaurado.
- O seletor foi transformado em uma única faixa horizontal para não aumentar a altura da tela.

**Nota de fidelidade ao arquivo de referência:** o ZIP CODE 05 recebido contém 10 arquivos TTF/OTF e 11 opções aprovadas, não 30 arquivos ou 30 opções aprovadas. O CODE 07 recupera fielmente o catálogo e os arquivos disponíveis no ZIP. Não cria duplicatas nem apresenta variações genéricas do Android como novas fontes personalizadas.

## Interface de estilo e cores

- Mantidos os 20 estilos de legenda, incluindo os dez estilos ilustrativos Premium.
- Reduzida a altura dos cartões de estilo; o canvas animado continua sendo atualizado durante a prévia.
- Reduzidos os botões de cor para 56 × 34 dp, com amostra e nome compacto abaixo; paleta permanece horizontal e inclui 25 opções.
- O selo textual grande foi substituído por uma pequena coroa 👑 nos pontos Premium ilustrativos, incluindo Dinâmico, cartões de estilos e filtros.

## Filtros

- Preservadas as duas fileiras: 15 opções gratuitas e 10 opções Premium ilustrativas.
- Reduzidos os cartões de filtro.
- A instrução de uso passou para a mesma linha do título FILTROS, na mesma escala tipográfica.
- Os IDs e a seleção automática de filtros foram preservados.

## Posição de legenda

- 9:16 inicia no meio do quadro.
- 16:9 inicia embaixo.
- Preferências manuais são gravadas separadamente por orientação para não transportar uma posição manual de um formato para o outro.
- A posição manual continua ajustável pelos controles existentes.

## Identidade e contratos preservados

- `applicationId`: `com.sonusstudios.sonusedit`.
- `versionName`: `0.0.7`; `versionCode`: `7`.
- Workflow Codemagic: `sonus-edit-0-0-3-code03-debug` (inalterado).
- Material de assinatura permanente mantido, sem revelar seu conteúdo no relatório.
- Media3 1.10.1, Whisper Small com `ENGINE_VERSION = 16`, Link, yt-dlp e FFmpeg preservados.
- Paleta de cores do CODE 06 (25 opções) e filas de filtros (15 + 10) mantidas.

## Verificações realizadas

- Validador estático CODE 07: aprovado.
- YAML Codemagic: parseado com sucesso; ID do workflow e material de assinatura comparados com CODE 06.
- Cinco declarações Media3 1.10.1 confirmadas.
- Dez arquivos de fontes personalizados do CODE 05 comparados byte a byte.
- Integridade do ZIP final: aprovada com `unzip -t` (nenhum erro no arquivo compactado).

## Limitações

- A pasta Google Drive indicada pelo usuário não foi acessível neste ambiente, portanto a fotografia não foi inspecionada. A implementação visual foi baseada no código e nas descrições fornecidas. Para validar medidas contra a captura real, a imagem deve ser anexada diretamente à conversa.
- Não foi possível executar Gradle/JUnit nem compilar APK aqui: o ambiente de trabalho não contém Gradle, wrapper do projeto nem Android SDK. A suíte de testes precisa ser executada no Codemagic. Nenhuma compilação de APK é declarada neste relatório.
