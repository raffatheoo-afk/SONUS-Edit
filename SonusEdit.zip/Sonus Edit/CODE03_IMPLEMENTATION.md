# Sonus Edit 0.0.3 / code03

Pacote implementado sobre a base 0.2.0/code02.

Principais mudanças desta rodada:
- Nome oficial exibido: Sonus Edit.
- Splash de 3 segundos com identidade própria e assinatura `by SONUS STUDIOS - RΛFΛ亗`.
- Catálogo Stream unificado de duas fontes públicas pCloud.
- Metadados reais de áudio e status discreto de letra sincronizada.
- LRCLIB automática + busca manual pela lupa.
- Smart Start rápido com prioridade para letra/refrão quando disponível e fallback por energia do áudio.
- Presets de trecho limitados a 15/30/40/50/60/65/90/120 segundos.
- Timeline de imagens corrigida para preencher 100% da duração; mínimo de 5s por imagem.
- Fade visual de 1,5s por imagem e fade de áudio de 2,5s no início/fim.
- 13 efeitos automáticos contextuais derivados dos vídeos fornecidos, pré-processados para transparência.
- Assinatura, letra sincronizada, título e artista renderizados no vídeo final.
- Revisão com edição de título e artista sem alterar os metadados originais do áudio.
- Exportação 9:16 real: 720x1280, 1080x1920, 1440x2560 e 2160x3840.
- FPS selecionável: 30, 60 e 90, com validação do resultado para impedir downgrade silencioso.
- Assinatura de APK: usa chave segura do Codemagic quando configurada; fallback gera e cacheia uma chave persistente de desenvolvimento.

IMPORTANTE: este pacote foi validado estaticamente no ambiente de preparação. A compilação Android real e testes em aparelho dependem do Codemagic/Android e não devem ser chamados de BUILD GREEN antes de executados.
