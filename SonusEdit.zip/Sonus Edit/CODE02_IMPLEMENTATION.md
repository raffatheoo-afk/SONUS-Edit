# SONUS Edit 0.2.0 / code02

## Direção
Code02 transforma o wizard da code01 em fluxo automático enxuto:

Assinatura + Música → Imagens → Estilo/Letra → Revisão → Exportação → Galeria.

## Implementado no pacote
- versionName 0.2.0 / versionCode 2.
- novo logo sem anel e adaptive launcher icon.
- assinatura integrada à primeira etapa.
- etapa exclusiva de assinatura removida.
- ajuste fino horizontal -10s/-5s/-1s/+1s/+5s/+10s.
- presets de 15s a 10min.
- cliente público pCloud e repositories para SONUS MUSIC / Sonus Gallery.
- snapshot local de catálogo e refresh silencioso (cache-first).
- Stream simplificado com busca, gêneros, lista e sugestão.
- histórico local para sugestão do próximo vídeo.
- regra de 5s mínimos por imagem preservada.
- seleção local e Sonus Gallery.
- 10 previews tipográficos visualmente distintos.
- preview de paleta neon por linha.
- presets de filtros preservados no modelo/UI.
- revisão final.
- botão CRIAR VÍDEO abre export automático, não timeline.
- export base Media3 Composition com múltiplas imagens + trecho de áudio + crop 1080x1920.
- progresso/cancelamento e salvamento via MediaStore em Android 10+.
- tela final Assistir / Compartilhar / Criar outro.

## Limites conhecidos que NÃO devem ser mascarados
1. O código/fonte real da letra sincronizada usada por `com.sonusstudios.streampulse` não está no projeto SONUS Edit fornecido. CODE02 cria `SonusLyricsResolver` e mantém SONUS Stream separado do LRCLIB, porém o resolver concreto depende do módulo/endpoint real do SONUS principal.
2. Media3 Composition exporta a sequência de imagens + áudio. Crossfade nativo entre itens em Composition não é suportado pela API atual; portanto o “Fade Suave 2s” permanece especificado no modelo/UX, mas não deve ser declarado validado no arquivo final até existir efeito temporal próprio.
3. O overlay final de assinatura e letras neon ainda exige o compositor/overlay temporal do export. A UI e contratos estão preparados, mas não devem ser declarados renderizados sem teste real.
4. A barra de progresso segue a identidade do SONUS visualmente; para ser literalmente o mesmo componente/código do SONUS principal, é necessário receber o componente-fonte real.
5. Nenhuma função de mídia/rede/encoder deve ser declarada BUILD GREEN sem build Codemagic e teste em aparelho.
