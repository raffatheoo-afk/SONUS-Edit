# Sonus Edit 0.0.4 / code04

Implementação autorizada por Rafa sobre a base 0.0.3/code03.

Principais pontos desta rodada:
- assinatura persistente obrigatória; o workflow não gera chave nova;
- ícone adaptive com safe-zone maior;
- exportação 9:16 validada pela orientação visual real do MP4;
- integração de letras do SONUS pela mesma fonte pública de trackOverrides, com LRCLIB fallback;
- Automação Total e configurações individuais;
- 15s somente manual; automação começa em 30s;
- seleção automática contextual de duração, imagens, filtro, fonte e efeito;
- Gerar outra combinação na revisão;
- contraste branco/amarelo/verde corrigido nas superfícies críticas;
- qualidade/FPS em verde, exportação verde e cancelar vermelho.

Build real e testes em aparelho dependem do Codemagic/APK. Não considerar BUILD GREEN apenas por este pacote.
