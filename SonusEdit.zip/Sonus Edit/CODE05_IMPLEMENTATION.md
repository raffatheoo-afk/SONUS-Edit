# Sonus Edit 0.0.5 / code05

Implementação autorizada por Rafa sobre a base oficial 0.0.4/code04 — Build Fix 1.

Principais mudanças desta rodada:
- nova biblioteca pública de LRC sincronizada e atualizada automaticamente na abertura;
- cache local de letras e reaproveitamento de arquivos inalterados;
- associação segura de LRC por título + artista, com normalização e recusa de correspondências ambíguas;
- prioridade de letra para Stream: biblioteca oficial -> fonte SONUS já existente -> fallback externo;
- letra do Stream detectada automaticamente, mantendo pesquisa manual como correção/opção;
- interface sem exposição de nomes de provedores, códigos, links ou IDs técnicos;
- seleção automática de imagens por cruzamento de título + gênero/contexto + trecho LRC na timeline;
- fallback visual contextual quando não há correspondência forte;
- preservação do mínimo de 5s por imagem e da distribuição existente;
- splash com assinatura institucional reposicionada no rodapé, seguindo a referência do app Sonus;
- versão elevada para 0.0.5 / versionCode 5;
- assinatura persistente obrigatória preservada.

Atenção:
- este pacote passou por validação estática local, mas o ambiente local não possui Android SDK/Gradle completo;
- não considerar BUILD GREEN antes do build real no Codemagic;
- validar o APK em aparelho real, inclusive atualização por cima da code04, letras, timeline e exportação.
