package com.sonusstudios.sonusedit.lyrics

import android.content.Context
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * User-facing Stream lyrics resolver. Technical providers stay behind this class so the UI only
 * exposes friendly states such as "Buscando letra" / "Com letra" / "Sem letra".
 */
class StreamLyricsResolver(
    context: Context,
    private val library: PCloudLyricsRepository = PCloudLyricsRepository(context.applicationContext),
    private val sonus: SonusLyricsResolver = FirebaseSonusLyricsResolver(),
    private val external: LrclibLyricsProvider = LrclibLyricsProvider(),
) {
    private val refreshMutex = Mutex()
    @Volatile private var refreshedThisSession = false

    suspend fun refreshLibrary() {
        if (refreshedThisSession) return
        refreshMutex.withLock {
            if (refreshedThisSession) return
            runCatching { library.refresh() }
            refreshedThisSession = true
        }
    }

    suspend fun resolve(trackId: String?, metadata: LyricsMetadata): String? {
        refreshLibrary()

        library.bestMatch(metadata.trackName, metadata.artistName)?.let { return it }

        trackId?.takeIf { it.isNotBlank() }?.let { id ->
            runCatching { sonus.syncedLyrics(id) }.getOrNull()?.takeIf { PCloudLyricsRepository.isValidLrc(it) }?.let { return it }
        }

        val externalMatch = runCatching {
            if (metadata.artistName.isNotBlank()) {
                external.bestMatch(metadata)
            } else {
                external.search(metadata.trackName, null).firstOrNull { it.hasSyncedLyrics }
            }
        }.getOrNull()
        return externalMatch?.syncedLyrics?.takeIf { PCloudLyricsRepository.isValidLrc(it) }
    }

    suspend fun search(trackName: String, artistName: String?): List<LyricsMatch> =
        runCatching { external.search(trackName, artistName?.takeIf { it.isNotBlank() }) }
            .getOrDefault(emptyList())
            .filter { it.hasSyncedLyrics && PCloudLyricsRepository.isValidLrc(it.syncedLyrics) }
}
