package com.sonusstudios.sonusedit.catalog

import android.content.Context
import com.sonusstudios.sonusedit.create.AudioMetadata
import com.sonusstudios.sonusedit.create.AudioMetadataReader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Small persistent metadata cache so pCloud file codes are never the preferred visible label. */
class StreamMetadataStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("sonus_edit_stream_metadata", Context.MODE_PRIVATE)

    fun cached(asset: PCloudAsset): AudioMetadata? {
        val raw = prefs.getString(asset.stableKey, null) ?: return null
        val parts = raw.split('\u001F')
        if (parts.size < 5) return null
        return AudioMetadata(
            title = parts[0],
            artist = parts[1].ifBlank { null },
            durationMs = parts[2].toLongOrNull() ?: asset.durationMs ?: 0L,
            album = parts[3].ifBlank { null },
            genre = parts[4].ifBlank { null },
        )
    }

    suspend fun resolve(asset: PCloudAsset, repository: PCloudMusicRepository): AudioMetadata = withContext(Dispatchers.IO) {
        cached(asset)?.let { return@withContext it }
        val fallbackTitle = asset.name.substringBeforeLast('.', asset.name)
        val url = repository.downloadUrl(asset)
        val metadata = if (url != null) {
            AudioMetadataReader.readRemote(
                url = url,
                fallbackTitle = fallbackTitle,
                fallbackArtist = null,
                fallbackDurationMs = asset.durationMs ?: 0L,
                fallbackGenre = asset.genre,
            )
        } else {
            AudioMetadata(fallbackTitle, null, asset.durationMs ?: 0L, genre = asset.genre)
        }
        prefs.edit().putString(
            asset.stableKey,
            listOf(metadata.title, metadata.artist.orEmpty(), metadata.durationMs.toString(), metadata.album.orEmpty(), metadata.genre.orEmpty()).joinToString("\u001F")
        ).apply()
        metadata
    }
}
