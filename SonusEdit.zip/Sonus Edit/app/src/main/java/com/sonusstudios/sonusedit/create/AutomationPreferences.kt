package com.sonusstudios.sonusedit.create

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.sonusAutomationDataStore by preferencesDataStore(name = "sonus_edit_automation")

enum class EffectIntensity(val label: String, val opacity: Float) {
    SOFT("Suave", 0.48f),
    BALANCED("Equilibrada", 0.72f),
    MARKED("Marcante", 0.90f),
}

enum class ImageQuantityMode(val label: String) {
    FEW("Poucas"),
    BALANCED("Equilibrado"),
    DYNAMIC("Dinâmico"),
}

data class AutomationSettings(
    val totalAutomation: Boolean = true,
    val smartStart: Boolean = true,
    val prioritizeChorus: Boolean = true,
    val automaticLyrics: Boolean = true,
    val automaticEffects: Boolean = true,
    val effectIntensity: EffectIntensity = EffectIntensity.BALANCED,
    val automaticImages: Boolean = true,
    val automaticFilter: Boolean = true,
    val imageQuantity: ImageQuantityMode = ImageQuantityMode.BALANCED,
    val metadataOnVideo: Boolean = true,
    val defaultResolution: ExportResolution = ExportResolution.P1080,
    val defaultFps: Int = 60,
)

class AutomationPreferences(private val context: Context) {
    private object Keys {
        val Total = booleanPreferencesKey("total_automation")
        val SmartStart = booleanPreferencesKey("smart_start")
        val Chorus = booleanPreferencesKey("prioritize_chorus")
        val Lyrics = booleanPreferencesKey("automatic_lyrics")
        val Effects = booleanPreferencesKey("automatic_effects")
        val EffectIntensity = stringPreferencesKey("effect_intensity")
        val Images = booleanPreferencesKey("automatic_images")
        val Filter = booleanPreferencesKey("automatic_filter")
        val ImageQuantity = stringPreferencesKey("image_quantity")
        val Metadata = booleanPreferencesKey("metadata_on_video")
        val Resolution = stringPreferencesKey("default_resolution")
        val Fps = intPreferencesKey("default_fps")
    }

    val values: Flow<AutomationSettings> = context.sonusAutomationDataStore.data.map { prefs ->
        AutomationSettings(
            totalAutomation = prefs[Keys.Total] ?: true,
            smartStart = prefs[Keys.SmartStart] ?: true,
            prioritizeChorus = prefs[Keys.Chorus] ?: true,
            automaticLyrics = prefs[Keys.Lyrics] ?: true,
            automaticEffects = prefs[Keys.Effects] ?: true,
            effectIntensity = prefs[Keys.EffectIntensity]
                ?.let { runCatching { EffectIntensity.valueOf(it) }.getOrNull() }
                ?: EffectIntensity.BALANCED,
            automaticImages = prefs[Keys.Images] ?: true,
            automaticFilter = prefs[Keys.Filter] ?: true,
            imageQuantity = prefs[Keys.ImageQuantity]
                ?.let { runCatching { ImageQuantityMode.valueOf(it) }.getOrNull() }
                ?: ImageQuantityMode.BALANCED,
            metadataOnVideo = prefs[Keys.Metadata] ?: true,
            defaultResolution = prefs[Keys.Resolution]
                ?.let { runCatching { ExportResolution.valueOf(it) }.getOrNull() }
                ?: ExportResolution.P1080,
            defaultFps = (prefs[Keys.Fps] ?: 60).takeIf { it in setOf(30, 60, 90) } ?: 60,
        )
    }

    suspend fun save(value: AutomationSettings) {
        context.sonusAutomationDataStore.edit { prefs ->
            prefs[Keys.Total] = value.totalAutomation
            prefs[Keys.SmartStart] = value.smartStart
            prefs[Keys.Chorus] = value.prioritizeChorus
            prefs[Keys.Lyrics] = value.automaticLyrics
            prefs[Keys.Effects] = value.automaticEffects
            prefs[Keys.EffectIntensity] = value.effectIntensity.name
            prefs[Keys.Images] = value.automaticImages
            prefs[Keys.Filter] = value.automaticFilter
            prefs[Keys.ImageQuantity] = value.imageQuantity.name
            prefs[Keys.Metadata] = value.metadataOnVideo
            prefs[Keys.Resolution] = value.defaultResolution.name
            prefs[Keys.Fps] = value.defaultFps
        }
    }

    suspend fun restoreDefaults() = save(AutomationSettings())
}
