package com.sonusstudios.sonusedit.create

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns

/** Metadata used by Stream suggestions, Smart Start, LRCLIB and the final lower-third. */
data class AudioMetadata(
    val title: String,
    val artist: String?,
    val durationMs: Long,
    val album: String? = null,
    val genre: String? = null,
)

object AudioMetadataReader {
    fun read(context: Context, uri: Uri): AudioMetadata {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, uri)
            readFromRetriever(retriever, fallbackTitle = displayName(context, uri) ?: "Música selecionada")
        } finally {
            runCatching { retriever.release() }
        }
    }

    /** Reads embedded metadata from a public Stream URL. Falls back cleanly when a server/device
     * does not allow metadata-range reads. */
    fun readRemote(url: String, fallbackTitle: String, fallbackArtist: String? = null, fallbackDurationMs: Long = 0L, fallbackGenre: String? = null): AudioMetadata {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(url, emptyMap())
            val embedded = readFromRetriever(retriever, fallbackTitle)
            embedded.copy(
                artist = embedded.artist ?: fallbackArtist,
                durationMs = embedded.durationMs.takeIf { it > 0 } ?: fallbackDurationMs,
                genre = embedded.genre ?: fallbackGenre,
            )
        } catch (_: Throwable) {
            AudioMetadata(
                title = cleanFallbackTitle(fallbackTitle),
                artist = fallbackArtist,
                durationMs = fallbackDurationMs,
                genre = fallbackGenre,
            )
        } finally {
            runCatching { retriever.release() }
        }
    }

    private fun readFromRetriever(retriever: MediaMetadataRetriever, fallbackTitle: String): AudioMetadata {
        val title = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
            ?.trim()?.takeIf { it.isNotBlank() }
            ?: cleanFallbackTitle(fallbackTitle)
        val artist = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
            ?.trim()?.takeIf { it.isNotBlank() }
        val album = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM)
            ?.trim()?.takeIf { it.isNotBlank() }
        val genre = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_GENRE)
            ?.trim()?.takeIf { it.isNotBlank() }
        val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            ?.toLongOrNull()?.coerceAtLeast(0L) ?: 0L
        return AudioMetadata(title, artist, durationMs, album, genre)
    }

    private fun cleanFallbackTitle(value: String): String = value.substringBeforeLast('.', value)
        .replace('_', ' ')
        .trim()
        .ifBlank { "Música selecionada" }

    private fun displayName(context: Context, uri: Uri): String? =
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { cursor ->
                if (!cursor.moveToFirst()) return@use null
                val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index >= 0) cursor.getString(index) else null
            }
}
