package com.sonusstudios.sonusedit.create

import com.sonusstudios.sonusedit.catalog.PCloudAsset
import com.sonusstudios.sonusedit.editor.LrcParser
import java.text.Normalizer

/**
 * Chooses automatic gallery images by crossing title, genre/context and the synchronized lyric
 * that belongs to each visual slot. The song's central context always weighs more than an isolated
 * lyric word, preventing literal but incoherent image choices.
 */
object ContextualImageSelector {
    fun select(
        assets: List<PCloudAsset>,
        metadata: AudioMetadata,
        syncedLyrics: String?,
        segmentStartMs: Long,
        segmentDurationMs: Long,
        count: Int,
        regenerationNonce: Int = 0,
    ): List<PCloudAsset> {
        if (assets.isEmpty() || count <= 0) return emptyList()
        val targetCount = count.coerceAtMost(assets.size)
        val lines = syncedLyrics?.let(LrcParser::parse).orEmpty()
        val slotDurations = MediaDistributionPlanner.durationsMs(
            durationSeconds = (segmentDurationMs / 1_000L).toInt().coerceAtLeast(1),
            imageCount = targetCount,
        )
        val centralText = listOfNotNull(metadata.title, metadata.genre).joinToString(" ")
        val centralTerms = meaningfulTerms(centralText)
        val centralThemes = themesFor(centralText)
        val chosen = mutableListOf<PCloudAsset>()
        var cursor = segmentStartMs

        repeat(targetCount) { slotIndex ->
            val slotEnd = if (slotIndex == targetCount - 1) segmentStartMs + segmentDurationMs else cursor + slotDurations[slotIndex]
            val lyricText = lines.asSequence()
                .filter { it.timeMs in (cursor - 1_500L).coerceAtLeast(0L)..(slotEnd + 1_500L) }
                .map { it.text }
                .filter(String::isNotBlank)
                .joinToString(" ")
            val localTerms = meaningfulTerms(lyricText)
            val localThemes = themesFor(lyricText)

            val available = assets.filterNot { candidate -> chosen.any { it.stableKey == candidate.stableKey } }
                .ifEmpty { assets }
            val ranked = available.sortedWith(
                compareByDescending<PCloudAsset> { asset -> score(asset, centralTerms, centralThemes, localTerms, localThemes) }
                    .thenBy { it.stableKey }
            )
            val positive = ranked.filter { score(it, centralTerms, centralThemes, localTerms, localThemes) > 0 }
            val pool = if (positive.isNotEmpty()) positive else ranked
            if (pool.isNotEmpty()) {
                val variation = kotlin.math.abs(regenerationNonce + slotIndex) % minOf(pool.size, 4)
                chosen += pool[variation]
            }
            cursor = slotEnd
        }
        return chosen.distinctBy { it.stableKey }.let { unique ->
            if (unique.size >= targetCount) unique.take(targetCount)
            else unique + assets.filterNot { a -> unique.any { it.stableKey == a.stableKey } }.take(targetCount - unique.size)
        }
    }

    fun rankForManualGallery(assets: List<PCloudAsset>, metadata: AudioMetadata?, syncedLyrics: String?): List<PCloudAsset> {
        val meta = metadata ?: return assets
        val centralText = listOfNotNull(meta.title, meta.genre).joinToString(" ")
        val lyricText = syncedLyrics.orEmpty().take(1_200)
        val centralTerms = meaningfulTerms(centralText)
        val centralThemes = themesFor(centralText)
        val localTerms = meaningfulTerms(lyricText)
        val localThemes = themesFor(lyricText)
        return assets.sortedByDescending { score(it, centralTerms, centralThemes, localTerms, localThemes) }
    }

    private fun score(
        asset: PCloudAsset,
        centralTerms: Set<String>,
        centralThemes: Set<String>,
        localTerms: Set<String>,
        localThemes: Set<String>,
    ): Int {
        val haystack = normalize("${asset.name} ${asset.folderPath}")
        val assetTerms = meaningfulTerms(haystack)
        val assetThemes = themesFor(haystack)
        var score = 0

        score += centralTerms.count { haystack.containsWordOrPhrase(it) } * 9
        score += centralThemes.count { it in assetThemes } * 14
        score += localTerms.count { haystack.containsWordOrPhrase(it) } * 5
        score += localThemes.count { it in assetThemes } * 8

        // A strongly classified song should not be hijacked by an isolated word from another theme.
        val strongCentral = centralThemes.firstOrNull()
        if (strongCentral != null && assetThemes.isNotEmpty() && strongCentral !in assetThemes) score -= 7
        if (assetTerms.isEmpty()) score -= 1
        return score
    }

    private fun meaningfulTerms(value: String): Set<String> = normalize(value)
        .split(' ')
        .filter { it.length >= 4 && it !in STOP_WORDS }
        .toSet()

    private fun themesFor(value: String): Set<String> {
        val text = normalize(value)
        return THEME_KEYWORDS.mapNotNull { (theme, words) ->
            theme.takeIf { words.any { word -> text.containsWordOrPhrase(normalize(word)) } }
        }.toSet()
    }

    private fun normalize(value: String): String = Normalizer.normalize(value, Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "")
        .lowercase()
        .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
        .trim()
        .replace(Regex("\\s+"), " ")

    private fun String.containsWordOrPhrase(value: String): Boolean {
        if (value.isBlank()) return false
        return this == value || startsWith("$value ") || endsWith(" $value") || contains(" $value ")
    }

    private val STOP_WORDS = setOf(
        "para", "com", "sem", "uma", "umas", "uns", "isso", "essa", "esse", "aqui", "quando", "onde",
        "voce", "voces", "meu", "minha", "seu", "sua", "nosso", "nossa", "mais", "menos", "muito", "tudo",
        "todo", "toda", "porque", "como", "the", "and", "with", "from", "that", "this", "your", "you", "our"
    )

    private val THEME_KEYWORDS = linkedMapOf(
        "catholic" to setOf("catolico", "catholic", "maria", "nossa senhora", "aparecida", "jesus", "cristo", "eucaristia", "sacrario", "altar", "igreja", "oracao", "fe", "manto", "rosario", "santa", "santo", "teresinha", "worship", "gospel"),
        "romantic" to setOf("romantico", "amor", "beijo", "casal", "coracao", "paixao", "alianca", "casamento", "saudade", "sofrencia", "arrocha", "sertanejo", "flor", "rosa", "petala"),
        "urban" to setOf("trap", "funk", "rap", "drill", "hip hop", "urbano", "rua", "cidade", "neon", "carro", "luxo", "dinheiro", "topo", "vitoria", "luta"),
        "melancholic" to setOf("saudade", "chuva", "noite", "silencio", "sozinho", "solidao", "triste", "madrugada", "deserto", "lua"),
        "nature" to setOf("rosa", "flor", "petala", "jardim", "arvore", "mar", "praia", "ceu", "nuvem", "lua", "estrela", "chuva", "deserto", "natureza"),
        "ambient" to setOf("instrumental", "ambient", "relax", "sleep", "meditacao", "calma", "chuva", "piano", "natureza")
    )
}
