package com.sonusstudios.sonusedit.media

import android.content.Context
import kotlin.random.Random

object EffectIds {
    const val NONE = "none"
    const val BOKEH_SOFT = "bokeh_soft"
    const val FLOATING_BUBBLES = "floating_bubbles"
    const val MAGIC_GLOW = "magic_glow"
    const val TWINKLE_STARS = "twinkle_stars"
    const val DISTANT_LIGHTS = "distant_lights"
    const val LIGHT_DUST = "light_dust"
    const val ETHEREAL_WAVES = "ethereal_waves"
    const val GOLDEN_SPARKS = "golden_sparks"
    const val LIGHT_SNOW = "light_snow"
    const val MINIMAL_PARTICLES = "minimal_particles"
    const val SUBTLE_DUST = "subtle_dust"
    const val LIGHT_FRAGMENTS = "light_fragments"
    const val NEON_STARS = "neon_stars"

    val all = listOf(
        BOKEH_SOFT, FLOATING_BUBBLES, MAGIC_GLOW, TWINKLE_STARS, DISTANT_LIGHTS,
        LIGHT_DUST, ETHEREAL_WAVES, GOLDEN_SPARKS, LIGHT_SNOW, MINIMAL_PARTICLES,
        SUBTLE_DUST, LIGHT_FRAGMENTS, NEON_STARS,
    )
}

/** Invisible contextual selector. The user never needs another manual control. */
class AutomaticEffectSelector(context: Context) {
    private val prefs = context.getSharedPreferences("sonus_edit_effect_history", Context.MODE_PRIVATE)

    fun select(title: String, genre: String?, lyrics: String?, regenerationNonce: Int = 0): String {
        val text = listOf(title, genre.orEmpty(), lyrics.orEmpty().take(900)).joinToString(" ").lowercase()
        val candidates = when {
            text.containsAny("católic", "catholic", "maria", "jesus", "nossa senhora", "eucar", "santo", "santa", "worship", "gospel") ->
                listOf(EffectIds.TWINKLE_STARS, EffectIds.DISTANT_LIGHTS, EffectIds.GOLDEN_SPARKS, EffectIds.MAGIC_GLOW, EffectIds.SUBTLE_DUST)
            text.containsAny("trap", "funk", "rap", "urban", "drill", "hip hop", "eletr") ->
                listOf(EffectIds.NEON_STARS, EffectIds.LIGHT_FRAGMENTS, EffectIds.LIGHT_SNOW, EffectIds.MAGIC_GLOW)
            text.containsAny("românt", "romantic", "love", "amor", "sofr", "arrocha", "sertanejo", "piseiro") ->
                listOf(EffectIds.BOKEH_SOFT, EffectIds.MAGIC_GLOW, EffectIds.LIGHT_DUST, EffectIds.DISTANT_LIGHTS)
            text.containsAny("ambient", "instrumental", "relax", "sleep", "chuva", "medita") ->
                listOf(EffectIds.ETHEREAL_WAVES, EffectIds.SUBTLE_DUST, EffectIds.MINIMAL_PARTICLES, EffectIds.FLOATING_BUBBLES)
            else -> listOf(EffectIds.MINIMAL_PARTICLES, EffectIds.SUBTLE_DUST, EffectIds.DISTANT_LIGHTS, EffectIds.TWINKLE_STARS, EffectIds.LIGHT_FRAGMENTS)
        }

        val recent = prefs.getString("recent", "").orEmpty().split('|').filter { it.isNotBlank() }.take(4)
        val pool = candidates.filterNot { it in recent }.ifEmpty { candidates }
        val seed = System.nanoTime() xor title.hashCode().toLong() xor regenerationNonce.toLong().shl(17)
        val chosen = pool[Random(seed).nextInt(pool.size)]
        val next = (listOf(chosen) + recent.filterNot { it == chosen }).take(4)
        prefs.edit().putString("recent", next.joinToString("|")).apply()
        return chosen
    }
}

private fun String.containsAny(vararg needles: String): Boolean = needles.any { contains(it) }
