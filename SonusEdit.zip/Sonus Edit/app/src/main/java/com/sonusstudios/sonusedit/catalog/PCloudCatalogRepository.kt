package com.sonusstudios.sonusedit.catalog

import android.content.Context
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

open class PCloudCatalogRepository(
    context: Context,
    private val publicCodes: List<String>,
    cacheName: String,
    private val client: PCloudPublicCatalogClient = PCloudPublicCatalogClient(),
    private val json: Json = Json { ignoreUnknownKeys = true },
) {
    constructor(
        context: Context,
        publicCode: String,
        cacheName: String,
        client: PCloudPublicCatalogClient = PCloudPublicCatalogClient(),
        json: Json = Json { ignoreUnknownKeys = true },
    ) : this(context, listOf(publicCode), cacheName, client, json)

    private val cacheFile = File(context.filesDir, "catalog_$cacheName.json")

    suspend fun cached(): List<PCloudAsset> = withContext(Dispatchers.IO) {
        runCatching {
            if (!cacheFile.exists()) return@runCatching emptyList()
            json.decodeFromString<CatalogSnapshot>(cacheFile.readText()).assets
        }.getOrDefault(emptyList())
    }

    suspend fun refresh(): List<PCloudAsset> = coroutineScope {
        val fresh = publicCodes.map { code ->
            async(Dispatchers.IO) { runCatching { client.listAssets(code) }.getOrDefault(emptyList()) }
        }.awaitAll().flatten().distinctBy { it.stableKey }
        if (fresh.isNotEmpty()) {
            withContext(Dispatchers.IO) {
                runCatching { cacheFile.writeText(json.encodeToString(CatalogSnapshot(System.currentTimeMillis(), fresh))) }
            }
            fresh
        } else cached()
    }

    suspend fun downloadUrl(asset: PCloudAsset): String? {
        val code = asset.sourcePublicCode ?: publicCodes.firstOrNull() ?: return null
        return client.resolveDownloadUrl(code, asset.fileId)
    }

    suspend fun thumbnailUrl(asset: PCloudAsset): String? {
        val code = asset.sourcePublicCode ?: publicCodes.firstOrNull() ?: return null
        return client.resolveThumbnailUrl(code, asset.fileId)
    }
}

class PCloudMusicRepository(context: Context) : PCloudCatalogRepository(
    context = context,
    publicCodes = SonusPublicCatalogs.MUSIC_PUBLIC_CODES,
    cacheName = "music",
)

class PCloudImageRepository(context: Context) : PCloudCatalogRepository(
    context = context,
    publicCode = SonusPublicCatalogs.IMAGE_PUBLIC_CODE,
    cacheName = "images",
)
