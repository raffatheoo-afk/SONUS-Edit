package com.sonusstudios.sonusedit.media

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import com.sonusstudios.sonusedit.editor.LrcParser
import java.nio.ByteOrder
import kotlin.math.abs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

/** Fast automatic start selector. Lyrics/refrain are preferred; audio analysis is a bounded fallback. */
object SmartStartResolver {
    private const val PRE_ROLL_MS = 2_500L

    suspend fun resolve(
        context: Context,
        uri: Uri,
        trackDurationMs: Long,
        segmentDurationMs: Long,
        syncedLyrics: String?,
    ): Long = withContext(Dispatchers.Default) {
        val maxStart = (trackDurationMs - segmentDurationMs).coerceAtLeast(0L)
        if (maxStart <= 0L) return@withContext 0L

        lyricsCandidate(syncedLyrics, trackDurationMs)?.let { chorusMs ->
            return@withContext (chorusMs - PRE_ROLL_MS).coerceIn(0L, maxStart)
        }

        // Keep the UI snappy. If decoding cannot produce a result quickly (network/device codec),
        // fall back rather than making the user wait.
        if (uri.scheme == "http" || uri.scheme == "https") {
            return@withContext fallback(trackDurationMs, segmentDurationMs)
        }
        val analyzed = withTimeoutOrNull(1_100L) {
            analyzeEnergy(context, uri, trackDurationMs, segmentDurationMs)
        }
        analyzed?.coerceIn(0L, maxStart) ?: fallback(trackDurationMs, segmentDurationMs)
    }

    private fun lyricsCandidate(raw: String?, durationMs: Long): Long? {
        if (raw.isNullOrBlank()) return null
        val lines = LrcParser.parse(raw).filter { it.text.isNotBlank() }
        if (lines.isEmpty()) return null

        // Explicit section markers when the LRC provider includes them.
        lines.indexOfFirst {
            val t = it.text.lowercase()
            t.contains("chorus") || t.contains("refrão") || t.contains("refrao")
        }.takeIf { it >= 0 }?.let { index ->
            return lines.getOrNull(index + 1)?.timeMs ?: lines[index].timeMs
        }

        // Infer a chorus from the first repeated two-line phrase. This is intentionally cheap and
        // deterministic; it catches the most common LRC structure without a heavy NLP pass.
        fun norm(value: String) = value.lowercase()
            .replace(Regex("[^\\p{L}\\p{N} ]"), "")
            .replace(Regex("\\s+"), " ")
            .trim()
        val pairs = linkedMapOf<String, MutableList<Int>>()
        for (i in 0 until lines.lastIndex) {
            val a = norm(lines[i].text)
            val b = norm(lines[i + 1].text)
            if (a.length < 5 || b.length < 5) continue
            pairs.getOrPut("$a|$b") { mutableListOf() }.add(i)
        }
        val repeated = pairs.values
            .filter { it.size >= 2 }
            .mapNotNull { indexes -> indexes.firstOrNull { lines[it].timeMs >= durationMs * 0.12 } }
            .minOrNull()
        if (repeated != null) return lines[repeated].timeMs

        // Single repeated lyric line is a weaker signal, but still better than a blind peak.
        val counts = lines.groupingBy { norm(it.text) }.eachCount()
        return lines.firstOrNull {
            val key = norm(it.text)
            key.length >= 8 && (counts[key] ?: 0) >= 2 && it.timeMs >= durationMs * 0.15
        }?.timeMs
    }

    private fun fallback(durationMs: Long, segmentMs: Long): Long {
        val maxStart = (durationMs - segmentMs).coerceAtLeast(0L)
        // A quarter into the song generally skips intros while remaining fast and predictable.
        return (durationMs * 0.24).toLong().coerceIn(0L, maxStart)
    }

    private fun analyzeEnergy(context: Context, uri: Uri, durationMs: Long, segmentMs: Long): Long? {
        val maxStart = (durationMs - segmentMs).coerceAtLeast(0L)
        if (maxStart <= 0L) return 0L
        val fractions = doubleArrayOf(0.12, 0.24, 0.38, 0.52, 0.66, 0.78)
        val deadlineNs = System.nanoTime() + 900_000_000L
        var bestStart = -1L
        var bestEnergy = -1.0
        for (fraction in fractions) {
            if (System.nanoTime() >= deadlineNs) break
            val candidate = (maxStart * fraction).toLong().coerceIn(0L, maxStart)
            val energy = runCatching { samplePcmEnergy(context, uri, candidate) }.getOrNull() ?: continue
            if (energy > bestEnergy) {
                bestEnergy = energy
                bestStart = candidate
            }
        }
        return bestStart.takeIf { it >= 0L }
    }

    private fun samplePcmEnergy(context: Context, uri: Uri, startMs: Long): Double {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            if (uri.scheme == "http" || uri.scheme == "https") {
                extractor.setDataSource(uri.toString(), emptyMap())
            } else {
                extractor.setDataSource(context, uri, null)
            }
            var trackIndex = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val candidate = extractor.getTrackFormat(i)
                val mime = candidate.getString(MediaFormat.KEY_MIME).orEmpty()
                if (mime.startsWith("audio/")) {
                    trackIndex = i
                    format = candidate
                    break
                }
            }
            if (trackIndex < 0 || format == null) return 0.0
            extractor.selectTrack(trackIndex)
            extractor.seekTo(startMs * 1_000L, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: return 0.0
            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(format, null, null, 0)
            codec.start()

            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var sum = 0.0
            var sampleCount = 0L
            val endUs = startMs * 1_000L + 900_000L
            while (!outputDone && sampleCount < 160_000L) {
                if (!inputDone) {
                    val inIndex = codec.dequeueInputBuffer(4_000)
                    if (inIndex >= 0) {
                        val input = codec.getInputBuffer(inIndex) ?: continue
                        val size = extractor.readSampleData(input, 0)
                        if (size < 0) {
                            codec.queueInputBuffer(inIndex, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(inIndex, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                val outIndex = codec.dequeueOutputBuffer(info, 4_000)
                if (outIndex >= 0) {
                    if (info.size > 1) {
                        val output = codec.getOutputBuffer(outIndex)
                        if (output != null) {
                            output.position(info.offset)
                            output.limit(info.offset + info.size)
                            val shorts = output.slice().order(ByteOrder.nativeOrder()).asShortBuffer()
                            while (shorts.hasRemaining()) {
                                val value = shorts.get().toInt()
                                sum += abs(value).toDouble()
                                sampleCount++
                            }
                        }
                    }
                    outputDone = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0 || info.presentationTimeUs >= endUs
                    codec.releaseOutputBuffer(outIndex, false)
                }
            }
            return if (sampleCount > 0) sum / sampleCount else 0.0
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            runCatching { extractor.release() }
        }
    }
}
