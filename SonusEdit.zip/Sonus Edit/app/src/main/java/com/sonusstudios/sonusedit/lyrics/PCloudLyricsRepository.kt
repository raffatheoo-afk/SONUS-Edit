package com.sonusstudios.sonusedit.lyrics

import android.content.Context
import com.sonusstudios.sonusedit.catalog.PCloudAsset
import com.sonusstudios.sonusedit.catalog.PCloudPublicCatalogClient
import java.io.File
import java.net.HttpURLConnection
import java.net.URI
import java.text.Normalizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * Local mirror/index of the public synchronized-lyrics folder used by Sonus Edit.
 * Only valid timestamped LRC files are stored as synchronized lyrics.
 */
class PCloudLyricsRepository(
    context: Context,
    private val client: PCloudPublicCatalogClient = PCloudPublicCatalogClient(),
    private val json: Json = Json { ignoreUnknownKeys = true },
) {
    private val cacheFile = File(context.filesDir, "sonus_edit_lyrics_library.json")

    suspend fun cached(): List<PCloudLyricsEntry> = withContext(Dispatchers.IO) {
        readSnapshot().entries
    }

    suspend fun refresh(): List<PCloudLyricsEntry> = withContext(Dispatchers.IO) {
        val previous = readSnapshot()
        val previousById = previous.entries.associateBy { it.fileId }
        val assets = runCatching { client.listAssets(PUBLIC_CODE) }
            .getOrDefault(emptyList())
            .filter { it.extension == "lrc" }

        // listAssets returns an empty list on network failure as well as for an empty folder.
        // Keep the last known-good local library in that case so offline use never regresses.
        if (assets.isEmpty()) return@withContext previous.entries

        val refreshed = assets.mapNotNull { asset ->
            val old = previousById[asset.fileId]
            if (old != null && old.modified == asset.modified && old.size == asset.size && isValidLrc(old.syncedLyrics)) {
                old
            } else {
                downloadEntry(asset) ?: old
            }
        }.distinctBy { entry ->
            listOf(normalize(entry.title.orEmpty()), normalize(entry.artist.orEmpty()), normalize(entry.fileName)).joinToString("|")
        }

        if (refreshed.isNotEmpty()) {
            runCatching {
                cacheFile.writeText(
                    json.encodeToString(PCloudLyricsSnapshot(System.currentTimeMillis(), refreshed))
                )
            }
            refreshed
        } else {
            previous.entries
        }
    }

    suspend fun bestMatch(trackTitle: String, trackArtist: String?): String? {
        val entries = cached()
        if (entries.isEmpty()) return null
        val title = normalize(trackTitle)
        val artist = normalize(trackArtist.orEmpty())
        if (title.isBlank()) return null

        val ranked = entries.mapNotNull { entry ->
            val score = matchScore(entry, title, artist)
            if (score > 0) entry to score else null
        }.sortedByDescending { it.second }

        val best = ranked.firstOrNull() ?: return null
        if (ranked.size > 1 && ranked[1].second == best.second && best.second < 1000) {
            // Ambiguous same-strength matches must not be guessed.
            return null
        }
        return best.first.syncedLyrics.takeIf { isValidLrc(it) }
    }

    private fun matchScore(entry: PCloudLyricsEntry, title: String, artist: String): Int {
        val tagTitle = normalize(entry.title.orEmpty())
        val tagArtist = normalize(entry.artist.orEmpty())
        val stem = normalize(entry.fileName.substringBeforeLast('.'))
        val splitCandidates = splitName(entry.fileName.substringBeforeLast('.'))
        val normalizedParts = splitCandidates.map(::normalize).filter { it.isNotBlank() }

        if (tagTitle == title && artist.isNotBlank() && tagArtist == artist) return 1200
        if (normalizedParts.size >= 2 && artist.isNotBlank() && title in normalizedParts && artist in normalizedParts) return 1100
        if (artist.isNotBlank() && stem.containsPhrase(title) && stem.containsPhrase(artist)) return 1050
        if (tagTitle == title && tagArtist.isBlank()) return 900
        if (stem == title) return 850
        if (normalizedParts.any { it == title } && artist.isBlank()) return 820
        return 0
    }

    private suspend fun downloadEntry(asset: PCloudAsset): PCloudLyricsEntry? {
        val url = client.resolveDownloadUrl(PUBLIC_CODE, asset.fileId) ?: return null
        val raw = downloadText(url)?.trim().orEmpty()
        if (!isValidLrc(raw)) return null
        val title = TAG_TITLE.find(raw)?.groupValues?.getOrNull(1)?.trim()?.takeIf { it.isNotBlank() }
        val artist = TAG_ARTIST.find(raw)?.groupValues?.getOrNull(1)?.trim()?.takeIf { it.isNotBlank() }
        return PCloudLyricsEntry(
            fileId = asset.fileId,
            fileName = asset.name,
            modified = asset.modified,
            size = asset.size,
            title = title,
            artist = artist,
            syncedLyrics = raw,
        )
    }

    private fun downloadText(url: String): String? {
        val connection = (URI.create(url).toURL().openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 8_000
            readTimeout = 12_000
            setRequestProperty("Accept", "text/plain,*/*")
            setRequestProperty("User-Agent", "Sonus-Edit/0.0.5 Android")
        }
        return try {
            if (connection.responseCode == HttpURLConnection.HTTP_OK) {
                connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            } else null
        } catch (_: Throwable) {
            null
        } finally {
            connection.disconnect()
        }
    }

    private fun readSnapshot(): PCloudLyricsSnapshot = runCatching {
        if (!cacheFile.exists()) return@runCatching PCloudLyricsSnapshot()
        json.decodeFromString<PCloudLyricsSnapshot>(cacheFile.readText())
    }.getOrDefault(PCloudLyricsSnapshot())

    private fun splitName(value: String): List<String> = value
        .split(Regex("\\s+(?:-|–|—|\\|)\\s+"))
        .map(String::trim)
        .filter(String::isNotBlank)

    private fun String.containsPhrase(value: String): Boolean {
        if (value.isBlank()) return false
        return this == value || startsWith("$value ") || endsWith(" $value") || contains(" $value ")
    }

    companion object {
        const val PUBLIC_CODE = "kZNiXQJZTobHXlzVPjzsj9LyASRI77DUtfJk"
        private val LRC_TIMESTAMP = Regex("\\[\\d{1,3}:\\d{2}(?:[.:]\\d{1,3})?]")
        private val TAG_TITLE = Regex("(?im)^\\[ti\\s*:\\s*([^]]+)]\\s*$")
        private val TAG_ARTIST = Regex("(?im)^\\[ar\\s*:\\s*([^]]+)]\\s*$")

        fun isValidLrc(value: String?): Boolean = !value.isNullOrBlank() && LRC_TIMESTAMP.containsMatchIn(value)

        fun normalize(value: String): String {
            val noMarks = Normalizer.normalize(value, Normalizer.Form.NFD)
                .replace(Regex("\\p{M}+"), "")
            return noMarks.lowercase()
                .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
                .trim()
                .replace(Regex("\\s+"), " ")
        }
    }
}

@Serializable
data class PCloudLyricsEntry(
    val fileId: Long,
    val fileName: String,
    val modified: String? = null,
    val size: Long = 0L,
    val title: String? = null,
    val artist: String? = null,
    val syncedLyrics: String,
)

@Serializable
private data class PCloudLyricsSnapshot(
    val updatedAtMs: Long = 0L,
    val entries: List<PCloudLyricsEntry> = emptyList(),
)
