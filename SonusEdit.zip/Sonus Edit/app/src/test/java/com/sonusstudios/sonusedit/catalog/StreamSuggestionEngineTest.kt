package com.sonusstudios.sonusedit.catalog

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test

class StreamSuggestionEngineTest {
    @Test
    fun `prefers dominant recent genre without repeating last track`() {
        val international1 = PCloudAsset(1, "One.mp3", folderPath = "SONUS MUSIC/Internacional", sourcePublicCode = "A")
        val international2 = PCloudAsset(2, "Two.mp3", folderPath = "SONUS MUSIC/Internacional", sourcePublicCode = "A")
        val catholic = PCloudAsset(3, "Three.mp3", folderPath = "SONUS MUSIC/Católica", sourcePublicCode = "B")
        val history = listOf(
            StreamHistoryStore.Entry(international1.stableKey, "Internacional"),
            StreamHistoryStore.Entry("A:90", "Internacional"),
            StreamHistoryStore.Entry("A:91", "Internacional"),
            StreamHistoryStore.Entry("B:92", "Católica"),
        )
        val suggestion = StreamSuggestionEngine.suggest(listOf(international1, international2, catholic), history)
        assertEquals("Internacional", suggestion?.genre)
        assertNotEquals(international1.stableKey, suggestion?.stableKey)
    }
}
