package com.sonusstudios.sonusedit.create

import com.sonusstudios.sonusedit.catalog.PCloudAsset
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ContextualImageSelectorTest {
    @Test
    fun `catholic context prevents isolated romantic rose from winning`() {
        val metadata = AudioMetadata(
            title = "Rosa no Deserto",
            artist = "SONUS Studios",
            durationMs = 60_000L,
            genre = "Católico",
        )
        val lyrics = """
            [00:00.00] Rosa no deserto
            [00:06.00] Mãe cobre-me com teu manto
            [00:12.00] Leva-me a Jesus
        """.trimIndent()
        val catholic = PCloudAsset(1, "maria_rosas_altar.jpg", folderPath = "Católico/Maria", sourcePublicCode = "I")
        val genericRomance = PCloudAsset(2, "rosas_para_casal.jpg", folderPath = "Romântico", sourcePublicCode = "I")
        val urban = PCloudAsset(3, "cidade_neon.jpg", folderPath = "Trap", sourcePublicCode = "I")

        val selected = ContextualImageSelector.select(
            assets = listOf(genericRomance, urban, catholic),
            metadata = metadata,
            syncedLyrics = lyrics,
            segmentStartMs = 0L,
            segmentDurationMs = 15_000L,
            count = 1,
        )

        assertEquals(catholic.stableKey, selected.single().stableKey)
    }

    @Test
    fun `uses lyric timing to vary images across slots while preserving context`() {
        val metadata = AudioMetadata(
            title = "Saudade de Madrugada",
            artist = "Artista",
            durationMs = 30_000L,
            genre = "Sofrência",
        )
        val lyrics = """
            [00:00.00] A chuva bate na janela
            [00:10.00] Seu retrato ficou na mesa
            [00:20.00] A madrugada não termina
        """.trimIndent()
        val rain = PCloudAsset(10, "chuva_na_janela.jpg", folderPath = "Melancólico", sourcePublicCode = "I")
        val portrait = PCloudAsset(11, "retrato_saudade.jpg", folderPath = "Romântico", sourcePublicCode = "I")
        val night = PCloudAsset(12, "noite_madrugada.jpg", folderPath = "Melancólico", sourcePublicCode = "I")

        val selected = ContextualImageSelector.select(
            assets = listOf(rain, portrait, night),
            metadata = metadata,
            syncedLyrics = lyrics,
            segmentStartMs = 0L,
            segmentDurationMs = 30_000L,
            count = 3,
        )

        assertEquals(3, selected.size)
        assertTrue(selected.map { it.stableKey }.toSet().size == 3)
    }
}
