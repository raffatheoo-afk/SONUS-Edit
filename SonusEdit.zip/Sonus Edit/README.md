# Sonus Edit — 0.0.5 / code05

App Android `com.sonusstudios.sonusedit` para criação automática de vídeos musicais verticais 9:16.

## Estado desta base
- Base anterior: 0.0.4/code04 — Build Fix 1.
- Versionamento atual: `versionName 0.0.5` / `versionCode 5`.
- Assinatura persistente deve ser exatamente a mesma já confirmada na code04.
- O workflow deve falhar se a chave persistente não estiver disponível; nunca gerar nova chave automaticamente.

## Destaques da code05
- letras sincronizadas do Stream resolvidas automaticamente;
- biblioteca LRC atualizável sem nova versão do app;
- pesquisa manual de letra preservada;
- seleção de imagens guiada por título, gênero/contexto e palavras/temas do trecho LRC;
- splash com assinatura institucional no rodapé;
- preservação do Smart Start, Automação Total, 15s manual-only, efeitos, filtros, 9:16 e qualidade/FPS reais.

Leia `CODE05_IMPLEMENTATION.md` para o resumo da rodada. BUILD GREEN somente após compilação real no Codemagic.
