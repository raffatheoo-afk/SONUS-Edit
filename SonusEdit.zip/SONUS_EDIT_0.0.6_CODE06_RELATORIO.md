# Sonus Edit 0.0.6 — CODE 06

## Escopo e origem

Atualização preparada a partir do pacote de continuidade `PACOTE_CONTINUIDADE_SONUS_EDIT_0.0.5.zip`, incluindo o projeto Android, os recursos gráficos e audiovisuais, o arquivo Codemagic e as instruções de continuidade. O identificador do aplicativo foi preservado: `com.sonusstudios.sonusedit`.

**Versão:** 0.0.6  
**versionCode:** 6  
**Workflow Codemagic:** `sonus-edit-0-0-3-code03-debug` (mantido)

## Alterações implementadas

### 1. Legendas automáticas e identificação de áudio
- A tela de legendas automáticas agora inspeciona as faixas do contêiner com `MediaExtractor` e verifica o MIME de faixas `audio/`, usando o leitor de metadados anterior como fallback.
- Não foi introduzido limite artificial de 30 segundos. O extrator WAV continua aceitando segmentos curtos (limiar técnico de 0,1 s).
- Whisper Small multilíngue e `ENGINE_VERSION 16` foram preservados. Não houve troca, redução, quantização ou substituição do modelo.

### 2. Estilos de legenda e temporização
- A seleção passa a oferecer 20 estilos: os dez existentes e dez estilos novos.
- Os dez estilos novos recebem indicação Premium apenas visual; não estão bloqueados.
- Prévia e exportação usam o mesmo renderizador de estilo.
- A divisão palavra por palavra agora respeita a janela temporal da frase. Quando a janela disponível é curta demais para atribuir tempo representável a cada palavra, a frase é mantida como uma unidade em vez de gerar tempos inválidos ou empurrar palavras para fora do trecho.

### 3. Cores e fontes
- Paleta ampliada para 25 opções: Dinâmico e 24 cores nomeadas, com novas opções como vermelho, laranja, cinzas e outras tonalidades.
- A paleta é horizontalmente deslizável. Dinâmico tem selo Premium ilustrativo, mas continua disponível.
- A seleção de fontes oferece 30 opções baseadas em famílias e pesos do sistema Android, priorizando legibilidade e aparência natural. Não foram adicionados arquivos externos de fontes.
- As fontes permanecem desbloqueadas; a seleção dinâmica foi normalizada para uma família sem serifa natural.

### 4. Filtros e seleção automática
- A primeira fileira apresenta 15 filtros gratuitos, incluindo os seis filtros nomeados pelo usuário e nove efeitos já existentes no projeto.
- A segunda fileira apresenta dez filtros Premium ilustrativos, também disponíveis sem bloqueio.
- O controle específico de seleção automática começa desativado em instalações sem preferência salva, preservando o padrão neutro do CODE 05 e o teste de regressão existente. Uma escolha explícita já gravada é respeitada. Quando a Automação Total está ligada, o fluxo global continua podendo selecionar filtros automaticamente; Preto e Branco permanece excluído. Os filtros mantêm identificadores estáveis para preservar compatibilidade com projetos já salvos.

### 5. Galeria e buscas
- O histórico anti-repetição de 15 vídeos foi mantido.
- A busca publica primeiro o catálogo em cache e depois consulta as fontes disponíveis de forma concorrente e progressiva, com rotação de início entre as fontes configuradas.
- O estado de disponibilidade por fonte e tipo de mídia é persistido: fontes conhecidas como vazias podem ser ignoradas; fontes desconhecidas ainda são consultadas.
- Foi adicionado indicador verde mais visível com círculo giratório e “BUSCANDO”, com tempo mínimo de exibição para evitar que desapareça imediatamente.
- A identificação “VÍDEO” permanece exclusiva para vídeos/MP4. As imagens não recebem selo de identificação adicional.
- Observação sobre as fontes originais: há três fontes configuradas para imagens verticais e duas para imagens horizontais. A atualização respeita essa configuração existente; não inventa uma terceira fonte horizontal.
- A melhora de latência foi implementada estruturalmente, mas o tempo de resposta real depende da rede e do serviço pCloud e não pôde ser medido neste ambiente.

### 6. Seleção e prévia de MP3 local
- O ExoPlayer agora recebe a mídia e inicia `prepare()` antes da leitura dos metadados incorporados ao arquivo.
- A leitura dos metadados ocorre em segundo plano. A duração fornecida pelo player pode criar uma identificação provisória enquanto os metadados completos não chegam.
- Os controles de prévia de início e fim aguardam apenas o estado pronto do player, exibindo “Preparando áudio…” enquanto necessário.
- A mudança atende ao atraso relatado ao selecionar um MP3 local de aproximadamente seis minutos e 11 MB, sem assumir que o tamanho do arquivo era a única causa.

### 7. Tela de revisão e FPS
- A revisão mantém nome da música e artista no topo e compacta o controle de legendas.
- A barra de progresso foi afinada e o mini player passou a calcular seu espaço com base na área disponível.
- Permanecem os ajustes de tamanho e posição da legenda e as opções 720p, 1080p, 2K e 4K.
- O controle de FPS foi removido da revisão. O padrão de novos projetos é 30 FPS; a alteração permanece em Ajustes.
- A revisão não usa rolagem vertical própria. O layout responsivo ainda deve ser confirmado em aparelhos físicos com diferentes tamanhos de tela.

### 8. Sobre, planos e identificação da versão
- Número de versão atualizado para 0.0.6 / CODE 06 nos arquivos de versão e nas telas correspondentes.
- A tela Sobre foi atualizada com as novidades desta versão.
- A tela de planos foi atualizada como apresentação ilustrativa, com valores planejados: R$ 1,90 mensal, R$ 3,90 trimestral, R$ 7,90 semestral e R$ 11,90 anual.
- Não foi ativada cobrança, cota, limite mensal, bloqueio de estilos, filtros, cores ou fontes. As indicações Premium são ilustrativas.

## Recursos e contratos preservados

- Logo central, ícone de primeiro plano, ícones de launcher em múltiplas densidades, vídeos de partículas e shaders originais foram mantidos; não houve redesenho nem substituição desses recursos.
- `applicationId` mantido como `com.sonusstudios.sonusedit`.
- Workflow Codemagic ID mantido como `sonus-edit-0-0-3-code03-debug`.
- O bloco de assinatura persistente do YAML permaneceu byte a byte idêntico ao original do pacote.
- Media3 1.10.1 mantido.
- Integrações Link, yt-dlp e FFmpeg mantidas.
- Exportador, fallback/retry de exportações longas, apresentação final de vídeo com uma faixa, shaders e mecanismos existentes de Gallery/cache foram preservados fora das mudanças descritas.

## Verificações executadas

1. `python3 scripts/validate_v0_0_6_code06.py` — **passou após a correção do padrão neutro de filtros**.
2. O contrato do padrão foi conferido contra `Code03CaptionLanguageHintTest`: `CaptionStyleId.CLASSIC` e `automaticFilter == false`.
3. Compilação e execução de smoke test isolado dos modelos Kotlin — **passou**. Conferiu 20 estilos / 10 Premium, 30 opções de fonte distintas, 25 cores, 27 identificadores de filtro / 10 Premium, 24 filtros elegíveis para seleção automática, limites de temporização e rotação de fontes.
4. Parse do `codemagic.yaml` e conferência do workflow — **passou**.
5. Comparação do bloco de assinatura com o YAML original do ZIP — **idêntico**.
6. Inspeção dos principais recursos visuais — logo, ícone, partículas, shaders e variantes de launcher presentes.

## Validação que ainda falta

**A compilação Android completa e a suíte JUnit não foram reexecutadas neste ambiente.** Não há Gradle instalado, Gradle Wrapper no pacote nem Android SDK/`android.jar` disponível. O log Codemagic enviado pelo usuário comprova que a compilação Kotlin/Javac ocorreu e que 72 dos 73 testes passaram antes deste ajuste; a execução integral após a correção ainda precisa ser confirmada no Codemagic. Portanto, este pacote não contém APK produzido ou teste de instalação em dispositivo. A validação de compilação, testes Android/JUnit e geração do APK devem ocorrer no workflow Codemagic atualizado.

Também não foi possível medir o tempo real das consultas pCloud nem testar os fluxos em Galaxy S10e, Galaxy A15 ou outros dispositivos físicos. A validação estática e os testes isolados dos modelos não substituem essas verificações.

## Resultado

Pacote de código-fonte **Sonus Edit 0.0.6 / CODE 06** preparado para envio ao repositório privado e validação no Codemagic. Nenhuma credencial foi reproduzida neste relatório. Nenhum arquivo `.jks` foi incluído no pacote.
