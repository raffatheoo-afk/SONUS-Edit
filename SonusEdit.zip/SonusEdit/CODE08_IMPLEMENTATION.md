# Sonus Edit 0.0.8 / code08

Base: 0.0.7 / code07 funcional.

## Alterações desta rodada
- Legendas renderizadas no centro horizontal real do frame 9:16, com safe-area lateral de 8% por lado.
- Quebra automática de legendas em até duas linhas e redução proporcional de fonte apenas quando necessário.
- Marcações editoriais entre `[...]` e `(...)` são removidas somente na exibição/renderização; o LRC original permanece intacto na origem.
- Nome do artista aproximado discretamente do título no overlay final.
- Favoritos persistentes para fontes e filtros, com estrela dourada quando marcada.
- Automação Total usa somente favoritos quando houver favoritos naquela categoria; sem favoritos, preserva o comportamento normal.
- "Gerar outra combinação" varia também entre fontes/filtros favoritos quando houver alternativas.
- Revisão compactada em duas colunas, qualidade + FPS visíveis em área menor e remoção do aviso técnico inferior.
- Exportação movida para Foreground Service, com progresso na notificação e botão `EXECUÇÃO 2° PLANO`.
- Minimizar/sair da tela de exportação não cancela mais a renderização automaticamente.
- Otimizações sem redução de qualidade: limpeza/layout de legenda pré-processados, busca binária de timestamps e cache de métricas de metadata.

## Preservado
- Assinatura pessoal do vídeo permanece na mesma altura/posição aprovada.
- Seleção de imagens continua leve por título + gênero.
- LRC do Stream continua baixando apenas após seleção da música.
- Smart Start, filtros, efeitos, timeline, 15s manual, 9:16, resolução/FPS reais e assinatura persistente permanecem.

## Revisão de interface — etapa Estilo (referência de 15/11/2026)
- A tela de Estilo foi retirada do `LazyColumn` vertical e agora ocupa somente a altura disponível entre o cabeçalho do fluxo e a barra inferior `Anterior/Avançar`; as listas internas permanecem horizontais.
- As fontes aprovadas continuam intactas: são mostradas oito por sessão em duas fileiras de quatro. A seleção inicial é mantida na grade e as demais opções aprovadas alternam entre sessões.
- A coluna direita recupera a prévia preta da legenda e o botão `Fonte dinâmica`, com o estado selecionado destacado. A prévia usa o mesmo `CaptionOverlayCanvas` do projeto e reflete fonte, cor e estilo escolhidos.
- Os botões de cor passam a ter a amostra e o rótulo centralizados; o tamanho dos cartões não foi aumentado para resolver o alinhamento.
- A fonte de demonstração dentro dos cartões de estilo foi ampliada sem alterar o tamanho dos cartões.
- Os cartões de filtros foram ampliados proporcionalmente, mantendo 15 opções gratuitas e 10 Premium ilustrativas em faixas horizontais.
- Versão Android: `0.0.8`, `versionCode=8`. O ID fixo do workflow Codemagic permaneceu `sonus-edit-0-0-3-code03-debug`.

### Validação desta revisão
- Validador estático CODE 08: aprovado.
- YAML Codemagic: parseado com sucesso e ID do workflow confirmado.
- Testes JUnit, compilação Kotlin Android e APK: pendentes de execução no Codemagic; este ambiente não dispõe de Gradle/Android SDK configurado.
