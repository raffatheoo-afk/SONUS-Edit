# Sonus Edit 0.0.8 / code08

Base: 0.0.7 / code07 funcional.

## Alterações desta rodada
- Legendas renderizadas no centro horizontal real do frame 9:16, com safe-area lateral de 8% por lado.
- Quebra automática de legendas em até duas linhas e redução proporcional de fonte apenas quando necessário.
- Marcações editoriais entre `[...]` e `(...)` são removidas somente na exibição/renderização; o LRC original permanece intacto na origem.
- Nome do artista aproximado discretamente do título no overlay final.
- Favoritos persistentes para fontes e filtros, com estrela dourada quando marcada.
- Automação Total usa somente favoritos quando houver favoritos naquela categoria; sem favoritos, preserva o comportamento normal.
- "Gerar outra combinação" varia também entre fontes/filtros favoritos quando houver alternativas.
- Revisão compactada em duas colunas, qualidade + FPS visíveis em área menor e remoção do aviso técnico inferior.
- Exportação movida para Foreground Service, com progresso na notificação e botão `EXECUÇÃO 2° PLANO`.
- Minimizar/sair da tela de exportação não cancela mais a renderização automaticamente.
- Otimizações sem redução de qualidade: limpeza/layout de legenda pré-processados, busca binária de timestamps e cache de métricas de metadata.

## Preservado
- Assinatura pessoal do vídeo permanece na mesma altura/posição aprovada.
- Seleção de imagens continua leve por título + gênero.
- LRC do Stream continua baixando apenas após seleção da música.
- Smart Start, filtros, efeitos, timeline, 15s manual, 9:16, resolução/FPS reais e assinatura persistente permanecem.
