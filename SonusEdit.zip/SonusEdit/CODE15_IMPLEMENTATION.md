# SONUS EDIT — 0.0.15 / code15 — HOTFIX DE EXPORTAÇÃO

Base: 0.0.14/code14 corrigida de compilação.

Objetivo exclusivo desta versão: atacar o erro de runtime `Asset loader error` surgido após a migração dos efeitos de atlas para MP4 real.

Mudanças:
- versionCode 15 / versionName 0.0.15;
- Media3 alinhado em 1.10.1 (common/exoplayer/ui/effect/transformer);
- MP4s de partículas e PNG transparente de timing são copiados byte a byte para `cacheDir/sonus_edit_export_assets` antes de entrar no Transformer;
- Transformer passa a receber `file://` via `Uri.fromFile` para esses assets internos;
- não alterar os próprios frames, bitrate, resolução, FPS ou loop dos efeitos;
- erro de exportação agora registra stack trace com tag `SonusEditExport` e mostra cadeia de causas na UI.

IMPORTANTE:
- code15 ainda precisa de confirmação em aparelho real após instalação;
- se o erro persistir, NÃO voltar para atlas automaticamente;
- coletar a mensagem completa mostrada pela code15 e/ou Logcat `SonusEditExport` e corrigir somente a causa identificada.
