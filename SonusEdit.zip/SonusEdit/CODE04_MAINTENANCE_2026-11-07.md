SONUS EDIT 0.0.4 / CODE04 — MANUTENÇÃO DE ESTABILIDADE
Data: 2026-11-07

ESCOPO EXECUTADO
1. Galeria e responsividade
- Ranking, filtragem e contagem do catálogo movidos para Dispatchers.Default.
- Leituras repetidas do histórico de imagens removidas do caminho de recomposição.
- Pré-carregamento limitado à primeira linha (até 3 miniaturas).
- Decodificação/download de miniaturas remotas e resolução de mídias selecionadas limitados a 2 trabalhos simultâneos cada.
- Contagem de seleções pendentes incluída no limite para evitar disparar muitas resoluções ao tocar rapidamente em várias mídias.
- Miniaturas de galeria reduzidas para 240x360; os arquivos originais e as fontes usadas na exportação não foram reduzidos.
- Cache de miniaturas versionado para regenerar apenas as prévias compactas.
- Salvamento automático do rascunho agrupado por 180 ms; cálculo das chaves de histórico fora da UI.

2. Reprodução
- Verificação do limite final mantida a cada 40 ms.
- Atualização visual do playhead limitada a 10 vezes por segundo para evitar recomposições excessivas; a checagem do limite continua a cada 40 ms.
- Animação demonstrativa da legenda na prévia também reduzida para 10 atualizações por segundo.

3. Revisão
- Nome da música e artista na mesma linha.
- Botões de qualidade e FPS ampliados para 38 dp.
- Prévia dimensionada para reservar espaço aos controles.
- Ao abrir a correção de legenda, a reprodução pausa; ao salvar, cancelar ou fechar, retoma do ponto pausado somente se estava tocando antes.

IDENTIDADE PRESERVADA
- versionName 0.0.4
- versionCode 4
- package com.sonusstudios.sonusedit
- Workflow e chave permanente preservados.
- Sem dependências novas.

VALIDAÇÃO
- Validador estático code04 estendido e executado com sucesso.
- YAML validado sintaticamente.
- Integridade do ZIP e versionamento conferidos.
- Compilação Android/JUnit completa ainda depende do Codemagic; não foi declarada como executada localmente.
