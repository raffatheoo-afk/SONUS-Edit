# SONUS EDIT 1.0.7 / CODE 17 — Relatório de manutenção

**Base:** `SonusEdit_1.0.6_CODE16.zip` e `codemagic.yaml` correspondente  
**Data:** 28/11/2026  
**Status:** alterações de código aplicadas; validação Android/Codemagic e testes em aparelho pendentes.

## 1. Identidade e preservação

- `versionName`: **1.0.7**.
- `versionCode`: **17**.
- `applicationId` e namespace preservados: `com.sonusstudios.sonusedit`.
- `minSdk` preservado em 26.
- Workflow atualizado para `sonus-edit-1-0-7-code17`; seleção de pacotes antigos CODE14/CODE16 foi bloqueada.
- Importador original `LinkAudioImporter.kt` e dependências yt-dlp + FFmpeg 0.18.1 preservados.
- Whisper Small, whisper-android e Media3 1.10.1 preservados.
- Nenhum keystore foi gerado, trocado ou incorporado ao ZIP/YAML.

## 2. Fontes das legendas

- `Montepetrum Thin` removida do catálogo selecionável e seu arquivo retirado dos assets ativos.
- A identidade serializada antiga permanece reconhecida; rascunhos que a utilizavam são direcionados para `Patrick Hand`, evitando referência quebrada.
- Catálogo inclui `Caveat`, `Dancing Script`, `Patrick Hand`, `Kalam` e `Kaushan Script`.
- O Gradle obtém os TTFs e as licenças SIL OFL do repositório Google Fonts durante `preBuild`, se ainda não existirem, e só prossegue após validar a estrutura SFNT e o mapa de caracteres português/Latin Extended.
- **Pendente:** os binários ainda não foram baixados para dentro deste ambiente (a rede de saída do contêiner não resolveu o host do repositório). O fluxo do Codemagic fará a obtenção no build. A renderização visual e os glifos precisam ser confirmados no APK/aparelho.

## 3. Preparação do áudio para Whisper

- `AudioSegmentWavExtractor` ganhou diagnóstico de faixa/MIME, janela solicitada, PTS, buffers, frames aceitos, amostras, bytes e duração PCM.
- Quando a extração por seek produz PCM insuficiente, há uma única nova tentativa desde o início da faixa, mantendo o filtro de tempo; não há repetição infinita.
- A janela normal exige cobertura PCM de 95% (75% para janelas inferiores a dois segundos).
- O caminho sequencial de chunks também rejeita um bloco final abaixo de 95% das amostras solicitadas, em vez de publicá-lo com a duração planejada.
- **Limitação:** a causa raiz da intermitência ainda não foi comprovada em aparelho. A instrumentação permitirá distinguir PTS/codec/track/EOS e a nova tentativa recupera apenas alguns cenários; testes com os mesmos arquivos e Logcat ainda são necessários.

## 4. Cobertura e sincronização de legendas

- Cache do motor de legenda atualizado para `ENGINE_VERSION = 17` para não reutilizar resultados antigos incompatíveis.
- A geração verifica a conclusão dos blocos planejados e a cobertura temporal do áudio antes de confirmar o resultado/cache.
- O overlay de legendas normaliza o timestamp da composição usando a primeira apresentação do vídeo como base, reduzindo a divergência entre tempo relativo do trecho e PTS da composição.
- Progresso da revisão automática usa o mesmo estimador da criação.
- **Pendente:** conferir com o mesmo projeto as legendas no início/meio/fim da revisão, quadro a quadro, e na exportação final. Silêncio/música sem voz ainda precisa de validação funcional em aparelho.

## 5. Relógio e progresso da geração de legendas

- `CaptionProgressEstimator13` não usa mais o maior entre progresso reportado, cobertura de áudio e tempo decorrido. Agora a porcentagem é calculada pelo tempo decorrido dividido pela mesma previsão total usada pelo relógio.
- 98% é o limite antes da confirmação; 100% só aparece quando Whisper conclui com sucesso.
- `CaptionEtaEstimator14` usa a regressão inicial calculada pelos cinco tempos fornecidos pelo usuário (15/30/40/50/60 segundos) e gera previsões para durações intermediárias.
- Aprendizado local com até 10 medições recentes comparáveis, priorizando orientação e quantidade de mídias, com média de razões, limitação de outliers após cinco amostras e persistência local.
- Histórico agregado da chave CODE16 `sonus_caption_eta_code28` é importado uma vez como referência genérica; não é apagado.
- Logs Whisper separam preparação, carga do modelo, extração/inferência e consolidação/cache.
- **Pendente:** medição de execuções sucessivas no aparelho para conferir a calibração da curva e a influência de primeira carga/download do modelo.

## 6. Relógio e progresso da exportação

- Barra e relógio usam uma previsão total congelada compartilhada.
- Progresso fica em 99% até a gravação/salvamento confirmar sucesso; somente então chega a 100%.
- Fallback para uma tentativa mais leve recalcula o total considerando o tempo já decorrido e a previsão da tentativa seguinte.
- Histórico local mantém até 256 registros; as últimas 10 exportações limpas comparáveis alimentam a média adaptativa.
- Registros guardam metadados técnicos: duração, resolução, FPS, orientação/aspect ratio, contagem de mídias, partículas, fabricante/modelo do aparelho, API Android, versão do app e indicação de primeira exportação.
- Tentativas falhas, canceladas ou que usaram fallback não contaminam a média de sucesso do perfil original.

## 7. Tempos-base de legenda e exportação

- Tempos de legenda usados como referência: 15s=107s; 30s=177s; 40s=198s; 50s=269s; 60s=302s.
- Tempos de exportação do TXT foram cadastrados como pontos medidos exatos para 720p/1080p/2K/4K em 30/60 FPS.
- A interpolação preserva os pontos não monotônicos, conforme esclarecimento do usuário: mesma música e mesmas imagens foram usadas nos diferentes tempos para controlar a origem do conteúdo. Não se presume que um vídeo mais longo sempre demore mais.
- 4K60/60s não é tratado como sucesso: seis tentativas falharam. A estimativa fria é derivada da base 4K30/60s e da razão média 4K60/4K30 nos pontos 15–50s, e está identificada como inferência, não como medição.
- 9:16 e 16:9 são perfis separados quando há metadados específicos; amostras legadas sem orientação permanecem genéricas.

## 8. Investigação da falha 4K60

- Logs de falha incluem resolução, FPS, duração, proporção, quantidade de mídias, stack trace, identificação técnica, heap da aplicação, memória livre do sistema e estado térmico quando disponível.
- A sondagem do aparelho registra os encoders AVC encontrados e suporte informado para 4K30, 4K60 e 2K60, além dos limites/alinhamento reportados.
- O fallback existente foi preservado: erros recuperáveis podem reduzir FPS/resolução conforme o tipo de falha; não foi removido nem alterado para forçar exportações instáveis.
- **Não declarado como corrigido:** ainda não há stack trace/Logcat das seis tentativas do aparelho. CODE17 melhora diagnóstico e evita treinar a média com tentativas falhas, mas não prova a causa da falha próxima de 80%.
- Ainda falta esclarecer se “3m56s” era tempo decorrido ou restante.

## 9. Carregamento das miniaturas

- Imagens locais usam leitura de bounds e decodificação com amostragem em vez de carregar o arquivo inteiro na memória.
- Vídeos usam `getScaledFrameAtTime()` quando disponível e fallback para versões suportadas.
- Adicionado cache de miniaturas em memória com limite aproximado de 12 MB.
- A qualidade dos arquivos originais e da exportação não é alterada por essa otimização.
- **Pendente:** comparar o tempo antes/depois em aparelho e verificar memória, compatibilidade e cancelamento ao trocar de mídia.

## 10. Arquivos alterados em relação ao ZIP CODE16

**23 arquivos modificados:**

- `BUILD_VERSION.txt`
- `README.md`
- `app/build.gradle.kts`
- `app/src/main/java/com/sonusstudios/sonusedit/create/AudioSegmentWavExtractor.kt`
- `app/src/main/java/com/sonusstudios/sonusedit/create/CaptionEtaEstimator14.kt`
- `app/src/main/java/com/sonusstudios/sonusedit/create/CaptionProgressEstimator13.kt`
- `app/src/main/java/com/sonusstudios/sonusedit/create/CreateModels.kt`
- `app/src/main/java/com/sonusstudios/sonusedit/create/WhisperCaptionEngine.kt`
- `app/src/main/java/com/sonusstudios/sonusedit/media/AutomaticVideoExporter.kt`
- `app/src/main/java/com/sonusstudios/sonusedit/media/ExportCapabilities02.kt`
- `app/src/main/java/com/sonusstudios/sonusedit/media/ExportEtaEstimator15.kt`
- `app/src/main/java/com/sonusstudios/sonusedit/media/ExportForegroundService.kt`
- `app/src/main/java/com/sonusstudios/sonusedit/media/VideoVisualEffects.kt`
- `app/src/main/java/com/sonusstudios/sonusedit/stats/UsageStatsStore.kt`
- `app/src/main/java/com/sonusstudios/sonusedit/ui/AboutScreen.kt`
- `app/src/main/java/com/sonusstudios/sonusedit/ui/AutoCaptionsScreen.kt`
- `app/src/main/java/com/sonusstudios/sonusedit/ui/CreateFlowScreen18.kt`
- `app/src/main/java/com/sonusstudios/sonusedit/ui/HomeScreen.kt`
- `app/src/test/java/com/sonusstudios/sonusedit/create/CaptionProgressEstimator13Test.kt`
- `app/src/test/java/com/sonusstudios/sonusedit/create/Code28StabilityTest.kt`
- `app/src/test/java/com/sonusstudios/sonusedit/create/Code30CaptionFontPoolTest.kt`
- `app/src/test/java/com/sonusstudios/sonusedit/media/ExportEtaEstimator15Test.kt`
- `codemagic.yaml`

**Arquivos adicionados:**
- `scripts/validate_v1_0_7_code17.py`
- `scripts/verify_caption_fonts17.py`
- `CODE17_SONUS_EDIT_1.0.7_IMPLEMENTATION_2026-11-28.md`
- `CODE17_FINAL_CHECKLIST_STATUS_2026-11-28.txt`
- `reference/SONUS_EDIT_CODE17_ESTIMATIVAS_ORIGINAIS.txt`
- `reference/SONUS_EDIT_CODE17_CHECKLIST_APROVADO_ORIGINAL.txt`

**1 arquivo removido dos assets:** `app/src/main/assets/fonts/Montepetrum Thin.ttf`. A identificação serializada antiga continua tratada no código para preservar rascunhos.

Documentos históricos `CODE17_IMPLEMENTATION.md` e `CODE17_APPROVED_CHECKLIST.txt` da linha antiga foram preservados; este relatório novo tem nome/data próprios para não sobrescrever aquele histórico.

## 11. Validações executadas nesta sessão

- Validador estático `scripts/validate_v1_0_7_code17.py`: passou em todas as verificações previstas.
- Harness Kotlin isolado para `CaptionEtaEstimator14`, `CaptionProgressEstimator13` e `ExportEtaEstimator15`: compilou e passou, incluindo tempos intermediários, pontos de exportação, separação 9:16/16:9 e migração de histórico legado.
- `codemagic.yaml`: parse YAML aprovado.
- Os sete scripts do workflow: `bash -n` aprovado.
- Scripts Python: `py_compile` aprovado.
- Integridade do ZIP: será conferida no pacote final.

## 12. Validações que não foram possíveis

- Não foi possível executar Gradle/Android SDK nesta sessão: o pacote não contém `gradlew`, não há Gradle instalado nem `ANDROID_HOME`/`android.jar` disponível.
- Os TTFs novos não foram baixados nesta sessão porque o contêiner não resolveu o host externo; o workflow tenta baixar e valida durante `preBuild`.
- Nenhum APK foi compilado nesta sessão.
- Nenhum teste foi realizado em aparelho físico.
- A falha 4K60 e a sincronização completa precisam de reprodução/Logcat no dispositivo para confirmação final.

## 13. Vínculo do keystore já configurado no Codemagic

O keystore não foi migrado, gerado nem alterado, e nenhum segredo foi colocado no pacote. Para que o Codemagic injete `CM_KEYSTORE_PATH`, `CM_KEYSTORE_PASSWORD`, `CM_KEY_ALIAS` e `CM_KEY_PASSWORD` a partir da área **Code signing identities**, o `codemagic.yaml` precisa listar o nome exato da referência cadastrada sob `environment.android_signing`. Esse nome não consta nos arquivos recebidos e não foi inventado. Alternativamente, se a conta usa um grupo de variáveis seguras customizado, o nome desse grupo precisa ser referenciado em `environment.groups`.

## Conclusão

O código CODE17 e os testes locais/estáticos foram atualizados. O pacote está preparado para validação no Codemagic, mas **não é correto declarar o build Android, o APK assinado ou os testes de aparelho como concluídos** enquanto os itens da seção 12–13 não forem resolvidos.
