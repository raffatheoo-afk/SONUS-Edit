# SONUS EDIT 1.0.7 / CODE17 — BUILD FIX 3

Data: 28/11/2026
Base: SonusEdit_1.0.7_CODE17_BUILD_FIX2.zip

## Falha recebida

O Codemagic concluiu `compileDebugKotlin`, executou `testDebugUnitTest` e reportou 146 testes, com duas falhas:

1. `CaptionProgressEstimator13Test.extractorRejectsAWindowThatDecodedOnlyAsAFragment`, linha 64.
2. `Code29FontAndImageRotationTest.expandedFontPoolKeepsLegacyAndIncludesNormalFaces`, linha 16.

## Causa 1 — unidade incorreta no teste de cobertura

`AudioSegmentWavExtractor.hasEnoughSampleCoverage(samplesWritten, targetSamples)` recebe contagens de amostras PCM, não milissegundos. A taxa de destino é 16.000 amostras/segundo. O teste usava `25.500 / 30.000` e comentava como se isso representasse 85% de um bloco de 30 segundos. Na realidade, 30.000 amostras representam 1,875 segundo; para blocos abaixo de 2 segundos, a implementação aplica corretamente a tolerância de 75%, portanto 25.500 amostras atingem 85% e passam.

Correção do fixture: bloco de 30 segundos passa a usar 480.000 amostras. O caso parcial usa 408.000 (85%) e deve ser rejeitado pelo limite de 95%; o caso válido usa 456.000 (95%) e deve ser aceito. O código de produção e o limite de cobertura não foram relaxados.

## Causa 2 — expectativa de catálogo desatualizada

`Code29FontAndImageRotationTest` ainda exigia o catálogo CODE11: 16 itens, sendo 15 fontes empacotadas e uma Sans-serif do sistema. O catálogo ativo CODE17 possui 20 opções: 19 fontes TTF/OTF e uma Sans-serif do sistema. A suíte já continha `Code30CaptionFontPoolTest`, que confirma o contrato atual de 20/19.

Correção: atualizar apenas as expectativas obsoletas do teste legado para 20 opções e 19 fontes empacotadas. Nenhuma fonte foi removida do catálogo.

## Arquivos alterados nesta correção

- `app/src/test/java/com/sonusstudios/sonusedit/create/CaptionProgressEstimator13Test.kt` — fixture corrigido para contagens de amostras reais em 16 kHz.
- `app/src/test/java/com/sonusstudios/sonusedit/create/Code29FontAndImageRotationTest.kt` — expectativas legadas alinhadas ao catálogo CODE17.
- Documentação de manutenção CODE17.

Nenhum código de produção, assinatura, identidade, dependência, importador, Whisper, Media3 ou configuração de exportação foi alterado nesta correção. A versão permanece 1.0.7 / CODE17.

## Validação

- Validador estático `scripts/validate_v1_0_7_code17.py`: aprovado após as alterações.
- Coerência dos limites do teste de amostras: 408.000/480.000 = 85% (rejeita); 456.000/480.000 = 95% (aceita).
- Consistência do catálogo: 20 opções, 19 com arquivo TTF/OTF e 1 opção do sistema.
- Integridade do ZIP: verificada após empacotamento.
- YAML: mantido idêntico ao `codemagic.yaml` existente.
- A suíte JUnit completa ainda precisa ser executada novamente no Codemagic; este ambiente não contém Gradle/Android SDK. Não se declara que os 146 testes já passaram após a correção.

## Próximo passo

Enviar este ZIP ao repositório e executar novamente o workflow. Esperado: `testDebugUnitTest` sem as duas falhas acima. Se aparecer nova falha, analisar o novo relatório sem remover testes ou diminuir critérios de qualidade.
