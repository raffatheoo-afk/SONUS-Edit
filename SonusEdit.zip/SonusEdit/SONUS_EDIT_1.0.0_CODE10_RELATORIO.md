# Sonus Edit 1.0.0 — CODE 10

## Ajustes desta versão

1. **Prévia de fonte:** aumentada somente a escala do texto dentro da janela preta (`textScale` 3.2 → 6.0). A largura de 98 dp e a altura disponível do painel de prévia não foram alteradas.
2. **Cartões de estilo:** na tela principal de criação, os cartões passaram de 96 × 60 dp para 104 × 78 dp. A área de demonstração passou para 56 dp, a escala do texto de demonstração para 5.8 e o rótulo para 8 sp. Isso acrescenta 18 dp de altura (aproximadamente 0,48 cm) e 8 dp de largura.
3. **Demais telas:** o seletor reutilizado na tela de legendas automáticas conserva os tamanhos padrão de 96 × 60 dp e prévia de 42 dp. O ajuste maior é passado somente pela tela principal do editor.
4. **Área dos filtros:** os pesos verticais existentes (0.63 / 0.37), as fileiras de filtros e o layout da navegação inferior foram preservados. Não foi adicionado `verticalScroll` à etapa de estilo.
5. **Sobre:** atualizado para mostrar somente a versão 1.0.0 / CODE 10 e as novidades atuais; os blocos de versões anteriores foram retirados.
6. **Versão Android:** `versionName=1.0.0` e `versionCode=10`. As identificações na tela inicial e no fluxo de criação também foram atualizadas.

## Preservação

- As opções de fontes e os 10 arquivos TTF/OTF personalizados foram mantidos.
- O mecanismo de renderização compartilhado entre prévia e exportação não foi alterado.
- O `applicationId`, Media3 1.10.1, fluxo de exportação, integração Link/FFmpeg, Whisper local e demais recursos do projeto foram preservados.
- O identificador fixo do workflow Codemagic continua `sonus-edit-0-0-3-code03-debug`.
- Nenhum keystore foi incluído como arquivo separado no ZIP.

## Verificações realizadas neste ambiente

- Validador estático `scripts/validate_v1_0_0_code10.py`: **PASSOU**.
- YAML do Codemagic: **parseado com sucesso**.
- Sintaxe Bash do passo de validação: **PASSOU**.
- Workflow fixo: **confirmado**.
- Fontes personalizadas: **10 referências e 10 arquivos presentes**.
- Integridade do ZIP: **verificada com `unzip -t`**.

## Pendências reais

Este ambiente não tem Gradle, Gradle Wrapper nem Android SDK configurados. Portanto, **JUnit, compilação Android e APK não foram executados aqui**. Ainda é necessário rodar o workflow no Codemagic e conferir visualmente em aparelho real que os cartões ampliados cabem no espaço reservado sem tocar na área de filtros.

O link de imagem do Google Drive enviado nesta conversa não pôde ser aberto por uma conexão de Drive disponível. Os ajustes foram aplicados conforme a descrição detalhada do pedido e o código atual da CODE 08; não afirmo ter inspecionado a imagem compartilhada no Drive.
