# Third-party notice

The deployment stack uses the upstream Cobalt container image `ghcr.io/imputnet/cobalt:11` at runtime. Cobalt is maintained by imputnet. Its repository identifies AGPL-3.0 as the default repository license unless a subproject specifies otherwise. This SONUS gateway does not copy Cobalt source code into the Android application or modify the Cobalt image.

Upstream project and license: https://github.com/imputnet/cobalt

Review the current upstream license and the API-specific license before modifying, redistributing, or offering a modified Cobalt service. The SONUS gateway source in this directory is separate code and does not replace or relicense the upstream Cobalt components.
