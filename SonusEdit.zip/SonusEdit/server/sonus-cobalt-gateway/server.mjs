import { createServer } from 'node:http';
import { DatabaseSync } from 'node:sqlite';
import { Readable, Transform } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { mkdirSync } from 'node:fs';
import { dirname, basename, extname, join } from 'node:path';
import { lookup } from 'node:dns/promises';
import { isIP } from 'node:net';

const PORT = Number(process.env.PORT || 8080);
const COBALT_INTERNAL_URL = requiredUrl('COBALT_INTERNAL_URL');
const COBALT_PUBLIC_URL = requiredUrl('COBALT_PUBLIC_URL');
const COBALT_API_KEY = required('COBALT_API_KEY');
const MONTHLY_LIMIT = Math.max(0, Number(process.env.SONUS_MONTHLY_LIMIT || 0)); // 0 = unlimited, counting stays enabled.
const IP_RATE_LIMIT = Math.max(1, Number(process.env.SONUS_IP_RATE_LIMIT_PER_MINUTE || 30));
const MAX_AUDIO_BYTES = Math.max(10 * 1024 * 1024, Number(process.env.SONUS_MAX_AUDIO_BYTES || 536870912));
const DB_PATH = process.env.SONUS_DATABASE_PATH || '/data/usage.sqlite';
const REQUEST_TIMEOUT_MS = Math.max(30_000, Number(process.env.SONUS_REQUEST_TIMEOUT_MS || 300_000));

function required(name) {
  const value = process.env[name]?.trim();
  if (!value) throw new Error(`Missing required environment variable: ${name}`);
  return value;
}
function requiredUrl(name) {
  const raw = required(name);
  const value = new URL(raw);
  if (!['http:', 'https:'].includes(value.protocol) || value.username || value.password) {
    throw new Error(`${name} must be an HTTP(S) URL without embedded credentials`);
  }
  return value.toString().endsWith('/') ? value.toString() : `${value.toString()}/`;
}

mkdirSync(dirname(DB_PATH), { recursive: true });
const db = new DatabaseSync(DB_PATH);
db.exec(`
  PRAGMA journal_mode = WAL;
  PRAGMA busy_timeout = 5000;
  CREATE TABLE IF NOT EXISTS installations (
    install_id TEXT PRIMARY KEY,
    successful_total INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS monthly_usage (
    install_id TEXT NOT NULL,
    period TEXT NOT NULL,
    successful INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (install_id, period)
  );
  CREATE TABLE IF NOT EXISTS daily_usage (
    install_id TEXT NOT NULL,
    period TEXT NOT NULL,
    successful INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (install_id, period)
  );
`);

const selectStats = db.prepare(`
  SELECT
    COALESCE((SELECT successful_total FROM installations WHERE install_id = ?), 0) AS total,
    COALESCE((SELECT successful FROM monthly_usage WHERE install_id = ? AND period = ?), 0) AS month,
    COALESCE((SELECT successful FROM daily_usage WHERE install_id = ? AND period = ?), 0) AS day
`);
function incrementUsage(installId, monthKey, dayKey) {
  db.exec('BEGIN IMMEDIATE');
  try {
    const now = new Date().toISOString();
    db.prepare(`INSERT INTO installations (install_id, successful_total, updated_at)
      VALUES (?, 1, ?) ON CONFLICT(install_id) DO UPDATE SET
      successful_total = successful_total + 1, updated_at = excluded.updated_at`).run(installId, now);
    db.prepare(`INSERT INTO monthly_usage (install_id, period, successful)
      VALUES (?, ?, 1) ON CONFLICT(install_id, period) DO UPDATE SET successful = successful + 1`).run(installId, monthKey);
    db.prepare(`INSERT INTO daily_usage (install_id, period, successful)
      VALUES (?, ?, 1) ON CONFLICT(install_id, period) DO UPDATE SET successful = successful + 1`).run(installId, dayKey);
    db.exec('COMMIT');
  } catch (error) {
    db.exec('ROLLBACK');
    throw error;
  }
}

function utcPeriods() {
  const now = new Date();
  return {
    month: now.toISOString().slice(0, 7),
    day: now.toISOString().slice(0, 10),
  };
}
function statsFor(installId) {
  const periods = utcPeriods();
  return selectStats.get(installId, installId, periods.month, installId, periods.day);
}
function usagePayload(installId) {
  const stats = statsFor(installId);
  return {
    total: Number(stats.total),
    month: Number(stats.month),
    day: Number(stats.day),
    monthKey: utcPeriods().month,
    monthlyLimit: MONTHLY_LIMIT > 0 ? MONTHLY_LIMIT : null,
    remaining: MONTHLY_LIMIT > 0 ? Math.max(0, MONTHLY_LIMIT - Number(stats.month)) : null,
    countingMode: 'successful-downloads-per-installation',
  };
}

function json(res, status, body, extraHeaders = {}) {
  const content = Buffer.from(JSON.stringify(body));
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': content.length,
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
    ...extraHeaders,
  });
  res.end(content);
}
async function readJson(req, maxBytes = 32 * 1024) {
  const chunks = [];
  let total = 0;
  for await (const chunk of req) {
    total += chunk.length;
    if (total > maxBytes) throw Object.assign(new Error('Request body too large'), { status: 413 });
    chunks.push(chunk);
  }
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); }
  catch { throw Object.assign(new Error('Invalid JSON body'), { status: 400 }); }
}
function installationId(req) {
  const value = String(req.headers['x-sonus-install-id'] || '').toLowerCase();
  if (!/^[a-f0-9]{64}$/.test(value)) {
    throw Object.assign(new Error('SONUS installation identifier is missing or invalid.'), { status: 400 });
  }
  return value;
}

const ipRequests = new Map();
const activeInstallations = new Set();
function enforceIpLimit(req) {
  const now = Date.now();
  const forwarded = String(req.headers['x-forwarded-for'] || '');
  const ip = (forwarded ? forwarded.split(',').at(-1) : req.socket.remoteAddress || 'unknown').trim();
  const entry = ipRequests.get(ip);
  if (!entry || now - entry.windowStart >= 60_000) {
    ipRequests.set(ip, { windowStart: now, count: 1 });
    return;
  }
  entry.count += 1;
  if (entry.count > IP_RATE_LIMIT) {
    throw Object.assign(new Error('Muitas solicitações deste endereço. Aguarde um minuto e tente novamente.'), { status: 429 });
  }
}
setInterval(() => {
  const cutoff = Date.now() - 120_000;
  for (const [ip, entry] of ipRequests) if (entry.windowStart < cutoff) ipRequests.delete(ip);
}, 60_000).unref();

function isPrivateAddress(address) {
  const ipType = isIP(address);
  if (ipType === 4) {
    const parts = address.split('.').map(Number);
    const [a, b] = parts;
    return a === 0 || a === 10 || a === 127 || (a === 169 && b === 254) ||
      (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) ||
      (a === 100 && b >= 64 && b <= 127) || a >= 224;
  }
  if (ipType === 6) {
    const v = address.toLowerCase();
    return v === '::1' || v === '::' || v.startsWith('fc') || v.startsWith('fd') ||
      v.startsWith('fe8') || v.startsWith('fe9') || v.startsWith('fea') || v.startsWith('feb') ||
      v.startsWith('::ffff:127.') || v.startsWith('::ffff:10.') || v.startsWith('::ffff:192.168.');
  }
  return true;
}
async function assertPublicHttps(url) {
  if (url.protocol !== 'https:' || url.username || url.password) {
    throw Object.assign(new Error('A origem retornou um endereço de mídia inseguro.'), { status: 502 });
  }
  if (url.origin === new URL(COBALT_PUBLIC_URL).origin) return;
  const records = await lookup(url.hostname, { all: true, verbatim: true });
  if (!records.length || records.some(record => isPrivateAddress(record.address))) {
    throw Object.assign(new Error('A origem retornou um destino de rede não público.'), { status: 502 });
  }
}

async function fetchMediaSafely(rawUrl, cobaltTunnel) {
  let current = new URL(rawUrl);
  for (let hop = 0; hop <= 5; hop += 1) {
    await assertPublicHttps(current);
    const headers = {};
    if (current.origin === new URL(COBALT_PUBLIC_URL).origin) {
      headers.Authorization = `Api-Key ${COBALT_API_KEY}`;
    } else if (cobaltTunnel) {
      throw Object.assign(new Error('O túnel Cobalt redirecionou para um host inesperado.'), { status: 502 });
    }
    const response = await fetch(current, {
      method: 'GET', headers, redirect: 'manual',
      signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
    });
    if (response.status >= 300 && response.status < 400) {
      const location = response.headers.get('location');
      if (!location) throw Object.assign(new Error('Redirecionamento de mídia sem destino.'), { status: 502 });
      current = new URL(location, current);
      continue;
    }
    return response;
  }
  throw Object.assign(new Error('A mídia excedeu o número permitido de redirecionamentos.'), { status: 502 });
}

function safeFilename(value, mime) {
  let name = basename(String(value || 'sonus-audio')).replace(/[\r\n"\\]/g, '').replace(/[^\p{L}\p{N} ._()-]/gu, '_').trim();
  if (!name || name === '.' || name === '..') name = 'sonus-audio';
  if (!extname(name)) {
    const extension = ({
      'audio/mp4': '.m4a', 'audio/x-m4a': '.m4a', 'audio/mpeg': '.mp3',
      'audio/aac': '.aac', 'audio/wav': '.wav', 'audio/x-wav': '.wav',
      'audio/ogg': '.ogg', 'application/ogg': '.ogg', 'audio/opus': '.opus', 'audio/webm': '.webm', 'audio/flac': '.flac',
      'application/octet-stream': '.bin',
    })[mime] || '.audio';
    name += extension;
  }
  return name.slice(0, 160);
}

async function createCobaltAudioUrl(sourceUrl) {
  const response = await fetch(COBALT_INTERNAL_URL, {
    method: 'POST',
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/json',
      Authorization: `Api-Key ${COBALT_API_KEY}`,
    },
    body: JSON.stringify({
      url: sourceUrl,
      downloadMode: 'audio',
      audioFormat: 'best',
      audioBitrate: '320',
      filenameStyle: 'pretty',
      disableMetadata: false,
      alwaysProxy: true,
      localProcessing: 'disabled',
      youtubeBetterAudio: true,
      tiktokFullAudio: true,
    }),
    signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const code = payload?.error?.code || `cobalt_http_${response.status}`;
    throw Object.assign(new Error(`Cobalt recusou o processamento (${code}).`), { status: response.status === 429 ? 429 : 502 });
  }
  if (payload.status === 'error') {
    const code = payload?.error?.code || 'unknown';
    throw Object.assign(new Error(`Cobalt não conseguiu processar este link (${code}).`), { status: 422 });
  }
  if (payload.status === 'local-processing') {
    throw Object.assign(new Error('O Cobalt solicitou processamento local, que está desativado no SONUS para manter o APK leve.'), { status: 422 });
  }
  let mediaUrl = payload.url;
  let tunnel = payload.status === 'tunnel';
  if (payload.status === 'picker' && payload.audio) {
    mediaUrl = payload.audio;
    tunnel = true;
  }
  if (!['tunnel', 'redirect', 'picker'].includes(payload.status) || typeof mediaUrl !== 'string') {
    throw Object.assign(new Error('Cobalt não retornou uma faixa de áudio para este link.'), { status: 422 });
  }
  const resolved = new URL(mediaUrl, COBALT_PUBLIC_URL);
  if (tunnel && resolved.origin !== new URL(COBALT_PUBLIC_URL).origin) {
    throw Object.assign(new Error('A resposta do Cobalt informou um túnel em host inesperado.'), { status: 502 });
  }
  return { mediaUrl: resolved.toString(), tunnel, filename: payload.filename || payload.audioFilename || 'sonus-audio' };
}

async function handleAudio(req, res) {
  enforceIpLimit(req);
  const installId = installationId(req);
  const input = await readJson(req);
  const sourceUrl = String(input?.url || '').trim();
  let parsed;
  try { parsed = new URL(sourceUrl); }
  catch { throw Object.assign(new Error('Cole um link válido.'), { status: 400 }); }
  if (parsed.protocol !== 'https:' || parsed.username || parsed.password || !parsed.hostname) {
    throw Object.assign(new Error('O SONUS aceita links HTTPS públicos, sem credenciais no endereço.'), { status: 400 });
  }

  if (activeInstallations.has(installId)) {
    throw Object.assign(new Error('Já existe uma importação em andamento nesta instalação.'), { status: 409 });
  }
  const current = statsFor(installId);
  if (MONTHLY_LIMIT > 0 && Number(current.month) >= MONTHLY_LIMIT) {
    throw Object.assign(new Error(`Limite mensal do SONUS atingido (${MONTHLY_LIMIT} importações).`), { status: 429 });
  }

  // Serialize jobs per installation so two simultaneous requests cannot spend the same last quota slot.
  activeInstallations.add(installId);
  try {
    const cobalt = await createCobaltAudioUrl(parsed.toString());
    const upstream = await fetchMediaSafely(cobalt.mediaUrl, cobalt.tunnel);
    if (!upstream.ok || !upstream.body) {
      throw Object.assign(new Error(`Não foi possível receber o áudio do Cobalt (HTTP ${upstream.status}).`), { status: upstream.status === 429 ? 429 : 502 });
    }
    const mime = (upstream.headers.get('content-type') || 'application/octet-stream').split(';')[0].trim().toLowerCase();
    if (mime.startsWith('text/') || mime.includes('html') || mime.startsWith('video/')) {
      await upstream.body.cancel().catch(() => {});
      throw Object.assign(new Error('O Cobalt retornou uma página ou vídeo, não uma faixa de áudio.'), { status: 502 });
    }
    const filename = safeFilename(
      upstream.headers.get('content-disposition')?.match(/filename\*?=(?:UTF-8''|"?)([^;"\r\n]+)/i)?.[1]?.replace(/^"|"$/g, '') || cobalt.filename,
      mime,
    );
    const contentLength = upstream.headers.get('content-length');
    if (contentLength && Number(contentLength) > MAX_AUDIO_BYTES) {
      await upstream.body.cancel().catch(() => {});
      throw Object.assign(new Error('O áudio ultrapassa o tamanho máximo configurado para o SONUS.'), { status: 413 });
    }

    res.writeHead(200, {
      'Content-Type': mime,
      'Content-Disposition': `attachment; filename="${filename.replace(/"/g, '')}"`,
      ...(contentLength ? { 'Content-Length': contentLength } : {}),
      'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff',
      'X-Sonus-Provider': 'Cobalt',
    });
    let transferred = 0;
    const byteGuard = new Transform({
      transform(chunk, _encoding, callback) {
        transferred += chunk.length;
        if (transferred > MAX_AUDIO_BYTES) callback(Object.assign(new Error('Audio size limit exceeded'), { code: 'SONUS_SIZE_LIMIT' }));
        else callback(null, chunk);
      },
    });
    await pipeline(Readable.fromWeb(upstream.body), byteGuard, res);
    const periods = utcPeriods();
    incrementUsage(installId, periods.month, periods.day);
  } finally {
    activeInstallations.delete(installId);
  }
}

const server = createServer(async (req, res) => {
  try {
    const url = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);
    if (req.method === 'GET' && url.pathname === '/health') {
      const cobaltResponse = await fetch(COBALT_INTERNAL_URL, {
        headers: { Authorization: `Api-Key ${COBALT_API_KEY}` },
        signal: AbortSignal.timeout(5_000),
      });
      const cobaltInfo = await cobaltResponse.json().catch(() => ({}));
      if (!cobaltResponse.ok) throw Object.assign(new Error('A instância Cobalt não respondeu corretamente.'), { status: 503 });
      json(res, 200, {
        service: 'sonus-cobalt-gateway', status: 'ok',
        cobaltVersion: cobaltInfo?.cobalt?.version || 'unknown',
        services: Array.isArray(cobaltInfo?.cobalt?.services) ? cobaltInfo.cobalt.services : [],
      });
      return;
    }
    if (req.method === 'GET' && url.pathname === '/v1/usage') {
      const id = installationId(req);
      json(res, 200, usagePayload(id));
      return;
    }
    if (req.method === 'POST' && url.pathname === '/v1/audio') {
      await handleAudio(req, res);
      return;
    }
    json(res, 404, { error: 'not_found', message: 'Endpoint não encontrado.' });
  } catch (error) {
    if (res.headersSent) {
      if (!res.destroyed) res.destroy(error);
      return;
    }
    const status = Number(error?.status || 500);
    if (status >= 500) console.error(`[sonus-gateway] ${error?.message || 'internal error'}`);
    json(res, status, { error: error?.code || 'sonus_gateway_error', message: String(error?.message || 'Falha interna do gateway.').slice(0, 240) });
  }
});

server.headersTimeout = REQUEST_TIMEOUT_MS + 15_000;
server.requestTimeout = REQUEST_TIMEOUT_MS + 15_000;
server.listen(PORT, '0.0.0.0', () => {
  console.log(`[sonus-gateway] listening on :${PORT}; monthly limit=${MONTHLY_LIMIT || 'unlimited'}`);
});

for (const signal of ['SIGINT', 'SIGTERM']) {
  process.on(signal, () => {
    server.close(() => {
      db.close();
      process.exit(0);
    });
  });
}
