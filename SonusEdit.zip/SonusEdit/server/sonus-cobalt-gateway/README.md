# SONUS Link Gateway + Cobalt

Servidor opcional para o SONUS EDIT. O APK chama somente este gateway; a chave da API Cobalt fica no servidor e não é incluída no aplicativo.

## O que este pacote faz

- recebe `POST /v1/audio` com `{ "url": "https://..." }`;
- solicita ao Cobalt uma faixa em modo áudio (`downloadMode: audio`, `audioFormat: best`);
- transmite o arquivo ao Android sem gravar uma biblioteca permanente no servidor;
- mantém uma base SQLite persistente com contagem de importações concluídas por instalação;
- oferece `GET /v1/usage` com total, mês, dia e limite configurado;
- permite limitar importações por instalação/mês e também limita a frequência por IP;
- mantém as credenciais Cobalt no ambiente do gateway.

A contagem é por instalação Android (ID derivado e com hash de `ANDROID_ID`), não por conta de usuário. Reinstalação, redefinição de fábrica ou restauração de um dispositivo pode criar outra identidade. Não use essa contagem isolada como medição de faturamento sem autenticação de usuário.

## Requisitos de hospedagem

- servidor Linux com Docker Engine e Docker Compose;
- domínio próprio e DNS apontando para o servidor;
- portas TCP 80 e 443 liberadas para o Caddy emitir/renovar TLS;
- recursos de CPU, RAM e tráfego adequados à quantidade e duração dos arquivos.

A execução não é gratuita por si só: o software é aberto, mas VPS, armazenamento temporário e tráfego de rede podem ter custos. Não use o serviço público `api.cobalt.tools` como endpoint do aplicativo; a documentação oficial orienta hospedar sua própria instância ou obter autorização expressa do proprietário.

## Instalação

1. Copie esta pasta para seu servidor.
2. Duplique `.env.example` para `.env`.
3. Altere `COBALT_DOMAIN` e `SONUS_GATEWAY_DOMAIN` para dois subdomínios seus. Crie registros DNS A/AAAA apontando ambos para o IP público do servidor.
4. Gere uma UUIDv4 nova para a chave da API Cobalt. Coloque a mesma UUID em `.env` (`COBALT_API_KEY`) e em `keys.json` (copie `keys.json.example`). Nunca reutilize o valor ilustrativo do exemplo.
5. Mantenha `SONUS_MONTHLY_LIMIT=0` para contar sem limitar. Para uma cota de 100 importações concluídas por instalação/mês, use `SONUS_MONTHLY_LIMIT=100`.
6. Inicie:

   ```bash
   docker compose up -d --build
   ```

7. Confira:

   ```bash
   curl https://SEU_GATEWAY/health
   ```

   Deve retornar `{"service":"sonus-cobalt-gateway","status":"ok"}`.

O Cobalt fica na rede interna do Compose; apenas o Caddy publica os domínios HTTPS. O `API_URL` interno/público é separado de propósito: o gateway chama `http://cobalt:9000/`, enquanto o Cobalt gera túneis em `https://COBALT_DOMAIN/`. A instância usa uma única subinstância; escalonamento horizontal com Redis pode ser configurado depois, seguindo os requisitos da versão do Cobalt.

## Conectar o aplicativo pelo Codemagic

Na conta Codemagic, no grupo de variáveis utilizado para compilar o SONUS EDIT, adicione:

- **Variable name:** `SONUS_LINK_GATEWAY_URL`
- **Variable value:** `https://SEU_GATEWAY` (domínio de `SONUS_GATEWAY_DOMAIN`)
- **Secret:** desmarcado; é apenas o endereço público, não uma chave.

A compilação injeta este endereço em `BuildConfig.SONUS_LINK_GATEWAY_URL`. Não adicione `COBALT_API_KEY` ao Codemagic nem ao APK. Essa chave existe somente no `.env` do servidor e no arquivo privado `keys.json` do container Cobalt.

Se o endereço do gateway não estiver configurado durante a compilação, o importador continua aceitando URLs diretas de arquivos, mas os links de páginas sociais não poderão usar o Cobalt até uma nova compilação com o endereço correto.

## Contagem e limites

`GET /v1/usage` requer `X-Sonus-Install-ID` com 64 caracteres hexadecimais e retorna:

- `total`: importações finalizadas com sucesso desde o primeiro uso daquela instalação;
- `month`: importações concluídas no mês UTC atual;
- `day`: importações concluídas no dia UTC atual;
- `monthlyLimit`: `null` quando ilimitado ou o limite configurado;
- `remaining`: saldo do mês quando houver limite.

Falhas, solicitações rejeitadas e transferências interrompidas não são contadas como importações concluídas. O gateway persiste os totais no volume Docker `sonus-usage`.

A cota padrão é ilimitada (`SONUS_MONTHLY_LIMIT=0`), mas a contagem permanece ativa. `SONUS_IP_RATE_LIMIT_PER_MINUTE` protege o endpoint contra rajadas por endereço IP; o Cobalt também tem limite próprio por chave e janela, configurado no `docker-compose.yml` e `keys.json`.

## Segurança e privacidade

- Use HTTPS público e não exponha diretamente a porta 9000 do Cobalt.
- Guarde `.env` e `keys.json` fora de repositórios públicos e faça backup seguro do volume `sonus-usage`.
- Não coloque cookies de plataformas, tokens de sessão ou chaves privadas na configuração.
- O gateway não guarda os arquivos baixados; ele os transmite em fluxo. O Cobalt também informa que não armazena em cache o conteúdo processado.
- A URL original é encaminhada ao Cobalt para processamento. Evite enviar links que contenham dados pessoais ou credenciais.
- A contagem é por instalação, sem autenticação individual. Para planos pagos ou cotas resistentes a fraude, acrescente autenticação de conta e validação de identidade no servidor antes de vender limites.
- O Cobalt é um projeto externo. Respeite sua licença e suas condições, e use apenas conteúdo público que você tenha direito/autorização para importar. A integração não implementa login, DRM, cookies ou contorno de controle de acesso.

## Referências upstream

- Projeto Cobalt: https://github.com/imputnet/cobalt
- Como executar uma instância: https://github.com/imputnet/cobalt/blob/main/docs/run-an-instance.md
- Proteção por chave API: https://github.com/imputnet/cobalt/blob/main/docs/protect-an-instance.md
- Contrato da API: https://github.com/imputnet/cobalt/blob/main/docs/api.md
- Variáveis de ambiente: https://github.com/imputnet/cobalt/blob/main/docs/api-env-variables.md

Este diretório contém somente o gateway SONUS e os arquivos de implantação. O código/imagem do Cobalt é obtido do registry oficial em tempo de execução; nenhum binário Cobalt ou FFmpeg é empacotado no APK.

## Observação sobre suporte por plataforma

A lista de serviços reconhecidos pelo Cobalt não significa que todos aceitam áudio isolado. Na matriz oficial consultada, YouTube (incluindo YouTube Music e Shorts), TikTok, Instagram, SoundCloud, Reddit, Pinterest, Bluesky, Vimeo, Streamable, Dailymotion, Bilibili, Rutube, Snapchat, Tumblr e Twitch Clips aparecem com suporte a áudio. Facebook, Loom, OK.ru e VK aparecem apenas com vídeo+áudio/vídeo, sem áudio isolado; nesses casos a solicitação `downloadMode=audio` poderá retornar erro. A matriz upstream pode mudar: https://github.com/imputnet/cobalt/tree/main/api#supported-services.

O Cobalt usa `ffmpeg` internamente no servidor para operações de muxagem/encode. Isso não adiciona FFmpeg ao APK: o Android recebe apenas o arquivo de áudio pronto pelo gateway.
