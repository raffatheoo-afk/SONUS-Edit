# SONUS Edit 0.0.19 / code19

Status: implementation package prepared from the user-approved code19 checklist.

## Changes
- Signature settings: fixes the clipped name field and restores clear Patrick Hand / Rancho / Playball selectors.
- Automatic captions: independent enable/disable switch; disabled means no Whisper work and no caption gating.
- Whisper: multilingual Base model, 30 s chunks with 1.5 s overlap, overlap de-duplication, low-memory PCM normalization and cache by audio/trim/duration.
- Caption state: prominent red/green/yellow status on Style. Advance is blocked only while an enabled caption job is pending; success/error/disabled states can proceed.
- Caption rendering: thin black stroke plus the existing soft shadow.
- Gallery: search first, one visual pool, optimistic remote selection, selected media shown with a green check.
- Particles: RAW_GREEN_60 chroma key strengthened to remove the pale white haze; raw MP4 assets are unchanged.
- Fonts and filters: long press toggles favourites; automation uses persistent shuffle bags, all choices when there are no favourites and only favourites otherwise.
- Filters: visible 3x3 grid adds Contraste Suave, Quente Natural and Frio Natural, with distinct preview/real processing.
- Artist/category resolver: indexed local SQLite seed (1,924 artists, 40 aliases, 24 categories) gates image selection by filename/folder category and blocks explicit conflicts.

## Preserved contracts
- package `com.sonusstudios.sonusedit`
- Media3 1.10.1
- 9:16, 720p/1080p/2K/4K, 30/60 FPS
- durations 15/30/40/50/60/65/infinity
- max 50 visual media
- raw particle MP4 files unchanged
- persistent signing workflow id `sonus-edit-0-0-3-code03-debug`

## Validation
The package includes unit-test coverage for category normalization/gating and the existing duration, metadata, suggestion and statistics tests. The Codemagic workflow runs static guards, `:app:compileDebugKotlin`, unit tests and then `:app:assembleDebug` with the persistent signer. A full Android build is not available in the local packaging environment, so Codemagic remains the authoritative compile/device-build check.
