# CODE 17 — Cobalt (implementação substituída)

Este documento descreve uma proposta anterior de integração com Cobalt, agora removida do projeto ativo.

A manutenção mais recente do mesmo CODE 17 utiliza um hand-off do Android para o site oficial OpenDownloader, sem VPS nem gateway Cobalt. Consulte `CODE17_OPENDOWNLOADER_HANDOFF.md` e `CODE17_IMPLEMENTATION.md` para a implementação vigente e seus limites reais de compatibilidade.
