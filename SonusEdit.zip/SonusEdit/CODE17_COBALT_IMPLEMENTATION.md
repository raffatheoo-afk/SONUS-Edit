# SONUS EDIT 1.0.7 / CODE 17 — integração Cobalt

## Escopo mantido
- `versionName=1.0.7` e `versionCode=17` sem alteração.
- `applicationId` e assinatura persistente preservados.
- Nenhum binário Cobalt, FFmpeg ou yt-dlp adicionado ao APK.
- Whisper Small e recursos existentes preservados.

## Integração
- URLs de páginas reconhecidas pelo Cobalt são encaminhadas ao `CobaltGatewayClient` no Android.
- O aplicativo chama apenas o SONUS Link Gateway via HTTPS; a chave da API Cobalt fica no servidor.
- O gateway solicita áudio ao Cobalt com `downloadMode=audio`, `audioFormat=best` e `localProcessing=disabled`, depois transmite o arquivo em fluxo ao aplicativo.
- A integração cobre os serviços listados pela matriz oficial do Cobalt, mas a disponibilidade de áudio isolado varia por serviço. Facebook, Loom, OK.ru e VK, por exemplo, não aparecem como compatíveis com áudio isolado na matriz consultada.
- Não são implementados cookies de sessão, login, DRM, acesso privado ou contorno de proteções.

## Contagem e cota
- SQLite registra importações que terminaram com transferência completa.
- O app mostra contagem mensal e total por instalação.
- `SONUS_MONTHLY_LIMIT=0` significa ilimitado com contagem habilitada; outro valor configura limite mensal por instalação.
- Um bloqueio de concorrência por instalação impede que duas solicitações simultâneas consumam a mesma última vaga da cota no gateway único.
- A identificação é por instalação, não por usuário autenticado; não deve ser usada como faturamento/antifraude sem autenticação de conta.

## Servidor incluído
`server/sonus-cobalt-gateway/` contém Docker Compose, Caddy, gateway Node.js, exemplos de ambiente e instruções. O Compose utiliza a imagem oficial `ghcr.io/imputnet/cobalt:11`. A API exige chave e o gateway autentica também o endpoint de saúde. A instância está configurada em modo de uma única subinstância; a documentação do Cobalt exige Redis e runtime específico para usar múltiplas subinstâncias.

## Configuração obrigatória antes do uso real
1. Provisionar uma VPS Linux com Docker e domínio.
2. Configurar `.env` e `keys.json` privados na VPS com UUID nova.
3. Iniciar `docker compose up -d --build` e testar `/health`.
4. No Codemagic, criar `SONUS_LINK_GATEWAY_URL` com `https://` e o domínio do gateway público. É um endereço público, portanto Secret desmarcado.
5. Compilar o APK com essa variável definida. Sem o domínio real injetado no BuildConfig, links de páginas sociais não se conectam ao gateway.

## Validações feitas nesta manutenção
- Validador estático existente do CODE 17 aprovado.
- `node --check` no gateway aprovado.
- Compilação isolada de `CobaltGatewayClient.kt` com stubs Android/JSON e coroutines aprovada (não substitui build Android completo). Teste de classificação isolado aprovou 11 domínios de serviços Cobalt.
- Teste de integração local com uma instância Cobalt simulada: autenticação no health, streaming de áudio, persistência SQLite, bloqueio mensal HTTP 429 e proteção contra importações simultâneas da mesma instalação (HTTP 409) aprovados.
- YAML e Docker Compose serão novamente verificados no empacotamento final.
- Build Android completo não foi executado: este ambiente não tem Android SDK/Gradle configurados. O Codemagic é necessário para validar o APK final.

## Referências técnicas
- Cobalt API: https://github.com/imputnet/cobalt/blob/main/docs/api.md
- Matriz de serviços: https://github.com/imputnet/cobalt/blob/main/api/README.md
- Proteção por API key: https://github.com/imputnet/cobalt/blob/main/docs/protect-an-instance.md
- Variáveis de ambiente: https://github.com/imputnet/cobalt/blob/main/docs/api-env-variables.md
