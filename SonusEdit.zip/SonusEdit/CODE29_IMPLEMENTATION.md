# SONUS Edit 1.5 / code29 — Fontes, variedade e estatísticas

## Fontes
- Integrados 35 arquivos únicos do ZIP de fontes. `Valid Harmony.otf` e `RJOETRIAL.otf` foram descartados por duplicarem as respectivas famílias TTF.
- Mantidos os oito presets legados e adicionadas duas fontes simples de sistema (Sans-serif e Serif).
- A cada nova sessão, oito fontes diferentes são sorteadas para a grade; a opção Fonte dinâmica fica selecionada por padrão e usa uma fonte aleatória para a legenda.
- A grade e o botão dinâmico ocupam duas linhas alinhadas; o preview fica à direita da primeira linha. O renderer carrega a fonte embutida e mantém o cálculo de quebra/redução de tamanho para respeitar a área segura.

## Variedade de imagens
- Histórico local armazena os conjuntos de imagens remotas usados nos três projetos mais recentes.
- O seletor exclui essas imagens se ainda houver opções suficientes; somente reutiliza itens recentes quando o catálogo não consegue completar a quantidade pedida.

## Estatísticas
- O intervalo de edição começa quando o áudio fica pronto, não durante importação/download do link.
- O intervalo ativo é fechado na entrada da tela de exportação. A duração da exportação continua disponível como estatística separada, mas deixa de ser somada ao tempo de edição automática.

## Partículas da nuvem
- O shader agora tem modos separados para efeitos remotos: remove com mais firmeza o cinza escuro de compressão e eleva o sinal dos pixels restantes. Os dois efeitos internos continuam usando os modos originais 0 e 1, sem alterar seus parâmetros.

## Validação
- `scripts/validate_v1_5_code29.py` verifica as proteções da versão 1.4 e os novos requisitos.
- Teste unitário adicionado para o pool de fontes e a não repetição de imagens recentes.
- A validação estática não substitui compilação Android nem testes reais no aparelho; executar o workflow do Codemagic e conferir exportações antes de declarar aprovação final.
