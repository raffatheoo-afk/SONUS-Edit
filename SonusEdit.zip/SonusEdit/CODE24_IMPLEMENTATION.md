# SONUS Edit 1.0 — code24

**Base oficial:** source code23 buildfix1, correspondente à versão instalada 0.0.23/code23. **Nova versão:** `versionName = "1.0"` e `versionCode = 24`.

## Mudanças
- Formatos 9:16 e 16:9: pictogramas maiores e coloridos de plataformas, posicionados à direita; miniatura geométrica e proporção à esquerda.
- Indicador das quatro etapas: círculos de 31→35 dp, espaçamento de 7→9 dp e ícones de 17→20 dp; cabeçalho mantém versão e badge.
- Partículas: controles imediatamente ao lado da legenda em Estilo.
- Cor da legenda: sete opções em linha única com amostras; Preto incluído; Dinâmico é padrão e percorre as nove cores preexistentes, sem exibi-las como botões individuais. Código de paleta compartilhado por preview e exportação.
- Preto recebe contorno claro discreto ao exportar para ser legível sobre imagens escuras.
- Revisão: player vertical cresce conforme altura disponível (104–150 dp de largura e 9:16 real); Qualidade/FPS descem naturalmente com o player. Player 16:9 continua preenchendo largura disponível; Exportar permanece no rodapé fixo.
- Home exibe versão 1.0, preservada sua estrutura.

## Preservação
Sem alterações intencionais em Gallery, fontes, filtros, Stream, Link, integração SONUS, Media3, Whisper, exportação longa, assinatura, áudio/vídeo ou partículas RAW.

## Verificações
- `scripts/validate_code24.py`: versão, opções visíveis, integração, recursos, exportação, SHA256 de partículas e contratos principais.
- `Code24LyricPaletteTest.kt`: nove cores do Dinâmico, Preto individual e estabilidade de cores estáticas.
- `codemagic.yaml`: compileDebugKotlin → unit tests → assembleDebug, signer persistente existente, validação estática com guards code23 + code24.
- Android SDK/Gradle completo não disponível no ambiente desta edição: APK **não compilado localmente**. A compilação e testes Android de verdade devem ser feitos no Codemagic.

## Teste em aparelho depois do build
- Topo legível em fonte normal/grande e sem sobrepor a barra de status.
- 9:16 e 16:9 com ícones identificáveis e proporção selecionável.
- Todas as sete cores (inclusive Preto) e Dinâmico alternando nove tons durante a legenda.
- Revisão 9:16/16:9: player adequado, botões Qualidade/FPS e Exportar sem corte, sem rolagem vertical.
- Gallery e filtros permanecem idênticos à code23.
