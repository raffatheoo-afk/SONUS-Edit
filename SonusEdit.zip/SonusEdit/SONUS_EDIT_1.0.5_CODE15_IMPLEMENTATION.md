# SONUS EDIT 1.0.5 — CODE 15

## Base e compatibilidade

- Base utilizada: pacote original `SonusEdit.zip`, versão 1.0.4 / versionCode 14.
- Nova identificação: versão 1.0.5 / versionCode 15.
- `applicationId` mantido em `com.sonusstudios.sonusedit`.
- Nenhuma troca de namespace, de dependência de runtime ou de identidade visual foi feita.
- O bloco `Restore persistent Sonus Edit signing` do `codemagic.yaml` foi mantido byte a byte igual ao arquivo original. O keystore embutido foi validado com `keytool`; as variáveis de assinatura e a configuração Gradle de assinatura não foram alteradas.

## Galeria pCloud

- Pré-carregamento das dez primeiras mídias selecionadas para a proporção ativa.
- Concorrência de miniaturas limitada a três tarefas.
- Requisições simultâneas para a mesma chave estável compartilham o mesmo trabalho.
- Cache de miniaturas movido para `filesDir`, com migração de miniaturas válidas do cache CODE 14 e limite LRU de 128 MiB.
- URL de miniatura expirada é renovada uma vez.
- Removido o fallback que baixava o arquivo original (inclusive vídeo inteiro) apenas para renderizar cartão da galeria. A URL original continua sendo resolvida no fluxo explícito de seleção.
- Pesquisa manual, fontes pCloud e histórico por chave estável permanecem preservados.

## Whisper

- `ggml-small.bin`, detecção de idioma e fluxo de segmentação/cache permaneceram inalterados. A auditoria não encontrou evidência que justificasse trocar modelo ou parâmetros.

## Transições

- Prévia alinhada aos deslocamentos usados no exportador para Slide, Push, Rise e Parallax.
- Exportador valida lista completa e IDs de transição antes de iniciar renderização.
- Projeto legado com lista inteiramente vazia mantém Fade de fábrica; lista parcial ou ID desconhecido gera erro de exportação tratado, em vez de substituir transições silenciosamente por Fade.
- A chave de exportação agora inclui as atribuições de transição.
- Acrescentados testes de compatibilidade, lista parcial e ID desconhecido.

## Progresso e previsão de exportação

- Percentual fica limitado a 99% até o callback confirmar que o arquivo foi salvo.
- `UsageStatsStore` conserva localmente até vinte amostras individuais de exportações concluídas, com duração, tempo de processamento, resolução, FPS, quantidade de mídias e uso de partículas.
- ETA só é exibida após pelo menos cinco amostras válidas. A previsão compara projetos semelhantes e se ajusta à duração, resolução, FPS, quantidade de mídias e partículas.
- O tempo restante não chega a zero antes da confirmação de salvamento.
- As estatísticas antigas eram agregadas por mês e não continham tempos individuais recuperáveis; portanto, as amostras para ETA começam a ser acumuladas após a instalação do CODE 15. O restante do histórico estatístico é preservado.
- Acrescentados testes unitários para mínimo de amostras, cálculo e limite mínimo de ETA.

## Validação realizada

- Validador estático `scripts/validate_v1_0_5_code15.py` passou.
- Teste Kotlin isolado de fumaça do estimador de ETA passou.
- Sintaxe YAML e sintaxe shell dos scripts do Codemagic verificadas.
- Bloco de assinatura comparado byte a byte com o YAML original; keystore embutido validado com `keytool`.
- Integridade do ZIP e execução do validador dentro do pacote verificadas.

## Limitação do ambiente desta edição

Este ambiente não tem Gradle nem Android SDK instalados e o pacote original não contém Gradle Wrapper. Por isso, não foi possível executar o build Android completo nem os testes instrumentados/local unitários pelo Gradle neste ambiente. O Codemagic permanece configurado para instalar Gradle 8.13 e executar o fluxo de build/validação.
