# Sonus Edit 1.0.1 — CODE 11

## Entrega
- Projeto Android completo em `SonusEdit.zip` (pasta `SonusEdit/` na raiz).
- Workflow separado em `codemagic.yaml`, idêntico ao arquivo dentro do projeto.

## Alterações
1. Atualização para `versionName=1.0.1` e `versionCode=11`; applicationId e workflow ID preservados.
2. Catálogo de fontes passa de 11 para 16 opções (15 customizadas + Sans-serif). Das 16 fontes novas recebidas, somente cinco foram incorporadas: Bainsley Bold Italic, Fundamental Brigade, Torid Bold, Montepetrum Thin e Andika Basic. As outras foram excluídas por licença de redistribuição não comprovada/restritiva ou glifo português essencial ausente.
3. Mantidas oito opções visíveis por abertura; o rodízio usa o catálogo aprovado e a Fonte dinâmica escolhe entre as 16 opções.
4. Histórico de imagens separado: 20 projetos 9:16 e 15 projetos 16:9. Apenas o histórico da proporção selecionada é consultado. O registro continua ocorrendo somente após exportação salva com sucesso.
5. Nova preferência “Bloquear imagens recentes”, ativada por padrão. Históricos antigos mistos não são migrados, para não atribuir projetos antigos ao formato incorreto.
6. Controle mestre Automação Total removido; opções individuais permanecem independentes e têm defaults ativos.
7. Ajustes reorganizados por grupos; painel de estatísticas recebeu cartões e contornos de identidade Sonus; tela inicial recebeu logo transparente, cartões destacados, botões em degradê, coroa dourada com halo e estrelas animadas.
8. “Sobre o Edit” atualizado com as novidades do CODE 11.

## Fontes e caracteres
Os cinco arquivos adicionados foram lidos com FontTools. Todos contêm os glifos de letras portuguesas testados (acentos agudos, circunflexos, til, crase, cedilha e Ü em caixa alta/baixa). Os arquivos foram incorporados sem modificação. Licenças e atribuições estão em `FONT_LICENSES_CODE11.md`. A confirmação visual final de alinhamento dos acentos deve ocorrer em dispositivo Android.

## Verificações executadas neste ambiente
- Validador estático `scripts/validate_v1_0_1_code11.py`: passou.
- YAML Codemagic: parseado com PyYAML; workflow ID fixo confirmado.
- Blocos shell do workflow: passaram em `bash -n`.
- Integridade e estrutura do ZIP: verificadas após empacotamento.
- Comparação do YAML externo com o interno: idênticos.
- Ausência de keystore e de credenciais privadas no pacote: verificada.

## Não executado
Este ambiente não possui Gradle nem Android SDK; portanto não foi possível executar compilação Android, JUnit ou gerar APK. O workflow remoto executará compilação Kotlin e testes. A keystore de assinatura persistente deve ser cadastrada no Codemagic como secrets, conforme `CODE11_CODEMAGIC_SECRETS.md`.
