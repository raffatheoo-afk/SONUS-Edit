# CODE 11 — Build fix 2

## Erro identificado

O build remoto compilou Kotlin com sucesso e executou o JUnit: 75 testes foram executados, com uma falha em `Code03CaptionLanguageHintTest > professional defaults stay classic and neutral`.

## Causa raiz

O teste ainda exigia `AutomationSettings().automaticFilter == false`, uma regra histórica do CODE 06. No CODE 11, o usuário aprovou explicitamente remover o controle mestre “Automação Total” e deixar as opções individuais ativadas por padrão. A implementação já estava correta: `AutomationSettings.automaticFilter` usa `true` e o fallback do DataStore usa `prefs[Keys.Filter] ?: true`; valores explicitamente salvos continuam respeitados. O teste antigo não havia sido atualizado para o novo contrato.

## Correção

- Separado o teste do estilo de legenda clássico do teste dos defaults de automação.
- Adicionado teste que verifica como ativos por padrão: Smart Start, priorizar refrão, legendas, efeitos, imagens, filtros, bloqueio de imagens recentes e metadados.
- Nenhum código de produção foi alterado para fazer o teste passar.
- A expectativa antiga `automaticFilter == false` foi substituída porque contradizia o requisito CODE 11 aprovado, não para ocultar falha.

## Validação

- `scripts/validate_v1_0_1_code11.py`: passou após a alteração.
- O log remoto fornecido comprova `:app:compileDebugKotlin` concluído e 75 testes executados, com 1 falha antes desta correção.
- O ambiente de edição não possui Gradle nem Android SDK; o JUnit atualizado ainda precisa ser executado novamente no Codemagic.
