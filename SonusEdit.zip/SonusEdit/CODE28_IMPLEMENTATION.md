# SONUS Edit 1.4 / code28 — Estabilidade

Base oficial: 1.3 / code27, preservando package `com.sonusstudios.sonusedit`, a assinatura histórica, Gallery, Premium demonstrativo, efeitos de pCloud/RAW, filtros e Media3 1.10.1.

## 1 — Link/yt-dlp (prioridade)
- O importador consulta o canal STABLE do yt-dlp na primeira importação e novamente após 24 horas, em Dispatchers.IO; atualiza o EXTRATOR, não o Python/FFmpeg/QuickJS nativos.
- Copia o binário anterior antes da atualização. Valida o novo binário rodando `--version` e `--list-extractors` no Python instalado. Se ocorrer incompatibilidade ou falha, restaura o binário e o registro da versão anterior, e continua com o importador conhecido.
- Erros de extração deixam de ficar escondidos em tentativas silenciosas; mensagens de erro comuns são identificadas e outras preservadas para diagnóstico (login exigido, HTTP 403, formato ausente, Python incompatível).
- Não se pode garantir que novos bloqueios do YouTube, autenticação, proteção de conteúdo ou compatibilidade do runtime sejam corrigidos sem testar links reais nos aparelhos.

## 2 — Exportação (prioridade)
- Media3 e padrões de saída H.264/AAC continuam 1.10.1, sem reduzir FPS/resolução automaticamente.
- Watchdog bounded de 30 s para acomodar início lento de codificador, sem desativar detecção de stalls.
- Falhas caracterizadas como Muxer/MediaCodec/ausência de amostras na exportação curta disparam uma segunda via: segmentos de 12 s e concatenação MP4 usando a infraestrutura da exportação longa. Cada segmento tolera um retry isolado; se falhar novamente, o erro é mostrado.
- O sistema de chunking passou a respeitar as durações explícitas das fotos, preservando o tempo exato selecionado manualmente, os fades nos limites da composição, recortes e legendas.
- Logcat inclui fabricante, modelo, versão Android, resolução, FPS, duração e efeito (não inclui links privados).
- Exportação segmentada e concatenação precisam de testes reais em codecs do Galaxy A15 e S10+ antes de afirmar cura completa.

## 3 — Idioma do Whisper Small
- Cache do motor versionado para 14, impedindo reaproveitar trechos inconsistentes processados pela configuração anterior.
- O primeiro trecho cantado informa uma pista de idioma pela própria transcrição, antes de considerar título e locale. Passagem forçada e confirmação mantidas para `en`/`pt` quando existe evidência. Sem evidência suficiente, continua testando os próximos trechos em vez de armazenar `auto` como idioma definitivo. Chunks não confirmados não são persistidos como definitivos.
- É uma redução de deriva PT/EN, não garantia de transcrição perfeita de canto.

## 4 — Cronômetro de legendas
- Referências atualizadas para 30 segundos ≈ 3:02 e 60 segundos ≈ 3:04, em vez de regra linear anterior.
- Cada aparelho salva a média móvel de transcrições concluídas, separada por intervalo de duração. O ETA combina histórico local, referência inicial e ritmo real dos blocos do Whisper. Se expirar, mostra `--:--` em vez de alegar conclusão.
- Download inicial do modelo permanece fora da estimativa.

## Preservação
- Manifest, keystore histórico, marca e assinatura, 9:16/16:9, 30/60 FPS, partículas locais sem alteração binária, Gallery/cache/ícones, Premium sem cobrança, Whisper Small e pCloud mantidos.

## Verificações realizadas
- Guardas estáticas do Codemagic: PASSOU, incluindo checks da assinatura e SHA-256 dos dois vídeos RAW.
- `scripts/validate_v1_4_code28.py`: PASSOU.
- Checks Kotlin/JVM isolados: PASSOU para heurística de idioma, regra de retry e novas estimativas.
- ZIP final reaberto e extraído: verificação planejada na embalagem final; registrada no manifesto de hashes gerado.

## LIMITE DE VALIDAÇÃO
**Não há Android SDK/Gradle Android completo neste ambiente. Não houve compilação do APK nem testes reais em Galaxy A15 / Galaxy S10+ / Galaxy S10e.** A confirmação do compilador Kotlin/Android, do yt-dlp atualizado na rede e da exportação acelerada exige execução do Codemagic e testes em aparelhos. Não declarar o bug resolvido antes dessas verificações.

## Testes prioritários no aparelho
1. Abrir Link e importar ao menos dois links públicos permitidos. Confirmar progresso de atualização, sem alerta de motor antigo, e validar áudio e metadados. Simular rede indisponível e garantir fallback.
2. Exportar 30s em 720p30 e 1080p30, com e sem partículas, no S10e, S10+ e A15. Repetir 1080p60 e 16:9.
3. Forçar export com stall reproduzível e verificar que retry segmentado salva o vídeo com duração correta, ou informa erro sem mascará-lo.
4. Comparar uma canção cantada em inglês e outra em português, e validar idioma sem mistura grosseira.
5. Cronômetro de 30s e 60s durante Gallery → Estilo, depois comparar estimativas da segunda transcrição no mesmo celular.
6. Conferir mesmo signer histórico e instalação por atualização sobre 1.3, sem desinstalar a aplicação.
