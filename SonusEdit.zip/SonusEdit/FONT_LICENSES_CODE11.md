# Fontes adicionadas — CODE 11

Foram incluídas somente cinco fontes do pacote enviado. As demais foram deixadas de fora por ausência de licença de redistribuição comprovada, restrição de uso ou falta de glifos portugueses. Os arquivos abaixo são distribuídos sem modificação.

- **Bainsley Bold Italic** — Paul James Miller. SIL Open Font License 1.1 (OFL). https://scripts.sil.org/OFL
- **Fundamental Brigade** — Peter Wiegel. Metadados do arquivo indicam GPL com exceção para fontes e OFL. https://scripts.sil.org/OFL
- **Torid Bold** — Ruben Holthuijsen. Creative Commons Attribution-ShareAlike 3.0 Unported (CC BY-SA 3.0). https://creativecommons.org/licenses/by-sa/3.0/
- **Montepetrum Thin** — Johan Aakerlund. Creative Commons Attribution-NoDerivatives 3.0 Unported (CC BY-ND 3.0). O arquivo é incorporado sem modificação. https://creativecommons.org/licenses/by-nd/3.0/
- **Andika Basic** — SIL International. SIL Open Font License 1.1 (OFL). https://scripts.sil.org/OFL

Verificação técnica de cmap: todas as cinco fontes cobrem as letras latinas básicas e os caracteres portugueses testados (Á É Í Ó Ú, Â Ê Ô, Ã Õ, À, Ç, Ü e respectivas minúsculas). A validação não substitui teste visual em dispositivo; o alinhamento final de acentos deve ser confirmado no Android após instalação.

As fontes foram mantidas byte a byte iguais às fornecidas. Este arquivo registra a identificação de licença presente nos metadados internos dos arquivos; consulte os textos e links de licença dos respectivos titulares para as condições completas.
