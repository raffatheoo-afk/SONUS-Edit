# SONUS Edit 0.0.16 / code16

Base: code15 hotfix lineage. This version implements the checklist approved by Rafa on 05/10/2026.

## 1. Smart image variation
- Replaced deterministic automatic selection with `SmartImageSelector`.
- Semantic score uses title, artist, album, genre and common lyric keywords.
- Weighted sampling without replacement preserves relevance but varies combinations.
- `ImageSelectionHistoryStore` penalizes recently used images per track/link/local source.
- Image URL resolution is parallelized and `stableKey` prevents duplicates.

## 2. Music source: Link
- Home adds **Criar com link**.
- Music source selector is now Stream / Local / Link.
- `LinkAudioImporter` isolates provider resolution from the editing pipeline.
- Current resolver uses `youtubedl-android` 0.18.1 / yt-dlp and prepares media inside the app cache.
- YouTube, TikTok and other providers supported by the resolver use the exact same downstream editor after import.
- yt-dlp compatibility is refreshed at most once every 24 hours when Link is used; failure to refresh falls back to the bundled engine.
- Download progress is real when available; non-measurable stages are indeterminate.
- Temporary imported media is removed after successful export, on source replacement, or later by stale-cache cleanup.

## 3. Unified progress UI
- Added `ProcessProgressOverlay`.
- SONUS synchronization is now centered and indeterminate until the real task finishes.
- Link import exposes stages and real download percentage.
- Export uses the same centered circular progress pattern with cancel/background actions.
- No fabricated percentage is shown for non-measurable stages.

## 4. Natural filter replacements
The seven filters that were not approved in the screenshot keep their stable enum IDs for preference compatibility but now expose new labels/processing:
- SUNSET -> HDR Natural
- NIGHT_CITY -> Preto Profundo
- NATURAL_PLUS -> Vívido Natural
- SOFT_LIGHT -> HDR Suave
- WARM_NATURAL -> Luzes Vivas
- COOL_NATURAL -> Sombras Limpas
- GOLDEN -> Nitidez+

Implementation:
- `NaturalFilterEffect` performs GPU sharpening, contrast, saturation, brightness and black-point adjustment.
- No translucent wash/veil overlay is used for these replacements.
- Filter thumbnails use tonal/color processing instead of tinted layers and reuse a single loaded preview bitmap.
- Existing approved/favorited filters keep their established behavior.

## 5. Entry-flow optimization
- Cached/fresh music and image catalogs are loaded in parallel.
- A short process-session freshness cache prevents Home -> Create from immediately repeating the same pCloud refresh.
- Resolved music download URL is reused for metadata instead of being requested twice.
- Image semantic ranking runs on `Dispatchers.Default` instead of the UI thread.
- Remote image URLs are resolved concurrently.
- Home/Create navigation uses `launchSingleTop` and visible preparation feedback when a suggested track still needs work.

## 6. FPS simplification
- UI/settings expose only 30 and 60 FPS.
- Transformer validates only 30/60 FPS.
- Persisted legacy values (including 90 FPS) are normalized to 60 FPS both in preferences and again at export-service boundary.
- Particle sources remain native 60 FPS (green) / 30 FPS (black); no interpolation was added.
- Resolutions remain 720p / 1080p / 2K / 4K.

## 7. Preserved engine behavior
- Raw MP4 particle engine remains intact; no atlas/sprite regression.
- 9:16 overlay behavior remains intact.
- Media3 remains 1.10.1 from the code15 hotfix.
- Internal raw assets continue to be materialized to cache before Transformer.
- Foreground export, background execution, open/share/conclude flow, LRC, Sonus Gallery, signatures, fonts/colors and Smart Start remain present.
- Workflow id remains `sonus-edit-0-0-3-code03-debug` and persistent signer behavior remains fail-safe.

## Validation state
- Source/codemagic static guards passed locally.
- Full Android Gradle compilation cannot be executed in this workspace because an Android SDK/Gradle runtime is not installed here.
- Codemagic remains the authoritative compile/unit-test/APK gate and must pass before device installation.

## Priority device tests after Codemagic
1. Install code16 over code15 and confirm signer continuity.
2. Open suggested Stream song: verify immediate navigation and preparation overlay only while needed.
3. Reopen the same song 3-5 times: verify varied but relevant image combinations.
4. Test Link with one YouTube URL and one TikTok URL; verify cancel and temporary-cache behavior.
5. Verify 15s / 1080p60 exports with green and black particle effects.
6. Verify 30 FPS and 60 FPS; no 90 FPS option anywhere.
7. Verify 2K60 and 4K60 save successfully.
8. Compare every replaced filter against Original; confirm no washed veil and validate HDR/black/sharpness behavior.
9. Confirm centered synchronization and export progress UI.
10. Confirm save/open/share/conclude flow and 9:16 output.
