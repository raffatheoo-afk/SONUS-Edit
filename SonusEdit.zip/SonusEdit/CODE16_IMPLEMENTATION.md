# SONUS EDIT 1.0.6 — CODE 16

## Base
- Base efetivamente usada: pacote fornecido nesta conversa, identificado como Sonus Edit 1.0.5 / CODE 15.
- `applicationId` preservado: `com.sonusstudios.sonusedit`.
- `versionName=1.0.6`; `versionCode=16`.
- Assinatura persistente e workflow Codemagic preservados.

## Correções

### Indicador percentual de legendas automáticas
- `AutoCaptionsScreen` agora calcula `captionProgressPercent` com `CaptionProgressEstimator13`, da mesma forma que a criação normal.
- Usa percentual informado pelo Whisper, áudio processado e interpolação temporal limitada a 98%; 100% só aparece quando o motor confirma conclusão.
- O valor é enviado ao sexto parâmetro de `CaptionStatusPill20`, corrigindo o `--%` permanente.
- Whisper Small, segmentação, idioma, cache e geração das legendas não foram modificados.

### Exportação de vídeos com legendas automáticas
- `fitFullFrame` é exclusivo do fluxo de legendas automáticas nesta base.
- O caminho anterior aplicava `Presentation` e `LanczosResample` em cada clipe e voltava a aplicar `Presentation` na composição final.
- O CODE 16 elimina o redimensionamento/efeitos por clipe nesse modo; mantém o vídeo de origem no quadro completo e usa o `Presentation.createForWidthAndHeight` da composição para aplicar a dimensão final uma única vez.
- O overlay das legendas continua na composição e o áudio original continua sendo incluído pela sequência de áudio existente.
- Demais projetos seguem usando o pipeline e o redimensionamento por clipe sem alteração.
- O log técnico de erro agora registra `fitFullFrame`, quantidade de legendas e dimensão final para facilitar diagnóstico de aparelho, sem expor esses dados ao usuário.

### Interface de exportação
- Removida a mensagem interna de calibração `0/5` da tela de exportação.
- A contagem local de amostras, a calibração e a previsão de ETA permanecem ativas; quando houver ETA disponível, ela continua sendo exibida.

## Preservações
- Galeria pCloud e cache: sem alterações.
- Importação de música local/link/Stream: sem alterações.
- Whisper Small e `WhisperCaptionEngine`: sem alterações.
- Transições e filtros: sem alterações.
- `applicationId`, `namespace`, dependências, workflow e chave de assinatura persistente: preservados.

## Validação
- Validador `scripts/validate_v1_0_6_code16.py`.
- Teste isolado adicionado para o percentual calculado com progresso de áudio.
- Sintaxe do YAML e shell do Codemagic.
- Hash SHA-256 do bloco `Restore persistent Sonus Edit signing` comparado com a base original.
- Limitação: este ambiente não possui Gradle/Android SDK; o build completo e os testes Gradle permanecem como etapa obrigatória no Codemagic.
