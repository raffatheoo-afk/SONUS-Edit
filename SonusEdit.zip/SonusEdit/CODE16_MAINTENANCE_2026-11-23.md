# SONUS EDIT 1.0.6 / CODE 16 — manutenção (23/11/2026)

## Identidade preservada
- `versionName=1.0.6`
- `versionCode=16`
- `applicationId=com.sonusstudios.sonusedit`
- Sem alteração da chave, bloco de assinatura persistente ou workflow Codemagic.

## Correções desta manutenção
- Rascunhos agora usam `AtomicFile` e sincronização de escrita; uma interrupção durante o salvamento não substitui o último rascunho íntegro por um arquivo parcial.
- O botão Rascunho atualiza sua disponibilidade quando a tela inicial volta ao primeiro plano.
- Ao restaurar um rascunho, o início inteligente não sobrescreve o trecho salvo; a prévia do ExoPlayer também reposiciona no início salvo assim que a nova mídia fica pronta. A escolha de uma nova fonte de áudio libera novamente o início inteligente.
- O serviço promove-se a foreground antes de decodificar/processar o conteúdo serializado da exportação.
- Preparação de efeitos e composição acontece fora da thread principal; o Transformer é criado/iniciado no looper principal. A operação possui tratamento de falhas e invalidação do trabalho pendente ao cancelar; erros são encaminhados à tela de exportação. Erros de memória, muxer sem amostras e falhas de codec podem seguir a escada de exportação mais leve (FPS/resolução menores).
- Atualizações auxiliares de estatísticas e limpeza de rascunho são protegidas para que falhas nesses registros não encerrem o processo do aplicativo.
- O tempo máximo sem amostras iniciais do muxer foi elevado de 30 para 90 segundos para evitar abortar dispositivos que demoram mais para montar o primeiro quadro composto.
- A tela Sobre descreve as correções mantendo 1.0.6 / CODE 16.

## Validação
- Verificação estática dos pontos alterados, referências a versões/identidade e sintaxe XML/YAML; testes unitários de regressão adicionados para o recorte restaurado e a recuperação de muxer.
- A compilação Android completa e os testes Gradle precisam ser executados pelo workflow Codemagic: este ambiente não possui Android SDK nem Gradle wrapper.
