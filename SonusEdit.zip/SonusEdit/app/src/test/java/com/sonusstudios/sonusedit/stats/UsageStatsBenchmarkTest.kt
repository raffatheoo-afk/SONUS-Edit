package com.sonusstudios.sonusedit.stats

import org.junit.Assert.assertEquals
import org.junit.Test

class UsageStatsBenchmarkTest {
    @Test
    fun `manual benchmark matches Rafa 30 second test`() {
        assertEquals(264_000L, UsageStatsStore.estimateManualEditingMs(30_000L))
        assertEquals(132_000L, UsageStatsStore.estimateManualEditingMs(15_000L))
        assertEquals(528_000L, UsageStatsStore.estimateManualEditingMs(60_000L))
    }
}
