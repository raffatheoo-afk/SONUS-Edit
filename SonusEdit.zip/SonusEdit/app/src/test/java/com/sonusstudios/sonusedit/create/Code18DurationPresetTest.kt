package com.sonusstudios.sonusedit.create

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class Code18DurationPresetTest {
    @Test
    fun `visible durations end in infinity and exclude old 90 and 120`() {
        assertEquals(listOf("15s", "30s", "40s", "50s", "60s", "65s", "∞"), DurationPreset.all.map { it.label })
        assertFalse(DurationPreset.all.any { it.seconds == 90 || it.seconds == 120 })
        assertTrue(DurationPreset.all.last().untilEnd)
    }

    @Test
    fun `infinity uses exact remaining track duration`() {
        val infinity = DurationPreset.all.last()
        assertEquals(172_500L, infinity.durationMs(trackDurationMs = 212_500L, startMs = 40_000L))
    }
}
