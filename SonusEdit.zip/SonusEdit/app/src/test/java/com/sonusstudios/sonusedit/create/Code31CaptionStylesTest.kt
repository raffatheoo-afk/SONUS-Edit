package com.sonusstudios.sonusedit.create

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class Code31CaptionStylesTest {
    @Test fun twentyLooksAndThreePositionsExist() {
        assertEquals(20, CaptionStyleId.entries.size)
        assertEquals(3, CaptionPosition.entries.size)
    }

    @Test fun wordTimingCoversTheWholePhraseInOrder() {
        val words = CaptionWordTimer.split("Olá mundo, tudo bem?", 1_000L, 5_000L)
        assertEquals(4, words.size)
        assertEquals(1_000L, words.first().startMs)
        assertEquals(5_000L, words.last().endMs)
        words.zipWithNext().forEach { (a, b) ->
            assertTrue(a.startMs < b.startMs)
            assertTrue(a.endMs <= b.startMs + 1L)
        }
    }

    @Test fun veryShortPhraseStillGivesEveryWordTime() {
        val words = CaptionWordTimer.split("um dois três", 0L, 100L)
        assertEquals(3, words.size)
        assertEquals(100L, words.last().endMs)
        assertTrue(words.all { it.startMs >= 0L && it.endMs <= 100L && it.endMs > it.startMs })
    }

    @Test fun everyPremiumLookIsIllustrativeAndThereAreTen() {
        assertEquals(10, CaptionStyleId.entries.count { it.premiumIllustrative })
        assertEquals(10, CaptionStyleId.entries.count { !it.premiumIllustrative })
    }

    @Test fun ultraShortPhraseNeverEscapesItsTimestampWindow() {
        val words = CaptionWordTimer.split("um dois três quatro cinco seis", 500L, 502L)
        assertEquals(1, words.size)
        assertEquals("um dois três quatro cinco seis", words.single().text)
        assertEquals(500L, words.single().startMs)
        assertEquals(502L, words.single().endMs)
    }

    @Test fun blankTextHasNoWords() {
        assertTrue(CaptionWordTimer.split("   ", 0L, 1_000L).isEmpty())
    }

    @Test fun refreshNeverReturnsTheSameLook() {
        repeat(40) {
            CaptionStyleId.entries.forEach { assertNotEquals(it, CaptionStyleSelector.refresh(it)) }
        }
    }

    @Test fun speechRateIsWordsPerSecondOfSpeech() {
        val rate = CaptionStyleSelector.wordsPerSecond(
            listOf(CaptionSegment(startMs = 0L, endMs = 4_000L, text = "um dois três quatro cinco seis sete oito")),
        )
        assertNotNull(rate)
        assertEquals(2.0, rate!!, 0.01)
    }

    @Test fun tooLittleSpeechGivesNoRate() {
        assertNull(CaptionStyleSelector.wordsPerSecond(listOf(CaptionSegment(startMs = 0L, endMs = 1_000L, text = "oi"))))
        assertNull(CaptionStyleSelector.wordsPerSecond(emptyList()))
    }
}
