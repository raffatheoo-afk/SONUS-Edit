package com.sonusstudios.sonusedit.create

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GalleryQueryResultGate13Test {
    @Test fun onlyCurrentQueryAndAspectMayPublish() {
        assertTrue(GalleryQueryResultGate13.canPublish("cidade", "cidade", "9:16", "9:16"))
        assertTrue(GalleryQueryResultGate13.canPublish(" cidade ", "cidade", "16:9", "16:9"))
        assertFalse(GalleryQueryResultGate13.canPublish("cidade", "noite", "9:16", "9:16"))
        assertFalse(GalleryQueryResultGate13.canPublish("cidade", "cidade", "9:16", "16:9"))
    }
}
