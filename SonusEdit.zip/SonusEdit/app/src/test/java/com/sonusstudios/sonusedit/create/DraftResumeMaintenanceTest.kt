package com.sonusstudios.sonusedit.create

import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DraftResumeMaintenanceTest {
    @Test fun restoredDraftNeverRunsSmartStartAgain() {
        assertFalse(SegmentTrimPlanner12.shouldApplySmartStart(enabled = true, trimIsProtected = true))
    }

    @Test fun newProjectStillAllowsSmartStartWhenEnabled() {
        assertTrue(SegmentTrimPlanner12.shouldApplySmartStart(enabled = true, trimIsProtected = false))
        assertFalse(SegmentTrimPlanner12.shouldApplySmartStart(enabled = false, trimIsProtected = false))
        assertFalse(SegmentTrimPlanner12.shouldApplySmartStart(enabled = true, trimIsProtected = true))
    }

    @Test fun choosingANewSourceAfterResumeAllowsSmartStartAgain() {
        // Restoring a draft sets trimIsProtected=true; selecting another audio source resets it.
        assertFalse(SegmentTrimPlanner12.shouldApplySmartStart(enabled = true, trimIsProtected = true))
        assertTrue(SegmentTrimPlanner12.shouldApplySmartStart(enabled = true, trimIsProtected = false))
    }

    @Test fun restoredTrimPositionIsClampedToValidAudioBounds() {
        assertEquals(60_000L, SegmentTrimPlanner12.initialPlaybackPosition(180_000L, 60_000L))
        assertEquals(179_000L, SegmentTrimPlanner12.initialPlaybackPosition(180_000L, 300_000L))
        assertEquals(0L, SegmentTrimPlanner12.initialPlaybackPosition(0L, 60_000L))
    }

    @Test fun customTrimIsPreservedByDraftSerialization() {
        val original = CreationDraftSnapshot(
            audioUri = "content://audio/track",
            durationSeconds = 30,
            segmentStartMs = 60_000L,
            manualEndMs = 100_000L,
            captionSegments = listOf(CaptionSegment(61_000L, 63_000L, "Trecho selecionado")),
            captionCompleted = true,
        )
        val decoded = Json { ignoreUnknownKeys = true }.decodeFromString<CreationDraftSnapshot>(
            Json.encodeToString(original)
        )
        assertEquals(60_000L, decoded.segmentStartMs)
        assertEquals(100_000L, decoded.manualEndMs)
        assertEquals(60_000L, SegmentTrimPlanner12.initialPlaybackPosition(180_000L, decoded.segmentStartMs))
        assertEquals(40_000L, SegmentTrimPlanner12.endMs(
            totalMs = 180_000L,
            startMs = decoded.segmentStartMs,
            presetSeconds = decoded.durationSeconds,
            untilEnd = decoded.durationUntilEnd,
            manualEndMs = decoded.manualEndMs,
        ) - decoded.segmentStartMs)
        assertEquals("Trecho selecionado", decoded.captionSegments.single().text)
    }
}
