package com.sonusstudios.sonusedit.catalog

import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class StreamSuggestionEngineTest {
    @Test
    fun `never immediately repeats recent suggestion while fresh tracks exist`() {
        val first = PCloudAsset(1, "One.mp3", folderPath = "SONUS MUSIC/Internacional", sourcePublicCode = "A")
        val second = PCloudAsset(2, "Two.mp3", folderPath = "SONUS MUSIC/Internacional", sourcePublicCode = "A")
        val third = PCloudAsset(3, "Three.mp3", folderPath = "SONUS MUSIC/Católica", sourcePublicCode = "B")
        val history = listOf(StreamHistoryStore.Entry(first.stableKey, first.genre))

        repeat(40) {
            val suggestion = StreamSuggestionEngine.suggest(listOf(first, second, third), history)
            assertNotEquals(first.stableKey, suggestion?.stableKey)
            assertTrue(suggestion?.stableKey in setOf(second.stableKey, third.stableKey))
        }
    }
}
