package com.sonusstudios.sonusedit.create

import com.sonusstudios.sonusedit.catalog.PCloudAsset
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class Code22GallerySearchTest {
    private val assets = listOf(
        PCloudAsset(1, "Nossa_Senhora_da_Aparecida_hora_01.png", folderPath = "Sonus Gallery 16:9"),
        PCloudAsset(2, "Bar-de-Bairro 01.jpg", folderPath = "Sonus Gallery 16:9"),
        PCloudAsset(3, "BAR_DE_BAIRRO_FINAL_02.webp", folderPath = "Sonus Gallery 9:16"),
        PCloudAsset(4, "paisagem_neutra.jpg", folderPath = "Sonus Gallery 16:9"),
    )

    @Test
    fun `search normalizes underscores dashes accents and connector words`() {
        val result = SmartImageSelector.searchManualGallery(assets, "nossa senhora Aparecida")
        assertEquals(listOf(1L), result.map { it.fileId })
    }

    @Test
    fun `search by song title finds keyword files independent of case and separators`() {
        val result = SmartImageSelector.searchManualGallery(assets, "bar de bairro")
        assertEquals(setOf(2L, 3L), result.map { it.fileId }.toSet())
        assertTrue(result.none { it.fileId == 4L })
    }

    @Test
    fun `all meaningful words are required for precise search`() {
        val result = SmartImageSelector.searchManualGallery(assets, "bar bairro aparecida")
        assertTrue(result.isEmpty())
    }
    @Test
    fun `exact song title can override category conflict without opening unrelated conflicts`() {
        val match = ArtistGenreResolver.Match(
            artist = "Artista Forró",
            category = "forro",
            imageKeyword = "forro",
            positiveKeywords = setOf("forro", "piseiro", "vaquejada"),
            blockedCategoryKeywords = setOf("catolico", "nossa senhora", "maria", "gospel"),
            confidence = "high",
            source = ArtistGenreResolver.Match.Source.ARTIST,
        )
        val catalog = listOf(
            PCloudAsset(10, "Nossa_Senhora_da_Aparecida_01.png", folderPath = "Sonus Gallery 16:9"),
            PCloudAsset(11, "Nossa_Senhora_das_Gracas_01.png", folderPath = "Sonus Gallery 16:9"),
            PCloudAsset(12, "vaquejada_forro_01.png", folderPath = "Sonus Gallery 16:9"),
        )
        val ranked = SmartImageSelector.rank(
            catalog,
            AudioMetadata("Nossa Senhora Aparecida", "Artista Forró", 180_000L, genre = "Forró"),
            "",
            match,
        )

        assertEquals(10L, ranked.first().fileId)
        assertTrue(ranked.none { it.fileId == 11L })
    }

}
