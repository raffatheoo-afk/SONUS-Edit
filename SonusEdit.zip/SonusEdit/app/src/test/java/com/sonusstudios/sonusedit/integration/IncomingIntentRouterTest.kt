package com.sonusstudios.sonusedit.integration

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class IncomingIntentRouterTest {
    @Test
    fun extractsSharedUrlAndTrimsTrailingPunctuation() {
        assertEquals(
            "https://youtu.be/abc123?si=share",
            IncomingIntentRouter.extractSharedHttpUrl("Confira este vídeo: https://youtu.be/abc123?si=share."),
        )
    }

    @Test
    fun ignoresTextWithoutAnHttpUrl() {
        assertNull(IncomingIntentRouter.extractSharedHttpUrl("Somente um texto, sem endereço."))
    }

    @Test
    fun rejectsNonHttpSchemesAndUrlsWithEmbeddedCredentials() {
        assertNull(IncomingIntentRouter.extractSharedHttpUrl("javascript:alert(1)"))
        assertNull(IncomingIntentRouter.extractSharedHttpUrl("https://user:pass@example.com/video.mp4"))
    }
}
