package com.sonusstudios.sonusedit.catalog

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PCloudSearchCachePolicyTest {
    private val imageExtensions = setOf("jpg", "jpeg", "png", "webp")

    @Test
    fun `320 matching catalogue items with 50 blocked still provide enough fresh results`() {
        val assets = (1..320).map { id ->
            PCloudAsset(id.toLong(), "romantico ${id.toString().padStart(3, '0')}.jpg", folderPath = "romantico", sourcePublicCode = "gallery")
        }
        val blocked = (1..50).map { "gallery:$it" }.toSet()

        assertTrue(PCloudSearchCachePolicy.hasEnoughFreshMatches(assets, "romântico", imageExtensions, blocked))
    }

    @Test
    fun `ten fresh results do not stop progressive search`() {
        val assets = (1..320).map { id ->
            PCloudAsset(id.toLong(), "romantico ${id.toString().padStart(3, '0')}.jpg", folderPath = "romantico", sourcePublicCode = "gallery")
        }
        val blocked = (1..310).map { "gallery:$it" }.toSet()

        assertFalse(PCloudSearchCachePolicy.hasEnoughFreshMatches(assets, "romântico", imageExtensions, blocked))
    }

    @Test
    fun `substring false positives do not count toward the cache threshold`() {
        val falseMatches = (1..20).map { id ->
            PCloudAsset(id.toLong(), "amores ${id.toString().padStart(2, '0')}.jpg", folderPath = "romantico", sourcePublicCode = "gallery")
        }
        val exactMatches = (21..30).map { id ->
            PCloudAsset(id.toLong(), "amor ${id.toString().padStart(2, '0')}.jpg", folderPath = "romantico", sourcePublicCode = "gallery")
        }

        assertFalse(PCloudSearchCachePolicy.hasEnoughFreshMatches(falseMatches + exactMatches, "amor", imageExtensions, emptySet()))
    }
}
