package com.sonusstudios.sonusedit.create

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class VisualTransitionCatalogTest {
    @Test
    fun `catalog has ten paired transition families`() {
        assertEquals(10, VisualTransitionCatalog.families.size)
        assertEquals(10, VisualTransitionCatalog.families.map { it.id }.distinct().size)
        assertTrue(VisualTransitionCatalog.families.all { it.entrance.endsWith("In") })
        assertTrue(VisualTransitionCatalog.families.all { it.exit.endsWith("Out") })
        assertEquals("fade", VisualTransitionCatalog.normalize(VisualTransitionSettings()).selectedIds.single())
    }

    @Test
    fun `single selection is applied to every visual`() {
        val result = VisualTransitionCatalog.resolveForProject(
            VisualTransitionSettings(VisualTransitionMode.SINGLE, listOf("zoom")),
            mediaCount = 20,
            seed = 1234L,
        )
        assertEquals(20, result.size)
        assertEquals(setOf("zoom"), result.toSet())
    }

    @Test
    fun `multiple selection never exceeds four families`() {
        val result = VisualTransitionCatalog.resolveForProject(
            VisualTransitionSettings(VisualTransitionMode.MULTIPLE, listOf("fade", "zoom", "blur", "slide", "light")),
            mediaCount = 20,
            seed = 5678L,
        )
        assertEquals(20, result.size)
        assertEquals(4, result.toSet().size)
        assertTrue(result.all { it in setOf("fade", "zoom", "blur", "slide") })
    }

    @Test
    fun `random mode selects four families once and keeps assignment deterministic for the project seed`() {
        val settings = VisualTransitionSettings(VisualTransitionMode.RANDOM, listOf("fade"))
        val first = VisualTransitionCatalog.resolveForProject(settings, mediaCount = 20, seed = 9988L)
        val second = VisualTransitionCatalog.resolveForProject(settings, mediaCount = 20, seed = 9988L)
        assertEquals(first, second)
        assertEquals(20, first.size)
        assertEquals(4, first.toSet().size)
        assertTrue(first.all { family -> VisualTransitionCatalog.families.any { it.id == family } })
    }
    @Test
    fun `project transition pool does not reroll when more media are appended`() {
        val settings = VisualTransitionSettings(VisualTransitionMode.RANDOM, listOf("fade"))
        val pool = VisualTransitionCatalog.resolvePoolForProject(settings, seed = 5150L)
        val firstBatch = VisualTransitionCatalog.appendAssignments(emptyList(), pool, mediaCount = 2, seed = 5150L)
        val expanded = VisualTransitionCatalog.appendAssignments(firstBatch, pool, mediaCount = 20, seed = 5150L)
        assertEquals(4, pool.size)
        assertEquals(firstBatch, expanded.take(2))
        assertEquals(pool.toSet(), expanded.toSet())
        assertEquals(20, expanded.size)
    }

}
