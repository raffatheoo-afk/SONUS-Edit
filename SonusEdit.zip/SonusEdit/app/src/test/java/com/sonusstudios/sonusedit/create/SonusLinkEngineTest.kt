package com.sonusstudios.sonusedit.create

import java.net.URI
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SonusLinkEngineTest {
    @Test
    fun youtubeShortLinkIsRecognizedAsPlatformPage() {
        val result = SonusLinkSourceClassifier.classify(URI("https://youtu.be/abc123"))
        assertTrue(result.isPlatformPage)
        assertTrue(result.label == "YouTube")
    }

    @Test
    fun youtubeMusicHostGetsItsOwnLabel() {
        val result = SonusLinkSourceClassifier.classify(URI("https://music.youtube.com/watch?v=abc123"))
        assertTrue(result.isPlatformPage)
        assertTrue(result.label == "YouTube Music")
    }

    @Test
    fun nestedTikTokHostIsRecognizedAsPlatformPage() {
        val result = SonusLinkSourceClassifier.classify(URI("https://www.tiktok.com/@creator/video/123"))
        assertTrue(result.isPlatformPage)
        assertTrue(result.label == "TikTok")
    }

    @Test
    fun additionalSocialAndMediaPlatformsAreRecognized() {
        val cases = listOf(
            "https://www.instagram.com/reel/abc123" to "Instagram",
            "https://www.facebook.com/watch/?v=123" to "Facebook",
            "https://fb.watch/abc123" to "Facebook",
            "https://soundcloud.com/artist/track" to "SoundCloud",
            "https://open.spotify.com/track/abc123" to "Spotify",
            "https://vimeo.com/123456" to "Vimeo",
            "https://x.com/user/status/123" to "X",
        )
        cases.forEach { (url, expectedLabel) ->
            val result = SonusLinkSourceClassifier.classify(URI(url))
            assertTrue(result.isPlatformPage)
            assertTrue(result.label == expectedLabel)
        }
    }

    @Test
    fun directAudioFileIsRecognizedWithoutPlatformScraping() {
        val result = SonusLinkSourceClassifier.classify(URI("https://cdn.example.org/audio/track.m4a?download=1"))
        assertFalse(result.isPlatformPage)
        assertTrue(result.looksLikeDirectMedia)
    }

    @Test
    fun directVideoFileIsRecognizedAsMedia() {
        val result = SonusLinkSourceClassifier.classify(URI("https://media.example.org/clip.mp4"))
        assertFalse(result.isPlatformPage)
        assertTrue(result.looksLikeDirectMedia)
    }

    @Test
    fun genericWebPageIsNotAssumedToBeMedia() {
        val result = SonusLinkSourceClassifier.classify(URI("https://example.org/watch?id=123"))
        assertFalse(result.isPlatformPage)
        assertFalse(result.looksLikeDirectMedia)
    }
}
