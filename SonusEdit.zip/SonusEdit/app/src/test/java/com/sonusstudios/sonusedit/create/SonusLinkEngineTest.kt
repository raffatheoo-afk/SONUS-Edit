package com.sonusstudios.sonusedit.create

import java.net.URI
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SonusLinkEngineTest {
    @Test
    fun youtubeShortLinkIsRecognizedAsPlatformPage() {
        val result = SonusLinkSourceClassifier.classify(URI("https://youtu.be/abc123"))
        assertTrue(result.isPlatformPage)
        assertTrue(result.label == "YouTube")
    }

    @Test
    fun youtubeMusicHostGetsItsOwnLabel() {
        val result = SonusLinkSourceClassifier.classify(URI("https://music.youtube.com/watch?v=abc123"))
        assertTrue(result.isPlatformPage)
        assertTrue(result.label == "YouTube Music")
    }

    @Test
    fun nestedTikTokHostIsRecognizedAsPlatformPage() {
        val result = SonusLinkSourceClassifier.classify(URI("https://www.tiktok.com/@creator/video/123"))
        assertTrue(result.isPlatformPage)
        assertTrue(result.label == "TikTok")
    }

    @Test
    fun additionalSocialAndMediaPlatformsAreRecognized() {
        val cases = listOf(
            "https://www.instagram.com/reel/abc123" to "Instagram",
            "https://www.facebook.com/watch/?v=123" to "Facebook",
            "https://fb.watch/abc123" to "Facebook",
            "https://soundcloud.com/artist/track" to "SoundCloud",
            "https://vimeo.com/123456" to "Vimeo",
            "https://x.com/user/status/123" to "X",
            "https://bsky.app/profile/example/post/123" to "Bluesky",
            "https://www.pinterest.com/pin/123" to "Pinterest",
            "https://www.bilibili.com/video/123" to "Bilibili",
            "https://rutube.ru/video/123" to "Rutube",
            "https://www.snapchat.com/spotlight/123" to "Snapchat",
            "https://example.tumblr.com/post/123" to "Tumblr",
            "https://vk.com/video-123" to "VK",
            "https://www.loom.com/share/123" to "Loom",
        )
        cases.forEach { (url, expectedLabel) ->
            val result = SonusLinkSourceClassifier.classify(URI(url))
            assertTrue(result.isPlatformPage)
            assertTrue(result.label == expectedLabel)
        }
    }

    @Test
    fun spotifyIsNotAdvertisedAsAnOpenDownloaderWebSource() {
        val result = SonusLinkSourceClassifier.classify(URI("https://open.spotify.com/track/abc123"))
        assertFalse(result.isPlatformPage)
    }

    @Test
    fun directAudioFileIsRecognizedWithoutPlatformScraping() {
        val result = SonusLinkSourceClassifier.classify(URI("https://cdn.example.org/audio/track.m4a?download=1"))
        assertFalse(result.isPlatformPage)
        assertTrue(result.looksLikeDirectMedia)
    }

    @Test
    fun directVideoFileIsRecognizedAsMedia() {
        val result = SonusLinkSourceClassifier.classify(URI("https://media.example.org/clip.mp4"))
        assertFalse(result.isPlatformPage)
        assertTrue(result.looksLikeDirectMedia)
    }

    @Test
    fun genericWebPageIsNotAssumedToBeMedia() {
        val result = SonusLinkSourceClassifier.classify(URI("https://example.org/watch?id=123"))
        assertFalse(result.isPlatformPage)
        assertFalse(result.looksLikeDirectMedia)
    }
}
