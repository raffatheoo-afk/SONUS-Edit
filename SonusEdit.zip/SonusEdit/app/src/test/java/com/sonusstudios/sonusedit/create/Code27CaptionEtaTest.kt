package com.sonusstudios.sonusedit.create

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class Code27CaptionEtaTest {
    @Test fun userMeasurementScalesPresetDurations() {
        mapOf(15 to 46L, 30 to 92L, 40 to 123L, 50 to 153L, 60 to 184L, 65 to 199L).forEach { (seconds, expected) ->
            val actual = CaptionEtaEstimator13.baselineMs(seconds * 1_000L)
            assertEquals(expected, (actual / 1_000.0).let { kotlin.math.round(it).toLong() })
        }
    }

    @Test fun elapsedFromGalleryIsIncluded() {
        assertEquals(124_000L, CaptionEtaEstimator13.remainingMs(60_000, 60_000))
        assertEquals("02:04", CaptionEtaEstimator13.formatRemaining(124_000))
    }

    @Test fun progressRecalibratesButCannotPretendToFinish() {
        val updated = CaptionEtaEstimator13.remainingMs(60_000, 95_000, 24_000, 95_000)
        assertTrue(updated != null && updated > 0L)
        assertNull(CaptionEtaEstimator13.remainingMs(60_000, 500_000))
        assertEquals("--:--", CaptionEtaEstimator13.formatRemaining(null))
    }

    @Test fun invalidRangesStaySafe() {
        assertNull(CaptionEtaEstimator13.remainingMs(0, 0))
        assertEquals(0L, CaptionEtaEstimator13.baselineMs(-50))
    }
}
