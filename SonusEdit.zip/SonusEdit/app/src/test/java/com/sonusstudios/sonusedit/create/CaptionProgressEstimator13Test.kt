package com.sonusstudios.sonusedit.create

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.assertNotNull
import org.junit.Test

class CaptionProgressEstimator13Test {
    @Test fun modelDownloadDoesNotPretendTranscriptionHasProgress() {
        assertNull(CaptionProgressEstimator13.percent(0, 0L, 60_000L, 10_000L, 180_000L, true, false))
    }

    @Test fun elapsedTimeAndEtaShareTheSamePercentage() {
        assertEquals(0, CaptionProgressEstimator13.percent(null, 25_000L, 100_000L, 0L, 180_000L, false, false))
        assertEquals(50, CaptionProgressEstimator13.percent(98, 60_000L, 100_000L, 90_000L, 180_000L, false, false))
        assertEquals(98, CaptionProgressEstimator13.percent(0, 100_000L, 100_000L, 400_000L, 180_000L, false, false))
        assertEquals(100, CaptionProgressEstimator13.percent(0, 0L, 100_000L, 400_000L, 180_000L, false, true))
    }

    @Test fun `remaining timer can display the final one second`() {
        assertNotNull(CaptionEtaEstimator14.remainingMs(10_000L, 60_000L, 9_000L, null, null))
        assertEquals(1_000L, CaptionEtaEstimator14.remainingMs(10_000L, 60_000L, 9_000L, null, null))
        assertEquals(1_000L, CaptionEtaEstimator14.remainingMs(10_000L, 60_000L, 15_000L, null, null))
    }

    @Test fun completionProgressIsReservedUntilWhisperConfirmsSuccess() {
        assertEquals(98, CaptionProgressEstimator13.percent(null, null, 60_000L, 99_000L, 100_000L, false, false))
        assertEquals(100, CaptionProgressEstimator13.percent(null, null, 60_000L, 99_000L, 100_000L, false, true))
    }

    @Test fun progressAndClockStayProportionalAtTheSameElapsedTime() {
        val totalMs = 240_000L
        listOf(0L to 0, 60_000L to 25, 120_000L to 50, 180_000L to 75, 235_000L to 97).forEach { (elapsed, expectedPercent) ->
            assertEquals(expectedPercent, CaptionProgressEstimator13.percent(null, null, 60_000L, elapsed, totalMs, false, false))
            assertEquals((totalMs - elapsed).coerceAtLeast(1_000L), CaptionEtaEstimator14.remainingMs(totalMs, 60_000L, elapsed, null, null))
        }
    }

    @Test fun captionBenchmarksKeepTheExactStopwatchPointsAndInterpolateBrokenDurations() {
        val expected = mapOf(
            15 to 105_590L,
            30 to 171_221L,
            40 to 214_975L,
            50 to 258_730L,
            60 to 302_484L,
            31 to 175_597L,
            32 to 179_972L,
            33 to 184_348L,
            34 to 188_723L,
            35 to 193_098L,
        )
        expected.forEach { (seconds, milliseconds) ->
            assertEquals(milliseconds, CaptionEtaEstimator14.defaultMs(seconds * 1_000L))
        }
    }

    @Test fun extractorRejectsAWindowThatDecodedOnlyAsAFragment() {
        assertTrue(!AudioSegmentWavExtractor.hasEnoughPcmCoverage(3_200L, 30_000L))
        assertTrue(!AudioSegmentWavExtractor.hasEnoughPcmCoverage(160_000L, 30_000L)) // 5 seconds
        assertTrue(!AudioSegmentWavExtractor.hasEnoughPcmCoverage(816_000L, 30_000L)) // 25.5 seconds: 85%, partial
        assertTrue(AudioSegmentWavExtractor.hasEnoughPcmCoverage(912_000L, 30_000L)) // 28.5 seconds: 95%
        assertTrue(AudioSegmentWavExtractor.hasEnoughPcmCoverage(30_000L, 1_000L)) // 937 ms
        // Sample coverage uses 16 kHz sample counts (30 seconds = 480,000 samples),
        // not milliseconds. Keep this a normal-length chunk so the 95% rule applies.
        assertTrue(!AudioSegmentWavExtractor.hasEnoughSampleCoverage(408_000L, 480_000L)) // 85%, partial chunk
        assertTrue(AudioSegmentWavExtractor.hasEnoughSampleCoverage(456_000L, 480_000L)) // 95%, valid chunk
    }

    @Test fun progressIsMonotonicForAnUnchangingExpectedTotal() {
        val values = listOf(0L, 20_000L, 40_000L, 80_000L, 179_000L).map {
            CaptionProgressEstimator13.percent(null, null, 60_000L, it, 180_000L, false, false)!!
        }
        assertTrue(values.zipWithNext().all { (a, b) -> b >= a })
        assertEquals(listOf(0, 11, 22, 44, 98), values)
    }
}
