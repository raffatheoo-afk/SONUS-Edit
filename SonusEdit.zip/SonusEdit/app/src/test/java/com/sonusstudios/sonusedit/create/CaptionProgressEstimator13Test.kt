package com.sonusstudios.sonusedit.create

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CaptionProgressEstimator13Test {
    @Test fun modelDownloadDoesNotPretendTranscriptionHasProgress() {
        assertNull(CaptionProgressEstimator13.percent(0, 0L, 60_000L, 10_000L, 180_000L, true, false))
    }

    @Test fun processedAudioProvidesVisiblePercentWhenWhisperCheckpointHasNoPercent() {
        val percent = CaptionProgressEstimator13.percent(
            reportedPercent = null,
            processedAudioMs = 25_000L,
            durationMs = 100_000L,
            elapsedMs = 0L,
            expectedTotalMs = 0L,
            waitingForModel = false,
            completed = false,
        )
        assertEquals(25, percent)
    }

    @Test fun percentageUsesReportedAndElapsedCheckpointsButStopsAt98UntilDone() {
        val first = CaptionProgressEstimator13.percent(12, 5_000L, 60_000L, 20_000L, 180_000L, false, false)!!
        val next = CaptionProgressEstimator13.percent(25, 15_000L, 60_000L, 40_000L, 180_000L, false, false)!!
        val late = CaptionProgressEstimator13.percent(99, 60_000L, 60_000L, 400_000L, 180_000L, false, false)!!
        assertTrue(next >= first)
        assertEquals(98, late)
        assertEquals(100, CaptionProgressEstimator13.percent(100, 60_000L, 60_000L, 400_000L, 180_000L, false, true))
    }
}
