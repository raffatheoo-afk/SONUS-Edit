package com.sonusstudios.sonusedit.catalog

import org.junit.Assert.assertEquals
import org.junit.Test

class GallerySearchRotationTest {
    @Test fun rotatesAcrossAvailableServersAndSkipsKnownEmptySources() {
        val available = listOf("s1", "s3")
        assertEquals(listOf("s1", "s3"), GallerySearchRotation.order(available, 0))
        assertEquals(listOf("s3", "s1"), GallerySearchRotation.order(available, 1))
        assertEquals(listOf("s1", "s3"), GallerySearchRotation.order(available, 2))
    }

    @Test fun emptySourceListStaysEmpty() {
        assertEquals(emptyList<String>(), GallerySearchRotation.order(emptyList(), 0))
    }
}
