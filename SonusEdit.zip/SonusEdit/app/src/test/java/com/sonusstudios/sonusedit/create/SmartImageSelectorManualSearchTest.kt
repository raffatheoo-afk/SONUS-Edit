package com.sonusstudios.sonusedit.create

import com.sonusstudios.sonusedit.catalog.PCloudAsset
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SmartImageSelectorManualSearchTest {
    @Test
    fun `large query excludes all blocked stable identities without releasing them`() {
        val assets = (1..320).map { id ->
            PCloudAsset(
                fileId = id.toLong(),
                name = "Romantico ${id.toString().padStart(3, '0')}.jpg",
                folderPath = "Romantico",
                sourcePublicCode = "gallery",
            )
        }
        val blocked = (1..50).map { "gallery:$it" }.toSet()
        val visible = SmartImageSelector.searchManualGallery(assets, "romântico", blocked)

        assertEquals(270, visible.size)
        assertTrue(visible.none { it.stableKey in blocked })
        assertTrue(visible.all { it.name.startsWith("Romantico") })
    }

    @Test
    fun `exact phrase matcher does not count partial words as search results`() {
        val assets = listOf(
            PCloudAsset(1L, "Amores antigos.jpg", folderPath = "Galeria", sourcePublicCode = "gallery"),
            PCloudAsset(2L, "Amor verdadeiro.jpg", folderPath = "Galeria", sourcePublicCode = "gallery"),
            PCloudAsset(3L, "Canção de amor.jpg", folderPath = "Galeria", sourcePublicCode = "gallery"),
        )

        val result = SmartImageSelector.searchManualGallery(assets, "amor")
        assertEquals(listOf(2L, 3L), result.map { it.fileId })
    }

    @Test
    fun `all meaningful words must match across title and folder`() {
        val assets = listOf(
            PCloudAsset(1L, "Nossa Senhora.jpg", folderPath = "Aparecida", sourcePublicCode = "gallery"),
            PCloudAsset(2L, "Nossa Senhora.jpg", folderPath = "Romantico", sourcePublicCode = "gallery"),
        )
        val result = SmartImageSelector.searchManualGallery(assets, "nossa senhora aparecida")
        assertEquals(listOf(1L), result.map { it.fileId })
    }
}
