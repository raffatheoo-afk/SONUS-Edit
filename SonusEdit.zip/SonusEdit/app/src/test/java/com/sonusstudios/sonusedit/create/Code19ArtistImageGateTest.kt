package com.sonusstudios.sonusedit.create

import com.sonusstudios.sonusedit.catalog.PCloudAsset
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class Code19ArtistImageGateTest {
    @Test
    fun `artist normalization handles accents punctuation and duo separators`() {
        assertEquals("jorge e mateus", ArtistGenreResolver.normalize("JORGE & MATEUS"))
        assertEquals("jorge e mateus", ArtistGenreResolver.normalize("Jorge + Mateus"))
        assertEquals("marilia mendonca", ArtistGenreResolver.normalize("Marília Mendonça"))
    }

    @Test
    fun `sertanejo category excludes explicitly catholic images`() {
        val match = ArtistGenreResolver.Match(
            artist = "Gustavo Mioto",
            category = "sertanejo",
            imageKeyword = "sertanejo",
            positiveKeywords = setOf("sertanejo", "agronejo", "modao", "sofrencia"),
            blockedCategoryKeywords = setOf("catolico", "catolica", "gospel", "funk", "trap", "nossa senhora", "maria", "santo"),
            confidence = "high",
            source = ArtistGenreResolver.Match.Source.ARTIST,
        )
        val assets = listOf(
            PCloudAsset(1, "estrada_sertanejo_01.jpg", folderPath = "Galeria"),
            PCloudAsset(2, "fazenda_sertanejo_02.jpg", folderPath = "Galeria"),
            PCloudAsset(3, "casal_sertanejo_03.jpg", folderPath = "Galeria"),
            PCloudAsset(4, "chapeu_sertanejo_04.jpg", folderPath = "Galeria"),
            PCloudAsset(5, "nossa_senhora_das_gracas_01.jpg", folderPath = "Galeria"),
            PCloudAsset(6, "paisagem_neutra.jpg", folderPath = "Galeria"),
            PCloudAsset(7, "imagem_catolica_01.jpg", folderPath = "Galeria"),
        )
        val ranked = SmartImageSelector.rank(
            assets = assets,
            metadata = AudioMetadata("Teste", "Gustavo Mioto", 30_000L, genre = "Sertanejo"),
            syncedLyrics = "",
            artistCategory = match,
        )

        assertFalse(ranked.any { it.fileId == 5L })
        assertFalse(ranked.any { it.fileId == 7L })
        assertTrue(ranked.take(4).all { "sertanejo" in it.name.lowercase() })
    }

    @Test
    fun `unknown artist keeps neutral ranking path`() {
        val assets = listOf(
            PCloudAsset(1, "paisagem_um.jpg", folderPath = "Galeria"),
            PCloudAsset(2, "paisagem_dois.jpg", folderPath = "Galeria"),
        )
        val ranked = SmartImageSelector.rank(assets, AudioMetadata("Teste", "Artista Novo", 30_000L), "", null)
        assertEquals(2, ranked.size)
    }
}
