package com.sonusstudios.sonusedit.create

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class Code20AspectRatioTest {
    @Test
    fun verticalRemainsTheDefaultAndLegacyMapping() {
        assertEquals("9:16", ProjectAspectRatios.VERTICAL)
        assertFalse(ProjectAspectRatios.isHorizontal(ProjectAspectRatios.VERTICAL))
        assertEquals(1080, ExportResolution.P1080.outputWidth(ProjectAspectRatios.VERTICAL))
        assertEquals(1920, ExportResolution.P1080.outputHeight(ProjectAspectRatios.VERTICAL))
    }

    @Test
    fun horizontalSwapsEveryApprovedResolution() {
        assertTrue(ProjectAspectRatios.isHorizontal(ProjectAspectRatios.HORIZONTAL))
        val expected = mapOf(
            ExportResolution.P720 to (1280 to 720),
            ExportResolution.P1080 to (1920 to 1080),
            ExportResolution.P2K to (2560 to 1440),
            ExportResolution.P4K to (3840 to 2160),
        )
        expected.forEach { (resolution, size) ->
            assertEquals(size.first, resolution.outputWidth(ProjectAspectRatios.HORIZONTAL))
            assertEquals(size.second, resolution.outputHeight(ProjectAspectRatios.HORIZONTAL))
        }
    }

    @Test
    fun infinityStillMeansSelectedStartToTrackEnd() {
        assertTrue(DurationPreset.INFINITE.untilEnd)
        assertEquals(71_000L, DurationPreset.INFINITE.durationMs(140_000L, 69_000L))
    }
}
