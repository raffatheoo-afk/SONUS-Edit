package com.sonusstudios.sonusedit.create

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class Code11LanguageHintTest {
    @Test fun titleIndicatesLanguageWithoutOverconfidence() {
        assertEquals("pt", CaptionLanguageHint.fromTitle("Eu Te Amo"))
        assertEquals("en", CaptionLanguageHint.fromTitle("I Love You"))
        assertEquals("pt", CaptionLanguageHint.fromTitle("Última Mensagem"))
        assertEquals(null, CaptionLanguageHint.fromTitle("Instrumental 2026"))
        assertEquals(null, CaptionLanguageHint.fromTitle("Love e Amor"))
    }

    @Test fun titleHypothesisStillNeedsAudioEvidence() {
        assertTrue(CaptionLanguageHint.acceptCandidate("pt", "Eu não consigo viver sem você", "love me forever"))
        assertTrue(CaptionLanguageHint.acceptCandidate("en", "I love you forever my baby", "eu amo"))
        assertFalse(CaptionLanguageHint.acceptCandidate("pt", "Love you baby forever", "Love you baby"))
        assertFalse(CaptionLanguageHint.acceptCandidate("en", "Eu te amo muito", "eu amo você"))
    }
}
