package com.sonusstudios.sonusedit.create

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CaptionRequestGuard14Test {
    @Test fun sameAudioTrimIsNotStartedTwice() {
        val key = CaptionRequestGuard14.key("content://track/1", 0L, 180_000L)
        assertTrue(CaptionRequestGuard14.canStart(key, null, false, false))
        assertFalse(CaptionRequestGuard14.canStart(key, key, false, false))
        assertFalse(CaptionRequestGuard14.canStart(key, null, true, false))
        assertFalse(CaptionRequestGuard14.canStart(key, null, false, true))
    }

    @Test fun changedTrimCreatesASeparateRequest() {
        val oldKey = CaptionRequestGuard14.key("content://track/1", 0L, 180_000L)
        val newKey = CaptionRequestGuard14.key("content://track/1", 30_000L, 150_000L)
        assertTrue(CaptionRequestGuard14.canStart(newKey, oldKey, false, false))
        assertEquals(oldKey, CaptionRequestGuard14.key("content://track/1", 0L, 180_000L))
    }

    @Test fun titleOrMetadataChangesDoNotChangeTheJobIdentity() {
        val first = CaptionRequestGuard14.key("content://track/1", 0L, 180_000L)
        val afterMetadataLoaded = CaptionRequestGuard14.key("content://track/1", 0L, 180_000L)
        assertEquals(first, afterMetadataLoaded)
    }
}
