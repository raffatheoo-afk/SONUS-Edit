package com.sonusstudios.sonusedit.catalog

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PCloudCatalogNodeParser14Test {
    @Test fun recognizesAllPCloudFolderFlagRepresentations() {
        assertTrue(PCloudCatalogNodeParser14.isFolder("1", false))
        assertTrue(PCloudCatalogNodeParser14.isFolder("true", false))
        assertTrue(PCloudCatalogNodeParser14.isFolder("TRUE", false))
        assertTrue(PCloudCatalogNodeParser14.isFolder(null, true))
        assertFalse(PCloudCatalogNodeParser14.isFolder("0", false))
        assertFalse(PCloudCatalogNodeParser14.isFolder("false", false))
    }

    @Test fun rejectsMalformedFolderResponseInsteadOfTreatingItAsEmptyCatalog() {
        assertFalse(PCloudCatalogNodeParser14.isValidRoot("1", false, false))
        assertFalse(PCloudCatalogNodeParser14.isValidRoot(null, false, false))
        assertTrue(PCloudCatalogNodeParser14.isValidRoot("1", true, false))
        assertTrue(PCloudCatalogNodeParser14.isValidRoot("0", false, true))
        assertTrue(PCloudCatalogNodeParser14.isValidRoot("1", true, false)) // valid empty folder is still represented by an array
    }
}
