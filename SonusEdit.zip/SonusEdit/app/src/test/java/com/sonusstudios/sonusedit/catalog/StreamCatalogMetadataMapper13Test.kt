package com.sonusstudios.sonusedit.catalog

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class StreamCatalogMetadataMapper13Test {
    @Test fun readsRealTagsDirectlyFromPCloudCatalog() {
        val asset = PCloudAsset(
            fileId = 42L,
            name = "P2cTU8sQm9NwX1kL.mp3",
            durationMs = 185_000L,
            sourcePublicCode = "public-folder",
            metadataTitle = "Noite de Amor",
            metadataArtist = "Artista Exemplo",
            metadataAlbum = "Ao Vivo",
            metadataGenre = "Romântico",
        )
        val metadata = StreamCatalogMetadataMapper.fromAsset(asset)
        assertEquals("Noite de Amor", metadata?.title)
        assertEquals("Artista Exemplo", metadata?.artist)
        assertEquals("Ao Vivo", metadata?.album)
        assertEquals("Romântico", metadata?.genre)
        assertEquals(185_000L, metadata?.durationMs)
        assertTrue(StreamCatalogMetadataMapper.hasUsefulCatalogIdentity(asset))
    }

    @Test fun opaqueFilenameIsNotPretendedToBeARealTitle() {
        val asset = PCloudAsset(
            fileId = 43L,
            name = "P2cTU8sQm9NwX1kL.mp3",
            metadataArtist = "Artista Exemplo",
        )
        val metadata = StreamCatalogMetadataMapper.fromAsset(asset)
        assertTrue(StreamCatalogMetadataMapper.isOpaqueCode(metadata?.title.orEmpty()))
        assertFalse(StreamCatalogMetadataMapper.hasUsefulCatalogIdentity(asset))
    }

    @Test fun emptyCatalogTagsReturnNullAndCanUseRemoteFallback() {
        val asset = PCloudAsset(fileId = 44L, name = "P2cTU8sQm9NwX1kL.mp3")
        assertNull(StreamCatalogMetadataMapper.fromAsset(asset))
    }
}
