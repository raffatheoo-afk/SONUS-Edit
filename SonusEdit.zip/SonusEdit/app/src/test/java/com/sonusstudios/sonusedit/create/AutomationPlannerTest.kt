package com.sonusstudios.sonusedit.create

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AutomationPlannerTest {
    @Test
    fun `automatic duration never chooses 15 seconds`() {
        val metadata = AudioMetadata(
            title = "Teste",
            artist = "Artista",
            durationMs = 180_000L,
            genre = "Pop",
        )
        val chosen = AutomationPlanner.duration(metadata, null)
        assertNotEquals(15, chosen?.seconds)
        assertTrue(chosen == null || chosen.seconds >= 30)
    }

    @Test
    fun `short tracks still preserve 15 seconds as manual only by returning no auto preset`() {
        val metadata = AudioMetadata(
            title = "Curta",
            artist = "Artista",
            durationMs = 22_000L,
        )
        val chosen = AutomationPlanner.duration(metadata, null)
        assertTrue(chosen == null)
    }

    @Test fun automaticFilterPoolNeverSelectsBlackAndWhite() {
        val metadata = AudioMetadata(title = "Faixa", artist = "Artista", durationMs = 120_000L)
        repeat(100) { nonce ->
            assertTrue(AutomationPlanner.filter(metadata, null, nonce = nonce) != FilterPresetId.BLACK_AND_WHITE)
        }
        assertEquals(27, FilterPresetId.entries.size)
        assertEquals(24, FilterPresetId.entries.count { it.automaticEligible && it != FilterPresetId.BLACK_AND_WHITE })
    }

}
