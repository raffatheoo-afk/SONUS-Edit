package com.sonusstudios.sonusedit.create

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class OpenDownloaderHandoffTest {
    @Test fun addsHttpsToBareLinksAndStripsFragments() {
        assertEquals("https://youtu.be/example", OpenDownloaderHandoff.normalizeHttpUrl("youtu.be/example#t=2"))
    }

    @Test fun preservesHttpsUrls() {
        assertEquals("https://x.com/video/123", OpenDownloaderHandoff.normalizeHttpUrl("https://x.com/video/123"))
    }

    @Test fun rejectsCredentialsAndNonHttpsSchemes() {
        assertNull(OpenDownloaderHandoff.normalizeHttpUrl("https://user:pass@example.com/video"))
        assertNull(OpenDownloaderHandoff.normalizeHttpUrl("http://example.com/video"))
        assertNull(OpenDownloaderHandoff.normalizeHttpUrl("not a link"))
    }
}
