package com.sonusstudios.sonusedit.create

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class Code03CaptionLanguageHintTest {
    @Test
    fun `professional captions default to classic clean style`() {
        assertEquals(CaptionStyleId.CLASSIC, AutomationSettings().preferredCaptionStyle)
    }

    @Test
    fun `individual automation options are enabled by default`() {
        val defaults = AutomationSettings()
        assertTrue(defaults.smartStart)
        assertTrue(defaults.prioritizeChorus)
        assertTrue(defaults.automaticLyrics)
        assertTrue(defaults.automaticEffects)
        assertTrue(defaults.automaticImages)
        assertTrue(defaults.automaticFilter)
        assertTrue(defaults.blockRecentImages)
        assertTrue(defaults.metadataOnVideo)
    }

    @Test
    fun `audio text can identify english without relying on title or device locale`() {
        assertEquals("en", CaptionLanguageHint.fromTranscription("I will never leave you alone tonight"))
    }

    @Test
    fun `audio text can identify brazilian portuguese`() {
        assertEquals("pt", CaptionLanguageHint.fromTranscription("Eu te amo voce meu coracao"))
    }

    @Test
    fun `instrumental or ambiguous text remains automatic`() {
        assertNull(CaptionLanguageHint.fromTranscription("la la la oh oh"))
    }

    @Test
    fun `title hint cannot force portuguese over clear english recognition`() {
        assertFalse(CaptionLanguageHint.acceptCandidate(
            candidate = "pt",
            triedText = "I will never give up on you tonight",
            automaticText = "I will never leave you alone tonight",
        ))
    }

    @Test
    fun `a corroborating english pass can be accepted`() {
        assertTrue(CaptionLanguageHint.acceptCandidate(
            candidate = "en",
            triedText = "I will never leave you alone tonight",
            automaticText = "eu te amo meu coracao",
        ))
    }
}
