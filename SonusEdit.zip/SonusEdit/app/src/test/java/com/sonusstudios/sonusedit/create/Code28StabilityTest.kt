package com.sonusstudios.sonusedit.create

import com.sonusstudios.sonusedit.media.ExportRecoveryPolicy14
import org.junit.Assert.*
import org.junit.Test

class Code28StabilityTest {
    @Test fun improvedDefaultEtaUsesTheFiveNewStopwatchBenchmarks() {
        assertEquals(105_590L, CaptionEtaEstimator14.defaultMs(15_000L))
        assertEquals(171_221L, CaptionEtaEstimator14.defaultMs(30_000L))
        assertEquals(214_975L, CaptionEtaEstimator14.defaultMs(40_000L))
        assertEquals(258_730L, CaptionEtaEstimator14.defaultMs(50_000L))
        assertEquals(302_484L, CaptionEtaEstimator14.defaultMs(60_000L))
        assertEquals(179_972L, CaptionEtaEstimator14.defaultMs(32_000L))
        assertTrue(CaptionEtaEstimator14.defaultMs(65_000L) > 302_000L)
    }

    @Test fun languageUsesEvidenceFromTranscribedVocal() {
        assertEquals("en", CaptionLanguageHint.fromTitle("I Love You"))
        assertEquals("pt", CaptionLanguageHint.fromTitle("Eu Te Amo"))
        assertEquals("en", CaptionLanguageHint.fromTranscription("I never knew the love you gave me", "en"))
        assertEquals("pt", CaptionLanguageHint.fromTranscription("Eu não sei o que vai acontecer com meu amor", "pt"))
        assertNull(CaptionLanguageHint.fromTranscription("ah la la la", "en"))
    }

    @Test fun retryOnlyRecoverableShortExport() {
        assertTrue(ExportRecoveryPolicy14.shouldRetryInChunks(
            IllegalStateException("Muxer error: no output sample written in the last 10000 milliseconds"),30_000L))
        assertFalse(ExportRecoveryPolicy14.shouldRetryInChunks(IllegalArgumentException("File not found"),30_000L))
        assertFalse(ExportRecoveryPolicy14.shouldRetryInChunks(IllegalStateException("Muxer error"),901_000L))
    }
}
