package com.sonusstudios.sonusedit.create

import com.sonusstudios.sonusedit.media.ExportRecoveryPolicy14
import org.junit.Assert.*
import org.junit.Test

class Code28StabilityTest {
    @Test fun improvedDefaultEtaUsesLatestOnDeviceMeasurements() {
        assertEquals(182_000L, CaptionEtaEstimator14.defaultMs(30_000L))
        assertEquals(184_000L, CaptionEtaEstimator14.defaultMs(60_000L))
        assertTrue(CaptionEtaEstimator14.defaultMs(65_000L) >= 184_000L)
    }

    @Test fun languageUsesEvidenceFromTranscribedVocal() {
        assertEquals("en", CaptionLanguageHint.fromTitle("I Love You"))
        assertEquals("pt", CaptionLanguageHint.fromTitle("Eu Te Amo"))
        assertEquals("en", CaptionLanguageHint.fromTranscription("I never knew the love you gave me", "en"))
        assertEquals("pt", CaptionLanguageHint.fromTranscription("Eu não sei o que vai acontecer com meu amor", "pt"))
        assertNull(CaptionLanguageHint.fromTranscription("ah la la la", "en"))
    }

    @Test fun retryOnlyRecoverableShortExport() {
        assertTrue(ExportRecoveryPolicy14.shouldRetryInChunks(
            IllegalStateException("Muxer error: no output sample written in the last 10000 milliseconds"),30_000L))
        assertFalse(ExportRecoveryPolicy14.shouldRetryInChunks(IllegalArgumentException("File not found"),30_000L))
        assertFalse(ExportRecoveryPolicy14.shouldRetryInChunks(IllegalStateException("Muxer error"),901_000L))
    }
}
