package com.sonusstudios.sonusedit.create

import com.sonusstudios.sonusedit.media.ExportFallbackLadder02
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class Code02ExportAndRatiosTest {
    private fun draft(
        resolution: ExportResolution = ExportResolution.P1080,
        fps: Int = 60,
        ratio: String = ProjectAspectRatios.VERTICAL,
        customW: Int = 0,
        customH: Int = 0,
    ) = CreateProjectDraft(
        audioUri = "content://audio",
        audioTitle = "t",
        audioDurationMs = 10_000L,
        segmentStartMs = 0L,
        segmentDurationMs = 10_000L,
        signatureText = "",
        imageUris = listOf("content://image"),
        fontPreset = FontPresetId.DEFAULT,
        aspectRatio = ratio,
        exportResolution = resolution,
        exportFps = fps,
        customOutputWidth = customW,
        customOutputHeight = customH,
    )

    @Test fun originalRatiosKeepTheirExactSizes() {
        assertEquals(1080, ExportResolution.P1080.outputWidth("9:16"))
        assertEquals(1920, ExportResolution.P1080.outputHeight("9:16"))
        assertEquals(1920, ExportResolution.P1080.outputWidth("16:9"))
        assertEquals(1080, ExportResolution.P1080.outputHeight("16:9"))
        assertEquals(2160, ExportResolution.P4K.outputWidth("9:16"))
        assertEquals(3840, ExportResolution.P4K.outputHeight("9:16"))
        assertEquals(3840, ExportResolution.P4K.outputWidth("16:9"))
        assertEquals(720, ExportResolution.P720.outputWidth("9:16"))
        assertEquals(1280, ExportResolution.P720.outputHeight("9:16"))
    }

    @Test fun otherRatiosKeepTheShortSideAndUseEvenNumbers() {
        assertEquals(1080 to 1080, ExportResolution.P1080.outputWidth("1:1") to ExportResolution.P1080.outputHeight("1:1"))
        assertEquals(1080 to 1350, ExportResolution.P1080.outputWidth("4:5") to ExportResolution.P1080.outputHeight("4:5"))
        assertEquals(1080 to 1440, ExportResolution.P1080.outputWidth("3:4") to ExportResolution.P1080.outputHeight("3:4"))
        assertEquals(720 to 900, ExportResolution.P720.outputWidth("4:5") to ExportResolution.P720.outputHeight("4:5"))
        ProjectAspectRatios.ALL.forEach { ratio ->
            ExportResolution.entries.forEach { resolution ->
                assertEquals(0, resolution.outputWidth(ratio) % 2)
                assertEquals(0, resolution.outputHeight(ratio) % 2)
            }
        }
    }

    @Test fun ratioHelpers() {
        assertTrue(ProjectAspectRatios.isValid("1:1"))
        assertFalse(ProjectAspectRatios.isValid("7:3"))
        assertTrue(ProjectAspectRatios.isHorizontal("16:9"))
        assertFalse(ProjectAspectRatios.isHorizontal("9:16"))
        assertFalse(ProjectAspectRatios.isHorizontal("1:1"))
        assertEquals(5 to 4, ProjectAspectRatios.parts("5:4"))
        assertEquals(9 to 16, ProjectAspectRatios.parts("nonsense"))
    }

    @Test fun draftUsesCustomSizeWhenSetAndResolutionOtherwise() {
        val normal = draft()
        assertEquals(1080, normal.outputWidth())
        assertEquals(1920, normal.outputHeight())
        assertFalse(normal.isHorizontalOutput())
        val custom = draft(customW = 1350, customH = 1080)
        assertEquals(1350, custom.outputWidth())
        assertEquals(1080, custom.outputHeight())
        assertTrue(custom.isHorizontalOutput())
        assertEquals("1350x1080", custom.outputLabel())
    }

    @Test fun ladderLowersFpsThenResolution() {
        val error = IllegalStateException("MediaCodec encoder failed to configure")
        val step1 = ExportFallbackLadder02.next(draft(ExportResolution.P2K, 60), error, 2)
        assertNotNull(step1)
        assertEquals(30, step1!!.exportFps)
        assertEquals(ExportResolution.P2K, step1.exportResolution)
        val step2 = ExportFallbackLadder02.next(step1, error, 2)!!
        assertEquals(ExportResolution.P1080, step2.exportResolution)
        val step3 = ExportFallbackLadder02.next(step2, error, 2)!!
        assertEquals(ExportResolution.P720, step3.exportResolution)
        assertNull(ExportFallbackLadder02.next(step3, error, 2))
    }

    @Test fun ladderScalesCustomSizeDownAndStopsWhenSmall() {
        val error = IllegalStateException("O aparelho não entregou o tamanho pedido")
        val scaled = ExportFallbackLadder02.next(draft(fps = 30, customW = 1080, customH = 1920), error, 16)!!
        assertEquals(0, scaled.customOutputWidth % 16)
        assertEquals(0, scaled.customOutputHeight % 16)
        assertTrue(scaled.customOutputWidth < 1080 && scaled.customOutputHeight < 1920)
        assertNull(ExportFallbackLadder02.next(draft(fps = 30, customW = 480, customH = 854), error, 2))
    }

    @Test fun ladderIgnoresErrorsThatALighterExportCannotFix() {
        assertNull(ExportFallbackLadder02.next(draft(), java.io.FileNotFoundException("open failed: ENOENT"), 2))
        assertFalse(ExportFallbackLadder02.isRecoverable(RuntimeException("cancelado")))
        assertTrue(ExportFallbackLadder02.isRecoverable(OutOfMemoryError()))
    }
}
