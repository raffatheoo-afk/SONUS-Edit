package com.sonusstudios.sonusedit.create

import org.junit.Assert.assertEquals
import org.junit.Test

class AudioDurationProbe13Test {
    @Test
    fun convertsContainerDurationToMillisecondsWithoutDecoding() {
        assertEquals(378_000L, AudioDurationProbe13.normalizeDurationUs(378_000_000L))
    }

    @Test
    fun ignoresMissingOrTooShortDuration() {
        assertEquals(0L, AudioDurationProbe13.normalizeDurationUs(0L))
        assertEquals(0L, AudioDurationProbe13.normalizeDurationUs(999_999L))
    }

    @Test
    fun choosesLongestAudioTrackDuration() {
        assertEquals(378_000L, AudioDurationProbe13.longestAudioTrackDurationUs(listOf(12_000_000L, 378_000_000L)))
        assertEquals(0L, AudioDurationProbe13.longestAudioTrackDurationUs(emptyList()))
    }
}
