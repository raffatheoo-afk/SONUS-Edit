package com.sonusstudios.sonusedit.create

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ImageCooldownPlannerTest {
    @Test
    fun `large query keeps every recent image blocked and releases none`() {
        val assets = (1..320).map { "gallery:$it" }.toSet()
        val history = listOf(
            (1..10).map { "gallery:$it" },
            (11..20).map { "gallery:$it" },
            (21..30).map { "gallery:$it" },
            (31..40).map { "gallery:$it" },
            (41..50).map { "gallery:$it" },
        )
        val result = ImageCooldownPlanner.calculate(assets, history, requiredCount = 10)
        assertEquals(320, result.totalCatalogCount)
        assertEquals(50, result.blockedCount)
        assertEquals(0, result.releasedCount)
        assertEquals(270, result.availableCount)
        assertEquals(50, result.blockedKeys.size)
    }

    @Test
    fun `small query releases oldest project entries only to fill the shortage`() {
        val historyNewestFirst = listOf(listOf("new"), listOf("middle"), listOf("old"))
        val assets = setOf("fresh-1", "fresh-2", "fresh-3", "new", "middle", "old")
        val result = ImageCooldownPlanner.calculate(assets, historyNewestFirst, requiredCount = 5)
        assertEquals(2, result.releasedCount)
        assertEquals(setOf("new"), result.blockedKeys)
        assertFalse("old" in result.blockedKeys)
        assertFalse("middle" in result.blockedKeys)
        assertTrue("new" in result.blockedKeys)
    }

    @Test
    fun `eleven fresh query matches never trigger early release`() {
        val history = listOf(listOf("old-1", "old-2"))
        val assets = (1..11).map { "fresh-$it" }.toSet() + setOf("old-1", "old-2")
        val result = ImageCooldownPlanner.calculate(assets, history, requiredCount = 20)
        assertEquals(0, result.releasedCount)
        assertEquals(setOf("old-1", "old-2"), result.blockedKeys)
    }
    @Test
    fun `every exported project advances its format FIFO including projects with only local media`() {
        val vertical = (1..20).map { listOf("vertical-$it") }
        val nextVertical = ImageProjectHistoryPlanner.append(vertical, listOf("new-vertical"), 20)
        assertEquals(20, nextVertical.size)
        assertEquals(listOf("new-vertical"), nextVertical.first())
        assertEquals(listOf("vertical-19"), nextVertical.last())

        val horizontal = (1..15).map { listOf("horizontal-$it") }
        val localOnlyProject = ImageProjectHistoryPlanner.append(horizontal, emptyList(), 15)
        assertEquals(15, localOnlyProject.size)
        assertTrue(localOnlyProject.first().isEmpty())
        assertEquals(listOf("horizontal-14"), localOnlyProject.last())
        val roundTrip = ImageProjectHistoryPlanner.decode(ImageProjectHistoryPlanner.encode(localOnlyProject), 15)
        assertEquals(localOnlyProject, roundTrip)
    }

}
