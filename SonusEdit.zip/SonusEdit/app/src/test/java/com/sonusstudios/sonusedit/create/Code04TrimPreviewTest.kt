package com.sonusstudios.sonusedit.create

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class Code04TrimPreviewTest {
    @Test fun startPreviewTracksCurrentStart() {
        assertEquals(12_000L, TrimPreviewPlanner04.startPreviewPosition(12_000L, 42_000L))
    }

    @Test fun endPreviewIsLastFiveSecondsOrWholeShortSegment() {
        assertEquals(37_000L, TrimPreviewPlanner04.endPreviewPosition(12_000L, 42_000L))
        assertEquals(12_000L, TrimPreviewPlanner04.endPreviewPosition(12_000L, 16_000L))
    }

    @Test fun endPreviewStopsAtTrimBoundary() {
        assertFalse(TrimPreviewPlanner04.shouldStop(41_900L, 42_000L))
        assertTrue(TrimPreviewPlanner04.shouldStop(41_965L, 42_000L))
    }
}
