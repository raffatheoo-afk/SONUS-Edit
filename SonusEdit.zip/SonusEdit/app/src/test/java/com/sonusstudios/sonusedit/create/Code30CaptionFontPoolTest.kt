package com.sonusstudios.sonusedit.create

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class Code30CaptionFontPoolTest {
    @Test fun approvedPoolHasSixteenBundledFonts() {
        assertEquals(16, CaptionFontPool.approved.size)
        assertEquals(16, CaptionFontPool.approved.toSet().size)
        assertTrue(CaptionFontPool.approved.all { it.assetFileName != null })
        assertTrue(CaptionFontPool.approved.none { CaptionFontPool.isRetired(it) })
    }

    @Test fun retiredFontsMapToApprovedReplacements() {
        val retired = FontPresetId.entries.filter { CaptionFontPool.isRetired(it) }
        assertEquals(19, retired.size)
        retired.forEach {
            assertTrue(it.assetFileName == null)
            assertTrue(it.effective() in CaptionFontPool.approved)
            assertFalse(CaptionFontPool.isRetired(it.effective()))
        }
    }

    @Test fun legacyAndSystemFontsKeepWorkingForOldDrafts() {
        assertEquals(FontPresetId.DEFAULT, FontPresetId.DEFAULT.effective())
        assertEquals(FontPresetId.NORMAL_SANS, FontPresetId.NORMAL_SANS.effective())
        assertNotNull(FontPresetId.valueOf("ROOMBOY"))
    }
}
