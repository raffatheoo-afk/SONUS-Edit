package com.sonusstudios.sonusedit.create

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class Code30CaptionFontPoolTest {
    @Test fun approvedPoolContainsTwentyChoicesIncludingNewArtisticFaces() {
        assertEquals(20, CaptionFontPool.approved.size)
        assertEquals(20, CaptionFontPool.approved.toSet().size)
        assertTrue(CaptionFontPool.approved.all { it.assetFileName != null || it.systemTypefaceName != null })
        assertEquals(19, CaptionFontPool.approved.count { it.assetFileName != null })
        assertTrue(CaptionFontPool.approved.none { CaptionFontPool.isRetired(it) })
    }

    @Test fun everyBundledCustomFontIsInTheApprovedPool() {
        val assets = setOf(
            "Magic Clover.otf", "Impact Stone.otf", "PaintBrushScript-Regular.ttf", "Always Lovely.ttf",
            "Elione.otf", "Valid Harmony.ttf", "Adelicius.ttf", "Kabut Hitam.ttf", "Fake Serif.ttf", "BAARS___.TTF",
            "Bainsley_Bold_Italic.otf", "Fundamental Brigade.ttf", "ToridBold.ttf", "AndBasR.ttf",
            "Caveat[wght].ttf", "DancingScript[wght].ttf", "PatrickHand-Regular.ttf", "Kalam-Regular.ttf", "KaushanScript-Regular.ttf",
        )
        assertEquals(assets, CaptionFontPool.approved.mapNotNull { it.assetFileName }.toSet())
    }

    @Test fun montePetrumIsHiddenAndOldDraftsResolveToPatrickHand() {
        assertFalse(FontPresetId.MONTEPETRUM_THIN in CaptionFontPool.approved)
        assertTrue(CaptionFontPool.isRetired(FontPresetId.MONTEPETRUM_THIN))
        assertEquals(FontPresetId.PATRICK_HAND, FontPresetId.MONTEPETRUM_THIN.effective())
    }

    @Test fun retiredFontsMapToApprovedReplacements() {
        val retired = FontPresetId.entries.filter { CaptionFontPool.isRetired(it) }
        retired.forEach {
            assertTrue("${it.name} must resolve to a real approved preset", it.effective() in CaptionFontPool.approved)
            assertFalse(CaptionFontPool.isRetired(it.effective()))
        }
    }

    @Test fun code06SystemAliasesRemainReadableInOldDraftsButAreNotOffered() {
        val temporarySystemIds = FontPresetId.entries.filter {
            it.name.startsWith("SANS_") || it.name.startsWith("SERIF_") || it.name.startsWith("MONO_") || it == FontPresetId.CASUAL_SYSTEM
        }
        assertEquals(29, temporarySystemIds.size)
        temporarySystemIds.forEach {
            assertTrue(CaptionFontPool.isRetired(it))
            assertTrue(it.effective() in CaptionFontPool.approved)
        }
        assertNotNull(FontPresetId.valueOf("ROOMBOY"))
        assertEquals(FontPresetId.NORMAL_SANS, FontPresetId.ROCKY_TTF.effective())
        assertEquals(FontPresetId.NORMAL_SANS, FontPresetId.EPICENTRUM.effective())
        assertEquals(FontPresetId.NORMAL_SANS, FontPresetId.GLOVERLEY.effective())
        assertEquals(FontPresetId.NORMAL_SANS, FontPresetId.THE_BROTHER_HOOPS.effective())
    }
}
