package com.sonusstudios.sonusedit.create

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class Code30CaptionFontPoolTest {
    @Test fun approvedPoolHasThirtyNaturalSystemFonts() {
        assertEquals(30, CaptionFontPool.approved.size)
        assertEquals(30, CaptionFontPool.approved.toSet().size)
        assertTrue(CaptionFontPool.approved.all { it.systemTypefaceName != null })
        assertEquals(30, CaptionFontPool.approved.map { it.systemTypefaceName to it.systemTypefaceStyle }.toSet().size)
        assertTrue(CaptionFontPool.approved.none { CaptionFontPool.isRetired(it) })
    }

    @Test fun retiredFontsMapToApprovedReplacements() {
        val retired = FontPresetId.entries.filter { CaptionFontPool.isRetired(it) }
        assertEquals(FontPresetId.entries.size - 30, retired.size)
        retired.forEach {
            assertTrue(it.effective() in CaptionFontPool.approved)
            assertFalse(CaptionFontPool.isRetired(it.effective()))
        }
    }

    @Test fun legacyAndSystemFontsKeepWorkingForOldDrafts() {
        assertEquals(FontPresetId.SANS_CLEAN, FontPresetId.DEFAULT.effective())
        assertEquals(FontPresetId.NORMAL_SANS, FontPresetId.NORMAL_SANS.effective())
        assertNotNull(FontPresetId.valueOf("ROOMBOY"))
        assertEquals(FontPresetId.NORMAL_SANS, FontPresetId.ROCKY_TTF.effective())
        assertEquals(FontPresetId.NORMAL_SANS, FontPresetId.EPICENTRUM.effective())
        assertEquals(FontPresetId.NORMAL_SANS, FontPresetId.GLOVERLEY.effective())
        assertEquals(FontPresetId.NORMAL_SANS, FontPresetId.THE_BROTHER_HOOPS.effective())
    }
}
