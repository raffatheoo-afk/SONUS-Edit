package com.sonusstudios.sonusedit.create

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class Code30CaptionFontPoolTest {
    @Test fun approvedPoolHasElevenCuratedFontsIncludingProfessionalSystemSans() {
        assertEquals(11, CaptionFontPool.approved.size)
        assertEquals(11, CaptionFontPool.approved.toSet().size)
        assertTrue(CaptionFontPool.approved.all { it.assetFileName != null || it.systemTypefaceName != null })
        assertTrue(CaptionFontPool.approved.none { CaptionFontPool.isRetired(it) })
    }

    @Test fun retiredFontsMapToApprovedReplacements() {
        val retired = FontPresetId.entries.filter { CaptionFontPool.isRetired(it) }
        assertEquals(25, retired.size)
        retired.forEach {
            assertTrue(it.effective() in CaptionFontPool.approved)
            assertFalse(CaptionFontPool.isRetired(it.effective()))
        }
    }

    @Test fun legacyAndSystemFontsKeepWorkingForOldDrafts() {
        assertEquals(FontPresetId.DEFAULT, FontPresetId.DEFAULT.effective())
        assertEquals(FontPresetId.NORMAL_SANS, FontPresetId.NORMAL_SANS.effective())
        assertNotNull(FontPresetId.valueOf("ROOMBOY"))
        assertEquals(FontPresetId.NORMAL_SANS, FontPresetId.ROCKY_TTF.effective())
        assertEquals(FontPresetId.NORMAL_SANS, FontPresetId.EPICENTRUM.effective())
        assertEquals(FontPresetId.NORMAL_SANS, FontPresetId.GLOVERLEY.effective())
        assertEquals(FontPresetId.NORMAL_SANS, FontPresetId.THE_BROTHER_HOOPS.effective())
    }
}
