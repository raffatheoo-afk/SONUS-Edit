package com.sonusstudios.sonusedit.create

import org.junit.Assert.assertEquals
import org.junit.Test

class Code07CaptionPositionTest {
    @Test fun portraitDefaultsToMiddleAndLandscapeDefaultsToBottom() {
        assertEquals(0.52f, CaptionLookPrefs.defaultPosition(CaptionLookPrefs.FLOW, ProjectAspectRatios.VERTICAL), 0.001f)
        assertEquals(0.12f, CaptionLookPrefs.defaultPosition(CaptionLookPrefs.FLOW, ProjectAspectRatios.HORIZONTAL), 0.001f)
        assertEquals(0.52f, CaptionLookPrefs.defaultPosition(CaptionLookPrefs.AUTO, ProjectAspectRatios.VERTICAL), 0.001f)
        assertEquals(0.12f, CaptionLookPrefs.defaultPosition(CaptionLookPrefs.AUTO, ProjectAspectRatios.HORIZONTAL), 0.001f)
    }
}
