package com.sonusstudios.sonusedit.create

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class Code24LyricPaletteTest {
    @Test fun dynamicUsesAllNinePreviousColors() {
        val sequence = (0 until 9).map { LyricColorPalette24.argb(LyricColorPreset.DYNAMIC, it) }
        assertEquals(9, LyricColorPalette24.dynamicColorCount())
        assertEquals(9, sequence.toSet().size)
        val previousOptions = listOf(
            LyricColorPreset.WHITE, LyricColorPreset.YELLOW, LyricColorPreset.ORANGE,
            LyricColorPreset.RED, LyricColorPreset.PINK, LyricColorPreset.PURPLE,
            LyricColorPreset.BLUE, LyricColorPreset.CYAN, LyricColorPreset.GREEN,
        ).map { LyricColorPalette24.argb(it, 0) }
        assertEquals(previousOptions.toSet(), sequence.toSet())
        assertEquals(sequence.first(), LyricColorPalette24.argb(LyricColorPreset.DYNAMIC, 9))
    }

    @Test fun blackIsSelectableButExcludedFromDynamic() {
        val black = LyricColorPalette24.argb(LyricColorPreset.BLACK, 0)
        assertEquals(0xFF000000.toInt(), black)
        assertFalse((0 until 9).map { LyricColorPalette24.argb(LyricColorPreset.DYNAMIC, it) }.contains(black))
        assertNotEquals(black, LyricColorPalette24.argb(LyricColorPreset.WHITE, 0))
    }

    @Test fun staticColorsIgnoreCaptionIndex() {
        val presets = LyricColorPreset.entries.filter { it != LyricColorPreset.DYNAMIC }
        assertTrue(presets.isNotEmpty())
        presets.forEach { color ->
            assertEquals(LyricColorPalette24.argb(color, 0), LyricColorPalette24.argb(color, 15))
        }
    }
}
