package com.sonusstudios.sonusedit.create

import com.sonusstudios.sonusedit.catalog.PCloudAsset
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MusicImageKeywordCatalog13Test {
    private val catalog = MusicImageKeywordCatalog.parse(
        "religious|gospel;catolico|jesus;nossa senhora;cristo|igreja;jesus;cruz\n" +
            "romantic|romantico;romantica|amor;paixao|casal;flores;beijo\n" +
            "city_night|city pop|cidade;noite|cidade;skyline;neon"
    )

    @Test fun religiousContextRequiresReligiousTitleOrGenre() {
        assertTrue(catalog.classify("Nossa Senhora Aparecida", "Sertanejo").isReligious)
        assertTrue(catalog.classify("Noite de Louvor", "Pop").isReligious)
        assertFalse(catalog.classify("Noite de Amor", "Romântico").isReligious)
    }

    @Test fun explicitReligiousAssetsAreRecognizedForAutomaticGate() {
        val context = catalog.classify("Noite de Amor", "Romântico")
        assertTrue(context.isReligiousAsset(PCloudAsset(1L, "igreja_noite.jpg", folderPath = "Gospel")))
        assertFalse(context.isReligiousAsset(PCloudAsset(2L, "casal_na_cidade.jpg", folderPath = "Romantico")))
    }

    @Test fun genericWordsDoNotClassifyNeutralAssetsAsReligious() {
        val context = catalog.classify("Noite de Amor", "Romântico")
        assertFalse(context.isReligiousAsset(PCloudAsset(4L, "santa_monica_city.jpg", folderPath = "Cidade")))
        assertFalse(context.isReligiousAsset(PCloudAsset(5L, "ceu_azul_noite.jpg", folderPath = "Paisagem")))
        assertTrue(context.isReligiousAsset(PCloudAsset(6L, "igreja_noite.jpg", folderPath = "Centro")))
    }

    @Test fun manualSearchSupportsCommonPortugueseInflections() {
        val assets = listOf(
            PCloudAsset(1L, "cidades_a_noite.jpg"),
            PCloudAsset(2L, "musica_romantica.jpg"),
            PCloudAsset(3L, "sertaneja_no_ceu.jpg"),
        )
        assertEquals(1L, SmartImageSelector.searchManualGallery(assets, "cidade noite").single().fileId)
        assertEquals(2L, SmartImageSelector.searchManualGallery(assets, "romantico").single().fileId)
        assertEquals(3L, SmartImageSelector.searchManualGallery(assets, "sertanejo").single().fileId)
    }

    @Test fun automaticSelectionDoesNotLeakReligiousAssetsIntoNonReligiousTrack() {
        val assets = listOf(
            PCloudAsset(1L, "jesus_cristo.jpg", folderPath = "Gospel"),
            PCloudAsset(2L, "casal_flores.jpg", folderPath = "Romantico"),
        )
        val context = catalog.classify("Noite de Amor", "Romântico")
        val selected = SmartImageSelector.select(
            assets = assets, metadata = AudioMetadata("Noite de Amor", null, 60_000L, genre = "Romântico"),
            syncedLyrics = null, count = 2, recentKeys = emptySet(), nonce = 7, musicContext = context,
        )
        assertTrue(selected.none { it.fileId == 1L })
        assertTrue(selected.any { it.fileId == 2L })
    }
}
