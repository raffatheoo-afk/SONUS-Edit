package com.sonusstudios.sonusedit.create

import com.sonusstudios.sonusedit.catalog.PCloudAsset
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class Code29FontAndImageRotationTest {
    @Test fun expandedFontPoolKeepsLegacyAndIncludesNormalFaces() {
        assertTrue(FontPresetId.entries.size >= 40)
        assertTrue(FontPresetId.NORMAL_SANS in FontPresetId.entries)
        assertTrue(FontPresetId.NORMAL_SERIF in FontPresetId.entries)
        assertEquals("Patrick Hand", FontPresetId.DEFAULT.label)
        // CODE06 offers 30 natural built-in Android typeface variants without bundled assets.
        assertEquals(30, CaptionFontPool.approved.size)
        assertTrue(CaptionFontPool.approved.all { it.systemTypefaceName != null && it.assetFileName == null })
    }

    @Test fun recentImagesAreAvoidedWhenEnoughFreshImagesExist() {
        val assets = (1L..12L).map { PCloudAsset(fileId = it, name = "image_$it.jpg", sourcePublicCode = "catalog") }
        val recent = assets.take(6).map { it.stableKey }.toSet()
        val selected = SmartImageSelector.select(
            assets = assets,
            metadata = null,
            syncedLyrics = null,
            count = 5,
            recentKeys = recent,
            nonce = 29,
        )
        assertEquals(5, selected.size)
        assertFalse(selected.any { it.stableKey in recent })
    }
}
