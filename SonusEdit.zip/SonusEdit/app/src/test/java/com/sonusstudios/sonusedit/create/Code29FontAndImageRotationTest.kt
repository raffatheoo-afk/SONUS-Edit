package com.sonusstudios.sonusedit.create

import com.sonusstudios.sonusedit.catalog.PCloudAsset
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class Code29FontAndImageRotationTest {
    @Test fun expandedFontPoolKeepsLegacyAndIncludesNormalFaces() {
        assertTrue(FontPresetId.entries.size >= 40)
        assertTrue(FontPresetId.NORMAL_SANS in FontPresetId.entries)
        assertTrue(FontPresetId.NORMAL_SERIF in FontPresetId.entries)
        assertEquals("Patrick Hand", FontPresetId.DEFAULT.label)
        // CODE07 restores the CODE05 pool: 10 bundled custom fonts plus Sans-serif.
        assertEquals(11, CaptionFontPool.approved.size)
        assertEquals(10, CaptionFontPool.approved.count { it.assetFileName != null })
        assertTrue(CaptionFontPool.approved.all { it.assetFileName != null || it.systemTypefaceName != null })
    }

    @Test fun recentImagesAreAvoidedWhenEnoughFreshImagesExist() {
        val assets = (1L..12L).map { PCloudAsset(fileId = it, name = "image_$it.jpg", sourcePublicCode = "catalog") }
        val recent = assets.take(6).map { it.stableKey }.toSet()
        val selected = SmartImageSelector.select(
            assets = assets,
            metadata = null,
            syncedLyrics = null,
            count = 5,
            recentKeys = recent,
            nonce = 29,
        )
        assertEquals(5, selected.size)
        assertFalse(selected.any { it.stableKey in recent })
    }
}
