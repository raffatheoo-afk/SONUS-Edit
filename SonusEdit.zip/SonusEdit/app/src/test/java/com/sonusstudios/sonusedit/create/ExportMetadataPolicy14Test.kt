package com.sonusstudios.sonusedit.create

import org.junit.Assert.assertEquals
import org.junit.Test

class ExportMetadataPolicy14Test {
    @Test fun clearingBothReviewFieldsNeverRestoresMetadataFallback() {
        assertEquals("", ExportMetadataPolicy.resolveTitle("", "Original title", manuallyEdited = true))
        assertEquals("", ExportMetadataPolicy.resolveArtist("", "Original artist", manuallyEdited = true))
    }

    @Test fun clearingOnlyOneFieldDoesNotRestoreThatField() {
        assertEquals("", ExportMetadataPolicy.resolveTitle("", "Original title", manuallyEdited = true))
        assertEquals("Original artist", ExportMetadataPolicy.resolveArtist("", "Original artist", manuallyEdited = false))
    }

    @Test fun untouchedFieldsKeepTheirAutomaticFallback() {
        assertEquals("Original title", ExportMetadataPolicy.resolveTitle("", "Original title", manuallyEdited = false))
        assertEquals("Original artist", ExportMetadataPolicy.resolveArtist("", "Original artist", manuallyEdited = false))
    }
}
