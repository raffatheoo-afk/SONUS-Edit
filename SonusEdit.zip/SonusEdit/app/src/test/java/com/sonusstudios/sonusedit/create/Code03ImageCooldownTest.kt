package com.sonusstudios.sonusedit.create

import com.sonusstudios.sonusedit.catalog.PCloudAsset
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class Code03ImageCooldownTest {
    private val assets = (1L..8L).map { id ->
        PCloudAsset(fileId = id, name = "city_$id.jpg", sourcePublicCode = "gallery-a")
    }

    @Test
    fun `automatic selection never reuses one of the four recent project assets`() {
        val blocked = assets.take(4).map { it.stableKey }.toSet()
        val selected = SmartImageSelector.select(
            assets = assets,
            metadata = null,
            syncedLyrics = null,
            count = 5,
            recentKeys = blocked,
            nonce = 123,
        )
        assertTrue(selected.none { it.stableKey in blocked })
        assertEquals(setOf(5L, 6L, 7L, 8L), selected.map { it.fileId }.toSet())
    }

    @Test
    fun `manual search also hides assets in the four project cooldown`() {
        val blocked = setOf(assets.first().stableKey)
        val found = SmartImageSelector.searchManualGallery(assets, "city", blocked)
        assertEquals((2L..8L).toSet(), found.map { it.fileId }.toSet())
    }

    @Test
    fun `selection returns fewer assets instead of silently reusing blocked assets`() {
        val blocked = assets.take(7).map { it.stableKey }.toSet()
        val selected = SmartImageSelector.select(
            assets = assets,
            metadata = null,
            syncedLyrics = null,
            count = 5,
            recentKeys = blocked,
            nonce = 456,
        )
        assertEquals(listOf(8L), selected.map { it.fileId })
    }
}
