package com.sonusstudios.sonusedit.create

import org.junit.Assert.assertEquals
import org.junit.Test

class ExportMetadataPolicy13Test {
    @Test fun intentionallyClearedTitleAndArtistStayBlank() {
        assertEquals("", ExportMetadataPolicy.resolveTitle("", "Original song", true))
        assertEquals("", ExportMetadataPolicy.resolveArtist("", "Original artist", true))
    }

    @Test fun untouchedFieldsStillUseMetadataFallback() {
        assertEquals("Original song", ExportMetadataPolicy.resolveTitle("", "Original song", false))
        assertEquals("Original artist", ExportMetadataPolicy.resolveArtist("", "Original artist", false))
    }
}
