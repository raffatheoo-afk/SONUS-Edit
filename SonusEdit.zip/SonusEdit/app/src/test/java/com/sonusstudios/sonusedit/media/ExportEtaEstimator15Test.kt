package com.sonusstudios.sonusedit.media

import com.sonusstudios.sonusedit.create.CreateProjectDraft
import com.sonusstudios.sonusedit.create.FontPresetId
import com.sonusstudios.sonusedit.stats.ExportTimingSample
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExportEtaEstimator15Test {
    private fun draft() = CreateProjectDraft(
        audioUri = "file:///audio.mp3",
        audioTitle = "Áudio",
        audioDurationMs = 30_000L,
        segmentStartMs = 0L,
        segmentDurationMs = 30_000L,
        signatureText = "",
        imageUris = listOf("file:///one.jpg"),
        fontPreset = FontPresetId.DEFAULT,
    )

    private fun samples(count: Int = 5) = (0 until count).map { index ->
        ExportTimingSample(
            timestampMs = index.toLong() + 1L,
            videoDurationMs = 30_000L,
            exportTimeMs = 90_000L,
            outputWidth = 1080,
            outputHeight = 1920,
            fps = 30,
            mediaCount = 1,
            particlesEnabled = false,
        )
    }

    @Test fun `cold start uses the measured benchmark table before any export`() {
        val estimate = ExportEtaEstimator15.expectedTotalMs(draft(), emptyList())
        assertNotNull(estimate)
        assertTrue(estimate!! in 30_000L..90_000L)
    }

    @Test fun `learning starts with the first successful comparable export`() {
        val matchingDraft = draft().copy(exportFps = 30)
        val cold = ExportEtaEstimator15.expectedTotalMs(matchingDraft, emptyList())!!
        val learned = ExportEtaEstimator15.expectedTotalMs(matchingDraft, samples(1))!!
        assertTrue(learned > 0L)
        assertTrue(learned != cold)
    }

    @Test fun `controlled measurements remain exact even when a longer clip exported faster`() {
        val base = draft().copy(
            exportResolution = com.sonusstudios.sonusedit.create.ExportResolution.P720,
            exportFps = 30,
        )
        val at30 = ExportEtaEstimator15.expectedTotalMs(base.copy(segmentDurationMs = 30_000L), emptyList())!!
        val at35 = ExportEtaEstimator15.expectedTotalMs(base.copy(segmentDurationMs = 35_000L), emptyList())!!
        val at40 = ExportEtaEstimator15.expectedTotalMs(base.copy(segmentDurationMs = 40_000L), emptyList())!!
        assertEquals(39_000L, at30)
        assertEquals(32_500L, at35)
        assertEquals(26_000L, at40)
    }

    @Test fun `samples from a different landscape ratio do not train this export profile`() {
        val customDraft = draft().copy(
            aspectRatio = "3:2",
            customOutputWidth = 1920,
            customOutputHeight = 1280,
            segmentDurationMs = 30_000L,
            exportFps = 30,
        )
        val otherRatio = ExportTimingSample(
            timestampMs = 1L,
            videoDurationMs = 30_000L,
            exportTimeMs = 180_000L,
            outputWidth = 1920,
            outputHeight = 1080,
            fps = 30,
            mediaCount = 1,
            particlesEnabled = false,
            aspectRatio = "16:9",
        )
        val baseline = ExportEtaEstimator15.expectedTotalMs(customDraft, emptyList())
        val afterOtherRatio = ExportEtaEstimator15.expectedTotalMs(customDraft, listOf(otherRatio))
        assertEquals(baseline, afterOtherRatio)
    }

    @Test fun `missing 4k60 sixty second result uses a cold start estimate without failed sample`() {
        val fourK60 = draft().copy(
            segmentDurationMs = 60_000L,
            exportResolution = com.sonusstudios.sonusedit.create.ExportResolution.P4K,
            exportFps = 60,
        )
        val estimate = ExportEtaEstimator15.expectedTotalMs(fourK60, emptyList())
        assertNotNull(estimate)
        assertTrue(estimate!! > 172_000L)
    }

    @Test fun `fallback estimate adds the new attempt after time already spent`() {
        val combined = ExportEtaEstimator15.totalAfterFallback(180_000L, 74_000L)
        assertEquals(254_000L, combined)
        assertEquals(74_000L, ExportEtaEstimator15.remainingMs(combined, 180_000L))
    }

    @Test fun `remaining estimate never reaches zero before save callback`() {
        val estimate = ExportEtaEstimator15.expectedTotalMs(draft(), samples())!!
        assertEquals(1_000L, ExportEtaEstimator15.remainingMs(estimate, estimate + 60_000L))
        assertTrue(ExportEtaEstimator15.remainingMs(estimate, 10_000L)!! > 0L)
        assertNull(ExportEtaEstimator15.remainingMs(null, 10_000L))
        assertEquals(50, ExportEtaEstimator15.progressPercent(100_000L, 50_000L))
        assertEquals(99, ExportEtaEstimator15.progressPercent(100_000L, 150_000L))
        assertEquals(100, ExportEtaEstimator15.progressPercent(100_000L, 150_000L, completed = true))
    }
}
