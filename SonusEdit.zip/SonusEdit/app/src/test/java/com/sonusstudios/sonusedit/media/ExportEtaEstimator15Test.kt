package com.sonusstudios.sonusedit.media

import com.sonusstudios.sonusedit.create.CreateProjectDraft
import com.sonusstudios.sonusedit.create.FontPresetId
import com.sonusstudios.sonusedit.stats.ExportTimingSample
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExportEtaEstimator15Test {
    private fun draft() = CreateProjectDraft(
        audioUri = "file:///audio.mp3",
        audioTitle = "Áudio",
        audioDurationMs = 30_000L,
        segmentStartMs = 0L,
        segmentDurationMs = 30_000L,
        signatureText = "",
        imageUris = listOf("file:///one.jpg"),
        fontPreset = FontPresetId.DEFAULT,
    )

    private fun samples(count: Int = 5) = (0 until count).map { index ->
        ExportTimingSample(
            timestampMs = index.toLong() + 1L,
            videoDurationMs = 30_000L,
            exportTimeMs = 90_000L,
            outputWidth = 1080,
            outputHeight = 1920,
            fps = 30,
            mediaCount = 1,
            particlesEnabled = false,
        )
    }

    @Test fun `eta stays unavailable before five successful exports`() {
        assertNull(ExportEtaEstimator15.expectedTotalMs(draft(), samples(4)))
    }

    @Test fun `eta is based on the last five or more successful export samples`() {
        val estimate = ExportEtaEstimator15.expectedTotalMs(draft(), samples())
        assertNotNull(estimate)
        assertEquals(90_000L, estimate)
    }

    @Test fun `remaining estimate never reaches zero before save callback`() {
        val estimate = ExportEtaEstimator15.expectedTotalMs(draft(), samples())!!
        assertEquals(1_000L, ExportEtaEstimator15.remainingMs(estimate, estimate + 60_000L))
        assertTrue(ExportEtaEstimator15.remainingMs(estimate, 10_000L)!! > 0L)
        assertNull(ExportEtaEstimator15.remainingMs(null, 10_000L))
    }
}
