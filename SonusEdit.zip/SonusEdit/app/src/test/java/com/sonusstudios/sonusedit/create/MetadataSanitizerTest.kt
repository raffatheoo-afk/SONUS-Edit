package com.sonusstudios.sonusedit.create

import org.junit.Assert.assertEquals
import org.junit.Test

class MetadataSanitizerTest {
    @Test
    fun `cleans provider noise and duplicated artist without affecting caption engine`() {
        val clean = MetadataSanitizer.clean(
            "Marília Mendonça - Infiel (Vídeo Oficial)",
            "Marília Mendonça",
        )
        assertEquals("Infiel", clean.title)
        assertEquals("Marília Mendonça", clean.artist)
    }

    @Test
    fun `removes common platform suffixes`() {
        assertEquals("Infiel", MetadataSanitizer.clean("Infiel - Official Audio", "Marília Mendonça").title)
    }
}
