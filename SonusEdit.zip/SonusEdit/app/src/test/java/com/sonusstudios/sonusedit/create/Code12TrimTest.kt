package com.sonusstudios.sonusedit.create

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class Code12TrimTest {
    @Test fun presetAndManualEndAreIndependent() {
        assertEquals(90_000L, SegmentTrimPlanner12.endMs(180_000L,60_000L,30,false,null))
        assertEquals(92_000L, SegmentTrimPlanner12.endMs(180_000L,60_000L,30,false,92_000L))
        assertEquals(180_000L, SegmentTrimPlanner12.endMs(180_000L,60_000L,30,true,null))
        assertEquals(92_000L, SegmentTrimPlanner12.endMs(180_000L,60_000L,30,true,92_000L))
    }
    @Test fun trimMustStayInsideSource() {
        assertEquals(90_000L, SegmentTrimPlanner12.endMs(90_000L,75_000L,30,false,null))
        assertEquals(76_000L, SegmentTrimPlanner12.endMs(90_000L,75_000L,30,false,70_000L))
        assertEquals(75_000L, SegmentTrimPlanner12.maxStartMs(180_000L,30,false,76_000L))
    }
    @Test fun proportionalMediaCountsAndDurations() {
        assertEquals(6, MediaDistributionPlanner.maxImagesForDurationMs(30_000L))
        assertEquals(6, MediaDistributionPlanner.maxImagesForDurationMs(32_000L))
        assertEquals(7, MediaDistributionPlanner.maxImagesForDurationMs(34_000L))
        val segment = MediaDistributionPlanner.durationsForTotalMs(34_000L,7)
        assertEquals(34_000L, segment.sum())
        assertTrue(segment.maxOrNull()!! - segment.minOrNull()!! <= 1L)
    }
}
