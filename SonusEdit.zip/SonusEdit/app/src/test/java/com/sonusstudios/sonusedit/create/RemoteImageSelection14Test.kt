package com.sonusstudios.sonusedit.create

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RemoteImageSelection14Test {
    @Test fun differentPublicCatalogsNeverShareAFileIdUrl() {
        val keys = listOf("publicA:42", "publicB:42")
        val migrated = RemoteImageSelection14.migrateLegacyUrls(keys, mapOf(42L to "https://cdn/a.jpg"))
        assertTrue(migrated.isEmpty())
        assertEquals(listOf(42L), RemoteImageSelection14.fileIds(keys))
    }

    @Test fun uniqueLegacyIdentityMigratesSafely() {
        assertEquals(
            mapOf("publicA:42" to "https://cdn/a.jpg"),
            RemoteImageSelection14.migrateLegacyUrls(listOf("publicA:42"), mapOf(42L to "https://cdn/a.jpg")),
        )
    }

    @Test fun historyIncludesOnlySelectedStableKeysWhoseUrisAreInDraft() {
        val selected = listOf("publicA:42", "publicB:42", "publicA:43")
        val urls = mapOf("publicA:42" to "https://cdn/a.jpg", "publicB:42" to "https://cdn/b.jpg")
        assertEquals(
            listOf("publicB:42"),
            RemoteImageSelection14.historyKeys(selected, urls, listOf("https://cdn/b.jpg")),
        )
    }

    @Test fun pendingKeysAreStableIdentityBased() {
        assertEquals(
            setOf("publicB:42"),
            RemoteImageSelection14.pendingKeys(listOf("publicA:42", "publicB:42"), mapOf("publicA:42" to "https://cdn/a.jpg")),
        )
    }

    @Test fun ambiguousIdsAreOmittedFromLegacyProjection() {
        assertTrue(RemoteImageSelection14.legacyProjection(mapOf(
            "publicA:42" to "https://cdn/a.jpg", "publicB:42" to "https://cdn/b.jpg",
        )).isEmpty())
        assertFalse(RemoteImageSelection14.legacyProjection(mapOf("publicA:42" to "https://cdn/a.jpg")).isEmpty())
    }
}
