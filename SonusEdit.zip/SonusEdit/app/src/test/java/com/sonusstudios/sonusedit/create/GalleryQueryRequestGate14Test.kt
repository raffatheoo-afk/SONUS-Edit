package com.sonusstudios.sonusedit.create

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GalleryQueryRequestGate14Test {
    @Test fun sameQueryFromOlderRequestCannotOverwriteNewerRequest() {
        assertFalse(GalleryQueryRequestGate14.canPublish("cidade", "cidade", "9:16", "9:16", 4L, 5L))
        assertTrue(GalleryQueryRequestGate14.canPublish("cidade", "cidade", "9:16", "9:16", 5L, 5L))
    }

    @Test fun queryAndAspectMustAlsoMatch() {
        assertFalse(GalleryQueryRequestGate14.canPublish("cidade", "noite", "9:16", "9:16", 5L, 5L))
        assertFalse(GalleryQueryRequestGate14.canPublish("cidade", "cidade", "16:9", "9:16", 5L, 5L))
    }
}
