#version 100
precision highp float;

uniform sampler2D uTexSampler;
uniform vec2 uTexelSize;
uniform float uSharpen;
uniform float uContrast;
uniform float uSaturation;
uniform float uBrightness;
uniform float uBlackPoint;
uniform float uTemperature;
varying vec2 vTexSamplingCoord;

void main() {
    vec4 src = texture2D(uTexSampler, vTexSamplingCoord);
    vec3 center = src.rgb;

    if (uSharpen > 0.001) {
        vec3 left  = texture2D(uTexSampler, vTexSamplingCoord + vec2(-uTexelSize.x, 0.0)).rgb;
        vec3 right = texture2D(uTexSampler, vTexSamplingCoord + vec2( uTexelSize.x, 0.0)).rgb;
        vec3 up    = texture2D(uTexSampler, vTexSamplingCoord + vec2(0.0, -uTexelSize.y)).rgb;
        vec3 down  = texture2D(uTexSampler, vTexSamplingCoord + vec2(0.0,  uTexelSize.y)).rgb;
        center = clamp(center * (1.0 + 4.0 * uSharpen) - (left + right + up + down) * uSharpen, 0.0, 1.0);
    }

    float luma = dot(center, vec3(0.2126, 0.7152, 0.0722));
    center = mix(vec3(luma), center, uSaturation);
    center = (center - vec3(0.5)) * uContrast + vec3(0.5 + uBrightness);
    if (uBlackPoint > 0.0001) {
        center = max(center - vec3(uBlackPoint), vec3(0.0)) / (1.0 - uBlackPoint);
    }
    // Small red/blue balance used only by the explicit warm/cool presets. Keeping the range
    // narrow prevents skin tones and highlights from becoming artificial.
    center.r += uTemperature;
    center.b -= uTemperature;
    center.g += uTemperature * 0.12;
    gl_FragColor = vec4(clamp(center, 0.0, 1.0), src.a);
}
