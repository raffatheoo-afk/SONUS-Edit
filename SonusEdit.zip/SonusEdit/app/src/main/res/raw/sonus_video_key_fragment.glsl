#version 100
precision highp float;

uniform sampler2D uTexSampler;
uniform float uMode;      // 0.0 = green chroma key, 1.0 = black/luma key
uniform float uOpacity;
varying vec2 vTexSamplingCoord;

void main() {
    vec4 src = texture2D(uTexSampler, vTexSamplingCoord);
    vec3 c = src.rgb;
    float alpha;
    float brightness = max(c.r, max(c.g, c.b));

    if (uMode < 0.5) {
        // Original 60 fps source: green chroma background around sRGB (45,122,41).
        // Compression moves many background pixels away from the exact key colour, so distance
        // alone leaves a pale veil. code19 combines exact-key distance, green dominance and a
        // minimum particle signal. This removes the haze while retaining bright particle edges.
        vec3 key = vec3(0.0262412, 0.1946178, 0.0221739);
        float keyDistance = distance(c, key);
        float distanceAlpha = smoothstep(0.040, 0.165, keyDistance);
        float greenDominance = c.g - max(c.r, c.b);
        float dominanceAlpha = 1.0 - smoothstep(0.030, 0.105, greenDominance);
        float signalAlpha = smoothstep(0.165, 0.300, brightness);
        alpha = distanceAlpha * dominanceAlpha * signalAlpha;
        if (alpha < 0.018) alpha = 0.0;

        // Despill by rendering only neutral luminance for the surviving particle. Background
        // pixels receive zero alpha instead of becoming semi-transparent grey/white smoke.
        float neutral = clamp(brightness, 0.0, 1.0);
        gl_FragColor = vec4(vec3(neutral), alpha * uOpacity);
    } else {
        // Black source: luma/brightness key is cleaner and cheaper than chroma key.
        // Near-black compression noise disappears; the natural soft glow is retained in alpha.
        alpha = smoothstep(0.010, 0.240, brightness);
        float neutral = clamp(brightness, 0.0, 1.0);
        gl_FragColor = vec4(vec3(neutral), alpha * uOpacity);
    }
}
