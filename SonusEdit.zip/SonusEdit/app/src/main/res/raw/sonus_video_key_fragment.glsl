#version 100
precision highp float;

uniform sampler2D uTexSampler;
uniform float uMode;      // 0/1 = unchanged bundled sources, 2/3 = cloud-optimized keys
uniform float uOpacity;
varying vec2 vTexSamplingCoord;

void main() {
    vec4 src = texture2D(uTexSampler, vTexSamplingCoord);
    vec3 c = src.rgb;
    float alpha;
    float brightness = max(c.r, max(c.g, c.b));

    if (uMode < 0.5) {
        // Original 60 fps source: green chroma background around sRGB (45,122,41).
        // Compression moves many background pixels away from the exact key colour, so distance
        // alone leaves a pale veil. code19 combines exact-key distance, green dominance and a
        // minimum particle signal. This removes the haze while retaining bright particle edges.
        vec3 key = vec3(0.0262412, 0.1946178, 0.0221739);
        float keyDistance = distance(c, key);
        float distanceAlpha = smoothstep(0.040, 0.165, keyDistance);
        float greenDominance = c.g - max(c.r, c.b);
        float dominanceAlpha = 1.0 - smoothstep(0.030, 0.105, greenDominance);
        float signalAlpha = smoothstep(0.165, 0.300, brightness);
        alpha = distanceAlpha * dominanceAlpha * signalAlpha;
        if (alpha < 0.018) alpha = 0.0;

        // Despill by rendering only neutral luminance for the surviving particle. Background
        // pixels receive zero alpha instead of becoming semi-transparent grey/white smoke.
        float neutral = clamp(brightness, 0.0, 1.0);
        gl_FragColor = vec4(vec3(neutral), alpha * uOpacity);
    } else if (uMode < 1.5) {
        // Original bundled black-background source. Keep its established appearance unchanged.
        alpha = smoothstep(0.010, 0.240, brightness);
        float neutral = clamp(brightness, 0.0, 1.0);
        gl_FragColor = vec4(vec3(neutral), alpha * uOpacity);
    } else if (uMode < 2.5) {
        // Cloud green-screen assets vary more in compression and key shade than the two bundled
        // sources. Tighten background rejection and remove the green tint before compositing.
        vec3 key = vec3(0.0262412, 0.1946178, 0.0221739);
        float keyDistance = distance(c, key);
        float distanceAlpha = smoothstep(0.055, 0.195, keyDistance);
        float greenDominance = c.g - max(c.r, c.b);
        float dominanceAlpha = 1.0 - smoothstep(0.040, 0.120, greenDominance);
        float signalAlpha = smoothstep(0.190, 0.335, brightness);
        alpha = distanceAlpha * dominanceAlpha * signalAlpha;
        if (alpha < 0.035) alpha = 0.0;
        float neutral = clamp((brightness - 0.025) * 1.08, 0.0, 1.0);
        gl_FragColor = vec4(vec3(neutral), alpha * uOpacity);
    } else {
        // Cloud black/luma assets often carry compression haze. Discard dark grey shadows, then
        // lift the remaining particle signal so the effect contributes light instead of a dark veil.
        alpha = smoothstep(0.105, 0.315, brightness);
        alpha = pow(alpha, 1.15);
        if (brightness < 0.105) alpha = 0.0;
        vec3 lifted = clamp((c - vec3(0.035)) * 1.28, 0.0, 1.0);
        gl_FragColor = vec4(lifted, alpha * uOpacity);
    }
}
