package com.sonusstudios.sonusedit.create

/** Pure preview-window rules for the music trim controls (0.0.4/code04). */
object TrimPreviewPlanner04 {
    fun startPreviewPosition(startMs: Long, endMs: Long): Long = startMs.coerceIn(0L, endMs.coerceAtLeast(0L))

    fun endPreviewPosition(startMs: Long, endMs: Long): Long {
        val safeStart = startMs.coerceAtLeast(0L)
        val safeEnd = endMs.coerceAtLeast(safeStart)
        return (safeEnd - 5_000L).coerceAtLeast(safeStart)
    }

    /** Stop a few milliseconds before the end so playback cannot leak past the trim boundary. */
    fun shouldStop(currentPositionMs: Long, endMs: Long): Boolean = currentPositionMs >= (endMs - 35L).coerceAtLeast(0L)
}
