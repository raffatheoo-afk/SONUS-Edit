package com.sonusstudios.sonusedit.media

import android.content.Context
import android.graphics.Typeface
import com.sonusstudios.sonusedit.create.FontPresetId
import com.sonusstudios.sonusedit.create.effective

/** Android typeface for a caption font; retired fonts resolve to their approved replacement. */
object CaptionTypefaces {
    private val cache = HashMap<FontPresetId, Typeface>()

    fun resolve(context: Context, requested: FontPresetId): Typeface = synchronized(cache) {
        cache.getOrPut(requested) { build(context.applicationContext, requested.effective()) }
    }

    private fun build(context: Context, font: FontPresetId): Typeface {
        val asset = font.assetFileName
        return if (asset != null) {
            runCatching { Typeface.createFromAsset(context.assets, "fonts/$asset") }
                .getOrElse { fallback(font) }
        } else if (font.systemTypefaceName != null) {
            Typeface.create(font.systemTypefaceName, Typeface.NORMAL)
        } else fallback(font)
    }

    private fun fallback(font: FontPresetId): Typeface = when (font) {
        FontPresetId.DEFAULT -> Typeface.create("cursive", Typeface.NORMAL)
        FontPresetId.MODERN -> Typeface.create("sans-serif-black", Typeface.BOLD)
        FontPresetId.ELEGANT -> Typeface.create("sans-serif-condensed-light", Typeface.NORMAL)
        FontPresetId.IMPACT -> Typeface.create("cursive", Typeface.BOLD)
        FontPresetId.HANDWRITTEN -> Typeface.create("sans-serif-medium", Typeface.ITALIC)
        FontPresetId.MINIMAL -> Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
        FontPresetId.NEON -> Typeface.create(Typeface.SERIF, Typeface.ITALIC)
        FontPresetId.RETRO -> Typeface.create("cursive", Typeface.ITALIC)
        else -> Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
    }
}
