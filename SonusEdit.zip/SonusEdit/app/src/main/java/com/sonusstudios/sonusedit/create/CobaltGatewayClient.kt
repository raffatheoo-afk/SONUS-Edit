package com.sonusstudios.sonusedit.create

import android.content.Context
import android.provider.Settings
import android.util.Log
import com.sonusstudios.sonusedit.BuildConfig
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URI
import java.security.MessageDigest
import java.time.YearMonth
import java.time.ZoneOffset
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * SONUS client for the self-hosted Cobalt gateway.
 * The Cobalt API key remains on the gateway server and is never packaged in the Android APK.
 */
internal class CobaltGatewayClient(
    context: Context,
    private val cacheRoot: File,
    private val activeConnections: ConcurrentHashMap<String, HttpURLConnection>,
) {
    data class Result(
        val file: File,
        val normalizedUrl: String,
        val providerLabel: String,
        val displayTitle: String,
        val usageSummary: String,
    )

    private val appContext = context.applicationContext
    private val usagePrefs = appContext.getSharedPreferences(USAGE_PREFS, Context.MODE_PRIVATE)

    suspend fun download(
        normalizedUrl: String,
        providerLabel: String,
        onProgress: (String, Int?, String) -> Unit,
    ): Result = withContext(Dispatchers.IO) {
        val gatewayBase = normalizeGatewayBase(BuildConfig.SONUS_LINK_GATEWAY_URL)
        if (gatewayBase.isBlank()) {
            throw LinkImportFailure(
                "O serviço Cobalt do SONUS ainda não está conectado. Configure o endereço do servidor SONUS Link Gateway antes de importar links de páginas.",
                suggestLocalMedia = true,
            )
        }

        val processId = "sonus_cobalt_${UUID.randomUUID()}"
        var connection: HttpURLConnection? = null
        var outputFile: File? = null
        var completed = false
        onProgress("Conectando ao SONUS Cobalt…", null, processId)

        try {
            val endpoint = URI.create("$gatewayBase/v1/audio").toURL()
            val request = (endpoint.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = CONNECT_TIMEOUT_MS
                readTimeout = READ_TIMEOUT_MS
                doOutput = true
                useCaches = false
                instanceFollowRedirects = false
                setRequestProperty("User-Agent", USER_AGENT)
                setRequestProperty("Accept", "audio/*,application/octet-stream,application/json")
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("X-Sonus-Install-ID", installId())
            }
            connection = request
            activeConnections[processId] = request
            val body = JSONObject().put("url", normalizedUrl).put("mode", "audio").toString().toByteArray(Charsets.UTF_8)
            request.outputStream.use { it.write(body) }

            val responseCode = request.responseCode
            if (responseCode !in 200..299) {
                val message = readErrorMessage(request, responseCode)
                val retryable = responseCode == 408 || responseCode == 425 || responseCode == 429 || responseCode >= 500
                throw LinkImportFailure(message, retryable, suggestLocalMedia = responseCode == 422 || responseCode == 404)
            }

            val contentType = request.contentType.orEmpty().substringBefore(';').trim().lowercase()
            if (contentType == "application/json" || contentType.contains("text/html")) {
                val bodyText = runCatching { request.inputStream.bufferedReader().use { it.readText() } }.getOrDefault("")
                val message = runCatching { JSONObject(bodyText).optString("message") }.getOrNull().orEmpty()
                throw LinkImportFailure(message.ifBlank { "O servidor Cobalt não retornou um arquivo de áudio válido." }, suggestLocalMedia = true)
            }

            val disposition = request.getHeaderField("Content-Disposition")
            val extension = extensionFromMime(contentType) ?: extensionFromDisposition(disposition)
            if (extension == null) {
                throw LinkImportFailure("O Cobalt retornou um formato de áudio não reconhecido ($contentType).", suggestLocalMedia = true)
            }

            val contentLength = request.contentLengthLong
            if (contentLength == 0L) throw LinkImportFailure("O Cobalt retornou um arquivo vazio.", retryable = true)
            if (contentLength > 0L && contentLength > cacheRoot.usableSpace.coerceAtLeast(0L) - MIN_FREE_SPACE_BYTES) {
                throw LinkImportFailure("Não há espaço livre suficiente para receber o áudio temporariamente.")
            }

            val title = displayNameFromDisposition(disposition)
                ?: runCatching { URI.create(normalizedUrl).path.substringAfterLast('/').substringBeforeLast('.') }
                    .getOrNull()?.replace('_', ' ')?.takeIf { it.isNotBlank() }
                ?: "Áudio importado"
            val token = "cobalt_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(8)}"
            outputFile = File(cacheRoot, "$token.$extension")
            onProgress("Recebendo áudio do Cobalt…", 0, processId)

            val total = contentLength.takeIf { it > 0L } ?: -1L
            var copied = 0L
            BufferedInputStream(request.inputStream).use { input ->
                input.mark(SNIFF_BUFFER_SIZE)
                val prefix = ByteArray(SNIFF_BUFFER_SIZE)
                val prefixLength = input.read(prefix).coerceAtLeast(0)
                input.reset()
                if (looksLikeHtml(prefix, prefixLength)) {
                    throw LinkImportFailure("O servidor Cobalt respondeu com uma página em vez de um arquivo de áudio.", suggestLocalMedia = true)
                }
                FileOutputStream(outputFile).use { output ->
                    val buffer = ByteArray(BUFFER_SIZE)
                    var lastPercent = -1
                    while (true) {
                        val count = input.read(buffer)
                        if (count < 0) break
                        val availableAfterReserve = cacheRoot.usableSpace.coerceAtLeast(0L) - MIN_FREE_SPACE_BYTES
                        if (count.toLong() > availableAfterReserve) {
                            throw LinkImportFailure("O espaço livre ficou insuficiente durante a importação.")
                        }
                        output.write(buffer, 0, count)
                        copied += count
                        if (total > 0L) {
                            val percent = ((copied * 100L) / total).toInt().coerceIn(0, 99)
                            if (percent != lastPercent) {
                                lastPercent = percent
                                onProgress("Recebendo áudio do Cobalt…", percent, processId)
                            }
                        }
                    }
                    output.fd.sync()
                }
            }

            if (!outputFile.isFile || outputFile.length() <= 0L) {
                throw LinkImportFailure("A transferência do Cobalt terminou sem gerar um áudio utilizável.", retryable = true)
            }
            if (total > 0L && outputFile.length() != total) {
                throw LinkImportFailure("A transferência do Cobalt foi interrompida antes de receber o arquivo completo.", retryable = true)
            }

            onProgress("Atualizando contador de usos…", 100, processId)
            val expectedTotal = usagePrefs.getInt(KEY_TOTAL, 0) + 1
            val refreshedUsage = refreshUsage(gatewayBase)
            val usage = if (refreshedUsage != null && usagePrefs.getInt(KEY_TOTAL, 0) >= expectedTotal) {
                refreshedUsage
            } else {
                // The gateway commits its counter at the end of the streamed response. A
                // very fast client can poll a few milliseconds before that commit; keep the
                // UI accurate locally, then let the next sync reconcile with server truth.
                incrementLocalUsage()
            }
            completed = true
            Result(outputFile, normalizedUrl, "Cobalt · $providerLabel", title, usage)
        } catch (error: LinkImportFailure) {
            outputFile?.delete()
            throw error
        } catch (error: SocketTimeoutException) {
            outputFile?.delete()
            throw LinkImportFailure("O Cobalt demorou demais para responder. Tente novamente.", retryable = true, cause = error, suggestLocalMedia = true)
        } catch (error: IOException) {
            outputFile?.delete()
            Log.w(TAG, "Cobalt gateway transfer failed: ${error.javaClass.simpleName}")
            throw LinkImportFailure("Não foi possível receber o áudio do servidor SONUS Cobalt. Verifique a conexão e tente novamente.", retryable = true, cause = error, suggestLocalMedia = true)
        } finally {
            activeConnections.remove(processId)
            if (!completed) runCatching { outputFile?.delete() }
            runCatching { connection?.disconnect() }
        }
    }

    fun currentUsageSummary(): String {
        val total = usagePrefs.getInt(KEY_TOTAL, 0)
        val currentMonth = YearMonth.now(ZoneOffset.UTC).toString()
        val month = if (usagePrefs.getString(KEY_MONTH_KEY, null) == currentMonth) usagePrefs.getInt(KEY_MONTH, 0) else 0
        val limit = usagePrefs.getInt(KEY_LIMIT, 0)
        return if (limit > 0) {
            "Cobalt: $month/$limit usos neste mês • $total no total"
        } else {
            "Cobalt: $month usos neste mês • $total no total"
        }
    }

    suspend fun syncUsageSummary(): String = withContext(Dispatchers.IO) {
        val gatewayBase = runCatching { normalizeGatewayBase(BuildConfig.SONUS_LINK_GATEWAY_URL) }.getOrNull().orEmpty()
        if (gatewayBase.isBlank()) currentUsageSummary() else refreshUsage(gatewayBase) ?: currentUsageSummary()
    }

    private fun refreshUsage(gatewayBase: String): String? {
        var connection: HttpURLConnection? = null
        return try {
            val request = (URI.create("$gatewayBase/v1/usage").toURL().openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = USAGE_TIMEOUT_MS
                readTimeout = USAGE_TIMEOUT_MS
                useCaches = false
                setRequestProperty("Accept", "application/json")
                setRequestProperty("X-Sonus-Install-ID", installId())
                setRequestProperty("User-Agent", USER_AGENT)
            }
            connection = request
            if (request.responseCode !in 200..299) return null
            val json = request.inputStream.bufferedReader().use { JSONObject(it.readText()) }
            val total = json.optInt("total", 0).coerceAtLeast(0)
            val month = json.optInt("month", 0).coerceAtLeast(0)
            val limit = if (json.isNull("monthlyLimit")) 0 else json.optInt("monthlyLimit", 0).coerceAtLeast(0)
            val monthKey = json.optString("monthKey").ifBlank { YearMonth.now(ZoneOffset.UTC).toString() }
            usagePrefs.edit()
                .putInt(KEY_TOTAL, total)
                .putInt(KEY_MONTH, month)
                .putInt(KEY_LIMIT, limit)
                .putString(KEY_MONTH_KEY, monthKey)
                .putBoolean(KEY_SERVER_SYNCED, true)
                .apply()
            currentUsageSummary()
        } catch (error: Exception) {
            Log.w(TAG, "Usage refresh unavailable: ${error.javaClass.simpleName}")
            null
        } finally {
            runCatching { connection?.disconnect() }
        }
    }

    private fun incrementLocalUsage(): String {
        val currentMonth = YearMonth.now(ZoneOffset.UTC).toString()
        val savedMonth = usagePrefs.getString(KEY_MONTH_KEY, null)
        val total = usagePrefs.getInt(KEY_TOTAL, 0) + 1
        val month = if (savedMonth == currentMonth) usagePrefs.getInt(KEY_MONTH, 0) + 1 else 1
        usagePrefs.edit()
            .putInt(KEY_TOTAL, total)
            .putInt(KEY_MONTH, month)
            .putInt(KEY_LIMIT, 0)
            .putString(KEY_MONTH_KEY, currentMonth)
            .putBoolean(KEY_SERVER_SYNCED, false)
            .apply()
        return currentUsageSummary()
    }

    private fun installId(): String {
        val androidId = Settings.Secure.getString(appContext.contentResolver, Settings.Secure.ANDROID_ID)
            ?.takeIf { it.isNotBlank() && it != "9774d56d682e549c" }
            ?: usagePrefs.getString(KEY_FALLBACK_ID, null)
            ?: UUID.randomUUID().toString().also { usagePrefs.edit().putString(KEY_FALLBACK_ID, it).apply() }
        val digest = MessageDigest.getInstance("SHA-256")
            .digest("com.sonusstudios.sonusedit:$androidId".toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    private fun readErrorMessage(connection: HttpURLConnection, code: Int): String {
        val body = runCatching {
            (connection.errorStream ?: connection.inputStream).bufferedReader().use { it.readText() }
        }.getOrDefault("")
        val message = runCatching {
            val json = JSONObject(body)
            json.optString("message").ifBlank { json.optString("error") }
        }.getOrNull().orEmpty()
        return when {
            code == 429 -> message.ifBlank { "Limite de importações atingido. Consulte o contador de usos do SONUS." }
            code == 503 -> message.ifBlank { "O serviço Cobalt está temporariamente indisponível." }
            message.isNotBlank() -> message.take(220)
            else -> "O servidor SONUS Cobalt respondeu com erro HTTP $code."
        }
    }

    private fun normalizeGatewayBase(value: String): String {
        val raw = value.trim().trimEnd('/')
        if (raw.isBlank()) return ""
        val uri = runCatching { URI.create(raw) }.getOrNull()
            ?: throw LinkImportFailure("O endereço do servidor SONUS Cobalt está inválido.")
        if (uri.scheme != "https" || uri.host.isNullOrBlank() || uri.userInfo != null) {
            throw LinkImportFailure("O servidor SONUS Cobalt precisa usar um endereço HTTPS válido.")
        }
        return uri.toASCIIString()
    }

    private fun extensionFromMime(mime: String): String? = MIME_EXTENSIONS[mime]

    private fun extensionFromDisposition(header: String?): String? {
        val name = header.orEmpty().split(';')
            .firstOrNull { it.trim().startsWith("filename=", true) }
            ?.substringAfter('=')?.trim()?.removeSurrounding("\"")?.removeSurrounding("'")
            ?: return null
        val ext = name.substringAfterLast('.', "").lowercase()
        return ext.takeIf { it in SUPPORTED_AUDIO_EXTENSIONS }
    }

    private fun displayNameFromDisposition(header: String?): String? {
        val name = header.orEmpty().split(';')
            .firstOrNull { it.trim().startsWith("filename=", true) }
            ?.substringAfter('=')?.trim()?.removeSurrounding("\"")?.removeSurrounding("'")
            ?: return null
        return name.substringAfterLast('/').substringAfterLast('\\').substringBeforeLast('.')
            .replace('_', ' ').take(120).takeIf { it.isNotBlank() }
    }

    private fun looksLikeHtml(prefix: ByteArray, length: Int): Boolean {
        if (length <= 0) return false
        val sample = prefix.copyOfRange(0, length).toString(Charsets.UTF_8).removePrefix("\uFEFF").trimStart().lowercase()
        return sample.startsWith("<!doctype html") || sample.startsWith("<html") || sample.startsWith("<head") || sample.startsWith("<body")
    }

    companion object {
        private const val TAG = "SONUS-Cobalt"
        private const val USER_AGENT = "SONUS-Edit/1.0.7 (Android; Cobalt Gateway)"
        private const val USAGE_PREFS = "sonus_edit_cobalt_usage"
        private const val KEY_TOTAL = "successful_total"
        private const val KEY_MONTH = "successful_month"
        private const val KEY_LIMIT = "monthly_limit"
        private const val KEY_MONTH_KEY = "month_key"
        private const val KEY_SERVER_SYNCED = "server_synced"
        private const val KEY_FALLBACK_ID = "fallback_install_id"
        private const val CONNECT_TIMEOUT_MS = 20_000
        private const val READ_TIMEOUT_MS = 330_000
        private const val USAGE_TIMEOUT_MS = 5_000
        private const val BUFFER_SIZE = 64 * 1024
        private const val SNIFF_BUFFER_SIZE = 512
        private const val MIN_FREE_SPACE_BYTES = 16L * 1024L * 1024L
        private val SUPPORTED_AUDIO_EXTENSIONS = setOf("m4a", "mp3", "aac", "wav", "ogg", "opus", "webm", "flac", "amr")
        private val MIME_EXTENSIONS = mapOf(
            "audio/mp4" to "m4a", "audio/x-m4a" to "m4a", "audio/mpeg" to "mp3",
            "audio/aac" to "aac", "audio/wav" to "wav", "audio/x-wav" to "wav",
            "audio/ogg" to "ogg", "application/ogg" to "ogg", "audio/opus" to "opus",
            "audio/webm" to "webm", "audio/flac" to "flac",
            "audio/x-flac" to "flac", "audio/amr" to "amr",
        )
    }
}
