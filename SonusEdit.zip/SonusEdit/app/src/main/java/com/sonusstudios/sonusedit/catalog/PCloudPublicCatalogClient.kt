package com.sonusstudios.sonusedit.catalog

import java.net.HttpURLConnection
import java.net.URI
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.concurrent.ExecutorCompletionService
import java.util.concurrent.Executors
import java.util.concurrent.Future
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.longOrNull
import kotlinx.serialization.json.doubleOrNull

class PCloudPublicCatalogClient(
    private val json: Json = Json { ignoreUnknownKeys = true },
) {
    private val bases = listOf("https://api.pcloud.com", "https://eapi.pcloud.com")
    @Volatile private var preferredBase: String? = null

    /** Compatibility helper. A failed request still appears as an empty list to older callers. */
    suspend fun listAssets(publicCode: String): List<PCloudAsset> =
        listAssetsOrNull(publicCode).orEmpty()

    /**
     * Returns null only when the public catalog could not be read/parsed.
     * A successful empty folder returns an actual empty list. This distinction is important for
     * cache safety: a temporary pCloud region failure must never erase the last known-good index.
     */
    suspend fun listAssetsOrNull(publicCode: String): List<PCloudAsset>? = withContext(Dispatchers.IO) {
        val body = requestCatalogRaced("showpublink", mapOf("code" to publicCode)) ?: return@withContext null
        val root = successfulRoot(body) ?: return@withContext null
        val metadata = root["metadata"]?.jsonObject ?: return@withContext null
        buildList { walk(metadata, "", publicCode, this) }.distinctBy { it.stableKey }
    }

    /**
     * Resolve a real public file URL. A HTTP 200 response is NOT considered success by itself:
     * pCloud can answer 200 with a non-zero `result` or without hosts/path on one API region.
     * In that case we immediately try the other official region instead of returning a broken URL.
     */
    suspend fun resolveDownloadUrl(publicCode: String, fileId: Long): String? = withContext(Dispatchers.IO) {
        resolvePublicFileUrl(
            endpoint = "getpublinkdownload",
            params = mapOf("code" to publicCode, "fileid" to fileId.toString()),
        )
    }

    suspend fun resolveThumbnailUrl(publicCode: String, fileId: Long): String? = withContext(Dispatchers.IO) {
        resolvePublicFileUrl(
            endpoint = "getpubthumblink",
            params = mapOf("code" to publicCode, "fileid" to fileId.toString(), "size" to "512x512", "crop" to "1"),
        )
    }

    private fun resolvePublicFileUrl(endpoint: String, params: Map<String, String>): String? {
        val preferred = preferredBase
        val ordered = if (preferred == null) bases else listOf(preferred) + bases.filterNot { it == preferred }
        for (base in ordered) {
            val body = requestOne(base, endpoint, params) ?: continue
            val url = publicFileUrl(body) ?: continue
            preferredBase = base
            return url
        }
        return null
    }

    private fun publicFileUrl(body: String): String? {
        val root = successfulRoot(body) ?: return null
        val host = root["hosts"]?.jsonArray?.firstOrNull()?.jsonPrimitive?.contentOrNull
            ?.trim()?.takeIf { it.isNotBlank() } ?: return null
        val path = root["path"]?.jsonPrimitive?.contentOrNull
            ?.trim()?.takeIf { it.isNotBlank() } ?: return null
        val base = if (host.startsWith("http://") || host.startsWith("https://")) host else "https://$host"
        return "$base$path"
    }

    private fun successfulRoot(body: String): JsonObject? {
        val root = runCatching { json.parseToJsonElement(body).jsonObject }.getOrNull() ?: return null
        val result = root["result"]?.jsonPrimitive?.longOrNull
        return if (result == null || result == 0L) root else null
    }

    private fun walk(node: JsonObject, parent: String, publicCode: String, out: MutableList<PCloudAsset>) {
        val isFolder = node["isfolder"]?.jsonPrimitive?.booleanOrNull == true
        val name = node["name"]?.jsonPrimitive?.content.orEmpty()
        val currentPath = if (name.isBlank()) parent else listOf(parent, name).filter { it.isNotBlank() }.joinToString("/")
        if (!isFolder) {
            val fileId = node["fileid"]?.jsonPrimitive?.longOrNull ?: return
            out += PCloudAsset(
                fileId = fileId,
                name = name,
                size = node["size"]?.jsonPrimitive?.longOrNull ?: 0,
                contentType = node["contenttype"]?.jsonPrimitive?.contentOrNull,
                folderPath = parent,
                modified = node["modified"]?.jsonPrimitive?.contentOrNull,
                durationMs = node["duration"]?.jsonPrimitive?.doubleOrNull?.let { (it * 1000.0).toLong() },
                sourcePublicCode = publicCode,
            )
            return
        }
        val contents = node["contents"] as? JsonArray ?: return
        contents.forEach { child -> (child as? JsonObject)?.let { walk(it, currentPath, publicCode, out) } }
    }

    /**
     * Race both official pCloud regions only for the cold catalog read. Crucially, the winner must
     * be a semantically valid pCloud response (`result` success + metadata), not merely HTTP 200.
     */
    private fun requestCatalogRaced(endpoint: String, params: Map<String, String>): String? {
        val executor = Executors.newFixedThreadPool(bases.size)
        val completion = ExecutorCompletionService<Pair<String, String?>>(executor)
        val futures = mutableListOf<Future<Pair<String, String?>>>()
        return try {
            bases.forEach { base ->
                futures += completion.submit {
                    val body = requestOne(base, endpoint, params)
                    val valid = body?.let { response ->
                        successfulRoot(response)?.get("metadata") is JsonObject
                    } == true
                    base to body?.takeIf { valid }
                }
            }
            repeat(bases.size) {
                val (base, body) = completion.take().get()
                if (body != null) {
                    preferredBase = base
                    return body
                }
            }
            null
        } catch (_: Throwable) {
            null
        } finally {
            futures.forEach { it.cancel(true) }
            executor.shutdownNow()
        }
    }

    private fun requestOne(base: String, endpoint: String, params: Map<String, String>): String? {
        val query = params.entries.joinToString("&") { (k, v) -> "${enc(k)}=${enc(v)}" }
        val connection = (URI.create("$base/$endpoint?$query").toURL().openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 5_000
            readTimeout = 8_000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "Sonus-Edit/1.0 Android")
        }
        return try {
            if (connection.responseCode == HttpURLConnection.HTTP_OK) {
                connection.inputStream.bufferedReader().use { it.readText() }
            } else null
        } catch (_: Throwable) {
            null
        } finally {
            connection.disconnect()
        }
    }

    private fun enc(value: String): String = URLEncoder.encode(value, StandardCharsets.UTF_8.toString())
}

private val kotlinx.serialization.json.JsonPrimitive.contentOrNull: String?
    get() = runCatching { content }.getOrNull()
