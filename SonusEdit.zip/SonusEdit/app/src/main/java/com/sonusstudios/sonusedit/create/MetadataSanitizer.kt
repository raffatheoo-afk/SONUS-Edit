package com.sonusstudios.sonusedit.create

/**
 * Lightweight metadata cleanup used only for display/export names.
 * code18 captions no longer depend on title/artist matching at all.
 */
object MetadataSanitizer {
    data class CleanMetadata(val title: String, val artist: String?)

    private val editorialParenthetical = Regex(
        "(?i)\\s*[\\[(](?:vídeo oficial|video oficial|official video|official audio|official music video|lyric video|lyrics?|visualizer|audio|clipe oficial|hd|4k|1080p|720p)[^\\])]*[\\])]\\s*"
    )
    private val editorialBareSuffix = Regex(
        "(?i)\\s*(?:[-–—|•:]\\s*)?(?:vídeo oficial|video oficial|official video|official audio|official music video|lyric video|lyrics?|visualizer|clipe oficial|hd|4k|1080p|720p)\\s*$"
    )

    fun clean(title: String, artist: String?): CleanMetadata {
        val cleanArtist = artist?.trim()?.takeIf { it.isNotBlank() }
        var text = title
            .substringBeforeLast('.', title)
            .replace(editorialParenthetical, " ")
            .replace(editorialBareSuffix, " ")
            .trim()

        if (!cleanArtist.isNullOrBlank()) {
            val escaped = Regex.escape(cleanArtist)
            text = text
                .replace(Regex("(?i)^$escaped\\s*[-–—|•:]\\s*"), "")
                .replace(Regex("(?i)\\s*[-–—|•:]\\s*$escaped$"), "")
        }

        text = text
            .replace(Regex("\\s+"), " ")
            .trim(' ', '-', '–', '—', '|', '•', ':')
            .ifBlank { title.trim() }

        return CleanMetadata(text, cleanArtist)
    }
}
