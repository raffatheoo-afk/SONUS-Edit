package com.sonusstudios.sonusedit.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonusstudios.sonusedit.create.CaptionLookPrefs
import com.sonusstudios.sonusedit.designsystem.SonusEditColors

private val SliderBlue = Color(0xFF3FA9FF)
private val SliderTrack = Color(0x33FFFFFF)

/**
 * Caption size and caption position sliders, in blue and thinner than the purple player bar so the
 * two controls are never mistaken for the video progress.
 */
@Composable
fun CaptionAdjustSliders(
    sizeScale: Float,
    onSizeScale: (Float) -> Unit,
    positionPercent: Float,
    onPositionPercent: (Float) -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(0.dp)) {
        SliderLine("Tamanho da legenda", sizeLabel(sizeScale), sizeScale, CaptionLookPrefs.MIN_SIZE..CaptionLookPrefs.MAX_SIZE, onSizeScale)
        SliderLine("Posição da legenda", positionLabel(positionPercent), positionPercent, 0f..1f, onPositionPercent)
    }
}

@Composable
private fun SliderLine(
    title: String,
    valueLabel: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit,
) {
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, color = SonusEditColors.TextMuted, fontSize = 10.sp)
            Text(valueLabel, color = SliderBlue, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
        ThinBlueSlider(value, onChange, range)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ThinBlueSlider(
    value: Float,
    onValueChange: (Float) -> Unit,
    range: ClosedFloatingPointRange<Float>,
) {
    Slider(
        value = value.coerceIn(range.start, range.endInclusive),
        onValueChange = onValueChange,
        valueRange = range,
        modifier = Modifier.fillMaxWidth().height(22.dp),
        colors = SliderDefaults.colors(thumbColor = SliderBlue, activeTrackColor = SliderBlue, inactiveTrackColor = SliderTrack),
        thumb = { Box(Modifier.size(14.dp).background(SliderBlue, CircleShape)) },
        track = { state ->
            val span = state.valueRange.endInclusive - state.valueRange.start
            val fraction = if (span <= 0f) 0f else ((state.value - state.valueRange.start) / span).coerceIn(0f, 1f)
            Box(Modifier.fillMaxWidth().height(3.dp).clip(CircleShape).background(SliderTrack)) {
                Box(Modifier.fillMaxWidth(fraction).height(3.dp).background(SliderBlue))
            }
        },
    )
}

private fun sizeLabel(scale: Float): String = when {
    scale < 0.65f -> "Minúsculo"
    scale < 0.9f -> "Pequeno"
    scale < 1.25f -> "Médio"
    scale < 1.7f -> "Grande"
    else -> "Extra grande"
}

private fun positionLabel(percent: Float): String = when {
    percent < 0.18f -> "Embaixo"
    percent < 0.42f -> "Baixo"
    percent < 0.62f -> "Meio"
    percent < 0.85f -> "Alto"
    else -> "Topo"
}
