package com.sonusstudios.sonusedit.create

import android.content.Context

/**
 * Remembers the last caption size, position and (manually chosen) style so the user does not have to
 * set them again for every video. Kept separately for the creation flow and for Legendas automáticas.
 */
object CaptionLookPrefs {
    const val FLOW = "flow"
    const val AUTO = "auto"
    private const val PREFS = "sonus_caption_look_code02"

    const val MIN_SIZE = 0.5f
    const val MAX_SIZE = 2.4f

    /** Landscape 16:9 defaults to bottom; portrait 9:16 defaults to middle. */
    fun defaultPosition(flow: String, aspectRatio: String? = null): Float = when {
        aspectRatio != null && ProjectAspectRatios.isHorizontal(aspectRatio) -> 0.12f
        aspectRatio != null -> 0.52f
        flow == AUTO -> 0.12f
        else -> 0.52f
    }

    private fun prefs(context: Context) = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun sizeScale(context: Context, flow: String): Float =
        prefs(context).getFloat("$flow.size", 1f).coerceIn(MIN_SIZE, MAX_SIZE)

    fun positionPercent(context: Context, flow: String, aspectRatio: String? = null): Float {
        val p = prefs(context)
        val legacy = p.getFloat("$flow.position", defaultPosition(flow, aspectRatio))
        val key = when {
            aspectRatio == null -> "$flow.position"
            ProjectAspectRatios.isHorizontal(aspectRatio) -> "$flow.position.landscape"
            else -> "$flow.position.portrait"
        }
        val fallback = if (aspectRatio != null && ProjectAspectRatios.isHorizontal(aspectRatio)) {
            defaultPosition(flow, aspectRatio)
        } else legacy
        return p.getFloat(key, fallback).coerceIn(0f, 1f)
    }

    fun save(context: Context, flow: String, sizeScale: Float, positionPercent: Float, aspectRatio: String? = null) {
        val normalized = positionPercent.coerceIn(0f, 1f)
        val edit = prefs(context).edit()
            .putFloat("$flow.size", sizeScale.coerceIn(MIN_SIZE, MAX_SIZE))
            .putFloat("$flow.position", normalized)
        when {
            aspectRatio == null -> Unit
            ProjectAspectRatios.isHorizontal(aspectRatio) -> edit.putFloat("$flow.position.landscape", normalized)
            else -> edit.putFloat("$flow.position.portrait", normalized)
        }
        edit.apply()
    }

    /** The style the user picked by hand last time; null means "Dinâmico" (automatic). */
    fun manualStyle(context: Context, flow: String): CaptionStyleId? =
        prefs(context).getString("$flow.style", null)?.let { name -> CaptionStyleId.entries.firstOrNull { it.name == name } }

    fun saveManualStyle(context: Context, flow: String, style: CaptionStyleId?) {
        prefs(context).edit().apply {
            if (style == null) remove("$flow.style") else putString("$flow.style", style.name)
        }.apply()
    }
}
