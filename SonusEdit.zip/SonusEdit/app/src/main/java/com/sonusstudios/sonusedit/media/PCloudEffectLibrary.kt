package com.sonusstudios.sonusedit.media

import android.content.Context
import android.graphics.Color
import android.media.MediaMetadataRetriever
import android.net.Uri
import com.sonusstudios.sonusedit.catalog.PCloudAsset
import com.sonusstudios.sonusedit.catalog.PCloudPublicCatalogClient
import java.io.File
import java.net.HttpURLConnection
import java.net.URI
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json
import kotlin.coroutines.coroutineContext

/**
 * 1.1: public-only SONUS Edit visual overlays. No private pCloud token is used.
 * Files are discovered only after the user chooses audio; no network access on Home.
 * Downloaded MP4s remain local (bounded cache). A damaged/unknown file is never used in export.
 */
class PCloudEffectLibrary(private val context: Context) {
    companion object {
        const val PUBLIC_CODE = "kZ6cTYJZ17xlSBf2QdbwBCvGBonokuAOGiw7"
        private const val PREFIX = "cloud_effect_"
        private const val MAX_FILE_BYTES = 20L * 1024L * 1024L
        private const val MIN_DURATION_MS = 3_000L
        private const val MAX_DURATION_MS = 30_000L
        private const val MAX_CACHE_BYTES = 120L * 1024L * 1024L
        private val filenamePattern = Regex("(?i)\\.mp4$")

        fun idFor(asset: PCloudAsset): String = "$PREFIX${asset.fileId}"
        fun isCloud(id: String): Boolean = id.startsWith(PREFIX) && id.removePrefix(PREFIX).toLongOrNull()?.let { it > 0L } == true
    }

    data class Prepared(val file: File, val mode: RawParticleVideoEffect.Mode, val durationMs: Long)

    private val client = PCloudPublicCatalogClient()
    private val json = Json { ignoreUnknownKeys = true }
    private val prefs = context.getSharedPreferences("sonus_cloud_effects_code11", Context.MODE_PRIVATE)
    private val root = File(context.cacheDir, "sonus_cloud_effects_v1")

    private fun allowed(asset: PCloudAsset): Boolean =
        asset.fileId > 0 && filenamePattern.containsMatchIn(asset.name) &&
            (asset.size <= 0L || asset.size <= MAX_FILE_BYTES) &&
            asset.sourcePublicCode == PUBLIC_CODE

    private fun savedCatalog(): List<PCloudAsset> = runCatching {
        json.decodeFromString<List<PCloudAsset>>(prefs.getString("assets", "[]").orEmpty())
            .filter(::allowed)
    }.getOrDefault(emptyList())

    /** Empty folder is distinct from unreachable pCloud: empty selection => bundled effects only. */
    suspend fun listAvailable(): List<PCloudAsset> {
        val fetched = client.listAssetsOrNull(PUBLIC_CODE)
        if (fetched != null) {
            val eligible = fetched.filter(::allowed)
            prefs.edit().putString("assets", json.encodeToString(eligible)).apply()
            return eligible
        }
        // Network outage: only locally downloaded cached entries remain selectable.
        return savedCatalog().filter { cachedFile(it.fileId).isFile }
    }

    private fun cachedFile(fileId: Long): File = File(root, "overlay_${fileId}.mp4")

    private fun safeDownloadUrl(url: String): Boolean = runCatching {
        val uri = URI.create(url)
        val host = uri.host?.lowercase() ?: return@runCatching false
        uri.scheme.equals("https", ignoreCase = true) && uri.userInfo == null &&
            (host.endsWith(".pcloud.com") || host == "pcloud.com" ||
                host.endsWith(".pcloud.link") || host == "pcloud.link" ||
                host.endsWith(".pcloudcdn.com"))
    }.getOrDefault(false)

    suspend fun prepare(effectId: String): Prepared? = withContext(Dispatchers.IO) {
        val id = effectId.removePrefix(PREFIX).toLongOrNull()?.takeIf { isCloud(effectId) } ?: return@withContext null
        cachedPrepared(effectId)?.let { return@withContext it }
        val asset = savedCatalog().firstOrNull { it.fileId == id }
            ?: client.listAssetsOrNull(PUBLIC_CODE)?.filter(::allowed)?.also {
                prefs.edit().putString("assets", json.encodeToString(it)).apply()
            }?.firstOrNull { it.fileId == id }
            ?: return@withContext null
        if (!allowed(asset)) return@withContext null

        // A half-written download must never be mistaken for a valid effect.
        root.mkdirs()
        val target = cachedFile(id)
        val temp = File(root, "overlay_${id}.${System.nanoTime()}.partial")
        try {
            val downloadUrl = client.resolveDownloadUrl(PUBLIC_CODE, id) ?: return@withContext null
            if (!safeDownloadUrl(downloadUrl)) return@withContext null
            var nextUrl = downloadUrl
            for (hop in 0..3) {
                coroutineContext.ensureActive()
                if (!safeDownloadUrl(nextUrl)) return@withContext null
                val connection = (URI.create(nextUrl).toURL().openConnection() as HttpURLConnection).apply {
                    connectTimeout = 10_000
                    readTimeout = 15_000
                    instanceFollowRedirects = false // redirect hosts are verified explicitly
                    setRequestProperty("Accept", "video/mp4,application/octet-stream")
                }
                try {
                    val code = connection.responseCode
                    if (code in listOf(301, 302, 303, 307, 308)) {
                        val location = connection.getHeaderField("Location") ?: return@withContext null
                        nextUrl = URI.create(nextUrl).resolve(location).toString()
                        continue
                    }
                    if (code != HttpURLConnection.HTTP_OK) return@withContext null
                    val declared = connection.contentLengthLong
                    if (declared > MAX_FILE_BYTES) return@withContext null
                    connection.inputStream.use { input ->
                        temp.outputStream().buffered().use { output ->
                            val buffer = ByteArray(64 * 1024)
                            var total = 0L
                            while (true) {
                                coroutineContext.ensureActive()
                                val read = input.read(buffer)
                                if (read < 0) break
                                total += read
                                if (total > MAX_FILE_BYTES) return@withContext null
                                output.write(buffer, 0, read)
                            }
                        }
                    }
                    if (temp.length() < 2_048L) return@withContext null
                    val validated = inspect(temp, asset.name) ?: return@withContext null
                    // Same-file concurrent downloads may race; replace atomically within this filesystem.
                    if (!temp.renameTo(target)) return@withContext null
                    pruneCache(target)
                    return@withContext validated.copy(file = target)
                } finally {
                    connection.disconnect()
                }
            }
            return@withContext null
        } catch (cancelled: kotlinx.coroutines.CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            return@withContext null
        } finally {
            temp.delete()
        }
    }

    /** Called by exporter only after service preparation; cached MP4 rechecked before use. */
    fun cachedPrepared(effectId: String): Prepared? {
        if (!isCloud(effectId)) return null
        val id = effectId.removePrefix(PREFIX).toLongOrNull() ?: return null
        val file = cachedFile(id)
        if (!file.isFile || file.length() > MAX_FILE_BYTES) return null
        val name = savedCatalog().firstOrNull { it.fileId == id }?.name ?: file.name
        return inspect(file, name)?.also { file.setLastModified(System.currentTimeMillis()) }
    }

    private fun inspect(file: File, name: String): Prepared? {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(file.absolutePath)
            val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
                ?: return null
            if (durationMs !in MIN_DURATION_MS..MAX_DURATION_MS) return null
            val width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            val height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            if (width < 64 || height < 64) return null
            val mode = detectBackground(retriever, name, durationMs) ?: return null
            Prepared(file, mode, durationMs)
        } catch (_: Exception) {
            null
        } finally {
            runCatching { retriever.release() }
        }
    }

    private fun detectBackground(retriever: MediaMetadataRetriever, name: String, durationMs: Long): RawParticleVideoEffect.Mode? {
        // Prefer explicit filenames when supplied; frame sampling covers unnamed MP4s.
        val normalized = name.lowercase()
        val namedGreen = Regex("(^|[^a-z])(green|verde|chroma)([^a-z]|$)").containsMatchIn(normalized)
        val namedBlack = Regex("(^|[^a-z])(black|preto|luma)([^a-z]|$)").containsMatchIn(normalized)
        if (namedGreen && !namedBlack) return RawParticleVideoEffect.Mode.GREEN_CHROMA
        if (namedBlack && !namedGreen) return RawParticleVideoEffect.Mode.BLACK_LUMA

        var green = 0
        var black = 0
        var total = 0
        for (positionMs in listOf(0L, durationMs / 3, durationMs * 2 / 3)) {
            val frame = if (android.os.Build.VERSION.SDK_INT >= 27) {
                retriever.getScaledFrameAtTime(positionMs * 1_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 256, 256)
            } else {
                retriever.getFrameAtTime(positionMs * 1_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
            } ?: continue
            try {
                val w = frame.width
                val h = frame.height
                // Borders are typically solid chroma or black; avoid effect graphics at the center.
                for (step in 0 until 16) {
                    val t = (step + 1f) / 17f
                    for ((x, y) in listOf(
                        Pair((t * (w - 1)).toInt(), (h * 0.04f).toInt()),
                        Pair((t * (w - 1)).toInt(), (h * 0.96f).toInt()),
                        Pair((w * 0.04f).toInt(), (t * (h - 1)).toInt()),
                        Pair((w * 0.96f).toInt(), (t * (h - 1)).toInt()),
                    )) {
                        val pixel = frame.getPixel(x.coerceIn(0, w - 1), y.coerceIn(0, h - 1))
                        val r = Color.red(pixel)
                        val g = Color.green(pixel)
                        val b = Color.blue(pixel)
                        if (g > 65 && g > r * 1.40f && g > b * 1.32f) green++
                        if (maxOf(r, g, b) <= 65) black++
                        total++
                    }
                }
            } finally { frame.recycle() }
        }
        if (total < 32) return null
        return when {
            green >= (total * 0.65f) -> RawParticleVideoEffect.Mode.GREEN_CHROMA
            black >= (total * 0.65f) -> RawParticleVideoEffect.Mode.BLACK_LUMA
            else -> null // opaque/ambiguous backgrounds must not damage exported videos
        }
    }

    private fun pruneCache(active: File) {
        val files = root.listFiles()?.filter { it.isFile && it.extension == "mp4" } ?: return
        var bytes = files.sumOf { it.length() }
        for (candidate in files.sortedBy { it.lastModified() }) {
            if (bytes <= MAX_CACHE_BYTES) break
            if (candidate == active) continue
            bytes -= candidate.length()
            candidate.delete()
        }
    }
}
