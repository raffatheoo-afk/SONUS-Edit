package com.sonusstudios.sonusedit.media

/** Pure decision logic, covered by JVM tests; do not retry all errors indiscriminately. */
object ExportRecoveryPolicy14 {
    fun shouldRetryInChunks(error: Throwable, durationMs: Long): Boolean {
        if (durationMs < 2_000L || durationMs >= 10L * 60_000L) return false
        val message = generateSequence(error) { it.cause }.mapNotNull { it.message }
            .joinToString(" ").lowercase()
        return message.contains("no output sample") ||
            message.contains("muxer error") ||
            message.contains("codec error") ||
            message.contains("failed to configure codec") ||
            message.contains("mediacodec")
    }
}
