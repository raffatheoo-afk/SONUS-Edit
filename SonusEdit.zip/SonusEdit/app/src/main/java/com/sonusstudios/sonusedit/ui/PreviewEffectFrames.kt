package com.sonusstudios.sonusedit.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.sonusstudios.sonusedit.media.PCloudEffectLibrary
import com.sonusstudios.sonusedit.media.RawParticleSources
import com.sonusstudios.sonusedit.media.RawParticleVideoEffect
import java.io.File
import kotlin.math.max
import kotlin.math.pow

/** Lightweight low-resolution effect preview. Real export always uses the Media3 GPU shader. */
internal class PreviewEffectFrames(private val context: Context) : AutoCloseable {
    private var loadedId: String? = null
    private var retriever: MediaMetadataRetriever? = null
    private var mode: RawParticleVideoEffect.Mode? = null
    private var cloudOptimized: Boolean = false
    private var durationMs: Long = 0L

    @Synchronized
    fun frameAt(id: String, timeMs: Long, opacity: Float): ImageBitmap? {
        if (loadedId != id) prepare(id)
        val extractor = retriever ?: return null
        val effectMode = mode ?: return null
        return try {
            val t = if (durationMs <= 0L) 0L else timeMs.coerceAtLeast(0L) % (durationMs - 80L).coerceAtLeast(1_000L)
            val bitmap = if (Build.VERSION.SDK_INT >= 27) {
                extractor.getScaledFrameAtTime(t * 1_000L, MediaMetadataRetriever.OPTION_CLOSEST, 160, 284)
            } else {
                extractor.getFrameAtTime(t * 1_000L, MediaMetadataRetriever.OPTION_CLOSEST)
            } ?: return null
            try { applyKey(bitmap, effectMode, opacity, cloudOptimized).asImageBitmap() }
            finally { bitmap.recycle() }
        } catch (_: Exception) { null }
    }

    @Synchronized
    private fun prepare(id: String) {
        close()
        loadedId = id
        val remote = if (PCloudEffectLibrary.isCloud(id)) PCloudEffectLibrary(context).cachedPrepared(id) else null
        val local = RawParticleSources.resolve(id)
        if (remote == null && local == null) return
        val file = if (remote != null) remote.file else {
            val source = requireNotNull(local)
            val cacheFile = File(context.cacheDir, "sonus_preview_${id}.mp4")
            if (!cacheFile.isFile || cacheFile.length() < 1_024L) {
                context.resources.openRawResource(source.rawResourceId).use { input ->
                    cacheFile.outputStream().use { output -> input.copyTo(output) }
                }
            }
            cacheFile
        }
        try {
            val decoder = MediaMetadataRetriever()
            decoder.setDataSource(file.absolutePath)
            retriever = decoder
            mode = remote?.mode ?: requireNotNull(local).mode
            cloudOptimized = remote != null
            durationMs = remote?.durationMs ?: requireNotNull(local).loopDurationMs
        } catch (_: Exception) { close(); loadedId = id }
    }

    private fun applyKey(source: Bitmap, effectMode: RawParticleVideoEffect.Mode, opacity: Float, cloud: Boolean): Bitmap {
        val small = if (source.width > 220) Bitmap.createScaledBitmap(source, 160, 284, true) else source
        val w = small.width
        val h = small.height
        val px = IntArray(w * h)
        small.getPixels(px, 0, w, 0, 0, w, h)
        for (i in px.indices) {
            val r = Color.red(px[i]) / 255f
            val g = Color.green(px[i]) / 255f
            val b = Color.blue(px[i]) / 255f
            val brightness = max(r, max(g, b))
            val alpha: Float
            val outR: Int
            val outG: Int
            val outB: Int
            if (!cloud) {
                // Keep the preview of the two bundled particle videos unchanged.
                alpha = if (effectMode == RawParticleVideoEffect.Mode.BLACK_LUMA) {
                    smooth(.01f, .24f, brightness)
                } else {
                    val keyDistance = kotlin.math.sqrt((r - .026f) * (r - .026f) + (g - .195f) * (g - .195f) + (b - .022f) * (b - .022f))
                    smooth(.040f, .165f, keyDistance) * (1f - smooth(.030f, .105f, g - max(r, b))) * smooth(.165f, .300f, brightness)
                }
                val lum = (brightness * 255f).toInt().coerceIn(0, 255)
                outR = lum; outG = lum; outB = lum
            } else if (effectMode == RawParticleVideoEffect.Mode.BLACK_LUMA) {
                var cloudAlpha = smooth(.105f, .315f, brightness).toDouble().pow(1.15).toFloat()
                if (brightness < .105f) cloudAlpha = 0f
                alpha = cloudAlpha
                outR = (((r - .035f) * 1.28f).coerceIn(0f, 1f) * 255f).toInt()
                outG = (((g - .035f) * 1.28f).coerceIn(0f, 1f) * 255f).toInt()
                outB = (((b - .035f) * 1.28f).coerceIn(0f, 1f) * 255f).toInt()
            } else {
                val keyDistance = kotlin.math.sqrt((r - .026f) * (r - .026f) + (g - .195f) * (g - .195f) + (b - .022f) * (b - .022f))
                var cloudAlpha = smooth(.055f, .195f, keyDistance) * (1f - smooth(.040f, .120f, g - max(r, b))) * smooth(.190f, .335f, brightness)
                if (cloudAlpha < .035f) cloudAlpha = 0f
                alpha = cloudAlpha
                val lum = (((brightness - .025f) * 1.08f).coerceIn(0f, 1f) * 255f).toInt()
                outR = lum; outG = lum; outB = lum
            }
            val a = (alpha * opacity.coerceIn(0f, 1f) * 255f).toInt().coerceIn(0, 255)
            px[i] = Color.argb(if (a < 5) 0 else a, outR, outG, outB)
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, w, 0, 0, w, h)
        if (small !== source) small.recycle()
        return out
    }

    private fun smooth(edge0: Float, edge1: Float, value: Float): Float {
        val t = ((value - edge0) / (edge1 - edge0)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    @Synchronized
    override fun close() {
        runCatching { retriever?.release() }
        retriever = null
        mode = null
        cloudOptimized = false
        durationMs = 0L
        loadedId = null
    }
}
