package com.sonusstudios.sonusedit.catalog

/** Pure round-robin ordering helper. Empty sources are omitted before calling this function. */
object GallerySearchRotation {
    fun order(availableSources: List<String>, nextIndex: Int): List<String> {
        val unique = availableSources.distinct()
        if (unique.isEmpty()) return emptyList()
        val offset = Math.floorMod(nextIndex, unique.size)
        return unique.drop(offset) + unique.take(offset)
    }

    fun nextIndex(currentIndex: Int, sourceCount: Int): Int =
        if (sourceCount <= 0) 0 else Math.floorMod(currentIndex + 1, sourceCount)
}
