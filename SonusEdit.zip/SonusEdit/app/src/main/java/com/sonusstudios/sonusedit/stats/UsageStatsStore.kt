package com.sonusstudios.sonusedit.stats

import android.content.Context
import com.sonusstudios.sonusedit.create.AudioSource
import com.sonusstudios.sonusedit.create.CreateProjectDraft
import com.sonusstudios.sonusedit.create.ProjectAspectRatios
import java.io.File
import java.time.Instant
import java.time.YearMonth
import java.time.ZoneId
import java.time.ZonedDateTime
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@Serializable
data class MonthlyUsageStats(
    val monthKey: String,
    val videosCreated: Int = 0,
    val producedVideoMs: Long = 0L,
    val appForegroundMs: Long = 0L,
    val manualEditingMs: Long = 0L,
    val automaticWorkMs: Long = 0L,
    val estimatedManualMs: Long = 0L,
    val successfulExports: Int = 0,
    val failedExports: Int = 0,
    val cancelledExports: Int = 0,
    val streamUses: Int = 0,
    val localUses: Int = 0,
    val linkUses: Int = 0,
    val videoAudioUses: Int = 0,
    val verticalProjects: Int = 0,
    val horizontalProjects: Int = 0,
    val captionedVideos: Int = 0,
    val captionAudioMs: Long = 0L,
    val photosUsed: Int = 0,
    val videosUsed: Int = 0,
    val exportTimeMs: Long = 0L,
    val longestVideoMs: Long = 0L,
    val filterCounts: Map<String, Int> = emptyMap(),
    val effectCounts: Map<String, Int> = emptyMap(),
)

@Serializable
data class UsageStatsSnapshot(
    val months: Map<String, MonthlyUsageStats> = emptyMap(),
    val allTimeVideos: Int = 0,
    val allTimeEstimatedSavedMs: Long = 0L,
)

/** Local-only productivity statistics. No account, server or telemetry upload is used. */
class UsageStatsStore(context: Context) {
    private val appContext = context.applicationContext
    private val file = File(appContext.filesDir, "sonus_usage_stats.json")
    private val resetMarker = File(appContext.filesDir, "sonus_usage_stats_reset_epoch.txt")
    private val json = Json { ignoreUnknownKeys = true; prettyPrint = false }
    private val lock = Any()

    fun currentMonth(): MonthlyUsageStats = synchronized(lock) {
        val snapshot = readLocked()
        snapshot.months[currentMonthKey()] ?: MonthlyUsageStats(currentMonthKey())
    }

    fun snapshot(): UsageStatsSnapshot = synchronized(lock) { readLocked() }

    suspend fun recordForeground(startEpochMs: Long, endEpochMs: Long) = withContext(Dispatchers.IO) {
        if (endEpochMs <= startEpochMs) return@withContext
        synchronized(lock) {
            val zone = ZoneId.systemDefault()
            val resetEpoch = runCatching { resetMarker.readText().trim().toLong() }.getOrDefault(0L)
            var cursor = maxOf(startEpochMs, resetEpoch)
            if (cursor >= endEpochMs) return@synchronized
            var snapshot = readLocked()
            while (cursor < endEpochMs) {
                val cursorTime = Instant.ofEpochMilli(cursor).atZone(zone)
                val month = YearMonth.from(cursorTime)
                val nextMonth = month.plusMonths(1).atDay(1).atStartOfDay(zone).toInstant().toEpochMilli()
                val sliceEnd = minOf(endEpochMs, nextMonth)
                val key = month.toString()
                val old = snapshot.months[key] ?: MonthlyUsageStats(key)
                snapshot = snapshot.copy(
                    months = snapshot.months + (key to old.copy(appForegroundMs = old.appForegroundMs + (sliceEnd - cursor)))
                )
                cursor = sliceEnd
            }
            writeLocked(snapshot)
        }
    }

    suspend fun recordExportSuccess(
        draft: CreateProjectDraft,
        exportTimeMs: Long,
    ) = withContext(Dispatchers.IO) {
        synchronized(lock) {
            val key = currentMonthKey()
            val manualEstimate = estimateManualEditingMs(draft.segmentDurationMs)
            val current = readLocked()
            val old = current.months[key] ?: MonthlyUsageStats(key)
            val filterCounts = old.filterCounts.toMutableMap().apply {
                this[draft.filterPreset.name] = (this[draft.filterPreset.name] ?: 0) + 1
            }
            val effectCounts = old.effectCounts.toMutableMap().apply {
                val effectKey = if (draft.particlesEnabled) draft.automaticEffectId else "none"
                this[effectKey] = (this[effectKey] ?: 0) + 1
            }
            val localVideoSet = draft.localVideoUris.toSet()
            val videoCount = draft.imageUris.count { it in localVideoSet }
            val photoCount = draft.imageUris.size - videoCount
            val updatedMonth = old.copy(
                videosCreated = old.videosCreated + 1,
                producedVideoMs = old.producedVideoMs + draft.segmentDurationMs,
                manualEditingMs = old.manualEditingMs + draft.manualWorkMs,
                automaticWorkMs = old.automaticWorkMs + draft.automaticWorkMs + exportTimeMs,
                estimatedManualMs = old.estimatedManualMs + manualEstimate,
                successfulExports = old.successfulExports + 1,
                streamUses = old.streamUses + if (draft.audioSource == AudioSource.SONUS_STREAM) 1 else 0,
                localUses = old.localUses + if (draft.audioSource == AudioSource.LOCAL || draft.audioSource == AudioSource.SHARED) 1 else 0,
                linkUses = old.linkUses + if (draft.audioSource == AudioSource.LINK) 1 else 0,
                videoAudioUses = old.videoAudioUses + if (draft.audioSource == AudioSource.VIDEO_EXTRACTED) 1 else 0,
                verticalProjects = old.verticalProjects + if (!ProjectAspectRatios.isHorizontal(draft.aspectRatio)) 1 else 0,
                horizontalProjects = old.horizontalProjects + if (ProjectAspectRatios.isHorizontal(draft.aspectRatio)) 1 else 0,
                captionedVideos = old.captionedVideos + if (draft.captionSegments.isNotEmpty()) 1 else 0,
                captionAudioMs = old.captionAudioMs + if (draft.captionSegments.isNotEmpty()) draft.segmentDurationMs else 0L,
                photosUsed = old.photosUsed + photoCount,
                videosUsed = old.videosUsed + videoCount,
                exportTimeMs = old.exportTimeMs + exportTimeMs,
                longestVideoMs = maxOf(old.longestVideoMs, draft.segmentDurationMs),
                filterCounts = filterCounts,
                effectCounts = effectCounts,
            )
            val saved = (manualEstimate - draft.manualWorkMs).coerceAtLeast(0L)
            writeLocked(
                current.copy(
                    months = current.months + (key to updatedMonth),
                    allTimeVideos = current.allTimeVideos + 1,
                    allTimeEstimatedSavedMs = current.allTimeEstimatedSavedMs + saved,
                )
            )
        }
    }

    suspend fun recordExportFailure(cancelled: Boolean) = withContext(Dispatchers.IO) {
        synchronized(lock) {
            val key = currentMonthKey()
            updateMonthLocked(key) { old ->
                if (cancelled) old.copy(cancelledExports = old.cancelledExports + 1)
                else old.copy(failedExports = old.failedExports + 1)
            }
        }
    }


    suspend fun clearAll() = withContext(Dispatchers.IO) {
        synchronized(lock) {
            if (file.exists()) file.delete()
            // Clamp a still-running foreground session so time from before the user's reset is not
            // reinserted when the app later goes to background.
            resetMarker.writeText(System.currentTimeMillis().toString())
        }
    }

    fun monthKeysNewestFirst(): List<String> = synchronized(lock) {
        readLocked().months.keys.sortedDescending()
    }

    fun month(key: String): MonthlyUsageStats = synchronized(lock) {
        readLocked().months[key] ?: MonthlyUsageStats(key)
    }

    private fun updateMonthLocked(key: String, transform: (MonthlyUsageStats) -> MonthlyUsageStats) {
        val current = readLocked()
        val old = current.months[key] ?: MonthlyUsageStats(key)
        writeLocked(current.copy(months = current.months + (key to transform(old))))
    }

    private fun readLocked(): UsageStatsSnapshot = runCatching {
        if (!file.exists()) UsageStatsSnapshot()
        else json.decodeFromString<UsageStatsSnapshot>(file.readText())
    }.getOrDefault(UsageStatsSnapshot())

    private fun writeLocked(value: UsageStatsSnapshot) {
        val temp = File(file.parentFile, "${file.name}.tmp")
        temp.writeText(json.encodeToString(value))
        if (file.exists()) file.delete()
        temp.renameTo(file)
    }

    companion object {
        // Rafa's measured manual benchmark: 30 s final video took 4 min 24 s = 8.8 s work / 1 s output.
        const val MANUAL_SECONDS_PER_VIDEO_SECOND = 8.8

        fun estimateManualEditingMs(videoDurationMs: Long): Long =
            (videoDurationMs / 1_000.0 * MANUAL_SECONDS_PER_VIDEO_SECOND * 1_000.0).toLong()

        fun currentMonthKey(): String = YearMonth.now().toString()

        fun monthKey(epochMs: Long): String = YearMonth.from(
            Instant.ofEpochMilli(epochMs).atZone(ZoneId.systemDefault())
        ).toString()
    }
}
