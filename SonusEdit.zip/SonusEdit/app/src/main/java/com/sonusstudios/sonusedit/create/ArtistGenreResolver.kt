package com.sonusstudios.sonusedit.create

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import java.io.File
import java.text.Normalizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * code19 local artist -> image-category resolver.
 *
 * Runtime lookup is an indexed SQLite query. The human-editable CSV/TXT masters live under
 * reference/artist_genre and are never scanned on the device.
 */
class ArtistGenreResolver(context: Context) {
    data class Match(
        val artist: String?,
        val category: String,
        val imageKeyword: String,
        val positiveKeywords: Set<String>,
        val blockedCategoryKeywords: Set<String>,
        val confidence: String,
        val source: Source,
    ) {
        enum class Source { ARTIST, ALIAS, METADATA_GENRE }
    }

    private data class Rule(
        val category: String,
        val imageKeyword: String,
        val positiveKeywords: Set<String>,
        val blockedCategoryKeywords: Set<String>,
    )

    private val appContext = context.applicationContext
    private val databaseFile = File(appContext.filesDir, "artist_genre/sonus_artist_genres_v1.db")
    private val lock = Any()
    @Volatile private var database: SQLiteDatabase? = null
    @Volatile private var cachedRules: List<Rule>? = null

    suspend fun resolve(artist: String?, metadataGenre: String?): Match? = withContext(Dispatchers.IO) {
        val db = openDatabase()
        artistCandidates(artist).forEach { candidate ->
            queryArtist(db, candidate)?.let { return@withContext it }
            queryAlias(db, candidate)?.let { return@withContext it }
        }
        resolveGenreFallback(db, metadataGenre)
    }

    private fun queryArtist(db: SQLiteDatabase, candidate: String): Match? {
        val normalized = normalize(candidate)
        if (normalized.isBlank()) return null
        var found: Match? = null
        db.rawQuery(
            """
            SELECT a.artist, a.category, a.image_keyword, a.confidence,
                   r.positive_keywords, r.blocked_category_keywords
            FROM artists a
            LEFT JOIN genre_rules r ON r.category = a.category
            WHERE a.normalized_name = ?
            LIMIT 1
            """.trimIndent(),
            arrayOf(normalized),
        ).use { cursor ->
            if (cursor.moveToFirst()) {
                found = Match(
                    artist = cursor.getString(0),
                    category = cursor.getString(1),
                    imageKeyword = cursor.getString(2),
                    confidence = cursor.getString(3),
                    positiveKeywords = parseKeywords(cursor.getString(4)),
                    blockedCategoryKeywords = parseKeywords(cursor.getString(5)),
                    source = Match.Source.ARTIST,
                )
            }
        }
        return found?.expandBlockedKeywords(db)
    }

    private fun queryAlias(db: SQLiteDatabase, candidate: String): Match? {
        val normalized = normalize(candidate)
        if (normalized.isBlank()) return null
        var found: Match? = null
        db.rawQuery(
            """
            SELECT a.artist, a.category, a.image_keyword, a.confidence,
                   r.positive_keywords, r.blocked_category_keywords
            FROM aliases al
            JOIN artists a ON a.normalized_name = al.canonical_normalized
            LEFT JOIN genre_rules r ON r.category = a.category
            WHERE al.normalized_alias = ?
            LIMIT 1
            """.trimIndent(),
            arrayOf(normalized),
        ).use { cursor ->
            if (cursor.moveToFirst()) {
                found = Match(
                    artist = cursor.getString(0),
                    category = cursor.getString(1),
                    imageKeyword = cursor.getString(2),
                    confidence = cursor.getString(3),
                    positiveKeywords = parseKeywords(cursor.getString(4)),
                    blockedCategoryKeywords = parseKeywords(cursor.getString(5)),
                    source = Match.Source.ALIAS,
                )
            }
        }
        return found?.expandBlockedKeywords(db)
    }

    private fun resolveGenreFallback(db: SQLiteDatabase, rawGenre: String?): Match? {
        val genre = normalize(rawGenre.orEmpty())
        if (genre.isBlank()) return null
        val rules = rules(db)
        val matched = rules.firstOrNull { rule ->
            genre.containsWordOrPhrase(normalize(rule.category)) ||
                genre.containsWordOrPhrase(normalize(rule.imageKeyword)) ||
                rule.positiveKeywords.any { genre.containsWordOrPhrase(normalize(it)) }
        } ?: return null
        return Match(
            artist = null,
            category = matched.category,
            imageKeyword = matched.imageKeyword,
            positiveKeywords = matched.positiveKeywords,
            blockedCategoryKeywords = matched.blockedCategoryKeywords,
            confidence = "metadata",
            source = Match.Source.METADATA_GENRE,
        ).expandBlockedKeywords(db)
    }

    /**
     * A category label alone is not enough to reject a bad image. Rafa's gallery also contains
     * descriptive category terms such as "nossa senhora" without the literal word "catolico".
     * Expand the blocker set from every OTHER genre rule, while keeping any keyword shared with
     * the selected category. That makes religious/genre mismatches disappear without rejecting
     * shared crossover tags such as "sofrencia", "samba" or "jesus".
     */
    private fun Match.expandBlockedKeywords(db: SQLiteDatabase): Match {
        val selected = (positiveKeywords + category + imageKeyword).map(::normalize).toSet()
        val expanded = buildSet {
            addAll(blockedCategoryKeywords.map(::normalize))
            rules(db).asSequence()
                .filter { normalize(it.category) != normalize(category) }
                .flatMap { (listOf(it.category, it.imageKeyword) + it.positiveKeywords).asSequence() }
                .map(::normalize)
                .filter { it.isNotBlank() && it !in selected && it !in overlyGenericBlockers }
                .forEach(::add)
        }
        return copy(blockedCategoryKeywords = expanded)
    }

    private fun rules(db: SQLiteDatabase): List<Rule> {
        cachedRules?.let { return it }
        return synchronized(lock) {
            cachedRules?.let { return@synchronized it }
            val loaded = buildList {
                db.rawQuery(
                    "SELECT category, primary_filename_keyword, positive_keywords, blocked_category_keywords FROM genre_rules",
                    null,
                ).use { cursor ->
                    while (cursor.moveToNext()) {
                        add(
                            Rule(
                                category = cursor.getString(0),
                                imageKeyword = cursor.getString(1),
                                positiveKeywords = parseKeywords(cursor.getString(2)),
                                blockedCategoryKeywords = parseKeywords(cursor.getString(3)),
                            )
                        )
                    }
                }
            }
            cachedRules = loaded
            loaded
        }
    }

    private fun openDatabase(): SQLiteDatabase {
        database?.takeIf { it.isOpen }?.let { return it }
        return synchronized(lock) {
            database?.takeIf { it.isOpen }?.let { return@synchronized it }
            databaseFile.parentFile?.mkdirs()
            if (!databaseFile.exists() || databaseFile.length() < MIN_DATABASE_BYTES) {
                val temp = File(databaseFile.parentFile, "${databaseFile.name}.tmp")
                appContext.assets.open(ASSET_NAME).use { input ->
                    temp.outputStream().buffered().use { output -> input.copyTo(output) }
                }
                if (databaseFile.exists()) databaseFile.delete()
                check(temp.renameTo(databaseFile)) { "Não foi possível preparar o banco local de artistas." }
            }
            SQLiteDatabase.openDatabase(databaseFile.absolutePath, null, SQLiteDatabase.OPEN_READONLY)
                .also { database = it }
        }
    }

    private fun artistCandidates(raw: String?): List<String> {
        val value = raw.orEmpty().trim()
        if (value.isBlank()) return emptyList()
        val cleaned = value
            .replace(Regex("(?i)\\s*[-–—|]\\s*(topic|official|oficial|vevo)\\s*$"), "")
            .trim()
        val firstFeatured = cleaned
            .split(Regex("(?i)\\s+(?:feat\\.?|ft\\.?|featuring)\\s+"), limit = 2)
            .firstOrNull()
            .orEmpty()
            .trim()
        return listOf(value, cleaned, firstFeatured).filter { it.isNotBlank() }.distinctBy(::normalize)
    }

    companion object {
        private const val ASSET_NAME = "sonus_artist_genres.db"
        private const val MIN_DATABASE_BYTES = 100_000L
        private val overlyGenericBlockers = setOf("brasil")

        fun normalize(value: String): String = Normalizer.normalize(value, Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
            .lowercase()
            .replace("&", " e ")
            .replace("+", " e ")
            .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
            .trim()
            .replace(Regex("\\s+"), " ")

        private fun parseKeywords(value: String?): Set<String> = value.orEmpty()
            .split(',', ';')
            .map(::normalize)
            .filter { it.isNotBlank() }
            .toSet()

        private fun String.containsWordOrPhrase(value: String): Boolean {
            if (value.isBlank()) return false
            return this == value || startsWith("$value ") || endsWith(" $value") || contains(" $value ")
        }
    }
}
