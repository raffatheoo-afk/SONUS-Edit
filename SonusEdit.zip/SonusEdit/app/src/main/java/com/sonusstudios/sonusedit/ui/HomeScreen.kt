package com.sonusstudios.sonusedit.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonusstudios.sonusedit.R
import com.sonusstudios.sonusedit.catalog.PCloudAsset
import com.sonusstudios.sonusedit.catalog.PCloudMusicRepository
import com.sonusstudios.sonusedit.catalog.StreamHistoryStore
import com.sonusstudios.sonusedit.catalog.StreamMetadataStore
import com.sonusstudios.sonusedit.catalog.StreamSuggestionEngine
import com.sonusstudios.sonusedit.create.AudioMetadata
import com.sonusstudios.sonusedit.create.AutomationPreferences
import com.sonusstudios.sonusedit.create.AutomationSettings
import com.sonusstudios.sonusedit.designsystem.SonusEditColors
import com.sonusstudios.sonusedit.lyrics.LyricsMetadata
import com.sonusstudios.sonusedit.lyrics.StreamLyricsResolver

private val homeMusicExtensions = setOf("mp3", "wav", "flac", "m4a", "aac", "ogg", "opus")
private val HomeTitleYellow = Color(0xFFFFD84A)

@Composable
fun HomeScreen(
    onCreate: () -> Unit,
    onUseSuggestion: (PCloudAsset) -> Unit,
    onSettings: () -> Unit,
) {
    val context = LocalContext.current
    val repository = remember { PCloudMusicRepository(context.applicationContext) }
    val history = remember { StreamHistoryStore(context.applicationContext) }
    val metadataStore = remember { StreamMetadataStore(context.applicationContext) }
    val streamLyrics = remember { StreamLyricsResolver(context.applicationContext) }
    val automationPreferences = remember { AutomationPreferences(context.applicationContext) }
    val automation by automationPreferences.values.collectAsState(initial = AutomationSettings())

    var suggestion by remember { mutableStateOf<PCloudAsset?>(null) }
    var suggestionMetadata by remember { mutableStateOf<AudioMetadata?>(null) }
    var lyricsIndex by remember { mutableStateOf<List<PCloudAsset>>(emptyList()) }
    var lyricsIndexReady by remember { mutableStateOf(false) }
    var suggestionHasLyrics by remember { mutableStateOf<Boolean?>(null) }

    // Preserve the code04 behavior: cached/fresh music suggestion is independent from lyrics sync.
    LaunchedEffect(Unit) {
        val cached = repository.cached().filter { it.extension in homeMusicExtensions }
        if (cached.isNotEmpty()) suggestion = StreamSuggestionEngine.suggest(cached, history.recent())
        val fresh = repository.refresh().filter { it.extension in homeMusicExtensions }
        if (fresh.isNotEmpty()) suggestion = StreamSuggestionEngine.suggest(fresh, history.recent())
    }

    // Lightweight lyrics index only. This reads filenames/IDs; it does NOT download LRC bodies.
    LaunchedEffect(Unit) {
        val cached = runCatching { streamLyrics.cachedIndex() }.getOrDefault(emptyList())
        if (cached.isNotEmpty()) {
            lyricsIndex = cached
            lyricsIndexReady = true
        }
        val refreshed = runCatching { streamLyrics.refreshIndex() }.getOrDefault(cached)
        if (refreshed.isNotEmpty()) {
            lyricsIndex = refreshed
            lyricsIndexReady = true
        }
    }

    LaunchedEffect(suggestion) {
        val asset = suggestion ?: return@LaunchedEffect
        suggestionMetadata = runCatching { metadataStore.resolve(asset, repository) }.getOrNull()
    }

    LaunchedEffect(suggestionMetadata, lyricsIndex, lyricsIndexReady) {
        val meta = suggestionMetadata
        suggestionHasLyrics = when {
            meta == null || !lyricsIndexReady -> null
            else -> streamLyrics.hasIndexedLyrics(
                lyricsIndex,
                LyricsMetadata(
                    trackName = meta.title,
                    artistName = meta.artist.orEmpty(),
                    albumName = meta.album,
                    durationSeconds = (meta.durationMs / 1_000L).toInt().takeIf { it > 0 },
                )
            )
        }
    }

    Column(
        Modifier.fillMaxSize().background(SonusEditColors.Black).padding(horizontal = 20.dp, vertical = 28.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        Row(verticalAlignment = Alignment.Top) {
            Image(painterResource(R.drawable.sonus_edit_logo), "Sonus Edit", Modifier.size(82.dp))
            Spacer(Modifier.size(14.dp))
            Column(Modifier.weight(1f)) {
                Text("Sonus Edit", color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.ExtraBold)
                Text("0.0.6", color = SonusEditColors.TextMuted, fontSize = 11.sp)
            }
            IconButton(onClick = onSettings, modifier = Modifier.size(46.dp)) {
                Icon(Icons.Default.Settings, contentDescription = "Configurações do editor", tint = Color.White, modifier = Modifier.size(27.dp))
            }
        }

        Text("Escolha. Revise. O Sonus Edit monta e exporta sozinho.", color = SonusEditColors.TextMuted, fontSize = 17.sp)

        suggestion?.let { asset ->
            Card(
                Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = SonusEditColors.Violet.copy(alpha = .22f)),
            ) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("SUGESTÃO PARA O PRÓXIMO VÍDEO", color = SonusEditColors.Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text(
                        suggestionMetadata?.title ?: "Lendo metadados…",
                        color = HomeTitleYellow,
                        fontSize = 23.sp,
                        fontWeight = FontWeight.ExtraBold,
                        maxLines = 2,
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            listOfNotNull(suggestionMetadata?.artist, suggestionMetadata?.genre ?: asset.genre).joinToString(" • "),
                            color = Color.White,
                            modifier = Modifier.weight(1f),
                            fontSize = 13.sp,
                        )
                        val dot = when (suggestionHasLyrics) {
                            true -> Color(0xFF20C86B)
                            false -> Color(0xFFE94F64)
                            null -> SonusEditColors.TextMuted
                        }
                        Box(Modifier.size(9.dp).background(dot, CircleShape))
                    }
                    Button(onClick = { onUseSuggestion(asset) }, colors = ButtonDefaults.buttonColors(containerColor = SonusEditColors.Violet)) {
                        Icon(Icons.Default.MusicNote, null)
                        Text("  USAR ESTA MÚSICA")
                    }
                }
            }
        }

        Card(
            Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = SonusEditColors.Surface),
        ) {
            Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AutoAwesome, null, tint = SonusEditColors.Cyan)
                    Spacer(Modifier.size(10.dp))
                    Text("Criar vídeo automático", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 21.sp)
                }
                Text(
                    if (automation.totalAutomation)
                        "Automação Total ativa • o Sonus Edit escolhe música, trecho, duração, imagens, filtro e efeito."
                    else
                        "Assinatura + música → imagens → estilo/letra → revisão → exportação automática.",
                    color = SonusEditColors.TextMuted,
                )
                Button(
                    onClick = {
                        val autoSuggestion = suggestion
                        if (automation.totalAutomation && autoSuggestion != null) onUseSuggestion(autoSuggestion) else onCreate()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SonusEditColors.Violet),
                ) {
                    Icon(Icons.Default.PlayArrow, null)
                    Text("  CRIAR VÍDEO")
                }
            }
        }
        Spacer(Modifier.weight(1f))
    }
}
