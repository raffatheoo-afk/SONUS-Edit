package com.sonusstudios.sonusedit.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.BorderStroke
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.sp
import com.sonusstudios.sonusedit.R
import com.sonusstudios.sonusedit.create.CreationDraftStore
import com.sonusstudios.sonusedit.designsystem.SonusEditColors

@Composable
fun HomeScreen(
    onCreate: () -> Unit,
    onCreateFromLink: () -> Unit,
    onAutoCaptions: () -> Unit,
    onResumeDraft: () -> Unit,
    onStats: () -> Unit,
    onSettings: () -> Unit,
    onPremium: () -> Unit,
) {
    val context = LocalContext.current
    val hasDraft = remember { CreationDraftStore(context.applicationContext).exists() }

    Column(
        Modifier
            .fillMaxSize()
            .background(SonusEditColors.Black)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 24.dp),
        verticalArrangement = Arrangement.spacedBy(15.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.sonus_edit_logo_center), "Sonus Edit", Modifier.size(74.dp))
            Spacer(Modifier.size(13.dp))
            Column(Modifier.weight(1f)) {
                Text("Sonus Edit", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                Text("1.0.6", color = SonusEditColors.TextMuted, fontSize = 11.sp)
            }
            // Settings moved here (beside the crown) in 1.7/code31; nothing was removed from Settings itself.
            IconButton(onClick = onSettings, modifier = Modifier.size(46.dp)) {
                Icon(Icons.Default.Settings, contentDescription = "Ajustes", tint = Color(0xFF9BE7FF), modifier = Modifier.size(28.dp))
            }
            IconButton(onClick = onPremium, modifier = Modifier.size(46.dp)) {
                // Vector icon, never a text emoji.
                PremiumCrownIcon()
            }
        }

        Text(
            "Escolha a fonte. O Sonus Edit monta, legenda e exporta sozinho.",
            color = SonusEditColors.TextMuted,
            fontSize = 15.sp,
        )

        Card(
            Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(30.dp),
            border = BorderStroke(1.5.dp, Color(0xFFCB76FF).copy(alpha = .8f)),
            colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .shadow(18.dp, RoundedCornerShape(30.dp))
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color(0xFF6544F6), Color(0xFF9B43F4), Color(0xFFEA4D9F))
                        )
                    )
                    .padding(horizontal = 22.dp, vertical = 30.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                val sparkleMotion = rememberInfiniteTransition(label = "sonus-sparkles")
                val sparkleRotation by sparkleMotion.animateFloat(
                    initialValue = -8f, targetValue = 8f,
                    animationSpec = infiniteRepeatable(tween(1900), repeatMode = RepeatMode.Reverse),
                    label = "sparkle-rotation",
                )
                val sparklePulse by sparkleMotion.animateFloat(
                    initialValue = 0.88f, targetValue = 1.12f,
                    animationSpec = infiniteRepeatable(tween(1250), repeatMode = RepeatMode.Reverse),
                    label = "sparkle-pulse",
                )
                Icon(Icons.Default.AutoAwesome, null, tint = Color(0xFFFFE5A1), modifier = Modifier
                    .size(38.dp).graphicsLayer { rotationZ = sparkleRotation; scaleX = sparklePulse; scaleY = sparklePulse })
                Text("Criar vídeo automático", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                Text("Novo projeto", color = Color.White.copy(alpha = .82f), fontSize = 11.sp)
                Button(
                    onClick = onCreate,
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF6037D8)),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.shadow(10.dp, RoundedCornerShape(24.dp)),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 30.dp, vertical = 15.dp),
                ) {
                    Icon(Icons.Default.PlayArrow, null)
                    Text("  CRIAR", fontWeight = FontWeight.ExtraBold)
                }
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            HomeSmallAction(
                title = "Criar com Link",
                subtitle = "Nova mídia",
                accent = Color(0xFF24D4F2),
                icon = { Icon(Icons.Default.Link, null, tint = SonusEditColors.Cyan) },
                modifier = Modifier.weight(1f),
                onClick = onCreateFromLink,
            )
            HomeSmallAction(
                // Two short lines: "Legendas automáticas" in one 15 sp title would be cut off in a half-width card.
                title = "Legendas",
                subtitle = "Automáticas • galeria",
                accent = Color(0xFFB085FF),
                icon = { Icon(Icons.Default.Subtitles, null, tint = Color(0xFFB085FF)) },
                modifier = Modifier.weight(1f),
                onClick = onAutoCaptions,
            )
        }

        Text("Central", color = SonusEditColors.TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            HomeSmallAction(
                title = "Estatísticas",
                subtitle = "Seu mês no SONUS",
                accent = Color(0xFF67E69A),
                icon = { Icon(Icons.Default.BarChart, null, tint = Color(0xFF67E69A)) },
                modifier = Modifier.weight(1f),
                onClick = onStats,
            )
            HomeSmallAction(
                title = "Rascunho",
                accent = Color(0xFFFFD65C),
                subtitle = if (hasDraft) "Continuar" else "Sem projeto salvo",
                icon = { Icon(Icons.Default.Description, null, tint = Color(0xFFFFD65C)) },
                modifier = Modifier.weight(1f),
                enabled = hasDraft,
                onClick = onResumeDraft,
            )
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun HomeSmallAction(
    title: String,
    subtitle: String? = null,
    icon: @Composable () -> Unit,
    modifier: Modifier,
    enabled: Boolean = true,
    accent: Color,
    onClick: () -> Unit,
) {
    Card(
        modifier = modifier.height(174.dp),
        shape = RoundedCornerShape(25.dp),
        border = BorderStroke(1.3.dp, accent.copy(alpha = .52f)),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
    ) {
        Column(
            Modifier.fillMaxSize()
                .background(Brush.linearGradient(listOf(accent.copy(alpha = .18f), Color(0xFF101D31), accent.copy(alpha = .07f))))
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(7.dp),
        ) {
            Box(
                Modifier.size(48.dp).background(
                    Brush.radialGradient(listOf(accent.copy(alpha = .58f), accent.copy(alpha = .18f), Color(0xFF142A48))),
                    RoundedCornerShape(50),
                ), contentAlignment = Alignment.Center,
            ) { icon() }
            Text(
                title,
                color = if (enabled) Color.White else SonusEditColors.TextMuted,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            subtitle?.let { Text(it, color = SonusEditColors.TextMuted, fontSize = 9.sp, maxLines = 1) }
            Spacer(Modifier.weight(1f))
            Box(
                Modifier.fillMaxWidth().height(44.dp)
                    .shadow(8.dp, RoundedCornerShape(18.dp))
                    .clip(RoundedCornerShape(18.dp))
                    .background(
                        if (enabled) Brush.horizontalGradient(listOf(Color(0xFF37C7F4), Color(0xFF2862F5)))
                        else Brush.horizontalGradient(listOf(Color(0xFF30394A), Color(0xFF252D3D)))
                    )
                    .clickable(enabled = enabled, onClick = onClick),
                contentAlignment = Alignment.Center,
            ) {
                Text(if (enabled) "ABRIR" else "EM BREVE", color = Color.White.copy(alpha = if (enabled) 1f else .62f), fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
    }
}
