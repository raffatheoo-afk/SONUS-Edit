package com.sonusstudios.sonusedit.integration

import android.content.Intent
import android.net.Uri

/**
 * Accepts both the original SONUS deep link and richer explicit intents from newer SONUS builds.
 * The richer fields are deliberately optional so older SONUS versions keep working.
 */
object IncomingIntentRouter {
    sealed interface Route {
        data object Home : Route
        data object ExportProgress : Route
        data class SonusTrack(
            val trackId: String,
            val startMs: Long?,
            val durationMs: Long?,
            val audioUri: Uri? = null,
            val title: String? = null,
            val artist: String? = null,
            val album: String? = null,
            val genre: String? = null,
            val captionsJson: String? = null,
        ) : Route
        data class SharedMedia(
            val uris: List<Uri>,
            val title: String? = null,
            val artist: String? = null,
            val trackId: String? = null,
            val captionsJson: String? = null,
        ) : Route
    }

    fun parse(intent: Intent?): Route {
        intent ?: return Route.Home

        if (intent.action == "com.sonusstudios.sonusedit.OPEN_EXPORT") return Route.ExportProgress

        if (intent.action == Intent.ACTION_VIEW) {
            val data = intent.data
            if (data?.scheme == SonusLinkContract.SCHEME && data.host == SonusLinkContract.HOST_CREATE) {
                val trackId = firstNonBlank(
                    data.getQueryParameter("trackId"),
                    intent.getStringExtra(EXTRA_TRACK_ID),
                    data.getQueryParameter("id"),
                ).orEmpty()
                val directAudio = firstNonBlank(
                    data.getQueryParameter("audioUri"),
                    intent.getStringExtra(EXTRA_AUDIO_URI),
                 )?.let { raw -> runCatching { Uri.parse(raw) }.getOrNull() }
                if (trackId.isNotEmpty() || directAudio != null) {
                    return Route.SonusTrack(
                        trackId = trackId,
                        startMs = data.getQueryParameter("startMs")?.toLongOrNull()
                            ?: intent.longExtraOrNull(EXTRA_START_MS),
                        durationMs = data.getQueryParameter("durationMs")?.toLongOrNull()
                            ?: intent.longExtraOrNull(EXTRA_DURATION_MS),
                        audioUri = directAudio,
                        title = firstNonBlank(data.getQueryParameter("title"), intent.getStringExtra(Intent.EXTRA_TITLE), intent.getStringExtra(EXTRA_TITLE)),
                        artist = firstNonBlank(data.getQueryParameter("artist"), intent.getStringExtra(EXTRA_ARTIST)),
                        album = firstNonBlank(data.getQueryParameter("album"), intent.getStringExtra(EXTRA_ALBUM)),
                        genre = firstNonBlank(data.getQueryParameter("genre"), intent.getStringExtra(EXTRA_GENRE)),
                        captionsJson = firstNonBlank(data.getQueryParameter("captions"), intent.getStringExtra(EXTRA_CAPTIONS_JSON)),
                    )
                }
            }
        }

        if (intent.action == Intent.ACTION_SEND) {
            @Suppress("DEPRECATION")
            val uri = intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
                ?: intent.clipData?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.uri
                ?: intent.data
            if (uri != null) {
                return Route.SharedMedia(
                    uris = listOf(uri),
                    title = firstNonBlank(intent.getStringExtra(Intent.EXTRA_TITLE), intent.getStringExtra(EXTRA_TITLE)),
                    artist = intent.getStringExtra(EXTRA_ARTIST)?.trim()?.takeIf { it.isNotEmpty() },
                    trackId = intent.getStringExtra(EXTRA_TRACK_ID)?.trim()?.takeIf { it.isNotEmpty() },
                    captionsJson = intent.getStringExtra(EXTRA_CAPTIONS_JSON)?.trim()?.takeIf { it.isNotEmpty() },
                )
            }
        }

        if (intent.action == Intent.ACTION_SEND_MULTIPLE) {
            @Suppress("DEPRECATION")
            val uris = intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM).orEmpty()
            if (uris.isNotEmpty()) {
                return Route.SharedMedia(
                    uris = uris,
                    title = firstNonBlank(intent.getStringExtra(Intent.EXTRA_TITLE), intent.getStringExtra(EXTRA_TITLE)),
                    artist = intent.getStringExtra(EXTRA_ARTIST)?.trim()?.takeIf { it.isNotEmpty() },
                    trackId = intent.getStringExtra(EXTRA_TRACK_ID)?.trim()?.takeIf { it.isNotEmpty() },
                    captionsJson = intent.getStringExtra(EXTRA_CAPTIONS_JSON)?.trim()?.takeIf { it.isNotEmpty() },
                )
            }
        }

        // Explicit SONUS intent fallback: newer SONUS builds may target this package directly
        // instead of using ACTION_VIEW. Keep it compatible with the same non-secret contract.
        val explicitTrackId = intent.getStringExtra(EXTRA_TRACK_ID)?.trim().orEmpty()
        val explicitAudio = intent.getStringExtra(EXTRA_AUDIO_URI)?.trim()?.takeIf { it.isNotEmpty() }
            ?.let { raw -> runCatching { Uri.parse(raw) }.getOrNull() }
        if (explicitTrackId.isNotEmpty() || explicitAudio != null) {
            return Route.SonusTrack(
                trackId = explicitTrackId,
                startMs = intent.longExtraOrNull(EXTRA_START_MS),
                durationMs = intent.longExtraOrNull(EXTRA_DURATION_MS),
                audioUri = explicitAudio,
                title = firstNonBlank(intent.getStringExtra(Intent.EXTRA_TITLE), intent.getStringExtra(EXTRA_TITLE)),
                artist = intent.getStringExtra(EXTRA_ARTIST)?.trim()?.takeIf { it.isNotEmpty() },
                album = intent.getStringExtra(EXTRA_ALBUM)?.trim()?.takeIf { it.isNotEmpty() },
                genre = intent.getStringExtra(EXTRA_GENRE)?.trim()?.takeIf { it.isNotEmpty() },
                captionsJson = intent.getStringExtra(EXTRA_CAPTIONS_JSON)?.trim()?.takeIf { it.isNotEmpty() },
            )
        }

        return Route.Home
    }

    private fun Intent.longExtraOrNull(name: String): Long? =
        if (hasExtra(name)) getLongExtra(name, Long.MIN_VALUE).takeIf { it != Long.MIN_VALUE } else null

    private fun firstNonBlank(vararg values: String?): String? =
        values.firstNotNullOfOrNull { it?.trim()?.takeIf(String::isNotEmpty) }

    const val EXTRA_TRACK_ID = "sonus.trackId"
    const val EXTRA_AUDIO_URI = "sonus.audioUri"
    const val EXTRA_TITLE = "sonus.title"
    const val EXTRA_ARTIST = "sonus.artist"
    const val EXTRA_ALBUM = "sonus.album"
    const val EXTRA_GENRE = "sonus.genre"
    const val EXTRA_START_MS = "sonus.startMs"
    const val EXTRA_DURATION_MS = "sonus.durationMs"
    const val EXTRA_CAPTIONS_JSON = "sonus.captionsJson"
}
