package com.sonusstudios.sonusedit.lyrics

import android.content.Context
import com.sonusstudios.sonusedit.catalog.PCloudAsset
import com.sonusstudios.sonusedit.catalog.PCloudPublicCatalogClient
import java.io.File
import java.net.HttpURLConnection
import java.net.URI
import java.text.Normalizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * Lightweight synchronized-lyrics catalog.
 *
 * Startup/list browsing only reads pCloud file metadata (name/id/path/modified/size). It never
 * downloads all LRC contents. A single LRC is downloaded only when the user actually selects a
 * matching Stream song for a video.
 */
class PCloudLyricsRepository(
    context: Context,
    private val client: PCloudPublicCatalogClient = PCloudPublicCatalogClient(),
    private val json: Json = Json { ignoreUnknownKeys = true },
) {
    private val indexCacheFile = File(context.filesDir, "sonus_edit_lyrics_index.json")
    private val lrcCacheDir = File(context.filesDir, "sonus_edit_lrc_cache")

    suspend fun cachedIndex(): List<PCloudAsset> = withContext(Dispatchers.IO) {
        readIndexSnapshot().assets.filter { it.extension == "lrc" }
    }

    /** Refreshes metadata only. No LRC body is downloaded here. */
    suspend fun refreshIndex(): List<PCloudAsset> = withContext(Dispatchers.IO) {
        val previous = readIndexSnapshot().assets.filter { it.extension == "lrc" }
        val fresh = runCatching { client.listAssets(PUBLIC_CODE) }
            .getOrDefault(emptyList())
            .filter { it.extension == "lrc" }
            .distinctBy { it.stableKey }

        // The low-level client returns an empty list on network failure too. Preserve the last
        // known-good index instead of turning every green dot red while offline.
        if (fresh.isEmpty()) return@withContext previous

        runCatching {
            indexCacheFile.writeText(json.encodeToString(LyricsIndexSnapshot(System.currentTimeMillis(), fresh)))
        }
        fresh
    }

    fun bestMatchAsset(index: List<PCloudAsset>, trackTitle: String, trackArtist: String?): PCloudAsset? {
        val title = normalize(trackTitle)
        val artist = normalize(trackArtist.orEmpty())
        if (title.isBlank()) return null

        val ranked = index.asSequence()
            .filter { it.extension == "lrc" }
            .mapNotNull { asset ->
                val score = matchScore(asset, title, artist)
                if (score > 0) asset to score else null
            }
            .sortedWith(compareByDescending<Pair<PCloudAsset, Int>> { it.second }.thenBy { it.first.stableKey })
            .toList()

        val best = ranked.firstOrNull() ?: return null
        val second = ranked.getOrNull(1)

        // Never guess between equally plausible songs/artists.
        if (second != null && second.second == best.second && best.second < STRONG_UNAMBIGUOUS_SCORE) return null
        return best.first
    }

    fun hasMatch(index: List<PCloudAsset>, trackTitle: String, trackArtist: String?): Boolean =
        bestMatchAsset(index, trackTitle, trackArtist) != null

    /**
     * Downloads only the one LRC selected for the current song. Previously downloaded versions are
     * reused while file id/size/modified stay unchanged.
     */
    suspend fun loadSelected(index: List<PCloudAsset>, trackTitle: String, trackArtist: String?): String? = withContext(Dispatchers.IO) {
        val asset = bestMatchAsset(index, trackTitle, trackArtist) ?: return@withContext null
        readCachedLrc(asset)?.let { return@withContext it }

        val url = client.resolveDownloadUrl(PUBLIC_CODE, asset.fileId) ?: return@withContext null
        val raw = downloadText(url)?.trim().orEmpty()
        if (!isValidLrc(raw)) return@withContext null

        runCatching {
            lrcCacheDir.mkdirs()
            lrcCacheDir.listFiles()
                ?.filter { it.name.startsWith("lrc_${asset.fileId}_") }
                ?.forEach { it.delete() }
            cacheFileFor(asset).writeText(raw)
        }
        raw
    }

    private fun readCachedLrc(asset: PCloudAsset): String? {
        val file = cacheFileFor(asset)
        if (!file.exists()) return null
        return runCatching { file.readText() }.getOrNull()?.takeIf(::isValidLrc)
    }

    private fun cacheFileFor(asset: PCloudAsset): File {
        val modifiedHash = Integer.toHexString(asset.modified.orEmpty().hashCode())
        return File(lrcCacheDir, "lrc_${asset.fileId}_${asset.size}_$modifiedHash.lrc")
    }

    private fun matchScore(asset: PCloudAsset, title: String, artist: String): Int {
        val stem = normalize(asset.name.substringBeforeLast('.'))
        val folder = normalize(asset.folderPath)
        val titleInStem = stem.containsPhrase(title)
        val artistInStem = artist.isNotBlank() && stem.containsPhrase(artist)
        val artistInFolder = artist.isNotBlank() && folder.containsPhrase(artist)

        if (artist.isNotBlank()) {
            if (stem == "$title $artist" || stem == "$artist $title") return 1600
            if (titleInStem && artistInStem) return 1500
            if (stem == title && artistInFolder) return 1450
            if (titleInStem && artistInFolder) return 1400
            // Title-only filenames are accepted only when they are unambiguous in the index.
            if (stem == title) return 1000
            if (titleInStem) return 760
            return 0
        }

        if (stem == title) return 1200
        if (titleInStem) return 850
        return 0
    }

    private fun downloadText(url: String): String? {
        val connection = (URI.create(url).toURL().openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 8_000
            readTimeout = 12_000
            setRequestProperty("Accept", "text/plain,*/*")
            setRequestProperty("User-Agent", "Sonus-Edit/0.0.6 Android")
        }
        return try {
            if (connection.responseCode == HttpURLConnection.HTTP_OK) {
                connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            } else null
        } catch (_: Throwable) {
            null
        } finally {
            connection.disconnect()
        }
    }

    private fun readIndexSnapshot(): LyricsIndexSnapshot = runCatching {
        if (!indexCacheFile.exists()) return@runCatching LyricsIndexSnapshot()
        json.decodeFromString<LyricsIndexSnapshot>(indexCacheFile.readText())
    }.getOrDefault(LyricsIndexSnapshot())

    private fun String.containsPhrase(value: String): Boolean {
        if (value.isBlank()) return false
        return this == value || startsWith("$value ") || endsWith(" $value") || contains(" $value ")
    }

    companion object {
        const val PUBLIC_CODE = "kZNiXQJZTobHXlzVPjzsj9LyASRI77DUtfJk"
        private const val STRONG_UNAMBIGUOUS_SCORE = 1400
        private val LRC_TIMESTAMP = Regex("\\[\\d{1,3}:\\d{2}(?:[.:]\\d{1,3})?]")

        fun isValidLrc(value: String?): Boolean = !value.isNullOrBlank() && LRC_TIMESTAMP.containsMatchIn(value)

        fun normalize(value: String): String {
            val noMarks = Normalizer.normalize(value, Normalizer.Form.NFD)
                .replace(Regex("\\p{M}+"), "")
            return noMarks.lowercase()
                .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
                .trim()
                .replace(Regex("\\s+"), " ")
        }
    }
}

@Serializable
private data class LyricsIndexSnapshot(
    val updatedAtMs: Long = 0L,
    val assets: List<PCloudAsset> = emptyList(),
)
