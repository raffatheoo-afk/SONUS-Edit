package com.sonusstudios.sonusedit.lyrics

import android.content.Context
import com.sonusstudios.sonusedit.catalog.PCloudAsset
import com.sonusstudios.sonusedit.catalog.PCloudPublicCatalogClient
import java.io.File
import java.net.HttpURLConnection
import java.net.URI
import java.text.Normalizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * Lightweight synchronized-lyrics catalog.
 *
 * Browsing reads only pCloud file metadata (name/id/path/modified/size). It never downloads all
 * LRC contents. One LRC body is downloaded only after its matching Stream song is selected.
 */
class PCloudLyricsRepository(
    context: Context,
    private val client: PCloudPublicCatalogClient = PCloudPublicCatalogClient(),
    private val json: Json = Json { ignoreUnknownKeys = true },
) {
    private val indexCacheFile = File(context.filesDir, "sonus_edit_lyrics_index.json")
    private val lrcCacheDir = File(context.filesDir, "sonus_edit_lrc_cache")

    suspend fun cachedIndexState(): LyricsIndexState = withContext(Dispatchers.IO) {
        val exists = indexCacheFile.exists()
        val assets = readIndexSnapshot().assets.filter { it.extension == "lrc" }
        LyricsIndexState(assets = assets, ready = exists)
    }

    /** Refreshes metadata only. No LRC body is downloaded here. */
    suspend fun refreshIndexState(): LyricsIndexState = withContext(Dispatchers.IO) {
        val previous = cachedIndexState()
        val fresh = client.listAssetsOrNull(PUBLIC_CODE)
            ?.filter { it.extension == "lrc" }
            ?.distinctBy { it.stableKey }
            ?: return@withContext previous

        // A successful empty folder is valid and replaces an old index. A failed request returns
        // null above and preserves the previous snapshot instead.
        runCatching {
            indexCacheFile.writeText(json.encodeToString(LyricsIndexSnapshot(System.currentTimeMillis(), fresh)))
        }
        LyricsIndexState(assets = fresh, ready = true)
    }

    suspend fun cachedIndex(): List<PCloudAsset> = cachedIndexState().assets
    suspend fun refreshIndex(): List<PCloudAsset> = refreshIndexState().assets

    fun bestMatchAsset(index: List<PCloudAsset>, trackTitle: String, trackArtist: String?): PCloudAsset? {
        val title = normalize(trackTitle)
        val artist = normalize(trackArtist.orEmpty())
        if (title.isBlank()) return null

        val candidates = index.filter { it.extension == "lrc" }
        val ranked = candidates.mapNotNull { asset ->
            val score = matchScore(asset, title, artist)
            if (score > 0) asset to score else null
        }.sortedWith(compareByDescending<Pair<PCloudAsset, Int>> { it.second }.thenBy { it.first.stableKey })

        val best = ranked.firstOrNull() ?: return null
        val second = ranked.getOrNull(1)

        // Exact-title-only files are accepted only when unique. Never guess between two artists.
        if (best.second == TITLE_ONLY_SCORE) {
            val exactTitleMatches = candidates.count { normalize(it.name.substringBeforeLast('.')) == title }
            if (exactTitleMatches != 1) return null
        }

        if (second != null && second.second == best.second) return null
        return best.first
    }

    fun hasMatch(index: List<PCloudAsset>, trackTitle: String, trackArtist: String?): Boolean =
        bestMatchAsset(index, trackTitle, trackArtist) != null

    /** Downloads only the one LRC selected for the current song. */
    suspend fun loadSelected(index: List<PCloudAsset>, trackTitle: String, trackArtist: String?): String? = withContext(Dispatchers.IO) {
        val asset = bestMatchAsset(index, trackTitle, trackArtist) ?: return@withContext null
        readCachedLrc(asset)?.let { return@withContext it }

        val url = client.resolveDownloadUrl(PUBLIC_CODE, asset.fileId) ?: return@withContext null
        val raw = downloadText(url)?.trim().orEmpty()
        if (!isValidLrc(raw)) return@withContext null

        runCatching {
            lrcCacheDir.mkdirs()
            lrcCacheDir.listFiles()
                ?.filter { it.name.startsWith("lrc_${asset.fileId}_") }
                ?.forEach { it.delete() }
            cacheFileFor(asset).writeText(raw)
        }
        raw
    }

    private fun readCachedLrc(asset: PCloudAsset): String? {
        val file = cacheFileFor(asset)
        if (!file.exists()) return null
        return runCatching { file.readText() }.getOrNull()?.takeIf(::isValidLrc)
    }

    private fun cacheFileFor(asset: PCloudAsset): File {
        val modifiedHash = Integer.toHexString(asset.modified.orEmpty().hashCode())
        return File(lrcCacheDir, "lrc_${asset.fileId}_${asset.size}_$modifiedHash.lrc")
    }

    private fun matchScore(asset: PCloudAsset, title: String, artist: String): Int {
        val stem = normalize(asset.name.substringBeforeLast('.'))
        val folder = normalize(asset.folderPath)
        val titleInStem = stem.containsPhrase(title)
        val artistInStem = artist.isNotBlank() && stem.containsPhrase(artist)
        val artistInFolder = artist.isNotBlank() && folder.containsPhrase(artist)

        if (artist.isNotBlank()) {
            if (stem == "$title $artist" || stem == "$artist $title") return 2000
            if (titleInStem && artistInStem) return 1900
            if (stem == title && artistInFolder) return 1800
            if (titleInStem && artistInFolder) return 1700
            // No partial title-only fallback when artist is known. Only an exact title filename may
            // be used, and bestMatchAsset() still requires it to be unique in the index.
            if (stem == title) return TITLE_ONLY_SCORE
            return 0
        }

        // Without artist metadata, only an exact title is safe enough for automatic linking.
        return if (stem == title) TITLE_ONLY_SCORE else 0
    }

    private fun downloadText(url: String): String? {
        val connection = (URI.create(url).toURL().openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 8_000
            readTimeout = 12_000
            setRequestProperty("Accept", "text/plain,*/*")
            setRequestProperty("User-Agent", "Sonus-Edit/0.0.8 Android")
        }
        return try {
            if (connection.responseCode == HttpURLConnection.HTTP_OK) {
                connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            } else null
        } catch (_: Throwable) {
            null
        } finally {
            connection.disconnect()
        }
    }

    private fun readIndexSnapshot(): LyricsIndexSnapshot = runCatching {
        if (!indexCacheFile.exists()) return@runCatching LyricsIndexSnapshot()
        json.decodeFromString<LyricsIndexSnapshot>(indexCacheFile.readText())
    }.getOrDefault(LyricsIndexSnapshot())

    private fun String.containsPhrase(value: String): Boolean {
        if (value.isBlank()) return false
        return this == value || startsWith("$value ") || endsWith(" $value") || contains(" $value ")
    }

    companion object {
        const val PUBLIC_CODE = "kZNiXQJZTobHXlzVPjzsj9LyASRI77DUtfJk"
        private const val TITLE_ONLY_SCORE = 1200
        private val LRC_TIMESTAMP = Regex("\\[\\d{1,3}:\\d{2}(?:[.:]\\d{1,3})?]")

        fun isValidLrc(value: String?): Boolean = !value.isNullOrBlank() && LRC_TIMESTAMP.containsMatchIn(value)

        fun normalize(value: String): String {
            val noMarks = Normalizer.normalize(value, Normalizer.Form.NFD)
                .replace(Regex("\\p{M}+"), "")
            return noMarks.lowercase()
                .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
                .trim()
                .replace(Regex("\\s+"), " ")
        }
    }
}

@Serializable
data class LyricsIndexState(
    val assets: List<PCloudAsset> = emptyList(),
    val ready: Boolean = false,
)

@Serializable
private data class LyricsIndexSnapshot(
    val updatedAtMs: Long = 0L,
    val assets: List<PCloudAsset> = emptyList(),
)
