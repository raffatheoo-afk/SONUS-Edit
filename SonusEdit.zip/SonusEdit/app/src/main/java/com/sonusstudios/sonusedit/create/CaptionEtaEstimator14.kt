package com.sonusstudios.sonusedit.create

import android.content.Context
import kotlin.math.roundToLong

/** Local adaptive estimate. The gallery timer remains the anchor; only model download/load pauses active processing time. */
object CaptionEtaEstimator14 {
    private const val PREFS = "sonus_caption_eta_code17"
    private const val MAX_SAMPLES = 100
    private const val MIN_TOTAL_MS = 5_000L
    private const val MAX_TOTAL_MS = 12L * 60L * 60_000L

    // Stopwatch measurements supplied for 15, 30, 40, 50 and 60 second clips.
    // Least-squares fit from those five points: seconds = 39.96 + 4.375 * videoSeconds.
    // This cold-start curve follows the approved TXT's intermediate-duration examples;
    // local samples then recalibrate it after each successful run.
    private val measuredDurationMs = longArrayOf(15_000L, 30_000L, 40_000L, 50_000L, 60_000L)
    private val measuredElapsedMs = longArrayOf(107_000L, 177_000L, 198_000L, 269_000L, 302_000L)
    private val regressionFit: Pair<Double, Double> by lazy {
        val xs = measuredDurationMs.map { it / 1_000.0 }
        val ys = measuredElapsedMs.map { it / 1_000.0 }
        val meanX = xs.average()
        val meanY = ys.average()
        val denominator = xs.sumOf { (it - meanX) * (it - meanX) }.coerceAtLeast(1e-9)
        val slope = xs.indices.sumOf { index -> (xs[index] - meanX) * (ys[index] - meanY) } / denominator
        (meanY - slope * meanX) to slope
    }

    fun defaultMs(durationMs: Long): Long {
        if (durationMs <= 0L) return 0L
        val (interceptSeconds, slope) = regressionFit
        val predictedSeconds = interceptSeconds + slope * (durationMs / 1_000.0)
        return (predictedSeconds * 1_000.0).roundToLong().coerceIn(MIN_TOTAL_MS, MAX_TOTAL_MS)
    }

    // Null metadata identifies a CODE16-era aggregate. These legacy bucket averages are
    // retained as generic, lower-specificity observations rather than discarded on upgrade.
    private data class Sample(
        val durationMs: Long,
        val elapsedMs: Long,
        val mediaCount: Int?,
        val horizontal: Boolean?,
    )

    private fun encodeSamples(samples: List<Sample>): String = samples.joinToString(";") {
        "${it.durationMs}:${it.elapsedMs}:${it.mediaCount?.toString() ?: "*"}:${it.horizontal?.toString() ?: "*"}"
    }

    private fun parseSamples(raw: String): List<Sample> = raw.split(';').mapNotNull { token ->
        if (token.isBlank()) return@mapNotNull null
        val parts = token.split(':')
        if (parts.size < 2) return@mapNotNull null
        val duration = parts[0].toLongOrNull() ?: return@mapNotNull null
        val elapsed = parts[1].toLongOrNull() ?: return@mapNotNull null
        val mediaCount = parts.getOrNull(2)?.takeUnless { it == "*" }?.toIntOrNull()?.coerceAtLeast(1)
        val horizontal = parts.getOrNull(3)?.takeUnless { it == "*" }?.toBooleanStrictOrNull()
        if (duration <= 0L || elapsed !in 1_000L..MAX_TOTAL_MS) null
        else Sample(duration, elapsed, mediaCount, horizontal)
    }.takeLast(MAX_SAMPLES)

    private fun migrateLegacyHistory(context: Context) {
        val appContext = context.applicationContext
        val current = appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (current.getBoolean("legacy_migrated", false) || current.contains("samples")) return
        val legacy = appContext.getSharedPreferences("sonus_caption_eta_code28", Context.MODE_PRIVATE)
        val legacyBuckets = listOf(
            "short" to 15_000L,
            "medium" to 30_000L,
            "one_min" to 60_000L,
            "long" to 300_000L,
            "very_long" to 1_800_000L,
        )
        val imported = legacyBuckets.mapNotNull { (bucket, representativeDurationMs) ->
            val elapsedAverage = legacy.getLong("eta_$bucket", 0L)
            if (elapsedAverage in 1_000L..MAX_TOTAL_MS) {
                Sample(representativeDurationMs, elapsedAverage, null, null)
            } else null
        }
        current.edit()
            .putString("samples", encodeSamples(imported))
            .putBoolean("legacy_migrated", true)
            .apply()
    }

    private fun readSamples(context: Context): List<Sample> = runCatching {
        migrateLegacyHistory(context)
        val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        parseSamples(prefs.getString("samples", "").orEmpty())
    }.getOrDefault(emptyList())

    fun expectedTotalMs(
        context: Context,
        durationMs: Long,
        mediaCount: Int? = null,
        horizontal: Boolean? = null,
    ): Long {
        val baseline = defaultMs(durationMs)
        if (baseline <= 0L) return 0L
        val allSamples = readSamples(context)
        // Orientation histories never borrow samples from the other aspect ratio.
        // When a media-count-specific history is still short, widen only within that orientation.
        val orientationSamples = allSamples.filter { horizontal == null || it.horizontal == null || it.horizontal == horizontal }
        val matching = orientationSamples.filter { mediaCount == null || it.mediaCount == null || it.mediaCount == mediaCount }
        val sourceSamples = matching.ifEmpty { orientationSamples }
        val ratios = sourceSamples.takeLast(10).map { sample ->
            sample.elapsedMs.toDouble() / defaultMs(sample.durationMs).coerceAtLeast(1L).toDouble()
        }.filter { it.isFinite() && it in 0.25..3.0 }.sorted()
        if (ratios.isEmpty()) return baseline
        // Arithmetic mean follows the user's requested moving average. With five or more
        // samples, trim one high and one low ratio to soften single-run thermal/network outliers.
        val stableRatios = if (ratios.size >= 5) ratios.drop(1).dropLast(1) else ratios
        val averageRatio = stableRatios.average()
        val weight = (ratios.size.toDouble() / (ratios.size + 3.0)).coerceAtMost(0.80)
        return (baseline * (1.0 - weight + averageRatio * weight)).roundToLong()
            .coerceIn(MIN_TOTAL_MS, MAX_TOTAL_MS)
    }

    /** Records only successful runs, using exactly the interval shown by the on-screen ETA. */
    fun record(
        context: Context,
        durationMs: Long,
        elapsedMs: Long,
        mediaCount: Int = 1,
        horizontal: Boolean = false,
    ) {
        if (durationMs <= 0L || elapsedMs !in 1_000L..MAX_TOTAL_MS) return
        val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val next = (readSamples(context) + Sample(durationMs, elapsedMs, mediaCount.coerceAtLeast(1), horizontal)).takeLast(MAX_SAMPLES)
        prefs.edit().putString("samples", encodeSamples(next)).putBoolean("legacy_migrated", true).apply()
    }

    /**
     * Freeze one calibrated total for the whole operation. The clock and bar must never use
     * separate live guesses: both are derived from this same total and the same elapsed clock.
     * Previous versions mixed Whisper audio-window coverage with elapsed-time progress, which
     * could make the bar jump ahead while the countdown still showed minutes. Learning happens
     * between runs from the last ten completed measurements, not by changing the ruler mid-run.
     */
    @Suppress("UNUSED_PARAMETER")
    fun effectiveTotalMs(
        context: Context,
        durationMs: Long,
        elapsedMs: Long,
        processedAudioMs: Long?,
        sampleElapsedMs: Long?,
        mediaCount: Int? = null,
        horizontal: Boolean? = null,
    ): Long = expectedTotalMs(context, durationMs, mediaCount, horizontal)

    @Suppress("UNUSED_PARAMETER")
    fun remainingMs(totalEstimateMs: Long, durationMs: Long, elapsedMs: Long,
                    processedAudioMs: Long?, sampleElapsedMs: Long?): Long? {
        if (durationMs <= 0L || totalEstimateMs <= 0L) return null
        val remaining = totalEstimateMs - elapsedMs.coerceAtLeast(0L)
        return remaining.coerceAtLeast(1_000L)
    }
}
