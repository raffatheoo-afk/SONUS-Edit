package com.sonusstudios.sonusedit.create

import android.content.Context
import kotlin.math.roundToLong

/** Estimated only: never claim that an ETA is a real-time guarantee. */
object CaptionEtaEstimator14 {
    private const val PREFS = "sonus_caption_eta_code28"
    // Latest device observations: a 30s excerpt completed around 182s,
    // whereas an earlier 60s excerpt took 184s. This suggests major fixed overhead
    // rather than a linear ratio, so extrapolate cautiously and learn on each phone.
    fun defaultMs(durationMs: Long): Long = when {
        durationMs <= 0L -> 0L
        durationMs < 30_000L -> 90_000L + (durationMs * 92_000L / 30_000L)
        durationMs <= 60_000L -> 182_000L + ((durationMs - 30_000L) * 2L / 30L)
        else -> 184_000L + ((durationMs - 60_000L) * 184L / 60L)
    }

    private fun bucket(durationMs: Long) = when {
        durationMs <= 20_000L -> "short"
        durationMs <= 45_000L -> "medium"
        durationMs <= 90_000L -> "one_min"
        durationMs <= 10L * 60_000L -> "long"
        else -> "very_long"
    }

    fun expectedTotalMs(context: Context, durationMs: Long): Long {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val saved = prefs.getLong("eta_${bucket(durationMs)}", 0L)
        return if (saved > 0L) (saved * .70 + defaultMs(durationMs) * .30).roundToLong()
            .coerceAtLeast(15_000L) else defaultMs(durationMs)
    }

    fun record(context: Context, durationMs: Long, elapsedMs: Long) {
        if (durationMs <= 0L || elapsedMs !in 1_000L..(12L * 60L * 60_000L)) return
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val key = "eta_${bucket(durationMs)}"
        val previous = prefs.getLong(key, 0L)
        val next = if (previous <= 0L) elapsedMs else (previous * .6 + elapsedMs * .4).roundToLong()
        prefs.edit().putLong(key, next).apply()
    }

    fun remainingMs(totalEstimateMs: Long, durationMs: Long, elapsedMs: Long,
                    processedAudioMs: Long?, sampleElapsedMs: Long?): Long? {
        if (durationMs <= 0L) return null
        val ratio = (processedAudioMs ?: 0L).toDouble() / durationMs.toDouble()
        val elapsed = elapsedMs.coerceAtLeast(0L)
        val sampled = (sampleElapsedMs ?: 0L).coerceAtLeast(0L)
        val calibrated = if (ratio >= .15 && ratio < .99 && sampled >= 2_000L) {
            val measured = sampled / ratio
            // Favor measured speed, with enough margin for late model merging/finalization.
            maxOf(totalEstimateMs.toDouble(), measured * 1.12)
        } else totalEstimateMs.toDouble()
        val remaining = (calibrated - elapsed).roundToLong()
        return remaining.takeIf { it > 1_000L }
    }
}
