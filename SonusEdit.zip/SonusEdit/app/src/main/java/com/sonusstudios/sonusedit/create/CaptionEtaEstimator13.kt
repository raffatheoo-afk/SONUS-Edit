package com.sonusstudios.sonusedit.create

import kotlin.math.roundToLong

/**
 * UI-only ETA, based on a user measurement: 60 s of audio took 184 s on their phone.
 * Not a guarantee. The model download is NOT included, since its length depends on the network.
 * After Whisper completes a chunk, its measured device speed gradually calibrates the total.
 */
object CaptionEtaEstimator13 {
    private const val BASELINE_AUDIO_MS = 60_000.0
    private const val BASELINE_PROCESS_MS = 184_000.0

    fun baselineMs(durationMs: Long): Long =
        (durationMs.coerceAtLeast(0L).toDouble() * BASELINE_PROCESS_MS / BASELINE_AUDIO_MS / 1_000.0)
            .coerceIn(0.0, (Long.MAX_VALUE / 1_000L).toDouble()).roundToLong() * 1_000L

    /** Null = still preparing, or the estimate has elapsed before Whisper actually finished. */
    fun remainingMs(
        durationMs: Long,
        elapsedMs: Long,
        processedAudioMs: Long? = null,
        sampleElapsedMs: Long? = null,
    ): Long? {
        if (durationMs <= 0L) return null
        val baseline = baselineMs(durationMs).toDouble()
        val processed = processedAudioMs?.coerceIn(0L, durationMs) ?: 0L
        val sampled = sampleElapsedMs?.coerceAtLeast(0L) ?: 0L
        val ratio = processed.toDouble() / durationMs.toDouble()
        val totalEstimate = if (ratio >= 0.10 && sampled > 0L && ratio < 1.0) {
            val speedProjection = (sampled / ratio).coerceAtLeast(1.0)
            // Smooth the projection: early chunks can include loading and language comparison.
            val weight = if (ratio < 0.50) 0.45 else 0.65
            baseline * (1.0 - weight) + speedProjection * weight
        } else baseline
        val remaining = (totalEstimate - elapsedMs.coerceAtLeast(0L)).roundToLong()
        // Never freeze on 00:00 while still processing. The UI shows --:-- instead.
        return remaining.takeIf { it > 0L }
    }

    fun formatRemaining(remainingMs: Long?): String {
        if (remainingMs == null) return "--:--"
        val seconds = ((remainingMs + 999L) / 1_000L).coerceAtLeast(0L)
        val hours = seconds / 3_600L
        val minutes = (seconds % 3_600L) / 60L
        val leftover = seconds % 60L
        return if (hours > 0L) "%d:%02d:%02d".format(hours, minutes, leftover)
        else "%02d:%02d".format(minutes, leftover)
    }
}
