package com.sonusstudios.sonusedit.catalog

import android.content.Context

class StreamHistoryStore(context: Context) {
    private val prefs = context.getSharedPreferences("sonus_edit_stream_history", Context.MODE_PRIVATE)

    data class Entry(val stableKey: String, val genre: String)

    fun recent(limit: Int = 20): List<Entry> = prefs.getString("recent_v2", "")
        .orEmpty()
        .split(';')
        .mapNotNull { token ->
            val parts = token.split('|', limit = 2)
            val key = parts.getOrNull(0)?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
            Entry(key, parts.getOrNull(1).orEmpty())
        }
        .take(limit)

    fun record(asset: PCloudAsset) {
        val updated = (listOf(Entry(asset.stableKey, asset.genre)) + recent(30).filterNot { it.stableKey == asset.stableKey })
            .take(30)
        prefs.edit().putString("recent_v2", updated.joinToString(";") { "${it.stableKey}|${it.genre}" }).apply()
    }
}

object StreamSuggestionEngine {
    fun suggest(catalog: List<PCloudAsset>, history: List<StreamHistoryStore.Entry>): PCloudAsset? {
        if (catalog.isEmpty()) return null
        val recentKeys = history.take(10).map { it.stableKey }.toSet()
        val fresh = catalog.filterNot { it.stableKey in recentKeys }.ifEmpty { catalog }
        val genreCounts = history.groupingBy { it.genre.lowercase() }.eachCount()
        val preferredGenre = genreCounts.maxByOrNull { it.value }?.key
        val weighted = fresh.flatMap { asset ->
            val weight = if (preferredGenre != null && asset.genre.lowercase() == preferredGenre) 3 else 1
            List(weight) { asset }
        }
        return weighted.randomOrNull() ?: fresh.randomOrNull()
    }
}
