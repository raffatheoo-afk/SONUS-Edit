package com.sonusstudios.sonusedit.catalog

import com.sonusstudios.sonusedit.create.SmartImageSelector

/** Exact-query matcher retained for regression tests and diagnostics. Runtime searches refresh all public sources. */
object PCloudSearchCachePolicy {
    fun hasEnoughFreshMatches(
        assets: List<PCloudAsset>,
        query: String,
        mediaExtensions: Set<String>,
        blockedKeys: Set<String>,
        minimumFreshMatches: Int = 11,
    ): Boolean {
        val supported = mediaExtensions.map { it.lowercase() }.toSet()
        val searchable = assets.filter { it.extension.lowercase() in supported }
        val visibleMatches = SmartImageSelector.searchManualGallery(searchable, query, blockedKeys)
        return visibleMatches.size >= minimumFreshMatches.coerceAtLeast(1)
    }
}
