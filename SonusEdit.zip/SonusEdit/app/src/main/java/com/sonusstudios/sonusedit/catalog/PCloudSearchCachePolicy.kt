package com.sonusstudios.sonusedit.catalog

import com.sonusstudios.sonusedit.create.SmartImageSelector

/** Shared gate for cache-first searches: only exact, visible, non-blocked results count as usable. */
object PCloudSearchCachePolicy {
    fun hasEnoughFreshMatches(
        assets: List<PCloudAsset>,
        query: String,
        mediaExtensions: Set<String>,
        blockedKeys: Set<String>,
        minimumFreshMatches: Int = 11,
    ): Boolean {
        val supported = mediaExtensions.map { it.lowercase() }.toSet()
        val searchable = assets.filter { it.extension.lowercase() in supported }
        val visibleMatches = SmartImageSelector.searchManualGallery(searchable, query, blockedKeys)
        return visibleMatches.size >= minimumFreshMatches.coerceAtLeast(1)
    }
}
