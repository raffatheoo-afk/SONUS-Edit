package com.sonusstudios.sonusedit.media

import android.app.ActivityManager
import android.content.Context
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaFormat
import android.os.Build
import com.sonusstudios.sonusedit.create.CreateProjectDraft
import com.sonusstudios.sonusedit.create.ExportResolution
import kotlin.math.max
import kotlin.math.min

/**
 * What this phone's H.264 encoder can really produce (0.0.2/code02). Probed once and cached; the
 * probe never throws and falls back to "everything up to 1080p60", which is what the app assumed
 * before. A phone that supports everything (for example a Galaxy S10e) sees no change at all; a basic
 * phone only loses the options its encoder cannot deliver, instead of failing at the end of an export.
 */
object ExportCapabilities02 {
    data class Result(
        /** Resolutions (9:16 reference sizes) the encoder accepts at 30 FPS. */
        val resolutions30: Set<ExportResolution>,
        /** Resolutions the encoder accepts at 60 FPS. */
        val resolutions60: Set<ExportResolution>,
        /** Largest frame sides the encoder accepts (long side, short side). */
        val maxLongSide: Int,
        val maxShortSide: Int,
        /** Every frame side must be a multiple of this (2 or more). */
        val alignment: Int,
    ) {
        fun supports(resolution: ExportResolution, fps: Int): Boolean =
            if (fps >= 60) resolution in resolutions60 else resolution in resolutions30

        /** Highest resolution available at the given FPS (720p when nothing is reported). */
        fun best(fps: Int): ExportResolution =
            ExportResolution.entries.lastOrNull { supports(it, fps) } ?: ExportResolution.P720

        /**
         * Scales a frame down, keeping its proportion, until the encoder accepts it, and aligns both
         * sides. [capLongSide] lets the caller limit the long side to a resolution tier as well.
         */
        fun fit(width: Int, height: Int, capLongSide: Int = Int.MAX_VALUE): Pair<Int, Int> {
            val longSide = max(width, height).coerceAtLeast(1)
            val shortSide = min(width, height).coerceAtLeast(1)
            val scale = minOf(
                1.0,
                min(maxLongSide, capLongSide).toDouble() / longSide,
                maxShortSide.toDouble() / shortSide,
            )
            return alignDown((width * scale).toInt()) to alignDown((height * scale).toInt())
        }

        fun alignDown(value: Int): Int {
            val step = alignment.coerceAtLeast(2)
            return (value - value % step).coerceAtLeast(step)
        }
    }

    private val safeDefault = Result(
        resolutions30 = setOf(ExportResolution.P720, ExportResolution.P1080, ExportResolution.P2K, ExportResolution.P4K),
        resolutions60 = setOf(ExportResolution.P720, ExportResolution.P1080, ExportResolution.P2K, ExportResolution.P4K),
        maxLongSide = 3840,
        maxShortSide = 2160,
        alignment = 2,
    )

    @Volatile private var cached: Result? = null

    fun probe(context: Context): Result =
        cached ?: synchronized(this) { cached ?: compute(context.applicationContext).also { cached = it } }

    /** Long side limit of each resolution tier (the 9:16 reference height). */
    fun longSideOf(resolution: ExportResolution): Int = resolution.height

    private fun compute(context: Context): Result = runCatching {
        val encoders = MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos
            .filter { info -> info.isEncoder && info.supportedTypes.any { it.equals(MediaFormat.MIMETYPE_VIDEO_AVC, true) } }
        if (encoders.isEmpty()) return@runCatching safeDefault
        // Hardware encoders first: software codecs are what makes basic phones stall or run out of memory.
        val usable = encoders.filter { !isSoftware(it) }.ifEmpty { encoders }
        val videoCaps = usable.mapNotNull {
            runCatching { it.getCapabilitiesForType(MediaFormat.MIMETYPE_VIDEO_AVC).videoCapabilities }.getOrNull()
        }
        if (videoCaps.isEmpty()) return@runCatching safeDefault

        fun supported(resolution: ExportResolution, fps: Double): Boolean = videoCaps.any { caps ->
            val w = resolution.width
            val h = resolution.height
            runCatching {
                caps.areSizeAndRateSupported(w, h, fps) || caps.areSizeAndRateSupported(h, w, fps)
            }.getOrDefault(false)
        }

        val lowRam = (context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager)?.isLowRamDevice == true
        val allowed = if (lowRam) setOf(ExportResolution.P720, ExportResolution.P1080) else ExportResolution.entries.toSet()
        val r30 = ExportResolution.entries.filter { it in allowed && supported(it, 30.0) }.toSet()
        val r60 = ExportResolution.entries.filter { it in allowed && supported(it, 60.0) }.toSet()
        val maxW = videoCaps.maxOf { runCatching { it.supportedWidths.upper }.getOrDefault(1920) }
        val maxH = videoCaps.maxOf { runCatching { it.supportedHeights.upper }.getOrDefault(1920) }
        val align = videoCaps.maxOf { runCatching { max(it.widthAlignment, it.heightAlignment) }.getOrDefault(2) }
        Result(
            resolutions30 = r30.ifEmpty { setOf(ExportResolution.P720) },
            resolutions60 = r60,
            maxLongSide = max(maxW, maxH).coerceAtLeast(1280),
            maxShortSide = min(maxW, maxH).coerceAtLeast(720),
            alignment = align.coerceAtLeast(2),
        )
    }.getOrDefault(safeDefault)

    private fun isSoftware(info: MediaCodecInfo): Boolean =
        if (Build.VERSION.SDK_INT >= 29) info.isSoftwareOnly
        else info.name.startsWith("OMX.google.", true) || info.name.startsWith("c2.android.", true)
}

/**
 * When an export fails for a reason that a smaller export can fix (the encoder or the memory of the
 * phone is not enough), the next attempt uses the next tier down instead of ending in an error:
 * 60 FPS becomes 30 FPS, then the resolution steps down. Errors that a smaller export cannot fix
 * (missing file, no storage, cancelled) are returned as they are.
 */
object ExportFallbackLadder02 {
    private val markers = listOf(
        "encoder", "encoding", "codec", "mediacodec", "configure", "não entregou", "nao entregou",
        "unsupported", "not supported", "frame processing", "opengl", "egl", "out of memory",
    )

    fun isRecoverable(error: Throwable): Boolean {
        val chain = generateSequence(error) { it.cause }.toList()
        if (chain.any { it is OutOfMemoryError }) return true
        val text = chain.mapNotNull { it.message }.joinToString(" ").lowercase()
        return markers.any { text.contains(it) }
    }

    /** The next, lighter draft, or null when there is nothing lighter left to try. */
    fun next(draft: CreateProjectDraft, error: Throwable, alignment: Int): CreateProjectDraft? {
        if (!isRecoverable(error)) return null
        if (draft.exportFps >= 60) return draft.copy(exportFps = 30)
        if (draft.customOutputWidth > 0 && draft.customOutputHeight > 0) {
            if (min(draft.customOutputWidth, draft.customOutputHeight) <= 540) return null
            val step = alignment.coerceAtLeast(2)
            fun scaled(value: Int): Int = ((value * 0.75).toInt()).let { (it - it % step).coerceAtLeast(step) }
            return draft.copy(customOutputWidth = scaled(draft.customOutputWidth), customOutputHeight = scaled(draft.customOutputHeight))
        }
        val lower = when (draft.exportResolution) {
            ExportResolution.P4K -> ExportResolution.P2K
            ExportResolution.P2K -> ExportResolution.P1080
            ExportResolution.P1080 -> ExportResolution.P720
            ExportResolution.P720 -> null
        } ?: return null
        return draft.copy(exportResolution = lower)
    }

    fun describe(draft: CreateProjectDraft): String =
        "Seu aparelho não conseguiu nessa qualidade. Tentando de novo em ${draft.outputLabel()} · ${draft.exportFps} FPS…"
}
