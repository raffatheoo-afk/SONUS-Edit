package com.sonusstudios.sonusedit.navigation

sealed class AppRoute(val route: String) {
    data object Home : AppRoute("home")
    data object Settings : AppRoute("settings")
    data object About : AppRoute("about")
    data object Stats : AppRoute("stats")
    data object Premium : AppRoute("premium")
    data object Create : AppRoute("create")
    data object AutoCaptions : AppRoute("auto_captions")
    data object Editor : AppRoute("editor")
}
