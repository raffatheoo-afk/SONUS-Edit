package com.sonusstudios.sonusedit.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonusstudios.sonusedit.create.CaptionPosition
import com.sonusstudios.sonusedit.create.CaptionSegment
import com.sonusstudios.sonusedit.create.CaptionStyleId
import com.sonusstudios.sonusedit.create.FontPresetId
import com.sonusstudios.sonusedit.create.LyricColorPreset
import com.sonusstudios.sonusedit.designsystem.SonusEditColors
import com.sonusstudios.sonusedit.media.CaptionStyleRenderer
import com.sonusstudios.sonusedit.media.CaptionTypefaces
import kotlinx.coroutines.delay

private const val DEMO_LOOP_MS = 4_400L
private val demoSegments = listOf(CaptionSegment(startMs = 0L, endMs = 3_700L, text = "Sua legenda"))

/** Draws captions with the same renderer used by the exporter, over whatever is behind it. */
@Composable
fun CaptionOverlayCanvas(
    captions: List<CaptionSegment>,
    timeMs: Long,
    font: FontPresetId,
    color: LyricColorPreset,
    style: CaptionStyleId,
    position: CaptionPosition,
    modifier: Modifier = Modifier,
    textScale: Float = 2.2f,
    sizeScale: Float = 1f,
    positionPercent: Float? = null,
) {
    val context = LocalContext.current
    val renderer = remember { CaptionStyleRenderer() }
    val typeface = remember(font) { CaptionTypefaces.resolve(context, font) }
    val prepared = remember(captions) { CaptionStyleRenderer.prepare(captions).sortedBy { it.startMs } }
    val config = remember(style, position, typeface, color, textScale, sizeScale, positionPercent) {
        CaptionStyleRenderer.Config(
            style, position, typeface, color, textScale,
            sizeScale = sizeScale, positionPercent = positionPercent,
        )
    }
    Canvas(modifier) {
        drawIntoCanvas { canvas ->
            renderer.draw(canvas.nativeCanvas, size.width.toInt(), size.height.toInt(), timeMs, prepared, config)
        }
    }
}

/** Horizontal row: "Dinâmico" first, then the ten looks, each card animating a live sample. */
@Composable
fun CaptionStylePicker(
    selected: CaptionStyleId,
    dynamicSelected: Boolean,
    font: FontPresetId,
    color: LyricColorPreset,
    onStyle: (CaptionStyleId) -> Unit,
    onDynamic: () -> Unit,
) {
    val clock by produceState(0L) {
        while (true) {
            value = System.currentTimeMillis() % DEMO_LOOP_MS
            delay(60L)
        }
    }
    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        item {
            StyleCardFrame(dynamicSelected, onDynamic) {
                Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.AutoAwesome, null, Modifier.size(22.dp), tint = Color.White)
                    Text("Estilo dinâmico", color = Color.White, fontSize = 8.sp, maxLines = 1)
                }
            }
        }
        items(CaptionStyleId.entries.toList()) { style ->
            StyleCardFrame(selected == style && !dynamicSelected, { onStyle(style) }) {
                CaptionOverlayCanvas(
                    captions = demoSegments,
                    timeMs = clock,
                    font = font,
                    color = color,
                    style = style,
                    position = CaptionPosition.MIDDLE,
                    modifier = Modifier.fillMaxWidth().height(52.dp).align(Alignment.TopCenter).background(Color(0xFF050711)),
                    textScale = 4.2f,
                )
                Text(
                    style.label,
                    Modifier.align(Alignment.BottomCenter).padding(bottom = 4.dp),
                    color = Color.White,
                    fontSize = 8.sp,
                    maxLines = 1,
                )
            }
        }
    }
}

@Composable
private fun StyleCardFrame(
    selected: Boolean,
    onClick: () -> Unit,
    content: @Composable androidx.compose.foundation.layout.BoxScope.() -> Unit,
) {
    Card(
        modifier = Modifier.width(108.dp).height(76.dp).clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = if (selected) Color(0xFF173F58) else SonusEditColors.SurfaceRaised),
        shape = RoundedCornerShape(10.dp),
    ) {
        Box(
            Modifier.fillMaxSize().border(
                if (selected) 2.dp else 1.dp,
                if (selected) Color(0xFF57D8FF) else Color(0xFF394154),
                RoundedCornerShape(10.dp),
            ),
        ) {
            content()
            if (selected) {
                Icon(Icons.Default.Check, null, Modifier.align(Alignment.TopEnd).padding(3.dp).size(11.dp), tint = Color(0xFF57D8FF))
            }
        }
    }
}

/** Topo / Meio / Embaixo. */
@Composable
fun CaptionPositionPicker(position: CaptionPosition, onPosition: (CaptionPosition) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        CaptionPosition.entries.forEach { value ->
            val selected = value == position
            Button(
                onClick = { onPosition(value) },
                modifier = Modifier.weight(1f).height(40.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (selected) Color(0xFF307EA5) else SonusEditColors.SurfaceRaised,
                    contentColor = Color.White,
                ),
            ) {
                Text(value.label, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            }
        }
    }
}
