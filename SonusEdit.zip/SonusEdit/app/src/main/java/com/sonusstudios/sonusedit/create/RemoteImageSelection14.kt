package com.sonusstudios.sonusedit.create

/**
 * Stable-key-first bookkeeping for remote gallery media.
 * The public folder code is part of the key because file ids can collide across public catalogs.
 */
object RemoteImageSelection14 {
    fun migrateLegacyUrls(
        selectedStableKeys: Collection<String>,
        legacyUrlsByFileId: Map<Long, String>,
    ): Map<String, String> {
        val keysById = selectedStableKeys.filter { it.isNotBlank() }
            .groupByNotNull(::fileIdFromStableKey)
        return buildMap {
            keysById.forEach { (fileId, keys) ->
                val url = legacyUrlsByFileId[fileId]
                // A legacy fileId-only URL is safe only if exactly one stable identity owns it.
                if (keys.size == 1 && !url.isNullOrBlank()) put(keys.single(), url)
            }
        }
    }

    fun fileIdFromStableKey(stableKey: String): Long? =
        stableKey.substringAfterLast(':', "").toLongOrNull()

    fun fileIds(selectedStableKeys: Collection<String>): List<Long> =
        selectedStableKeys.mapNotNull(::fileIdFromStableKey).distinct()

    fun pendingKeys(selectedStableKeys: Collection<String>, urlsByStableKey: Map<String, String>): Set<String> =
        selectedStableKeys.filterTo(linkedSetOf()) { it !in urlsByStableKey }

    fun historyKeys(
        selectedStableKeys: Collection<String>,
        urlsByStableKey: Map<String, String>,
        selectedUris: Collection<String>,
    ): List<String> {
        val uriSet = selectedUris.toSet()
        return selectedStableKeys.filter { key -> urlsByStableKey[key]?.let(uriSet::contains) == true }.distinct()
    }

    fun pruneUrls(urlsByStableKey: Map<String, String>, keptUris: Collection<String>): Map<String, String> {
        val kept = keptUris.toSet()
        return urlsByStableKey.filterValues { it in kept }
    }

    /** Legacy compatibility projection; ambiguous file ids are deliberately omitted. */
    fun legacyProjection(urlsByStableKey: Map<String, String>): Map<Long, String> =
        urlsByStableKey.entries.groupBy { fileIdFromStableKey(it.key) }
            .filterKeys { it != null }
            .mapNotNull { (fileId, entries) ->
                val distinctUrls = entries.map { it.value }.distinct()
                if (distinctUrls.size == 1) fileId!! to distinctUrls.single() else null
            }.toMap()

    private fun <T, K : Any> Iterable<T>.groupByNotNull(keySelector: (T) -> K?): Map<K, List<T>> =
        groupBy { keySelector(it) }.filterKeys { it != null }.mapKeys { it.key!! }
}
