package com.sonusstudios.sonusedit.create

import com.sonusstudios.sonusedit.catalog.PCloudAsset
import java.text.Normalizer

/**
 * Small, bundled music-context index used only to rank automatic gallery suggestions.
 * Manual Gallery searches remain explicit and are never restricted by this classifier.
 */
class MusicImageKeywordCatalog private constructor(
    private val groups: List<Group>,
) {
    private data class Group(
        val id: String,
        val genreAliases: Set<String>,
        val titleTriggers: Set<String>,
        val assetKeywords: Set<String>,
    )

    data class Context internal constructor(
        val groupIds: Set<String>,
        val priorityKeywords: Set<String>,
        val religiousAssetKeywords: Set<String>,
    ) {
        val isReligious: Boolean get() = "religious" in groupIds

        fun isReligiousAsset(asset: PCloudAsset): Boolean = isReligiousAsset(asset.name, asset.folderPath)

        fun isReligiousAsset(name: String, folderPath: String = ""): Boolean {
            if (religiousAssetKeywords.isEmpty()) return false
            val haystack = normalize("${name.substringBeforeLast('.')} $folderPath")
            return religiousAssetKeywords.any { haystack.containsPhrase(it) }
        }

        fun scoreAsset(asset: PCloudAsset): Int {
            if (priorityKeywords.isEmpty()) return 0
            val haystack = normalize("${asset.name.substringBeforeLast('.')} ${asset.folderPath}")
            val hits = priorityKeywords.count { haystack.containsPhrase(it) }
            return (hits * 22).coerceAtMost(220)
        }

        companion object {
            val EMPTY = Context(emptySet(), emptySet(), emptySet())
        }
    }

    fun classify(title: String?, genre: String?): Context {
        val normalizedTitle = normalize(title.orEmpty())
        val normalizedGenre = normalize(genre.orEmpty())
        val religiousTitleMatch = RELIGIOUS_TITLE_MARKERS.any { normalizedTitle.containsPhrase(it) }
        val matched = groups.filter { group ->
            group.genreAliases.any { normalizedGenre.containsPhrase(it) } ||
                group.titleTriggers.any { normalizedTitle.containsPhrase(it) } ||
                (group.id == RELIGIOUS_GROUP_ID && religiousTitleMatch)
        }
        val religiousKeywords = groups.firstOrNull { it.id == RELIGIOUS_GROUP_ID }
            ?.assetKeywords.orEmpty()
            .intersect(STRICT_RELIGIOUS_ASSET_MARKERS)
        return Context(
            groupIds = matched.map { it.id }.toSet(),
            priorityKeywords = matched.flatMap { it.assetKeywords }.toSet(),
            religiousAssetKeywords = religiousKeywords,
        )
    }

    /**
     * Parsing is deterministic and intentionally tolerant: a malformed line is skipped rather
     * than making project creation fail. The asset is tiny and parsed once when Create opens.
     */
    companion object {
        private const val RELIGIOUS_GROUP_ID = "religious"

        // High-confidence title markers supplement the TXT vocabulary so that short, decisive
        // religious terms (for example "louvor") still classify correctly in minimal test/catalog
        // configurations. Generic words are deliberately excluded to avoid false positives.
        private val RELIGIOUS_TITLE_MARKERS = setOf(
            "jesus", "cristo", "gospel", "catolico", "catolica", "cristao", "crista",
            "igreja", "biblia", "eucaristia", "adoracao", "louvor", "evangelho",
            "evangelico", "oracao", "salmo", "espirito santo", "nossa senhora",
            "virgem maria", "aparecida", "padre", "freira", "rosario", "terco",
            "cruz", "worship", "hino religioso", "hino de louvor"
        ).map(::normalize).toSet()

        // High-confidence visual markers only. Generic words such as "santa", "santo", "céu",
        // "fé" or "anjo" must not hide ordinary city/portrait assets from non-religious tracks.
        private val STRICT_RELIGIOUS_ASSET_MARKERS = setOf(
            "jesus", "cristo", "gospel", "catolico", "catolica", "cristao", "crista",
            "igreja", "templo", "altar", "cruz", "biblia", "terco", "rosario", "padre",
            "freira", "virgem maria", "nossa senhora", "aparecida", "eucaristia", "ostia",
            "comunhao", "adoracao", "louvor", "evangelho", "evangelico", "oracao",
            "salmo", "espirito santo", "capela", "catedral", "procissao", "romaria",
            "vaticano", "maos orando", "worship", "religioso", "religiosa"
        ).map(::normalize).toSet()

        fun parse(raw: String): MusicImageKeywordCatalog {
            val parsed = raw.lineSequence()
                .map(String::trim)
                .filter { it.isNotEmpty() && !it.startsWith("#") }
                .mapNotNull { line ->
                    val fields = line.split('|')
                    if (fields.size < 4) return@mapNotNull null
                    val id = fields[0].trim().lowercase()
                    if (id.isBlank()) return@mapNotNull null
                    Group(
                        id = id,
                        genreAliases = parseTerms(fields[1]),
                        titleTriggers = parseTerms(fields[2]),
                        assetKeywords = parseTerms(fields[3]),
                    )
                }
                .distinctBy { it.id }
                .toList()
            return MusicImageKeywordCatalog(parsed)
        }

        fun empty(): MusicImageKeywordCatalog = MusicImageKeywordCatalog(emptyList())

        private fun parseTerms(value: String): Set<String> = value
            .split(';', ',')
            .map(::normalize)
            .filter { it.isNotBlank() }
            .toSet()

        internal fun normalize(value: String): String = Normalizer.normalize(value.lowercase(), Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
            .replace('&', ' ')
            .replace('+', ' ')
            .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
            .trim()
            .replace(Regex("\\s+"), " ")

        private fun String.containsPhrase(phrase: String): Boolean =
            phrase.isNotBlank() && (this == phrase || startsWith("$phrase ") || endsWith(" $phrase") || contains(" $phrase "))
    }
}
