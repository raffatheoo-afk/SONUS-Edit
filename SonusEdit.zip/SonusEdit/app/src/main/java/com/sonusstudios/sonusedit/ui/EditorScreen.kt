package com.sonusstudios.sonusedit.ui

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.sonusstudios.sonusedit.create.CreateProjectDraft
import com.sonusstudios.sonusedit.designsystem.SonusEditColors
import com.sonusstudios.sonusedit.integration.IncomingIntentRouter
import com.sonusstudios.sonusedit.media.ExportForegroundService
import com.sonusstudios.sonusedit.media.ExportProgressBus
import com.sonusstudios.sonusedit.media.ExportServiceStatus

@Composable
fun EditorScreen(
    incomingRoute: IncomingIntentRouter.Route?,
    draft: CreateProjectDraft?,
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val serviceState by ExportProgressBus.state.collectAsState()

    val notificationPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    LaunchedEffect(draft) {
        val sourceDraft = draft ?: return@LaunchedEffect
        val now = System.currentTimeMillis()
        val activeEditMs = (sourceDraft.editingStartedEpochMs?.let { now - it } ?: 0L).coerceAtLeast(0L)
        val exportDraft = sourceDraft.copy(manualWorkMs = sourceDraft.manualWorkMs + activeEditMs)
        val key = ExportForegroundService.draftKey(exportDraft)
        val current = ExportProgressBus.state.value
        if (current.draftKey != key || current.status == ExportServiceStatus.IDLE) {
            ExportForegroundService.start(context.applicationContext, exportDraft)
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().background(SonusEditColors.Black).padding(22.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        when (serviceState.status) {
            ExportServiceStatus.EXPORTING -> {
                val progress = serviceState.progress.coerceIn(0, 100)
                ProcessProgressOverlay(
                    title = "Exportando",
                    // When the phone could not export in the chosen quality, say that a lighter try is running.
                    status = serviceState.notice ?: exportStage(progress),
                    progressPercent = progress,
                    cancelLabel = "CANCELAR",
                    onCancel = { ExportForegroundService.cancel(context.applicationContext) },
                    secondaryLabel = "EXECUÇÃO 2º PLANO",
                    onSecondary = { activity?.moveTaskToBack(true) },
                )
            }

            ExportServiceStatus.SAVED -> {
                val outputUri = serviceState.outputUri?.let(Uri::parse)
                Text("✓", color = SonusEditColors.Cyan, fontSize = 58.sp, fontWeight = FontWeight.Bold)
                Text("Vídeo salvo na galeria", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                Spacer(Modifier.height(10.dp))
                Text("A próxima sugestão do Stream será atualizada pelo seu histórico.", color = SonusEditColors.TextMuted)
                Spacer(Modifier.height(24.dp))
                Button(
                    onClick = {
                        outputUri?.let { uri ->
                            context.startActivity(Intent(Intent.ACTION_VIEW).apply {
                                setDataAndType(uri, "video/mp4")
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            })
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = SonusEditColors.Violet),
                ) {
                    androidx.compose.material3.Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Text(" ASSISTIR")
                }
                Spacer(Modifier.height(10.dp))
                OutlinedButton(
                    onClick = {
                        outputUri?.let { uri ->
                            context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                                type = "video/mp4"
                                putExtra(Intent.EXTRA_STREAM, uri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }, "Compartilhar vídeo"))
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    androidx.compose.material3.Icon(Icons.Default.Share, contentDescription = null)
                    Text(" Compartilhar")
                }
                Spacer(Modifier.height(10.dp))
                OutlinedButton(
                    onClick = {
                        ExportProgressBus.reset()
                        onBack()
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Criar outro") }
            }

            ExportServiceStatus.ERROR -> {
                androidx.compose.material3.Icon(Icons.Default.Close, contentDescription = null, tint = Color.Red)
                Spacer(Modifier.height(12.dp))
                val fullError = serviceState.error.orEmpty()
                Text("Não foi possível criar o vídeo", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Spacer(Modifier.height(8.dp))
                // Plain-Portuguese reason first; the technical detail stays available through "Copiar detalhes".
                Text(fullError.substringBefore("\n\nDetalhe técnico:"), color = SonusEditColors.TextMuted)
                Spacer(Modifier.height(18.dp))
                OutlinedButton(onClick = {
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                    clipboard?.setPrimaryClip(ClipData.newPlainText("Detalhes do erro", fullError))
                }) { Text("Copiar detalhes") }
                Spacer(Modifier.height(10.dp))
                Button(onClick = { ExportProgressBus.reset(); onBack() }) { Text("Voltar") }
            }

            ExportServiceStatus.CANCELLED -> {
                Text("Exportação cancelada", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Spacer(Modifier.height(14.dp))
                Button(onClick = { ExportProgressBus.reset(); onBack() }) { Text("Voltar") }
            }

            ExportServiceStatus.IDLE -> {
                if (draft == null && incomingRoute is IncomingIntentRouter.Route.ExportProgress) {
                    Text("Nenhuma exportação ativa.", color = Color.White, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(14.dp))
                    Button(onClick = onBack) { Text("Voltar") }
                } else {
                    Text("Preparando exportação…", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

private fun exportStage(progress: Int): String = when (progress) {
    in 0..9 -> "Preparando mídia…"
    in 10..24 -> "Sincronizando projeto…"
    in 25..49 -> "Montando imagens…"
    in 50..94 -> "Renderizando vídeo…"
    else -> "Salvando na galeria…"
}
