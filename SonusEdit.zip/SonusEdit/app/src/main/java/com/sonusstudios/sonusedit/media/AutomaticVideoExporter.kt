package com.sonusstudios.sonusedit.media

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.media.MediaMetadataRetriever
import android.media.MediaExtractor
import android.media.MediaMuxer
import android.media.MediaCodec
import android.media.MediaFormat
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.OverlaySettings
import androidx.media3.common.VideoCompositorSettings
import androidx.media3.common.util.Size
import androidx.media3.common.audio.DefaultGainProvider
import androidx.media3.common.audio.GainProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.AlphaScale
import androidx.media3.effect.LanczosResample
import androidx.media3.effect.Presentation
import androidx.media3.effect.StaticOverlaySettings
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.sonusstudios.sonusedit.create.CreateProjectDraft
import com.sonusstudios.sonusedit.create.MediaDistributionPlanner
import com.sonusstudios.sonusedit.create.ProjectAspectRatios
import java.io.File
import java.nio.ByteBuffer
import kotlin.math.abs

@OptIn(UnstableApi::class)
class AutomaticVideoExporter(private val context: Context) {
    private val main = Handler(Looper.getMainLooper())
    private var transformer: Transformer? = null
    private var tempFile: File? = null
    private val longSegmentFiles = mutableListOf<File>()
    // One background check per export, not three frame decodes for every long-video chunk.
    private val remoteEffectsValidated = mutableMapOf<String, PCloudEffectLibrary.Prepared>()
    private var longRoot: File? = null
    private var longCompletedSegments = 0
    private var longTotalSegments = 0
    private var concatenating = false
    @Volatile private var cancelled = false

    fun start(
        draft: CreateProjectDraft,
        onCompleted: (Uri) -> Unit,
        onError: (Throwable) -> Unit,
        onFallback: (String) -> Unit = {},
    ) {
        require(draft.imageUris.isNotEmpty()) { "Selecione ao menos uma imagem." }
        require(
            ProjectAspectRatios.isValid(draft.aspectRatio) || (draft.customOutputWidth > 0 && draft.customOutputHeight > 0)
        ) { "Proporção inválida." }
        require(draft.exportFps in setOf(30, 60)) { "FPS inválido. Use 30 ou 60 FPS." }
        cancel()
        remoteEffectsValidated.clear()
        cancelled = false
        launchAttempt(draft, onCompleted, onError, onFallback)
    }

    /**
     * One export attempt. If it fails for a reason a lighter export can fix (the phone's encoder or
     * memory is not enough), the next attempt uses the next tier down (60 → 30 FPS, then a smaller
     * size) instead of ending in an error. Phones that already export fine never reach this path.
     */
    private fun launchAttempt(
        draft: CreateProjectDraft,
        onCompleted: (Uri) -> Unit,
        finalError: (Throwable) -> Unit,
        onFallback: (String) -> Unit,
    ) {
        val onAttemptError: (Throwable) -> Unit = { error ->
            val lighter = if (cancelled) null
            else ExportFallbackLadder02.next(draft, error, ExportCapabilities02.probe(context).alignment)
            if (lighter != null) {
                android.util.Log.w("SonusEditExport", "Tentando de novo com menos carga: ${lighter.outputLabel()} ${lighter.exportFps} FPS", error)
                main.post { onFallback(ExportFallbackLadder02.describe(lighter)) }
                launchAttempt(lighter, onCompleted, finalError, onFallback)
            } else finalError(error)
        }
        if (draft.segmentDurationMs >= LONG_EXPORT_THRESHOLD_MS) {
            startLongExport(draft, onCompleted, onAttemptError)
        } else {
            startSingleExport(draft, onCompleted, onAttemptError)
        }
    }

    private fun startSingleExport(
        draft: CreateProjectDraft,
        onCompleted: (Uri) -> Unit,
        onError: (Throwable) -> Unit,
    ) {
        val output = File(context.cacheDir, "sonus_edit_${System.currentTimeMillis()}.mp4")
        tempFile = output
        renderDraft(
            draft = draft,
            output = output,
            onRendered = { result ->
                if (cancelled) { output.delete(); return@renderDraft }
                runCatching { validateRealOutput(draft, result, output) }
                    .onFailure { error ->
                        output.delete()
                        main.post { onError(error) }
                        return@renderDraft
                    }
                Thread {
                    runCatching { saveToGallery(output, draft.exportTitle.ifBlank { draft.audioTitle }) }
                        .onSuccess { uri -> main.post { onCompleted(uri) } }
                        .onFailure { error -> main.post { onError(error) } }
                }.start()
            },
            onError = { error ->
                if (!cancelled && ExportRecoveryPolicy14.shouldRetryInChunks(error, draft.segmentDurationMs)) {
                    // A short one-shot render stalled. Rebuild smaller independent timelines
                    // instead of simply increasing the muxer timeout or silently changing FPS.
                    output.delete()
                    startLongExport(draft, onCompleted, onError, RETRY_SEGMENT_MS)
                } else if (!cancelled) {
                    output.delete()
                    onError(error)
                }
            },
        )
    }

    /**
     * Long projects are rendered in bounded chunks, then concatenated with MediaMuxer without a
     * second encode. This avoids losing an entire 60–90 minute export when Media3/MediaCodec stalls
     * after many minutes, and keeps memory/codec pressure bounded.
     */
    private fun startLongExport(
        draft: CreateProjectDraft,
        onCompleted: (Uri) -> Unit,
        onError: (Throwable) -> Unit,
        segmentMaxMs: Long = LONG_EXPORT_SEGMENT_MS,
    ) {
        val segments = buildLongSegmentDrafts(draft, segmentMaxMs)
        longTotalSegments = segments.size
        longCompletedSegments = 0
        concatenating = false
        val root = File(context.cacheDir, "sonus_long_${System.currentTimeMillis()}").apply { mkdirs() }
        longRoot = root
        val finalOutput = File(context.cacheDir, "sonus_edit_${System.currentTimeMillis()}.mp4")
        tempFile = finalOutput

        fun fail(error: Throwable) {
            if (cancelled) return
            transformer?.cancel()
            transformer = null
            longSegmentFiles.forEach { runCatching { it.delete() } }
            longSegmentFiles.clear()
            runCatching { root.deleteRecursively() }
            longRoot = null
            runCatching { finalOutput.delete() }
            main.post { onError(error) }
        }

        fun finishAll() {
            if (cancelled) return
            concatenating = true
            Thread {
                runCatching {
                    concatenateMp4(longSegmentFiles.toList(), finalOutput, segments.map { it.segmentDurationMs })
                    validateMergedOutput(draft, finalOutput)
                    saveToGallery(finalOutput, draft.exportTitle.ifBlank { draft.audioTitle })
                }.onSuccess { uri ->
                    if (cancelled) { runCatching { finalOutput.delete() }; return@onSuccess }
                    longSegmentFiles.forEach { runCatching { it.delete() } }
                    longSegmentFiles.clear()
                    runCatching { root.deleteRecursively() }
                    longRoot = null
                    main.post { onCompleted(uri) }
                }.onFailure(::fail)
            }.start()
        }

        fun renderIndex(index: Int, retry: Int, self: (Int, Int) -> Unit) {
            if (cancelled) return
            if (index >= segments.size) {
                finishAll()
                return
            }
            val segmentDraft = segments[index]
            val output = File(root, "segment_${index.toString().padStart(3, '0')}.mp4")
            renderDraft(
                draft = segmentDraft,
                output = output,
                onRendered = { result ->
                    if (cancelled) { output.delete(); return@renderDraft }
                    runCatching { validateRealOutput(segmentDraft, result, output) }
                        .onSuccess {
                            longSegmentFiles += output
                            longCompletedSegments = index + 1
                            self(index + 1, 0)
                        }
                        .onFailure { error ->
                            output.delete()
                            if (retry < 1) self(index, retry + 1) else fail(error)
                        }
                },
                onError = { error ->
                    output.delete()
                    if (cancelled) return@renderDraft
                    if (retry < 1) self(index, retry + 1) else fail(error)
                },
            )
        }

        lateinit var runner: (Int, Int) -> Unit
        runner = { index, retry -> renderIndex(index, retry, runner) }
        runner(0, 0)
    }

    private fun renderDraft(
        draft: CreateProjectDraft,
        output: File,
        onRendered: (ExportResult) -> Unit,
        onError: (Throwable) -> Unit,
    ) {
        val composition = buildComposition(draft)
        val localTransformer = Transformer.Builder(context)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            // Slow codecs on A15 / S10+ may legitimately take >10 seconds for the first
            // composite frame. This bounded watchdog works alongside chunk retry, not instead.
            .setMaxDelayBetweenMuxerSamplesMs(MUXER_WATCHDOG_MS)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    transformer = null
                    onRendered(exportResult)
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException,
                ) {
                    transformer = null
                    onError(exportException)
                }
            })
            .build()
        transformer = localTransformer
        try {
            localTransformer.start(composition, output.absolutePath)
        } catch (error: Exception) {
            transformer = null
            onError(error)
        }
    }

    private fun buildComposition(draft: CreateProjectDraft): Composition {
        val explicitDurations = draft.visualDurationsMs
            .takeIf { it.size == draft.imageUris.size && it.sum() == draft.segmentDurationMs }
        val durations = explicitDurations ?: MediaDistributionPlanner.durationsForTotalMs(draft.segmentDurationMs, draft.imageUris.size)
        check(durations.sum() == draft.segmentDurationMs) { "A timeline de mídias não fecha a duração total do vídeo." }
        val fadeInFlags = draft.visualFadeInFlags.takeIf { it.size == draft.imageUris.size }
        val fadeOutFlags = draft.visualFadeOutFlags.takeIf { it.size == draft.imageUris.size }
        val sourceOffsets = draft.visualSourceOffsetsMs.takeIf { it.size == draft.imageUris.size }
        val localVideoSet = draft.localVideoUris.toSet()

        val visualItems = draft.imageUris.mapIndexed { index, uriString ->
            val durationMs = durations[index]
            val fadeIn = fadeInFlags?.get(index) ?: true
            val fadeOut = fadeOutFlags?.get(index) ?: true
            if (uriString in localVideoSet) {
                buildLocalVideoItems(
                    draft = draft,
                    uri = Uri.parse(uriString),
                    allocatedMs = durationMs,
                    initialOffsetMs = sourceOffsets?.get(index) ?: 0L,
                    fadeIn = fadeIn,
                    fadeOut = fadeOut,
                )
            } else {
                val mediaItem = MediaItem.Builder()
                    .setUri(Uri.parse(uriString))
                    .setImageDurationMs(durationMs)
                    .build()
                listOf(
                    EditedMediaItem.Builder(mediaItem)
                        .setFrameRate(draft.exportFps)
                        .setEffects(Effects(emptyList(), visualEffectsFor(draft, durationMs, fadeIn, fadeOut)))
                        .build()
                )
            }
        }.flatten()
        val videoSequence = EditedMediaItemSequence.withVideoFrom(visualItems)

        val endMs = draft.segmentStartMs + draft.segmentDurationMs
        val audioItem = MediaItem.Builder()
            .setUri(Uri.parse(draft.audioUri))
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(draft.segmentStartMs)
                    .setEndPositionMs(endMs)
                    .build()
            )
            .build()

        val durationUs = draft.segmentDurationMs * 1_000L
        val fadeInUs = (draft.audioFadeInMs * 1_000L).coerceAtMost(durationUs / 2)
        val fadeOutUs = (draft.audioFadeOutMs * 1_000L).coerceAtMost(durationUs / 2)
        val gainBuilder = DefaultGainProvider.Builder(1f)
        if (fadeInUs > 0L) gainBuilder.addFadeAt(0L, fadeInUs.coerceAtLeast(2L), DefaultGainProvider.FADE_IN_EQUAL_POWER)
        if (fadeOutUs > 0L) {
            gainBuilder.addFadeAt(
                (durationUs - fadeOutUs).coerceAtLeast(0L),
                fadeOutUs.coerceAtLeast(2L),
                DefaultGainProvider.FADE_OUT_EQUAL_POWER,
            )
        }
        val audioEffects = Effects(listOf(GainProcessor(gainBuilder.build())), emptyList())
        val audioSequence = EditedMediaItemSequence.withAudioFrom(
            listOf(EditedMediaItem.Builder(audioItem).setRemoveVideo(true).setEffects(audioEffects).build())
        )

        val rawParticleSequence = buildRawParticleSequence(draft)
        val layered = rawParticleSequence != null
        val builder = if (rawParticleSequence != null) {
            val timingSequence = buildTransparentTimingSequence(draft)
            Composition.Builder(timingSequence, rawParticleSequence, videoSequence, audioSequence)
        } else {
            Composition.Builder(videoSequence, audioSequence)
        }
        // Media3 only has a video compositor when there is more than one video sequence. With a single
        // sequence (no particles) it uses SingleInputVideoGraph, which refuses VideoCompositorSettings
        // ("SingleInputVideoGraph does not use VideoCompositor"). In that case the exact output size is
        // locked by a final Presentation instead, ahead of the overlay.
        if (layered) {
            builder.setVideoCompositorSettings(
                ExactOutputCompositorSettings(draft.outputWidth(), draft.outputHeight())
            )
        }
        val compositionEffects = buildList<Effect> {
            if (!layered) {
                add(Presentation.createForWidthAndHeight(draft.outputWidth(), draft.outputHeight(), Presentation.LAYOUT_SCALE_TO_FIT))
            }
            add(VideoVisualEffects.globalOverlay(context, draft))
        }
        return builder
            .setEffects(Effects(emptyList(), compositionEffects))
            .build()
    }

    private fun visualEffectsFor(
        draft: CreateProjectDraft,
        durationMs: Long,
        fadeIn: Boolean,
        fadeOut: Boolean,
    ): List<Effect> = buildList {
        val outputWidth = draft.outputWidth()
        val outputHeight = draft.outputHeight()
        val targetAspect = outputWidth.toFloat() / outputHeight.toFloat()
        add(
            Presentation.createForAspectRatio(
                targetAspect,
                if (draft.fitFullFrame) Presentation.LAYOUT_SCALE_TO_FIT else Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP,
            )
        )
        add(LanczosResample.scaleToFit(outputWidth, outputHeight))
        VideoVisualEffects.filterEffect(draft.filterPreset)?.let(::add)
        add(
            VideoVisualEffects.imageFadeOverlay(
                durationMs = durationMs,
                fadeInMs = if (fadeIn) draft.imageFadeInMs.coerceAtMost(durationMs / 2) else 0L,
                fadeOutMs = if (fadeOut) draft.imageFadeOutMs.coerceAtMost(durationMs / 2) else 0L,
            )
        )
    }

    private fun buildLocalVideoItems(
        draft: CreateProjectDraft,
        uri: Uri,
        allocatedMs: Long,
        initialOffsetMs: Long = 0L,
        fadeIn: Boolean = true,
        fadeOut: Boolean = true,
    ): List<EditedMediaItem> {
        val sourceDuration = localVideoDurationMs(uri).coerceAtLeast(1L)
        data class Chunk(val startMs: Long, val durationMs: Long)
        val chunks = mutableListOf<Chunk>()
        var remaining = allocatedMs.coerceAtLeast(1L)
        var cursor = initialOffsetMs % sourceDuration
        while (remaining > 0L) {
            val available = (sourceDuration - cursor).coerceAtLeast(1L)
            val chunk = remaining.coerceAtMost(available)
            chunks += Chunk(cursor, chunk)
            remaining -= chunk
            cursor = 0L
        }
        return chunks.mapIndexed { index, chunk ->
            val mediaItem = MediaItem.Builder()
                .setUri(uri)
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(chunk.startMs)
                        .setEndPositionMs(chunk.startMs + chunk.durationMs)
                        .build()
                )
                .build()
            EditedMediaItem.Builder(mediaItem)
                .setRemoveAudio(true)
                .setFrameRate(draft.exportFps)
                .setEffects(
                    Effects(
                        emptyList(),
                        visualEffectsFor(
                            draft = draft,
                            durationMs = chunk.durationMs,
                            fadeIn = fadeIn && index == 0,
                            fadeOut = fadeOut && index == chunks.lastIndex,
                        ),
                    )
                )
                .build()
        }
    }

    private fun localVideoDurationMs(uri: Uri): Long {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, uri)
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 5_000L
        } catch (_: Throwable) {
            5_000L
        } finally {
            runCatching { retriever.release() }
        }
    }

    private fun buildTransparentTimingSequence(draft: CreateProjectDraft): EditedMediaItemSequence {
        val timingUri = materializeBundledResource(
            com.sonusstudios.sonusedit.R.drawable.sonus_transparent_timing,
            "sonus_transparent_timing.png",
        )
        val timingMediaItem = MediaItem.Builder()
            .setUri(timingUri)
            .setImageDurationMs(draft.segmentDurationMs)
            .build()
        val timingItem = EditedMediaItem.Builder(timingMediaItem)
            .setFrameRate(draft.exportFps)
            .setEffects(
                Effects(
                    emptyList(),
                    listOf(
                        Presentation.createForWidthAndHeight(
                            draft.outputWidth(),
                            draft.outputHeight(),
                            Presentation.LAYOUT_STRETCH_TO_FIT,
                        ),
                        AlphaScale(0f),
                    ),
                )
            )
            .build()
        return EditedMediaItemSequence.withVideoFrom(listOf(timingItem))
    }

    private fun buildRawParticleSequence(draft: CreateProjectDraft): EditedMediaItemSequence? {
        if (!draft.particlesEnabled || draft.automaticEffectId == EffectIds.NONE || draft.automaticEffectOpacity <= 0f) return null
        val localSource = RawParticleSources.resolve(draft.automaticEffectId)
        val remoteSource = if (PCloudEffectLibrary.isCloud(draft.automaticEffectId)) {
            remoteEffectsValidated.getOrPut(draft.automaticEffectId) {
                PCloudEffectLibrary(context).cachedPrepared(draft.automaticEffectId)
                    ?: error("Efeito remoto não preparado; impossível exportar com segurança.")
            }
        } else null
        if (localSource == null && remoteSource == null) return null

        // code14 browser-safe assets: each bundled MP4 is a visually selected compact loop copied
        // directly from the original source (no re-encode): 16 s green / 15 s black. Longer
        // exports concatenate the same excerpt until the project duration is covered. No frame
        // interpolation or atlas is used.
        val resourceUri = if (remoteSource != null) {
            Uri.fromFile(remoteSource.file)
        } else {
            val source = requireNotNull(localSource)
            materializeBundledResource(
                source.rawResourceId,
                if (source.mode == RawParticleVideoEffect.Mode.GREEN_CHROMA) {
                    "sonus_particles_green_60fps.mp4"
                } else {
                    "sonus_particles_black_30fps.mp4"
                },
            )
        }
        val mode = remoteSource?.mode ?: requireNotNull(localSource).mode
        val loopDurationMs = remoteSource?.durationMs?.minus(80L)?.coerceAtLeast(1_000L)
            ?: requireNotNull(localSource).loopDurationMs
        val outputWidth = draft.outputWidth()
        val outputHeight = draft.outputHeight()
        val effects = buildList<Effect> {
            // Keep exactly the same approved 9:16 source MP4 and chroma/luma key. For horizontal
            // projects we center-crop that transparent keyed frame to 16:9 (top/bottom removed),
            // then Lanczos-resample to the requested export size. No separate horizontal asset,
            // stretch, motion interpolation or source re-encode is introduced.
            add(RawParticleVideoEffect(mode, draft.automaticEffectOpacity, cloudOptimized = remoteSource != null))
            if (draft.aspectRatio != ProjectAspectRatios.VERTICAL) {
                add(
                    Presentation.createForAspectRatio(
                        outputWidth.toFloat() / outputHeight.toFloat(),
                        Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP,
                    )
                )
            }
            add(LanczosResample.scaleToFit(outputWidth, outputHeight))
        }

        val items = mutableListOf<EditedMediaItem>()
        var remainingMs = draft.segmentDurationMs.coerceAtLeast(1L)
        while (remainingMs > 0L) {
            val thisLoopMs = remainingMs.coerceAtMost(loopDurationMs)
            val mediaItem = MediaItem.Builder()
                .setUri(resourceUri)
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(0L)
                        .setEndPositionMs(thisLoopMs)
                        .build()
                )
                .build()
            items += EditedMediaItem.Builder(mediaItem)
                .setRemoveAudio(true)
                .setEffects(Effects(emptyList(), effects))
                .build()
            remainingMs -= thisLoopMs
        }
        return EditedMediaItemSequence.withVideoFrom(items)
    }

    private fun buildLongSegmentDrafts(draft: CreateProjectDraft, maxChunkMs: Long): List<CreateProjectDraft> {
        val fullDurations = draft.visualDurationsMs
            .takeIf { it.size == draft.imageUris.size && it.sum() == draft.segmentDurationMs }
            ?: MediaDistributionPlanner.durationsForTotalMs(draft.segmentDurationMs, draft.imageUris.size)
        val mediaStarts = mutableListOf<Long>()
        var cursor = 0L
        fullDurations.forEach { duration ->
            mediaStarts += cursor
            cursor += duration
        }

        val result = mutableListOf<CreateProjectDraft>()
        var chunkStart = 0L
        while (chunkStart < draft.segmentDurationMs) {
            val chunkDuration = minOf(maxChunkMs, draft.segmentDurationMs - chunkStart)
            val chunkEnd = chunkStart + chunkDuration
            val uris = mutableListOf<String>()
            val localVideos = mutableListOf<String>()
            val durations = mutableListOf<Long>()
            val sourceOffsets = mutableListOf<Long>()
            val fadeIns = mutableListOf<Boolean>()
            val fadeOuts = mutableListOf<Boolean>()

            draft.imageUris.forEachIndexed { index, uri ->
                val mediaStart = mediaStarts[index]
                val mediaEnd = mediaStart + fullDurations[index]
                val overlapStart = maxOf(chunkStart, mediaStart)
                val overlapEnd = minOf(chunkEnd, mediaEnd)
                if (overlapEnd > overlapStart) {
                    uris += uri
                    if (uri in draft.localVideoUris) localVideos += uri
                    durations += overlapEnd - overlapStart
                    sourceOffsets += (overlapStart - mediaStart).coerceAtLeast(0L)
                    fadeIns += overlapStart == mediaStart
                    fadeOuts += overlapEnd == mediaEnd
                }
            }
            check(uris.isNotEmpty() && durations.sum() == chunkDuration) {
                "Não foi possível dividir a timeline longa sem gaps."
            }

            val shiftedCaptions = draft.captionSegments.mapNotNull { caption ->
                val overlapStart = maxOf(caption.startMs, chunkStart)
                val overlapEnd = minOf(caption.endMs, chunkEnd)
                if (overlapEnd <= overlapStart) null else caption.copy(
                    startMs = overlapStart - chunkStart,
                    endMs = overlapEnd - chunkStart,
                )
            }
            result += draft.copy(
                segmentStartMs = draft.segmentStartMs + chunkStart,
                segmentDurationMs = chunkDuration,
                imageUris = uris,
                localVideoUris = localVideos,
                visualDurationsMs = durations,
                visualSourceOffsetsMs = sourceOffsets,
                visualFadeInFlags = fadeIns,
                visualFadeOutFlags = fadeOuts,
                captionSegments = shiftedCaptions,
                audioFadeInMs = if (chunkStart == 0L) draft.audioFadeInMs else 0L,
                audioFadeOutMs = if (chunkEnd == draft.segmentDurationMs) draft.audioFadeOutMs else 0L,
            )
            chunkStart = chunkEnd
        }
        return result
    }

    private fun concatenateMp4(files: List<File>, output: File, durationsMs: List<Long>) {
        require(files.isNotEmpty() && files.size == durationsMs.size) { "Segmentos inválidos para finalizar o vídeo." }
        if (output.exists()) output.delete()

        val firstExtractor = MediaExtractor()
        firstExtractor.setDataSource(files.first().absolutePath)
        val trackTypes = mutableListOf<String>()
        val trackFormats = mutableListOf<MediaFormat>()
        for (i in 0 until firstExtractor.trackCount) {
            val format = firstExtractor.getTrackFormat(i)
            val mime = format.getString(MediaFormat.KEY_MIME).orEmpty()
            if (mime.startsWith("video/") || mime.startsWith("audio/")) {
                trackTypes += if (mime.startsWith("video/")) "video" else "audio"
                trackFormats += format
            }
        }
        firstExtractor.release()
        require(trackFormats.isNotEmpty()) { "Nenhuma faixa válida nos segmentos renderizados." }

        val muxer = MediaMuxer(output.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val outputTrackByType = mutableMapOf<String, Int>()
        trackFormats.forEachIndexed { index, format ->
            val type = trackTypes[index]
            if (type !in outputTrackByType) outputTrackByType[type] = muxer.addTrack(format)
        }
        val rotation = runCatching {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(files.first().absolutePath)
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            } finally { retriever.release() }
        }.getOrDefault(0)
        if (rotation != 0) muxer.setOrientationHint(rotation)
        muxer.start()

        try {
            var segmentOffsetUs = 0L
            files.forEachIndexed { fileIndex, file ->
                // Use a fresh extractor per track. After an extractor reaches EOS on one selected
                // track, simply switching selection does not rewind it; reusing the same instance
                // can silently drop the audio track from the concatenated long video.
                val probe = MediaExtractor()
                val tracks = mutableListOf<Pair<Int, String>>()
                try {
                    probe.setDataSource(file.absolutePath)
                    for (track in 0 until probe.trackCount) {
                        val mime = probe.getTrackFormat(track).getString(MediaFormat.KEY_MIME).orEmpty()
                        when {
                            mime.startsWith("video/") -> tracks += track to "video"
                            mime.startsWith("audio/") -> tracks += track to "audio"
                        }
                    }
                } finally {
                    probe.release()
                }

                tracks.forEach { (track, type) ->
                    val outTrack = outputTrackByType[type] ?: return@forEach
                    val extractor = MediaExtractor()
                    try {
                        extractor.setDataSource(file.absolutePath)
                        val format = extractor.getTrackFormat(track)
                        extractor.selectTrack(track)
                        val requested = if (format.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) {
                            runCatching { format.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE) }.getOrDefault(2 * 1024 * 1024)
                        } else 2 * 1024 * 1024
                        val buffer = ByteBuffer.allocateDirect(requested.coerceIn(2 * 1024 * 1024, 32 * 1024 * 1024))
                        val info = MediaCodec.BufferInfo()
                        var baseSampleUs = -1L
                        var lastPtsUs = -1L
                        while (true) {
                            buffer.clear()
                            val size = extractor.readSampleData(buffer, 0)
                            if (size < 0) break
                            val sampleUs = extractor.sampleTime
                            if (baseSampleUs < 0L) baseSampleUs = sampleUs.coerceAtLeast(0L)
                            var pts = segmentOffsetUs + (sampleUs - baseSampleUs).coerceAtLeast(0L)
                            if (pts <= lastPtsUs) pts = lastPtsUs + 1L
                            info.set(0, size, pts, extractor.sampleFlags)
                            buffer.position(0)
                            buffer.limit(size)
                            muxer.writeSampleData(outTrack, buffer, info)
                            lastPtsUs = pts
                            extractor.advance()
                        }
                    } finally {
                        extractor.release()
                    }
                }
                segmentOffsetUs += durationsMs[fileIndex] * 1_000L
            }
        } finally {
            runCatching { muxer.stop() }
            muxer.release()
        }
        require(output.exists() && output.length() > 0L) { "Falha ao unir os segmentos do vídeo longo." }
    }

    private fun validateMergedOutput(draft: CreateProjectDraft, output: File) {
        val expectedW = draft.outputWidth()
        val expectedH = draft.outputHeight()
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(output.absolutePath)
            val rawW = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull()
            val rawH = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull()
            val rotation = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            val duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            if (rawW != null && rawH != null) {
                val rotated = rotation % 180 != 0
                val visualW = if (rotated) rawH else rawW
                val visualH = if (rotated) rawW else rawH
                require(visualW == expectedW && visualH == expectedH) {
                    "O vídeo longo final não manteve ${draft.outputLabel()}."
                }
            }
            require(duration >= draft.segmentDurationMs - 3_000L) {
                "O vídeo longo final ficou incompleto (${duration} ms de ${draft.segmentDurationMs} ms)."
            }
        } finally {
            retriever.release()
        }
    }

    private fun materializeBundledResource(resourceId: Int, fileName: String): Uri {
        val cacheRoot = File(context.cacheDir, "sonus_edit_export_assets").apply { mkdirs() }
        val target = File(cacheRoot, fileName)
        if (!target.exists() || target.length() == 0L) {
            val temporary = File(cacheRoot, "$fileName.tmp")
            context.resources.openRawResource(resourceId).use { input ->
                temporary.outputStream().use { output -> input.copyTo(output) }
            }
            if (target.exists()) target.delete()
            check(temporary.renameTo(target)) { "Não foi possível preparar o asset interno: $fileName" }
        }
        return Uri.fromFile(target)
    }

    private fun validateRealOutput(draft: CreateProjectDraft, result: ExportResult, output: File) {
        val expectedW = draft.outputWidth()
        val expectedH = draft.outputHeight()

        // Media3/MediaCodec may physically encode portrait video with swapped dimensions and
        // a 90/270 degree rotation flag. Validate the VISUAL orientation of the MP4 rather than
        // rejecting a correct 9:16 file because ExportResult reports the encoded surface size.
        val metadata = runCatching {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(output.absolutePath)
                val rawW = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull()
                val rawH = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull()
                val rotation = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                if (rawW != null && rawH != null) Triple(rawW, rawH, rotation) else null
            } finally {
                retriever.release()
            }
        }.getOrNull()

        val dimensionsOk = if (metadata != null) {
            val (rawW, rawH, rotation) = metadata
            val rotated = rotation % 180 != 0
            val visualW = if (rotated) rawH else rawW
            val visualH = if (rotated) rawW else rawH
            visualW == expectedW && visualH == expectedH
        } else {
            // Fallback for encoders where retriever metadata is not available yet. A swapped exact
            // pair is accepted because it is the canonical encoded-surface form of portrait MP4.
            (result.width == expectedW && result.height == expectedH) ||
                (!draft.isHorizontalOutput() && result.width == expectedH && result.height == expectedW)
        }

        if (!dimensionsOk) {
            val metadataDescription = metadata?.let { (w, h, r) -> "MP4: ${w}x${h}, rotação ${r}°" }
                ?: "ExportResult: ${result.width}x${result.height}"
            error(
                "O aparelho não entregou ${draft.outputLabel()} real. " +
                    "$metadataDescription; esperado visual: ${expectedW}x${expectedH}."
            )
        }

        val durationMs = result.approximateDurationMs.takeIf { it > 0 } ?: draft.segmentDurationMs
        if (result.videoFrameCount > 0 && durationMs > 0) {
            val actualFps = result.videoFrameCount * 1_000.0 / durationMs
            if (abs(actualFps - draft.exportFps) > 2.0) {
                error(
                    "O aparelho não entregou ${draft.exportFps} FPS reais " +
                        "(resultado aproximado: %.1f FPS).".format(actualFps)
                )
            }
        }
    }

    fun progressPercent(): Int? {
        if (longTotalSegments > 0) {
            if (concatenating) return 99
            val localProgress = transformer?.let { local ->
                val holder = ProgressHolder()
                if (local.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) holder.progress else 0
            } ?: 0
            val completed = longCompletedSegments.coerceAtMost(longTotalSegments)
            return (((completed * 100.0) + localProgress) / longTotalSegments.toDouble()).toInt().coerceIn(0, 98)
        }
        val local = transformer ?: return null
        val holder = ProgressHolder()
        val state = local.getProgress(holder)
        return if (state == Transformer.PROGRESS_STATE_AVAILABLE) holder.progress else null
    }

    fun cancel() {
        cancelled = true
        transformer?.cancel()
        transformer = null
        tempFile?.takeIf { it.exists() }?.delete()
        tempFile = null
        longSegmentFiles.forEach { runCatching { it.delete() } }
        longSegmentFiles.clear()
        runCatching { longRoot?.deleteRecursively() }
        longRoot = null
        longCompletedSegments = 0
        longTotalSegments = 0
        concatenating = false
    }

    private companion object {
        const val LONG_EXPORT_THRESHOLD_MS = 10L * 60_000L
        const val LONG_EXPORT_SEGMENT_MS = 4L * 60_000L
        private const val RETRY_SEGMENT_MS = 12_000L
        private const val MUXER_WATCHDOG_MS = 30_000L
    }

    private fun saveToGallery(source: File, title: String): Uri {
        val safe = title.replace(Regex("[^\\p{L}\\p{N}_\\- ]"), "").trim().ifBlank { "Sonus_Edit" }
        val fileName = "${safe.take(48)}_${System.currentTimeMillis()}.mp4"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Sonus Edit")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: error("Não foi possível criar o vídeo na galeria.")
            try {
                resolver.openOutputStream(uri, "w")!!.use { out -> source.inputStream().use { it.copyTo(out) } }
                values.clear()
                values.put(MediaStore.Video.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                source.delete()
                return uri
            } catch (t: Throwable) {
                resolver.delete(uri, null, null)
                throw t
            }
        }

        val dir = File(context.getExternalFilesDir(Environment.DIRECTORY_MOVIES), "Sonus Edit").apply { mkdirs() }
        val target = File(dir, fileName)
        source.copyTo(target, overwrite = true)
        source.delete()
        return Uri.fromFile(target)
    }
}

/**
 * Both visual inputs are pre-presented at the exact export size. Returning that same size here
 * prevents the compositor from deriving any crop/zoom from a source resolution.
 */
@OptIn(UnstableApi::class)
private class ExactOutputCompositorSettings(
    private val width: Int,
    private val height: Int,
) : VideoCompositorSettings {
    override fun getOutputSize(inputSizes: List<Size>): Size = Size(width, height)

    override fun getOverlaySettings(inputId: Int, presentationTimeUs: Long): OverlaySettings =
        StaticOverlaySettings.Builder().build()
}
