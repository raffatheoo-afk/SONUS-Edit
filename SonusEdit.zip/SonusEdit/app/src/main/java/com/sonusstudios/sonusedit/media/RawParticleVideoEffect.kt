package com.sonusstudios.sonusedit.media

import android.content.Context
import android.opengl.GLES20
import androidx.media3.common.VideoFrameProcessingException
import androidx.media3.common.util.GlProgram
import androidx.media3.common.util.GlUtil
import androidx.media3.common.util.Size
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BaseGlShaderProgram
import androidx.media3.effect.GlEffect
import androidx.media3.effect.GlShaderProgram
import com.sonusstudios.sonusedit.R

/**
 * code14: lightweight GPU key for the two original 9:16 particle MP4s.
 *
 * No atlas, frame interpolation, CPU bitmap extraction, colour animation or zoom is used.
 * Each decoded source frame stays a real video frame and only receives an alpha mask.
 */
@OptIn(UnstableApi::class)
class RawParticleVideoEffect(
    private val mode: Mode,
    private val opacity: Float,
    private val cloudOptimized: Boolean = false,
) : GlEffect {
    enum class Mode { GREEN_CHROMA, BLACK_LUMA }

    override fun toGlShaderProgram(context: Context, useHdr: Boolean): GlShaderProgram {
        return RawParticleKeyShaderProgram(
            context = context,
            useHdr = useHdr,
            mode = mode,
            opacity = opacity.coerceIn(0f, 1f),
            cloudOptimized = cloudOptimized,
        )
    }
}

@OptIn(UnstableApi::class)
class RawParticleKeyShaderProgram(
    context: Context,
    useHdr: Boolean,
    mode: RawParticleVideoEffect.Mode,
    opacity: Float,
    cloudOptimized: Boolean = false,
) : BaseGlShaderProgram(
    /* useHighPrecisionColorComponents = */ useHdr,
    /* texturePoolCapacity = */ 1,
) {
    private val glProgram: GlProgram

    init {
        try {
            glProgram = GlProgram(
                context,
                R.raw.sonus_video_key_vertex,
                R.raw.sonus_video_key_fragment,
            )
            glProgram.setBufferAttribute(
                "aFramePosition",
                GlUtil.getNormalizedCoordinateBounds(),
                GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE,
            )
            val identity = GlUtil.create4x4IdentityMatrix()
            glProgram.setFloatsUniform("uTransformationMatrix", identity)
            glProgram.setFloatsUniform("uTexTransformationMatrix", identity)
            glProgram.setFloatUniform(
                "uMode",
                when {
                    !cloudOptimized && mode == RawParticleVideoEffect.Mode.GREEN_CHROMA -> 0f
                    !cloudOptimized && mode == RawParticleVideoEffect.Mode.BLACK_LUMA -> 1f
                    cloudOptimized && mode == RawParticleVideoEffect.Mode.GREEN_CHROMA -> 2f
                    else -> 3f
                },
            )
            glProgram.setFloatUniform("uOpacity", opacity)
        } catch (e: Exception) {
            throw VideoFrameProcessingException(e)
        }
    }

    override fun configure(inputWidth: Int, inputHeight: Int): Size = Size(inputWidth, inputHeight)

    override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
        try {
            glProgram.use()
            glProgram.setSamplerTexIdUniform("uTexSampler", inputTexId, 0)
            glProgram.bindAttributesAndUniforms()
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e, presentationTimeUs)
        }
    }

    override fun release() {
        super.release()
        try {
            glProgram.delete()
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e)
        }
    }
}

/** Maps the public effect id to exactly one bundled original MP4. */
object RawParticleSources {
    data class Source(
        val rawResourceId: Int,
        val mode: RawParticleVideoEffect.Mode,
        val nativeFps: Int,
        val loopDurationMs: Long,
    )

    fun resolve(effectId: String): Source? = when (effectId) {
        EffectIds.RAW_GREEN_60 -> Source(
            R.raw.sonus_particles_green_60fps,
            RawParticleVideoEffect.Mode.GREEN_CHROMA,
            60,
            16_000L,
        )
        EffectIds.RAW_BLACK_30 -> Source(
            R.raw.sonus_particles_black_30fps,
            RawParticleVideoEffect.Mode.BLACK_LUMA,
            30,
            15_000L,
        )
        else -> null
    }
}
