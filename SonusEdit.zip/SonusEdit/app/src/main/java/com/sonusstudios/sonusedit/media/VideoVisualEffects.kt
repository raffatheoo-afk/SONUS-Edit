package com.sonusstudios.sonusedit.media

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import android.text.TextPaint
import androidx.media3.common.Effect
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.CanvasOverlay
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.OverlayEffect
import com.sonusstudios.sonusedit.R
import com.sonusstudios.sonusedit.create.CreateProjectDraft
import com.sonusstudios.sonusedit.create.FilterPresetId
import com.sonusstudios.sonusedit.create.FontPresetId
import com.sonusstudios.sonusedit.editor.LrcLine
import com.sonusstudios.sonusedit.editor.LrcParser
import kotlin.math.floor
import kotlin.math.sin

@OptIn(UnstableApi::class)
object VideoVisualEffects {
    fun filterEffect(filter: FilterPresetId): Effect? = when (filter) {
        FilterPresetId.ORIGINAL -> null
        FilterPresetId.CINEMATIC -> HslAdjustment.Builder().adjustSaturation(-12f).adjustLightness(-4f).adjustHue(-3f).build()
        FilterPresetId.SUNSET -> HslAdjustment.Builder().adjustSaturation(18f).adjustLightness(3f).adjustHue(-14f).build()
        FilterPresetId.VINTAGE_FILM -> HslAdjustment.Builder().adjustSaturation(-25f).adjustLightness(4f).adjustHue(7f).build()
        FilterPresetId.NIGHT_CITY -> HslAdjustment.Builder().adjustSaturation(22f).adjustLightness(-13f).adjustHue(16f).build()
        FilterPresetId.NATURAL_PLUS -> HslAdjustment.Builder().adjustSaturation(8f).adjustLightness(2f).build()
        FilterPresetId.SOFT_LIGHT -> HslAdjustment.Builder().adjustSaturation(-5f).adjustLightness(9f).build()
        FilterPresetId.WARM_NATURAL -> HslAdjustment.Builder().adjustSaturation(7f).adjustLightness(3f).adjustHue(-7f).build()
        FilterPresetId.COOL_NATURAL -> HslAdjustment.Builder().adjustSaturation(3f).adjustLightness(1f).adjustHue(8f).build()
        FilterPresetId.SOFT_CONTRAST -> HslAdjustment.Builder().adjustSaturation(6f).adjustLightness(-2f).build()
        FilterPresetId.CINEMA_CLEAN -> HslAdjustment.Builder().adjustSaturation(-8f).adjustLightness(2f).adjustHue(2f).build()
        FilterPresetId.GOLDEN -> HslAdjustment.Builder().adjustSaturation(16f).adjustLightness(5f).adjustHue(-10f).build()
        FilterPresetId.CLEAN_NIGHT -> HslAdjustment.Builder().adjustSaturation(7f).adjustLightness(-9f).adjustHue(10f).build()
        FilterPresetId.PASTEL_NATURAL -> HslAdjustment.Builder().adjustSaturation(-18f).adjustLightness(11f).build()
        FilterPresetId.CLARITY_PLUS -> HslAdjustment.Builder().adjustSaturation(12f).adjustLightness(1f).build()
    }

    fun globalOverlay(context: Context, draft: CreateProjectDraft): OverlayEffect =
        OverlayEffect(listOf(SonusCanvasOverlay(context, draft)))

    fun imageFadeOverlay(durationMs: Long, fadeInMs: Long, fadeOutMs: Long): OverlayEffect =
        OverlayEffect(listOf(ImageFadeOverlay(durationMs, fadeInMs, fadeOutMs)))
}

@OptIn(UnstableApi::class)
private class ImageFadeOverlay(
    private val durationMs: Long,
    private val fadeInMs: Long,
    private val fadeOutMs: Long,
) : CanvasOverlay(true) {
    private val black = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
    private var firstTimestampUs: Long? = null

    override fun onDraw(canvas: Canvas, presentationTimeUs: Long) {
        canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
        // Media3 may expose a composition timestamp. Anchor the first frame of EACH image clip
        // and always calculate fades in clip-local time. This prevents the old 5s/global-time
        // bug where later images became fully transparent/black.
        val baseUs = firstTimestampUs ?: presentationTimeUs.also { firstTimestampUs = it }
        val t = ((presentationTimeUs - baseUs).coerceAtLeast(0L)) / 1_000L
        val alpha = when {
            fadeInMs > 0 && t < fadeInMs -> ((1f - t.toFloat() / fadeInMs) * 255).toInt()
            fadeOutMs > 0 && t > durationMs - fadeOutMs -> (((t - (durationMs - fadeOutMs)).toFloat() / fadeOutMs) * 255).toInt()
            else -> 0
        }.coerceIn(0, 255)
        if (alpha > 0) {
            black.alpha = alpha
            canvas.drawRect(0f, 0f, canvas.width.toFloat(), canvas.height.toFloat(), black)
        }
    }
}

@OptIn(UnstableApi::class)
private class SonusCanvasOverlay(
    private val context: Context,
    private val draft: CreateProjectDraft,
) : CanvasOverlay(true) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val lyrics: List<LrcLine> = draft.syncedLyrics?.let { raw ->
        LrcParser.sliceAndShift(
            LrcParser.parse(raw),
            draft.segmentStartMs,
            draft.segmentStartMs + draft.segmentDurationMs,
        ).map { line -> line.copy(text = sanitizeLyricText(line.text)) }
    }.orEmpty()
    private val signatureBitmap: Bitmap? = draft.signaturePhotoUri?.let { value ->
        runCatching {
            context.contentResolver.openInputStream(Uri.parse(value))?.use { BitmapFactory.decodeStream(it) }
        }.getOrNull()
    }
    private val atlas: Bitmap? = BitmapFactory.decodeResource(context.resources, R.drawable.effect_particles_source)
    private val atlasCols = 9
    private val atlasRows = 5
    private val atlasFrames = 45
    private val effectFps = 3f

    private var metadataCanvasWidth = -1
    private var metadataTitleSize = 0f
    private var metadataArtistSize = 0f

    private val colors = intArrayOf(
        Color.rgb(0, 232, 255), Color.rgb(112, 255, 112), Color.rgb(255, 79, 163),
        Color.rgb(255, 224, 64), Color.rgb(184, 92, 255), Color.rgb(255, 78, 78),
        Color.rgb(70, 140, 255),
    )

    override fun onDraw(canvas: Canvas, presentationTimeUs: Long) {
        canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
        drawAnimatedEffect(canvas, presentationTimeUs)
        drawSignature(canvas)
        drawLyrics(canvas, presentationTimeUs / 1_000L)
        drawMetadata(canvas)
    }

    private fun drawAnimatedEffect(canvas: Canvas, timeUs: Long) {
        if (draft.automaticEffectId == EffectIds.NONE || draft.automaticEffectOpacity <= 0f) return
        val bitmap = atlas ?: return
        val cellW = bitmap.width / atlasCols
        val cellH = bitmap.height / atlasRows
        if (cellW <= 0 || cellH <= 0) return

        val frameFloat = ((timeUs / 1_000_000f) * effectFps) % atlasFrames
        val first = floor(frameFloat).toInt().coerceIn(0, atlasFrames - 1)
        val next = (first + 1) % atlasFrames
        val mix = frameFloat - floor(frameFloat)
        val dst = RectF(0f, 0f, canvas.width.toFloat(), canvas.height.toFloat())
        val baseAlpha = draft.automaticEffectOpacity.coerceIn(0f, 1f) * 255f

        val firstAlpha = ((1f - mix) * baseAlpha).toInt()
        val nextAlpha = (mix * baseAlpha).toInt()
        when (draft.automaticEffectId) {
            EffectIds.RAINBOW -> {
                drawRainbowFrame(canvas, bitmap, first, cellW, cellH, dst, firstAlpha, timeUs)
                drawRainbowFrame(canvas, bitmap, next, cellW, cellH, dst, nextAlpha, timeUs + 120_000L)
            }
            EffectIds.BRIGHT -> {
                val pulse = 0.90f + 0.10f * normalizedPulse(timeUs, 1_600_000L)
                drawTintedFrame(canvas, bitmap, first, cellW, cellH, dst, (firstAlpha * pulse).toInt(), Color.WHITE)
                drawTintedFrame(canvas, bitmap, next, cellW, cellH, dst, (nextAlpha * pulse).toInt(), Color.WHITE)
            }
            EffectIds.FIREFLY -> {
                val pulse = 0.62f + 0.38f * normalizedPulse(timeUs, 2_200_000L)
                val warm = Color.rgb(255, 216, 82)
                drawTintedFrame(canvas, bitmap, first, cellW, cellH, dst, (firstAlpha * pulse).toInt(), warm)
                drawTintedFrame(canvas, bitmap, next, cellW, cellH, dst, (nextAlpha * pulse).toInt(), warm)
            }
            EffectIds.GLITTER -> {
                val sparkle = 0.50f + 0.50f * normalizedPulse(timeUs, 420_000L)
                val glitterColors = intArrayOf(Color.WHITE, Color.rgb(255, 156, 232), Color.rgb(157, 232, 255))
                val colorIndex = ((timeUs / 240_000L) % glitterColors.size).toInt()
                val tint = glitterColors[colorIndex]
                drawTintedFrame(canvas, bitmap, first, cellW, cellH, dst, (firstAlpha * (0.72f + 0.28f * sparkle)).toInt(), tint)
                drawTintedFrame(canvas, bitmap, next, cellW, cellH, dst, (nextAlpha * (0.72f + 0.28f * sparkle)).toInt(), Color.WHITE)
            }
            else -> { // Estrela is the neutral, elegant default.
                val star = Color.rgb(226, 239, 255)
                val pulse = 0.82f + 0.18f * normalizedPulse(timeUs, 1_100_000L)
                drawTintedFrame(canvas, bitmap, first, cellW, cellH, dst, (firstAlpha * pulse).toInt(), star)
                drawTintedFrame(canvas, bitmap, next, cellW, cellH, dst, (nextAlpha * pulse).toInt(), Color.WHITE)
            }
        }
        paint.colorFilter = null
    }

    private fun normalizedPulse(timeUs: Long, periodUs: Long): Float {
        val phase = (timeUs % periodUs).toDouble() / periodUs.toDouble() * Math.PI * 2.0
        return ((sin(phase) + 1.0) * 0.5).toFloat()
    }

    private fun drawRainbowFrame(
        canvas: Canvas,
        bitmap: Bitmap,
        index: Int,
        cellW: Int,
        cellH: Int,
        dst: RectF,
        alpha: Int,
        timeUs: Long,
    ) {
        if (alpha <= 0) return
        val rainbow = intArrayOf(
            Color.rgb(255, 92, 124),
            Color.rgb(255, 177, 71),
            Color.rgb(255, 231, 96),
            Color.rgb(89, 210, 255),
            Color.rgb(150, 116, 255),
            Color.rgb(255, 118, 224),
        )
        val bandWidth = canvas.width.toFloat() / rainbow.size
        val shift = ((timeUs / 900_000L) % rainbow.size).toInt()
        rainbow.indices.forEach { band ->
            val save = canvas.save()
            canvas.clipRect(band * bandWidth, 0f, (band + 1) * bandWidth + 1f, canvas.height.toFloat())
            drawTintedFrame(canvas, bitmap, index, cellW, cellH, dst, alpha, rainbow[(band + shift) % rainbow.size])
            canvas.restoreToCount(save)
        }
    }

    private fun drawTintedFrame(
        canvas: Canvas,
        bitmap: Bitmap,
        index: Int,
        cellW: Int,
        cellH: Int,
        dst: RectF,
        alpha: Int,
        tint: Int,
    ) {
        if (alpha <= 0) return
        val col = index % atlasCols
        val row = index / atlasCols
        val src = Rect(col * cellW, row * cellH, (col + 1) * cellW, (row + 1) * cellH)
        paint.alpha = alpha.coerceIn(0, 255)
        paint.colorFilter = PorterDuffColorFilter(tint, PorterDuff.Mode.SRC_IN)
        canvas.drawBitmap(bitmap, src, dst, paint)
    }

    private fun drawSignature(canvas: Canvas) {
        val w = canvas.width.toFloat()
        val top = canvas.height * 0.055f
        val hasText = draft.signatureText.isNotBlank()
        val image = signatureBitmap
        if (image != null) {
            val maxW = w * 0.1344f
            val maxH = canvas.height * 0.072f
            val scale = minOf(maxW / image.width, maxH / image.height)
            val dw = image.width * scale
            val dh = image.height * scale
            val left = w * 0.5f - dw / 2f
            val rect = RectF(left, top, left + dw, top + dh)
            paint.alpha = 235
            canvas.drawBitmap(image, null, rect, paint)
        }
        if (hasText) {
            val y = if (image != null) top + canvas.height * 0.085f else top + canvas.height * 0.035f
            textPaint.reset()
            textPaint.isAntiAlias = true
            textPaint.color = Color.WHITE
            textPaint.textAlign = Paint.Align.CENTER
            textPaint.typeface = Typeface.create("cursive", Typeface.ITALIC)
            textPaint.textSize = w * 0.0413f
            textPaint.setShadowLayer(w * 0.005f, 0f, w * 0.002f, Color.BLACK)
            val max = w * 0.78f
            while (textPaint.measureText(draft.signatureText) > max && textPaint.textSize > w * 0.023f) {
                textPaint.textSize *= 0.92f
            }
            canvas.drawText(draft.signatureText, w / 2f, y, textPaint)
        }
    }

    private data class PreparedLyric(val lines: List<String>, val textSize: Float)

    private var preparedLyricKey: String? = null
    private var preparedLyric: PreparedLyric? = null

    private fun drawLyrics(canvas: Canvas, timeMs: Long) {
        if (lyrics.isEmpty()) return
        val index = lyricIndexAt(timeMs)
        if (index < 0) return

        // Performance/stage directions were cleaned once when the LRC was loaded.
        val line = lyrics[index].text.trim()
        if (line.isBlank()) return

        val safeWidth = canvas.width * 0.84f // 8% safe margin on each side.
        textPaint.reset()
        textPaint.isAntiAlias = true
        textPaint.typeface = lyricTypeface(draft.fontPreset)

        val cacheKey = "$index|${canvas.width}|${draft.fontPreset}|$line"
        val prepared = if (preparedLyricKey == cacheKey) {
            preparedLyric
        } else {
            prepareLyric(line, safeWidth).also {
                preparedLyricKey = cacheKey
                preparedLyric = it
            }
        } ?: return

        textPaint.color = colors[index % colors.size]
        textPaint.textSize = prepared.textSize
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.setShadowLayer(canvas.width * 0.0045f, 0f, canvas.width * 0.0015f, Color.argb(205, 0, 0, 0))

        val metrics = textPaint.fontMetrics
        val lineHeight = (metrics.descent - metrics.ascent) * 1.08f
        val totalHeight = lineHeight * prepared.lines.size
        val safeTop = canvas.height * 0.27f
        val safeBottom = canvas.height * 0.72f
        val centerY = canvas.height * 0.49f
        val blockTop = (centerY - totalHeight / 2f).coerceIn(safeTop, safeBottom - totalHeight)
        var baseline = blockTop - metrics.ascent

        // Draw directly around the real frame center. This deliberately avoids StaticLayout
        // translation so portrait output cannot drift toward the encoded/raw left edge.
        prepared.lines.forEach { lyricLine ->
            canvas.drawText(lyricLine, canvas.width / 2f, baseline, textPaint)
            baseline += lineHeight
        }
    }

    private fun lyricIndexAt(timeMs: Long): Int {
        var low = 0
        var high = lyrics.lastIndex
        var result = -1
        while (low <= high) {
            val mid = (low + high) ushr 1
            if (lyrics[mid].timeMs <= timeMs) {
                result = mid
                low = mid + 1
            } else {
                high = mid - 1
            }
        }
        return result
    }

    private fun prepareLyric(value: String, maxWidth: Float): PreparedLyric {
        var size = canvasIndependentLyricMaxSize(maxWidth)
        val minimum = maxWidth * 0.0216f
        while (size >= minimum) {
            textPaint.textSize = size
            val lines = splitAtMostTwo(value, maxWidth)
            if (lines != null) return PreparedLyric(lines, size)
            size *= 0.92f
        }

        // Very unusual long words/phrases get one final compact pass rather than escaping the safe area.
        val words = value.split(Regex("\\s+")).filter { it.isNotBlank() }
        val split = if (words.size > 1) words.size / 2 else 1
        val forced = if (words.size > 1) {
            listOf(words.take(split).joinToString(" "), words.drop(split).joinToString(" "))
        } else listOf(value)
        var compact = minimum
        textPaint.textSize = compact
        while (forced.any { textPaint.measureText(it) > maxWidth } && compact > maxWidth * 0.0132f) {
            compact *= 0.90f
            textPaint.textSize = compact
        }
        return PreparedLyric(forced.take(2), compact)
    }

    private fun canvasIndependentLyricMaxSize(maxWidth: Float): Float = maxWidth / 0.84f * 0.0430f

    private fun splitAtMostTwo(value: String, maxWidth: Float): List<String>? {
        if (textPaint.measureText(value) <= maxWidth) return listOf(value)
        val words = value.split(Regex("\\s+")).filter { it.isNotBlank() }
        if (words.size < 2) return null

        var best: List<String>? = null
        var bestScore = Float.MAX_VALUE
        for (split in 1 until words.size) {
            val first = words.take(split).joinToString(" ")
            val second = words.drop(split).joinToString(" ")
            val firstWidth = textPaint.measureText(first)
            val secondWidth = textPaint.measureText(second)
            if (firstWidth <= maxWidth && secondWidth <= maxWidth) {
                val score = maxOf(firstWidth, secondWidth) + kotlin.math.abs(firstWidth - secondWidth) * 0.12f
                if (score < bestScore) {
                    bestScore = score
                    best = listOf(first, second)
                }
            }
        }
        return best
    }

    private fun sanitizeLyricText(value: String): String = value
        .replace(Regex("\\[[^\\]]*]"), " ")
        .replace(Regex("\\([^)]*\\)"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun drawMetadata(canvas: Canvas) {
        if (!draft.metadataOverlayEnabled) return
        val w = canvas.width.toFloat()
        val title = draft.exportTitle.trim().ifBlank { draft.audioTitle }
        val artist = draft.exportArtist.trim().ifBlank { draft.audioArtist.orEmpty() }
        textPaint.reset()
        textPaint.isAntiAlias = true
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        textPaint.setShadowLayer(w * 0.004f, 0f, w * 0.002f, Color.BLACK)
        if (metadataCanvasWidth != canvas.width) {
            metadataCanvasWidth = canvas.width
            textPaint.textSize = w * 0.0346f
            shrinkToWidth(title, w * 0.84f, w * 0.025f)
            metadataTitleSize = textPaint.textSize
            textPaint.textSize = w * 0.0259f
            shrinkToWidth(artist, w * 0.84f, w * 0.0202f)
            metadataArtistSize = textPaint.textSize
        }
        textPaint.color = Color.rgb(255, 220, 45)
        textPaint.textSize = metadataTitleSize
        canvas.drawText(title, w / 2f, canvas.height * 0.885f, textPaint)
        if (artist.isNotBlank()) {
            textPaint.color = Color.WHITE
            textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
            textPaint.textSize = metadataArtistSize
            canvas.drawText(artist, w / 2f, canvas.height * 0.913f, textPaint)
        }
    }

    private fun shrinkToWidth(value: String, maxWidth: Float, minSize: Float) {
        while (textPaint.measureText(value) > maxWidth && textPaint.textSize > minSize) {
            textPaint.textSize *= 0.92f
        }
    }

    private fun lyricTypeface(font: FontPresetId): Typeface = when (font) {
        FontPresetId.DEFAULT -> Typeface.create("sans-serif", Typeface.NORMAL)
        FontPresetId.MODERN -> Typeface.create("sans-serif-light", Typeface.NORMAL)
        FontPresetId.ELEGANT -> Typeface.create(Typeface.SERIF, Typeface.ITALIC)
        FontPresetId.IMPACT -> Typeface.create("sans-serif-medium", Typeface.BOLD)
        FontPresetId.HANDWRITTEN -> Typeface.create("cursive", Typeface.ITALIC)
        FontPresetId.MINIMAL -> Typeface.create("sans-serif-thin", Typeface.NORMAL)
        FontPresetId.NEON -> Typeface.create("sans-serif-light", Typeface.NORMAL)
        FontPresetId.RETRO -> Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
    }
}
