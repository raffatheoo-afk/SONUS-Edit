package com.sonusstudios.sonusedit.media

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import android.text.TextPaint
import androidx.media3.common.Effect
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.CanvasOverlay
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.OverlayEffect
import com.sonusstudios.sonusedit.create.CreateProjectDraft
import com.sonusstudios.sonusedit.create.FilterPresetId
import com.sonusstudios.sonusedit.create.FontPresetId
import com.sonusstudios.sonusedit.create.effective
import com.sonusstudios.sonusedit.create.LyricColorPreset
import com.sonusstudios.sonusedit.create.LyricColorPalette24
import com.sonusstudios.sonusedit.create.SignatureColorPreset
import com.sonusstudios.sonusedit.create.SignatureFontPreset
import com.sonusstudios.sonusedit.editor.LrcLine
import com.sonusstudios.sonusedit.editor.LrcParser

@OptIn(UnstableApi::class)
object VideoVisualEffects {
    fun filterEffect(filter: FilterPresetId): Effect? = when (filter) {
        FilterPresetId.ORIGINAL -> null
        FilterPresetId.BLACK_AND_WHITE -> NaturalFilterEffect(NaturalFilterEffect.Preset(
            sharpen = .012f, contrast = 1.045f, saturation = 0f,
        ))
        FilterPresetId.SPRING -> NaturalFilterEffect(NaturalFilterEffect.Preset(
            sharpen = .035f, contrast = 1.045f, saturation = 1.13f, brightness = .006f, temperature = .012f,
        ))
        // Kept code13 filters that Rafa explicitly favorited.
        FilterPresetId.CINEMATIC -> HslAdjustment.Builder().adjustSaturation(-12f).adjustLightness(-4f).adjustHue(-3f).build()
        FilterPresetId.VINTAGE_FILM -> HslAdjustment.Builder().adjustSaturation(-25f).adjustLightness(4f).adjustHue(7f).build()
        FilterPresetId.SOFT_CONTRAST -> NaturalFilterEffect(NaturalFilterEffect.Preset(
            sharpen = .018f, contrast = .955f, saturation = 1.035f, brightness = .012f,
        ))
        FilterPresetId.CINEMA_CLEAN -> NaturalFilterEffect(NaturalFilterEffect.Preset(
            sharpen = .015f, contrast = 1.065f, saturation = 1.035f, brightness = -.004f, blackPoint = .010f,
        ))
        FilterPresetId.CLEAN_NIGHT -> HslAdjustment.Builder().adjustSaturation(7f).adjustLightness(-9f).adjustHue(10f).build()
        FilterPresetId.PASTEL_NATURAL -> HslAdjustment.Builder().adjustSaturation(-18f).adjustLightness(11f).build()
        FilterPresetId.CLARITY_PLUS -> HslAdjustment.Builder().adjustSaturation(12f).adjustLightness(1f).build()

        // code16 replacements: actual image enhancement, no translucent wash/veil overlay.
        FilterPresetId.SUNSET -> NaturalFilterEffect(NaturalFilterEffect.Preset(
            sharpen = .09f, contrast = 1.09f, saturation = 1.07f, blackPoint = .012f,
        ))
        FilterPresetId.NIGHT_CITY -> NaturalFilterEffect(NaturalFilterEffect.Preset(
            sharpen = .025f, contrast = 1.105f, saturation = 1.025f, brightness = -.006f, blackPoint = .022f,
        ))
        FilterPresetId.NATURAL_PLUS -> NaturalFilterEffect(NaturalFilterEffect.Preset(
            sharpen = .025f, contrast = 1.035f, saturation = 1.135f,
        ))
        FilterPresetId.SOFT_LIGHT -> NaturalFilterEffect(NaturalFilterEffect.Preset(
            sharpen = .045f, contrast = 1.055f, saturation = 1.045f, blackPoint = .008f,
        ))
        FilterPresetId.WARM_NATURAL -> NaturalFilterEffect(NaturalFilterEffect.Preset(
            sharpen = .025f, contrast = 1.04f, saturation = 1.07f, brightness = .010f, temperature = .045f,
        ))
        FilterPresetId.COOL_NATURAL -> NaturalFilterEffect(NaturalFilterEffect.Preset(
            sharpen = .030f, contrast = 1.045f, saturation = 1.02f, brightness = .004f, temperature = -.042f,
        ))
        FilterPresetId.GOLDEN -> NaturalFilterEffect(NaturalFilterEffect.Preset(
            sharpen = .115f, contrast = 1.035f, saturation = 1.015f,
        ))
        FilterPresetId.STUDIO_FILM -> HslAdjustment.Builder().adjustSaturation(-8f).adjustLightness(-2f).adjustHue(2f).build()
        FilterPresetId.PORTRAIT_GLOW -> NaturalFilterEffect(NaturalFilterEffect.Preset(sharpen = .018f, contrast = 1.025f, saturation = 1.045f, brightness = .012f))
        FilterPresetId.GOLDEN_HOUR -> NaturalFilterEffect(NaturalFilterEffect.Preset(sharpen = .028f, contrast = 1.04f, saturation = 1.08f, temperature = .055f, brightness = .008f))
        FilterPresetId.TEAL_ORANGE -> HslAdjustment.Builder().adjustSaturation(8f).adjustHue(-8f).adjustLightness(-1f).build()
        FilterPresetId.MOODY_BLUE -> NaturalFilterEffect(NaturalFilterEffect.Preset(sharpen = .02f, contrast = 1.10f, saturation = .94f, temperature = -.06f, brightness = -.01f))
        FilterPresetId.SOFT_MATTE -> NaturalFilterEffect(NaturalFilterEffect.Preset(sharpen = .005f, contrast = .94f, saturation = .92f, brightness = .018f, blackPoint = .02f))
        FilterPresetId.VIBRANT_POP -> NaturalFilterEffect(NaturalFilterEffect.Preset(sharpen = .07f, contrast = 1.08f, saturation = 1.18f))
        FilterPresetId.WARM_FILM -> HslAdjustment.Builder().adjustSaturation(-10f).adjustLightness(3f).adjustHue(5f).build()
        FilterPresetId.CRISP_HDR -> NaturalFilterEffect(NaturalFilterEffect.Preset(sharpen = .13f, contrast = 1.09f, saturation = 1.04f, blackPoint = .012f))
        FilterPresetId.DREAM_LIGHT -> NaturalFilterEffect(NaturalFilterEffect.Preset(sharpen = .01f, contrast = .97f, saturation = 1.07f, brightness = .025f))
    }

    fun globalOverlay(context: Context, draft: CreateProjectDraft): OverlayEffect =
        OverlayEffect(listOf(SonusCanvasOverlay(context, draft)))

    fun imageFadeOverlay(durationMs: Long, fadeInMs: Long, fadeOutMs: Long): OverlayEffect =
        OverlayEffect(listOf(ImageFadeOverlay(durationMs, fadeInMs, fadeOutMs)))
}

@OptIn(UnstableApi::class)
private class ImageFadeOverlay(
    private val durationMs: Long,
    private val fadeInMs: Long,
    private val fadeOutMs: Long,
) : CanvasOverlay(true) {
    private val black = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
    private var firstTimestampUs: Long? = null

    override fun onDraw(canvas: Canvas, presentationTimeUs: Long) {
        canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
        // Media3 may expose a composition timestamp. Anchor the first frame of EACH image clip
        // and always calculate fades in clip-local time. This prevents the old 5s/global-time
        // bug where later images became fully transparent/black.
        val baseUs = firstTimestampUs ?: presentationTimeUs.also { firstTimestampUs = it }
        val t = ((presentationTimeUs - baseUs).coerceAtLeast(0L)) / 1_000L
        val alpha = when {
            fadeInMs > 0 && t < fadeInMs -> ((1f - t.toFloat() / fadeInMs) * 255).toInt()
            fadeOutMs > 0 && t > durationMs - fadeOutMs -> (((t - (durationMs - fadeOutMs)).toFloat() / fadeOutMs) * 255).toInt()
            else -> 0
        }.coerceIn(0, 255)
        if (alpha > 0) {
            black.alpha = alpha
            canvas.drawRect(0f, 0f, canvas.width.toFloat(), canvas.height.toFloat(), black)
        }
    }
}

@OptIn(UnstableApi::class)
private class SonusCanvasOverlay(
    private val context: Context,
    private val draft: CreateProjectDraft,
) : CanvasOverlay(true) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val lyricTypefaceCache = mutableMapOf<FontPresetId, Typeface>()
    private data class TimedCaption(val startMs: Long, val endMs: Long, val text: String)

    private val lyrics: List<TimedCaption> = if (draft.captionSegments.isNotEmpty()) {
        draft.captionSegments.mapNotNull { segment ->
            val text = sanitizeLyricText(segment.text)
            if (text.isBlank()) null else TimedCaption(
                startMs = segment.startMs.coerceAtLeast(0L),
                endMs = segment.endMs.coerceAtLeast(segment.startMs + 120L),
                text = text,
            )
        }
    } else {
        draft.syncedLyrics?.let { raw ->
            val legacy = LrcParser.sliceAndShift(
                LrcParser.parse(raw),
                draft.segmentStartMs,
                draft.segmentStartMs + draft.segmentDurationMs,
            )
            legacy.mapIndexedNotNull { index, line ->
                val text = sanitizeLyricText(line.text)
                if (text.isBlank()) null else TimedCaption(
                    startMs = line.timeMs,
                    endMs = legacy.getOrNull(index + 1)?.timeMs ?: draft.segmentDurationMs,
                    text = text,
                )
            }
        }.orEmpty()
    }
    // 1.7/code31: every caption look is drawn by the renderer shared with the in-app preview.
    private val captionRenderer = CaptionStyleRenderer()
    private val styledCaptions: List<CaptionStyleRenderer.Caption> =
        lyrics.sortedBy { it.startMs }.map { CaptionStyleRenderer.Caption(it.startMs, it.endMs, it.text) }
    private val captionConfig by lazy {
        CaptionStyleRenderer.Config(
            draft.captionStyle, draft.captionPosition, lyricTypeface(draft.fontPreset), draft.lyricColorPreset,
            sizeScale = draft.captionSizeScale, positionPercent = draft.captionPositionPercent,
        )
    }
    private val signatureBitmap: Bitmap? = draft.signaturePhotoUri?.let { value ->
        runCatching {
            context.contentResolver.openInputStream(Uri.parse(value))?.use { BitmapFactory.decodeStream(it) }
        }.getOrNull()
    }
    private var metadataCanvasKey = ""
    private var metadataTitleSize = 0f
    private var metadataArtistSize = 0f

    override fun onDraw(canvas: Canvas, presentationTimeUs: Long) {
        canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
        // code14 particles are a real MP4 layer in AutomaticVideoExporter, not a Canvas atlas.
        drawSignature(canvas)
        drawStyledCaptions(canvas, presentationTimeUs / 1_000L)
        drawMetadata(canvas)
    }

    private fun drawStyledCaptions(canvas: Canvas, timeMs: Long) {
        if (styledCaptions.isEmpty()) return
        captionRenderer.draw(canvas, canvas.width, canvas.height, timeMs, styledCaptions, captionConfig)
    }

    private fun drawSignature(canvas: Canvas) {
        val w = canvas.width.toFloat()
        val base = minOf(canvas.width, canvas.height).toFloat()
        val top = canvas.height * 0.055f
        val hasText = draft.signatureText.isNotBlank()
        val image = signatureBitmap
        if (image != null) {
            val maxW = w * 0.1344f
            val maxH = canvas.height * 0.072f
            val scale = minOf(maxW / image.width, maxH / image.height)
            val dw = image.width * scale
            val dh = image.height * scale
            val left = w * 0.5f - dw / 2f
            val rect = RectF(left, top, left + dw, top + dh)
            paint.alpha = 235
            canvas.drawBitmap(image, null, rect, paint)
        }
        if (hasText) {
            val y = if (image != null) top + canvas.height * 0.085f else top + canvas.height * 0.035f
            textPaint.reset()
            textPaint.isAntiAlias = true
            textPaint.color = signatureColor(draft.signatureColorPreset)
            textPaint.textAlign = Paint.Align.CENTER
            textPaint.typeface = signatureTypeface(draft.signatureFontPreset)
            textPaint.textSize = base * 0.0413f
            val shadow = if (draft.signatureColorPreset == SignatureColorPreset.BLACK) Color.argb(105, 255, 255, 255) else Color.argb(105, 0, 0, 0)
            textPaint.setShadowLayer(base * 0.005f, 0f, base * 0.002f, shadow)
            val max = w * 0.78f
            while (textPaint.measureText(draft.signatureText) > max && textPaint.textSize > base * 0.023f) {
                textPaint.textSize *= 0.92f
            }
            canvas.drawText(draft.signatureText, w / 2f, y, textPaint)
        }
    }

    private data class PreparedLyric(val lines: List<String>, val textSize: Float)

    private var preparedLyricKey: String? = null
    private var preparedLyric: PreparedLyric? = null

    private fun drawLyrics(canvas: Canvas, timeMs: Long) {
        if (lyrics.isEmpty()) return
        val index = lyricIndexAt(timeMs)
        if (index < 0) return

        // Performance/stage directions were cleaned once when the LRC was loaded.
        val item = lyrics[index]
        if (timeMs > item.endMs) return
        val line = item.text.trim()
        if (line.isBlank()) return

        val base = minOf(canvas.width, canvas.height).toFloat()
        val safeWidth = canvas.width * 0.84f // Safe width follows the actual horizontal/vertical canvas.
        textPaint.reset()
        textPaint.isAntiAlias = true
        textPaint.typeface = lyricTypeface(draft.fontPreset)

        val cacheKey = "$index|${canvas.width}x${canvas.height}|${draft.fontPreset}|$line"
        val prepared = if (preparedLyricKey == cacheKey) {
            preparedLyric
        } else {
            prepareLyric(line, safeWidth, base).also {
                preparedLyricKey = cacheKey
                preparedLyric = it
            }
        } ?: return

        textPaint.textSize = prepared.textSize
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.setShadowLayer(base * 0.0036f, 0f, base * 0.0012f, Color.argb(100, 0, 0, 0))

        val metrics = textPaint.fontMetrics
        val lineHeight = (metrics.descent - metrics.ascent) * 1.08f
        val totalHeight = lineHeight * prepared.lines.size
        val safeTop = canvas.height * 0.27f
        val safeBottom = canvas.height * 0.72f
        val centerY = canvas.height * 0.49f
        val blockTop = (centerY - totalHeight / 2f).coerceIn(safeTop, safeBottom - totalHeight)
        var baseline = blockTop - metrics.ascent

        // Draw directly around the real frame center. This deliberately avoids StaticLayout
        // translation so portrait output cannot drift toward the encoded/raw left edge.
        prepared.lines.forEach { lyricLine ->
            // code19: a very thin black outline keeps captions readable on bright/busy photos
            // without turning the text into a heavy karaoke-style title.
            textPaint.style = Paint.Style.STROKE
            textPaint.strokeJoin = Paint.Join.ROUND
            textPaint.strokeMiter = 4f
            textPaint.strokeWidth = (base / 720f * 1.35f).coerceAtLeast(1.0f)
            // Black lettering gets a thin white outline so it remains visible on dark backgrounds.
            textPaint.color = if (draft.lyricColorPreset == LyricColorPreset.BLACK) Color.WHITE else Color.BLACK
            canvas.drawText(lyricLine, canvas.width / 2f, baseline, textPaint)

            textPaint.style = Paint.Style.FILL
            textPaint.strokeWidth = 0f
            textPaint.color = lyricColor(draft.lyricColorPreset, index)
            canvas.drawText(lyricLine, canvas.width / 2f, baseline, textPaint)
            baseline += lineHeight
        }
    }

    private fun lyricIndexAt(timeMs: Long): Int {
        var low = 0
        var high = lyrics.lastIndex
        var result = -1
        while (low <= high) {
            val mid = (low + high) ushr 1
            if (lyrics[mid].startMs <= timeMs) {
                result = mid
                low = mid + 1
            } else {
                high = mid - 1
            }
        }
        return result
    }

    private fun prepareLyric(value: String, maxWidth: Float, base: Float): PreparedLyric {
        var size = base * 0.03881f
        val minimum = base * 0.02052f
        while (size >= minimum) {
            textPaint.textSize = size
            val lines = splitAtMostTwo(value, maxWidth)
            if (lines != null) return PreparedLyric(lines, size)
            size *= 0.92f
        }

        // Very unusual long words/phrases get one final compact pass rather than escaping the safe area.
        val words = value.split(Regex("\\s+")).filter { it.isNotBlank() }
        val split = if (words.size > 1) words.size / 2 else 1
        val forced = if (words.size > 1) {
            listOf(words.take(split).joinToString(" "), words.drop(split).joinToString(" "))
        } else listOf(value)
        var compact = minimum
        textPaint.textSize = compact
        while (forced.any { textPaint.measureText(it) > maxWidth } && compact > base * 0.01254f) {
            compact *= 0.90f
            textPaint.textSize = compact
        }
        return PreparedLyric(forced.take(2), compact)
    }

    private fun splitAtMostTwo(value: String, maxWidth: Float): List<String>? {
        if (textPaint.measureText(value) <= maxWidth) return listOf(value)
        val words = value.split(Regex("\\s+")).filter { it.isNotBlank() }
        if (words.size < 2) return null

        var best: List<String>? = null
        var bestScore = Float.MAX_VALUE
        for (split in 1 until words.size) {
            val first = words.take(split).joinToString(" ")
            val second = words.drop(split).joinToString(" ")
            val firstWidth = textPaint.measureText(first)
            val secondWidth = textPaint.measureText(second)
            if (firstWidth <= maxWidth && secondWidth <= maxWidth) {
                val score = maxOf(firstWidth, secondWidth) + kotlin.math.abs(firstWidth - secondWidth) * 0.12f
                if (score < bestScore) {
                    bestScore = score
                    best = listOf(first, second)
                }
            }
        }
        return best
    }

    private fun sanitizeLyricText(value: String): String = value
        .replace(Regex("\\[[^\\]]*]"), " ")
        .replace(Regex("\\([^)]*\\)"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun drawMetadata(canvas: Canvas) {
        if (!draft.metadataOverlayEnabled) return
        val w = canvas.width.toFloat()
        val base = minOf(canvas.width, canvas.height).toFloat()
        val title = draft.exportTitle.trim().ifBlank { draft.audioTitle }
        val artist = draft.exportArtist.trim().ifBlank { draft.audioArtist.orEmpty() }
        textPaint.reset()
        textPaint.isAntiAlias = true
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        textPaint.setShadowLayer(base * 0.0032f, 0f, base * 0.0012f, Color.argb(105, 0, 0, 0))
        val canvasKey = "${canvas.width}x${canvas.height}"
        if (metadataCanvasKey != canvasKey) {
            metadataCanvasKey = canvasKey
            textPaint.textSize = base * 0.0346f
            shrinkToWidth(title, w * 0.84f, base * 0.025f)
            metadataTitleSize = textPaint.textSize
            textPaint.textSize = base * 0.0259f
            shrinkToWidth(artist, w * 0.84f, base * 0.0202f)
            metadataArtistSize = textPaint.textSize
        }
        textPaint.color = Color.rgb(255, 220, 45)
        textPaint.textSize = metadataTitleSize
        canvas.drawText(title, w / 2f, canvas.height * 0.885f, textPaint)
        if (artist.isNotBlank()) {
            textPaint.color = Color.WHITE
            textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
            textPaint.textSize = metadataArtistSize
            canvas.drawText(artist, w / 2f, canvas.height * 0.913f, textPaint)
        }
    }

    private fun shrinkToWidth(value: String, maxWidth: Float, minSize: Float) {
        while (textPaint.measureText(value) > maxWidth && textPaint.textSize > minSize) {
            textPaint.textSize *= 0.92f
        }
    }

    private fun lyricTypeface(requested: FontPresetId): Typeface = lyricTypefaceCache.getOrPut(requested) {
        // Retired fonts (old drafts/favorites) are drawn with their approved replacement.
        val font = requested.effective()
        val asset = font.assetFileName
        if (asset != null) {
            runCatching { Typeface.createFromAsset(context.assets, "fonts/$asset") }
                .getOrElse { fallbackLyricTypeface(font) }
        } else if (font.systemTypefaceName != null) {
            Typeface.create(font.systemTypefaceName, Typeface.NORMAL)
        } else fallbackLyricTypeface(font)
    }

    private fun fallbackLyricTypeface(font: FontPresetId): Typeface = when (font) {
        FontPresetId.DEFAULT -> Typeface.create("cursive", Typeface.NORMAL)
        FontPresetId.MODERN -> Typeface.create("sans-serif-black", Typeface.BOLD)
        FontPresetId.ELEGANT -> Typeface.create("sans-serif-condensed-light", Typeface.NORMAL)
        FontPresetId.IMPACT -> Typeface.create("cursive", Typeface.BOLD)
        FontPresetId.HANDWRITTEN -> Typeface.create("sans-serif-medium", Typeface.ITALIC)
        FontPresetId.MINIMAL -> Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
        FontPresetId.NEON -> Typeface.create(Typeface.SERIF, Typeface.ITALIC)
        FontPresetId.RETRO -> Typeface.create("cursive", Typeface.ITALIC)
        else -> Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
    }

    private fun signatureTypeface(font: SignatureFontPreset): Typeface = when (font) {
        SignatureFontPreset.PATRICK_HAND -> Typeface.create("cursive", Typeface.NORMAL)
        SignatureFontPreset.RANCHO -> Typeface.create("cursive", Typeface.BOLD)
        SignatureFontPreset.PLAYBALL -> Typeface.create("cursive", Typeface.ITALIC)
    }

    private fun signatureColor(color: SignatureColorPreset): Int = when (color) {
        SignatureColorPreset.WHITE -> Color.WHITE
        SignatureColorPreset.YELLOW -> Color.rgb(255, 224, 64)
        SignatureColorPreset.BLACK -> Color.BLACK
    }

    private fun lyricColor(preset: LyricColorPreset, index: Int): Int =
        LyricColorPalette24.argb(preset, index)

}
