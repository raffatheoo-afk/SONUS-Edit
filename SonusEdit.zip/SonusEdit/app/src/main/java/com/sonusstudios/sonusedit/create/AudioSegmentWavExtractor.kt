package com.sonusstudios.sonusedit.create

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteOrder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext

/** Decodes only the chosen range and writes 16-bit PCM / 16 kHz / mono WAV for Whisper. */
object AudioSegmentWavExtractor {
    private const val TARGET_RATE = 16_000
    private const val TIMEOUT_US = 10_000L

    suspend fun extract(
        context: Context,
        source: Uri,
        startMs: Long,
        durationMs: Long,
        output: File,
    ) = withContext(Dispatchers.IO) {
        val extractor = MediaExtractor()
        var decoder: MediaCodec? = null
        val wav = RandomAccessFile(output, "rw")
        try {
            if (source.scheme.equals("http", true) || source.scheme.equals("https", true)) {
                extractor.setDataSource(source.toString(), emptyMap())
            } else {
                extractor.setDataSource(context, source, null)
            }
            val audioTrack = (0 until extractor.trackCount).firstOrNull { index ->
                extractor.getTrackFormat(index).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true
            } ?: error("O áudio selecionado não possui uma faixa de som compatível.")
            extractor.selectTrack(audioTrack)
            val inputFormat = extractor.getTrackFormat(audioTrack)
            val mime = inputFormat.getString(MediaFormat.KEY_MIME) ?: error("Formato de áudio desconhecido.")
            decoder = MediaCodec.createDecoderByType(mime)
            decoder.configure(inputFormat, null, null, 0)
            decoder.start()

            wav.setLength(0L)
            writeWavHeader(wav, 0L)

            val startUs = startMs.coerceAtLeast(0L) * 1_000L
            val endUs = startUs + durationMs.coerceAtLeast(1L) * 1_000L
            extractor.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)

            var inputDone = false
            var outputDone = false
            var sampleRate = inputFormat.getIntegerOr(MediaFormat.KEY_SAMPLE_RATE, 44_100).coerceAtLeast(1)
            var channelCount = inputFormat.getIntegerOr(MediaFormat.KEY_CHANNEL_COUNT, 2).coerceAtLeast(1)
            var pcmEncoding = AudioFormat.ENCODING_PCM_16BIT
            var pcmBytes = 0L

            // For common 44.1/48 kHz music, average the source samples that feed each 16 kHz
            // output sample. This lightweight low-pass behavior is materially cleaner for ASR than
            // simply dropping samples (which can alias instruments back into the vocal band).
            var downsamplePhase = 0L
            var downsampleSum = 0L
            var downsampleCount = 0
            var upsamplePhase = 0L

            fun writeMonoSample(sample: Short) {
                wav.write(sample.toInt() and 0xff)
                wav.write((sample.toInt() ushr 8) and 0xff)
                pcmBytes += 2L
            }

            fun resampleAndWrite(sample: Short) {
                if (sampleRate >= TARGET_RATE) {
                    downsampleSum += sample.toLong()
                    downsampleCount++
                    downsamplePhase += TARGET_RATE.toLong()
                    if (downsamplePhase >= sampleRate) {
                        downsamplePhase -= sampleRate.toLong()
                        val averaged = (downsampleSum / downsampleCount.coerceAtLeast(1))
                            .coerceIn(Short.MIN_VALUE.toLong(), Short.MAX_VALUE.toLong())
                            .toShort()
                        writeMonoSample(averaged)
                        downsampleSum = 0L
                        downsampleCount = 0
                    }
                } else {
                    // Rare low-rate input: duplicate the closest decoded mono sample as needed.
                    upsamplePhase += TARGET_RATE.toLong()
                    while (upsamplePhase >= sampleRate) {
                        upsamplePhase -= sampleRate.toLong()
                        writeMonoSample(sample)
                    }
                }
            }

            val info = MediaCodec.BufferInfo()
            while (!outputDone) {
                ensureActive()
                if (!inputDone) {
                    val inputIndex = decoder.dequeueInputBuffer(TIMEOUT_US)
                    if (inputIndex >= 0) {
                        val buffer = decoder.getInputBuffer(inputIndex) ?: continue
                        val sampleTime = extractor.sampleTime
                        if (sampleTime < 0L || sampleTime >= endUs) {
                            decoder.queueInputBuffer(inputIndex, 0, 0, maxOf(sampleTime, endUs), MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            val size = extractor.readSampleData(buffer, 0)
                            if (size < 0) {
                                decoder.queueInputBuffer(inputIndex, 0, 0, maxOf(sampleTime, startUs), MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            } else {
                                decoder.queueInputBuffer(inputIndex, 0, size, sampleTime, 0)
                                extractor.advance()
                            }
                        }
                    }
                }

                val outputIndex = decoder.dequeueOutputBuffer(info, TIMEOUT_US)
                when {
                    outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val format = decoder.outputFormat
                        sampleRate = format.getIntegerOr(MediaFormat.KEY_SAMPLE_RATE, sampleRate).coerceAtLeast(1)
                        channelCount = format.getIntegerOr(MediaFormat.KEY_CHANNEL_COUNT, channelCount).coerceAtLeast(1)
                        pcmEncoding = format.getIntegerOr(MediaFormat.KEY_PCM_ENCODING, AudioFormat.ENCODING_PCM_16BIT)
                    }

                    outputIndex >= 0 -> {
                        val buffer = decoder.getOutputBuffer(outputIndex)
                        if (buffer != null && info.size > 0 && info.presentationTimeUs < endUs) {
                            buffer.position(info.offset)
                            buffer.limit(info.offset + info.size)
                            val slice = buffer.slice().order(ByteOrder.nativeOrder())

                            if (pcmEncoding == AudioFormat.ENCODING_PCM_FLOAT) {
                                val samples = slice.asFloatBuffer()
                                val frameCount = samples.remaining() / channelCount
                                for (frame in 0 until frameCount) {
                                    var sum = 0f
                                    repeat(channelCount) { sum += samples.get() }
                                    val frameUs = info.presentationTimeUs + (frame * 1_000_000L / sampleRate)
                                    if (frameUs in startUs until endUs) {
                                        val mono = ((sum / channelCount).coerceIn(-1f, 1f) * Short.MAX_VALUE)
                                            .toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
                                        resampleAndWrite(mono)
                                    }
                                }
                            } else {
                                val samples = slice.asShortBuffer()
                                val frameCount = samples.remaining() / channelCount
                                for (frame in 0 until frameCount) {
                                    var sum = 0L
                                    repeat(channelCount) { sum += samples.get().toLong() }
                                    val frameUs = info.presentationTimeUs + (frame * 1_000_000L / sampleRate)
                                    if (frameUs in startUs until endUs) {
                                        val mono = (sum / channelCount)
                                            .coerceIn(Short.MIN_VALUE.toLong(), Short.MAX_VALUE.toLong()).toShort()
                                        resampleAndWrite(mono)
                                    }
                                }
                            }
                        }
                        outputDone = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                        decoder.releaseOutputBuffer(outputIndex, false)
                    }
                }
            }

            require(pcmBytes > 3_200L) { "Não foi possível preparar áudio suficiente para a legenda." }
            wav.seek(0L)
            writeWavHeader(wav, pcmBytes)
            normalizePcm16Mono(wav, pcmBytes)
        } finally {
            runCatching { decoder?.stop() }
            runCatching { decoder?.release() }
            extractor.release()
            wav.close()
        }
    }


    /**
     * Long-project path: keeps a single MediaExtractor/MediaCodec session open while materializing
     * overlapping Whisper windows one at a time. The callback runs after each WAV is finalized and
     * the temporary file is deleted immediately afterwards. This avoids reopening/seek-decoding the
     * source hundreds of times for hour-long songs while keeping memory bounded to one small window.
     */
    suspend fun extractSequentialChunks(
        context: Context,
        source: Uri,
        startMs: Long,
        durationMs: Long,
        chunkMs: Long,
        overlapMs: Long,
        tempDir: File,
        onChunk: suspend (offsetMs: Long, plannedDurationMs: Long, wav: File) -> Unit,
    ) = withContext(Dispatchers.IO) {
        require(durationMs > 0L) { "Trecho de áudio inválido." }
        require(chunkMs > 0L) { "Janela de legenda inválida." }
        require(overlapMs >= 0L && overlapMs < chunkMs) { "Sobreposição de legenda inválida." }

        val extractor = MediaExtractor()
        var decoder: MediaCodec? = null
        val totalTargetSamples = ((durationMs * TARGET_RATE) / 1_000L).coerceAtLeast(1L)
        val fullChunkSamples = ((chunkMs * TARGET_RATE) / 1_000L).coerceAtLeast(1L)
        val overlapSamples = ((overlapMs * TARGET_RATE) / 1_000L).coerceIn(0L, fullChunkSamples - 1L).toInt()
        val stepSamples = (fullChunkSamples - overlapSamples).coerceAtLeast(1L)

        data class ReadyChunk(val offsetMs: Long, val durationMs: Long, val file: File)

        class ChunkWriter(
            val file: File,
            val startSample: Long,
            val targetSamples: Long,
            val plannedDurationMs: Long,
        ) {
            val raf = RandomAccessFile(file, "rw")
            var samplesWritten = 0L
            var dataBytes = 0L

            init {
                raf.setLength(0L)
                writeWavHeader(raf, 0L)
            }

            fun write(sample: Short) {
                raf.write(sample.toInt() and 0xff)
                raf.write((sample.toInt() ushr 8) and 0xff)
                samplesWritten++
                dataBytes += 2L
            }

            fun finish() {
                raf.seek(0L)
                writeWavHeader(raf, dataBytes)
                normalizePcm16Mono(raf, dataBytes)
                raf.close()
            }

            fun abort() = runCatching { raf.close() }
        }

        fun plannedDurationFor(startSample: Long): Long {
            val availableSamples = (totalTargetSamples - startSample).coerceAtLeast(0L)
            val samples = minOf(fullChunkSamples, availableSamples)
            return ((samples * 1_000L) / TARGET_RATE).coerceAtLeast(1L)
        }

        fun newWriter(startSample: Long): ChunkWriter? {
            if (startSample >= totalTargetSamples) return null
            val availableSamples = totalTargetSamples - startSample
            if (startSample > 0L && availableSamples <= overlapSamples.toLong()) return null
            val targetSamples = minOf(fullChunkSamples, availableSamples)
            val file = File.createTempFile("sonus_caption_seq_", ".wav", tempDir)
            return ChunkWriter(file, startSample, targetSamples, plannedDurationFor(startSample))
        }

        val tail = if (overlapSamples > 0) ShortArray(overlapSamples) else ShortArray(0)
        var tailCount = 0
        var tailWrite = 0

        fun pushTail(sample: Short) {
            if (tail.isEmpty()) return
            tail[tailWrite] = sample
            tailWrite = (tailWrite + 1) % tail.size
            if (tailCount < tail.size) tailCount++
        }

        fun snapshotTail(): ShortArray {
            if (tailCount == 0) return ShortArray(0)
            val out = ShortArray(tailCount)
            val start = if (tailCount < tail.size) 0 else tailWrite
            for (i in 0 until tailCount) out[i] = tail[(start + i) % tail.size]
            return out
        }

        var writer: ChunkWriter? = newWriter(0L)
        val ready = ArrayList<ReadyChunk>(2)
        var nextChunkStartSample = stepSamples

        fun finishCurrentAndAdvance() {
            val completed = writer ?: return
            completed.finish()
            ready += ReadyChunk(
                offsetMs = (completed.startSample * 1_000L) / TARGET_RATE,
                durationMs = completed.plannedDurationMs,
                file = completed.file,
            )
            val next = newWriter(nextChunkStartSample)
            nextChunkStartSample += stepSamples
            if (next != null && overlapSamples > 0) {
                val seed = snapshotTail()
                val keep = minOf(seed.size.toLong(), next.targetSamples).toInt()
                seed.takeLast(keep).forEach { next.write(it) }
            }
            writer = next
        }

        fun emit(sample: Short) {
            val current = writer ?: return
            current.write(sample)
            pushTail(sample)
            if (current.samplesWritten >= current.targetSamples) finishCurrentAndAdvance()
        }

        try {
            if (source.scheme.equals("http", true) || source.scheme.equals("https", true)) {
                extractor.setDataSource(source.toString(), emptyMap())
            } else {
                extractor.setDataSource(context, source, null)
            }
            val audioTrack = (0 until extractor.trackCount).firstOrNull { index ->
                extractor.getTrackFormat(index).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true
            } ?: error("O áudio selecionado não possui uma faixa de som compatível.")
            extractor.selectTrack(audioTrack)
            val inputFormat = extractor.getTrackFormat(audioTrack)
            val mime = inputFormat.getString(MediaFormat.KEY_MIME) ?: error("Formato de áudio desconhecido.")
            decoder = MediaCodec.createDecoderByType(mime)
            decoder.configure(inputFormat, null, null, 0)
            decoder.start()

            val startUs = startMs.coerceAtLeast(0L) * 1_000L
            val endUs = startUs + durationMs.coerceAtLeast(1L) * 1_000L
            extractor.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)

            var inputDone = false
            var outputDone = false
            var sampleRate = inputFormat.getIntegerOr(MediaFormat.KEY_SAMPLE_RATE, 44_100).coerceAtLeast(1)
            var channelCount = inputFormat.getIntegerOr(MediaFormat.KEY_CHANNEL_COUNT, 2).coerceAtLeast(1)
            var pcmEncoding = AudioFormat.ENCODING_PCM_16BIT
            var downsamplePhase = 0L
            var downsampleSum = 0L
            var downsampleCount = 0
            var upsamplePhase = 0L

            fun resample(sample: Short) {
                if (sampleRate >= TARGET_RATE) {
                    downsampleSum += sample.toLong()
                    downsampleCount++
                    downsamplePhase += TARGET_RATE.toLong()
                    if (downsamplePhase >= sampleRate) {
                        downsamplePhase -= sampleRate.toLong()
                        val averaged = (downsampleSum / downsampleCount.coerceAtLeast(1))
                            .coerceIn(Short.MIN_VALUE.toLong(), Short.MAX_VALUE.toLong()).toShort()
                        emit(averaged)
                        downsampleSum = 0L
                        downsampleCount = 0
                    }
                } else {
                    upsamplePhase += TARGET_RATE.toLong()
                    while (upsamplePhase >= sampleRate) {
                        upsamplePhase -= sampleRate.toLong()
                        emit(sample)
                    }
                }
            }

            suspend fun dispatchReady() {
                if (ready.isEmpty()) return
                val copy = ready.toList()
                ready.clear()
                for (chunk in copy) {
                    ensureActive()
                    try {
                        require(chunk.file.length() > 3_244L) { "Não foi possível preparar áudio suficiente para a legenda." }
                        onChunk(chunk.offsetMs, chunk.durationMs, chunk.file)
                    } finally {
                        chunk.file.delete()
                    }
                }
            }

            val info = MediaCodec.BufferInfo()
            while (!outputDone && writer != null) {
                ensureActive()
                if (!inputDone) {
                    val inputIndex = decoder.dequeueInputBuffer(TIMEOUT_US)
                    if (inputIndex >= 0) {
                        val buffer = decoder.getInputBuffer(inputIndex) ?: continue
                        val sampleTime = extractor.sampleTime
                        if (sampleTime < 0L || sampleTime >= endUs) {
                            decoder.queueInputBuffer(inputIndex, 0, 0, maxOf(sampleTime, endUs), MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            val size = extractor.readSampleData(buffer, 0)
                            if (size < 0) {
                                decoder.queueInputBuffer(inputIndex, 0, 0, maxOf(sampleTime, startUs), MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            } else {
                                decoder.queueInputBuffer(inputIndex, 0, size, sampleTime, 0)
                                extractor.advance()
                            }
                        }
                    }
                }

                val outputIndex = decoder.dequeueOutputBuffer(info, TIMEOUT_US)
                when {
                    outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val format = decoder.outputFormat
                        sampleRate = format.getIntegerOr(MediaFormat.KEY_SAMPLE_RATE, sampleRate).coerceAtLeast(1)
                        channelCount = format.getIntegerOr(MediaFormat.KEY_CHANNEL_COUNT, channelCount).coerceAtLeast(1)
                        pcmEncoding = format.getIntegerOr(MediaFormat.KEY_PCM_ENCODING, AudioFormat.ENCODING_PCM_16BIT)
                    }
                    outputIndex >= 0 -> {
                        val buffer = decoder.getOutputBuffer(outputIndex)
                        if (buffer != null && info.size > 0 && info.presentationTimeUs < endUs && writer != null) {
                            buffer.position(info.offset)
                            buffer.limit(info.offset + info.size)
                            val slice = buffer.slice().order(ByteOrder.nativeOrder())
                            if (pcmEncoding == AudioFormat.ENCODING_PCM_FLOAT) {
                                val samples = slice.asFloatBuffer()
                                val frameCount = samples.remaining() / channelCount
                                for (frame in 0 until frameCount) {
                                    var sum = 0f
                                    repeat(channelCount) { sum += samples.get() }
                                    val frameUs = info.presentationTimeUs + (frame * 1_000_000L / sampleRate)
                                    if (frameUs in startUs until endUs && writer != null) {
                                        val mono = ((sum / channelCount).coerceIn(-1f, 1f) * Short.MAX_VALUE)
                                            .toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
                                        resample(mono)
                                    }
                                }
                            } else {
                                val samples = slice.asShortBuffer()
                                val frameCount = samples.remaining() / channelCount
                                for (frame in 0 until frameCount) {
                                    var sum = 0L
                                    repeat(channelCount) { sum += samples.get().toLong() }
                                    val frameUs = info.presentationTimeUs + (frame * 1_000_000L / sampleRate)
                                    if (frameUs in startUs until endUs && writer != null) {
                                        resample((sum / channelCount).coerceIn(Short.MIN_VALUE.toLong(), Short.MAX_VALUE.toLong()).toShort())
                                    }
                                }
                            }
                        }
                        outputDone = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                        decoder.releaseOutputBuffer(outputIndex, false)
                        dispatchReady()
                    }
                }
            }

            // A decoder may end a couple of samples before the exact mathematical target after
            // resampling. Keep the final partial window if it contains meaningful audio.
            writer?.let { finalWriter ->
                if (finalWriter.samplesWritten > TARGET_RATE / 10L) {
                    finalWriter.finish()
                    ready += ReadyChunk(
                        offsetMs = (finalWriter.startSample * 1_000L) / TARGET_RATE,
                        durationMs = finalWriter.plannedDurationMs,
                        file = finalWriter.file,
                    )
                    writer = null
                }
            }
            dispatchReady()
        } finally {
            writer?.let { w -> w.abort(); runCatching { w.file.delete() } }
            ready.forEach { runCatching { it.file.delete() } }
            runCatching { decoder?.stop() }
            runCatching { decoder?.release() }
            extractor.release()
        }
    }


    /**
     * Two tiny file passes (~1 MB for a 30 s chunk) normalize quiet material without keeping PCM
     * in RAM. Loud masters stay essentially untouched; gain is capped to avoid pumping/noise.
     */
    private fun normalizePcm16Mono(file: RandomAccessFile, dataSize: Long) {
        if (dataSize <= 0L) return
        val buffer = ByteArray(32 * 1024)
        var peak = 0
        var sumSquares = 0.0
        var samples = 0L
        file.seek(44L)
        var remaining = dataSize
        while (remaining > 1L) {
            val wanted = minOf(buffer.size.toLong(), remaining).toInt().let { it - (it and 1) }
            if (wanted <= 0) break
            val read = file.read(buffer, 0, wanted)
            if (read <= 1) break
            var i = 0
            while (i + 1 < read) {
                val value = ((buffer[i].toInt() and 0xff) or ((buffer[i + 1].toInt() and 0xff) shl 8)).toShort().toInt()
                val absValue = kotlin.math.abs(value).coerceAtMost(32767)
                if (absValue > peak) peak = absValue
                val normalized = value / 32768.0
                sumSquares += normalized * normalized
                samples++
                i += 2
            }
            remaining -= read.toLong()
        }
        if (samples <= 0L || peak <= 0) return
        val peakNorm = peak / 32768.0
        val rms = kotlin.math.sqrt(sumSquares / samples)
        if (rms <= 0.0005) return
        val byPeak = 0.94 / peakNorm.coerceAtLeast(0.0001)
        val byRms = 0.16 / rms
        val gain = minOf(byPeak, byRms).coerceIn(1.0, 1.65)
        if (gain < 1.03) return

        file.seek(44L)
        remaining = dataSize
        while (remaining > 1L) {
            val wanted = minOf(buffer.size.toLong(), remaining).toInt().let { it - (it and 1) }
            if (wanted <= 0) break
            val read = file.read(buffer, 0, wanted)
            if (read <= 1) break
            var i = 0
            while (i + 1 < read) {
                val value = ((buffer[i].toInt() and 0xff) or ((buffer[i + 1].toInt() and 0xff) shl 8)).toShort().toInt()
                val scaled = (value * gain).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                buffer[i] = (scaled and 0xff).toByte()
                buffer[i + 1] = ((scaled ushr 8) and 0xff).toByte()
                i += 2
            }
            val afterRead = file.filePointer
            file.seek(afterRead - read)
            file.write(buffer, 0, read)
            remaining -= read.toLong()
        }
    }

    private fun writeWavHeader(file: RandomAccessFile, dataSize: Long) {
        fun writeAscii(value: String) = file.write(value.toByteArray(Charsets.US_ASCII))
        fun writeIntLE(value: Long) {
            file.write((value and 0xff).toInt())
            file.write(((value shr 8) and 0xff).toInt())
            file.write(((value shr 16) and 0xff).toInt())
            file.write(((value shr 24) and 0xff).toInt())
        }
        fun writeShortLE(value: Int) {
            file.write(value and 0xff)
            file.write((value ushr 8) and 0xff)
        }

        writeAscii("RIFF")
        writeIntLE(36L + dataSize)
        writeAscii("WAVE")
        writeAscii("fmt ")
        writeIntLE(16)
        writeShortLE(1)
        writeShortLE(1)
        writeIntLE(TARGET_RATE.toLong())
        writeIntLE(TARGET_RATE * 2L)
        writeShortLE(2)
        writeShortLE(16)
        writeAscii("data")
        writeIntLE(dataSize)
    }

    private fun MediaFormat.getIntegerOr(key: String, fallback: Int): Int =
        if (containsKey(key)) runCatching { getInteger(key) }.getOrDefault(fallback) else fallback
}
