package com.sonusstudios.sonusedit.catalog

import android.content.Context
import com.sonusstudios.sonusedit.create.AudioMetadata
import com.sonusstudios.sonusedit.create.AudioMetadataReader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Small persistent metadata cache so pCloud file codes are never the preferred visible label. */
class StreamMetadataStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("sonus_edit_stream_metadata", Context.MODE_PRIVATE)

    fun cached(asset: PCloudAsset): AudioMetadata? {
        val raw = prefs.getString(asset.stableKey, null) ?: return null
        val parts = raw.split('\u001F')
        if (parts.size < 5 || isOpaqueCode(parts[0])) return null
        return AudioMetadata(
            title = parts[0],
            artist = parts[1].ifBlank { null },
            durationMs = parts[2].toLongOrNull() ?: asset.durationMs ?: 0L,
            album = parts[3].ifBlank { null },
            genre = parts[4].ifBlank { null },
        )
    }

    suspend fun resolve(asset: PCloudAsset, repository: PCloudMusicRepository): AudioMetadata {
        cached(asset)?.let { return it }
        return resolveWithUrl(asset, repository.downloadUrl(asset))
    }

    /** Index a catalog in the background with bounded network/metadata concurrency. */
    suspend fun indexCatalog(
        assets: List<PCloudAsset>,
        repository: PCloudMusicRepository,
        onIndexed: (Int) -> Unit = {},
    ): Int = coroutineScope {
        val supported = setOf("mp3", "m4a", "flac", "wav", "aac", "ogg", "opus")
        val targets = assets.filter { cached(it) == null && it.extension.lowercase() in supported }
        val nextIndex = java.util.concurrent.atomic.AtomicInteger(0)
        val completed = java.util.concurrent.atomic.AtomicInteger(0)
        // Three fixed workers bound both active HTTP metadata reads and coroutine count. A large
        // catalogue no longer creates one waiting coroutine per audio file.
        val workers = List(3) {
            launch(Dispatchers.IO) {
                while (true) {
                    val index = nextIndex.getAndIncrement()
                    if (index >= targets.size) break
                    runCatching { resolve(targets[index], repository) }
                    val next = completed.incrementAndGet()
                    withContext(Dispatchers.Main.immediate) { onIndexed(next) }
                }
            }
        }
        workers.forEach { it.join() }
        completed.get()
    }

    fun displayTitle(asset: PCloudAsset): String {
        val stored = cached(asset)?.title?.takeIf { it.isNotBlank() }
        if (stored != null && !isOpaqueCode(stored)) return stored
        val fallback = asset.name.substringBeforeLast('.', asset.name).replace('_', ' ').trim()
        return if (isOpaqueCode(fallback)) "Lendo metadados…" else fallback.ifBlank { "Música do Stream" }
    }

    private fun isOpaqueCode(value: String): Boolean = value.matches(Regex("[A-Za-z0-9_-]{18,}"))

    suspend fun resolveWithUrl(asset: PCloudAsset, url: String?): AudioMetadata = withContext(Dispatchers.IO) {
        cached(asset)?.let { return@withContext it }
        val fallbackTitle = asset.name.substringBeforeLast('.', asset.name)
        val metadata = if (url != null) {
            AudioMetadataReader.readRemote(
                url = url,
                fallbackTitle = fallbackTitle,
                fallbackArtist = null,
                fallbackDurationMs = asset.durationMs ?: 0L,
                fallbackGenre = asset.genre,
            )
        } else {
            AudioMetadata(fallbackTitle, null, asset.durationMs ?: 0L, genre = asset.genre)
        }
        if (metadata.title.isNotBlank() && !isOpaqueCode(metadata.title)) {
            prefs.edit().putString(
                asset.stableKey,
                listOf(metadata.title, metadata.artist.orEmpty(), metadata.durationMs.toString(), metadata.album.orEmpty(), metadata.genre.orEmpty()).joinToString("\u001F")
            ).apply()
        } else {
            // Do not permanently cache an unresolved pCloud code as if it were a real title;
            // later catalog indexing must be allowed to retry after a transient URL/tag failure.
            prefs.edit().remove(asset.stableKey).apply()
        }
        metadata
    }
}
