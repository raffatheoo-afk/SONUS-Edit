package com.sonusstudios.sonusedit.catalog

import android.content.Context
import com.sonusstudios.sonusedit.create.AudioMetadata
import com.sonusstudios.sonusedit.create.AudioMetadataReader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Small persistent metadata cache so pCloud file codes are never the preferred visible label. */
class StreamMetadataStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("sonus_edit_stream_metadata", Context.MODE_PRIVATE)

    private fun stored(asset: PCloudAsset): AudioMetadata? {
        val raw = prefs.getString(asset.stableKey, null) ?: return null
        val parts = raw.split('\u001F')
        if (parts.size < 5 || isOpaqueCode(parts[0])) return null
        return AudioMetadata(
            title = parts[0],
            artist = parts[1].ifBlank { null },
            durationMs = parts[2].toLongOrNull() ?: asset.durationMs ?: 0L,
            album = parts[3].ifBlank { null },
            genre = parts[4].ifBlank { null },
        )
    }

    /** Persistent ID3 cache first, then the tags already supplied by pCloud's catalog. */
    fun cached(asset: PCloudAsset): AudioMetadata? =
        stored(asset) ?: StreamCatalogMetadataMapper.fromAsset(asset)

    suspend fun resolve(asset: PCloudAsset, repository: PCloudMusicRepository): AudioMetadata {
        stored(asset)?.let { return it }
        if (StreamCatalogMetadataMapper.hasUsefulCatalogIdentity(asset)) {
            return StreamCatalogMetadataMapper.fromAsset(asset)!!
        }
        return resolveWithUrl(asset, repository.downloadUrl(asset))
    }

    /** Index a catalog in the background with bounded network/metadata concurrency. */
    suspend fun indexCatalog(
        assets: List<PCloudAsset>,
        repository: PCloudMusicRepository,
        onIndexed: (Int) -> Unit = {},
    ): Int = coroutineScope {
        val supported = setOf("mp3", "m4a", "flac", "wav", "aac", "ogg", "opus")
        // Files that already expose title + artist in showpublink metadata need no audio download.
        val targets = assets.filter {
            stored(it) == null && !StreamCatalogMetadataMapper.hasUsefulCatalogIdentity(it) &&
                it.extension.lowercase() in supported
        }
        val nextIndex = java.util.concurrent.atomic.AtomicInteger(0)
        val completed = java.util.concurrent.atomic.AtomicInteger(0)
        // Three fixed workers bound both active HTTP metadata reads and coroutine count. A large
        // catalogue no longer creates one waiting coroutine per audio file.
        val workers = List(3) {
            launch(Dispatchers.IO) {
                while (true) {
                    val index = nextIndex.getAndIncrement()
                    if (index >= targets.size) break
                    runCatching { resolve(targets[index], repository) }
                    val next = completed.incrementAndGet()
                    withContext(Dispatchers.Main.immediate) { onIndexed(next) }
                }
            }
        }
        workers.forEach { it.join() }
        completed.get()
    }

    fun displayTitle(asset: PCloudAsset): String {
        val stored = cached(asset)?.title?.takeIf { it.isNotBlank() }
        if (stored != null && !isOpaqueCode(stored)) return stored
        val fallback = asset.name.substringBeforeLast('.', asset.name).replace('_', ' ').trim()
        return if (isOpaqueCode(fallback)) "Lendo metadados…" else fallback.ifBlank { "Música do Stream" }
    }

    private fun isOpaqueCode(value: String): Boolean = StreamCatalogMetadataMapper.isOpaqueCode(value)

    suspend fun resolveWithUrl(asset: PCloudAsset, url: String?): AudioMetadata = withContext(Dispatchers.IO) {
        stored(asset)?.let { return@withContext it }
        val catalogMetadata = StreamCatalogMetadataMapper.fromAsset(asset)
        if (StreamCatalogMetadataMapper.hasUsefulCatalogIdentity(asset) && catalogMetadata != null) {
            return@withContext catalogMetadata
        }
        val fallbackTitle = catalogMetadata?.title ?: asset.name.substringBeforeLast('.', asset.name)
        val remote = if (url != null) {
            AudioMetadataReader.readRemote(
                url = url,
                fallbackTitle = fallbackTitle,
                fallbackArtist = catalogMetadata?.artist,
                fallbackDurationMs = asset.durationMs ?: catalogMetadata?.durationMs ?: 0L,
                fallbackGenre = catalogMetadata?.genre ?: asset.metadataGenre ?: asset.genre,
            )
        } else {
            AudioMetadata(fallbackTitle, catalogMetadata?.artist, asset.durationMs ?: catalogMetadata?.durationMs ?: 0L,
                album = catalogMetadata?.album, genre = catalogMetadata?.genre ?: asset.metadataGenre ?: asset.genre)
        }
        val metadata = StreamCatalogMetadataMapper.merge(catalogMetadata, remote)
        if (metadata.title.isNotBlank() && !isOpaqueCode(metadata.title)) {
            prefs.edit().putString(
                asset.stableKey,
                listOf(metadata.title, metadata.artist.orEmpty(), metadata.durationMs.toString(), metadata.album.orEmpty(), metadata.genre.orEmpty()).joinToString("\u001F")
            ).apply()
        } else {
            // Do not permanently cache an unresolved pCloud code as if it were a real title;
            // later catalog indexing must be allowed to retry after a transient URL/tag failure.
            prefs.edit().remove(asset.stableKey).apply()
        }
        metadata
    }
}
