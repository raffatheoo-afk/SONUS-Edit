package com.sonusstudios.sonusedit.create

/** Rejects late cache/network callbacks from an older request, including a repeated identical query. */
object GalleryQueryRequestGate14 {
    fun canPublish(
        requestedQuery: String,
        currentQuery: String,
        requestedRatio: String,
        currentRatio: String,
        requestGeneration: Long,
        currentGeneration: Long,
    ): Boolean = requestGeneration == currentGeneration &&
        GalleryQueryResultGate13.canPublish(
            requestedQuery, currentQuery, requestedRatio, currentRatio,
        )
}
