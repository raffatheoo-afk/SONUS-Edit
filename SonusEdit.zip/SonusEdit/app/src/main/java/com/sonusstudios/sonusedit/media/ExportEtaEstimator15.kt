package com.sonusstudios.sonusedit.media

import com.sonusstudios.sonusedit.create.CreateProjectDraft
import com.sonusstudios.sonusedit.stats.ExportTimingSample
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.roundToLong

/** Conservative local estimate based only on completed exports from this device. */
object ExportEtaEstimator15 {
    const val MIN_SAMPLES = 5
    private const val MAX_SAMPLES = 20

    fun validSampleCount(samples: List<ExportTimingSample>): Int = samples.count {
        it.videoDurationMs > 0L && it.exportTimeMs in 1_000L..(12L * 60L * 60_000L) &&
            it.outputWidth > 0 && it.outputHeight > 0 && it.fps in setOf(30, 60) && it.mediaCount > 0
    }

    /** Returns null until at least five real, successful exports have been recorded. */
    fun expectedTotalMs(draft: CreateProjectDraft, samples: List<ExportTimingSample>): Long? {
        val targetDuration = draft.segmentDurationMs
        val targetPixels = draft.outputWidth().toDouble() * draft.outputHeight().toDouble()
        if (targetDuration <= 0L || targetPixels <= 0.0) return null

        val valid = samples.filter {
            it.videoDurationMs > 0L && it.exportTimeMs in 1_000L..(12L * 60L * 60_000L) &&
                it.outputWidth > 0 && it.outputHeight > 0 && it.fps in setOf(30, 60) && it.mediaCount > 0
        }.takeLast(MAX_SAMPLES)
        if (valid.size < MIN_SAMPLES) return null

        data class Projection(val totalMs: Double, val score: Double)
        val projections = valid.map { sample ->
            val durationRatio = targetDuration.toDouble() / sample.videoDurationMs.toDouble()
            val pixelRatio = targetPixels / (sample.outputWidth.toDouble() * sample.outputHeight.toDouble())
            val fpsRatio = draft.exportFps.toDouble() / sample.fps.toDouble()
            val projected = sample.exportTimeMs.toDouble() * durationRatio *
                pixelRatio.coerceIn(0.35, 2.85).pow(0.42) * fpsRatio.coerceIn(0.5, 2.0).pow(0.55)
            val durationGap = abs(ln(durationRatio.coerceIn(0.05, 20.0)))
            val pixelGap = abs(ln(pixelRatio.coerceIn(0.1, 10.0)))
            val fpsGap = abs(ln(fpsRatio.coerceIn(0.25, 4.0)))
            val mediaRatio = draft.imageUris.size.coerceAtLeast(1).toDouble() / sample.mediaCount.toDouble()
            val mediaGap = abs(ln(mediaRatio.coerceIn(0.1, 10.0)))
            val effectPenalty = if (draft.particlesEnabled == sample.particlesEnabled) 0.0 else 0.22
            Projection(
                totalMs = projected,
                score = durationGap + pixelGap * 0.22 + fpsGap * 0.30 + mediaGap * 0.12 + effectPenalty,
            )
        }.filter { it.totalMs.isFinite() && it.totalMs > 0.0 }
            .sortedBy { it.score }
            .take(10)
        if (projections.size < MIN_SAMPLES) return null

        val weighted = projections.sumOf { it.totalMs * exp(-1.35 * it.score) }
        val weights = projections.sumOf { exp(-1.35 * it.score) }
        if (weights <= 0.0 || !weighted.isFinite()) return null
        return (weighted / weights).roundToLong().coerceIn(1_000L, 12L * 60L * 60_000L)
    }

    /** Never shows zero before the service reports SAVED; a late finalization holds at one second. */
    fun remainingMs(expectedTotalMs: Long?, elapsedMs: Long): Long? {
        val total = expectedTotalMs?.takeIf { it > 0L } ?: return null
        return (total - elapsedMs.coerceAtLeast(0L)).coerceAtLeast(1_000L)
    }
}
