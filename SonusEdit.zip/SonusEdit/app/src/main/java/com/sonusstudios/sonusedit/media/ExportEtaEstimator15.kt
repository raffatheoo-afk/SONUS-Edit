package com.sonusstudios.sonusedit.media

import com.sonusstudios.sonusedit.create.CreateProjectDraft
import com.sonusstudios.sonusedit.stats.ExportTimingSample
import kotlin.math.roundToLong

/** Device-local ETA. Failed/cancelled exports are never timing samples. */
object ExportEtaEstimator15 {
    private const val MAX_SAMPLES = 10
    private const val MAX_ETA_MS = 12L * 60L * 60_000L

    private data class Benchmark(val seconds: LongArray, val times: LongArray)
    private val benchmarks = mapOf(
        (720 to 30) to Benchmark(longArrayOf(15, 30, 40, 50, 60), longArrayOf(11, 39, 26, 28, 34)),
        (1080 to 30) to Benchmark(longArrayOf(15, 30, 40, 50, 60), longArrayOf(12, 59, 36, 43, 56)),
        (2048 to 30) to Benchmark(longArrayOf(15, 30, 40, 50, 60), longArrayOf(19, 74, 56, 61, 63)),
        (3840 to 30) to Benchmark(longArrayOf(15, 30, 40, 50, 60), longArrayOf(59, 137, 124, 115, 172)),
        (720 to 60) to Benchmark(longArrayOf(15, 30, 40, 50, 60), longArrayOf(17, 34, 41, 56, 54)),
        (1080 to 60) to Benchmark(longArrayOf(15, 30, 40, 50, 60), longArrayOf(19, 59, 54, 64, 75)),
        (2048 to 60) to Benchmark(longArrayOf(15, 30, 40, 50, 60), longArrayOf(34, 92, 87, 101, 105)),
        // 60s 4K60 is intentionally absent: six reported attempts failed and are not successes.
        (3840 to 60) to Benchmark(longArrayOf(15, 30, 40, 50), longArrayOf(59, 212, 154, 144)),
    )

    fun validSampleCount(samples: List<ExportTimingSample>): Int = samples.count(::isValid)

    private fun isValid(sample: ExportTimingSample): Boolean =
        sample.videoDurationMs > 0L && sample.exportTimeMs in 1_000L..MAX_ETA_MS &&
            sample.outputWidth > 0 && sample.outputHeight > 0 && sample.fps in setOf(30, 60) && sample.mediaCount > 0

    private fun resolutionClass(width: Int, height: Int): Int = when (maxOf(width, height)) {
        in 1..1_500 -> 720
        in 1_501..2_300 -> 1080
        in 2_301..3_100 -> 2048
        else -> 3840
    }

    private fun predictFromBenchmark(durationMs: Long, resolution: Int, fps: Int): Long {
        val benchmark = benchmarks[resolution to fps] ?: benchmarks[720 to 30]!!
        val xs = benchmark.seconds.map { it.toDouble() }
        // Keep the user's measured points unchanged. Longer clips were sometimes faster
        // in the controlled same-music/same-images tests; do not force a monotonic curve.
        val ys = benchmark.times.map { it.toDouble() }
        val target = durationMs / 1_000.0
        val predictedSeconds = when {
            target <= xs.first() -> ys.first() * target / xs.first()
            target <= xs.last() -> {
                val upper = xs.indexOfFirst { it >= target }.coerceAtLeast(1)
                val lower = upper - 1
                val fraction = (target - xs[lower]) / (xs[upper] - xs[lower])
                ys[lower] + fraction * (ys[upper] - ys[lower])
            }
            // 4K60 has no successful 60-second reference: derive its cold-start estimate
            // from the successful 4K30/60s sample and the average 60/30 FPS ratio observed
            // at the common 15–50 second durations. Failed 4K60 attempts never enter the base.
            resolution == 3840 && fps == 60 && target > 50.0 -> {
                val base30 = predictFromBenchmark(durationMs, 3840, 30) / 1_000.0
                val ratios = benchmark.seconds.indices.mapNotNull { index ->
                    val seconds = benchmark.seconds[index]
                    val slower = benchmark.times[index].toDouble()
                    val faster = benchmarks[3840 to 30]?.let { other ->
                        val at = other.seconds.indexOf(seconds)
                        if (at >= 0) other.times[at].toDouble() else null
                    }
                    faster?.takeIf { it > 0.0 }?.let { slower / it }
                }.filter { it.isFinite() && it in 0.5..2.5 }
                base30 * (ratios.average().takeIf { it.isFinite() } ?: 1.25)
            }
            else -> {
                val positiveSlopes = (1 until xs.size).mapNotNull { index ->
                    val slope = (ys[index] - ys[index - 1]) / (xs[index] - xs[index - 1])
                    slope.takeIf { it > 0.0 && it.isFinite() }
                }
                val slope = positiveSlopes.takeLast(3).sorted().let { values ->
                    if (values.isEmpty()) ys.last() / xs.last()
                    else values[values.size / 2]
                }
                ys.last() + slope * (target - xs.last())
            }
        }.coerceAtLeast(5.0)
        return (predictedSeconds * 1_000.0).roundToLong().coerceIn(5_000L, MAX_ETA_MS)
    }

    fun expectedTotalMs(draft: CreateProjectDraft, samples: List<ExportTimingSample>): Long? {
        val duration = draft.segmentDurationMs
        if (duration <= 0L) return null
        val resolution = resolutionClass(draft.outputWidth(), draft.outputHeight())
        val fps = if (draft.exportFps == 30) 30 else 60
        val baseline = predictFromBenchmark(duration, resolution, fps)
        val horizontal = draft.outputWidth() > draft.outputHeight()
        val profileSamples = samples.filter { sample ->
            isValid(sample) && sample.fps == fps &&
                resolutionClass(sample.outputWidth, sample.outputHeight) == resolution &&
                (sample.outputWidth > sample.outputHeight) == horizontal &&
                (sample.aspectRatio.isBlank() || sample.aspectRatio == draft.aspectRatio)
        }
        // Prefer the same visual complexity (photo/video count and particles mode). If this
        // leaves too few measurements, widen gradually instead of withholding learning.
        val sameMediaAndEffects = profileSamples.filter {
            it.mediaCount == draft.imageUris.size && it.particlesEnabled == draft.particlesEnabled
        }
        val sameEffects = profileSamples.filter { it.particlesEnabled == draft.particlesEnabled }
        val comparable = (when {
            sameMediaAndEffects.size >= 2 -> sameMediaAndEffects
            sameEffects.size >= 2 -> sameEffects
            else -> profileSamples
        }).takeLast(MAX_SAMPLES)
        if (comparable.isEmpty()) return baseline

        // Normalize each completed result against its matching benchmark, then learn by
        // arithmetic moving average. With >=5 samples, trim one extreme at either end.
        val ratios = comparable.map { sample ->
            sample.exportTimeMs.toDouble() /
                predictFromBenchmark(sample.videoDurationMs, resolution, fps).coerceAtLeast(1L).toDouble()
        }.filter { it.isFinite() && it in 0.30..3.0 }.sorted()
        if (ratios.isEmpty()) return baseline
        val stableRatios = if (ratios.size >= 5) ratios.drop(1).dropLast(1) else ratios
        val averageRatio = stableRatios.average()
        val weight = (ratios.size.toDouble() / (ratios.size + 3.0)).coerceAtMost(0.80)
        return (baseline * (1.0 - weight + averageRatio * weight)).roundToLong().coerceIn(1_000L, MAX_ETA_MS)
    }

    /** Keeps whole-job elapsed time while giving a new fallback attempt its own remaining estimate. */
    fun totalAfterFallback(elapsedBeforeFallbackMs: Long, fallbackAttemptEstimateMs: Long?): Long? {
        val fallback = fallbackAttemptEstimateMs?.takeIf { it > 0L } ?: return null
        return (elapsedBeforeFallbackMs.coerceAtLeast(0L) + fallback).coerceAtMost(MAX_ETA_MS)
    }

    /** Clock and displayed progress use the same predicted total; 100 is reserved for save success. */
    fun progressPercent(expectedTotalMs: Long?, elapsedMs: Long, completed: Boolean = false): Int {
        if (completed) return 100
        val total = expectedTotalMs?.takeIf { it > 0L } ?: return 0
        return ((elapsedMs.coerceAtLeast(0L).toDouble() / total.toDouble()) * 100.0)
            .toInt().coerceIn(0, 99)
    }

    fun remainingMs(expectedTotalMs: Long?, elapsedMs: Long): Long? {
        val total = expectedTotalMs?.takeIf { it > 0L } ?: return null
        return (total - elapsedMs.coerceAtLeast(0L)).coerceAtLeast(1_000L)
    }
}
