package com.sonusstudios.sonusedit.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.sonusstudios.sonusedit.R
import com.sonusstudios.sonusedit.create.CreateProjectDraft
import com.sonusstudios.sonusedit.create.CreationDraftSnapshot
import com.sonusstudios.sonusedit.create.CreationDraftStore
import com.sonusstudios.sonusedit.designsystem.SonusEditColors
import com.sonusstudios.sonusedit.designsystem.SonusEditTheme
import com.sonusstudios.sonusedit.integration.IncomingIntentRouter
import com.sonusstudios.sonusedit.navigation.AppRoute
import com.sonusstudios.sonusedit.stats.UsageStatsStore
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun SonusEditApp(incomingRoute: StateFlow<IncomingIntentRouter.Route?>) {
    SonusEditTheme {
        val context = LocalContext.current
        val lifecycleOwner = LocalLifecycleOwner.current
        val scope = rememberCoroutineScope()
        val statsStore = remember { UsageStatsStore(context.applicationContext) }
        var foregroundStartedAt by remember { mutableStateOf(System.currentTimeMillis()) }

        DisposableEffect(lifecycleOwner) {
            val observer = LifecycleEventObserver { _, event ->
                when (event) {
                    Lifecycle.Event.ON_START -> foregroundStartedAt = System.currentTimeMillis()
                    Lifecycle.Event.ON_STOP -> {
                        val end = System.currentTimeMillis()
                        val start = foregroundStartedAt
                        scope.launch { statsStore.recordForeground(start, end) }
                    }
                    else -> Unit
                }
            }
            lifecycleOwner.lifecycle.addObserver(observer)
            onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
        }

        var splashVisible by remember { mutableStateOf(true) }
        LaunchedEffect(Unit) {
            delay(1_900)
            splashVisible = false
        }
        Box(
            Modifier
                .fillMaxSize()
                .background(SonusEditColors.Black)
                .windowInsetsPadding(WindowInsets.safeDrawing)
        ) {
            if (splashVisible) SonusEditSplash() else SonusNavigation(incomingRoute)
        }
    }
}

@Composable
private fun SonusNavigation(incomingRoute: StateFlow<IncomingIntentRouter.Route?>) {
    val context = LocalContext.current
    val navController = rememberNavController()
    val route by incomingRoute.collectAsState()
    val scope = rememberCoroutineScope()
    val draftStore = remember { CreationDraftStore(context.applicationContext) }
    var activeDraft by remember { mutableStateOf<CreateProjectDraft?>(null) }
    var resumeDraft by remember { mutableStateOf<CreationDraftSnapshot?>(null) }
    var openLinkOnStart by remember { mutableStateOf(false) }
    var showSyncPopup by remember { mutableStateOf(false) }
    // Where the export screen was opened from, so "Criar outro"/"Voltar" lands in the right place.
    var editorFromAutoCaptions by remember { mutableStateOf(false) }

    LaunchedEffect(route) {
        when (route) {
            is IncomingIntentRouter.Route.SonusTrack -> {
                resumeDraft = null
                openLinkOnStart = false
                showSyncPopup = true
                navController.navigate(AppRoute.Create.route) { launchSingleTop = true }
            }
            is IncomingIntentRouter.Route.SharedMedia -> {
                resumeDraft = null
                openLinkOnStart = false
                navController.navigate(AppRoute.Create.route) { launchSingleTop = true }
            }
            is IncomingIntentRouter.Route.ExportProgress -> navController.navigate(AppRoute.Editor.route) { launchSingleTop = true }
            else -> Unit
        }
    }

    Box(Modifier.fillMaxSize()) {
        NavHost(navController = navController, startDestination = AppRoute.Home.route) {
            composable(AppRoute.Home.route) {
                HomeScreen(
                    onCreate = {
                        resumeDraft = null
                        openLinkOnStart = false
                        navController.navigate(AppRoute.Create.route) { launchSingleTop = true }
                    },
                    onCreateFromLink = {
                        resumeDraft = null
                        openLinkOnStart = true
                        navController.navigate(AppRoute.Create.route) { launchSingleTop = true }
                    },
                    onResumeDraft = {
                        scope.launch {
                            val saved = draftStore.load() ?: return@launch
                            resumeDraft = saved
                            openLinkOnStart = saved.audioSource.name == "LINK" && saved.audioUri == null
                            navController.navigate(AppRoute.Create.route) { launchSingleTop = true }
                        }
                    },
                    onAutoCaptions = { navController.navigate(AppRoute.AutoCaptions.route) { launchSingleTop = true } },
                    onStats = { navController.navigate(AppRoute.Stats.route) },
                    onSettings = { navController.navigate(AppRoute.Settings.route) },
                    onPremium = { navController.navigate(AppRoute.Premium.route) },
                )
            }
            composable(AppRoute.Premium.route) {
                PremiumPlansScreen(onBack = { navController.popBackStack() })
            }
            composable(AppRoute.Settings.route) {
                AutomationSettingsScreen(onBack = { navController.popBackStack() })
            }
            composable(AppRoute.Stats.route) {
                StatisticsScreen(onBack = { navController.popBackStack() })
            }
            composable(AppRoute.Create.route) {
                CreateFlowScreen(
                    incomingRoute = route,
                    openLinkOnStart = openLinkOnStart,
                    resumeDraft = resumeDraft,
                    onInitialSyncFinished = { showSyncPopup = false },
                    onBack = { navController.popBackStack() },
                    onCreateDraft = { draft ->
                        editorFromAutoCaptions = false
                        activeDraft = draft
                        navController.navigate(AppRoute.Editor.route)
                    },
                )
            }
            composable(AppRoute.AutoCaptions.route) {
                AutoCaptionsScreen(
                    onBack = { navController.popBackStack() },
                    onExport = { draft ->
                        editorFromAutoCaptions = true
                        activeDraft = draft
                        navController.navigate(AppRoute.Editor.route)
                    },
                )
            }
            composable(AppRoute.Editor.route) {
                EditorScreen(
                    incomingRoute = route,
                    draft = activeDraft,
                    onBack = {
                        if (editorFromAutoCaptions) navController.popBackStack(AppRoute.Home.route, false)
                        else navController.popBackStack(AppRoute.Create.route, false)
                    },
                )
            }
        }
        if (showSyncPopup) {
            ProcessProgressOverlay(
                title = "Sincronizando",
                status = "Carregando música compartilhada pelo SONUS…",
                progressPercent = null,
            )
        }
    }
}

@Composable
private fun SonusEditSplash() {
    val infinite = rememberInfiniteTransition(label = "logoArrows")
    val rotation by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(1_350, easing = LinearEasing)),
        label = "arrowRotation",
    )

    Box(Modifier.fillMaxSize().padding(horizontal = 28.dp)) {
        Column(
            Modifier.align(Alignment.Center).padding(bottom = 44.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(Modifier.size(178.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize().graphicsLayer { rotationZ = rotation }) {
                    val stroke = size.minDimension * .105f
                    val radius = size.minDimension * .365f
                    val topLeft = androidx.compose.ui.geometry.Offset(center.x - radius, center.y - radius)
                    val arcSize = androidx.compose.ui.geometry.Size(radius * 2f, radius * 2f)
                    val gradient = Brush.sweepGradient(
                        listOf(Color(0xFF11D8FF), Color(0xFF6A3BFF), Color(0xFFFF42D0), Color(0xFF11D8FF)),
                        center = center,
                    )
                    drawArc(gradient, startAngle = 205f, sweepAngle = 125f, useCenter = false, topLeft = topLeft, size = arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
                    drawArc(gradient, startAngle = 25f, sweepAngle = 125f, useCenter = false, topLeft = topLeft, size = arcSize, style = Stroke(stroke, cap = StrokeCap.Round))

                    fun arrowHead(angleDeg: Float, tint: Color) {
                        val a = Math.toRadians(angleDeg.toDouble())
                        val tipRadius = radius + stroke * .30f
                        val tip = androidx.compose.ui.geometry.Offset(
                            center.x + cos(a).toFloat() * tipRadius,
                            center.y + sin(a).toFloat() * tipRadius,
                        )
                        val tangentX = -sin(a).toFloat()
                        val tangentY = cos(a).toFloat()
                        val radialX = cos(a).toFloat()
                        val radialY = sin(a).toFloat()
                        val head = stroke * 1.05f
                        val back = stroke * .76f
                        val p = Path().apply {
                            moveTo(tip.x, tip.y)
                            lineTo(tip.x - radialX * back + tangentX * head * .62f, tip.y - radialY * back + tangentY * head * .62f)
                            lineTo(tip.x - radialX * back - tangentX * head * .62f, tip.y - radialY * back - tangentY * head * .62f)
                            close()
                        }
                        drawPath(p, tint)
                    }
                    arrowHead(330f, Color(0xFF13D9FF))
                    arrowHead(150f, Color(0xFF7850FF))
                }
                Image(
                    painterResource(R.drawable.sonus_edit_logo_center),
                    contentDescription = "Sonus Edit",
                    modifier = Modifier.fillMaxSize(),
                )
            }
            Spacer(Modifier.height(2.dp))
            androidx.compose.material3.Text("Sonus Edit", color = Color.White, fontSize = 31.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(5.dp))
            androidx.compose.material3.Text("Seu vídeo musical, pronto em segundos.", color = SonusEditColors.TextMuted, fontSize = 12.sp)
        }

        androidx.compose.material3.Text(
            "by SONUS STUDIOS - RΛFΛ亗",
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 4.dp),
            color = SonusEditColors.TextMuted.copy(alpha = .72f),
            fontSize = 10.sp,
        )
    }
}
