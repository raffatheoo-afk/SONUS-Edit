package com.sonusstudios.sonusedit.ui

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.sonusstudios.sonusedit.R
import com.sonusstudios.sonusedit.catalog.PCloudAsset
import com.sonusstudios.sonusedit.create.CreateProjectDraft
import com.sonusstudios.sonusedit.designsystem.SonusEditColors
import com.sonusstudios.sonusedit.designsystem.SonusEditTheme
import com.sonusstudios.sonusedit.integration.IncomingIntentRouter
import com.sonusstudios.sonusedit.navigation.AppRoute
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.StateFlow

@Composable
fun SonusEditApp(incomingRoute: StateFlow<IncomingIntentRouter.Route?>) {
    SonusEditTheme {
        var splashVisible by remember { mutableStateOf(true) }
        LaunchedEffect(Unit) {
            delay(3_000)
            splashVisible = false
        }
        Box(
            Modifier
                .fillMaxSize()
                .background(SonusEditColors.Black)
                .windowInsetsPadding(WindowInsets.safeDrawing)
        ) {
            if (splashVisible) {
                SonusEditSplash()
            } else {
                SonusNavigation(incomingRoute)
            }
        }
    }
}

@Composable
private fun SonusNavigation(incomingRoute: StateFlow<IncomingIntentRouter.Route?>) {
    val navController = rememberNavController()
    val route by incomingRoute.collectAsState()
    var activeDraft by remember { mutableStateOf<CreateProjectDraft?>(null) }
    var preselectedStreamAsset by remember { mutableStateOf<PCloudAsset?>(null) }
    var showSyncPopup by remember { mutableStateOf(false) }

    LaunchedEffect(route) {
        when (route) {
            is IncomingIntentRouter.Route.SonusTrack -> {
                showSyncPopup = true
                navController.navigate(AppRoute.Create.route) { launchSingleTop = true }
                delay(1_700)
                showSyncPopup = false
            }
            is IncomingIntentRouter.Route.SharedMedia -> navController.navigate(AppRoute.Create.route) { launchSingleTop = true }
            is IncomingIntentRouter.Route.ExportProgress -> navController.navigate(AppRoute.Editor.route) { launchSingleTop = true }
            else -> Unit
        }
    }

    Box(Modifier.fillMaxSize()) {
    NavHost(navController = navController, startDestination = AppRoute.Home.route) {
        composable(AppRoute.Home.route) {
            HomeScreen(
                onCreate = {
                    preselectedStreamAsset = null
                    navController.navigate(AppRoute.Create.route)
                },
                onUseSuggestion = { asset ->
                    preselectedStreamAsset = asset
                    navController.navigate(AppRoute.Create.route)
                },
                onSettings = { navController.navigate(AppRoute.Settings.route) },
            )
        }
        composable(AppRoute.Settings.route) {
            AutomationSettingsScreen(onBack = { navController.popBackStack() })
        }
        composable(AppRoute.Create.route) {
            CreateFlowScreen(
                incomingRoute = route,
                preselectedStreamAsset = preselectedStreamAsset,
                onBack = { navController.popBackStack() },
                onCreateDraft = { draft ->
                    activeDraft = draft
                    navController.navigate(AppRoute.Editor.route)
                },
            )
        }
        composable(AppRoute.Editor.route) {
            EditorScreen(
                incomingRoute = route,
                draft = activeDraft,
                onBack = { navController.popBackStack(AppRoute.Create.route, false) },
            )
        }
    }
        if (showSyncPopup) {
            Card(
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 18.dp),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF173C29).copy(alpha = 0.96f)),
            ) {
                Text(
                    "Sincronizando…",
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 11.dp),
                    color = Color(0xFF86F0AD),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                )
            }
        }
    }
}

@Composable
private fun SonusEditSplash() {
    val infinite = rememberInfiniteTransition(label = "record")
    val dotAlpha by infinite.animateFloat(
        initialValue = .25f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(520), repeatMode = RepeatMode.Reverse),
        label = "recordAlpha",
    )
    val morph by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1_800), repeatMode = RepeatMode.Reverse),
        label = "cameraMorph",
    )

    Box(Modifier.fillMaxSize().padding(horizontal = 28.dp)) {
        Column(
            Modifier.align(Alignment.Center).padding(bottom = 34.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Image(
                painterResource(R.drawable.sonus_edit_logo_transparent),
                contentDescription = "Sonus Edit",
                modifier = Modifier.size(178.dp),
            )
            Spacer(Modifier.height(10.dp))
            androidx.compose.foundation.layout.Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Sonus Edit", color = Color.White, fontSize = 31.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.size(8.dp))
                Box(Modifier.size(9.dp).background(Color.Red.copy(alpha = dotAlpha), CircleShape))
            }
            Spacer(Modifier.height(16.dp))
            CameraMorph(progress = morph, modifier = Modifier.size(width = 190.dp, height = 72.dp))
            Spacer(Modifier.height(8.dp))
            Text("Seu vídeo musical, pronto em Segundos.", color = SonusEditColors.TextMuted, fontSize = 12.sp)
        }

        Text(
            "by SONUS STUDIOS - RΛFΛ亗",
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 4.dp),
            color = SonusEditColors.TextMuted.copy(alpha = .72f),
            fontSize = 10.sp,
        )
    }
}

@Composable
private fun CameraMorph(progress: Float, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val c = Color.White
        val stroke = 4.dp.toPx()
        val centerY = size.height / 2f
        if (progress < .42f) {
            val p = progress / .42f
            val half = size.width * .38f * p
            drawLine(c, Offset(size.width / 2f - half, centerY), Offset(size.width / 2f + half, centerY), stroke, StrokeCap.Round)
        } else {
            val p = ((progress - .42f) / .58f).coerceIn(0f, 1f)
            val bodyW = size.width * .52f * p
            val bodyH = size.height * .42f * p
            val left = size.width / 2f - bodyW / 2f
            val top = centerY - bodyH / 2f
            val path = Path().apply {
                moveTo(left, top)
                lineTo(left + bodyW, top)
                lineTo(left + bodyW, top + bodyH)
                lineTo(left, top + bodyH)
                close()
            }
            drawPath(path, c, style = Stroke(stroke, cap = StrokeCap.Round))
            if (p > .35f) {
                val lensP = ((p - .35f) / .65f).coerceIn(0f, 1f)
                val x = left + bodyW
                val tri = Path().apply {
                    moveTo(x, centerY - bodyH * .25f * lensP)
                    lineTo(x + size.width * .12f * lensP, centerY - bodyH * .42f * lensP)
                    lineTo(x + size.width * .12f * lensP, centerY + bodyH * .42f * lensP)
                    lineTo(x, centerY + bodyH * .25f * lensP)
                    close()
                }
                drawPath(tri, c, style = Stroke(stroke, cap = StrokeCap.Round))
            }
            if (p > .55f) {
                val reelP = ((p - .55f) / .45f).coerceIn(0f, 1f)
                drawCircle(c, radius = size.height * .13f * reelP, center = Offset(size.width * .43f, top - size.height * .11f), style = Stroke(stroke))
                drawCircle(c, radius = size.height * .16f * reelP, center = Offset(size.width * .57f, top - size.height * .13f), style = Stroke(stroke))
            }
        }
    }
}
