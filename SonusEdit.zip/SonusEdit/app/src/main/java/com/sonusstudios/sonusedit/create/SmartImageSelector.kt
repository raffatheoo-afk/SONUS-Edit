package com.sonusstudios.sonusedit.create

import android.content.Context
import com.sonusstudios.sonusedit.catalog.PCloudAsset
import java.text.Normalizer
import kotlin.math.pow
import kotlin.random.Random

/**
 * Weighted image selection that keeps semantic relevance while varying each combination.
 * code19 adds an artist/category gate before normal scoring, so an explicitly tagged conflicting
 * image never wins just because a title word happened to match.
 */
object SmartImageSelector {
    data class Candidate(val asset: PCloudAsset, val score: Int)

    fun rank(
        assets: List<PCloudAsset>,
        metadata: AudioMetadata?,
        syncedLyrics: String?,
        artistCategory: ArtistGenreResolver.Match? = null,
    ): List<PCloudAsset> {
        val policy = categoryPolicy(assets, artistCategory, Int.MAX_VALUE, metadata?.title)
        return scored(policy.allowed, metadata, syncedLyrics, artistCategory)
            .sortedWith(compareByDescending<Candidate> { it.score }.thenBy { it.asset.stableKey })
            .map { it.asset }
    }

    /**
     * Manual Gallery search deliberately scans the full catalog for the active aspect ratio instead
     * of the artist/category-ranked subset. Search is an explicit user request, so a title/keyword
     * such as "Nossa Senhora Aparecida" or "Bar de Bairro" must still find files even when the
     * current song category is unrelated. Matching is accent/case/separator-insensitive and requires
     * all meaningful query words, allowing extra words such as "de/da/do" in file names.
     */
    fun searchManualGallery(assets: List<PCloudAsset>, query: String, blockedKeys: Set<String> = emptySet()): List<PCloudAsset> {
        val searchableAssets = assets.filterNot { it.stableKey in blockedKeys }
        val normalizedQuery = normalize(query)
        if (normalizedQuery.isBlank()) return searchableAssets

        val queryTerms = normalizedQuery
            .split(' ')
            .filter { it.length >= 2 && it !in searchStopWords }
            .distinct()
        val requiredTerms = queryTerms.ifEmpty { listOf(normalizedQuery) }

        return searchableAssets.mapNotNull { asset ->
            val name = normalize(asset.name.substringBeforeLast('.'))
            val folder = normalize(asset.folderPath)
            val haystack = listOf(name, folder).filter { it.isNotBlank() }.joinToString(" ")
            val matchedTerms = requiredTerms.count { haystack.containsPhrase(it) }
            if (matchedTerms != requiredTerms.size) return@mapNotNull null

            var score = matchedTerms * 100
            if (name == normalizedQuery) score += 1_200
            if (name.containsPhrase(normalizedQuery)) score += 700
            else if (haystack.containsPhrase(normalizedQuery)) score += 500
            if (name.startsWith(requiredTerms.firstOrNull().orEmpty())) score += 30
            Candidate(asset, score)
        }.sortedWith(compareByDescending<Candidate> { it.score }.thenBy { it.asset.name.lowercase() })
            .map { it.asset }
    }

    fun select(
        assets: List<PCloudAsset>,
        metadata: AudioMetadata?,
        syncedLyrics: String?,
        count: Int,
        recentKeys: Set<String>,
        nonce: Int,
        artistCategory: ArtistGenreResolver.Match? = null,
    ): List<PCloudAsset> {
        if (count <= 0 || assets.isEmpty()) return emptyList()
        val policy = categoryPolicy(assets, artistCategory, count, metadata?.title)
        // Never silently reuse images from the active format-specific recent-project window. If the remaining
        // catalogue is too small, return fewer suggestions instead of breaking the cooldown.
        val selectionPool = policy.allowed.filterNot { it.stableKey in recentKeys }
        val ranked = scored(selectionPool, metadata, syncedLyrics, artistCategory)
            .sortedWith(compareByDescending<Candidate> { it.score }.thenBy { it.asset.stableKey })
        val target = count.coerceAtMost(ranked.size)
        if (target <= 0) return emptyList()

        val positive = ranked.filter { it.score > 0 }
        val poolSize = maxOf(target, target * 4, target + 8).coerceAtMost(ranked.size)
        val relevantPool = when {
            positive.size >= target -> positive.take(maxOf(target, poolSize.coerceAtMost(positive.size)))
            else -> (positive + ranked.filter { it.score <= 0 }).distinctBy { it.asset.stableKey }.take(poolSize)
        }.toMutableList()

        val random = Random(System.nanoTime() xor nonce.toLong().shl(21) xor metadata?.title.hashCode().toLong())
        val selected = ArrayList<PCloudAsset>(target)
        while (selected.size < target && relevantPool.isNotEmpty()) {
            val weights = relevantPool.map { candidate ->
                val relevance = (candidate.score.coerceAtLeast(0) + 3).toDouble().pow(1.35)
                if (candidate.asset.stableKey in recentKeys) relevance * 0.08 else relevance
            }
            val total = weights.sum().coerceAtLeast(0.0001)
            var cursor = random.nextDouble() * total
            var index = weights.lastIndex
            for (i in weights.indices) {
                cursor -= weights[i]
                if (cursor <= 0.0) {
                    index = i
                    break
                }
            }
            selected += relevantPool.removeAt(index).asset
        }
        return selected.distinctBy { it.stableKey }
    }

    private data class CategoryPolicy(val allowed: List<PCloudAsset>)

    /**
     * Exact category tags are authoritative. If the gallery has enough exact matches for the
     * requested project, stay inside that pool. Otherwise, complete only with neutral assets;
     * explicit tags from another category remain excluded.
     */
    private fun categoryPolicy(
        assets: List<PCloudAsset>,
        match: ArtistGenreResolver.Match?,
        requestedCount: Int,
        songTitle: String? = null,
    ): CategoryPolicy {
        if (match == null || assets.isEmpty()) return CategoryPolicy(assets)
        val exactKeyword = normalize(match.imageKeyword)
        if (exactKeyword.isBlank()) return CategoryPolicy(assets)

        val normalizedTitle = normalize(songTitle.orEmpty())
        val titleTerms = normalizedTitle
            .split(' ')
            .filter { it.length >= 2 && it !in searchStopWords && it !in stopWords }
            .distinct()
        val titleMatches = mutableListOf<PCloudAsset>()
        val exact = mutableListOf<PCloudAsset>()
        val neutral = mutableListOf<PCloudAsset>()
        assets.forEach { asset ->
            val haystack = normalize("${asset.name.substringBeforeLast('.')} ${asset.folderPath}")
            val strongTitleMatch = normalizedTitle.isNotBlank() && (
                haystack.containsPhrase(normalizedTitle) ||
                    (titleTerms.size >= 2 && titleTerms.all { haystack.containsPhrase(it) })
                )
            when {
                // An explicit song-title file is an intentional override. This prevents the artist
                // genre gate from hiding a hand-named visual for a crossover/religious song while
                // still blocking unrelated category conflicts (e.g. Gustavo Mioto + random Maria).
                strongTitleMatch -> titleMatches += asset
                haystack.containsPhrase(exactKeyword) -> exact += asset
                match.blockedCategoryKeywords.any { blocked -> haystack.containsPhrase(normalize(blocked)) } -> Unit
                else -> neutral += asset
            }
        }

        val target = requestedCount.coerceAtLeast(1)
        val categoryPool = if (exact.size >= MIN_STRICT_CATEGORY_IMAGES) {
            if (exact.size >= target) exact else exact + neutral
        } else {
            exact + neutral
        }
        return CategoryPolicy((titleMatches + categoryPool).distinctBy { it.stableKey })
    }

    private fun scored(
        assets: List<PCloudAsset>,
        metadata: AudioMetadata?,
        syncedLyrics: String?,
        artistCategory: ArtistGenreResolver.Match?,
    ): List<Candidate> {
        val meta = metadata ?: return assets.map { Candidate(it, categoryBonus(it, artistCategory)) }
        val title = normalize(meta.title)
        val artist = normalize(meta.artist.orEmpty())
        val album = normalize(meta.album.orEmpty())
        val genre = normalize(meta.genre.orEmpty())
        val lyricTerms = normalize(syncedLyrics.orEmpty())
            .split(' ')
            .asSequence()
            .filter { it.length >= 5 && it !in stopWords }
            .groupingBy { it }
            .eachCount()
            .entries
            .sortedByDescending { it.value }
            .take(18)
            .map { it.key }
            .toSet()

        val titleTerms = terms(title, 4)
        val artistTerms = terms(artist, 3)
        val albumTerms = terms(album, 4)
        val genreTerms = terms(genre, 3)

        return assets.map { asset ->
            val name = normalize(asset.name.substringBeforeLast('.'))
            val folder = normalize(asset.folderPath)
            val haystack = "$name $folder"
            var score = categoryBonus(asset, artistCategory)
            if (title.isNotBlank()) {
                score += when {
                    name == title -> 260
                    haystack.containsPhrase(title) -> 220
                    titleTerms.size >= 2 && titleTerms.all { haystack.containsPhrase(it) } -> 170
                    else -> 0
                }
            }
            score += titleTerms.count { haystack.containsPhrase(it) } * 7
            if (artist.isNotBlank() && haystack.containsPhrase(artist)) score += 18
            score += artistTerms.count { haystack.containsPhrase(it) } * 5
            if (album.isNotBlank() && haystack.containsPhrase(album)) score += 14
            score += albumTerms.count { haystack.containsPhrase(it) } * 4
            if (genre.isNotBlank() && (folder == genre || folder.containsPhrase(genre))) score += 18
            score += genreTerms.count { haystack.containsPhrase(it) } * 5
            score += lyricTerms.count { haystack.containsPhrase(it) } * 2
            Candidate(asset, score)
        }
    }

    private fun categoryBonus(asset: PCloudAsset, match: ArtistGenreResolver.Match?): Int {
        match ?: return 0
        val haystack = normalize("${asset.name.substringBeforeLast('.')} ${asset.folderPath}")
        val exact = normalize(match.imageKeyword)
        if (exact.isNotBlank() && haystack.containsPhrase(exact)) return 120
        val secondaryHit = match.positiveKeywords
            .asSequence()
            .map(::normalize)
            .filter { it.isNotBlank() && it != exact }
            .any { haystack.containsPhrase(it) }
        return if (secondaryHit) 28 else 0
    }

    private fun terms(value: String, minimum: Int): Set<String> = value.split(' ')
        .filter { it.length >= minimum && it !in stopWords }
        .toSet()

    private fun normalize(value: String): String = Normalizer.normalize(value, Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "")
        .lowercase()
        .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
        .trim()
        .replace(Regex("\\s+"), " ")

    private fun String.containsPhrase(value: String): Boolean {
        if (value.isBlank()) return false
        return this == value || startsWith("$value ") || endsWith(" $value") || contains(" $value ")
    }

    private const val MIN_STRICT_CATEGORY_IMAGES = 4

    private val stopWords = setOf(
        "para", "como", "mais", "muito", "uma", "com", "sem", "que", "this", "that", "with",
        "from", "your", "have", "will", "when", "onde", "porque", "sobre", "entre", "cada", "meu",
        "minha", "voce", "você", "amor", "music", "musica", "música"
    )

    // Only for explicit Gallery text search. Short connectors are ignored so users can type a
    // natural title while files may use underscores, dashes or omit/add connectors.
    private val searchStopWords = setOf(
        "a", "o", "as", "os", "de", "da", "do", "das", "dos", "e", "em", "na", "no", "nas", "nos",
        "the", "a", "an", "of", "and", "in", "on"
    )
}

data class ImageCooldownAvailability(
    val totalCatalogCount: Int,
    val availableCount: Int,
    val blockedCount: Int,
    val releasedCount: Int,
    val historyVideoCount: Int,
    val blockedKeys: Set<String>,
)

/** FIFO storage planner. Empty projects are kept in the window even when they used only local media. */
object ImageProjectHistoryPlanner {
    private const val EMPTY_PROJECT_MARKER = "__SONUS_EMPTY_PROJECT__"

    fun append(historyNewestFirst: List<List<String>>, selectedKeys: Collection<String>, limit: Int): List<List<String>> {
        val project = selectedKeys.filter { it.isNotBlank() }.distinct()
        return (listOf(project) + historyNewestFirst).take(limit.coerceAtLeast(1))
    }

    fun encode(historyNewestFirst: List<List<String>>): String = historyNewestFirst.joinToString("\n") { row ->
        if (row.isEmpty()) EMPTY_PROJECT_MARKER else row.joinToString("|")
    }

    fun decode(serialized: String, limit: Int): List<List<String>> = serialized.split('\n')
        .filter { it.isNotBlank() }
        .map { row -> if (row == EMPTY_PROJECT_MARKER) emptyList() else row.split('|').filter { it.isNotBlank() } }
        .take(limit.coerceAtLeast(0))
}

/** Pure cooldown policy shared by the Android store and unit tests. History order is newest first. */
object ImageCooldownPlanner {
    const val MAX_FRESH_BEFORE_RELEASE = 10

    fun calculate(
        assetKeys: Set<String>,
        historyNewestFirst: List<List<String>>,
        requiredCount: Int,
    ): ImageCooldownAvailability {
        val originallyBlocked = historyNewestFirst.flatten().toSet().intersect(assetKeys)
        val freshCount = (assetKeys - originallyBlocked).size
        // A large query (11+ fresh assets) never recycles protected media, even if the project
        // needs more images. Only a truly small query can release enough oldest entries to fill it.
        val shortage = if (freshCount <= MAX_FRESH_BEFORE_RELEASE) {
            (requiredCount.coerceAtLeast(0) - freshCount).coerceAtLeast(0)
        } else 0
        val releaseOrder = historyNewestFirst.asReversed().asSequence()
            .flatMap { it.asSequence() }
            .filter { it in originallyBlocked }
            .distinct()
            .take(shortage)
            .toSet()
        val blockedKeys = originallyBlocked - releaseOrder
        return ImageCooldownAvailability(
            totalCatalogCount = assetKeys.size,
            availableCount = (assetKeys.size - blockedKeys.size).coerceAtLeast(0),
            blockedCount = blockedKeys.size,
            releasedCount = releaseOrder.size,
            historyVideoCount = historyNewestFirst.size,
            blockedKeys = blockedKeys,
        )
    }
}

class ImageSelectionHistoryStore(context: Context) {
    private val prefs = context.getSharedPreferences("sonus_edit_image_history", Context.MODE_PRIVATE)

    fun recent(trackKey: String): Set<String> = prefs.getStringSet(key(trackKey), emptySet()).orEmpty()

    /** Image cooldown is isolated by the selected project aspect ratio. */
    fun availability(
        assets: List<PCloudAsset>,
        requiredCount: Int,
        aspectRatio: String,
        enabled: Boolean = true,
    ): ImageCooldownAvailability {
        if (!enabled) return ImageCooldownAvailability(assets.size, assets.size, 0, 0, 0, emptySet())
        val horizontal = com.sonusstudios.sonusedit.create.ProjectAspectRatios.isHorizontal(aspectRatio)
        val history = readProjectHistory(horizontal)
        return ImageCooldownPlanner.calculate(assets.map { it.stableKey }.toSet(), history, requiredCount)
    }

    /** Stable keys in the active FIFO, newest project first. Intended for a read-only settings view. */
    fun projectHistory(aspectRatio: String): List<List<String>> =
        readProjectHistory(com.sonusstudios.sonusedit.create.ProjectAspectRatios.isHorizontal(aspectRatio))

    /** Every selected asset key still inside the format-specific protection window. */
    fun blockedKeys(aspectRatio: String): Set<String> = projectHistory(aspectRatio).flatten().toSet()

    /** Monotonic revision used by the Compose gallery to refresh after returning from export. */
    fun revision(aspectRatio: String): Long {
        val horizontal = com.sonusstudios.sonusedit.create.ProjectAspectRatios.isHorizontal(aspectRatio)
        return prefs.getLong(if (horizontal) HORIZONTAL_REVISION_KEY else VERTICAL_REVISION_KEY, 0L)
    }

    /** Record only after a successful export; each aspect ratio has its own project window. */
    fun recordProjectKeys(selectedKeys: Collection<String>, aspectRatio: String) {
        val keys = selectedKeys.filter { it.isNotBlank() }.distinct()
        val horizontal = com.sonusstudios.sonusedit.create.ProjectAspectRatios.isHorizontal(aspectRatio)
        val limit = if (horizontal) HORIZONTAL_PROJECTS_TO_BLOCK else VERTICAL_PROJECTS_TO_BLOCK
        val historyKey = if (horizontal) HORIZONTAL_PROJECT_HISTORY_KEY else VERTICAL_PROJECT_HISTORY_KEY
        // Every successfully exported project advances its format FIFO, including a project made
        // only with local media. Otherwise the protection window counts remote-media projects,
        // not videos, and old pCloud assets stay blocked for longer than the user configured.
        val merged = ImageProjectHistoryPlanner.append(readProjectHistory(horizontal), keys, limit)
        val revisionKey = if (horizontal) HORIZONTAL_REVISION_KEY else VERTICAL_REVISION_KEY
        prefs.edit()
            .putString(historyKey, ImageProjectHistoryPlanner.encode(merged))
            .putLong(revisionKey, System.currentTimeMillis())
            .apply()
    }

    fun record(trackKey: String, selected: List<PCloudAsset>) {
        if (trackKey.isBlank() || selected.isEmpty()) return
        val previous = recent(trackKey).toList()
        val merged = (selected.map { it.stableKey } + previous).distinct().take(maxOf(16, selected.size * 3))
        prefs.edit().putStringSet(key(trackKey), merged.toSet()).apply()
    }

    private fun readProjectHistory(horizontal: Boolean): List<List<String>> {
        val historyKey = if (horizontal) HORIZONTAL_PROJECT_HISTORY_KEY else VERTICAL_PROJECT_HISTORY_KEY
        val limit = if (horizontal) HORIZONTAL_PROJECTS_TO_BLOCK else VERTICAL_PROJECTS_TO_BLOCK
        return ImageProjectHistoryPlanner.decode(prefs.getString(historyKey, "").orEmpty(), limit)
    }

    private fun key(trackKey: String): String = "track_${trackKey.hashCode()}"

    private companion object {
        const val VERTICAL_PROJECT_HISTORY_KEY = "recent_project_image_keys_vertical_v2"
        const val HORIZONTAL_PROJECT_HISTORY_KEY = "recent_project_image_keys_horizontal_v2"
        const val VERTICAL_PROJECTS_TO_BLOCK = 20
        const val HORIZONTAL_PROJECTS_TO_BLOCK = 15
        const val VERTICAL_REVISION_KEY = "recent_project_image_revision_vertical_v2"
        const val HORIZONTAL_REVISION_KEY = "recent_project_image_revision_horizontal_v2"
    }
}
