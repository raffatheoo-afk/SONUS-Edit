package com.sonusstudios.sonusedit.create

/** Distinguishes untouched auto-filled metadata from a field intentionally cleared by the user. */
object ExportMetadataPolicy {
    fun resolveTitle(value: String, fallback: String, manuallyEdited: Boolean): String =
        if (manuallyEdited) value else value.ifBlank { fallback }

    fun resolveArtist(value: String, fallback: String?, manuallyEdited: Boolean): String =
        if (manuallyEdited) value else value.ifBlank { fallback.orEmpty() }
}
