package com.sonusstudios.sonusedit.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

/** Clean scalable SONUS crown vector, not an emoji/font glyph. */
@Composable
fun PremiumCrownIcon(modifier: Modifier = Modifier) {
    Canvas(modifier.size(29.dp)) {
        val w = size.width
        val h = size.height
        val path = Path().apply {
            moveTo(.12f * w, .32f * h)
            lineTo(.29f * w, .65f * h)
            lineTo(.50f * w, .23f * h)
            lineTo(.71f * w, .65f * h)
            lineTo(.89f * w, .32f * h)
            lineTo(.82f * w, .78f * h)
            lineTo(.18f * w, .78f * h)
            close()
        }
        drawPath(path, Color(0xFFFFC94A))
        drawLine(Color(0xFFFFE28D), Offset(.20f * w, .83f * h), Offset(.80f * w, .83f * h),
            strokeWidth = w * .07f, cap = StrokeCap.Round)
    }
}
