package com.sonusstudios.sonusedit.create

import android.content.Context
import android.util.AtomicFile
import java.io.File
import java.io.FileOutputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@Serializable
data class CreationDraftSnapshot(
    val stepOrdinal: Int = 0,
    val audioUri: String? = null,
    val audioTitle: String = "",
    val audioArtist: String? = null,
    val audioAlbum: String? = null,
    val audioDurationMs: Long = 0L,
    val audioSource: AudioSource = AudioSource.LOCAL,
    val sourceTrackId: String? = null,
    val sourcePublicCode: String? = null,
    val sourceGenre: String? = null,
    val selectedLinkUrl: String? = null,
    val pendingLinkText: String = "",
    val linkProviderLabel: String? = null,
    val linkThumbnailUrl: String? = null,
    val durationSeconds: Int = 30,
    val durationUntilEnd: Boolean = false,
    val segmentStartMs: Long = 0L,
    val manualEndMs: Long? = null,
    val aspectRatio: String = ProjectAspectRatios.VERTICAL,
    val imageUris: List<String> = emptyList(),
    val localVideoUris: List<String> = emptyList(),
    val selectedRemoteIds: List<Long> = emptyList(),
    /** Legacy fileId-only URL map retained for drafts created before CODE 14. */
    val remoteImageUrls: Map<Long, String> = emptyMap(),
    /** Stable sourcePublicCode:fileId -> resolved URL mapping; authoritative for new drafts. */
    val remoteImageStableUrls: Map<String, String> = emptyMap(),
    /** Stable sourcePublicCode:fileId keys captured at the exact moment a remote asset is selected. */
    val selectedRemoteStableKeys: List<String> = emptyList(),
    /** Per-media transition families resolved once for this project and reused on resume/export. */
    val visualTransitionIds: List<String> = emptyList(),
    /** Four-family maximum selected once for this project; RANDOM keeps this pool across resume. */
    val visualTransitionPoolIds: List<String> = emptyList(),
    /** Stable keys retained when a draft is resumed before the pCloud catalog refresh finishes. */
    val imageHistoryKeys: List<String> = emptyList(),
    val fontPreset: FontPresetId = FontPresetId.DEFAULT,
    val lyricColorPreset: LyricColorPreset = LyricColorPreset.DYNAMIC,
    val filterPreset: FilterPresetId = FilterPresetId.ORIGINAL,
    val automaticEffectId: String = "raw_green_60",
    val particlesEnabled: Boolean = true,
    val captionSegments: List<CaptionSegment> = emptyList(),
    val captionCompleted: Boolean = false,
    /** Per-project export switch; null preserves the global preference for older drafts. */
    val captionsEnabledForVideo: Boolean? = null,
    val captionStyle: CaptionStyleId = CaptionStyleId.CLASSIC,
    val captionSizeScale: Float = 1f,
    val captionPositionPercent: Float = 0.52f,
    val exportTitle: String = "",
    val exportArtist: String = "",
    /** Backward-compatible flags: false means legacy/unmodified auto-fill behavior. */
    val exportTitleManuallyEdited: Boolean = false,
    val exportArtistManuallyEdited: Boolean = false,
    val exportResolution: ExportResolution = ExportResolution.P1080,
    val exportFps: Int = 60,
    val sessionStartedEpochMs: Long = System.currentTimeMillis(),
    val editingStartedEpochMs: Long? = null,
    val manualWorkMs: Long = 0L,
    val automaticWorkMs: Long = 0L,
)

/**
 * Stores the latest creation state with AtomicFile so an interrupted write cannot destroy the
 * last good draft. A process-wide lock serializes writers created by separate Compose screens.
 */
class CreationDraftStore(context: Context) {
    private val atomicFile = AtomicFile(
        File(context.applicationContext.filesDir, "sonus_last_creation_draft.json")
    )
    private val json = Json { ignoreUnknownKeys = true }

    suspend fun save(value: CreationDraftSnapshot) = withContext(Dispatchers.IO) {
        val encoded = json.encodeToString(value)
        synchronized(FILE_LOCK) {
            var output: FileOutputStream? = null
            try {
                val stream = atomicFile.startWrite()
                output = stream
                stream.write(encoded.toByteArray(Charsets.UTF_8))
                stream.fd.sync()
                atomicFile.finishWrite(stream)
                output = null
            } catch (error: Throwable) {
                output?.let { runCatching { atomicFile.failWrite(it) } }
                throw error
            }
        }
    }

    suspend fun load(): CreationDraftSnapshot? = withContext(Dispatchers.IO) {
        synchronized(FILE_LOCK) {
            runCatching {
                atomicFile.openRead().bufferedReader(Charsets.UTF_8).use { reader ->
                    json.decodeFromString<CreationDraftSnapshot>(reader.readText())
                }
            }.getOrNull()
        }
    }

    suspend fun clear() = withContext(Dispatchers.IO) {
        synchronized(FILE_LOCK) { atomicFile.delete() }
    }

    fun exists(): Boolean = synchronized(FILE_LOCK) {
        val base = atomicFile.baseFile
        base.exists() && base.length() > 0L ||
            File(base.parentFile, base.name + ".bak").let { it.exists() && it.length() > 0L }
    }

    private companion object {
        private val FILE_LOCK = Any()
    }
}
