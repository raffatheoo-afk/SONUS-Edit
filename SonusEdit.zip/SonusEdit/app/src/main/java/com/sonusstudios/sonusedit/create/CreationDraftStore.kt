package com.sonusstudios.sonusedit.create

import android.content.Context
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@Serializable
data class CreationDraftSnapshot(
    val stepOrdinal: Int = 0,
    val audioUri: String? = null,
    val audioTitle: String = "",
    val audioArtist: String? = null,
    val audioAlbum: String? = null,
    val audioDurationMs: Long = 0L,
    val audioSource: AudioSource = AudioSource.LOCAL,
    val sourceTrackId: String? = null,
    val sourcePublicCode: String? = null,
    val sourceGenre: String? = null,
    val selectedLinkUrl: String? = null,
    val pendingLinkText: String = "",
    val linkProviderLabel: String? = null,
    val linkThumbnailUrl: String? = null,
    val durationSeconds: Int = 30,
    val durationUntilEnd: Boolean = false,
    val segmentStartMs: Long = 0L,
    val manualEndMs: Long? = null,
    val aspectRatio: String = ProjectAspectRatios.VERTICAL,
    val imageUris: List<String> = emptyList(),
    val localVideoUris: List<String> = emptyList(),
    val selectedRemoteIds: List<Long> = emptyList(),
    val remoteImageUrls: Map<Long, String> = emptyMap(),
    /** Stable keys retained when a draft is resumed before the pCloud catalog refresh finishes. */
    val imageHistoryKeys: List<String> = emptyList(),
    val fontPreset: FontPresetId = FontPresetId.DEFAULT,
    val lyricColorPreset: LyricColorPreset = LyricColorPreset.DYNAMIC,
    val filterPreset: FilterPresetId = FilterPresetId.ORIGINAL,
    val automaticEffectId: String = "raw_green_60",
    val particlesEnabled: Boolean = true,
    val captionSegments: List<CaptionSegment> = emptyList(),
    val captionCompleted: Boolean = false,
    val captionStyle: CaptionStyleId = CaptionStyleId.CLASSIC,
    val captionSizeScale: Float = 1f,
    val captionPositionPercent: Float = 0.52f,
    val exportTitle: String = "",
    val exportArtist: String = "",
    val exportResolution: ExportResolution = ExportResolution.P1080,
    val exportFps: Int = 60,
    val sessionStartedEpochMs: Long = System.currentTimeMillis(),
    val editingStartedEpochMs: Long? = null,
    val manualWorkMs: Long = 0L,
    val automaticWorkMs: Long = 0L,
)

class CreationDraftStore(context: Context) {
    private val file = File(context.applicationContext.filesDir, "sonus_last_creation_draft.json")
    private val json = Json { ignoreUnknownKeys = true }

    suspend fun save(value: CreationDraftSnapshot) = withContext(Dispatchers.IO) {
        val temp = File(file.parentFile, "${file.name}.tmp")
        temp.writeText(json.encodeToString(value))
        if (file.exists()) file.delete()
        temp.renameTo(file)
    }

    suspend fun load(): CreationDraftSnapshot? = withContext(Dispatchers.IO) {
        runCatching {
            if (!file.exists()) null else json.decodeFromString<CreationDraftSnapshot>(file.readText())
        }.getOrNull()
    }

    suspend fun clear() = withContext(Dispatchers.IO) { runCatching { file.delete() } }
    fun exists(): Boolean = file.exists() && file.length() > 0L
}
