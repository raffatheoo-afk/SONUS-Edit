package com.sonusstudios.sonusedit.create

/** Prevents a slow result from an older query/ratio replacing the currently visible gallery. */
object GalleryQueryResultGate13 {
    fun canPublish(
        requestedQuery: String,
        activeQuery: String,
        requestedAspectRatio: String,
        activeAspectRatio: String,
    ): Boolean = requestedAspectRatio == activeAspectRatio &&
        requestedQuery.trim() == activeQuery.trim()
}
