package com.sonusstudios.sonusedit.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonusstudios.sonusedit.designsystem.SonusEditColors
import com.sonusstudios.sonusedit.stats.MonthlyUsageStats
import com.sonusstudios.sonusedit.stats.UsageStatsSnapshot
import com.sonusstudios.sonusedit.stats.UsageStatsStore
import java.time.YearMonth
import java.time.format.TextStyle
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch

@Composable
fun StatisticsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val store = remember { UsageStatsStore(context.applicationContext) }
    val scope = rememberCoroutineScope()
    var refreshToken by remember { mutableStateOf(0) }
    var confirmClear by remember { mutableStateOf(false) }
    val snapshot by produceState(UsageStatsSnapshot(), refreshToken) {
        value = withContext(Dispatchers.IO) { store.snapshot() }
    }
    val monthKeys = remember(snapshot) {
        (snapshot.months.keys + UsageStatsStore.currentMonthKey()).distinct().sortedDescending()
    }
    var selectedKey by remember(snapshot) { mutableStateOf(UsageStatsStore.currentMonthKey()) }
    val stats = snapshot.months[selectedKey] ?: MonthlyUsageStats(selectedKey)
    val yearMonth = runCatching { YearMonth.parse(selectedKey) }.getOrDefault(YearMonth.now())
    val monthName = yearMonth.month.getDisplayName(TextStyle.FULL, Locale("pt", "BR")).replaceFirstChar { it.uppercase() }
    val start = yearMonth.atDay(1)
    val end = yearMonth.atEndOfMonth()
    val manualEstimate = stats.estimatedManualMs
    val sonusUserTime = stats.manualEditingMs
    val saved = (manualEstimate - sonusUserTime).coerceAtLeast(0L)
    val savedPercent = if (manualEstimate > 0L) ((saved * 100L) / manualEstimate).toInt().coerceIn(0, 100) else 0
    val totalExports = stats.successfulExports + stats.failedExports + stats.cancelledExports
    val successRate = if (totalExports > 0) stats.successfulExports * 100 / totalExports else 0
    val favoriteFilter = stats.filterCounts.maxByOrNull { it.value }?.key?.let(::filterLabel18) ?: "—"
    val favoriteEffect = stats.effectCounts.maxByOrNull { it.value }?.key?.let(::effectLabel18) ?: "—"

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(SonusEditColors.Black),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar", tint = Color.White) }
                Column(Modifier.weight(1f)) {
                    Text("Estatísticas", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Produtividade local do SONUS Edit", color = SonusEditColors.TextMuted, fontSize = 10.sp)
                }
            }
        }

        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                monthKeys.take(4).forEach { key ->
                    val ym = runCatching { YearMonth.parse(key) }.getOrDefault(YearMonth.now())
                    FilterChip(
                        selected = key == selectedKey,
                        onClick = { selectedKey = key },
                        label = { Text(ym.month.getDisplayName(TextStyle.SHORT, Locale("pt", "BR")).uppercase(), fontSize = 9.sp) },
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }

        item {
            StatsCard {
                Text("$monthName ${yearMonth.year}", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                Text("${start.dayOfMonth.toString().padStart(2, '0')}/${start.monthValue.toString().padStart(2, '0')} → ${end.dayOfMonth.toString().padStart(2, '0')}/${end.monthValue.toString().padStart(2, '0')}", color = SonusEditColors.Cyan, fontSize = 10.sp)
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    BigMetric("${stats.videosCreated}", "vídeos", Modifier.weight(1f))
                    BigMetric(formatDuration(stats.producedVideoMs), "produzidos", Modifier.weight(1f))
                    BigMetric("$successRate%", "sucesso", Modifier.weight(1f))
                }
            }
        }

        item {
            Text("TEMPO E PRODUTIVIDADE", color = SonusEditColors.Cyan, fontWeight = FontWeight.Black, fontSize = 10.sp)
        }
        item {
            StatsCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    TimeMetric(Icons.Default.Person, "Seu trabalho", stats.manualEditingMs, Color(0xFF66B7FF), Modifier.weight(1f))
                    TimeMetric(Icons.Default.AutoAwesome, "SONUS automático", stats.automaticWorkMs, Color(0xFF67E69A), Modifier.weight(1f))
                }
                Spacer(Modifier.height(12.dp))
                Text("Tempo total dentro do app", color = SonusEditColors.TextMuted, fontSize = 10.sp)
                Text(formatDuration(stats.appForegroundMs), color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            }
        }

        item {
            StatsCard {
                Text("Manual × SONUS", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text("Estimativa baseada no teste manual de 30s: 4min24s.", color = SonusEditColors.TextMuted, fontSize = 9.sp)
                Spacer(Modifier.height(10.dp))
                MetricPair("Editor manual (estimado)", formatDuration(manualEstimate), "Seu tempo no SONUS", formatDuration(sonusUserTime))
                Spacer(Modifier.height(10.dp))
                LinearProgressIndicator(
                    progress = { savedPercent / 100f },
                    modifier = Modifier.fillMaxWidth().height(9.dp),
                    color = Color(0xFF67E69A),
                    trackColor = SonusEditColors.SurfaceRaised,
                )
                Spacer(Modifier.height(8.dp))
                Text("Você economizou aproximadamente ${formatDuration(saved)} • $savedPercent%", color = Color(0xFF67E69A), fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
            }
        }

        item {
            Text("O QUE O APP FEZ", color = SonusEditColors.Cyan, fontWeight = FontWeight.Black, fontSize = 10.sp)
        }
        item {
            StatsCard {
                MetricPair("Stream", stats.streamUses.toString(), "Local", stats.localUses.toString())
                MetricPair("Link", stats.linkUses.toString(), "Áudio de vídeo", stats.videoAudioUses.toString())
                MetricPair("9:16", stats.verticalProjects.toString(), "16:9", stats.horizontalProjects.toString())
                MetricPair("Com legenda automática", stats.captionedVideos.toString(), "Áudio transcrito", formatDuration(stats.captionAudioMs))
                MetricPair("Exportação média", averageExport(stats), "Vídeo mais longo", formatDuration(stats.longestVideoMs))
                MetricPair("Fotos usadas", stats.photosUsed.toString(), "Vídeos locais", stats.videosUsed.toString())
                MetricPair("Filtro favorito", favoriteFilter, "Efeito mais usado", favoriteEffect)
                MetricPair("Falhas", stats.failedExports.toString(), "Cancelamentos", stats.cancelledExports.toString())
            }
        }

        item {
            StatsCard {
                Text("Desde o início", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                MetricPair("Vídeos", snapshot.allTimeVideos.toString(), "Tempo economizado", formatDuration(snapshot.allTimeEstimatedSavedMs))
            }
        }

        item {
            Button(
                onClick = { confirmClear = true },
                modifier = Modifier.fillMaxWidth().height(46.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF5A252B)),
                shape = RoundedCornerShape(14.dp),
            ) {
                Text("🗑  Limpar dados de estatísticas", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Apagar todas as estatísticas?") },
            text = { Text("Isso zera vídeos, tempos, sucessos, fontes, legendas, estimativas e histórico mensal. Projetos, rascunhos, assinatura, favoritos e configurações não serão apagados.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmClear = false
                    scope.launch {
                        store.clearAll()
                        refreshToken++
                    }
                }) { Text("Apagar tudo", color = Color(0xFFFF6B75), fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancelar") } },
        )
    }
}

@Composable
private fun StatsCard(content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = SonusEditColors.Surface), shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), content = content)
    }
}

@Composable
private fun BigMetric(value: String, label: String, modifier: Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 21.sp, maxLines = 1)
        Text(label, color = SonusEditColors.TextMuted, fontSize = 8.sp)
    }
}

@Composable
private fun TimeMetric(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, value: Long, color: Color, modifier: Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = SonusEditColors.SurfaceRaised), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(12.dp)) {
            Icon(icon, null, tint = color)
            Spacer(Modifier.height(6.dp))
            Text(label, color = SonusEditColors.TextMuted, fontSize = 9.sp)
            Text(formatDuration(value), color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
        }
    }
}

@Composable
private fun MetricPair(leftLabel: String, leftValue: String, rightLabel: String, rightValue: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(Modifier.weight(1f)) {
            Text(leftLabel, color = SonusEditColors.TextMuted, fontSize = 9.sp)
            Text(leftValue, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
        Column(Modifier.weight(1f)) {
            Text(rightLabel, color = SonusEditColors.TextMuted, fontSize = 9.sp)
            Text(rightValue, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
    }
}

private fun filterLabel18(value: String): String = when (value) {
    "ORIGINAL" -> "Natural"
    "CINEMATIC" -> "Cinemático"
    "SUNSET" -> "HDR Natural"
    "NIGHT_CITY" -> "Preto Profundo"
    "NATURAL_PLUS" -> "Vívido Natural"
    "GOLDEN" -> "Nitidez+"
    "SOFT_CONTRAST" -> "Contraste Suave"
    "WARM_NATURAL" -> "Quente Natural"
    "COOL_NATURAL" -> "Frio Natural"
    else -> value.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() }
}

private fun effectLabel18(value: String): String = when (value) {
    "raw_green_60" -> "Original 60 FPS"
    "raw_black_30" -> "Original 30 FPS"
    "none" -> "Nenhum"
    else -> value
}

private fun averageExport(stats: MonthlyUsageStats): String =
    if (stats.successfulExports <= 0) "—" else formatDuration(stats.exportTimeMs / stats.successfulExports)

private fun formatDuration(ms: Long): String {
    if (ms <= 0L) return "0s"
    val total = ms / 1_000L
    val hours = total / 3_600L
    val minutes = (total % 3_600L) / 60L
    val seconds = total % 60L
    return when {
        hours > 0 -> "${hours}h ${minutes}min"
        minutes > 0 -> "${minutes}min ${seconds}s"
        else -> "${seconds}s"
    }
}
