package com.sonusstudios.sonusedit.catalog

import kotlinx.serialization.Serializable

object SonusPublicCatalogs {
    const val IMAGE_PUBLIC_CODE = "kZspB4JZmPJsxI5SKzQ1dgJWSicA2bQzFJhX"
    const val IMAGE_PUBLIC_CODE_SECONDARY = "kZlMPSJZIKQmTVCl6w7EgHPazyKmapmHe3cy"
    const val IMAGE_PUBLIC_CODE_TERTIARY = "kZwyCSJZUAqjAxCrE9zIvbA8MWP1rXS3YaAV"
    const val IMAGE_HORIZONTAL_PUBLIC_CODE = "kZpRVYJZCVInrVg53M8t2JVi0nyFVjrg28ik"
    const val IMAGE_HORIZONTAL_PUBLIC_CODE_SECONDARY = "kZaMPSJZNrH0Af6JWzJJhCoRVGPQULDaCRxX"
    const val MUSIC_PUBLIC_CODE_PRIMARY = "kZoiqzJZYKnSUcvcE3yhv2kogYMgtzmoSLyX"
    const val MUSIC_PUBLIC_CODE_SECONDARY = "kZjNE8JZ1u7bptnw2J7AJmDn04hFe8O3o09k"
    const val MUSIC_PUBLIC_CODE_TERTIARY = "kZ1MPSJZOx4zaPJ6YjLe5qaUy8Qw94bFfmpV"
    val MUSIC_PUBLIC_CODES = listOf(MUSIC_PUBLIC_CODE_PRIMARY, MUSIC_PUBLIC_CODE_SECONDARY, MUSIC_PUBLIC_CODE_TERTIARY)
    val IMAGE_PUBLIC_CODES = listOf(IMAGE_PUBLIC_CODE, IMAGE_PUBLIC_CODE_SECONDARY, IMAGE_PUBLIC_CODE_TERTIARY)
    val IMAGE_HORIZONTAL_PUBLIC_CODES = listOf(IMAGE_HORIZONTAL_PUBLIC_CODE, IMAGE_HORIZONTAL_PUBLIC_CODE_SECONDARY)
}

@Serializable
data class PCloudAsset(
    val fileId: Long,
    val name: String,
    val size: Long = 0,
    val contentType: String? = null,
    val folderPath: String = "",
    val modified: String? = null,
    val durationMs: Long? = null,
    val sourcePublicCode: String? = null,
) {
    val extension: String get() = name.substringAfterLast('.', "").lowercase()
    val genre: String get() = folderPath.split('/').lastOrNull { it.isNotBlank() } ?: "Outros"
    val stableKey: String get() = "${sourcePublicCode.orEmpty()}:$fileId"
}

@Serializable
data class CatalogSnapshot(
    val updatedAtMs: Long,
    val assets: List<PCloudAsset>,
)
