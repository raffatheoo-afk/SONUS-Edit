package com.sonusstudios.sonusedit.media

import android.content.Context
import kotlin.random.Random

object EffectIds {
    const val NONE = "none"
    const val BOKEH_SOFT = "bokeh_soft"
    const val FLOATING_BUBBLES = "floating_bubbles"
    const val MAGIC_GLOW = "magic_glow"
    const val TWINKLE_STARS = "twinkle_stars"
    const val DISTANT_LIGHTS = "distant_lights"
    const val LIGHT_DUST = "light_dust"
    const val ETHEREAL_WAVES = "ethereal_waves"
    const val GOLDEN_SPARKS = "golden_sparks"
    const val LIGHT_SNOW = "light_snow"
    const val MINIMAL_PARTICLES = "minimal_particles"
    const val SUBTLE_DUST = "subtle_dust"
    const val LIGHT_FRAGMENTS = "light_fragments"
    const val NEON_STARS = "neon_stars"

    val all = listOf(
        BOKEH_SOFT, FLOATING_BUBBLES, MAGIC_GLOW, TWINKLE_STARS, DISTANT_LIGHTS,
        LIGHT_DUST, ETHEREAL_WAVES, GOLDEN_SPARKS, LIGHT_SNOW, MINIMAL_PARTICLES,
        SUBTLE_DUST, LIGHT_FRAGMENTS, NEON_STARS,
    )
}

/**
 * Uses all 13 approved effects through a persistent shuffle bag.
 * No effect repeats until the current 13-effect cycle is exhausted.
 * The same project/nonce is cached so recomposition cannot consume the bag repeatedly.
 */
class AutomaticEffectSelector(context: Context) {
    private val prefs = context.getSharedPreferences("sonus_edit_effect_history", Context.MODE_PRIVATE)
    private val requestCache = mutableMapOf<String, String>()

    fun select(projectKey: String, regenerationNonce: Int = 0): String {
        val requestKey = "$projectKey|$regenerationNonce"
        requestCache[requestKey]?.let { return it }

        val signature = EffectIds.all.joinToString("|")
        var bag = if (prefs.getString("bag_signature", null) == signature) {
            prefs.getString("effect_bag", "").orEmpty()
                .split('|').filter { it in EffectIds.all }.toMutableList()
        } else mutableListOf()

        if (bag.isEmpty()) {
            val seed = System.nanoTime() xor projectKey.hashCode().toLong() xor regenerationNonce.toLong().shl(19)
            bag = EffectIds.all.shuffled(Random(seed)).toMutableList()
            val last = prefs.getString("last_effect", null)
            if (bag.size > 1 && bag.firstOrNull() == last) {
                val first = bag[0]
                bag[0] = bag[1]
                bag[1] = first
            }
        }

        val chosen = bag.removeAt(0)
        prefs.edit()
            .putString("bag_signature", signature)
            .putString("effect_bag", bag.joinToString("|"))
            .putString("last_effect", chosen)
            .apply()
        requestCache[requestKey] = chosen
        return chosen
    }
}
