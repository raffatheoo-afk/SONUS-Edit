package com.sonusstudios.sonusedit.media

import android.content.Context
import kotlin.random.Random

/**
 * code11 uses one approved transparent 9:16 particle source and derives visual styles from it.
 * The ids below are render variations, not separate effect assets.
 */
object EffectIds {
    const val NONE = "none"
    const val RAINBOW = "particles_rainbow"
    const val BRIGHT = "particles_bright"
    const val FIREFLY = "particles_firefly"
    const val STAR = "particles_star"
    const val GLITTER = "particles_glitter"

    val all = listOf(RAINBOW, BRIGHT, FIREFLY, STAR, GLITTER)
}

/**
 * Dynamic mode rotates all five code11 particle styles through a persistent shuffle bag.
 * A style does not repeat until the current cycle is exhausted, and recomposition for the
 * same project/nonce never consumes the bag twice.
 */
class AutomaticEffectSelector(context: Context) {
    private val prefs = context.getSharedPreferences("sonus_edit_particle_history", Context.MODE_PRIVATE)
    private val requestCache = mutableMapOf<String, String>()

    fun select(projectKey: String, regenerationNonce: Int = 0): String {
        val requestKey = "$projectKey|$regenerationNonce"
        requestCache[requestKey]?.let { return it }

        val signature = EffectIds.all.joinToString("|")
        var bag = if (prefs.getString("bag_signature", null) == signature) {
            prefs.getString("effect_bag", "").orEmpty()
                .split('|').filter { it in EffectIds.all }.toMutableList()
        } else mutableListOf()

        if (bag.isEmpty()) {
            val seed = System.nanoTime() xor projectKey.hashCode().toLong() xor regenerationNonce.toLong().shl(19)
            bag = EffectIds.all.shuffled(Random(seed)).toMutableList()
            val last = prefs.getString("last_effect", null)
            if (bag.size > 1 && bag.firstOrNull() == last) {
                val first = bag[0]
                bag[0] = bag[1]
                bag[1] = first
            }
        }

        val chosen = bag.removeAt(0)
        prefs.edit()
            .putString("bag_signature", signature)
            .putString("effect_bag", bag.joinToString("|"))
            .putString("last_effect", chosen)
            .apply()
        requestCache[requestKey] = chosen
        return chosen
    }
}
