package com.sonusstudios.sonusedit.media

import android.content.Context
import kotlin.random.Random

/** Built-in code14 effects remain as the offline fallback for the cloud catalogue. */
object EffectIds {
    const val NONE = "none"
    const val RAW_GREEN_60 = "raw_green_60"
    const val RAW_BLACK_30 = "raw_black_30"

    val all = listOf(RAW_GREEN_60, RAW_BLACK_30)
}

/**
 * Dynamic mode alternates the two raw sources through a persistent shuffle bag.
 * They are never mixed together in the same export.
 */
class AutomaticEffectSelector(context: Context) {
    private val prefs = context.getSharedPreferences("sonus_edit_raw_effect_history", Context.MODE_PRIVATE)
    private val requestCache = mutableMapOf<String, String>()

    fun select(projectKey: String, regenerationNonce: Int = 0, remoteEffectIds: List<String> = emptyList()): String {
        val pool = (EffectIds.all + remoteEffectIds.filter(PCloudEffectLibrary::isCloud)).distinct()
        val signature = pool.joinToString("|")
        val requestKey = "$projectKey|$regenerationNonce|$signature"
        requestCache[requestKey]?.let { return it }

        var bag = if (prefs.getString("bag_signature", null) == signature) {
            prefs.getString("effect_bag", "").orEmpty()
                .split('|').filter { it in pool }.toMutableList()
        } else mutableListOf()

        if (bag.isEmpty()) {
            val seed = System.nanoTime() xor projectKey.hashCode().toLong() xor regenerationNonce.toLong().shl(19)
            bag = pool.shuffled(Random(seed)).toMutableList()
            val last = prefs.getString("last_effect", null)
            if (bag.size > 1 && bag.firstOrNull() == last) {
                val first = bag[0]
                bag[0] = bag[1]
                bag[1] = first
            }
        }

        val chosen = bag.removeAt(0)
        prefs.edit()
            .putString("bag_signature", signature)
            .putString("effect_bag", bag.joinToString("|"))
            .putString("last_effect", chosen)
            .apply()
        requestCache[requestKey] = chosen
        return chosen
    }
}
