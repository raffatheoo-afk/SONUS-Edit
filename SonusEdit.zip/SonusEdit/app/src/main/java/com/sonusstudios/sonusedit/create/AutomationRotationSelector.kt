package com.sonusstudios.sonusedit.create

import android.content.Context
import kotlin.random.Random

/**
 * Persistent shuffle bags for user favorites.
 * Each option is used once before the bag is rebuilt, so favorites genuinely rotate.
 * Repeated recompositions for the same project/nonce reuse the same choice.
 */
class AutomationRotationSelector(context: Context) {
    private val prefs = context.getSharedPreferences("sonus_edit_favorite_rotation", Context.MODE_PRIVATE)
    private val requestCache = mutableMapOf<String, String>()

    fun selectFilter(projectKey: String, nonce: Int, favorites: Set<FilterPresetId>): FilterPresetId? =
        select(
            kind = "filter",
            requestKey = "$projectKey|$nonce",
            options = favorites.map { it.name },
        )?.let { runCatching { FilterPresetId.valueOf(it) }.getOrNull() }

    fun selectFont(projectKey: String, nonce: Int, favorites: Set<FontPresetId>): FontPresetId? =
        select(
            kind = "font",
            requestKey = "$projectKey|$nonce",
            options = favorites.map { it.name },
        )?.let { runCatching { FontPresetId.valueOf(it) }.getOrNull() }

    private fun select(kind: String, requestKey: String, options: List<String>): String? {
        val normalized = options.distinct().sorted()
        if (normalized.isEmpty()) return null
        val cacheKey = "$kind|$requestKey|${normalized.joinToString(",")}" 
        requestCache[cacheKey]?.let { return it }

        val signature = normalized.joinToString("|")
        val storedSignature = prefs.getString("${kind}_signature", null)
        var bag = if (storedSignature == signature) {
            prefs.getString("${kind}_bag", "").orEmpty()
                .split('|').filter { it in normalized }.toMutableList()
        } else mutableListOf()

        if (bag.isEmpty()) {
            val seed = System.nanoTime() xor signature.hashCode().toLong()
            bag = normalized.shuffled(Random(seed)).toMutableList()
            val last = prefs.getString("${kind}_last", null)
            if (bag.size > 1 && bag.firstOrNull() == last) {
                val first = bag[0]
                bag[0] = bag[1]
                bag[1] = first
            }
        }

        val chosen = bag.removeAt(0)
        prefs.edit()
            .putString("${kind}_signature", signature)
            .putString("${kind}_bag", bag.joinToString("|"))
            .putString("${kind}_last", chosen)
            .apply()
        requestCache[cacheKey] = chosen
        return chosen
    }
}
