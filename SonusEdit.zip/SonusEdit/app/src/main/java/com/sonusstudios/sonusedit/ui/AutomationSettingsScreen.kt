package com.sonusstudios.sonusedit.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.FilterVintage
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VideoSettings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Text
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonusstudios.sonusedit.create.AutomationPreferences
import com.sonusstudios.sonusedit.create.EditPreferences
import com.sonusstudios.sonusedit.create.SavedEditPreferences
import com.sonusstudios.sonusedit.create.SignatureColorPreset
import com.sonusstudios.sonusedit.create.SignatureFontPreset
import com.sonusstudios.sonusedit.create.UriPermissionHelper
import com.sonusstudios.sonusedit.create.AutomationSettings
import com.sonusstudios.sonusedit.create.CaptionStyleId
import com.sonusstudios.sonusedit.create.EffectIntensity
import com.sonusstudios.sonusedit.create.ExportResolution
import com.sonusstudios.sonusedit.create.ImageQuantityMode
import com.sonusstudios.sonusedit.create.ParticleStyle
import com.sonusstudios.sonusedit.designsystem.SonusEditColors
import kotlinx.coroutines.launch

private val AutomationGreen = Color(0xFF2BEA76)
private val AutomationGreenDark = Color(0xFF123C27)

@Composable
fun AutomationSettingsScreen(onBack: () -> Unit, onAbout: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { AutomationPreferences(context.applicationContext) }
    val current by prefs.values.collectAsState(initial = AutomationSettings())
    val editPreferences = remember { EditPreferences(context.applicationContext) }
    val savedEdit by editPreferences.values.collectAsState(initial = SavedEditPreferences())
    val scope = rememberCoroutineScope()
    var signatureText by remember(savedEdit.signatureText) { mutableStateOf(savedEdit.signatureText) }
    var signaturePhoto by remember(savedEdit.signaturePhotoUri) { mutableStateOf(savedEdit.signaturePhotoUri) }
    var signatureFont by remember(savedEdit.signatureFontPreset) { mutableStateOf(savedEdit.signatureFontPreset) }
    var signatureColor by remember(savedEdit.signatureColorPreset) { mutableStateOf(savedEdit.signatureColorPreset) }
    val signaturePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            UriPermissionHelper.persistRead(context, it)
            signaturePhoto = it.toString()
            scope.launch { editPreferences.saveSignature(signatureText, signaturePhoto, signatureFont, signatureColor) }
        }
    }

    fun saveSignature() {
        scope.launch { editPreferences.saveSignature(signatureText, signaturePhoto, signatureFont, signatureColor) }
    }

    fun update(block: (AutomationSettings) -> AutomationSettings) {
        scope.launch { prefs.save(block(current)) }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(SonusEditColors.Black),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF101B2C)),
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, Color(0xFF31516F)),
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar", tint = Color.White)
                    }
                    Column(Modifier.weight(1f)) {
                        Text("Ajustes", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                        Text("Sua central de preferências", color = SonusEditColors.TextMuted, fontSize = 11.sp)
                    }
                    Box(
                        Modifier.size(42.dp).background(AutomationGreenDark, CircleShape),
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Default.Tune, contentDescription = null, tint = AutomationGreen, modifier = Modifier.size(22.dp)) }
                }
            }
        }
        item {
            Card(
                modifier = Modifier.fillMaxWidth().clickable(onClick = onAbout),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF14283B)),
                shape = RoundedCornerShape(18.dp),
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 15.dp, vertical = 13.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Default.Info, null, tint = SonusEditColors.Cyan, modifier = Modifier.size(23.dp))
                    Column(Modifier.weight(1f).padding(start = 11.dp)) {
                        Text("Sobre o Sonus Edit", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("Versão, novidades e melhorias", color = SonusEditColors.TextMuted, fontSize = 9.sp)
                    }
                    Text("ABRIR  ›", color = SonusEditColors.Cyan, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
                }
            }
        }

        item { GroupTitle("Assinatura") }
        item {
            SettingsCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Assinatura do usuário", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Fica salva e é aplicada automaticamente aos próximos vídeos.", color = SonusEditColors.TextMuted, fontSize = 9.sp)
                    }
                    IconButton(onClick = { signaturePicker.launch(arrayOf("image/*")) }) {
                        Icon(Icons.Default.AddPhotoAlternate, "Selecionar imagem", tint = SonusEditColors.Cyan)
                    }
                }
                Text("Fonte da assinatura", color = SonusEditColors.TextMuted, fontSize = 9.sp)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    SignatureFontPreset.entries.forEach { preset ->
                        val selected = signatureFont == preset
                        Button(
                            onClick = { signatureFont = preset; saveSignature() },
                            modifier = Modifier.weight(1f).height(38.dp),
                            shape = RoundedCornerShape(11.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp, vertical = 0.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = if (selected) Color(0xFF1E6282) else SonusEditColors.SurfaceRaised),
                            border = BorderStroke(if (selected) 2.dp else 1.dp, if (selected) SonusEditColors.Cyan else Color(0xFF4B5365)),
                        ) {
                            Text(preset.label, fontWeight = FontWeight.Bold, fontSize = 7.sp, maxLines = 1)
                        }
                    }
                }
                Spacer(Modifier.height(4.dp))
                OutlinedTextField(
                    value = signatureText,
                    onValueChange = { signatureText = it; saveSignature() },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Nome / usuário") },
                    singleLine = true,
                )
                if (!signaturePhoto.isNullOrBlank()) {
                    Text("Imagem PNG selecionada • tocar no ícone para trocar", color = SonusEditColors.Cyan, fontSize = 9.sp)
                }
                Spacer(Modifier.height(5.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    SignatureColorPreset.entries.forEach { preset ->
                        val preview = when (preset) {
                            SignatureColorPreset.WHITE -> Color.White
                            SignatureColorPreset.YELLOW -> Color(0xFFFFE040)
                            SignatureColorPreset.BLACK -> Color(0xFF151515)
                        }
                        val selected = signatureColor == preset
                        Button(
                            onClick = { signatureColor = preset; saveSignature() },
                            modifier = Modifier.weight(1f).height(31.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(2.dp),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = preview),
                            border = androidx.compose.foundation.BorderStroke(if (selected) 2.dp else 1.dp, if (selected) SonusEditColors.Cyan else Color.Gray),
                        ) {
                            Text(preset.label, color = if (preset == SignatureColorPreset.BLACK) Color.White else Color.Black, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        item { GroupTitle("Música") }
        item {
            SettingsCard {
                ToggleSetting(
                    icon = { Icon(Icons.Default.MusicNote, null, tint = SonusEditColors.Cyan) },
                    title = "Smart Start automático",
                    subtitle = "Encontra rapidamente um bom ponto de entrada.",
                    checked = current.smartStart,
                    enabled = true,
                ) { value -> update { it.copy(smartStart = value) } }
                DividerSpace()
                ToggleSetting(
                    icon = { Icon(Icons.Default.Subtitles, null, tint = AutomationGreen) },
                    title = "Legenda automática",
                    subtitle = "Controle independente. Desativada, o Whisper não carrega nem bloqueia o avanço.",
                    checked = current.automaticLyrics,
                    enabled = true,
                ) { value -> update { it.copy(automaticLyrics = value) } }
                ChoiceGrid(
                    title = "Estilo da legenda",
                    enabled = true,
                    entries = CaptionStyleId.entries.map { it.label to ((current.preferredCaptionStyle ?: CaptionStyleId.CLASSIC) == it) },
                    columns = 3,
                ) { index ->
                    update { it.copy(preferredCaptionStyle = CaptionStyleId.entries[index]) }
                }
            }
        }

        item { GroupTitle("Visual") }
        item {
            SettingsCard {
                ToggleSetting(
                    icon = { Icon(Icons.Default.FilterVintage, null, tint = Color(0xFFFF6FB1)) },
                    title = "Partículas",
                    subtitle = "Usa um dos dois vídeos originais sem atlas ou mistura; no 16:9 o overlay é encaixado sem deformar.",
                    checked = current.automaticEffects,
                    enabled = true,
                ) { value -> update { it.copy(automaticEffects = value) } }
                ChoiceGrid(
                    title = "Estilo",
                    enabled = current.automaticEffects,
                    entries = ParticleStyle.entries.map { style ->
                        style.label to (current.particleStyle == style)
                    },
                    columns = 3,
                ) { index -> update { it.copy(particleStyle = ParticleStyle.entries[index]) } }
                ChoiceRow(
                    title = "Intensidade",
                    enabled = current.automaticEffects,
                    entries = EffectIntensity.entries.map { it.label to (current.effectIntensity == it) },
                ) { index -> update { it.copy(effectIntensity = EffectIntensity.entries[index]) } }
                DividerSpace()
                ToggleSetting(
                    icon = { Icon(Icons.Default.Image, null, tint = SonusEditColors.Cyan) },
                    title = "Sugestão automática de imagens",
                    subtitle = "Usa título, gênero e contexto para montar a seleção.",
                    checked = current.automaticImages,
                    enabled = true,
                ) { value -> update { it.copy(automaticImages = value) } }
                ChoiceRow(
                    title = "Quantidade",
                    enabled = current.automaticImages,
                    entries = ImageQuantityMode.entries.map { it.label to (current.imageQuantity == it) },
                ) { index -> update { it.copy(imageQuantity = ImageQuantityMode.entries[index]) } }
                DividerSpace()
                ToggleSetting(
                    icon = { Icon(Icons.Default.Tune, null, tint = Color(0xFFB69AFF)) },
                    title = "Filtros dinâmicos",
                    subtitle = "Escolhe automaticamente entre os filtros disponíveis; Preto e Branco fica fora da seleção automática.",
                    checked = current.automaticFilter,
                    enabled = true,
                ) { value -> update { it.copy(automaticFilter = value) } }
                DividerSpace()
                ToggleSetting(
                    icon = { Icon(Icons.Default.VideoSettings, null, tint = Color(0xFFFFD54F)) },
                    title = "Metadados no vídeo",
                    subtitle = "Mostra nome da música e artista no rodapé do vídeo.",
                    checked = current.metadataOnVideo,
                    enabled = true,
                ) { value -> update { it.copy(metadataOnVideo = value) } }
            }
        }

        item { GroupTitle("Inteligência") }
        item {
            SettingsCard {
                ToggleSetting(
                    icon = { Icon(Icons.Default.Image, null, tint = SonusEditColors.Cyan) },
                    title = "Bloquear imagens recentes",
                    subtitle = "Evita repetir imagens. Histórico separado: 20 projetos 9:16 e 15 projetos 16:9.",
                    checked = current.blockRecentImages,
                    enabled = true,
                ) { value -> update { it.copy(blockRecentImages = value) } }
            }
        }

        item { GroupTitle("Exportação") }
        item {
            SettingsCard {
                Text("Qualidade padrão", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(Modifier.height(6.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    ExportResolution.entries.forEach { resolution ->
                        val selected = current.defaultResolution == resolution
                        FilterChip(
                            selected = selected,
                            onClick = { update { it.copy(defaultResolution = resolution) } },
                            label = { Text(resolution.label, fontSize = 10.sp) },
                            enabled = true,
                            modifier = Modifier.weight(1f),
                            colors = automationChipColors(),
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("FPS padrão", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(Modifier.height(6.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    listOf(30, 60).forEach { fps ->
                        FilterChip(
                            selected = current.defaultFps == fps,
                            onClick = { update { it.copy(defaultFps = fps) } },
                            label = { Text("$fps", fontSize = 10.sp) },
                            enabled = true,
                            modifier = Modifier.weight(1f),
                            colors = automationChipColors(),
                        )
                    }
                }
            }
        }

        item {
            Button(
                onClick = { scope.launch { prefs.restoreDefaults() } },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = SonusEditColors.SurfaceRaised, contentColor = Color.White),
                shape = RoundedCornerShape(16.dp),
            ) {
                Icon(Icons.Default.Refresh, null)
                Spacer(Modifier.width(8.dp))
                Text("Restaurar automação padrão")
            }
        }

    }
}

@Composable
private fun GroupTitle(title: String) {
    Row(
        Modifier.padding(start = 3.dp, top = 5.dp)
            .background(Color(0xFF17334A), RoundedCornerShape(10.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(5.dp).background(SonusEditColors.Cyan, CircleShape))
        Spacer(Modifier.width(7.dp))
        Text(title.uppercase(), color = SonusEditColors.Cyan, fontWeight = FontWeight.Black, fontSize = 9.sp)
    }
}

@Composable
private fun SettingsCard(content: @Composable () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF111B2B)),
        border = BorderStroke(1.dp, Color(0xFF294763)),
        shape = RoundedCornerShape(22.dp),
    ) {
        Column(Modifier.fillMaxWidth().padding(15.dp)) { content() }
    }
}

@Composable
private fun ToggleSetting(
    icon: @Composable () -> Unit,
    title: String,
    subtitle: String,
    checked: Boolean,
    enabled: Boolean,
    onChange: (Boolean) -> Unit,
) {
    Row(
        Modifier.fillMaxWidth().clickable(enabled = enabled) { onChange(!checked) },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        icon()
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = if (enabled) Color.White else SonusEditColors.TextMuted, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(subtitle, color = SonusEditColors.TextMuted, fontSize = 9.sp, lineHeight = 12.sp)
        }
        Spacer(Modifier.width(8.dp))
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled, colors = automationSwitchColors())
    }
}

@Composable
private fun ChoiceRow(title: String, enabled: Boolean, entries: List<Pair<String, Boolean>>, onSelect: (Int) -> Unit) {
    Spacer(Modifier.height(8.dp))
    Text(title, color = SonusEditColors.TextMuted, fontSize = 9.sp)
    Spacer(Modifier.height(4.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        entries.forEachIndexed { index, (label, selected) ->
            FilterChip(
                selected = selected,
                onClick = { onSelect(index) },
                label = { Text(label, fontSize = 9.sp, maxLines = 1) },
                enabled = enabled,
                modifier = Modifier.weight(1f),
                colors = automationChipColors(),
            )
        }
    }
}


@Composable
private fun ChoiceGrid(
    title: String,
    enabled: Boolean,
    entries: List<Pair<String, Boolean>>,
    columns: Int,
    onSelect: (Int) -> Unit,
) {
    Spacer(Modifier.height(8.dp))
    Text(title, color = SonusEditColors.TextMuted, fontSize = 9.sp)
    Spacer(Modifier.height(4.dp))
    entries.chunked(columns).forEachIndexed { rowIndex, rowEntries ->
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            rowEntries.forEachIndexed { columnIndex, (label, selected) ->
                val absoluteIndex = rowIndex * columns + columnIndex
                FilterChip(
                    selected = selected,
                    onClick = { onSelect(absoluteIndex) },
                    label = { Text(label, fontSize = 9.sp, maxLines = 1) },
                    enabled = enabled,
                    modifier = Modifier.weight(1f),
                    colors = automationChipColors(),
                )
            }
            repeat((columns - rowEntries.size).coerceAtLeast(0)) { Spacer(Modifier.weight(1f)) }
        }
        if (rowIndex != entries.chunked(columns).lastIndex) Spacer(Modifier.height(4.dp))
    }
}

@Composable
private fun DividerSpace() {
    Spacer(Modifier.height(12.dp))
    Spacer(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = .06f)))
    Spacer(Modifier.height(12.dp))
}


@Composable
private fun automationSwitchColors() = SwitchDefaults.colors(
    checkedThumbColor = Color.White,
    checkedTrackColor = AutomationGreen,
    uncheckedThumbColor = SonusEditColors.TextMuted,
    uncheckedTrackColor = AutomationGreenDark.copy(alpha = .55f),
    disabledCheckedTrackColor = AutomationGreen.copy(alpha = .42f),
)

@Composable
private fun automationChipColors() = FilterChipDefaults.filterChipColors(
    selectedContainerColor = AutomationGreenDark,
    selectedLabelColor = AutomationGreen,
    containerColor = SonusEditColors.SurfaceRaised,
    labelColor = Color.White,
    disabledSelectedContainerColor = AutomationGreenDark.copy(alpha = .55f),
    disabledLabelColor = AutomationGreen.copy(alpha = .55f),
)
