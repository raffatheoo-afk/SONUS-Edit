package com.sonusstudios.sonusedit.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonusstudios.sonusedit.designsystem.SonusEditColors

/**
 * Shared progress surface for every visible long-running operation in SONUS Edit.
 * A null progress value is intentionally indeterminate; the UI never invents percentages.
 */
@Composable
fun ProcessProgressOverlay(
    title: String,
    status: String,
    progressPercent: Int?,
    modifier: Modifier = Modifier,
    cancelLabel: String = "CANCELAR",
    onCancel: (() -> Unit)? = null,
    secondaryLabel: String? = null,
    onSecondary: (() -> Unit)? = null,
) {
    Box(
        modifier = modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.72f)),
        contentAlignment = Alignment.Center,
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(0.82f),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF10151F)),
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 26.dp, vertical = 28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Box(Modifier.size(116.dp), contentAlignment = Alignment.Center) {
                    val progress = progressPercent?.coerceIn(0, 100)
                    if (progress == null) {
                        CircularProgressIndicator(
                            modifier = Modifier.fillMaxSize(),
                            color = Color(0xFF22F47A),
                            trackColor = Color(0xFF173C29),
                            strokeWidth = 9.dp,
                        )
                    } else {
                        CircularProgressIndicator(
                            progress = { progress / 100f },
                            modifier = Modifier.fillMaxSize(),
                            color = Color(0xFF22F47A),
                            trackColor = Color(0xFF173C29),
                            strokeWidth = 9.dp,
                        )
                        Text(
                            "$progress%",
                            color = Color.White,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.ExtraBold,
                        )
                    }
                }
                Spacer(Modifier.height(20.dp))
                Text(title, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(7.dp))
                Text(status, color = SonusEditColors.TextMuted, fontSize = 13.sp)
                if (onCancel != null || (secondaryLabel != null && onSecondary != null)) {
                    Spacer(Modifier.height(22.dp))
                    if (onCancel != null) {
                        Button(
                            onClick = onCancel,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD92D3A)),
                            shape = RoundedCornerShape(14.dp),
                        ) {
                            Text(cancelLabel, color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                    if (secondaryLabel != null && onSecondary != null) {
                        Spacer(Modifier.height(8.dp))
                        Button(
                            onClick = onSecondary,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = SonusEditColors.Violet),
                            shape = RoundedCornerShape(14.dp),
                        ) {
                            Text(secondaryLabel, color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
