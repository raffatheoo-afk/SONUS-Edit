package com.sonusstudios.sonusedit.create

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.sonusAutomationDataStore by preferencesDataStore(name = "sonus_edit_automation")

/** code12 keeps the same intensity levels while the source motion becomes smoother and more natural. */
enum class EffectIntensity(val label: String, val opacity: Float) {
    SOFT("30%", 0.30f),
    BALANCED("50%", 0.50f),
    MARKED("100%", 1.00f),
}

/**
 * DYNAMIC lets Auto Edit choose a variation for each project. The other entries lock a
 * particular visual style while still using the same approved particle source asset.
 */
enum class ParticleStyle(val label: String, val effectId: String?) {
    DYNAMIC("Dinâmico", null),
    RAINBOW("Arco-íris", "particles_rainbow"),
    BRIGHT("Brilhante", "particles_bright"),
    FIREFLY("Vagalume", "particles_firefly"),
    STAR("Estrela", "particles_star"),
    GLITTER("Glitter", "particles_glitter"),
}

enum class ImageQuantityMode(val label: String) {
    FEW("Poucas"),
    BALANCED("Equilibrado"),
    DYNAMIC("Dinâmico"),
}

data class AutomationSettings(
    val totalAutomation: Boolean = true,
    val smartStart: Boolean = true,
    val prioritizeChorus: Boolean = true,
    val automaticLyrics: Boolean = true,
    val automaticEffects: Boolean = true,
    val particleStyle: ParticleStyle = ParticleStyle.DYNAMIC,
    val effectIntensity: EffectIntensity = EffectIntensity.BALANCED,
    val automaticImages: Boolean = true,
    val automaticFilter: Boolean = true,
    val imageQuantity: ImageQuantityMode = ImageQuantityMode.BALANCED,
    val metadataOnVideo: Boolean = true,
    val defaultResolution: ExportResolution = ExportResolution.P1080,
    val defaultFps: Int = 60,
    val favoriteFonts: Set<FontPresetId> = emptySet(),
    val favoriteFilters: Set<FilterPresetId> = emptySet(),
)

class AutomationPreferences(private val context: Context) {
    private object Keys {
        val Total = booleanPreferencesKey("total_automation")
        val SmartStart = booleanPreferencesKey("smart_start")
        val Chorus = booleanPreferencesKey("prioritize_chorus")
        val Lyrics = booleanPreferencesKey("automatic_lyrics")
        val Effects = booleanPreferencesKey("automatic_effects")
        val ParticleStyle = stringPreferencesKey("particle_style")
        val EffectIntensity = stringPreferencesKey("effect_intensity")
        val Images = booleanPreferencesKey("automatic_images")
        val Filter = booleanPreferencesKey("automatic_filter")
        val ImageQuantity = stringPreferencesKey("image_quantity")
        val Metadata = booleanPreferencesKey("metadata_on_video")
        val Resolution = stringPreferencesKey("default_resolution")
        val Fps = intPreferencesKey("default_fps")
        val FavoriteFonts = stringSetPreferencesKey("favorite_fonts")
        val FavoriteFilters = stringSetPreferencesKey("favorite_filters")
    }

    val values: Flow<AutomationSettings> = context.sonusAutomationDataStore.data.map { prefs ->
        AutomationSettings(
            totalAutomation = prefs[Keys.Total] ?: true,
            smartStart = prefs[Keys.SmartStart] ?: true,
            prioritizeChorus = prefs[Keys.Chorus] ?: true,
            automaticLyrics = prefs[Keys.Lyrics] ?: true,
            automaticEffects = prefs[Keys.Effects] ?: true,
            particleStyle = prefs[Keys.ParticleStyle]
                ?.let { runCatching { ParticleStyle.valueOf(it) }.getOrNull() }
                ?: ParticleStyle.DYNAMIC,
            effectIntensity = prefs[Keys.EffectIntensity]
                ?.let { runCatching { EffectIntensity.valueOf(it) }.getOrNull() }
                ?: EffectIntensity.BALANCED,
            automaticImages = prefs[Keys.Images] ?: true,
            automaticFilter = prefs[Keys.Filter] ?: true,
            imageQuantity = prefs[Keys.ImageQuantity]
                ?.let { runCatching { ImageQuantityMode.valueOf(it) }.getOrNull() }
                ?: ImageQuantityMode.BALANCED,
            metadataOnVideo = prefs[Keys.Metadata] ?: true,
            defaultResolution = prefs[Keys.Resolution]
                ?.let { runCatching { ExportResolution.valueOf(it) }.getOrNull() }
                ?: ExportResolution.P1080,
            defaultFps = (prefs[Keys.Fps] ?: 60).takeIf { it in setOf(30, 60, 90) } ?: 60,
            favoriteFonts = prefs[Keys.FavoriteFonts].orEmpty().mapNotNull { name ->
                runCatching { FontPresetId.valueOf(name) }.getOrNull()
            }.toSet(),
            favoriteFilters = prefs[Keys.FavoriteFilters].orEmpty().mapNotNull { name ->
                runCatching { FilterPresetId.valueOf(name) }.getOrNull()
            }.toSet(),
        )
    }

    suspend fun save(value: AutomationSettings) {
        context.sonusAutomationDataStore.edit { prefs ->
            prefs[Keys.Total] = value.totalAutomation
            prefs[Keys.SmartStart] = value.smartStart
            prefs[Keys.Chorus] = value.prioritizeChorus
            prefs[Keys.Lyrics] = value.automaticLyrics
            prefs[Keys.Effects] = value.automaticEffects
            prefs[Keys.ParticleStyle] = value.particleStyle.name
            prefs[Keys.EffectIntensity] = value.effectIntensity.name
            prefs[Keys.Images] = value.automaticImages
            prefs[Keys.Filter] = value.automaticFilter
            prefs[Keys.ImageQuantity] = value.imageQuantity.name
            prefs[Keys.Metadata] = value.metadataOnVideo
            prefs[Keys.Resolution] = value.defaultResolution.name
            prefs[Keys.Fps] = value.defaultFps
            prefs[Keys.FavoriteFonts] = value.favoriteFonts.map { it.name }.toSet()
            prefs[Keys.FavoriteFilters] = value.favoriteFilters.map { it.name }.toSet()
        }
    }

    suspend fun restoreDefaults() {
        val current = context.sonusAutomationDataStore.data.first()
        val favoriteFonts = current[Keys.FavoriteFonts].orEmpty().mapNotNull { name ->
            runCatching { FontPresetId.valueOf(name) }.getOrNull()
        }.toSet()
        val favoriteFilters = current[Keys.FavoriteFilters].orEmpty().mapNotNull { name ->
            runCatching { FilterPresetId.valueOf(name) }.getOrNull()
        }.toSet()
        save(AutomationSettings(favoriteFonts = favoriteFonts, favoriteFilters = favoriteFilters))
    }
}
