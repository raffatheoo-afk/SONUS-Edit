package com.sonusstudios.sonusedit.create

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.sonusAutomationDataStore by preferencesDataStore(name = "sonus_edit_automation")

/** code14 opacity levels for the raw-video particle overlay. */
enum class EffectIntensity(val label: String, val opacity: Float) {
    SOFT("30%", 0.30f),
    BALANCED("50%", 0.50f),
    MARKED("100%", 1.00f),
}

/**
 * code14 removes every synthetic atlas variation. Dynamic alternates only between the two
 * original 9:16 MP4 sources; either source can also be locked manually.
 */
enum class ParticleStyle(val label: String, val effectId: String?) {
    DYNAMIC("Dinâmico", null),
    ORIGINAL_60("Original 60 FPS", "raw_green_60"),
    ORIGINAL_30("Original 30 FPS", "raw_black_30"),
}

enum class ImageQuantityMode(val label: String) {
    FEW("Poucas"),
    BALANCED("Equilibrado"),
    DYNAMIC("Dinâmico"),
}

data class AutomationSettings(
    val totalAutomation: Boolean = true,
    val smartStart: Boolean = true,
    val prioritizeChorus: Boolean = true,
    val automaticLyrics: Boolean = true,
    val automaticEffects: Boolean = true,
    val particleStyle: ParticleStyle = ParticleStyle.DYNAMIC,
    val effectIntensity: EffectIntensity = EffectIntensity.BALANCED,
    val automaticImages: Boolean = true,
    val automaticFilter: Boolean = true,
    val imageQuantity: ImageQuantityMode = ImageQuantityMode.BALANCED,
    val metadataOnVideo: Boolean = true,
    val defaultResolution: ExportResolution = ExportResolution.P1080,
    val defaultFps: Int = 60,
    val favoriteFonts: Set<FontPresetId> = emptySet(),
    val favoriteFilters: Set<FilterPresetId> = emptySet(),
    /** null = Automático: the app picks the caption look by speech rhythm and genre. */
    val preferredCaptionStyle: CaptionStyleId? = null,
)

class AutomationPreferences(private val context: Context) {
    private object Keys {
        val Total = booleanPreferencesKey("total_automation")
        val SmartStart = booleanPreferencesKey("smart_start")
        val Chorus = booleanPreferencesKey("prioritize_chorus")
        val Lyrics = booleanPreferencesKey("automatic_lyrics")
        val Effects = booleanPreferencesKey("automatic_effects")
        val ParticleStyle = stringPreferencesKey("particle_style")
        val EffectIntensity = stringPreferencesKey("effect_intensity")
        val Images = booleanPreferencesKey("automatic_images")
        val Filter = booleanPreferencesKey("automatic_filter")
        val ImageQuantity = stringPreferencesKey("image_quantity")
        val Metadata = booleanPreferencesKey("metadata_on_video")
        val Resolution = stringPreferencesKey("default_resolution")
        val Fps = intPreferencesKey("default_fps")
        val FavoriteFonts = stringSetPreferencesKey("favorite_fonts")
        val FavoriteFilters = stringSetPreferencesKey("favorite_filters")
        val PreferredCaptionStyle = stringPreferencesKey("preferred_caption_style")
    }

    val values: Flow<AutomationSettings> = context.sonusAutomationDataStore.data.map { prefs ->
        AutomationSettings(
            totalAutomation = prefs[Keys.Total] ?: true,
            smartStart = prefs[Keys.SmartStart] ?: true,
            prioritizeChorus = prefs[Keys.Chorus] ?: true,
            automaticLyrics = prefs[Keys.Lyrics] ?: true,
            automaticEffects = prefs[Keys.Effects] ?: true,
            particleStyle = prefs[Keys.ParticleStyle]
                ?.let { runCatching { ParticleStyle.valueOf(it) }.getOrNull() }
                ?: ParticleStyle.DYNAMIC,
            effectIntensity = prefs[Keys.EffectIntensity]
                ?.let { runCatching { EffectIntensity.valueOf(it) }.getOrNull() }
                ?: EffectIntensity.BALANCED,
            automaticImages = prefs[Keys.Images] ?: true,
            automaticFilter = prefs[Keys.Filter] ?: true,
            imageQuantity = prefs[Keys.ImageQuantity]
                ?.let { runCatching { ImageQuantityMode.valueOf(it) }.getOrNull() }
                ?: ImageQuantityMode.BALANCED,
            metadataOnVideo = prefs[Keys.Metadata] ?: true,
            defaultResolution = prefs[Keys.Resolution]
                ?.let { runCatching { ExportResolution.valueOf(it) }.getOrNull() }
                ?: ExportResolution.P1080,
            defaultFps = when (prefs[Keys.Fps] ?: 60) {
                30 -> 30
                else -> 60 // code16 migrates legacy 90 FPS preferences safely to 60.
            },
            favoriteFonts = prefs[Keys.FavoriteFonts].orEmpty().mapNotNull { name ->
                runCatching { FontPresetId.valueOf(name) }.getOrNull()
            }.toSet(),
            favoriteFilters = prefs[Keys.FavoriteFilters].orEmpty().mapNotNull { name ->
                runCatching { FilterPresetId.valueOf(name) }.getOrNull()
            }.toSet(),
            preferredCaptionStyle = prefs[Keys.PreferredCaptionStyle]
                ?.let { runCatching { CaptionStyleId.valueOf(it) }.getOrNull() },
        )
    }

    suspend fun save(value: AutomationSettings) {
        context.sonusAutomationDataStore.edit { prefs ->
            prefs[Keys.Total] = value.totalAutomation
            prefs[Keys.SmartStart] = value.smartStart
            prefs[Keys.Chorus] = value.prioritizeChorus
            prefs[Keys.Lyrics] = value.automaticLyrics
            prefs[Keys.Effects] = value.automaticEffects
            prefs[Keys.ParticleStyle] = value.particleStyle.name
            prefs[Keys.EffectIntensity] = value.effectIntensity.name
            prefs[Keys.Images] = value.automaticImages
            prefs[Keys.Filter] = value.automaticFilter
            prefs[Keys.ImageQuantity] = value.imageQuantity.name
            prefs[Keys.Metadata] = value.metadataOnVideo
            prefs[Keys.Resolution] = value.defaultResolution.name
            prefs[Keys.Fps] = if (value.defaultFps == 30) 30 else 60
            prefs[Keys.FavoriteFonts] = value.favoriteFonts.map { it.name }.toSet()
            prefs[Keys.FavoriteFilters] = value.favoriteFilters.map { it.name }.toSet()
            val style = value.preferredCaptionStyle
            if (style == null) prefs.remove(Keys.PreferredCaptionStyle) else prefs[Keys.PreferredCaptionStyle] = style.name
        }
    }

    suspend fun restoreDefaults() {
        val current = context.sonusAutomationDataStore.data.first()
        val favoriteFonts = current[Keys.FavoriteFonts].orEmpty().mapNotNull { name ->
            runCatching { FontPresetId.valueOf(name) }.getOrNull()
        }.toSet()
        val favoriteFilters = current[Keys.FavoriteFilters].orEmpty().mapNotNull { name ->
            runCatching { FilterPresetId.valueOf(name) }.getOrNull()
        }.toSet()
        save(AutomationSettings(favoriteFonts = favoriteFonts, favoriteFilters = favoriteFilters))
    }
}
