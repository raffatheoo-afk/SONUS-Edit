package com.sonusstudios.sonusedit.create

import android.content.Context
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Validates a local video selected as an audio source without copying or decoding the whole file.
 * Media3/Whisper can consume the original content Uri directly once an audio track is confirmed.
 */
object VideoAudioSourceInspector {
    suspend fun validate(context: Context, uri: Uri): AudioMetadata = withContext(Dispatchers.IO) {
        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(context, uri, null)
            val hasAudio = (0 until extractor.trackCount).any { index ->
                extractor.getTrackFormat(index).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true
            }
            require(hasAudio) { "O vídeo selecionado não possui uma faixa de áudio compatível." }
        } finally {
            extractor.release()
        }
        AudioMetadataReader.read(context, uri)
    }
}
