package com.sonusstudios.sonusedit.create

import android.content.Context
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri

/** Reads duration from container/track metadata without decoding the audio stream. */
object AudioDurationProbe13 {
    fun normalizeDurationUs(durationUs: Long): Long =
        if (durationUs >= MIN_DURATION_US) durationUs / 1_000L else 0L

    fun longestAudioTrackDurationUs(trackDurationsUs: Iterable<Long>): Long =
        normalizeDurationUs(trackDurationsUs.maxOrNull() ?: 0L)

    fun readDurationMs(context: Context, uri: Uri): Long {
        val extractor = MediaExtractor()
        return try {
            if (uri.scheme.equals("http", ignoreCase = true) || uri.scheme.equals("https", ignoreCase = true)) {
                extractor.setDataSource(uri.toString(), emptyMap())
            } else {
                extractor.setDataSource(context, uri, null)
            }
            var durationUs = 0L
            for (trackIndex in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(trackIndex)
                val mime = format.getString(MediaFormat.KEY_MIME).orEmpty()
                if (!mime.startsWith("audio/", ignoreCase = true)) continue
                if (!format.containsKey(MediaFormat.KEY_DURATION)) continue
                val trackDurationUs = runCatching { format.getLong(MediaFormat.KEY_DURATION) }.getOrDefault(0L)
                if (trackDurationUs > durationUs) durationUs = trackDurationUs
            }
            normalizeDurationUs(durationUs)
        } catch (_: Exception) {
            0L
        } finally {
            runCatching { extractor.release() }
        }
    }

    private const val MIN_DURATION_US = 1_000_000L
}
