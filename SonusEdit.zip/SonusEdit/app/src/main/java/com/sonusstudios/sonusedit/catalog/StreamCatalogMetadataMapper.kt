package com.sonusstudios.sonusedit.catalog

import com.sonusstudios.sonusedit.create.AudioMetadata

/** Maps audio tags already present in pCloud's recursive public-catalog metadata. */
object StreamCatalogMetadataMapper {
    fun fromAsset(asset: PCloudAsset): AudioMetadata? {
        val title = asset.metadataTitle?.trim()?.takeIf { it.isNotBlank() && !isOpaqueCode(it) }
        val artist = asset.metadataArtist?.trim()?.takeIf { it.isNotBlank() }
        val album = asset.metadataAlbum?.trim()?.takeIf { it.isNotBlank() }
        val genre = asset.metadataGenre?.trim()?.takeIf { it.isNotBlank() }
        if (title == null && artist == null && album == null && genre == null) return null
        return AudioMetadata(
            title = title ?: asset.name.substringBeforeLast('.', asset.name).replace('_', ' ').trim(),
            artist = artist,
            durationMs = asset.durationMs ?: 0L,
            album = album,
            genre = genre ?: asset.genre,
        )
    }

    /** A title and artist are sufficient to avoid downloading the audio just to index its tags. */
    fun hasUsefulCatalogIdentity(asset: PCloudAsset): Boolean =
        asset.metadataTitle?.isNotBlank() == true &&
            !isOpaqueCode(asset.metadataTitle.orEmpty()) &&
            asset.metadataArtist?.isNotBlank() == true

    fun merge(catalog: AudioMetadata?, remote: AudioMetadata): AudioMetadata {
        val catalogTitle = catalog?.title?.takeIf { it.isNotBlank() && !isOpaqueCode(it) }
        val remoteTitle = remote.title.takeIf { it.isNotBlank() && !isOpaqueCode(it) }
        return AudioMetadata(
            title = catalogTitle ?: remoteTitle ?: remote.title,
            artist = catalog?.artist?.takeIf { it.isNotBlank() } ?: remote.artist,
            durationMs = remote.durationMs.takeIf { it > 0L } ?: catalog?.durationMs?.takeIf { it > 0L } ?: 0L,
            album = catalog?.album?.takeIf { it.isNotBlank() } ?: remote.album,
            genre = catalog?.genre?.takeIf { it.isNotBlank() } ?: remote.genre,
        )
    }

    fun isOpaqueCode(value: String): Boolean = value.matches(Regex("[A-Za-z0-9_-]{18,}"))
}
