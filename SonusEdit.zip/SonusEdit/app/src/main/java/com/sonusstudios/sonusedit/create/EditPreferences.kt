package com.sonusstudios.sonusedit.create

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.sonusEditDataStore by preferencesDataStore(name = "sonus_edit_preferences")

data class SavedEditPreferences(
    val signatureText: String = "",
    val signaturePhotoUri: String? = null,
    val signatureFontPreset: SignatureFontPreset = SignatureFontPreset.PATRICK_HAND,
    val signatureColorPreset: SignatureColorPreset = SignatureColorPreset.WHITE,
    val fontPreset: FontPresetId = FontPresetId.DEFAULT,
)

class EditPreferences(private val context: Context) {
    private object Keys {
        val SignatureText = stringPreferencesKey("signature_text")
        val SignaturePhoto = stringPreferencesKey("signature_photo_uri")
        val SignatureFont = stringPreferencesKey("signature_font_preset")
        val SignatureColor = stringPreferencesKey("signature_color_preset")
        val FontPreset = stringPreferencesKey("font_preset")
    }

    val values: Flow<SavedEditPreferences> = context.sonusEditDataStore.data.map { prefs ->
        SavedEditPreferences(
            signatureText = prefs[Keys.SignatureText].orEmpty(),
            signaturePhotoUri = prefs[Keys.SignaturePhoto]?.takeIf { it.isNotBlank() },
            signatureFontPreset = prefs[Keys.SignatureFont]
                ?.let { runCatching { SignatureFontPreset.valueOf(it) }.getOrNull() }
                ?: SignatureFontPreset.PATRICK_HAND,
            signatureColorPreset = prefs[Keys.SignatureColor]
                ?.let { runCatching { SignatureColorPreset.valueOf(it) }.getOrNull() }
                ?: SignatureColorPreset.WHITE,
            fontPreset = prefs[Keys.FontPreset]
                ?.let { runCatching { FontPresetId.valueOf(it) }.getOrNull() }
                ?: FontPresetId.DEFAULT,
        )
    }

    suspend fun saveSignature(
        text: String,
        photoUri: String?,
        fontPreset: SignatureFontPreset,
        colorPreset: SignatureColorPreset,
    ) {
        context.sonusEditDataStore.edit { prefs ->
            prefs[Keys.SignatureText] = text.trim()
            prefs[Keys.SignaturePhoto] = photoUri.orEmpty()
            prefs[Keys.SignatureFont] = fontPreset.name
            prefs[Keys.SignatureColor] = colorPreset.name
        }
    }

    suspend fun saveFont(fontPreset: FontPresetId) {
        context.sonusEditDataStore.edit { prefs ->
            prefs[Keys.FontPreset] = fontPreset.name
        }
    }
}
