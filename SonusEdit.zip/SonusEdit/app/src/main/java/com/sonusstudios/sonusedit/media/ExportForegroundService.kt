package com.sonusstudios.sonusedit.media

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.IBinder
import android.os.Build
import android.content.pm.ServiceInfo
import com.sonusstudios.sonusedit.MainActivity
import com.sonusstudios.sonusedit.R
import com.sonusstudios.sonusedit.catalog.PCloudAsset
import com.sonusstudios.sonusedit.catalog.StreamHistoryStore
import com.sonusstudios.sonusedit.create.AudioSource
import com.sonusstudios.sonusedit.create.CreateProjectDraft
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json

enum class ExportServiceStatus { IDLE, EXPORTING, SAVED, ERROR, CANCELLED }

data class ExportServiceState(
    val status: ExportServiceStatus = ExportServiceStatus.IDLE,
    val progress: Int = 0,
    val outputUri: String? = null,
    val error: String? = null,
    val draftKey: String? = null,
    val title: String = "",
)

object ExportProgressBus {
    private val mutable = MutableStateFlow(ExportServiceState())
    val state: StateFlow<ExportServiceState> = mutable.asStateFlow()

    internal fun update(value: ExportServiceState) { mutable.value = value }
    fun reset() { mutable.value = ExportServiceState() }
}

/**
 * Owns the Media3 Transformer outside the Activity/Compose lifecycle.
 * Minimizing or navigating away from the export screen no longer cancels a running render.
 */
class ExportForegroundService : Service() {
    companion object {
        private const val ACTION_START = "com.sonusstudios.sonusedit.export.START"
        private const val ACTION_CANCEL = "com.sonusstudios.sonusedit.export.CANCEL"
        private const val EXTRA_DRAFT = "draft_json"
        private const val EXTRA_KEY = "draft_key"
        private const val CHANNEL_ID = "sonus_edit_export"
        private const val NOTIFICATION_ID = 2708

        fun draftKey(draft: CreateProjectDraft): String = listOf(
            draft.audioUri,
            draft.segmentStartMs,
            draft.segmentDurationMs,
            draft.imageUris.joinToString("|"),
            draft.exportTitle,
            draft.exportArtist,
            draft.exportResolution.name,
            draft.exportFps,
        ).joinToString("#").hashCode().toString()

        fun start(context: Context, draft: CreateProjectDraft) {
            val intent = Intent(context, ExportForegroundService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_DRAFT, Json.encodeToString(CreateProjectDraft.serializer(), draft))
                putExtra(EXTRA_KEY, draftKey(draft))
            }
            context.startForegroundService(intent)
        }

        fun cancel(context: Context) {
            context.startService(Intent(context, ExportForegroundService::class.java).setAction(ACTION_CANCEL))
        }
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var exporter: AutomaticVideoExporter
    private var progressJob: Job? = null
    private var activeDraft: CreateProjectDraft? = null
    private var activeKey: String? = null

    override fun onCreate() {
        super.onCreate()
        exporter = AutomaticVideoExporter(applicationContext)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CANCEL -> cancelExport()
            ACTION_START -> startExport(intent)
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun startExport(intent: Intent) {
        val json = intent.getStringExtra(EXTRA_DRAFT) ?: return stopSelfSafely()
        val key = intent.getStringExtra(EXTRA_KEY) ?: return stopSelfSafely()
        val draft = runCatching { Json.decodeFromString(CreateProjectDraft.serializer(), json) }.getOrElse {
            ExportProgressBus.update(ExportServiceState(ExportServiceStatus.ERROR, error = it.message, draftKey = key))
            return stopSelfSafely()
        }

        val current = ExportProgressBus.state.value
        if (current.status == ExportServiceStatus.EXPORTING && current.draftKey == key) return

        activeDraft = draft
        activeKey = key
        val title = draft.exportTitle.ifBlank { draft.audioTitle }
        ExportProgressBus.update(
            ExportServiceState(
                status = ExportServiceStatus.EXPORTING,
                progress = 0,
                draftKey = key,
                title = title,
            )
        )
        startExportForeground(buildNotification(0, title, "Preparando mídia…", ongoing = true))

        exporter.start(
            draft = draft,
            onCompleted = { uri -> onCompleted(draft, key, uri) },
            onError = { error -> onError(key, title, error) },
        )

        progressJob?.cancel()
        progressJob = serviceScope.launch {
            while (isActive && ExportProgressBus.state.value.status == ExportServiceStatus.EXPORTING) {
                val progress = exporter.progressPercent()?.coerceIn(0, 100)
                    ?: ExportProgressBus.state.value.progress
                ExportProgressBus.update(
                    ExportProgressBus.state.value.copy(progress = progress)
                )
                notifyProgress(progress, title)
                delay(350)
            }
        }
    }


    private fun startExportForeground(notification: Notification) {
        if (Build.VERSION.SDK_INT >= 35) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROCESSING)
        } else if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }
    private fun onCompleted(draft: CreateProjectDraft, key: String, uri: Uri) {
        progressJob?.cancel()
        val title = draft.exportTitle.ifBlank { draft.audioTitle }
        if (draft.audioSource == AudioSource.SONUS_STREAM) {
            val id = draft.sourceTrackId?.toLongOrNull()
            if (id != null) {
                runCatching {
                    StreamHistoryStore(applicationContext).record(
                        PCloudAsset(
                            fileId = id,
                            name = draft.audioTitle,
                            folderPath = draft.sourceGenre.orEmpty(),
                            sourcePublicCode = draft.sourcePublicCode,
                        )
                    )
                }
            }
        }
        ExportProgressBus.update(
            ExportServiceState(
                status = ExportServiceStatus.SAVED,
                progress = 100,
                outputUri = uri.toString(),
                draftKey = key,
                title = title,
            )
        )
        notificationManager().notify(
            NOTIFICATION_ID,
            buildNotification(100, title, "Vídeo concluído ✓", ongoing = false),
        )
        stopForeground(STOP_FOREGROUND_DETACH)
        stopSelf()
    }

    private fun onError(key: String, title: String, error: Throwable) {
        progressJob?.cancel()
        ExportProgressBus.update(
            ExportServiceState(
                status = ExportServiceStatus.ERROR,
                progress = ExportProgressBus.state.value.progress,
                error = error.message ?: "Falha ao exportar vídeo.",
                draftKey = key,
                title = title,
            )
        )
        notificationManager().notify(
            NOTIFICATION_ID,
            buildNotification(0, title, "Falha ao criar vídeo", ongoing = false),
        )
        stopForeground(STOP_FOREGROUND_DETACH)
        stopSelf()
    }

    private fun cancelExport() {
        val state = ExportProgressBus.state.value
        exporter.cancel()
        progressJob?.cancel()
        ExportProgressBus.update(state.copy(status = ExportServiceStatus.CANCELLED))
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun notifyProgress(progress: Int, title: String) {
        notificationManager().notify(
            NOTIFICATION_ID,
            buildNotification(progress, title, exportStage(progress), ongoing = true),
        )
    }

    private fun buildNotification(progress: Int, title: String, stage: String, ongoing: Boolean): Notification {
        val openApp = PendingIntent.getActivity(
            this,
            11,
            Intent(this, MainActivity::class.java).apply {
                action = "com.sonusstudios.sonusedit.OPEN_EXPORT"
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val cancel = PendingIntent.getService(
            this,
            12,
            Intent(this, ExportForegroundService::class.java).setAction(ACTION_CANCEL),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("Sonus Edit • $title")
            .setContentText(stage)
            .setContentIntent(openApp)
            .setOnlyAlertOnce(true)
            .setOngoing(ongoing)
            .setProgress(100, progress.coerceIn(0, 100), false)
            .apply {
                if (ongoing) {
                    val icon = android.graphics.drawable.Icon.createWithResource(this@ExportForegroundService, R.mipmap.ic_launcher)
                    addAction(Notification.Action.Builder(icon, "Cancelar", cancel).build())
                }
            }
            .build()
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Exportação de vídeos",
            NotificationManager.IMPORTANCE_LOW,
        ).apply {
            description = "Mostra o progresso da criação de vídeos no Sonus Edit."
            setSound(null, null)
        }
        notificationManager().createNotificationChannel(channel)
    }

    private fun notificationManager(): NotificationManager =
        getSystemService(NotificationManager::class.java)

    private fun stopSelfSafely() {
        stopSelf()
    }

    override fun onDestroy() {
        progressJob?.cancel()
        serviceScope.coroutineContext.cancel()
        super.onDestroy()
    }
}

private fun exportStage(progress: Int): String = when (progress) {
    in 0..9 -> "Preparando mídia…"
    in 10..24 -> "Sincronizando projeto…"
    in 25..49 -> "Montando imagens…"
    in 50..94 -> "Renderizando vídeo…"
    else -> "Salvando na galeria…"
}
