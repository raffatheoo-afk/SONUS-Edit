package com.sonusstudios.sonusedit.media

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.IBinder
import android.os.SystemClock
import android.os.Build
import android.util.Log
import android.content.pm.ServiceInfo
import com.sonusstudios.sonusedit.MainActivity
import com.sonusstudios.sonusedit.R
import com.sonusstudios.sonusedit.catalog.PCloudAsset
import com.sonusstudios.sonusedit.catalog.StreamHistoryStore
import com.sonusstudios.sonusedit.create.AudioSource
import com.sonusstudios.sonusedit.create.CreateProjectDraft
import com.sonusstudios.sonusedit.create.LinkAudioImporter
import com.sonusstudios.sonusedit.create.ImageSelectionHistoryStore
import com.sonusstudios.sonusedit.create.CreationDraftStore
import com.sonusstudios.sonusedit.stats.UsageStatsStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json

enum class ExportServiceStatus { IDLE, EXPORTING, SAVED, ERROR, CANCELLED }

data class ExportServiceState(
    val status: ExportServiceStatus = ExportServiceStatus.IDLE,
    val progress: Int = 0,
    val outputUri: String? = null,
    val error: String? = null,
    val draftKey: String? = null,
    val title: String = "",
    /** Short message shown while exporting, e.g. when the export restarts in a lighter quality. */
    val notice: String? = null,
)

object ExportProgressBus {
    private val mutable = MutableStateFlow(ExportServiceState())
    val state: StateFlow<ExportServiceState> = mutable.asStateFlow()

    internal fun update(value: ExportServiceState) { mutable.value = value }
    fun reset() { mutable.value = ExportServiceState() }
}

/**
 * Owns the Media3 Transformer outside the Activity/Compose lifecycle.
 * Minimizing or navigating away from the export screen no longer cancels a running render.
 */
class ExportForegroundService : Service() {
    companion object {
        private const val ACTION_START = "com.sonusstudios.sonusedit.export.START"
        private const val ACTION_CANCEL = "com.sonusstudios.sonusedit.export.CANCEL"
        private const val EXTRA_DRAFT = "draft_json"
        private const val EXTRA_KEY = "draft_key"
        private const val CHANNEL_ID = "sonus_edit_export"
        private const val NOTIFICATION_ID = 2708

        fun draftKey(draft: CreateProjectDraft): String = listOf(
            draft.audioUri,
            draft.segmentStartMs,
            draft.segmentDurationMs,
            draft.imageUris.joinToString("|"),
            draft.exportTitle,
            draft.exportArtist,
            draft.aspectRatio,
            draft.particlesEnabled,
            draft.automaticEffectId,
            draft.exportResolution.name,
            draft.exportFps,
            draft.captionStyle,
            draft.captionPosition,
            draft.captionSizeScale,
            draft.captionPositionPercent,
            draft.customOutputWidth,
            draft.customOutputHeight,
        ).joinToString("#").hashCode().toString()

        fun start(context: Context, draft: CreateProjectDraft) {
            val intent = Intent(context, ExportForegroundService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_DRAFT, Json.encodeToString(CreateProjectDraft.serializer(), draft))
                putExtra(EXTRA_KEY, draftKey(draft))
            }
            context.startForegroundService(intent)
        }

        fun cancel(context: Context) {
            context.startService(Intent(context, ExportForegroundService::class.java).setAction(ACTION_CANCEL))
        }
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var exporter: AutomaticVideoExporter
    private var progressJob: Job? = null
    private var effectPreparationJob: Job? = null
    private var activeDraft: CreateProjectDraft? = null
    private var activeKey: String? = null
    private var activeExportStartedMs: Long = 0L

    override fun onCreate() {
        super.onCreate()
        exporter = AutomaticVideoExporter(applicationContext)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CANCEL -> cancelExport()
            ACTION_START -> startExport(intent)
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun startExport(intent: Intent) {
        val json = intent.getStringExtra(EXTRA_DRAFT) ?: return stopSelfSafely()
        val key = intent.getStringExtra(EXTRA_KEY) ?: return stopSelfSafely()
        val decodedDraft = runCatching { Json.decodeFromString(CreateProjectDraft.serializer(), json) }.getOrElse {
            ExportProgressBus.update(ExportServiceState(ExportServiceStatus.ERROR, error = it.message, draftKey = key))
            return stopSelfSafely()
        }
        // code16 migration: old persisted/queued drafts may still contain 90 FPS.
        // Normalize before the Transformer sees them so removing 90 from the UI cannot break export.
        val draft = decodedDraft.copy(exportFps = if (decodedDraft.exportFps == 30) 30 else 60)

        val current = ExportProgressBus.state.value
        if (current.status == ExportServiceStatus.EXPORTING && current.draftKey == key) return

        activeDraft = draft
        activeKey = key
        activeExportStartedMs = SystemClock.elapsedRealtime()
        val title = draft.exportTitle.ifBlank { draft.audioTitle }
        ExportProgressBus.update(
            ExportServiceState(
                status = ExportServiceStatus.EXPORTING,
                progress = 0,
                draftKey = key,
                title = title,
            )
        )
        startExportForeground(buildNotification(0, title, "Preparando mídia…", ongoing = true))

        effectPreparationJob?.cancel()
        effectPreparationJob = serviceScope.launch {
            // A resumed project may have lost its cached cloud MP4. Prepare again on IO and use
            // a built-in overlay if pCloud cannot be reached; the export must not lose its video.
            val readyDraft = if (draft.particlesEnabled && PCloudEffectLibrary.isCloud(draft.automaticEffectId)) {
                val available = PCloudEffectLibrary(applicationContext).prepare(draft.automaticEffectId)
                if (available == null) draft.copy(automaticEffectId = EffectIds.RAW_GREEN_60) else draft
            } else draft
            if (!isActive || activeKey != key) return@launch
            activeDraft = readyDraft
            exporter.start(
                draft = readyDraft,
                onCompleted = { uri -> onCompleted(readyDraft, key, uri) },
                onError = { error -> onError(key, title, error) },
                onFallback = { message ->
                    val state = ExportProgressBus.state.value
                    if (state.status == ExportServiceStatus.EXPORTING && state.draftKey == key) {
                        ExportProgressBus.update(state.copy(progress = 0, notice = message))
                    }
                },
            )
        }

        progressJob?.cancel()
        progressJob = serviceScope.launch {
            while (isActive && ExportProgressBus.state.value.status == ExportServiceStatus.EXPORTING) {
                val progress = exporter.progressPercent()?.coerceIn(0, 100)
                    ?: ExportProgressBus.state.value.progress
                ExportProgressBus.update(
                    ExportProgressBus.state.value.copy(progress = progress)
                )
                notifyProgress(progress, title)
                delay(350)
            }
        }
    }


    private fun startExportForeground(notification: Notification) {
        if (Build.VERSION.SDK_INT >= 35) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROCESSING)
        } else if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }
    private fun onCompleted(draft: CreateProjectDraft, key: String, uri: Uri) {
        progressJob?.cancel()
        val title = draft.exportTitle.ifBlank { draft.audioTitle }
        if (draft.audioSource == AudioSource.SONUS_STREAM) {
            val id = draft.sourceTrackId?.toLongOrNull()
            if (id != null) {
                runCatching {
                    StreamHistoryStore(applicationContext).record(
                        PCloudAsset(
                            fileId = id,
                            name = draft.audioTitle,
                            folderPath = draft.sourceGenre.orEmpty(),
                            sourcePublicCode = draft.sourcePublicCode,
                        )
                    )
                }
            }
        }
        if (draft.audioSource == AudioSource.LINK) {
            LinkAudioImporter.deleteImportedAudio(applicationContext, draft.audioUri)
        }
        // Images enter the four-following-project cooldown only after the MP4 is safely saved.
        runCatching { ImageSelectionHistoryStore(applicationContext).recordProjectKeys(draft.imageHistoryKeys) }
        ExportProgressBus.update(
            ExportServiceState(
                status = ExportServiceStatus.SAVED,
                progress = 100,
                outputUri = uri.toString(),
                draftKey = key,
                title = title,
            )
        )
        val exportElapsed = (SystemClock.elapsedRealtime() - activeExportStartedMs).coerceAtLeast(0L)
        Thread {
            kotlinx.coroutines.runBlocking {
                UsageStatsStore(applicationContext).recordExportSuccess(draft, exportElapsed)
                // Legendas automáticas (fitFullFrame) never created a creation draft, so it must not erase one.
                if (!draft.fitFullFrame) CreationDraftStore(applicationContext).clear()
            }
        }.start()
        // code10: the export notification exists only while rendering. Once the file is saved,
        // remove the foreground notification completely instead of leaving a finished card behind.
        stopForeground(STOP_FOREGROUND_REMOVE)
        notificationManager().cancel(NOTIFICATION_ID)
        stopSelf()
    }

    private fun onError(key: String, title: String, error: Throwable) {
        progressJob?.cancel()
        ExportProgressBus.update(
            ExportServiceState(
                status = ExportServiceStatus.ERROR,
                progress = ExportProgressBus.state.value.progress,
                error = exportErrorMessage(error),
                draftKey = key,
                title = title,
            )
        )
        Thread {
            kotlinx.coroutines.runBlocking { UsageStatsStore(applicationContext).recordExportFailure(cancelled = false) }
        }.start()
        stopForeground(STOP_FOREGROUND_REMOVE)
        notificationManager().cancel(NOTIFICATION_ID)
        stopSelf()
    }

    private fun exportErrorMessage(error: Throwable): String {
        val draft = activeDraft
        Log.e("SonusEditExport", "Falha no ${Build.MANUFACTURER}/${Build.MODEL} Android ${Build.VERSION.SDK_INT}; " +
            "res=${draft?.exportResolution} fps=${draft?.exportFps} " +
            "duration=${draft?.segmentDurationMs} effect=${draft?.automaticEffectId}", error)
        val messages = generateSequence(error as Throwable?) { it.cause }
            .mapNotNull { throwable ->
                throwable.message?.trim()?.takeIf { it.isNotEmpty() }
                    ?: throwable::class.java.simpleName.takeIf { it.isNotEmpty() }
            }
            .distinct()
            .take(4)
            .toList()
        val detailed = messages.joinToString(" → ")
        val text = detailed.lowercase()
        val reason = when {
            text.contains("no output sample") || text.contains("muxer error") ->
                "O codificador deste aparelho parou de gerar vídeo. Tentamos recuperar por segmentos. " +
                    "Se persistir, teste 720p/30 FPS sem partículas."
            text.contains("out of memory") || error is OutOfMemoryError ->
                "O aparelho ficou sem memória ao exportar. Feche outros apps e tente uma qualidade menor."
            text.contains("enospc") || text.contains("no space") || text.contains("espaço") ->
                "Não há espaço livre suficiente no aparelho. Libere espaço e tente de novo."
            text.contains("não entregou") || text.contains("nao entregou") || text.contains("encoder") ||
                text.contains("codec") || text.contains("unsupported") || text.contains("configure") ->
                "Seu aparelho não conseguiu gerar o vídeo nessa qualidade. Tente uma qualidade menor, como 1080p ou 720p a 30 FPS."
            text.contains("filenotfound") || text.contains("no such file") || text.contains("open failed") ||
                text.contains("permission") ->
                "Não foi possível ler o vídeo ou o áudio escolhido. Escolha o arquivo de novo."
            else -> "Não foi possível criar o vídeo. Tente de novo; se repetir, copie os detalhes abaixo e envie para o suporte."
        }
        return if (detailed.isBlank()) reason else "$reason\n\nDetalhe técnico: ${detailed.take(500)}"
    }

    private fun cancelExport() {
        val state = ExportProgressBus.state.value
        effectPreparationJob?.cancel()
        exporter.cancel()
        progressJob?.cancel()
        ExportProgressBus.update(state.copy(status = ExportServiceStatus.CANCELLED))
        Thread {
            kotlinx.coroutines.runBlocking { UsageStatsStore(applicationContext).recordExportFailure(cancelled = true) }
        }.start()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun notifyProgress(progress: Int, title: String) {
        notificationManager().notify(
            NOTIFICATION_ID,
            buildNotification(progress, title, exportStage(progress), ongoing = true),
        )
    }

    private fun buildNotification(progress: Int, title: String, stage: String, ongoing: Boolean): Notification {
        val openApp = PendingIntent.getActivity(
            this,
            11,
            Intent(this, MainActivity::class.java).apply {
                action = "com.sonusstudios.sonusedit.OPEN_EXPORT"
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val cancel = PendingIntent.getService(
            this,
            12,
            Intent(this, ExportForegroundService::class.java).setAction(ACTION_CANCEL),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("Sonus Edit • $title")
            .setContentText(stage)
            .setContentIntent(openApp)
            .setOnlyAlertOnce(true)
            .setOngoing(ongoing)
            .setProgress(100, progress.coerceIn(0, 100), false)
            .apply {
                if (ongoing) {
                    val icon = android.graphics.drawable.Icon.createWithResource(this@ExportForegroundService, R.mipmap.ic_launcher)
                    addAction(Notification.Action.Builder(icon, "Cancelar", cancel).build())
                }
            }
            .build()
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Exportação de vídeos",
            NotificationManager.IMPORTANCE_LOW,
        ).apply {
            description = "Mostra o progresso da criação de vídeos no Sonus Edit."
            setSound(null, null)
        }
        notificationManager().createNotificationChannel(channel)
    }

    private fun notificationManager(): NotificationManager =
        getSystemService(NotificationManager::class.java)

    private fun stopSelfSafely() {
        stopSelf()
    }

    override fun onDestroy() {
        progressJob?.cancel()
        serviceScope.coroutineContext.cancel()
        super.onDestroy()
    }
}

private fun exportStage(progress: Int): String = when (progress) {
    in 0..9 -> "Preparando mídia…"
    in 10..24 -> "Sincronizando projeto…"
    in 25..49 -> "Montando imagens…"
    in 50..94 -> "Renderizando vídeo…"
    else -> "Salvando na galeria…"
}
