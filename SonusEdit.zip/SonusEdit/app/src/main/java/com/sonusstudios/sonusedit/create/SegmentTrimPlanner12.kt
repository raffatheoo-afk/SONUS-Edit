package com.sonusstudios.sonusedit.create

/** Millisecond-precise manual trim; duration presets remain the default when manualEndMs is null. */
object SegmentTrimPlanner12 {
    /** A restored or manually adjusted trim is protected until the user selects a new source. */
    fun shouldApplySmartStart(enabled: Boolean, trimIsProtected: Boolean): Boolean =
        enabled && !trimIsProtected

    fun initialPlaybackPosition(totalMs: Long, startMs: Long): Long {
        if (totalMs <= 0L) return 0L
        return startMs.coerceIn(0L, (totalMs - 1_000L).coerceAtLeast(0L))
    }

    fun endMs(totalMs: Long, startMs: Long, presetSeconds: Int, untilEnd: Boolean, manualEndMs: Long?): Long {
        if (totalMs <= 0L) return 0L
        val start = startMs.coerceIn(0L, (totalMs - 1_000L).coerceAtLeast(0L))
        val auto = if (untilEnd) totalMs else (start + presetSeconds * 1_000L).coerceAtMost(totalMs)
        return (manualEndMs ?: auto).coerceIn((start + 1_000L).coerceAtMost(totalMs), totalMs)
    }

    fun maxStartMs(totalMs: Long, presetSeconds: Int, untilEnd: Boolean, manualEndMs: Long?): Long {
        if (totalMs <= 1_000L) return 0L
        if (manualEndMs != null) return (manualEndMs.coerceAtMost(totalMs) - 1_000L).coerceAtLeast(0L)
        if (untilEnd) return totalMs - 1_000L
        return (totalMs - presetSeconds * 1_000L).coerceAtLeast(0L)
    }
}
