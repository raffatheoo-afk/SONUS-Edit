package com.sonusstudios.sonusedit.create

import java.text.Normalizer

/** A title is a hint, never a reliable language detector (instrumentals and foreign titles exist). */
object CaptionLanguageHint {
    private val pt = setOf("eu", "te", "amo", "voce", "nao", "meu", "minha", "saudade", "coracao", "vida", "pra", "seu", "sem", "com", "quando", "esqueci", "ultima", "amor", "noite", "hoje", "porque", "sonho")
    private val en = setOf("i", "you", "love", "your", "my", "the", "with", "without", "never", "always", "heart", "dream", "night", "baby", "forever", "stay", "away", "alone", "yesterday", "home", "dont")
    private fun words(value: String): List<String> = Normalizer.normalize(value.lowercase(), Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "")
        .replace(Regex("[^a-z]+"), " ").split(' ').filter { it.isNotBlank() }

    fun fromTitle(title: String): String? {
        val words = words(title)
        if (words.isEmpty()) return null
        val ptCount = words.count { it in pt }
        val enCount = words.count { it in en }
        return when {
            ptCount > enCount && ptCount > 0 -> "pt"
            enCount > ptCount && enCount > 0 -> "en"
            else -> null
        }
    }

    /** Conservative detection from actual singing; title is used only when audio is ambiguous. */
    fun fromTranscription(text: String, titleHint: String? = null): String? {
        val tokens = words(text)
        if (tokens.size < 3) return null
        val portuguese = tokens.count { it in pt }
        val english = tokens.count { it in en }
        val high = maxOf(portuguese, english)
        val low = minOf(portuguese, english)
        val titleAgrees = titleHint == (if (portuguese > english) "pt" else "en")
        if (high < 2 || high <= low || (high - low < 2 && !titleAgrees)) return null
        return if (portuguese > english) "pt" else "en"
    }

    /** Only lock when speech text corroborates a candidate and is not obvious nonsense. */
    fun acceptCandidate(candidate: String, triedText: String, automaticText: String): Boolean {
        val tried = words(triedText)
        if (tried.size < 2) return false
        val dictionary = if (candidate == "pt") pt else en
        val opposite = if (candidate == "pt") en else pt
        val hits = tried.count { it in dictionary }
        val other = tried.count { it in opposite }
        val auto = words(automaticText)
        val autoHits = auto.count { it in dictionary }
        // Compare absolute language evidence and don't discard an equally good automatic result.
        return hits >= 1 && hits >= other && hits.toDouble() / tried.size >= .08 &&
            (hits.toDouble() / tried.size >= autoHits.toDouble() / auto.size.coerceAtLeast(1) - .01)
    }
}
