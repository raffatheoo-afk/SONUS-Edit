package com.sonusstudios.sonusedit.create

import kotlinx.serialization.Serializable

/** Caption looks available since 1.7/code31. The renderer shared by preview and export draws every one of them. */
@Serializable
enum class CaptionStyleId(val label: String, val hint: String, val premiumIllustrative: Boolean = false) {
    CLASSIC("Clássico limpo", "Frase inteira com fade suave"),
    WORD_BY_WORD("Palavra por palavra", "Uma palavra grande por vez"),
    KARAOKE("Karaokê", "A palavra falada muda de cor"),
    POP_IN("Pop-in", "2 a 3 palavras em MAIÚSCULAS"),
    BUILD_UP("Acúmulo", "As palavras surgem e ficam"),
    HIGHLIGHT_BOX("Marca-texto", "Caixa na palavra falada"),
    NEON("Neon", "Brilho na palavra falada"),
    RISE("Subida suave", "A frase sobe com fade"),
    NEWS_BAR("Tarja", "Barra translúcida atrás"),
    CINEMA("Cinema", "Discreto e elegante"),
    TYPEWRITER("Máquina de escrever", "Palavras surgem em sequência", true),
    SLIDE_UP("Deslize", "Texto entra suavemente de baixo", true),
    BOUNCE("Salto", "Palavra ativa com movimento leve", true),
    UNDERLINE("Sublinhado", "Destaque fino na palavra ativa", true),
    CAPSULE("Cápsula", "Palavras em blocos arredondados", true),
    STACKED("Blocos", "Texto em blocos compactos", true),
    SPLIT_HIGHLIGHT("Destaque dividido", "Palavras faladas ganham cor", true),
    GLOW("Brilho suave", "Contorno luminoso controlado", true),
    FADE_WORDS("Palavras suaves", "Entrada progressiva de cada palavra", true),
    ACTIVE_ACCENT("Acento ativo", "Palavra atual recebe destaque", true),
}

/** Vertical position of the caption block; every position stays inside the safe area of 9:16 and 16:9. */
@Serializable
enum class CaptionPosition(val label: String) {
    TOP("Topo"),
    MIDDLE("Meio"),
    BOTTOM("Embaixo"),
}

data class TimedWord(val text: String, val startMs: Long, val endMs: Long)

/**
 * Whisper (whisper-android 1.0.0) only returns phrase timing. Word timing is therefore estimated by
 * sharing the phrase duration between the words by size, with a longer pause after punctuation.
 */
object CaptionWordTimer {
    private val whitespace = Regex("\\s+")

    fun split(text: String, startMs: Long, endMs: Long): List<TimedWord> {
        val tokens = text.split(whitespace).filter { it.isNotBlank() }
        if (tokens.isEmpty()) return emptyList()
        // Nunca estenda a última palavra além do tempo real da frase. Whisper fornece
        // timestamps por frase; mesmo frases muito curtas precisam ser repartidas dentro
        // da janela recebida, não receber um mínimo artificial por palavra.
        val boundedEnd = endMs.coerceAtLeast(startMs + 1L)
        val weights = tokens.map { token ->
            val letters = token.count { it.isLetterOrDigit() }.coerceAtLeast(1)
            val pause = when (token.last()) {
                '.', '!', '?', '…' -> 3.0
                ',', ';', ':' -> 1.5
                else -> 0.0
            }
            letters + 1.5 + pause
        }
        val sum = weights.sum()
        val totalMs = (boundedEnd - startMs).coerceAtLeast(1L)
        // A timestamp window shorter than the number of words cannot represent word-by-word
        // playback at millisecond precision. Preserve the complete phrase as one timed unit.
        if (totalMs < tokens.size.toLong()) {
            return listOf(TimedWord(tokens.joinToString(" "), startMs, boundedEnd))
        }
        var cursor = startMs
        return tokens.mapIndexed { index, token ->
            val remainingWords = tokens.size - index - 1
            val remainingMs = (boundedEnd - cursor).coerceAtLeast(0L)
            val end = if (index == tokens.lastIndex) {
                boundedEnd
            } else if (remainingMs > remainingWords) {
                val proportional = (totalMs.toDouble() * weights[index] / sum).toLong().coerceAtLeast(1L)
                (cursor + proportional).coerceAtMost(boundedEnd - remainingWords)
            } else {
                cursor
            }
            TimedWord(token, cursor, end.coerceAtMost(boundedEnd))
                .also { cursor = end.coerceAtMost(boundedEnd) }
        }
    }
}

/** Manual caption-look helpers. Automatic/dynamic look selection was retired in code03. */
object CaptionStyleSelector {
    fun wordsPerSecond(segments: List<CaptionSegment>): Double? {
        var words = 0
        var speechMs = 0L
        segments.forEach { segment ->
            words += segment.text.trim().split(Regex("\\s+")).count { it.isNotBlank() }
            speechMs += (segment.endMs - segment.startMs).coerceAtLeast(0L)
        }
        return if (speechMs < 2_000L || words == 0) null else words * 1_000.0 / speechMs
    }

    /** The user explicitly taps refresh to choose another visible look. */
    fun refresh(current: CaptionStyleId): CaptionStyleId =
        CaptionStyleId.entries.filter { it != current }.random()
}
