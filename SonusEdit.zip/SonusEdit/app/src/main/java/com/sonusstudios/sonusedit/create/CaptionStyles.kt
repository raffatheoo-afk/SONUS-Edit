package com.sonusstudios.sonusedit.create

import android.content.Context
import kotlinx.serialization.Serializable

/** Caption looks available since 1.7/code31. The renderer shared by preview and export draws every one of them. */
@Serializable
enum class CaptionStyleId(val label: String, val hint: String) {
    CLASSIC("Clássico limpo", "Frase inteira com fade suave"),
    WORD_BY_WORD("Palavra por palavra", "Uma palavra grande por vez"),
    KARAOKE("Karaokê", "A palavra falada muda de cor"),
    POP_IN("Pop-in", "2 a 3 palavras em MAIÚSCULAS"),
    BUILD_UP("Acúmulo", "As palavras surgem e ficam"),
    HIGHLIGHT_BOX("Marca-texto", "Caixa na palavra falada"),
    NEON("Neon", "Brilho na palavra falada"),
    RISE("Subida suave", "A frase sobe com fade"),
    NEWS_BAR("Tarja", "Barra translúcida atrás"),
    CINEMA("Cinema", "Discreto e elegante"),
}

/** Vertical position of the caption block; every position stays inside the safe area of 9:16 and 16:9. */
@Serializable
enum class CaptionPosition(val label: String) {
    TOP("Topo"),
    MIDDLE("Meio"),
    BOTTOM("Embaixo"),
}

data class TimedWord(val text: String, val startMs: Long, val endMs: Long)

/**
 * Whisper (whisper-android 1.0.0) only returns phrase timing. Word timing is therefore estimated by
 * sharing the phrase duration between the words by size, with a longer pause after punctuation.
 */
object CaptionWordTimer {
    private val whitespace = Regex("\\s+")

    fun split(text: String, startMs: Long, endMs: Long): List<TimedWord> {
        val tokens = text.split(whitespace).filter { it.isNotBlank() }
        if (tokens.isEmpty()) return emptyList()
        val total = (endMs - startMs).coerceAtLeast(tokens.size * 90L).toDouble()
        val weights = tokens.map { token ->
            val letters = token.count { it.isLetterOrDigit() }.coerceAtLeast(1)
            val pause = when (token.last()) {
                '.', '!', '?', '…' -> 3.0
                ',', ';', ':' -> 1.5
                else -> 0.0
            }
            letters + 1.5 + pause
        }
        val sum = weights.sum()
        var cursor = startMs.toDouble()
        return tokens.mapIndexed { index, token ->
            val begin = cursor
            cursor += total * weights[index] / sum
            val end = if (index == tokens.lastIndex) startMs + total else cursor
            TimedWord(token, begin.toLong(), end.toLong())
        }
    }
}

/** Chooses a caption look automatically from the speech rhythm and the genre; never repeats the last pick. */
object CaptionStyleSelector {
    private const val PREFS = "sonus_caption_style_code31"
    private val fast = listOf(
        CaptionStyleId.WORD_BY_WORD, CaptionStyleId.POP_IN, CaptionStyleId.KARAOKE,
        CaptionStyleId.HIGHLIGHT_BOX, CaptionStyleId.NEON, CaptionStyleId.BUILD_UP,
    )
    private val calm = listOf(
        CaptionStyleId.CLASSIC, CaptionStyleId.RISE, CaptionStyleId.CINEMA,
        CaptionStyleId.NEWS_BAR, CaptionStyleId.KARAOKE,
    )
    private val balanced = listOf(
        CaptionStyleId.KARAOKE, CaptionStyleId.CLASSIC, CaptionStyleId.RISE, CaptionStyleId.HIGHLIGHT_BOX,
        CaptionStyleId.BUILD_UP, CaptionStyleId.NEON, CaptionStyleId.NEWS_BAR,
    )

    fun wordsPerSecond(segments: List<CaptionSegment>): Double? {
        var words = 0
        var speechMs = 0L
        segments.forEach { segment ->
            words += segment.text.trim().split(Regex("\\s+")).count { it.isNotBlank() }
            speechMs += (segment.endMs - segment.startMs).coerceAtLeast(0L)
        }
        return if (speechMs < 2_000L || words == 0) null else words * 1_000.0 / speechMs
    }

    fun pick(context: Context, preferred: CaptionStyleId?, genre: String?, segments: List<CaptionSegment>): CaptionStyleId {
        if (preferred != null) return preferred
        val text = genre.orEmpty().lowercase()
        val rate = wordsPerSecond(segments)
        val pool = when {
            containsAny(text, "trap", "funk", "rap", "drill") -> fast
            containsAny(text, "católic", "catolic", "gospel", "worship", "românt", "romant", "sofr", "acúst", "acoust") -> calm
            rate != null && rate >= 2.6 -> fast
            rate != null && rate <= 1.5 -> calm
            else -> balanced
        }
        val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val last = prefs.getString("last", null)
        val choices = pool.filter { it.name != last }.ifEmpty { pool }
        val next = choices.random()
        prefs.edit().putString("last", next.name).apply()
        return next
    }

    /** "Atualizar estilo": any other look, chosen at random. */
    fun refresh(current: CaptionStyleId): CaptionStyleId =
        CaptionStyleId.entries.filter { it != current }.random()

    private fun containsAny(text: String, vararg values: String): Boolean = values.any { text.contains(it) }
}
