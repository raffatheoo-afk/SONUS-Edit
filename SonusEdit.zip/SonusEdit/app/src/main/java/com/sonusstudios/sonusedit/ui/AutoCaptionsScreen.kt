package com.sonusstudios.sonusedit.ui

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.StatFs
import android.os.SystemClock
import android.provider.OpenableColumns
import android.view.TextureView
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.sonusstudios.sonusedit.create.AudioSource
import com.sonusstudios.sonusedit.create.AutomationPreferences
import com.sonusstudios.sonusedit.create.AutomationSettings
import com.sonusstudios.sonusedit.create.CaptionEtaEstimator14
import com.sonusstudios.sonusedit.create.CaptionFontPool
import com.sonusstudios.sonusedit.create.CaptionPosition
import com.sonusstudios.sonusedit.create.CaptionSegment
import com.sonusstudios.sonusedit.create.CaptionStyleId
import com.sonusstudios.sonusedit.create.CaptionStyleSelector
import com.sonusstudios.sonusedit.create.CreateProjectDraft
import com.sonusstudios.sonusedit.create.CaptionLookPrefs
import com.sonusstudios.sonusedit.create.ExportResolution
import com.sonusstudios.sonusedit.media.ExportCapabilities02
import com.sonusstudios.sonusedit.create.FilterPresetId
import com.sonusstudios.sonusedit.create.FontPresetId
import com.sonusstudios.sonusedit.create.LyricColorPreset
import com.sonusstudios.sonusedit.create.LyricsPolicy
import com.sonusstudios.sonusedit.create.ProjectAspectRatios
import com.sonusstudios.sonusedit.create.UriPermissionHelper
import com.sonusstudios.sonusedit.create.WhisperCaptionEngine
import com.sonusstudios.sonusedit.designsystem.SonusEditColors
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.min

/** Videos above this length get a heads-up about the long caption sync and export. */
private const val LONG_VIDEO_WARNING_MS = 3L * 60_000L

private enum class AutoCaptionStep { PICK, SYNC, ADJUST, REVIEW }

private data class VideoInfo(
    val displayName: String,
    val durationMs: Long,
    val visualWidth: Int,
    val visualHeight: Int,
    val fps: Float?,
    val sizeBytes: Long?,
    val hasAudio: Boolean,
)

/**
 * Captions for a finished video from the gallery: pick the video, sync the captions, adjust the look and
 * export. The video is exported through the same exporter as every other project (long videos use its
 * chunked mode), with the original frame and audio kept and no particles, filter or signature.
 */
@Composable
fun AutoCaptionsScreen(
    onBack: () -> Unit,
    onExport: (CreateProjectDraft) -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val view = LocalView.current
    val snackbar = remember { SnackbarHostState() }
    val captionEngine = remember { WhisperCaptionEngine(context.applicationContext) }
    val automationPrefs = remember { AutomationPreferences(context.applicationContext) }
    val automation by automationPrefs.values.collectAsState(initial = AutomationSettings())

    var step by remember { mutableStateOf(AutoCaptionStep.PICK) }
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var info by remember { mutableStateOf<VideoInfo?>(null) }
    var loadingInfo by remember { mutableStateOf(false) }
    var pendingWarning by remember { mutableStateOf<Pair<Uri, VideoInfo>?>(null) }

    var captions by remember { mutableStateOf<List<CaptionSegment>>(emptyList()) }
    var captionError by remember { mutableStateOf<String?>(null) }
    var captionProgress by remember { mutableStateOf<WhisperCaptionEngine.Progress?>(null) }
    var captionJob by remember { mutableStateOf<Job?>(null) }
    var captionGeneration by remember { mutableStateOf(0) }
    var captionCompleted by remember { mutableStateOf(false) }
    var etaStartedAtMs by remember { mutableStateOf<Long?>(null) }
    var etaNowMs by remember { mutableStateOf(0L) }
    var etaProcessedAudioMs by remember { mutableStateOf<Long?>(null) }
    var etaSampleElapsedMs by remember { mutableStateOf<Long?>(null) }
    var etaWaitingForModel by remember { mutableStateOf(false) }

    // Remembers the last size, position and hand-picked style (no style picked by hand = "Dinâmico").
    val rememberedStyle = remember { CaptionLookPrefs.manualStyle(context, CaptionLookPrefs.AUTO) }
    var captionStyle by remember { mutableStateOf(rememberedStyle ?: CaptionStyleId.CLASSIC) }
    var dynamicStyle by remember { mutableStateOf(rememberedStyle == null) }
    var sizeScale by remember { mutableStateOf(CaptionLookPrefs.sizeScale(context, CaptionLookPrefs.AUTO)) }
    var positionPercent by remember { mutableStateOf(CaptionLookPrefs.positionPercent(context, CaptionLookPrefs.AUTO)) }
    LaunchedEffect(sizeScale, positionPercent) {
        CaptionLookPrefs.save(context, CaptionLookPrefs.AUTO, sizeScale, positionPercent)
    }
    var font by remember { mutableStateOf<FontPresetId>(CaptionFontPool.approved.random()) }
    var color by remember { mutableStateOf(LyricColorPreset.DYNAMIC) }
    var resolution by remember { mutableStateOf(ExportResolution.P1080) }
    var fps by remember { mutableStateOf(30) }
    // Export keeps the original frame; the size is only adjusted down when this phone's encoder cannot do it.
    var outputSize by remember { mutableStateOf<Pair<Int, Int>?>(null) }

    fun beginSync(uri: Uri, read: VideoInfo) {
        captionJob?.cancel()
        videoUri = uri
        info = read
        captions = emptyList()
        captionError = null
        captionCompleted = false
        captionProgress = WhisperCaptionEngine.Progress("Preparando legenda…")
        etaWaitingForModel = false
        etaProcessedAudioMs = null
        etaSampleElapsedMs = null
        val started = SystemClock.elapsedRealtime()
        etaStartedAtMs = started
        etaNowMs = started
        val capabilities = ExportCapabilities02.probe(context)
        val sizeTier = autoResolution(read)
        val wantedFps = if ((read.fps ?: 30f) >= 50f) 60 else 30
        resolution = sizeTier
        fps = if (wantedFps == 60 && capabilities.supports(sizeTier, 60)) 60 else 30
        val capLongSide = if (capabilities.supports(sizeTier, fps)) Int.MAX_VALUE
        else ExportCapabilities02.longSideOf(capabilities.best(fps))
        outputSize = capabilities.fit(read.visualWidth, read.visualHeight, capLongSide)
        step = AutoCaptionStep.SYNC
        val generationId = captionGeneration + 1
        captionGeneration = generationId
        captionJob = scope.launch {
            try {
                val result = captionEngine.generate(uri, 0L, read.durationMs, titleHint = read.displayName) { progress ->
                    // Async callback may arrive after cancellation; never show stale progress.
                    scope.launch {
                        if (captionGeneration != generationId) return@launch
                        captionProgress = progress
                        val now = SystemClock.elapsedRealtime()
                        if (progress.status.startsWith("Conectando ao motor") || progress.status.startsWith("Baixando Whisper Small")) {
                            // The one-time model download depends on the network; keep it out of the countdown.
                            etaWaitingForModel = true
                        } else if (etaWaitingForModel && (
                                progress.status.startsWith("Preparando áudio") ||
                                    progress.status.startsWith("Preparando legenda longa") ||
                                    progress.status.startsWith("Ouvindo e sincronizando")
                                )) {
                            etaWaitingForModel = false
                            etaStartedAtMs = now
                        }
                        val done = progress.processedAudioMs
                        if (done != null && done > (etaProcessedAudioMs ?: 0L)) {
                            etaProcessedAudioMs = done
                            etaSampleElapsedMs = (now - (etaStartedAtMs ?: now)).coerceAtLeast(0L)
                        }
                    }
                }
                if (!currentCoroutineContext().isActive || captionGeneration != generationId) return@launch
                if (!result.fromCache) {
                    CaptionEtaEstimator14.record(context.applicationContext, read.durationMs, result.processingMs)
                }
                captions = result.segments
                captionCompleted = true
                captionProgress = WhisperCaptionEngine.Progress(
                    if (result.segments.isEmpty()) "Sem voz detectada" else "Letra sincronizada", 100,
                )
                if (result.segments.isNotEmpty()) {
                    if (dynamicStyle) {
                        captionStyle = CaptionStyleSelector.pick(context, automation.preferredCaptionStyle, null, result.segments)
                    }
                    step = AutoCaptionStep.ADJUST
                }
            } catch (_: CancellationException) {
                // The user left the screen or picked another video.
            } catch (error: Exception) {
                if (captionGeneration != generationId) return@launch
                captionError = error.message ?: "Não foi possível gerar a legenda."
                captionProgress = null
            } finally {
                if (captionGeneration == generationId) captionJob = null
            }
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) {
            if (videoUri == null) onBack()
            return@rememberLauncherForActivityResult
        }
        UriPermissionHelper.persistRead(context, uri)
        scope.launch {
            loadingInfo = true
            val read = readVideoInfo(context, uri)
            loadingInfo = false
            when {
                read == null -> {
                    snackbar.showSnackbar("Não foi possível ler este vídeo.")
                    if (videoUri == null) onBack()
                }
                !read.hasAudio -> {
                    snackbar.showSnackbar("Este vídeo não tem áudio para gerar legendas.")
                    if (videoUri == null) onBack()
                }
                read.durationMs > LONG_VIDEO_WARNING_MS -> pendingWarning = uri to read
                else -> beginSync(uri, read)
            }
        }
    }

    // The system gallery/file manager opens right away, as soon as the screen appears.
    LaunchedEffect(Unit) { picker.launch(arrayOf("video/*")) }

    LaunchedEffect(etaStartedAtMs, captionCompleted, captionError) {
        if (etaStartedAtMs != null && !captionCompleted && captionError == null) {
            while (true) {
                etaNowMs = SystemClock.elapsedRealtime()
                delay(1_000L)
            }
        }
    }
    // A long sync must not be interrupted by the screen turning off.
    DisposableEffect(step) {
        view.keepScreenOn = step == AutoCaptionStep.SYNC
        onDispose { view.keepScreenOn = false }
    }
    DisposableEffect(Unit) { onDispose { captionJob?.cancel() } }

    fun goBack() {
        when (step) {
            AutoCaptionStep.PICK -> onBack()
            AutoCaptionStep.SYNC -> {
                captionJob?.cancel()
                captionGeneration += 1
                onBack()
            }
            AutoCaptionStep.ADJUST -> onBack()
            AutoCaptionStep.REVIEW -> step = AutoCaptionStep.ADJUST
        }
    }
    BackHandler { goBack() }

    fun exportBlockedReason(): String? {
        val source = info?.sizeBytes ?: return null
        val free = runCatching { StatFs(context.cacheDir.absolutePath).availableBytes }.getOrNull() ?: return null
        // The render is written to cache, then copied to the gallery: keep room for both copies.
        val needed = (source * 2.2).toLong() + 150L * 1_048_576L
        return if (free < needed) {
            "Espaço insuficiente no aparelho. Libere cerca de ${(needed - free) / 1_048_576L + 1} MB e tente de novo."
        } else null
    }

    fun buildDraft(): CreateProjectDraft? {
        val uri = videoUri ?: return null
        val read = info ?: return null
        val title = read.displayName.ifBlank { "Vídeo" }
        val horizontalCanvas = read.visualWidth.toFloat() / read.visualHeight.toFloat() >= 1.15f
        val size = outputSize ?: (read.visualWidth to read.visualHeight)
        return CreateProjectDraft(
            audioUri = uri.toString(),
            audioTitle = title,
            audioDurationMs = read.durationMs,
            audioSource = AudioSource.LOCAL,
            segmentStartMs = 0L,
            segmentDurationMs = read.durationMs,
            signatureText = "",
            imageUris = listOf(uri.toString()),
            localVideoUris = listOf(uri.toString()),
            fontPreset = font,
            lyricColorPreset = color,
            filterPreset = FilterPresetId.ORIGINAL,
            aspectRatio = if (horizontalCanvas) ProjectAspectRatios.HORIZONTAL else ProjectAspectRatios.VERTICAL,
            imageFadeInMs = 0L,
            imageFadeOutMs = 0L,
            audioFadeInMs = 0L,
            audioFadeOutMs = 0L,
            lyricsPolicy = LyricsPolicy.AUTO,
            captionSegments = captions,
            captionStyle = captionStyle,
            captionSizeScale = sizeScale,
            captionPositionPercent = positionPercent,
            fitFullFrame = true,
            customOutputWidth = size.first,
            customOutputHeight = size.second,
            exportTitle = title,
            exportArtist = "",
            particlesEnabled = false,
            metadataOverlayEnabled = false,
            exportResolution = resolution,
            exportFps = fps,
        )
    }

    var exportMessage by remember { mutableStateOf<String?>(null) }

    Scaffold(
        containerColor = SonusEditColors.Black,
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            if (step == AutoCaptionStep.ADJUST || step == AutoCaptionStep.REVIEW) {
                Row(
                    Modifier.fillMaxWidth().background(Color(0xFF0E1320)).padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    OutlinedButton(onClick = { goBack() }, modifier = Modifier.height(48.dp)) { Text("Voltar") }
                    Button(
                        onClick = {
                            if (step == AutoCaptionStep.ADJUST) {
                                step = AutoCaptionStep.REVIEW
                            } else {
                                val blocked = exportBlockedReason()
                                val draft = buildDraft()
                                if (blocked != null) exportMessage = blocked
                                else if (draft != null) onExport(draft)
                            }
                        },
                        modifier = Modifier.height(48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = SonusEditColors.Violet),
                    ) {
                        Text(if (step == AutoCaptionStep.REVIEW) "EXPORTAR" else "AVANÇAR", fontWeight = FontWeight.Bold)
                    }
                }
            }
        },
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            Column(Modifier.fillMaxSize()) {
                Spacer(Modifier.height(8.dp))
                val read = info
                val uri = videoUri
                when (step) {
                    AutoCaptionStep.PICK -> Column(
                        Modifier.fillMaxSize().padding(24.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Text("Escolha um vídeo da galeria", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text("O Sonus Edit ouve o vídeo, sincroniza e coloca a legenda sozinho.", color = SonusEditColors.TextMuted, fontSize = 12.sp)
                        Spacer(Modifier.height(18.dp))
                        Button(
                            onClick = { picker.launch(arrayOf("video/*")) },
                            colors = ButtonDefaults.buttonColors(containerColor = SonusEditColors.Violet),
                        ) { Text("ESCOLHER VÍDEO", fontWeight = FontWeight.Bold) }
                    }

                    AutoCaptionStep.SYNC -> Column(
                        Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Section18("") {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Letra sincronizada", modifier = Modifier.weight(1f), fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 2)
                                CaptionStatusPill20(
                                    true,
                                    captionJob?.isActive == true && captionError == null,
                                    captionCompleted,
                                    captionError,
                                    if (etaWaitingForModel) null else etaStartedAtMs?.let { started ->
                                        CaptionEtaEstimator14.remainingMs(
                                            totalEstimateMs = CaptionEtaEstimator14.expectedTotalMs(context.applicationContext, read?.durationMs ?: 0L),
                                            durationMs = read?.durationMs ?: 0L,
                                            elapsedMs = (etaNowMs - started).coerceAtLeast(0L),
                                            processedAudioMs = etaProcessedAudioMs,
                                            sampleElapsedMs = etaSampleElapsedMs,
                                        )
                                    },
                                )
                            }
                            if (read != null) {
                                Text(
                                    "${read.displayName} • ${formatTime18(read.durationMs)}",
                                    color = SonusEditColors.TextMuted, fontSize = 11.sp, maxLines = 2,
                                )
                            }
                            val percent = captionProgress?.percent
                            if (captionError == null && !(captionCompleted && captions.isEmpty())) {
                                if (percent != null) {
                                    LinearProgressIndicator(progress = { percent / 100f }, modifier = Modifier.fillMaxWidth())
                                } else {
                                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                                }
                                Text(captionProgress?.status ?: "Ouvindo o vídeo…", color = Color.White, fontSize = 12.sp)
                                Text(
                                    "Mantenha o app aberto: a tela fica ligada enquanto sincroniza.",
                                    color = SonusEditColors.TextMuted, fontSize = 10.sp,
                                )
                            }
                            if (captionError != null) {
                                Text(captionError ?: "", color = Color(0xFFFF7A84), fontSize = 12.sp)
                                Button(
                                    onClick = { if (uri != null && read != null) beginSync(uri, read) },
                                    colors = ButtonDefaults.buttonColors(containerColor = SonusEditColors.Violet),
                                ) { Text("TENTAR DE NOVO", fontWeight = FontWeight.Bold) }
                            }
                            if (captionCompleted && captions.isEmpty()) {
                                Text(
                                    "Nenhuma voz foi detectada neste vídeo, então não há o que legendar.",
                                    color = Color.White, fontSize = 12.sp,
                                )
                                Button(
                                    onClick = { picker.launch(arrayOf("video/*")) },
                                    colors = ButtonDefaults.buttonColors(containerColor = SonusEditColors.Violet),
                                ) { Text("ESCOLHER OUTRO VÍDEO", fontWeight = FontWeight.Bold) }
                            }
                        }
                        OutlinedButton(onClick = { goBack() }, modifier = Modifier.fillMaxWidth()) { Text("CANCELAR") }
                    }

                    AutoCaptionStep.ADJUST -> if (uri != null && read != null) {
                        Column(
                            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 6.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Text("Ajustar legenda", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth())
                            VideoCaptionPreview(
                                uri = uri,
                                durationMs = read.durationMs,
                                aspect = read.visualWidth.toFloat() / read.visualHeight.toFloat(),
                                captions = captions,
                                font = font,
                                color = color,
                                style = captionStyle,
                                sizeScale = sizeScale,
                                positionPercent = positionPercent,
                                textScale = 1.6f,
                                portraitWidth = 150.dp,
                                onRefreshStyle = null,
                            )
                            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("Estilo da legenda • deslize para ver todos", color = SonusEditColors.TextMuted, fontSize = 10.sp)
                                CaptionStylePicker(
                                    selected = captionStyle,
                                    dynamicSelected = dynamicStyle,
                                    font = font,
                                    color = color,
                                    onStyle = {
                                        captionStyle = it
                                        dynamicStyle = false
                                        CaptionLookPrefs.saveManualStyle(context, CaptionLookPrefs.AUTO, it)
                                    },
                                    onDynamic = {
                                        dynamicStyle = true
                                        CaptionLookPrefs.saveManualStyle(context, CaptionLookPrefs.AUTO, null)
                                        captionStyle = CaptionStyleSelector.pick(context, automation.preferredCaptionStyle, null, captions)
                                    },
                                )
                                Text("Fonte", color = SonusEditColors.TextMuted, fontSize = 10.sp)
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    items(CaptionFontPool.approved) { preset ->
                                        FontChoice18(
                                            preset = preset,
                                            selected = preset == font,
                                            favorite = false,
                                            modifier = Modifier.width(78.dp),
                                            onClick = { font = preset },
                                            onLongClick = {},
                                        )
                                    }
                                }
                                Text("Cor", color = SonusEditColors.TextMuted, fontSize = 10.sp)
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                    visibleLyricColors24.forEach { preset ->
                                        LyricColorButton24(preset, selected = preset == color, modifier = Modifier.weight(1f)) { color = preset }
                                    }
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                        }
                    }

                    AutoCaptionStep.REVIEW -> if (uri != null && read != null) {
                        Column(
                            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 6.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            VideoCaptionPreview(
                                uri = uri,
                                durationMs = read.durationMs,
                                aspect = read.visualWidth.toFloat() / read.visualHeight.toFloat(),
                                captions = captions,
                                font = font,
                                color = color,
                                style = captionStyle,
                                sizeScale = sizeScale,
                                positionPercent = positionPercent,
                                textScale = 1f,
                                portraitWidth = 230.dp,
                                onRefreshStyle = {
                                    captionStyle = CaptionStyleSelector.refresh(captionStyle)
                                    dynamicStyle = false
                                },
                            )
                            CaptionAdjustSliders(
                                sizeScale = sizeScale, onSizeScale = { sizeScale = it },
                                positionPercent = positionPercent, onPositionPercent = { positionPercent = it },
                            )
                            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                val shown = outputSize ?: (read.visualWidth to read.visualHeight)
                                Text("Exportação", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.White)
                                Box(
                                    Modifier.fillMaxWidth().height(34.dp)
                                        .background(Color(0xFF3A79A8), RoundedCornerShape(10.dp)),
                                    contentAlignment = Alignment.Center,
                                ) {
                                    Text(
                                        "Original  •  ${shown.first}×${shown.second}  •  $fps FPS",
                                        color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 11.sp, maxLines = 1,
                                    )
                                }
                                if (shown.first != read.visualWidth || shown.second != read.visualHeight) {
                                    Text(
                                        "Ajustado de ${read.visualWidth}×${read.visualHeight} para o que o seu aparelho consegue exportar.",
                                        color = SonusEditColors.TextMuted, fontSize = 10.sp,
                                    )
                                }
                                Text(
                                    "O vídeo mantém o enquadramento e o áudio originais. Só a legenda é adicionada.",
                                    color = SonusEditColors.TextMuted, fontSize = 10.sp,
                                )
                            }
                            Spacer(Modifier.height(8.dp))
                        }
                    }
                }
            }
            if (loadingInfo) ProcessProgressOverlay("Vídeo", "Lendo informações do vídeo…", null)
        }
    }

    pendingWarning?.let { (uri, read) ->
        val expected = CaptionEtaEstimator14.expectedTotalMs(context.applicationContext, read.durationMs)
        AlertDialog(
            onDismissRequest = {
                pendingWarning = null
                if (videoUri == null) onBack()
            },
            title = { Text("Vídeo longo") },
            text = {
                Text(
                    "Este vídeo tem ${formatTime18(read.durationMs)}. Sincronizar as legendas pode levar " +
                        "${formatEstimate(expected)} e a exportação também demora. " +
                        "Mantenha o app aberto durante a sincronização; a tela fica ligada para você.",
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    pendingWarning = null
                    beginSync(uri, read)
                }) { Text("CONTINUAR") }
            },
            dismissButton = {
                TextButton(onClick = {
                    pendingWarning = null
                    picker.launch(arrayOf("video/*"))
                }) { Text("ESCOLHER OUTRO") }
            },
        )
    }

    exportMessage?.let { message ->
        AlertDialog(
            onDismissRequest = { exportMessage = null },
            title = { Text("Não dá para exportar agora") },
            text = { Text(message) },
            confirmButton = { TextButton(onClick = { exportMessage = null }) { Text("OK") } },
        )
    }
}

/** Preview of the real video with the real caption renderer on top (what you see is what gets exported). */
@Composable
private fun VideoCaptionPreview(
    uri: Uri,
    durationMs: Long,
    aspect: Float,
    captions: List<CaptionSegment>,
    font: FontPresetId,
    color: LyricColorPreset,
    style: CaptionStyleId,
    sizeScale: Float,
    positionPercent: Float,
    textScale: Float,
    portraitWidth: Dp,
    onRefreshStyle: (() -> Unit)?,
) {
    val context = LocalContext.current
    val player = remember { ExoPlayer.Builder(context).build() }
    DisposableEffect(player) { onDispose { player.release() } }
    var playing by remember { mutableStateOf(false) }
    var positionMs by remember { mutableStateOf(0L) }
    var interacted by remember { mutableStateOf(false) }

    LaunchedEffect(uri) {
        player.setMediaItem(MediaItem.fromUri(uri))
        player.prepare()
        player.playWhenReady = false
    }
    LaunchedEffect(playing) {
        while (playing) {
            positionMs = player.currentPosition.coerceIn(0L, durationMs)
            if (positionMs >= durationMs - 80L || player.playbackState == Player.STATE_ENDED) {
                player.pause()
                player.seekTo(0L)
                positionMs = 0L
                playing = false
                break
            }
            delay(60L)
        }
    }
    // Until the user plays or scrubs, the first caption loops so every look can be seen moving.
    LaunchedEffect(style) { interacted = false }
    val demoMs by produceState(0L, style, interacted) {
        val began = System.currentTimeMillis()
        while (!interacted) {
            value = System.currentTimeMillis() - began
            delay(50L)
        }
    }
    val first = captions.firstOrNull()
    val captionTimeMs = if (!interacted && first != null) {
        val length = (first.endMs - first.startMs).coerceAtLeast(800L)
        first.startMs + demoMs % (length + 900L)
    } else positionMs

    val horizontal = aspect >= 1f
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Box(
            (if (horizontal) Modifier.fillMaxWidth() else Modifier.width(portraitWidth))
                .aspectRatio(aspect.coerceIn(0.3f, 3f))
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF050711)),
        ) {
            AndroidView(
                factory = { ctx -> TextureView(ctx).also { player.setVideoTextureView(it) } },
                modifier = Modifier.fillMaxSize(),
            )
            CaptionOverlayCanvas(
                captions = captions,
                timeMs = captionTimeMs,
                font = font,
                color = color,
                style = style,
                position = CaptionPosition.MIDDLE,
                modifier = Modifier.fillMaxSize(),
                textScale = textScale,
                sizeScale = sizeScale,
                positionPercent = positionPercent,
            )
            Text(
                style.label,
                Modifier.align(Alignment.BottomCenter).padding(bottom = 3.dp),
                color = Color.White.copy(alpha = .8f),
                fontSize = 8.sp,
                maxLines = 1,
            )
            if (onRefreshStyle != null) {
                Row(
                    Modifier
                        .align(Alignment.TopEnd)
                        .padding(5.dp)
                        .background(Color(0xAA000000), RoundedCornerShape(10.dp))
                        .clickable { onRefreshStyle() }
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Default.Refresh, null, Modifier.size(12.dp), tint = SonusEditColors.Cyan)
                    Text(" ATUALIZAR ESTILO", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                }
            }
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(
                onClick = {
                    interacted = true
                    if (playing) {
                        player.pause()
                        playing = false
                    } else {
                        if (positionMs >= durationMs - 100L) {
                            positionMs = 0L
                            player.seekTo(0L)
                        }
                        player.play()
                        playing = true
                    }
                },
                modifier = Modifier.size(34.dp),
            ) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = SonusEditColors.Cyan) }
            Slider(
                value = positionMs.toFloat(),
                onValueChange = {
                    interacted = true
                    val next = it.toLong().coerceIn(0L, durationMs.coerceAtLeast(1L))
                    positionMs = next
                    player.seekTo(next)
                },
                valueRange = 0f..durationMs.coerceAtLeast(1L).toFloat(),
                modifier = Modifier.weight(1f).height(28.dp),
            )
            Text(formatTime18(positionMs), color = SonusEditColors.TextMuted, fontSize = 9.sp, modifier = Modifier.width(40.dp))
        }
    }
}

private suspend fun readVideoInfo(context: Context, uri: Uri): VideoInfo? = withContext(Dispatchers.IO) {
    val retriever = MediaMetadataRetriever()
    try {
        retriever.setDataSource(context, uri)
        val duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        val rawW = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
        val rawH = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
        val rotation = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
        val hasAudio = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO) == "yes"
        val frames = if (Build.VERSION.SDK_INT >= 28) {
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_FRAME_COUNT)?.toLongOrNull()
        } else null
        val fps = if (frames != null && frames > 0L && duration > 0L) {
            frames * 1_000f / duration
        } else {
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_CAPTURE_FRAMERATE)?.toFloatOrNull()
        }
        if (duration <= 0L || rawW <= 0 || rawH <= 0) return@withContext null
        var name = "Vídeo"
        var size: Long? = null
        context.contentResolver.query(
            uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null,
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (nameIndex >= 0) name = cursor.getString(nameIndex) ?: name
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) size = cursor.getLong(sizeIndex)
            }
        }
        val rotated = rotation % 180 != 0
        VideoInfo(
            displayName = name.substringBeforeLast('.', name),
            durationMs = duration,
            visualWidth = if (rotated) rawH else rawW,
            visualHeight = if (rotated) rawW else rawH,
            fps = fps,
            sizeBytes = size,
            hasAudio = hasAudio,
        )
    } catch (_: Throwable) {
        null
    } finally {
        runCatching { retriever.release() }
    }
}

/** Never upscales: 720p for small videos, 1080p for full HD, 2K above that. */
private fun autoResolution(info: VideoInfo): ExportResolution {
    val shortSide = min(info.visualWidth, info.visualHeight)
    return when {
        shortSide <= 900 -> ExportResolution.P720
        shortSide <= 1300 -> ExportResolution.P1080
        else -> ExportResolution.P2K
    }
}

private fun formatEstimate(ms: Long): String {
    val minutes = ((ms + 59_999L) / 60_000L).coerceAtLeast(1L)
    return if (minutes >= 90L) "cerca de ${minutes / 60L} h ${minutes % 60L} min" else "cerca de $minutes min"
}
