package com.sonusstudios.sonusedit.create

import android.content.Context
import android.util.Log
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URI
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * SONUS Link Engine — lightweight, on-device transport for authorized direct media URLs.
 *
 * Direct media URLs are transferred with Android/JVM networking. Recognized platform pages are
 * delegated to the separately hosted SONUS Cobalt Gateway; the app bundles no extractor binaries.
 */
internal class SonusLinkEngine(context: Context) {
    data class DownloadResult(
        val file: File,
        val normalizedUrl: String,
        val providerLabel: String,
        val displayTitle: String,
        val usageSummary: String? = null,
    )

    data class EngineProgress(
        val status: String,
        val percent: Int? = null,
        val processId: String,
    )

    private val appContext = context.applicationContext
    private val cacheRoot = File(appContext.cacheDir, LinkAudioImporter.CACHE_FOLDER).apply { mkdirs() }
    private val activeConnections = ConcurrentHashMap<String, HttpURLConnection>()
    private val cobaltClient = CobaltGatewayClient(appContext, cacheRoot, activeConnections)

    suspend fun prewarm() = withContext(Dispatchers.IO) {
        if (!cacheRoot.exists() && !cacheRoot.mkdirs()) {
            throw IOException("Não foi possível preparar o armazenamento temporário do Link.")
        }
        cleanupStaleFiles()
    }

    fun currentCobaltUsageSummary(): String = cobaltClient.currentUsageSummary()

    suspend fun syncCobaltUsageSummary(): String = cobaltClient.syncUsageSummary()

    suspend fun download(
        rawUrl: String,
        onProgress: (EngineProgress) -> Unit,
    ): DownloadResult = withContext(Dispatchers.IO) {
        val normalized = normalizeUrl(rawUrl)
        val uri = parseHttpUri(normalized)
        val source = SonusLinkSourceClassifier.classify(uri)
        if (source.isPlatformPage) {
            val cobalt = cobaltClient.download(normalized, source.label) { status, percent, processId ->
                onProgress(EngineProgress(status, percent, processId))
            }
            return@withContext DownloadResult(
                file = cobalt.file,
                normalizedUrl = cobalt.normalizedUrl,
                providerLabel = cobalt.providerLabel,
                displayTitle = cobalt.displayTitle,
                usageSummary = cobalt.usageSummary,
            )
        }
        // Do not reject by hostname alone. Some authorized share URLs redirect to a direct
        // downloadable media resource. Follow ordinary HTTPS redirects and decide from the final
        // response (MIME type + payload), never by scraping or parsing a platform page.
        // For unknown hosts, an extension is only a hint: the HTTP MIME type and payload are
        // checked below before any file is retained.
        cleanupStaleFiles()
        val processId = "sonus_link_${UUID.randomUUID()}"
        onProgress(EngineProgress("Conectando à fonte…", processId = processId))

        var connection: HttpURLConnection? = null
        var outputFile: File? = null
        var completed = false
        try {
            val activeConnection = (URI.create(normalized).toURL().openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = CONNECT_TIMEOUT_MS
                readTimeout = READ_TIMEOUT_MS
                instanceFollowRedirects = true
                useCaches = false
                setRequestProperty("User-Agent", USER_AGENT)
                setRequestProperty("Accept", "audio/*,video/*,application/octet-stream;q=0.9,*/*;q=0.5")
                setRequestProperty("Accept-Encoding", "identity")
            }
            connection = activeConnection
            activeConnections[processId] = activeConnection
            activeConnection.connect()

            val responseCode = activeConnection.responseCode
            if (responseCode !in 200..299) {
                val retryable = responseCode == 408 || responseCode == 425 || responseCode == 429 || responseCode >= 500
                val reason = when {
                    source.isPlatformPage && responseCode in setOf(401, 403) ->
                        "${source.label} não disponibilizou um arquivo de mídia diretamente para este link (HTTP $responseCode). Use a opção permitida pela plataforma para salvar/compartilhar o vídeo e selecione o arquivo no SONUS."
                    responseCode == 401 || responseCode == 403 ->
                        "A origem recusou o acesso ao arquivo ($responseCode). Verifique as permissões do link."
                    responseCode == 404 -> "O arquivo não foi encontrado. Confira o endereço compartilhado."
                    else -> "A origem respondeu com erro HTTP $responseCode."
                }
                throw LinkImportFailure(reason, retryable, suggestLocalMedia = source.isPlatformPage)
            }

            val finalUri = runCatching { URI.create(activeConnection.url.toString()) }.getOrNull()
                ?: throw LinkImportFailure("A origem redirecionou para um endereço inválido.")
            if (!finalUri.scheme.equals("https", ignoreCase = true) || finalUri.userInfo != null) {
                throw LinkImportFailure("O redirecionamento final não manteve uma conexão HTTPS segura.", suggestLocalMedia = source.isPlatformPage)
            }
            val contentType = activeConnection.contentType.orEmpty().substringBefore(';').trim().lowercase()
            val dispositionExtension = extensionFromDisposition(activeConnection.getHeaderField("Content-Disposition"))
            val pathExtension = extensionFromPath(finalUri.path) ?: dispositionExtension
            if (contentType.contains("text/html") || contentType.contains("xhtml")) {
                val message = if (source.isPlatformPage) {
                    "${source.label} abriu uma página, não entregou o arquivo de mídia. Use a opção permitida pela plataforma para salvar/compartilhar o vídeo e selecione o arquivo no SONUS."
                } else {
                    "Este endereço abriu uma página da web, não um arquivo de áudio ou vídeo direto."
                }
                throw LinkImportFailure(message, suggestLocalMedia = source.isPlatformPage)
            }
            val extension = resolveExtension(contentType, pathExtension)
            if (extension == null) {
                val message = if (source.isPlatformPage) {
                    "${source.label} não entregou um arquivo de áudio/vídeo compatível. Salve/compartilhe a mídia pela opção permitida na plataforma e selecione o arquivo no SONUS."
                } else {
                    "A origem não forneceu um formato de áudio/vídeo compatível com o SONUS."
                }
                throw LinkImportFailure(message, suggestLocalMedia = source.isPlatformPage)
            }

            val contentLength = activeConnection.contentLengthLong
            if (contentLength == 0L) throw LinkImportFailure("O arquivo recebido está vazio.")
            if (contentLength > 0L && contentLength > cacheRoot.usableSpace.coerceAtLeast(0L) - MIN_FREE_SPACE_BYTES) {
                throw LinkImportFailure("Não há espaço livre suficiente para importar este arquivo temporariamente.")
            }

            val token = "link_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(8)}"
            outputFile = File(cacheRoot, "$token.$extension")
            onProgress(EngineProgress("Obtendo arquivo de mídia…", processId = processId))

            val total = contentLength.takeIf { it > 0L } ?: -1L
            var copied = 0L
            BufferedInputStream(activeConnection.inputStream).use { input ->
                input.mark(SNIFF_BUFFER_SIZE)
                val prefix = ByteArray(SNIFF_BUFFER_SIZE)
                val prefixLength = input.read(prefix).coerceAtLeast(0)
                input.reset()
                if (looksLikeHtml(prefix, prefixLength)) {
                    val message = if (source.isPlatformPage) {
                        "${source.label} retornou uma página em vez do arquivo de mídia. Salve/compartilhe o vídeo pela opção permitida na plataforma e selecione o arquivo no SONUS."
                    } else {
                        "A origem retornou uma página HTML em vez do arquivo de mídia."
                    }
                    throw LinkImportFailure(message, suggestLocalMedia = source.isPlatformPage)
                }
                FileOutputStream(outputFile).use { output ->
                    val buffer = ByteArray(BUFFER_SIZE)
                    var lastReported = -1
                    while (true) {
                        val count = input.read(buffer)
                        if (count < 0) break
                        val availableAfterReserve = cacheRoot.usableSpace.coerceAtLeast(0L) - MIN_FREE_SPACE_BYTES
                        if (count.toLong() > availableAfterReserve) {
                            throw LinkImportFailure("O espaço livre ficou insuficiente durante a importação.")
                        }
                        output.write(buffer, 0, count)
                        copied += count
                        if (total > 0L) {
                            val percent = ((copied * 100L) / total).toInt().coerceIn(0, 99)
                            if (percent != lastReported) {
                                lastReported = percent
                                onProgress(EngineProgress("Baixando mídia…", percent, processId))
                            }
                        }
                    }
                    output.fd.sync()
                }
            }
            if (!outputFile.isFile || outputFile.length() <= 0L) {
                throw LinkImportFailure("O download terminou sem produzir um arquivo utilizável.", retryable = true)
            }
            if (total > 0L && outputFile.length() != total) {
                throw LinkImportFailure("O download foi interrompido antes de receber o arquivo completo.", retryable = true)
            }

            val displayTitle = finalUri.path.substringAfterLast('/').takeIf { it.isNotBlank() }
                ?.substringBeforeLast('.')?.replace('_', ' ')?.take(120)
                ?.ifBlank { "Áudio importado" } ?: "Áudio importado"
            onProgress(EngineProgress("Validando mídia…", 100, processId))
            completed = true
            DownloadResult(outputFile, normalized, source.label, displayTitle)
        } catch (error: LinkImportFailure) {
            outputFile?.delete()
            throw error
        } catch (error: SocketTimeoutException) {
            outputFile?.delete()
            throw LinkImportFailure("A conexão demorou demais para responder. Tente novamente.", retryable = true, cause = error, suggestLocalMedia = source.isPlatformPage)
        } catch (error: IOException) {
            outputFile?.delete()
            Log.w(TAG, "Direct media transfer failed: ${error.javaClass.simpleName}")
            throw LinkImportFailure("Falha de rede ao receber o arquivo. Verifique sua conexão e tente novamente.", retryable = true, cause = error, suggestLocalMedia = source.isPlatformPage)
        } finally {
            activeConnections.remove(processId)
            if (!completed) runCatching { outputFile?.delete() }
            runCatching { connection?.disconnect() }
        }
    }

    fun cancel(processId: String?) {
        if (processId.isNullOrBlank()) return
        activeConnections.remove(processId)?.let { runCatching { it.disconnect() } }
    }

    private fun cleanupStaleFiles() {
        val cutoff = System.currentTimeMillis() - CACHE_MAX_AGE_MS
        cacheRoot.listFiles().orEmpty().filter { it.isFile && it.lastModified() < cutoff }
            .forEach { runCatching { it.delete() } }
    }

    private fun normalizeUrl(value: String): String {
        val raw = value.trim()
        if (raw.isBlank()) throw LinkImportFailure("Cole um link para importar.")
        val candidate = if (raw.startsWith("http://", true) || raw.startsWith("https://", true)) raw else "https://$raw"
        val uri = parseHttpUri(candidate)
        if (uri.userInfo != null) throw LinkImportFailure("O link não pode conter credenciais embutidas.")
        return uri.toASCIIString().substringBefore('#')
    }

    private fun parseHttpUri(value: String): URI {
        val uri = runCatching { URI.create(value) }.getOrNull()
            ?: throw LinkImportFailure("Cole um endereço válido começando com http:// ou https://.")
        if (uri.scheme?.lowercase() != "https" || uri.host.isNullOrBlank()) {
            throw LinkImportFailure("Por segurança, o SONUS aceita links diretos somente com HTTPS.")
        }
        return uri
    }

    private fun extensionFromPath(path: String?): String? {
        val ext = path.orEmpty().substringAfterLast('.', "").lowercase()
        return ext.takeIf { it in SUPPORTED_EXTENSIONS }
    }

    private fun extensionFromDisposition(header: String?): String? {
        val filename = header.orEmpty().split(';')
            .firstOrNull { it.trim().startsWith("filename=", ignoreCase = true) }
            ?.substringAfter('=')?.trim()?.removeSurrounding("\"")?.removeSurrounding("'")
        return extensionFromPath(filename)
    }

    private fun looksLikeHtml(prefix: ByteArray, length: Int): Boolean {
        if (length <= 0) return false
        val sample = prefix.copyOfRange(0, length).toString(Charsets.UTF_8)
            .removePrefix("\uFEFF").trimStart().lowercase()
        return sample.startsWith("<!doctype html") || sample.startsWith("<html") ||
            sample.startsWith("<head") || sample.startsWith("<body")
    }

    private fun resolveExtension(contentType: String, pathExtension: String?): String? {
        if (contentType.startsWith("audio/")) {
            return MIME_EXTENSIONS[contentType] ?: pathExtension
        }
        if (contentType.startsWith("video/")) {
            return MIME_EXTENSIONS[contentType] ?: pathExtension
        }
        if (contentType == "application/octet-stream" || contentType.isBlank()) {
            return pathExtension
        }
        return pathExtension?.takeIf { contentType in GENERIC_MEDIA_MIMES }
    }

    companion object {
        private const val TAG = "SONUS-LinkEngine"
        private const val USER_AGENT = "SONUS-Edit/1.0.7 (Android; direct-media-import)"
        private const val CONNECT_TIMEOUT_MS = 20_000
        private const val READ_TIMEOUT_MS = 30_000
        private const val BUFFER_SIZE = 64 * 1024
        private const val SNIFF_BUFFER_SIZE = 512
        private const val MIN_FREE_SPACE_BYTES = 16L * 1024L * 1024L
        private const val CACHE_MAX_AGE_MS = 24L * 60L * 60L * 1_000L

        private val SUPPORTED_EXTENSIONS = setOf(
            "m4a", "mp3", "aac", "wav", "ogg", "opus", "flac", "amr",
            "mp4", "m4v", "mov", "webm", "mkv", "3gp", "ts", "mpeg", "mpg",
        )
        private val MIME_EXTENSIONS = mapOf(
            "audio/mp4" to "m4a", "audio/x-m4a" to "m4a", "audio/mpeg" to "mp3",
            "audio/aac" to "aac", "audio/wav" to "wav", "audio/x-wav" to "wav",
            "audio/ogg" to "ogg", "audio/opus" to "opus", "audio/flac" to "flac",
            "video/mp4" to "mp4", "video/quicktime" to "mov", "video/webm" to "webm",
            "video/x-matroska" to "mkv", "video/3gpp" to "3gp", "video/mp2t" to "ts",
        )
        private val GENERIC_MEDIA_MIMES = setOf("application/octet-stream", "binary/octet-stream")
    }
}

internal data class SonusLinkSource(
    val label: String,
    val isPlatformPage: Boolean,
    val looksLikeDirectMedia: Boolean,
)

/** Pure URL classification shared by the resolver and regression tests. */
internal object SonusLinkSourceClassifier {
    // Domains mirror Cobalt's public service matrix. A recognized host is routed to our
    // self-hosted gateway; the upstream decides whether that service can provide audio-only.
    private val platformHosts = mapOf(
        "youtube.com" to "YouTube", "youtu.be" to "YouTube", "youtube-nocookie.com" to "YouTube",
        "youtube.com.br" to "YouTube", "tiktok.com" to "TikTok", "instagram.com" to "Instagram",
        "instagr.am" to "Instagram", "facebook.com" to "Facebook", "fb.watch" to "Facebook",
        "soundcloud.com" to "SoundCloud", "vimeo.com" to "Vimeo", "dailymotion.com" to "Dailymotion",
        "x.com" to "X", "twitter.com" to "X", "reddit.com" to "Reddit", "redd.it" to "Reddit",
        "twitch.tv" to "Twitch", "streamable.com" to "Streamable", "bilibili.com" to "Bilibili",
        "bilibili.tv" to "Bilibili", "bsky.app" to "Bluesky", "bluesky.app" to "Bluesky",
        "loom.com" to "Loom", "newgrounds.com" to "Newgrounds", "ok.ru" to "OK.ru",
        "pinterest.com" to "Pinterest", "pin.it" to "Pinterest", "rutube.ru" to "Rutube",
        "snapchat.com" to "Snapchat", "tumblr.com" to "Tumblr", "vk.com" to "VK",
    )
    private val mediaExtensions = setOf(
        "m4a", "mp3", "aac", "wav", "ogg", "opus", "flac", "amr",
        "mp4", "m4v", "mov", "webm", "mkv", "3gp", "ts", "mpeg", "mpg",
    )

    fun classify(uri: URI): SonusLinkSource {
        val host = uri.host.orEmpty().lowercase().removePrefix("www.")
        val platformLabel = if (host == "music.youtube.com") "YouTube Music" else {
            platformHosts.entries.firstOrNull { (domain, _) -> host == domain || host.endsWith(".$domain") }?.value
        }
        val extension = uri.path.orEmpty().substringAfterLast('.', "").lowercase()
        val direct = extension in mediaExtensions
        return SonusLinkSource(
            label = platformLabel ?: host.ifBlank { "Link" },
            isPlatformPage = platformLabel != null,
            looksLikeDirectMedia = direct,
        )
    }
}

internal class LinkImportFailure(
    message: String,
    val retryable: Boolean = false,
    cause: Throwable? = null,
    /** True when selecting a user-provided/shared media file is the actionable fallback. */
    val suggestLocalMedia: Boolean = false,
) : IOException(message, cause)
