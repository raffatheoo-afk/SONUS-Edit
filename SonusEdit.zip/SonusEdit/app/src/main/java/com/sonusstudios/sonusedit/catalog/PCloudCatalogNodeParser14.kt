package com.sonusstudios.sonusedit.catalog

/** pCloud showpublink encodes isfolder as either a boolean or numeric/string 1/0. */
internal object PCloudCatalogNodeParser14 {
    fun isFolder(rawIsFolder: String?, hasContentsArray: Boolean): Boolean {
        val flag = rawIsFolder?.trim()?.lowercase()
        return flag == "1" || flag == "true" || flag == "yes" || hasContentsArray
    }

    fun isValidRoot(rawIsFolder: String?, hasContentsArray: Boolean, hasFileId: Boolean): Boolean {
        val folder = isFolder(rawIsFolder, hasContentsArray)
        return if (folder) hasContentsArray else hasFileId || hasContentsArray
    }
}
