package com.sonusstudios.sonusedit.ui

import com.sonusstudios.sonusedit.create.TrimPreviewPlanner04

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.sonusstudios.sonusedit.create.AudioDurationProbe13
import com.sonusstudios.sonusedit.create.GalleryQueryResultGate13
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.SystemClock
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.FactCheck
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.blur
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.sonusstudios.sonusedit.R
import com.sonusstudios.sonusedit.catalog.PCloudAsset
import com.sonusstudios.sonusedit.catalog.SonusPublicCatalogs
import com.sonusstudios.sonusedit.catalog.PCloudCatalogRepository
import com.sonusstudios.sonusedit.catalog.PCloudHorizontalImageRepository
import com.sonusstudios.sonusedit.catalog.PCloudImageRepository
import com.sonusstudios.sonusedit.catalog.PCloudMusicRepository
import com.sonusstudios.sonusedit.catalog.StreamHistoryStore
import com.sonusstudios.sonusedit.catalog.StreamMetadataStore
import com.sonusstudios.sonusedit.catalog.StreamSuggestionEngine
import com.sonusstudios.sonusedit.create.AudioMetadata
import com.sonusstudios.sonusedit.create.AudioMetadataReader
import com.sonusstudios.sonusedit.create.AudioSource
import com.sonusstudios.sonusedit.create.AutomationPlanner
import com.sonusstudios.sonusedit.create.AutomationRotationSelector
import com.sonusstudios.sonusedit.create.AutomationPreferences
import com.sonusstudios.sonusedit.create.AutomationSettings
import com.sonusstudios.sonusedit.create.CaptionFontPool
import com.sonusstudios.sonusedit.create.CaptionLookPrefs
import com.sonusstudios.sonusedit.create.CaptionPosition
import com.sonusstudios.sonusedit.create.CaptionStyleId
import com.sonusstudios.sonusedit.create.CaptionStyleSelector
import com.sonusstudios.sonusedit.create.CaptionSegment
import com.sonusstudios.sonusedit.create.CaptionEtaEstimator13
import com.sonusstudios.sonusedit.create.CaptionEtaEstimator14
import com.sonusstudios.sonusedit.create.CaptionProgressEstimator13
import com.sonusstudios.sonusedit.create.CreateProjectDraft
import com.sonusstudios.sonusedit.create.CreationDraftSnapshot
import com.sonusstudios.sonusedit.create.CreationDraftStore
import com.sonusstudios.sonusedit.create.DurationPreset
import com.sonusstudios.sonusedit.create.SegmentTrimPlanner12
import com.sonusstudios.sonusedit.create.EditPreferences
import com.sonusstudios.sonusedit.create.ExportResolution
import com.sonusstudios.sonusedit.create.FilterPresetId
import com.sonusstudios.sonusedit.create.FontPresetId
import com.sonusstudios.sonusedit.create.effective
import com.sonusstudios.sonusedit.create.LinkAudioImporter
import com.sonusstudios.sonusedit.create.LyricColorPreset
import com.sonusstudios.sonusedit.create.LyricColorPalette24
import com.sonusstudios.sonusedit.create.MediaDistributionPlanner
import com.sonusstudios.sonusedit.create.ProjectAspectRatios
import com.sonusstudios.sonusedit.create.SavedEditPreferences
import com.sonusstudios.sonusedit.create.SignatureColorPreset
import com.sonusstudios.sonusedit.create.SignatureFontPreset
import com.sonusstudios.sonusedit.create.SmartImageSelector
import com.sonusstudios.sonusedit.create.MusicImageKeywordCatalog
import com.sonusstudios.sonusedit.create.ExportMetadataPolicy
import com.sonusstudios.sonusedit.create.ImageSelectionHistoryStore
import com.sonusstudios.sonusedit.create.ImageCooldownAvailability
import com.sonusstudios.sonusedit.create.VisualTransitionPreferences
import com.sonusstudios.sonusedit.create.UriPermissionHelper
import com.sonusstudios.sonusedit.create.VideoAudioSourceInspector
import com.sonusstudios.sonusedit.create.WhisperCaptionEngine
import com.sonusstudios.sonusedit.designsystem.SonusEditColors
import com.sonusstudios.sonusedit.integration.IncomingIntentRouter
import com.sonusstudios.sonusedit.media.AutomaticEffectSelector
import com.sonusstudios.sonusedit.media.EffectIds
import com.sonusstudios.sonusedit.media.ExportCapabilities02
import com.sonusstudios.sonusedit.media.PCloudEffectLibrary
import com.sonusstudios.sonusedit.media.SmartStartResolver
import java.net.HttpURLConnection
import java.net.URI
import java.io.File
import java.security.MessageDigest
import java.text.Normalizer
import kotlin.math.roundToInt
import kotlin.random.Random
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.isActive
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json

private enum class CreateStep18(val label: String) { MUSIC("Música"), IMAGES("Imagens"), STYLE("Estilo"), REVIEW("Revisão") }
private val freeFilters18 = listOf(
    FilterPresetId.ORIGINAL, FilterPresetId.NIGHT_CITY, FilterPresetId.NATURAL_PLUS,
    FilterPresetId.GOLDEN, FilterPresetId.SPRING, FilterPresetId.BLACK_AND_WHITE,
    FilterPresetId.CINEMATIC, FilterPresetId.SUNSET, FilterPresetId.SOFT_LIGHT,
    FilterPresetId.WARM_NATURAL, FilterPresetId.COOL_NATURAL, FilterPresetId.SOFT_CONTRAST,
    FilterPresetId.CINEMA_CLEAN, FilterPresetId.CLEAN_NIGHT, FilterPresetId.PASTEL_NATURAL,
)
private val premiumFilters18 = listOf(
    FilterPresetId.STUDIO_FILM, FilterPresetId.PORTRAIT_GLOW, FilterPresetId.GOLDEN_HOUR,
    FilterPresetId.TEAL_ORANGE, FilterPresetId.MOODY_BLUE, FilterPresetId.SOFT_MATTE,
    FilterPresetId.VIBRANT_POP, FilterPresetId.WARM_FILM, FilterPresetId.CRISP_HDR,
    FilterPresetId.DREAM_LIGHT,
)
internal val visibleLyricColors24 = LyricColorPreset.entries.toList()
private val musicExt18 = setOf("mp3", "wav", "flac", "m4a", "aac", "ogg", "opus")
private val imageExt18 = setOf("jpg", "jpeg", "png", "webp")
private val videoExt18 = setOf("mp4", "m4v", "mov", "webm", "mkv", "3gp")
private val galleryMediaExt18 = imageExt18 + videoExt18
// Keep remote thumbnail decode/network work bounded on entry-level Android devices.
private val galleryThumbnailSemaphore18 = Semaphore(2)
private val gallerySelectionSemaphore18 = Semaphore(2)

@Composable
fun CreateFlowScreen(
    incomingRoute: IncomingIntentRouter.Route?,
    openLinkOnStart: Boolean = false,
    resumeDraft: CreationDraftSnapshot? = null,
    onInitialSyncFinished: () -> Unit = {},
    onBack: () -> Unit,
    onCreateDraft: (CreateProjectDraft) -> Unit,
) {
    val context = LocalContext.current
    val musicImageKeywordCatalog = remember(context.applicationContext) {
        runCatching {
            context.assets.open("music_image_keywords.txt").bufferedReader().use { reader ->
                MusicImageKeywordCatalog.parse(reader.readText())
            }
        }.getOrElse { MusicImageKeywordCatalog.empty() }
    }
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    val editPrefs = remember { EditPreferences(context.applicationContext) }
    val savedPrefs by editPrefs.values.collectAsState(initial = SavedEditPreferences())
    val automationPrefs = remember { AutomationPreferences(context.applicationContext) }
    val automation by automationPrefs.values.collectAsState(initial = AutomationSettings())
    val musicRepo = remember { PCloudMusicRepository(context.applicationContext) }
    val verticalImageRepo = remember { PCloudImageRepository(context.applicationContext) }
    val horizontalImageRepo = remember { PCloudHorizontalImageRepository(context.applicationContext) }
    val metadataStore = remember { StreamMetadataStore(context.applicationContext) }
    val streamHistory = remember { StreamHistoryStore(context.applicationContext) }
    val effectSelector = remember { AutomaticEffectSelector(context.applicationContext) }
    val cloudEffectLibrary = remember { PCloudEffectLibrary(context.applicationContext) }
    val linkImporter = remember { LinkAudioImporter(context.applicationContext) }
    val captionEngine = remember { WhisperCaptionEngine(context.applicationContext) }
    val rotationSelector = remember { AutomationRotationSelector(context.applicationContext) }
    val imageHistoryStore = remember { ImageSelectionHistoryStore(context.applicationContext) }
    val transitionPreferences = remember { VisualTransitionPreferences(context.applicationContext) }
    // CODE05 font pool restored: ten bundled typefaces plus the neutral Sans-serif option.
    val randomOpeningFont = remember { CaptionFontPool.approved.random() }
    val draftStore = remember { CreationDraftStore(context.applicationContext) }
    val directLinkMode = remember(openLinkOnStart, resumeDraft) { openLinkOnStart && resumeDraft == null }

    var step by remember(resumeDraft) { mutableStateOf(CreateStep18.entries.getOrElse(resumeDraft?.stepOrdinal ?: 0) { CreateStep18.MUSIC }) }
    var audioUri by remember(resumeDraft) { mutableStateOf(resumeDraft?.audioUri?.let(Uri::parse)) }
    var audioSource by remember(resumeDraft, openLinkOnStart) {
        mutableStateOf(resumeDraft?.audioSource ?: if (openLinkOnStart) AudioSource.LINK else AudioSource.LOCAL)
    }
    var selectedStreamAsset by remember { mutableStateOf<PCloudAsset?>(null) }
    var streamCatalog by remember { mutableStateOf<List<PCloudAsset>>(emptyList()) }
    var showStreamBrowser by remember { mutableStateOf(false) }
    var streamSearch by remember { mutableStateOf("") }
    var streamMetadataRevision by remember { mutableStateOf(0) }
    var streamIndexJob by remember { mutableStateOf<Job?>(null) }
    var metadata by remember(resumeDraft) {
        mutableStateOf(resumeDraft?.takeIf { it.audioUri != null }?.let {
            AudioMetadata(it.audioTitle, it.audioArtist, it.audioDurationMs, it.audioAlbum, it.sourceGenre)
        })
    }
    var sourceTrackId by remember(resumeDraft) { mutableStateOf(resumeDraft?.sourceTrackId) }
    var sourcePublicCode by remember(resumeDraft) { mutableStateOf(resumeDraft?.sourcePublicCode) }
    var sourceGenre by remember(resumeDraft) { mutableStateOf(resumeDraft?.sourceGenre) }
    val musicImageContext = remember(musicImageKeywordCatalog, metadata?.title, metadata?.genre, sourceGenre) {
        musicImageKeywordCatalog.classify(
            title = metadata?.title,
            genre = listOfNotNull(metadata?.genre, sourceGenre).distinct().joinToString(" "),
        )
    }
    var showLinkInput by remember(resumeDraft, openLinkOnStart) { mutableStateOf(openLinkOnStart || resumeDraft?.audioSource == AudioSource.LINK) }
    var linkText by remember(resumeDraft) { mutableStateOf(resumeDraft?.pendingLinkText.orEmpty()) }
    var selectedLinkUrl by remember(resumeDraft) { mutableStateOf(resumeDraft?.selectedLinkUrl) }
    var linkProviderLabel by remember(resumeDraft) { mutableStateOf(resumeDraft?.linkProviderLabel) }
    var linkThumbnailUrl by remember(resumeDraft) { mutableStateOf(resumeDraft?.linkThumbnailUrl) }
    var linkProgress by remember { mutableStateOf<LinkAudioImporter.Progress?>(null) }
    var linkImportJob by remember { mutableStateOf<Job?>(null) }
    var streamLoading by remember { mutableStateOf(false) }
    var videoAudioPreparing by remember { mutableStateOf(false) }

    var aspectRatio by remember(resumeDraft) {
        mutableStateOf(
            resumeDraft?.aspectRatio?.takeIf { ProjectAspectRatios.isValid(it) }
                ?: ProjectAspectRatios.VERTICAL
        )
    }

    var selectedDuration by remember(resumeDraft) {
        mutableStateOf(DurationPreset.all.firstOrNull {
            it.untilEnd == (resumeDraft?.durationUntilEnd ?: false) && (it.untilEnd || it.seconds == (resumeDraft?.durationSeconds ?: 30))
        } ?: DurationPreset.all[1])
    }
    var lastVerticalDuration by remember(resumeDraft) {
        mutableStateOf(
            DurationPreset.all.firstOrNull {
                !it.untilEnd && it.seconds == (resumeDraft?.durationSeconds ?: 30)
            } ?: DurationPreset.all[1]
        )
    }
    var segmentStartMs by remember(resumeDraft) { mutableStateOf(resumeDraft?.segmentStartMs ?: 0L) }
    // Null means the chosen preset controls the end. Non-null stores a precise manual cut.
    var manualEndMs by remember(resumeDraft) { mutableStateOf(resumeDraft?.manualEndMs) }
    var playbackEndMs by remember { mutableStateOf<Long?>(null) }
    var playbackMode by remember { mutableStateOf<String?>(null) }
    var playheadMs by remember { mutableStateOf(0L) }
    var isPlaying by remember { mutableStateOf(false) }
    var playerDurationMs by remember { mutableStateOf(0L) }
    var smartStartLoading by remember { mutableStateOf(false) }
    var manualStartOverride by remember { mutableStateOf(false) }

    var captionSegments by remember(resumeDraft) { mutableStateOf(resumeDraft?.captionSegments.orEmpty()) }
    // This switch affects only the current export; the global automation preference remains unchanged.
    var reviewCaptionsEnabled by remember(resumeDraft) { mutableStateOf(resumeDraft?.captionsEnabledForVideo ?: automation.automaticLyrics) }
    var captionCompleted by remember(resumeDraft) { mutableStateOf(resumeDraft?.captionCompleted ?: resumeDraft?.captionSegments?.isNotEmpty() == true) }
    var captionProgress by remember { mutableStateOf<WhisperCaptionEngine.Progress?>(null) }
    var captionJob by remember { mutableStateOf<Job?>(null) }
    var captionGeneration by remember { mutableStateOf(0L) }
    var captionError by remember { mutableStateOf<String?>(null) }
    // 1.3: elapsedRealtime survives wall-clock changes. The timer starts in Gallery,
    // not when Style becomes visible; only real transcribed audio calibrates the ETA.
    var captionEtaStartedAtMs by remember { mutableStateOf<Long?>(null) }
    var captionEtaNowMs by remember { mutableStateOf(SystemClock.elapsedRealtime()) }
    var captionEtaProcessedAudioMs by remember { mutableStateOf<Long?>(null) }
    var captionEtaSampleElapsedMs by remember { mutableStateOf<Long?>(null) }
    var captionEtaWaitingForModel by remember { mutableStateOf(false) }
    var automaticWorkMs by remember(resumeDraft) { mutableStateOf(resumeDraft?.automaticWorkMs ?: 0L) }

    var imageCatalog by remember { mutableStateOf<List<PCloudAsset>>(emptyList()) }
    var imageCatalogRatio by remember { mutableStateOf<String?>(null) }
    var imageCatalogLoading by remember { mutableStateOf(false) }
    var imageUris by remember(resumeDraft) { mutableStateOf(resumeDraft?.imageUris.orEmpty()) }
    var localVideoUris by remember(resumeDraft) { mutableStateOf(resumeDraft?.localVideoUris.orEmpty().toSet()) }
    var selectedRemoteIds by remember(resumeDraft) { mutableStateOf(resumeDraft?.selectedRemoteIds.orEmpty()) }
    var remoteImageUrls by remember(resumeDraft) { mutableStateOf(resumeDraft?.remoteImageUrls.orEmpty()) }
    var selectedRemoteStableKeys by remember(resumeDraft) {
        val savedKeys = resumeDraft?.selectedRemoteStableKeys.orEmpty()
        mutableStateOf((savedKeys.takeIf { it.isNotEmpty() } ?: resumeDraft?.imageHistoryKeys.orEmpty()).toSet())
    }
    var galleryHistoryRevision by remember { mutableStateOf(0L) }
    var projectTransitionIds by remember(resumeDraft) { mutableStateOf(resumeDraft?.visualTransitionIds.orEmpty()) }
    var projectTransitionPoolIds by remember(resumeDraft) { mutableStateOf(resumeDraft?.visualTransitionPoolIds.orEmpty()) }
    var gallerySearch by remember { mutableStateOf("") }
    var galleryShuffleNonce by remember { mutableStateOf(System.nanoTime()) }
    var lastGallerySearchRefreshKey by remember { mutableStateOf<String?>(null) }
    var gallerySearchSubmitNonce by remember { mutableStateOf(0) }

    var fontPreset by remember(resumeDraft) { mutableStateOf(resumeDraft?.fontPreset?.effective() ?: randomOpeningFont) }
    // Eight font tiles are shown at once. The remaining approved choices rotate on the next session.
    val visibleFontChoices = remember(resumeDraft, randomOpeningFont) {
        val initial = resumeDraft?.fontPreset?.effective()?.takeIf { it in CaptionFontPool.approved } ?: randomOpeningFont
        (listOf(initial) + CaptionFontPool.approved.filterNot { it == initial }.shuffled()).take(8)
    }
    var dynamicFontSelected by remember(resumeDraft) { mutableStateOf(resumeDraft == null) }
    // code03: Clássico limpo is the default; caption-look changes happen only by explicit user action.
    var captionStyle by remember(resumeDraft) { mutableStateOf(resumeDraft?.captionStyle ?: CaptionStyleId.CLASSIC) }
    var captionSizeScale by remember(resumeDraft) {
        mutableStateOf(resumeDraft?.captionSizeScale ?: CaptionLookPrefs.sizeScale(context, CaptionLookPrefs.FLOW))
    }
    var captionPositionPercent by remember(resumeDraft, aspectRatio) {
        mutableStateOf(
            resumeDraft?.takeIf { it.aspectRatio == aspectRatio }?.captionPositionPercent
                ?: CaptionLookPrefs.positionPercent(context, CaptionLookPrefs.FLOW, aspectRatio)
        )
    }
    LaunchedEffect(captionSizeScale, captionPositionPercent, aspectRatio) {
        CaptionLookPrefs.save(context, CaptionLookPrefs.FLOW, captionSizeScale, captionPositionPercent, aspectRatio)
    }
    var lyricColor by remember(resumeDraft) { mutableStateOf(resumeDraft?.lyricColorPreset ?: LyricColorPreset.DYNAMIC) }
    var filterPreset by remember(resumeDraft) { mutableStateOf(resumeDraft?.filterPreset ?: FilterPresetId.ORIGINAL) }
    var automaticEffectId by remember(resumeDraft) { mutableStateOf(resumeDraft?.automaticEffectId ?: EffectIds.RAW_GREEN_60) }
    var particlesEnabled by remember(resumeDraft) { mutableStateOf(resumeDraft?.particlesEnabled ?: true) }
    var exportTitle by remember(resumeDraft) { mutableStateOf(resumeDraft?.exportTitle.orEmpty()) }
    var exportArtist by remember(resumeDraft) { mutableStateOf(resumeDraft?.exportArtist.orEmpty()) }
    var exportTitleManuallyEdited by remember(resumeDraft) { mutableStateOf(resumeDraft?.exportTitleManuallyEdited ?: false) }
    var exportArtistManuallyEdited by remember(resumeDraft) { mutableStateOf(resumeDraft?.exportArtistManuallyEdited ?: false) }
    var exportResolution by remember(resumeDraft) { mutableStateOf(resumeDraft?.exportResolution ?: ExportResolution.P1080) }
    var exportFps by remember(resumeDraft) { mutableStateOf(if (resumeDraft?.exportFps == 60) 60 else 30) }
    val manualWorkBeforeSession = remember(resumeDraft) { resumeDraft?.manualWorkMs ?: 0L }
    val sessionStartedAt = remember(resumeDraft) { System.currentTimeMillis() }
    var editingStartedEpochMs by remember(resumeDraft) { mutableStateOf<Long?>(null) }
    LaunchedEffect(audioUri) {
        // audioUri is assigned only after a link has finished importing (or a local source is chosen).
        // This excludes link resolution/download time from editing productivity metrics.
        editingStartedEpochMs = if (audioUri != null) System.currentTimeMillis() else null
    }
    fun currentManualWorkMs(): Long = manualWorkBeforeSession +
        ((editingStartedEpochMs?.let { System.currentTimeMillis() - it } ?: 0L).coerceAtLeast(0L))
    val activeImageRepo = if (ProjectAspectRatios.isHorizontal(aspectRatio)) horizontalImageRepo else verticalImageRepo

    LaunchedEffect(step, aspectRatio) {
        if (step == CreateStep18.IMAGES) {
            galleryHistoryRevision = imageHistoryStore.revision(aspectRatio) + System.nanoTime()
        }
    }

    // Select the allowed family pool once per project. Adding/removing media only extends or
    // truncates assignments; RANDOM never chooses a new four-family set for every image.
    LaunchedEffect(imageUris.size) {
        if (imageUris.isEmpty()) {
            projectTransitionIds = emptyList()
            projectTransitionPoolIds = emptyList()
        } else {
            if (projectTransitionPoolIds.isEmpty()) {
                projectTransitionPoolIds = transitionPreferences.resolvePoolForProject(sessionStartedAt xor 0x534F4E5553L)
            }
            if (projectTransitionIds.size != imageUris.size) {
                projectTransitionIds = transitionPreferences.appendAssignments(
                    projectTransitionIds,
                    projectTransitionPoolIds,
                    imageUris.size,
                    sessionStartedAt xor 0x45444954L,
                )
            }
        }
    }

    fun message(value: String) { scope.launch { snackbar.showSnackbar(value) } }
    fun activePreset(): DurationPreset =
        if (ProjectAspectRatios.isHorizontal(aspectRatio)) DurationPreset.INFINITE else selectedDuration
    fun endMs(): Long = SegmentTrimPlanner12.endMs(
        metadata?.durationMs ?: 0L, segmentStartMs, activePreset().seconds, activePreset().untilEnd, manualEndMs,
    )
    fun durationMs(): Long = (endMs() - segmentStartMs).coerceAtLeast(0L)
    val galleryRequiredCount = MediaDistributionPlanner.maxImagesForDurationMs(durationMs().coerceAtLeast(1_000L))
    val galleryAvailability by produceState(
        ImageCooldownAvailability(0, 0, 0, 0, 0, emptySet()),
        imageCatalog,
        gallerySearch,
        galleryRequiredCount,
        aspectRatio,
        automation.blockRecentImages,
        galleryHistoryRevision,
    ) {
        value = withContext(Dispatchers.Default) {
            val scopedAssets = if (gallerySearch.isBlank()) imageCatalog
                else SmartImageSelector.searchManualGallery(imageCatalog, gallerySearch, emptySet())
            imageHistoryStore.availability(scopedAssets, galleryRequiredCount, aspectRatio, automation.blockRecentImages)
        }
    }
    fun maxStartMs(): Long = SegmentTrimPlanner12.maxStartMs(
        metadata?.durationMs ?: 0L, activePreset().seconds, activePreset().untilEnd, manualEndMs,
    )
    fun invalidateCaption() {
        captionGeneration++
        captionJob?.cancel()
        captionJob = null
        captionProgress = null
        captionEtaStartedAtMs = null
        captionEtaProcessedAudioMs = null
        captionEtaSampleElapsedMs = null
        captionEtaWaitingForModel = false
        captionSegments = emptyList()
        captionCompleted = false
        captionError = null
    }

    // Link fast path: the field is rendered first. Only after the user chooses Link do we
    // warm the local resolver in background, so opening the screen never waits for it.
    LaunchedEffect(showLinkInput) {
        if (showLinkInput) {
            withContext(Dispatchers.IO) { runCatching { linkImporter.prewarm() } }
        }
    }

    val player = remember { ExoPlayer.Builder(context).build() }
    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY && player.duration > 0L) {
                    playerDurationMs = player.duration
                }
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener); player.release() }
    }

    LaunchedEffect(audioUri, audioSource) {
        isPlaying = false
        playbackEndMs = null
        playbackMode = null
        playheadMs = 0L
        playerDurationMs = 0L
        player.stop()
        val uri = audioUri ?: return@LaunchedEffect
        // Start ExoPlayer's preparation immediately. Metadata extraction can be slow for larger
        // local MP3s, so it must not hold the blue/red trim preview controls behind it.
        runCatching {
            player.setMediaItem(MediaItem.fromUri(uri))
            player.prepare()
        }
        // Local audio duration is probed from container/track metadata in parallel with ExoPlayer
        // preparation and descriptive ID3 extraction. This avoids waiting for MediaMetadataRetriever
        // or full player readiness before the user can edit the trim range.
        if (audioSource == AudioSource.LOCAL || audioSource == AudioSource.SHARED || audioSource == AudioSource.VIDEO_EXTRACTED) {
            launch {
                val probedDurationMs = withContext(Dispatchers.IO) {
                    AudioDurationProbe13.readDurationMs(context, uri)
                }
                if (audioUri == uri && probedDurationMs >= 1_000L) {
                    playerDurationMs = maxOf(playerDurationMs, probedDurationMs)
                    val currentMetadata = metadata
                    if (currentMetadata == null || currentMetadata.durationMs <= 0L) {
                        metadata = AudioMetadata(
                            title = currentMetadata?.title ?: "Música selecionada",
                            artist = currentMetadata?.artist,
                            durationMs = probedDurationMs,
                            album = currentMetadata?.album,
                            genre = currentMetadata?.genre,
                        )
                    } else if (currentMetadata.durationMs != probedDurationMs) {
                        metadata = currentMetadata.copy(durationMs = probedDurationMs)
                    }
                }
            }
        }
        if (metadata == null || audioSource != AudioSource.SONUS_STREAM) {
            // The trim controls depend on the player's duration, not on ID3/art extraction.
            // Run descriptive metadata extraction concurrently so large local files never block UI.
            launch {
                val embedded = withContext(Dispatchers.IO) {
                    runCatching { AudioMetadataReader.read(context, uri) }.getOrNull()
                }
                if (audioUri == uri && embedded != null) {
                    val readyDuration = playerDurationMs.takeIf { it > 0L } ?: embedded.durationMs
                    metadata = when (audioSource) {
                        AudioSource.LINK -> metadata?.copy(
                            durationMs = readyDuration.takeIf { it > 0L } ?: metadata?.durationMs ?: 0L,
                            artist = metadata?.artist ?: embedded.artist,
                            album = metadata?.album ?: embedded.album,
                            genre = metadata?.genre ?: embedded.genre,
                        ) ?: embedded.copy(durationMs = readyDuration)
                        else -> embedded.copy(durationMs = readyDuration)
                    }
                }
            }
        }
        if (playerDurationMs > 0L && metadata != null && metadata?.durationMs != playerDurationMs) {
            metadata = metadata?.copy(durationMs = playerDurationMs)
        }
    }

    LaunchedEffect(playerDurationMs, audioUri, audioSource, metadata) {
        val duration = playerDurationMs
        if (duration > 0L && metadata == null && audioUri != null && audioSource != AudioSource.SONUS_STREAM) {
            // Provisional metadata unlocks the trim UI as soon as playback is ready. The richer
            // MediaMetadataRetriever result replaces it when the background read completes.
            metadata = AudioMetadata(
                title = "Música selecionada",
                artist = null,
                durationMs = duration,
            )
        } else if (duration > 0L && metadata != null && metadata?.durationMs != duration) {
            metadata = metadata?.copy(durationMs = duration)
        }
    }

    LaunchedEffect(metadata?.title, metadata?.artist, exportTitleManuallyEdited, exportArtistManuallyEdited) {
        val meta = metadata ?: return@LaunchedEffect
        if (!exportTitleManuallyEdited && (exportTitle.isBlank() || exportTitle == "Música selecionada")) {
            exportTitle = cleanExportTitle18(meta.title, meta.artist)
        }
        if (!exportArtistManuallyEdited && exportArtist.isBlank()) exportArtist = meta.artist.orEmpty()
    }

    fun parseIncomingCaptions(raw: String?): List<CaptionSegment> = runCatching {
        if (raw.isNullOrBlank()) emptyList() else Json { ignoreUnknownKeys = true }.decodeFromString<List<CaptionSegment>>(raw)
    }.getOrDefault(emptyList())

    fun streamAssetMatches(asset: PCloudAsset, value: String): Boolean {
        val target = normalizeLookup18(value)
        if (target.isBlank()) return false
        val fileId = asset.fileId.toString()
        val baseName = asset.name.substringBeforeLast('.', asset.name)
        return target == normalizeLookup18(fileId) ||
            target == normalizeLookup18(asset.stableKey) ||
            target == normalizeLookup18(asset.name) ||
            target == normalizeLookup18(baseName) ||
            normalizeLookup18(asset.name).contains(target) ||
            target.contains(normalizeLookup18(baseName))
    }

    suspend fun loadStreamAsset(asset: PCloudAsset, startMs: Long? = null, incomingMetadata: AudioMetadata? = null): Boolean {
        val url = musicRepo.downloadUrl(asset) ?: return false
        invalidateCaption()
        selectedStreamAsset = asset
        sourceTrackId = asset.fileId.toString()
        sourcePublicCode = asset.sourcePublicCode
        sourceGenre = asset.genre
        selectedLinkUrl = null
        audioSource = AudioSource.SONUS_STREAM
        metadata = incomingMetadata ?: metadataStore.resolveWithUrl(asset, url)
        audioUri = Uri.parse(url)
        segmentStartMs = startMs?.coerceAtLeast(0L) ?: 0L
        manualEndMs = null
        exportTitle = ""
        exportArtist = ""
        exportTitleManuallyEdited = false
        exportArtistManuallyEdited = false
        streamHistory.record(asset)
        return true
    }

    fun chooseSpecificStream(asset: PCloudAsset) {
        if (streamLoading) return
        streamLoading = true
        showLinkInput = false
        audioSource = AudioSource.SONUS_STREAM
        scope.launch {
            val ok = runCatching { loadStreamAsset(asset) }.getOrDefault(false)
            streamLoading = false
            showStreamBrowser = false
            if (!ok) message("Não foi possível abrir a música selecionada.")
        }
    }

    suspend fun ensureStreamCatalog(forceRefresh: Boolean = false): List<PCloudAsset> {
        if (!forceRefresh && streamCatalog.isNotEmpty()) return streamCatalog
        val catalog = runCatching {
            (if (forceRefresh) musicRepo.refresh() else musicRepo.refreshIfStale())
                .filter { it.extension.lowercase() in musicExt18 }
        }.getOrDefault(emptyList())
        if (catalog.isNotEmpty()) streamCatalog = catalog
        return catalog
    }

    // Incoming SONUS/shared media is the only startup path allowed to load what it explicitly needs.
    // code23 accepts the old trackId-only contract plus a richer explicit audio URI/metadata contract.
    LaunchedEffect(incomingRoute) {
        when (val route = incomingRoute) {
            is IncomingIntentRouter.Route.SharedMedia -> {
                val firstAudio = route.uris.firstOrNull { context.contentResolver.getType(it)?.startsWith("audio/") == true }
                    ?: route.uris.singleOrNull()?.takeIf { uri ->
                        val type = context.contentResolver.getType(uri).orEmpty()
                        !type.startsWith("image/") && !type.startsWith("video/")
                    }
                if (audioUri == null && firstAudio != null) {
                    UriPermissionHelper.persistRead(context, firstAudio)
                    audioSource = AudioSource.SHARED
                    audioUri = firstAudio
                    sourceTrackId = route.trackId
                    val embedded = withContext(Dispatchers.IO) { runCatching { AudioMetadataReader.read(context, firstAudio) }.getOrNull() }
                    metadata = embedded?.copy(
                        title = route.title?.takeIf { it.isNotBlank() } ?: embedded.title,
                        artist = route.artist?.takeIf { it.isNotBlank() } ?: embedded.artist,
                    ) ?: AudioMetadata(route.title ?: "Áudio compartilhado", route.artist, 0L)
                    val incomingCaptions = parseIncomingCaptions(route.captionsJson)
                    if (incomingCaptions.isNotEmpty()) {
                        captionSegments = incomingCaptions
                        captionCompleted = true
                        captionError = null
                    }
                }
                val visual = route.uris.filter {
                    val type = context.contentResolver.getType(it).orEmpty()
                    type.startsWith("image/") || type.startsWith("video/")
                }
                visual.forEach { UriPermissionHelper.persistRead(context, it) }
                imageUris = (imageUris + visual.map(Uri::toString)).distinct()
                localVideoUris = localVideoUris + visual.filter { context.contentResolver.getType(it)?.startsWith("video/") == true }.map(Uri::toString)
                onInitialSyncFinished()
            }
            is IncomingIntentRouter.Route.SonusTrack -> {
                if (audioUri == null) {
                    streamLoading = true
                    var loaded = false
                    route.audioUri?.let { directUri ->
                        runCatching { UriPermissionHelper.persistRead(context, directUri) }
                        val embedded = withContext(Dispatchers.IO) { runCatching { AudioMetadataReader.read(context, directUri) }.getOrNull() }
                        val directMeta = AudioMetadata(
                            title = route.title?.takeIf { it.isNotBlank() } ?: embedded?.title ?: "Faixa SONUS",
                            artist = route.artist?.takeIf { it.isNotBlank() } ?: embedded?.artist,
                            durationMs = embedded?.durationMs ?: route.durationMs ?: 0L,
                            album = route.album ?: embedded?.album,
                            genre = route.genre ?: embedded?.genre,
                        )
                        audioSource = AudioSource.SONUS_STREAM
                        audioUri = directUri
                        metadata = directMeta
                        sourceTrackId = route.trackId.takeIf { it.isNotBlank() }
                        sourceGenre = directMeta.genre
                        route.startMs?.let { segmentStartMs = it.coerceAtLeast(0L) }
                        loaded = true
                    }
                    if (!loaded) {
                        var catalog = ensureStreamCatalog(false)
                        var asset = catalog.firstOrNull { streamAssetMatches(it, route.trackId) }
                            ?: route.title?.takeIf { it.isNotBlank() }?.let { title ->
                                catalog.firstOrNull { streamAssetMatches(it, title) }
                            }
                        // A stale catalog is the most common reason the old SONUS->Edit bridge opened
                        // an empty editor. Refresh once before giving up, then also try the supplied title.
                        if (asset == null && (route.trackId.isNotBlank() || !route.title.isNullOrBlank())) {
                            catalog = ensureStreamCatalog(true)
                            asset = catalog.firstOrNull { streamAssetMatches(it, route.trackId) }
                                ?: route.title?.takeIf { it.isNotBlank() }?.let { title ->
                                    catalog.firstOrNull { streamAssetMatches(it, title) }
                                }
                        }
                        if (asset != null) {
                            val incomingMeta = if (!route.title.isNullOrBlank()) {
                                AudioMetadata(route.title, route.artist, asset.durationMs ?: route.durationMs ?: 0L, route.album, route.genre ?: asset.genre)
                            } else null
                            loaded = runCatching { loadStreamAsset(asset, route.startMs, incomingMeta) }.getOrDefault(false)
                        }
                    }
                    val incomingCaptions = parseIncomingCaptions(route.captionsJson)
                    if (loaded && incomingCaptions.isNotEmpty()) {
                        captionSegments = incomingCaptions
                        captionCompleted = true
                        captionError = null
                    }
                    streamLoading = false
                    onInitialSyncFinished()
                    if (!loaded) message("Não consegui localizar esta faixa do SONUS. Abra novamente pela música ou use Stream.")
                } else onInitialSyncFinished()
            }
            else -> Unit
        }
    }

    fun chooseStream() {
        if (streamLoading) return
        streamLoading = true
        showLinkInput = false
        audioSource = AudioSource.SONUS_STREAM
        scope.launch {
            val catalog = ensureStreamCatalog(false)
            val asset = StreamSuggestionEngine.suggest(catalog, streamHistory.recent())
            if (asset == null) {
                streamLoading = false
                message("Não foi possível carregar uma música do Sonus Stream.")
                return@launch
            }
            val ok = runCatching { loadStreamAsset(asset) }.getOrDefault(false)
            streamLoading = false
            if (!ok) message("Não foi possível abrir a música selecionada.")
        }
    }

    fun openStreamBrowser() {
        showStreamBrowser = true
        if (!streamLoading) {
            streamLoading = true
            scope.launch {
                val catalog = ensureStreamCatalog(false)
                streamLoading = false
                if (catalog.isNotEmpty() && streamIndexJob?.isActive != true) {
                    streamIndexJob = scope.launch {
                        metadataStore.indexCatalog(catalog, musicRepo) { streamMetadataRevision++ }
                    }
                }
            }
        }
    }

    fun importLink() {
        val raw = linkText.trim()
        if (raw.isBlank()) { message("Cole um link para importar."); return }
        if (linkImportJob?.isActive == true) return
        linkImportJob = scope.launch {
            var imported: LinkAudioImporter.Result? = null
            var failure: Throwable? = null

            // One silent retry handles occasional extractor/native warm-up races without making the
            // user paste or tap the same link repeatedly. Only one import job exists at a time.
            repeat(2) { attempt ->
                if (imported != null) return@repeat
                runCatching {
                    linkImporter.import(raw) { p -> scope.launch { linkProgress = p } }
                }.onSuccess { result ->
                    imported = result
                }.onFailure { error ->
                    failure = error
                    if (attempt == 0) {
                        linkProgress = LinkAudioImporter.Progress(status = "Tentando novamente…")
                        delay(350L)
                    }
                }
            }

            val result = imported
            if (result != null) {
                invalidateCaption()
                selectedStreamAsset = null
                sourceTrackId = null
                sourcePublicCode = null
                sourceGenre = result.metadata.genre
                selectedLinkUrl = result.originalUrl
                linkProviderLabel = result.providerLabel
                linkThumbnailUrl = result.thumbnailUrl
                metadata = result.metadata.copy(title = cleanExportTitle18(result.metadata.title, result.metadata.artist))
                audioSource = AudioSource.LINK
                audioUri = result.localUri
                showLinkInput = true
                exportTitle = ""
                exportArtist = ""
                exportTitleManuallyEdited = false
                exportArtistManuallyEdited = false
                segmentStartMs = 0L
                manualEndMs = null
                linkProgress = null
                message("Áudio pronto.")
            } else {
                linkProgress = null
                val rawMessage = failure?.message.orEmpty()
                val friendly = when {
                    rawMessage.contains("libffmpeg", ignoreCase = true) ||
                        rawMessage.contains("ffmpeg-location", ignoreCase = true) ->
                        "Não foi possível preparar este link agora. Tente novamente."
                    rawMessage.isBlank() -> "Falha ao importar o link."
                    else -> rawMessage.take(180)
                }
                message(friendly)
            }
            linkImportJob = null
        }
    }

    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            UriPermissionHelper.persistRead(context, it)
            invalidateCaption()
            audioSource = AudioSource.LOCAL
            audioUri = it
            metadata = null
            selectedStreamAsset = null
            sourceTrackId = null
            selectedLinkUrl = null
            showLinkInput = false
            exportTitle = ""
            exportArtist = ""
            exportTitleManuallyEdited = false
            exportArtistManuallyEdited = false
            segmentStartMs = 0L
            manualEndMs = null
        }
    }
    val videoAudioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        UriPermissionHelper.persistRead(context, uri)
        videoAudioPreparing = true
        scope.launch {
            runCatching {
                VideoAudioSourceInspector.validate(context.applicationContext, uri)
            }.onSuccess { videoMetadata ->
                invalidateCaption()
                audioSource = AudioSource.VIDEO_EXTRACTED
                audioUri = uri
                metadata = videoMetadata.copy(title = cleanExportTitle18(videoMetadata.title, videoMetadata.artist))
                selectedStreamAsset = null
                sourceTrackId = null
                sourcePublicCode = null
                sourceGenre = videoMetadata.genre
                selectedLinkUrl = null
                linkProviderLabel = null
                linkThumbnailUrl = null
                showLinkInput = false
                exportTitle = ""
                exportArtist = ""
                exportTitleManuallyEdited = false
                exportArtistManuallyEdited = false
                segmentStartMs = 0L
                manualEndMs = null
                message("Áudio do vídeo pronto.")
            }.onFailure { error ->
                message(error.message ?: "Não foi possível usar o áudio deste vídeo.")
            }
            videoAudioPreparing = false
        }
    }
    val visualPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { UriPermissionHelper.persistRead(context, it) }
        val max = MediaDistributionPlanner.maxImagesForDurationMs(durationMs())
        val accepted = uris.take((max - imageUris.size).coerceAtLeast(0))
        imageUris = (imageUris + accepted.map(Uri::toString)).distinct().take(max)
        localVideoUris = localVideoUris + accepted.filter { context.contentResolver.getType(it)?.startsWith("video/") == true }.map(Uri::toString)
        if (accepted.size < uris.size) message("Limite de $max mídias para este trecho.")
    }

    fun startCaptionIfNeeded() {
        if (!automation.automaticLyrics || !reviewCaptionsEnabled) return
        if (captionJob?.isActive == true || captionCompleted) return
        val uri = audioUri ?: return
        val d = durationMs()
        if (d <= 0L) return
        val startAt = segmentStartMs
        val title = metadata?.title.orEmpty()
        val generationId = ++captionGeneration
        captionError = null
        captionSegments = emptyList()
        captionCompleted = false
        captionProgress = WhisperCaptionEngine.Progress("Preparando legenda…")
        captionEtaStartedAtMs = SystemClock.elapsedRealtime()
        captionEtaNowMs = captionEtaStartedAtMs!!
        captionEtaProcessedAudioMs = null
        captionEtaSampleElapsedMs = null
        captionEtaWaitingForModel = false
        captionJob = scope.launch {
            val began = System.currentTimeMillis()
            try {
                val result = captionEngine.generate(uri, startAt, d, titleHint = title) { progress ->
                    // Async callback may be delivered after cancellation; never show stale progress.
                    scope.launch {
                        if (captionGeneration != generationId) return@launch
                        captionProgress = progress
                        val now = SystemClock.elapsedRealtime()
                        if (progress.status.startsWith("Conectando ao motor") ||
                            progress.status.startsWith("Baixando Whisper Small") ||
                            progress.status.startsWith("Carregando Whisper Small")) {
                            // A first-time 488 MB model download depends on network speed.
                            // It is intentionally excluded from audio-based countdowns.
                            captionEtaWaitingForModel = true
                        } else if (captionEtaWaitingForModel && (
                                progress.status.startsWith("Preparando áudio") ||
                                progress.status.startsWith("Preparando legenda longa") ||
                                progress.status.startsWith("Ouvindo e sincronizando")
                            )) {
                            captionEtaWaitingForModel = false
                            captionEtaStartedAtMs = now
                        }
                        val done = progress.processedAudioMs
                        if (done != null && done > (captionEtaProcessedAudioMs ?: 0L)) {
                            captionEtaProcessedAudioMs = done
                            captionEtaSampleElapsedMs = (now - (captionEtaStartedAtMs ?: now)).coerceAtLeast(0L)
                        }
                    }
                }
                if (!currentCoroutineContext().isActive || captionGeneration != generationId) return@launch
                captionSegments = result.segments
                if (!result.fromCache) {
                    CaptionEtaEstimator14.record(context.applicationContext, d, result.processingMs)
                }
                captionCompleted = true
                automaticWorkMs += if (result.fromCache) 0L else result.processingMs
                captionProgress = WhisperCaptionEngine.Progress(if (result.segments.isEmpty()) "Sem voz detectada" else "Letra sincronizada", 100)
            } catch (_: CancellationException) {
                // A changed trim or track intentionally cancels obsolete transcription work.
            } catch (error: Exception) {
                if (captionGeneration != generationId) return@launch
                captionCompleted = false
                captionError = error.message ?: "Não foi possível gerar a legenda."
                captionProgress = null
                automaticWorkMs += (System.currentTimeMillis() - began).coerceAtLeast(0L)
            } finally {
                if (captionGeneration == generationId) captionJob = null
            }
        }
    }

    LaunchedEffect(captionEtaStartedAtMs, captionCompleted, captionError) {
        if (captionEtaStartedAtMs != null && !captionCompleted && captionError == null) {
            while (true) {
                captionEtaNowMs = SystemClock.elapsedRealtime()
                delay(1_000L)
            }
        }
    }

    LaunchedEffect(automation.automaticLyrics, reviewCaptionsEnabled) {
        if (!automation.automaticLyrics || !reviewCaptionsEnabled) {
            invalidateCaption()
        } else if (step != CreateStep18.MUSIC && audioUri != null && !captionCompleted && captionError == null) {
            startCaptionIfNeeded()
        }
    }

    // A resumed draft can land directly on Images/Style. Restart only when both the global
    // automation and this project's caption switch are enabled.
    LaunchedEffect(step, audioUri, segmentStartMs, manualEndMs, selectedDuration.label, metadata?.title, reviewCaptionsEnabled) {
        if (step != CreateStep18.MUSIC && automation.automaticLyrics && reviewCaptionsEnabled && !captionCompleted && captionError == null && captionJob?.isActive != true) {
            startCaptionIfNeeded()
        }
    }

    suspend fun loadImageCatalog(targetRatio: String, showLoading: Boolean) {
        val repo = if (ProjectAspectRatios.isHorizontal(targetRatio)) horizontalImageRepo else verticalImageRepo
        val began = System.currentTimeMillis()
        if (showLoading) imageCatalogLoading = true
        val querySnapshot = gallerySearch
        val metadataSnapshot = metadata
        val musicContextSnapshot = musicImageContext
        val requiredCount = MediaDistributionPlanner.maxImagesForDurationMs(durationMs().coerceAtLeast(1_000L))
        val shuffleSnapshot = galleryShuffleNonce
        suspend fun firstVisibleAssets(assets: List<PCloudAsset>): List<PCloudAsset> = withContext(Dispatchers.Default) {
            if (assets.isEmpty()) return@withContext emptyList()
            val visible = if (querySnapshot.isBlank()) {
                val cooldown = imageHistoryStore.availability(assets, requiredCount, targetRatio, automation.blockRecentImages)
                SmartImageSelector.select(
                    assets = assets, metadata = metadataSnapshot, syncedLyrics = null,
                    count = minOf(72, cooldown.availableCount),
                    recentKeys = cooldown.blockedKeys,
                    nonce = (shuffleSnapshot xor targetRatio.hashCode().toLong()).toInt(),
                    artistCategory = null,
                    musicContext = musicContextSnapshot,
                )
            } else {
                val matching = SmartImageSelector.searchManualGallery(assets, querySnapshot, emptySet())
                val cooldown = imageHistoryStore.availability(matching, requiredCount, targetRatio, automation.blockRecentImages)
                matching.filterNot { it.stableKey in cooldown.blockedKeys }
            }
            visible.take(3)
        }
        val cachedRaw = repo.cached()
        val cached = withContext(Dispatchers.Default) { cachedRaw.filter { it.extension.lowercase() in galleryMediaExt18 } }
        if (GalleryQueryResultGate13.canPublish(querySnapshot, gallerySearch, targetRatio, aspectRatio) && cached.isNotEmpty()) {
            imageCatalogRatio = targetRatio
            imageCatalog = cached
            // Warm the same first-visible choices before waiting for the network freshness check.
            val cachedWarm = firstVisibleAssets(cached).take(3)
            scope.launch(Dispatchers.IO) {
                // Warm only the first row. Remaining thumbnails are loaded lazily as they enter view.
                cachedWarm.forEach { asset -> runCatching { loadRemoteAssetThumbnail18(context.applicationContext, asset, repo) } }
            }
        }
        val freshRaw = repo.refreshIfStaleProgressively { partialRaw ->
            val partial = withContext(Dispatchers.Default) {
                partialRaw.filter { it.extension.lowercase() in galleryMediaExt18 }
            }
            if (GalleryQueryResultGate13.canPublish(querySnapshot, gallerySearch, targetRatio, aspectRatio) && partial.isNotEmpty()) {
                imageCatalogRatio = targetRatio
                imageCatalog = partial
            }
        }
        val fresh = withContext(Dispatchers.Default) { freshRaw.filter { it.extension.lowercase() in galleryMediaExt18 } }
        if (GalleryQueryResultGate13.canPublish(querySnapshot, gallerySearch, targetRatio, aspectRatio)) {
            imageCatalogRatio = targetRatio
            imageCatalog = fresh
            // Warm the exact first viewport selection while the user is still in the music step.
            if (cached.isEmpty()) {
                val freshWarm = firstVisibleAssets(fresh).take(3)
                scope.launch(Dispatchers.IO) {
                    freshWarm.forEach { asset -> runCatching { loadRemoteAssetThumbnail18(context.applicationContext, asset, repo) } }
                }
            }
        }
        if (GalleryQueryResultGate13.canPublish(querySnapshot, gallerySearch, targetRatio, aspectRatio)) imageCatalogLoading = false
        automaticWorkMs += (System.currentTimeMillis() - began).coerceAtLeast(0L)
    }

    // code20: once the user has actually selected audio, warm only the gallery for the chosen
    // aspect ratio in the background. This never runs on Home/app startup, but means Step 2 can
    // show cached/first images immediately instead of starting a 20 s wait after the tap.
    LaunchedEffect(audioUri, aspectRatio) {
        if (audioUri == null) return@LaunchedEffect
        val ratio = aspectRatio
        if (imageCatalogRatio != ratio || imageCatalog.isEmpty()) {
            loadImageCatalog(ratio, showLoading = step == CreateStep18.IMAGES)
        }
    }

    // If prefetch failed while the user was still on Music, Step 2 gets one explicit retry.
    LaunchedEffect(step, aspectRatio) {
        if (step == CreateStep18.IMAGES && (imageCatalogRatio != aspectRatio || imageCatalog.isEmpty()) && !imageCatalogLoading) {
            loadImageCatalog(aspectRatio, showLoading = true)
        }
    }

    // Every explicit text query refreshes the current term against all configured pCloud sources.
    // Catalog prefetches are guarded by their original query snapshot so a slow initial load cannot
    // overwrite results from a newer query after the user starts searching.
    LaunchedEffect(step, aspectRatio, gallerySearch, gallerySearchSubmitNonce) {
        val query = gallerySearch.trim()
        if (query.isBlank()) {
            lastGallerySearchRefreshKey = null
            return@LaunchedEffect
        }
        if (step != CreateStep18.IMAGES || query.length < 2) return@LaunchedEffect
        val explicitSearch = gallerySearchSubmitNonce > 0
        if (!explicitSearch) delay(350)
        // An explicit tap starts the indicator immediately; every pCloud folder publishes as soon
        // as it returns instead of holding the UI until the slowest folder finishes.
        val refreshKey = "$aspectRatio|${query.lowercase()}"
        if (!explicitSearch && lastGallerySearchRefreshKey == refreshKey) return@LaunchedEffect
        lastGallerySearchRefreshKey = refreshKey
        val ratio = aspectRatio
        val repo = if (ProjectAspectRatios.isHorizontal(ratio)) horizontalImageRepo else verticalImageRepo
        val began = System.currentTimeMillis()
        imageCatalogLoading = true
        try {
            // Every non-empty query refreshes all configured public folders. The cooldown is
            // deliberately applied later by the gallery selector, never used to truncate search.
            val freshRaw = repo.refreshSearchProgressively(
                query = query,
                mediaExtensions = galleryMediaExt18,
            ) { partialRaw ->
                val partial = withContext(Dispatchers.Default) {
                    partialRaw.filter { it.extension.lowercase() in galleryMediaExt18 }
                }
                if (GalleryQueryResultGate13.canPublish(query, gallerySearch, ratio, aspectRatio) && partial.isNotEmpty()) {
                    imageCatalogRatio = ratio
                    imageCatalog = partial
                }
            }
            val fresh = withContext(Dispatchers.Default) { freshRaw.filter { it.extension.lowercase() in galleryMediaExt18 } }
            if (GalleryQueryResultGate13.canPublish(query, gallerySearch, ratio, aspectRatio)) {
                imageCatalogRatio = ratio
                imageCatalog = fresh
            }
        } finally {
            val elapsed = System.currentTimeMillis() - began
            withContext(NonCancellable) {
                if (elapsed < 1_800L) delay(1_800L - elapsed)
            }
            if (GalleryQueryResultGate13.canPublish(query, gallerySearch, ratio, aspectRatio)) imageCatalogLoading = false
            automaticWorkMs += (System.currentTimeMillis() - began).coerceAtLeast(0L)
            if (explicitSearch) gallerySearchSubmitNonce = 0
        }
    }

    // code23: Gallery no longer waits on or depends on the artist->genre database. The normal
    // view is deliberately shuffled per project/aspect ratio so opening a new project does not
    // keep showing the same first thumbnails. Explicit text search still scans the whole active
    // 9:16 or 16:9 catalog with normalized keyword matching.
    // Capture Compose state on the UI thread, then rank/filter the large catalog on Default.
    val galleryCatalogSnapshot = imageCatalog
    val galleryQuerySnapshot = gallerySearch
    val galleryMetadataSnapshot = metadata
    val galleryMusicContextSnapshot = musicImageContext
    val galleryRatioSnapshot = aspectRatio
    val galleryShuffleSnapshot = galleryShuffleNonce
    val galleryDurationSnapshot = durationMs()
    val galleryVisibleImages by produceState(
        emptyList<PCloudAsset>(),
        galleryCatalogSnapshot,
        galleryQuerySnapshot,
        galleryRatioSnapshot,
        galleryShuffleSnapshot,
        galleryMetadataSnapshot?.title,
        galleryMetadataSnapshot?.artist,
        galleryMetadataSnapshot?.genre,
        galleryMusicContextSnapshot.groupIds,
        galleryMusicContextSnapshot.priorityKeywords,
        galleryDurationSnapshot,
        galleryHistoryRevision,
    ) {
        value = withContext(Dispatchers.Default) {
            val neededForVideo = MediaDistributionPlanner.maxImagesForDurationMs(galleryDurationSnapshot.coerceAtLeast(1_000L))
            if (galleryQuerySnapshot.isBlank()) {
                val cooldown = imageHistoryStore.availability(galleryCatalogSnapshot, neededForVideo, galleryRatioSnapshot, automation.blockRecentImages)
                SmartImageSelector.select(
                    assets = galleryCatalogSnapshot,
                    metadata = galleryMetadataSnapshot,
                    syncedLyrics = null,
                    count = minOf(72, cooldown.availableCount),
                    recentKeys = cooldown.blockedKeys,
                    nonce = (galleryShuffleSnapshot xor galleryRatioSnapshot.hashCode().toLong()).toInt(),
                    artistCategory = null,
                    musicContext = galleryMusicContextSnapshot,
                )
            } else {
                val matching = SmartImageSelector.searchManualGallery(galleryCatalogSnapshot, galleryQuerySnapshot, emptySet())
                val cooldown = imageHistoryStore.availability(matching, neededForVideo, galleryRatioSnapshot, automation.blockRecentImages)
                SmartImageSelector.searchManualGallery(matching, galleryQuerySnapshot, cooldown.blockedKeys)
            }
        }
    }

    LaunchedEffect(audioUri, metadata?.durationMs, selectedDuration.label, automation.smartStart) {
        val uri = audioUri ?: return@LaunchedEffect
        val total = metadata?.durationMs ?: return@LaunchedEffect
        val d = durationMs()
        if (!(automation.smartStart) || manualStartOverride || d <= 0L || total < d) return@LaunchedEffect
        val began = System.currentTimeMillis()
        smartStartLoading = true
        val suggestion = runCatching { SmartStartResolver.resolve(context, uri, total, d, null) }.getOrDefault(0L)
        if (!manualStartOverride) { segmentStartMs = suggestion.coerceIn(0L, maxStartMs()); player.seekTo(segmentStartMs) }
        smartStartLoading = false
        automaticWorkMs += (System.currentTimeMillis() - began).coerceAtLeast(0L)
    }

    LaunchedEffect(automation.defaultResolution, automation.defaultFps) {
        if (resumeDraft == null) {
            exportResolution = automation.defaultResolution
            exportFps = if (automation.defaultFps == 60) 60 else 30
        }
    }

    LaunchedEffect(metadata?.title, automation.automaticFilter, aspectRatio) {
        val meta = metadata ?: return@LaunchedEffect
        if (resumeDraft != null) return@LaunchedEffect
        val projectKey = "${audioUri?.toString().orEmpty()}|${meta.title}|$sessionStartedAt"

        if (automation.smartStart || automation.automaticEffects || automation.automaticImages || automation.automaticFilter) {
            if (!ProjectAspectRatios.isHorizontal(aspectRatio)) {
                AutomationPlanner.duration(meta, null)?.let {
                    selectedDuration = it
                    if (!it.untilEnd) lastVerticalDuration = it
                }
            } else {
                selectedDuration = DurationPreset.INFINITE
            }
            if (!dynamicFontSelected) {
                val fontPool = automation.favoriteFonts.filter { it in CaptionFontPool.approved }.toSet().ifEmpty { CaptionFontPool.approved.toSet() }
                fontPreset = rotationSelector.selectFont(projectKey, 0, fontPool) ?: AutomationPlanner.font(meta)
            }
        }

        if (automation.automaticFilter) {
            filterPreset = AutomationPlanner.filter(
                meta, null, automation.favoriteFilters,
                nonce = (sessionStartedAt xor meta.title.hashCode().toLong()).toInt(),
            )
        }
    }

    // Public effects are discovered only after a track is loaded, in parallel with captions.
    // No remote network request on Home or when effects are disabled.
    LaunchedEffect(audioUri, metadata?.title, particlesEnabled, resumeDraft) {
        val track = audioUri ?: return@LaunchedEffect
        if (metadata == null || !particlesEnabled) return@LaunchedEffect
        if (resumeDraft != null && PCloudEffectLibrary.isCloud(automaticEffectId)) {
            // Restored draft: warm its effect so preview/export can reuse it.
            cloudEffectLibrary.prepare(automaticEffectId)
            return@LaunchedEffect
        }
        if (resumeDraft != null) return@LaunchedEffect
        val available = cloudEffectLibrary.listAvailable().map(PCloudEffectLibrary::idFor)
        val selected = effectSelector.select("${track}|$sessionStartedAt", 0, available)
        if (PCloudEffectLibrary.isCloud(selected)) {
            // A remote choice only replaces the internal fallback after full validation.
            if (cloudEffectLibrary.prepare(selected) != null && audioUri == track && particlesEnabled) {
                automaticEffectId = selected
            }
        } else if (audioUri == track && particlesEnabled) automaticEffectId = selected
    }

    LaunchedEffect(isPlaying, audioUri, playbackEndMs) {
        if (!isPlaying) {
            playheadMs = player.currentPosition.coerceAtLeast(0L)
            return@LaunchedEffect
        }
        // Playback is bounded by the selected trim end. The red control previews only the last
        // five seconds; the cyan control follows the current start. Both stop exactly at the end.
        var lastUiTick = 0L
        while (isPlaying) {
            val current = player.currentPosition.coerceAtLeast(0L)
            val now = SystemClock.elapsedRealtime()
            if (now - lastUiTick >= 100L) {
                playheadMs = current
                lastUiTick = now
            }
            val boundary = playbackEndMs
            if ((boundary != null && TrimPreviewPlanner04.shouldStop(current, boundary)) || player.playbackState == Player.STATE_ENDED) {
                player.pause()
                boundary?.let { player.seekTo(it); playheadMs = it }
                isPlaying = false
                playbackEndMs = null
                playbackMode = null
                break
            }
            delay(40L)
        }
    }

    // Caption style is a deliberate user choice. New projects start with Clássico limpo;
    // the independent dynamic-font selector remains available.

    // Persist a lightweight draft throughout the editing flow.
    LaunchedEffect(
        step, audioUri, metadata, audioSource, linkText, selectedDuration.label, segmentStartMs, manualEndMs, aspectRatio, imageUris,
        localVideoUris, selectedRemoteIds, selectedRemoteStableKeys, fontPreset, lyricColor, captionStyle, captionSizeScale, captionPositionPercent, filterPreset, automaticEffectId,
        particlesEnabled, captionSegments, captionCompleted, reviewCaptionsEnabled, projectTransitionIds, projectTransitionPoolIds, exportTitle, exportArtist, exportTitleManuallyEdited, exportArtistManuallyEdited, exportResolution, exportFps, automaticWorkMs, editingStartedEpochMs,
    ) {
        if (audioUri == null && imageUris.isEmpty() && linkText.isBlank()) return@LaunchedEffect
        // Coalesce bursts of selection/slider changes into one background draft write.
        delay(180L)
        // Stable sourcePublicCode:fileId identities are captured on selection. Never reconstruct
        // them from a refreshed catalogue here: the catalogue may have changed since the tap.
        val remoteUrlsSnapshot = remoteImageUrls.toMap()
        val imageUrisSnapshot = imageUris.toSet()
        val draftImageHistoryKeys = selectedRemoteStableKeys.filter { stableKey ->
            val fileId = stableKey.substringAfterLast(':').toLongOrNull()
            fileId != null && remoteUrlsSnapshot[fileId]?.let { it in imageUrisSnapshot } == true
        }
        draftStore.save(
            CreationDraftSnapshot(
                stepOrdinal = step.ordinal,
                audioUri = audioUri?.toString(),
                audioTitle = metadata?.title.orEmpty(),
                audioArtist = metadata?.artist,
                audioAlbum = metadata?.album,
                audioDurationMs = metadata?.durationMs ?: 0L,
                audioSource = audioSource,
                sourceTrackId = sourceTrackId,
                sourcePublicCode = sourcePublicCode,
                sourceGenre = sourceGenre,
                selectedLinkUrl = selectedLinkUrl,
                pendingLinkText = linkText,
                linkProviderLabel = linkProviderLabel,
                linkThumbnailUrl = linkThumbnailUrl,
                durationSeconds = selectedDuration.seconds,
                durationUntilEnd = selectedDuration.untilEnd,
                segmentStartMs = segmentStartMs,
                manualEndMs = manualEndMs,
                aspectRatio = aspectRatio,
                imageUris = imageUris,
                localVideoUris = localVideoUris.toList(),
                selectedRemoteIds = selectedRemoteIds,
                remoteImageUrls = remoteImageUrls,
                selectedRemoteStableKeys = selectedRemoteStableKeys.toList(),
                visualTransitionIds = projectTransitionIds,
                visualTransitionPoolIds = projectTransitionPoolIds,
                imageHistoryKeys = draftImageHistoryKeys,
                fontPreset = fontPreset,
                lyricColorPreset = lyricColor,
                filterPreset = filterPreset,
                automaticEffectId = automaticEffectId,
                particlesEnabled = particlesEnabled,
                captionSegments = captionSegments,
                captionCompleted = captionCompleted,
                captionsEnabledForVideo = reviewCaptionsEnabled,
                captionStyle = captionStyle,
                captionSizeScale = captionSizeScale,
                captionPositionPercent = captionPositionPercent,
                exportTitle = exportTitle,
                exportArtist = exportArtist,
                exportTitleManuallyEdited = exportTitleManuallyEdited,
                exportArtistManuallyEdited = exportArtistManuallyEdited,
                exportResolution = exportResolution,
                exportFps = exportFps,
                sessionStartedEpochMs = sessionStartedAt,
                editingStartedEpochMs = editingStartedEpochMs,
                manualWorkMs = currentManualWorkMs(),
                automaticWorkMs = automaticWorkMs,
            )
        )
    }

    val segmentDurationMs = durationMs()
    val imageLimit = MediaDistributionPlanner.maxImagesForDurationMs(segmentDurationMs.coerceAtLeast(1_000L))
    val musicReady = audioUri != null && (metadata?.durationMs ?: 0L) >= 1_000L && segmentDurationMs > 0L
    val remoteSelectionPending = selectedRemoteIds.any { it !in remoteImageUrls }
    val imagesReady = imageUris.isNotEmpty() && imageUris.size <= imageLimit && !remoteSelectionPending
    val captionPending = automation.automaticLyrics && reviewCaptionsEnabled && !captionCompleted && captionError == null
    val captionDurationForProgress = durationMs().coerceAtLeast(0L)
    val captionProgressPercent = CaptionProgressEstimator13.percent(
        reportedPercent = captionProgress?.percent,
        processedAudioMs = captionProgress?.processedAudioMs ?: captionEtaProcessedAudioMs,
        durationMs = captionDurationForProgress,
        elapsedMs = captionEtaStartedAtMs?.let { (captionEtaNowMs - it).coerceAtLeast(0L) } ?: 0L,
        expectedTotalMs = if (captionDurationForProgress > 0L)
            CaptionEtaEstimator14.expectedTotalMs(context.applicationContext, captionDurationForProgress) else 0L,
        waitingForModel = captionEtaWaitingForModel || captionProgress?.status?.startsWith("Carregando Whisper Small") == true ||
            captionProgress?.status?.startsWith("Baixando Whisper Small") == true ||
            captionProgress?.status?.startsWith("Conectando ao motor") == true,
        completed = captionCompleted,
    )

    fun applyDuration(preset: DurationPreset) {
        if (ProjectAspectRatios.isHorizontal(aspectRatio) && !preset.untilEnd) return
        val total = metadata?.durationMs ?: 0L
        if (!preset.untilEnd && total > 0L && preset.seconds * 1_000L > total) { message("A música é menor que ${preset.label}."); return }
        selectedDuration = preset
        manualEndMs = null
        if (!preset.untilEnd) lastVerticalDuration = preset
        segmentStartMs = segmentStartMs.coerceAtMost(maxStartMs())
        val limit = MediaDistributionPlanner.maxImagesForDurationMs(durationMs())
        if (imageUris.size > limit) {
            val keep = imageUris.take(limit)
            val keptUrls = keep.toSet()
            imageUris = keep
            localVideoUris = localVideoUris.intersect(keptUrls)
            val keptRemoteIds = remoteImageUrls.filterValues { it in keptUrls }.keys
            selectedRemoteIds = selectedRemoteIds.filter { it in keptRemoteIds }
            selectedRemoteStableKeys = selectedRemoteStableKeys.filter { stableKey ->
                stableKey.substringAfterLast(':').toLongOrNull() in keptRemoteIds
            }.toSet()
            remoteImageUrls = remoteImageUrls.filterValues { it in keptUrls }
        }
        invalidateCaption()
    }

    fun applyAspectRatio(value: String) {
        if (value == aspectRatio) return
        if (!ProjectAspectRatios.isValid(value)) return

        val oldRemoteUris = remoteImageUrls.values.toSet()
        imageUris = imageUris.filterNot { it in oldRemoteUris }
        selectedRemoteIds = emptyList()
        selectedRemoteStableKeys = emptySet()
        remoteImageUrls = emptyMap()
        imageCatalog = emptyList()
        imageCatalogRatio = null
        galleryShuffleNonce = System.nanoTime()

        aspectRatio = value
        if (ProjectAspectRatios.isHorizontal(value)) {
            if (!selectedDuration.untilEnd) lastVerticalDuration = selectedDuration
            selectedDuration = DurationPreset.INFINITE
        } else {
            selectedDuration = lastVerticalDuration
        }
        segmentStartMs = segmentStartMs.coerceAtMost(maxStartMs())
        val limit = MediaDistributionPlanner.maxImagesForDurationMs(durationMs().coerceAtLeast(1_000L))
        if (imageUris.size > limit) {
            val keep = imageUris.take(limit)
            imageUris = keep
            localVideoUris = localVideoUris.intersect(keep.toSet())
        }
        invalidateCaption()
    }

    fun applyTrimRange(newStartMs: Long, newEndMs: Long) {
        val total = metadata?.durationMs ?: return
        if (total < 1_000L) return
        val start = newStartMs.coerceIn(0L, total - 1_000L)
        val finish = newEndMs.coerceIn(start + 1_000L, total)
        if (start == segmentStartMs && finish == endMs()) return
        manualStartOverride = true
        segmentStartMs = start
        manualEndMs = finish
        // Keep playback alive, but follow the edited trim point immediately.
        if (isPlaying) {
            val target = if (playbackMode == "end") TrimPreviewPlanner04.endPreviewPosition(start, finish) else TrimPreviewPlanner04.startPreviewPosition(start, finish)
            player.seekTo(target)
            playheadMs = target
            playbackEndMs = finish
        } else {
            player.seekTo(start)
            playheadMs = start
            playbackEndMs = null
        }
        invalidateCaption()
        val limit = MediaDistributionPlanner.maxImagesForDurationMs(finish - start)
        if (imageUris.size > limit) {
            // Keep existing selection when the user shortens the cut: trimming extra visuals is
            // necessary for a valid project, but avoid changing selection on other screens.
            val keep = imageUris.take(limit)
            imageUris = keep
            localVideoUris = localVideoUris.intersect(keep.toSet())
            val keptRemoteIds = remoteImageUrls.filterValues { it in keep }.keys
            selectedRemoteIds = selectedRemoteIds.filter { id -> id in keptRemoteIds }
            selectedRemoteStableKeys = selectedRemoteStableKeys.filter { stableKey ->
                stableKey.substringAfterLast(':').toLongOrNull() in keptRemoteIds
            }.toSet()
            remoteImageUrls = remoteImageUrls.filterValues { url -> url in keep }
        }
    }

    fun buildDraft(): CreateProjectDraft? {
        val uri = audioUri ?: return null
        val meta = metadata ?: return null
        val d = durationMs()
        if (projectTransitionPoolIds.isEmpty()) {
            projectTransitionPoolIds = transitionPreferences.resolvePoolForProject(sessionStartedAt xor 0x534F4E5553L)
        }
        if (projectTransitionIds.size != imageUris.size) {
            projectTransitionIds = transitionPreferences.appendAssignments(
                projectTransitionIds, projectTransitionPoolIds, imageUris.size, sessionStartedAt xor 0x45444954L,
            )
        }
        return CreateProjectDraft(
            audioUri = uri.toString(),
            audioTitle = meta.title,
            audioArtist = meta.artist,
            audioAlbum = meta.album,
            audioDurationMs = meta.durationMs,
            audioSource = audioSource,
            sourceTrackId = sourceTrackId,
            sourcePublicCode = sourcePublicCode,
            sourceGenre = sourceGenre,
            segmentStartMs = segmentStartMs,
            segmentDurationMs = d,
            aspectRatio = aspectRatio,
            signatureText = savedPrefs.signatureText,
            signaturePhotoUri = savedPrefs.signaturePhotoUri,
            signatureFontPreset = savedPrefs.signatureFontPreset,
            signatureColorPreset = savedPrefs.signatureColorPreset,
            imageUris = imageUris,
            localVideoUris = localVideoUris.toList(),
            imageHistoryKeys = selectedRemoteStableKeys.filter { stableKey ->
                val fileId = stableKey.substringAfterLast(':').toLongOrNull()
                fileId != null && remoteImageUrls[fileId]?.let { it in imageUris } == true
            },
            visualTransitionIds = projectTransitionIds,
            fontPreset = fontPreset,
            lyricColorPreset = lyricColor,
            filterPreset = filterPreset,
            lyricsPolicy = if (automation.automaticLyrics && reviewCaptionsEnabled) com.sonusstudios.sonusedit.create.LyricsPolicy.AUTO else com.sonusstudios.sonusedit.create.LyricsPolicy.OFF,
            captionSegments = if (automation.automaticLyrics && reviewCaptionsEnabled) captionSegments else emptyList(),
            captionStyle = captionStyle,
            captionPosition = if (ProjectAspectRatios.isHorizontal(aspectRatio)) CaptionPosition.BOTTOM else CaptionPosition.MIDDLE,
            captionSizeScale = captionSizeScale,
            captionPositionPercent = captionPositionPercent,
            exportTitle = ExportMetadataPolicy.resolveTitle(
                exportTitle, cleanExportTitle18(meta.title, meta.artist), exportTitleManuallyEdited,
            ),
            exportArtist = ExportMetadataPolicy.resolveArtist(
                exportArtist, meta.artist, exportArtistManuallyEdited,
            ),
            exportTitleManuallyEdited = exportTitleManuallyEdited,
            exportArtistManuallyEdited = exportArtistManuallyEdited,
            automaticEffectId = automaticEffectId,
            automaticEffectOpacity = automation.effectIntensity.opacity,
            particlesEnabled = particlesEnabled,
            metadataOverlayEnabled = automation.metadataOnVideo,
            exportResolution = exportResolution,
            exportFps = exportFps,
            sessionStartedEpochMs = sessionStartedAt,
            editingStartedEpochMs = editingStartedEpochMs,
            manualWorkMs = manualWorkBeforeSession,
            automaticWorkMs = automaticWorkMs,
        )
    }

    Scaffold(
        containerColor = SonusEditColors.Black,
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            Row(Modifier.fillMaxWidth().background(SonusEditColors.Surface).padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                OutlinedButton(onClick = { if (step == CreateStep18.MUSIC) onBack() else step = CreateStep18.entries[step.ordinal - 1] }) { Text(if (step == CreateStep18.MUSIC) "Voltar" else "Anterior") }
                Button(
                    onClick = {
                        when (step) {
                            CreateStep18.MUSIC -> {
                                if (!musicReady) return@Button
                                player.pause()
                                isPlaying = false
                                playbackEndMs = null
                                playbackMode = null
                                playheadMs = segmentStartMs
                                startCaptionIfNeeded()
                                step = CreateStep18.IMAGES
                            }
                            CreateStep18.IMAGES -> if (imagesReady) step = CreateStep18.STYLE
                            CreateStep18.STYLE -> {
                                if (captionPending) message("Aguarde a sincronização da letra terminar.")
                                else step = CreateStep18.REVIEW
                            }
                            CreateStep18.REVIEW -> {
                                if (captionPending) message("A legenda ainda está sendo finalizada.")
                                else buildDraft()?.let(onCreateDraft)
                            }
                        }
                    },
                    enabled = when (step) {
                        CreateStep18.MUSIC -> musicReady
                        CreateStep18.IMAGES -> imagesReady
                        CreateStep18.STYLE, CreateStep18.REVIEW -> !captionPending
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SonusEditColors.Violet),
                ) { Text(if (step == CreateStep18.REVIEW) "EXPORTAR" else "AVANÇAR", fontWeight = FontWeight.Bold) }
            }
        },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            CreateHeader18(step, aspectRatio, onBack) { target -> if (target.ordinal <= step.ordinal) step = target }
            when (step) {
                CreateStep18.IMAGES -> ImagesStep18(
                    localMediaUris = imageUris.filterNot { it in remoteImageUrls.values },
                    totalSelected = imageUris.size,
                    selectedItems = imageUris.map { uri ->
                        val remoteEntry = remoteImageUrls.entries.firstOrNull { it.value == uri }
                        val asset = remoteEntry?.let { entry -> imageCatalog.firstOrNull { it.fileId == entry.key } }
                        SelectedGalleryItem18(
                            uri = uri,
                            title = asset?.name ?: uri.substringAfterLast('/').substringBefore('?').ifBlank { "Mídia local" },
                            isVideo = uri in localVideoUris,
                        )
                    },
                    localVideos = localVideoUris,
                    remote = galleryVisibleImages,
                    selectedRemoteIds = selectedRemoteIds,
                    selectedRemoteStableKeys = selectedRemoteStableKeys,
                    loading = imageCatalogLoading,
                    search = gallerySearch,
                    limit = imageLimit,
                    totalCatalogCount = galleryAvailability.totalCatalogCount,
                    availableCount = galleryAvailability.availableCount,
                    cooldownBlockedCount = galleryAvailability.blockedCount,
                    releasedCount = galleryAvailability.releasedCount,
                    historyVideoCount = galleryAvailability.historyVideoCount,
                    imageRepo = activeImageRepo,
                    projectAspectRatio = aspectRatio,
                    onSearch = { gallerySearch = it },
                    onSearchNow = {
                        if (gallerySearch.trim().length >= 2) {
                            imageCatalogLoading = true
                            gallerySearchSubmitNonce++
                        }
                    },
                    onLocal = { visualPicker.launch(arrayOf("image/*", "video/*")) },
                    onRemove = { uri ->
                        imageUris = imageUris - uri
                        localVideoUris = localVideoUris - uri
                        val remoteEntry = remoteImageUrls.entries.firstOrNull { it.value == uri }
                        if (remoteEntry != null) {
                            selectedRemoteIds = selectedRemoteIds - remoteEntry.key
                            imageCatalog.firstOrNull { it.fileId == remoteEntry.key }?.stableKey?.let { stable ->
                                selectedRemoteStableKeys = selectedRemoteStableKeys - stable
                            }
                            remoteImageUrls = remoteImageUrls - remoteEntry.key
                        }
                    },
                    onToggleRemote = { asset ->
                        if (asset.stableKey in selectedRemoteStableKeys || asset.fileId in selectedRemoteIds) {
                            selectedRemoteStableKeys = selectedRemoteStableKeys - asset.stableKey
                            selectedRemoteIds = selectedRemoteIds - asset.fileId
                            remoteImageUrls[asset.fileId]?.let {
                                imageUris = imageUris - it
                                localVideoUris = localVideoUris - it
                            }
                            remoteImageUrls = remoteImageUrls - asset.fileId
                        } else if (imageUris.size + selectedRemoteIds.count { it !in remoteImageUrls } < imageLimit) {
                            // Capture the exact pCloud identity now; never reconstruct it later from a refreshed catalogue.
                            selectedRemoteStableKeys = selectedRemoteStableKeys + asset.stableKey
                            selectedRemoteIds = selectedRemoteIds + asset.fileId
                            scope.launch {
                                val url = gallerySelectionSemaphore18.withPermit {
                                    if (asset.fileId in selectedRemoteIds) activeImageRepo.downloadUrl(asset) else null
                                }
                                if (url == null) {
                                    selectedRemoteStableKeys = selectedRemoteStableKeys - asset.stableKey
                                    if (asset.fileId in selectedRemoteIds) selectedRemoteIds = selectedRemoteIds - asset.fileId
                                    message("Não foi possível carregar esta mídia.")
                                } else if (asset.fileId in selectedRemoteIds) {
                                    remoteImageUrls = remoteImageUrls + (asset.fileId to url)
                                    imageUris = (imageUris + url).distinct().take(imageLimit)
                                    if (asset.extension in videoExt18) localVideoUris = localVideoUris + url
                                }
                            }
                        } else message("Limite de $imageLimit mídias.")
                    },
                )
                CreateStep18.REVIEW -> Column(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 6.dp)) {
                    ReviewStep18(
                    audioUri = audioUri?.toString(),
                    imageUris = imageUris,
                    localVideoUris = localVideoUris,
                    durationMs = segmentDurationMs,
                    startMs = segmentStartMs,
                    captions = if (automation.automaticLyrics && reviewCaptionsEnabled) captionSegments else emptyList(),
                    visualTransitionIds = projectTransitionIds,
                    particlesEnabled = particlesEnabled,
                    onParticlesEnabled = { particlesEnabled = it },
                    font = fontPreset,
                    lyricColor = lyricColor,
                    filter = filterPreset,
                    effectsEnabled = particlesEnabled,
                    effectId = automaticEffectId,
                    effectOpacity = automation.effectIntensity.opacity,
                    title = exportTitle,
                    artist = exportArtist,
                    resolution = exportResolution,
                    fps = exportFps,
                    aspectRatio = aspectRatio,
                    onTitle = { exportTitle = it; exportTitleManuallyEdited = true },
                    onArtist = { exportArtist = it; exportArtistManuallyEdited = true },
                    onResolution = { exportResolution = it },
                    onFps = { exportFps = it },
                    captionStyle = captionStyle,
                    onRefreshStyle = {
                        captionStyle = CaptionStyleSelector.refresh(captionStyle)
                    },
                    captionSizeScale = captionSizeScale,
                    onCaptionSizeScale = { captionSizeScale = it },
                    captionPositionPercent = captionPositionPercent,
                    onCaptionPositionPercent = { captionPositionPercent = it },
                    onCaptionEdit = { index, text ->
                        captionSegments = captionSegments.toMutableList().also { current ->
                            if (index in current.indices) current[index] = current[index].copy(text = text)
                        }
                    },
                )
                }
                CreateStep18.STYLE -> StyleStep18(
                                font = fontPreset,
                                visibleFonts = visibleFontChoices,
                                dynamicFontSelected = dynamicFontSelected,
                                color = lyricColor,
                                filter = filterPreset,
                                captionEnabled = automation.automaticLyrics && reviewCaptionsEnabled,
                                captionsGloballyEnabled = automation.automaticLyrics,
                                onCaptionsEnabled = { enabled ->
                                    reviewCaptionsEnabled = enabled
                                    invalidateCaption()
                                    if (enabled && automation.automaticLyrics) startCaptionIfNeeded()
                                },
                                captionGenerating = captionPending,
                                captionCompleted = captionCompleted,
                                captionError = captionError,
                                captionProgressPercent = captionProgressPercent,
                                estimatedRemainingMs = if (captionEtaWaitingForModel) null else captionEtaStartedAtMs?.let { started ->
                                    CaptionEtaEstimator14.remainingMs(
                                        totalEstimateMs = CaptionEtaEstimator14.expectedTotalMs(context.applicationContext, segmentDurationMs),
                                        durationMs = segmentDurationMs,
                                        elapsedMs = (captionEtaNowMs - started).coerceAtLeast(0L),
                                        processedAudioMs = captionEtaProcessedAudioMs,
                                        sampleElapsedMs = captionEtaSampleElapsedMs,
                                    )
                                },
                                favoriteFonts = automation.favoriteFonts,
                                favoriteFilters = automation.favoriteFilters,
                                previewUri = imageUris.firstOrNull(),
                                previewIsVideo = imageUris.firstOrNull()?.let { it in localVideoUris } == true,
                                onFont = { fontPreset = it; dynamicFontSelected = false; scope.launch { editPrefs.saveFont(it) } },
                                onDynamicFont = { fontPreset = CaptionFontPool.approved.random(); dynamicFontSelected = true; scope.launch { editPrefs.saveFont(fontPreset) } },
                                onToggleFontFavorite = { preset ->
                                    val next = if (preset in automation.favoriteFonts) automation.favoriteFonts - preset else automation.favoriteFonts + preset
                                    scope.launch { automationPrefs.save(automation.copy(favoriteFonts = next)) }
                                },
                                onColor = { lyricColor = it },
                                onFilter = { filterPreset = it },
                                onToggleFilterFavorite = { preset ->
                                    val next = if (preset in automation.favoriteFilters) automation.favoriteFilters - preset else automation.favoriteFilters + preset
                                    scope.launch { automationPrefs.save(automation.copy(favoriteFilters = next)) }
                                },
                                captionStyle = captionStyle,
                                onCaptionStyle = { captionStyle = it },
                    modifier = Modifier.fillMaxSize(),
                            )
                else -> LazyColumn(
                    Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    item {
                        when (step) {
                            CreateStep18.MUSIC -> MusicStep18(
                                metadata = metadata,
                                audioUri = audioUri?.toString(),
                                source = audioSource,
                                showLink = showLinkInput,
                                showSourceChooser = !directLinkMode,
                                sourceChosen = audioUri != null || showLinkInput || streamLoading,
                                linkText = linkText,
                                provider = linkProviderLabel,
                                thumbnail = linkThumbnailUrl,
                                duration = selectedDuration,
                                aspectRatio = aspectRatio,
                                totalDurationMs = metadata?.durationMs ?: 0L,
                                segmentStartMs = segmentStartMs,
                                segmentEndMs = endMs(),
                                manualEndMs = manualEndMs,
                                playheadMs = playheadMs,
                                isPlaying = isPlaying,
                                playbackMode = playbackMode,
                                smartStartLoading = smartStartLoading,
                                streamLoading = streamLoading,
                                videoAudioPreparing = videoAudioPreparing,
                                onStream = { chooseStream() },
                                onStreamShuffle = { chooseStream() },
                                onStreamBrowse = { openStreamBrowser() },
                                onLocal = { audioPicker.launch(arrayOf("audio/*")) },
                                onExtractAudioVideo = { videoAudioPicker.launch(arrayOf("video/*")) },
                                onLink = { showLinkInput = true; audioSource = AudioSource.LINK },
                                onLinkText = { linkText = it },
                                onImportLink = { importLink() },
                                onDuration = { applyDuration(it) },
                                onAspectRatio = { applyAspectRatio(it) },
                                onRangeChange = { newStart, newEnd -> applyTrimRange(newStart, newEnd) },
                                onFineStart = { seconds ->
                                    val newStart = (segmentStartMs + seconds * 1_000L)
                                        .coerceIn(0L, maxStartMs())
                                    // Preset mode retains its chosen duration when the start moves.
                                    if (manualEndMs == null) {
                                        if (segmentStartMs != newStart) {
                                            manualStartOverride = true
                                            segmentStartMs = newStart
                                            if (isPlaying) {
                                                val target = if (playbackMode == "end") TrimPreviewPlanner04.endPreviewPosition(newStart, endMs()) else TrimPreviewPlanner04.startPreviewPosition(newStart, endMs())
                                                player.seekTo(target)
                                                playheadMs = target
                                                playbackEndMs = endMs()
                                            } else {
                                                player.seekTo(newStart)
                                                playheadMs = newStart
                                            }
                                            invalidateCaption()
                                        }
                                    } else applyTrimRange(newStart, endMs())
                                },
                                onFineEnd = { seconds ->
                                    applyTrimRange(segmentStartMs, endMs() + seconds * 1_000L)
                                },
                                onPlayStart = {
                                    // ExoPlayer queues seek/play requests while BUFFERING. Do not
                                    // force the user to wait for STATE_READY after a duration probe.
                                    if (isPlaying && playbackMode == "start") {
                                        player.pause(); isPlaying = false; playbackEndMs = null; playbackMode = null
                                    } else {
                                        player.pause()
                                        val previewStart = TrimPreviewPlanner04.startPreviewPosition(segmentStartMs, endMs())
                                        player.seekTo(previewStart)
                                        playheadMs = previewStart
                                        playbackEndMs = endMs()
                                        playbackMode = "start"
                                        player.play(); isPlaying = true
                                    }
                                },
                                onPlayEnd = {
                                    // As above, a pending seek is retained until the source is ready.
                                    if (isPlaying && playbackMode == "end") {
                                        player.pause(); isPlaying = false; playbackEndMs = null; playbackMode = null
                                    } else {
                                        player.pause()
                                        val previewStart = TrimPreviewPlanner04.endPreviewPosition(segmentStartMs, endMs())
                                        player.seekTo(previewStart)
                                        playheadMs = previewStart
                                        playbackEndMs = endMs()
                                        playbackMode = "end"
                                        player.play(); isPlaying = true
                                    }
                                },
                            )
                            CreateStep18.STYLE -> Unit
                            else -> Unit
                        }
                    }
                }
            }
        }

        if (showStreamBrowser) {
            val metadataRevisionSnapshot = streamMetadataRevision
            val normalized = normalizeLookup18(streamSearch)
            val visibleStream = streamCatalog.filter { asset ->
                val cached = metadataStore.cached(asset)
                normalized.isBlank() || normalizeLookup18(asset.name).contains(normalized) ||
                    normalizeLookup18(metadataStore.displayTitle(asset)).contains(normalized) ||
                    normalizeLookup18(cached?.artist.orEmpty()).contains(normalized) ||
                    normalizeLookup18(cached?.album.orEmpty()).contains(normalized)
            }.take(40)
            AlertDialog(
                onDismissRequest = { showStreamBrowser = false },
                title = { Text("Sonus Stream") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            streamSearch,
                            { streamSearch = it },
                            Modifier.fillMaxWidth(),
                            placeholder = { Text("Pesquisar música ou artista") },
                            leadingIcon = { Icon(Icons.Default.Search, null) },
                            singleLine = true,
                        )
                        LazyColumn(Modifier.fillMaxWidth().height(310.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            items(visibleStream.size) { index ->
                                val asset = visibleStream[index]
                                val cached = metadataStore.cached(asset)
                                Card(
                                    Modifier.fillMaxWidth().clickable { chooseSpecificStream(asset) },
                                    colors = CardDefaults.cardColors(containerColor = SonusEditColors.SurfaceRaised),
                                ) {
                                    Row(Modifier.fillMaxWidth().padding(9.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.MusicNote, null, tint = SonusEditColors.Cyan, modifier = Modifier.size(20.dp))
                                        Spacer(Modifier.width(8.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(cleanExportTitle18(metadataStore.displayTitle(asset), cached?.artist), fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                            Text(listOfNotNull(cached?.artist, cached?.album, cached?.genre).distinct().joinToString(" • ").ifBlank { "Lendo metadados do catálogo…" }, color = SonusEditColors.TextMuted, fontSize = 9.sp, maxLines = 1)
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showStreamBrowser = false }) { Text("FECHAR") }
                },
            )
        }

        linkProgress?.let {
            ProcessProgressOverlay(it.title, it.status, it.percent, onCancel = { linkImporter.cancel(it.processId); linkProgress = null })
        }
        if (streamLoading) ProcessProgressOverlay("Sonus Stream", "Buscando uma música…", null)
        if (videoAudioPreparing) ProcessProgressOverlay("Áudio do vídeo", "Preparando faixa de áudio…", null)
    }
}

@Composable
private fun CreateHeader18(current: CreateStep18, aspectRatio: String, onBack: () -> Unit, onSelect: (CreateStep18) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(onClick = onBack, modifier = Modifier.size(40.dp)) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar", tint = Color.White)
        }
        Image(
            painterResource(R.drawable.sonus_edit_logo),
            "Sonus Edit",
            Modifier.size(43.dp).clip(RoundedCornerShape(11.dp)),
        )
        Spacer(Modifier.width(9.dp))
        Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(9.dp), verticalAlignment = Alignment.CenterVertically) {
            CreateStep18.entries.forEach { item ->
                val active = item == current
                val completed = item.ordinal < current.ordinal
                val background = when {
                    active -> SonusEditColors.Violet
                    completed -> Color(0xFF245F78)
                    else -> SonusEditColors.SurfaceRaised
                }
                val tint = if (active || completed) Color.White else SonusEditColors.TextMuted
                Box(
                    Modifier
                        .size(35.dp)
                        .background(background, CircleShape)
                        .border(1.dp, if (active) Color(0xFFB69BFF) else Color(0xFF394154), CircleShape)
                        .clickable(enabled = item.ordinal <= current.ordinal) { onSelect(item) },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = when (item) {
                            CreateStep18.MUSIC -> Icons.Default.MusicNote
                            CreateStep18.IMAGES -> Icons.Default.Image
                            CreateStep18.STYLE -> Icons.Default.AutoAwesome
                            CreateStep18.REVIEW -> Icons.Default.FactCheck
                        },
                        contentDescription = item.label,
                        tint = tint,
                        modifier = Modifier.size(20.dp),
                    )
                }
            }
        }
        Column(horizontalAlignment = Alignment.End) {
            Text("1.0.3", color = SonusEditColors.Cyan, fontWeight = FontWeight.Bold, fontSize = 10.sp)
            Box(
                Modifier.background(Color(0xFF6F2027), RoundedCornerShape(6.dp)).padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(aspectRatio, color = Color(0xFFFF8B93), fontWeight = FontWeight.Bold, fontSize = 9.sp)
            }
        }
    }
}

@Composable
private fun MusicStep18(
    metadata: AudioMetadata?, audioUri: String?, source: AudioSource, showLink: Boolean, showSourceChooser: Boolean, sourceChosen: Boolean,
    linkText: String, provider: String?, thumbnail: String?,
    duration: DurationPreset, aspectRatio: String, totalDurationMs: Long, segmentStartMs: Long,
    segmentEndMs: Long, manualEndMs: Long?, playheadMs: Long, isPlaying: Boolean, playbackMode: String?,
    smartStartLoading: Boolean, streamLoading: Boolean, videoAudioPreparing: Boolean,
    onStream: () -> Unit, onStreamShuffle: () -> Unit, onStreamBrowse: () -> Unit, onLocal: () -> Unit, onExtractAudioVideo: () -> Unit, onLink: () -> Unit,
    onLinkText: (String) -> Unit, onImportLink: () -> Unit,
    onDuration: (DurationPreset) -> Unit, onAspectRatio: (String) -> Unit,
    onRangeChange: (Long, Long) -> Unit,
    onFineStart: (Int) -> Unit, onFineEnd: (Int) -> Unit,
    onPlayStart: () -> Unit, onPlayEnd: () -> Unit,
) {
    val horizontal = ProjectAspectRatios.isHorizontal(aspectRatio)
    val customRatio = aspectRatio != ProjectAspectRatios.VERTICAL && aspectRatio != ProjectAspectRatios.HORIZONTAL
    var showOtherRatios by remember { mutableStateOf(false) }
    if (showOtherRatios) {
        AlertDialog(
            onDismissRequest = { showOtherRatios = false },
            title = { Text("Outra proporção") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ProjectAspectRatios.OTHER.forEach { ratio ->
                        val note = when (ratio) {
                            ProjectAspectRatios.SQUARE -> "quadrado"
                            ProjectAspectRatios.PORTRAIT_4_5 -> "retrato do feed"
                            else -> "retrato clássico"
                        }
                        OutlinedButton(
                            onClick = { showOtherRatios = false; onAspectRatio(ratio) },
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text("$ratio  •  $note", fontWeight = if (ratio == aspectRatio) FontWeight.ExtraBold else FontWeight.Normal) }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showOtherRatios = false }) { Text("Cancelar") } },
        )
    }
    Section18(if (showSourceChooser) "Fonte da música" else "Criar com Link") {
        if (showSourceChooser) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SourceButton18("Stream", Color(0xFF1F7A4C), sourceChosen && source == AudioSource.SONUS_STREAM && !showLink, Modifier.weight(1f), onStream)
                SourceButton18("Local", Color(0xFF8B3640), sourceChosen && source == AudioSource.LOCAL && !showLink, Modifier.weight(1f), onLocal)
                SourceButton18("Link", Color(0xFF2668A8), source == AudioSource.LINK || showLink, Modifier.weight(1f), onLink)
            }
            OutlinedButton(
                onClick = onExtractAudioVideo,
                enabled = !videoAudioPreparing,
                modifier = Modifier.fillMaxWidth().height(42.dp),
                border = BorderStroke(if (source == AudioSource.VIDEO_EXTRACTED) 2.dp else 1.dp, if (source == AudioSource.VIDEO_EXTRACTED) Color(0xFF57D8FF) else Color(0xFF4C566C)),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
            ) {
                Icon(Icons.Default.VideoFile, null, Modifier.size(16.dp))
                Text("  EXTRAIR ÁUDIO DE VÍDEO", fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }
        if (showLink) {
            Card(colors = CardDefaults.cardColors(containerColor = SonusEditColors.SurfaceRaised), shape = RoundedCornerShape(14.dp)) {
                Column(Modifier.padding(horizontal = 10.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Importar por link", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    OutlinedTextField(linkText, onLinkText, Modifier.fillMaxWidth().height(50.dp), placeholder = { Text("Cole o link") }, singleLine = true)
                    Button(onClick = onImportLink, enabled = linkText.isNotBlank(), modifier = Modifier.fillMaxWidth().height(38.dp), contentPadding = PaddingValues(0.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2668A8))) {
                        Icon(Icons.Default.Link, null, Modifier.size(16.dp)); Text("  IMPORTAR ÁUDIO", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        if (metadata != null) {
            Row(Modifier.fillMaxWidth().background(SonusEditColors.SurfaceRaised, RoundedCornerShape(12.dp)).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                MusicArtwork18(audioUri = audioUri, remoteThumbnail = thumbnail)
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text(cleanExportTitle18(metadata.title, metadata.artist), fontWeight = FontWeight.Bold, maxLines = 1)
                    Text(listOfNotNull(metadata.artist, if (source == AudioSource.LINK) provider else sourceLabel18(source)).joinToString(" • "), color = SonusEditColors.TextMuted, fontSize = 10.sp, maxLines = 1)
                }
                if (source == AudioSource.SONUS_STREAM) {
                    IconButton(onClick = onStreamShuffle, enabled = !streamLoading) { Icon(Icons.Default.Shuffle, "Trocar", tint = Color.White) }
                    IconButton(onClick = onStreamBrowse, enabled = !streamLoading) { Icon(Icons.Default.Search, "Pesquisar Stream", tint = SonusEditColors.Cyan) }
                }
                if (smartStartLoading || streamLoading || videoAudioPreparing) Text("…", color = SonusEditColors.Cyan, fontSize = 18.sp)
            }
        }
    }

    Section18("Duração e formato") {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            DurationPreset.all.forEach { preset ->
                val enabled = !horizontal || preset.untilEnd
                val selected = if (horizontal) preset.untilEnd else preset == duration
                Button(
                    onClick = { onDuration(preset) },
                    enabled = enabled,
                    modifier = Modifier.size(43.dp),
                    shape = CircleShape,
                    contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (selected) Color(0xFF27B96C) else Color(0xFF163C2B),
                        disabledContainerColor = Color(0xFF17231D),
                        disabledContentColor = Color(0xFF68736D),
                    ),
                ) { Text(preset.label.removeSuffix("s"), fontSize = if (preset.untilEnd) 18.sp else 9.sp, color = if (enabled) Color.White else Color(0xFF68736D), fontWeight = FontWeight.Bold) }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AspectRatioButton20(
                label = "9:16",
                verticalIcon = true,
                selected = aspectRatio == ProjectAspectRatios.VERTICAL,
                modifier = Modifier.weight(1f),
            ) { onAspectRatio(ProjectAspectRatios.VERTICAL) }
            AspectRatioButton20(
                label = "16:9",
                verticalIcon = false,
                selected = aspectRatio == ProjectAspectRatios.HORIZONTAL,
                modifier = Modifier.weight(1f),
            ) { onAspectRatio(ProjectAspectRatios.HORIZONTAL) }
            AspectRatioButton20(
                label = if (customRatio) aspectRatio else "Outra proporção",
                verticalIcon = true,
                selected = customRatio,
                modifier = Modifier.weight(1f),
            ) { showOtherRatios = true }
        }
        if (horizontal) {
            Text("16:9 usa a duração completa a partir do início escolhido (∞).", color = SonusEditColors.TextMuted, fontSize = 9.sp)
        }
        if (metadata != null && totalDurationMs > 0L) {
            if (manualEndMs != null) {
                Text("Trecho personalizado • ${(segmentEndMs - segmentStartMs) / 1000}s", color = SonusEditColors.Cyan, fontSize = 10.sp)
            }
            SegmentRangeBar12(
                totalDurationMs = totalDurationMs,
                startMs = segmentStartMs,
                endMs = segmentEndMs,
                playheadMs = playheadMs,
                onRangeChange = onRangeChange,
            )
            Text("${formatTime18(segmentStartMs)}  →  ${formatTime18(segmentEndMs)}  •  ${(segmentEndMs - segmentStartMs) / 1000}s", color = SonusEditColors.TextMuted, fontSize = 11.sp)
            CompactTrimControls12(
                label = "INÍCIO", tint = SonusEditColors.Cyan, isPlaying = isPlaying && playbackMode == "start",
                time = segmentStartMs, onPlay = onPlayStart, onFine = onFineStart,
            )
            CompactTrimControls12(
                label = "FINAL • últimos 5s", tint = Color(0xFFED4A57), isPlaying = isPlaying && playbackMode == "end",
                time = segmentEndMs, onPlay = onPlayEnd, onFine = onFineEnd,
            )
        }
    }
}

/** Timeline with independent purple start and red end handles. Drawing is allocation-light. */
@Composable
private fun SegmentRangeBar12(
    totalDurationMs: Long, startMs: Long, endMs: Long, playheadMs: Long,
    onRangeChange: (Long, Long) -> Unit,
) {
    val latestStart by rememberUpdatedState(startMs)
    val latestEnd by rememberUpdatedState(endMs)
    val latestOnChange by rememberUpdatedState(onRangeChange)
    val safeTotal = totalDurationMs.coerceAtLeast(1_000L)
    val indicatorInset = 12f
    Canvas(
        Modifier.fillMaxWidth().height(42.dp)
            .pointerInput(safeTotal) {
                var moveStart = true
                fun newTime(x: Float): Long {
                    val fraction = ((x - indicatorInset) / (size.width - 2f * indicatorInset).coerceAtLeast(1f)).coerceIn(0f, 1f)
                    return ((fraction * safeTotal) / 100L).roundToInt() * 100L
                }
                detectDragGestures(
                    onDragStart = { point ->
                        val ms = newTime(point.x)
                        moveStart = kotlin.math.abs(ms - latestStart) <= kotlin.math.abs(ms - latestEnd)
                    },
                    onDrag = { change, _ ->
                        change.consume()
                        val ms = newTime(change.position.x)
                        if (moveStart) latestOnChange(ms.coerceAtMost(latestEnd - 1_000L), latestEnd)
                        else latestOnChange(latestStart, ms.coerceAtLeast(latestStart + 1_000L))
                    },
                )
            }
            .pointerInput(safeTotal) {
                detectTapGestures { point ->
                    val fraction = ((point.x - indicatorInset) / (size.width - 2f * indicatorInset).coerceAtLeast(1f)).coerceIn(0f, 1f)
                    val ms = ((fraction * safeTotal) / 100L).roundToInt() * 100L
                    if (kotlin.math.abs(ms - latestStart) <= kotlin.math.abs(ms - latestEnd))
                        latestOnChange(ms.coerceAtMost(latestEnd - 1_000L), latestEnd)
                    else latestOnChange(latestStart, ms.coerceAtLeast(latestStart + 1_000L))
                }
            },
    ) {
        val left = indicatorInset
        val right = size.width - indicatorInset
        fun x(ms: Long): Float = left + (ms.coerceIn(0L, safeTotal) / safeTotal.toFloat()) * (right - left)
        val cy = size.height / 2f
        drawRoundRect(Color(0xFF4D475B), topLeft = Offset(left, cy - 4f),
            size = androidx.compose.ui.geometry.Size(right - left, 8f), cornerRadius = CornerRadius(4f))
        drawLine(Color(0xFFA578FD), Offset(x(startMs), cy), Offset(x(endMs), cy), strokeWidth = 8f)
        drawCircle(Color(0xFFAE7DFF), radius = 11f, center = Offset(x(startMs), cy))
        drawCircle(Color(0xFFEF4654), radius = 11f, center = Offset(x(endMs), cy))
        if (playheadMs in startMs..endMs) {
            drawLine(Color(0xFF4BE4F2), Offset(x(playheadMs), cy - 16f), Offset(x(playheadMs), cy + 16f), strokeWidth = 2.5f)
        }
    }
}

@Composable
private fun CompactTrimControls12(
    label: String, tint: Color, isPlaying: Boolean, time: Long,
    onPlay: () -> Unit, onFine: (Int) -> Unit,
) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onPlay, modifier = Modifier.size(38.dp)) {
            Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "Ouvir $label", tint = tint)
        }
        Column(Modifier.weight(1f)) {
            Text(label, color = tint, fontSize = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(formatTime18(time), color = SonusEditColors.TextMuted, fontSize = 10.sp)
        }
        listOf(-5, -1, 1, 5).forEach { sec ->
            OutlinedButton(
                onClick = { onFine(sec) }, modifier = Modifier.padding(start = 3.dp).height(32.dp),
                contentPadding = PaddingValues(horizontal = 7.dp),
            ) { Text(if (sec > 0) "+$sec" else "$sec", color = tint, fontSize = 9.sp) }
        }
    }
}

@Composable
private fun AspectRatioButton20(
    label: String,
    verticalIcon: Boolean,
    selected: Boolean,
    modifier: Modifier,
    onClick: () -> Unit,
) {
    Button(
        onClick = onClick,
        modifier = modifier.height(62.dp),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(containerColor = if (selected) Color(0xFF2F7EA7) else SonusEditColors.SurfaceRaised),
        border = BorderStroke(if (selected) 2.dp else 1.dp, if (selected) Color(0xFF58D7FF) else Color(0xFF394154)),
        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 5.dp),
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            Box(
                Modifier
                    .size(if (verticalIcon) 15.dp else 23.dp, if (verticalIcon) 23.dp else 15.dp)
                    .border(1.5.dp, Color.White, RoundedCornerShape(3.dp)),
            )
            Text(
                label, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 11.sp, maxLines = 2,
                lineHeight = 12.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                modifier = Modifier.weight(1f, fill = false).padding(start = 4.dp),
            )
        }
    }
}

@Composable
private fun MusicArtwork18(audioUri: String?, remoteThumbnail: String?) {
    val context = LocalContext.current
    val artwork by produceState<ImageBitmap?>(null, audioUri, remoteThumbnail) {
        value = withContext(Dispatchers.IO) {
            val thumbnailUrl = remoteThumbnail?.takeIf {
                it.startsWith("http://") || it.startsWith("https://")
            }
            val remoteArtwork = if (thumbnailUrl != null) {
                loadMediaBitmap18(thumbnailUrl)?.asImageBitmap()
            } else {
                null
            }
            remoteArtwork ?: audioUri?.let { loadAudioArtwork18(context, it)?.asImageBitmap() }
        }
    }
    Box(
        Modifier.size(42.dp).background(Color(0xFF172334), RoundedCornerShape(10.dp)).clip(RoundedCornerShape(10.dp)),
        contentAlignment = Alignment.Center,
    ) {
        if (artwork != null) {
            Image(artwork!!, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Icon(Icons.Default.MusicNote, null, tint = SonusEditColors.Cyan, modifier = Modifier.size(22.dp))
        }
    }
}

private fun loadAudioArtwork18(context: Context, raw: String): Bitmap? {
    val retriever = MediaMetadataRetriever()
    return try {
        val uri = Uri.parse(raw)
        if (uri.scheme.equals("http", true) || uri.scheme.equals("https", true)) {
            retriever.setDataSource(raw, emptyMap())
        } else {
            retriever.setDataSource(context, uri)
        }
        retriever.embeddedPicture?.let { bytes -> BitmapFactory.decodeByteArray(bytes, 0, bytes.size) }
    } catch (_: Throwable) {
        null
    } finally {
        runCatching { retriever.release() }
    }
}

@Composable
private fun SourceButton18(label: String, base: Color, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier.height(58.dp),
        shape = RoundedCornerShape(15.dp),
        border = if (selected) BorderStroke(2.dp, Color.White) else null,
        colors = ButtonDefaults.buttonColors(containerColor = if (selected) base else base.copy(alpha = .58f)),
    ) { Text(label, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold) }
}

private data class SelectedGalleryItem18(
    val uri: String,
    val title: String,
    val isVideo: Boolean,
)

@Composable
private fun ImagesStep18(
    localMediaUris: List<String>, totalSelected: Int, selectedItems: List<SelectedGalleryItem18>, localVideos: Set<String>, remote: List<PCloudAsset>, selectedRemoteIds: List<Long>, selectedRemoteStableKeys: Set<String>, loading: Boolean,
    search: String, limit: Int, totalCatalogCount: Int, availableCount: Int, cooldownBlockedCount: Int,
    releasedCount: Int, historyVideoCount: Int,
    imageRepo: PCloudCatalogRepository, projectAspectRatio: String,
    onSearch: (String) -> Unit, onSearchNow: () -> Unit, onLocal: () -> Unit, onRemove: (String) -> Unit, onToggleRemote: (PCloudAsset) -> Unit,
) {
    val previewRatio = if (ProjectAspectRatios.isHorizontal(projectAspectRatio)) 16f / 9f else .72f
    val cooldownLimit = if (ProjectAspectRatios.isHorizontal(projectAspectRatio)) 15 else 20
    var showSelection by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 8.dp)) {
        Card(
            Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = SonusEditColors.Surface),
            shape = RoundedCornerShape(18.dp),
        ) {
            Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Imagens e vídeos", fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        Box(Modifier.background(Color(0xFF183F56), RoundedCornerShape(8.dp)).padding(horizontal = 10.dp, vertical = 6.dp)) {
                            Text("$totalSelected / $limit", color = Color(0xFF75D8FF), fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                        }
                        TextButton(onClick = { showSelection = true }, enabled = selectedItems.isNotEmpty(), contentPadding = PaddingValues(horizontal = 7.dp, vertical = 2.dp)) {
                            Text("VER", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = SonusEditColors.Cyan)
                        }
                    }
                }
                Text("Sonus Gallery • ${if (ProjectAspectRatios.isHorizontal(projectAspectRatio)) "16:9" else "9:16"}", color = SonusEditColors.TextMuted, fontSize = 9.sp)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = search,
                        onValueChange = onSearch,
                        modifier = Modifier.weight(1f).height(56.dp),
                        placeholder = { Text("Pesquisar imagens e vídeos", fontSize = 11.sp, maxLines = 1) },
                        textStyle = TextStyle(fontSize = 14.sp, lineHeight = 18.sp),
                        singleLine = true,
                    )
                    IconButton(onClick = onSearchNow, modifier = Modifier.size(42.dp)) {
                        Icon(Icons.Default.Search, "Pesquisar", Modifier.size(24.dp), tint = SonusEditColors.Cyan)
                    }
                    Button(
                        onClick = onLocal,
                        modifier = Modifier.width(116.dp).height(54.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8B3640)),
                        contentPadding = PaddingValues(horizontal = 5.dp, vertical = 0.dp),
                    ) {
                        Icon(Icons.Default.Image, null, Modifier.size(15.dp))
                        Text("FOTOS/VÍDEOS", fontSize = 8.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    }
                }
                if (loading) {
                    Row(
                        Modifier.fillMaxWidth().background(Color(0xFF123C27), RoundedCornerShape(9.dp))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(9.dp),
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(17.dp), color = Color(0xFF35E77C), strokeWidth = 2.4.dp,
                        )
                        Text(
                            if (search.isNotBlank()) "BUSCANDO" else "ATUALIZANDO CATÁLOGO",
                            color = Color(0xFF7CF0A5), fontSize = 10.sp, fontWeight = FontWeight.ExtraBold,
                        )
                    }
                }
                Text(
                    "Catálogo: $totalCatalogCount  •  Disponíveis: $availableCount  •  Bloqueadas: $cooldownBlockedCount",
                    color = SonusEditColors.TextMuted, fontSize = 9.sp, lineHeight = 12.sp,
                )
                Text(
                    "Liberadas por falta de opções: $releasedCount  •  Histórico: $historyVideoCount/$cooldownLimit vídeos",
                    color = SonusEditColors.TextMuted, fontSize = 9.sp, lineHeight = 12.sp,
                )
                if (remote.isEmpty() && search.isNotBlank() && !loading) Text(
                    if (cooldownBlockedCount > 0) "Nenhum resultado disponível para este termo. O bloqueio só libera mídias quando o catálogo não basta para concluir o vídeo."
                    else "Nenhuma mídia encontrada com esse termo.",
                    color = SonusEditColors.TextMuted, fontSize = 10.sp,
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        // code23: only the gallery scrolls. Header/count/search/local controls stay visible.
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(bottom = 8.dp),
            verticalArrangement = Arrangement.spacedBy(7.dp),
        ) {
            localMediaUris.chunked(3).forEach { row ->
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        row.forEach { uri ->
                            MediaCard18(uri, localVideos.contains(uri), true, previewRatio, Modifier.weight(1f)) { onRemove(uri) }
                        }
                        repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
            remote.chunked(3).forEach { row ->
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        row.forEach { asset ->
                            RemoteAssetCard18(asset, asset.stableKey in selectedRemoteStableKeys || asset.fileId in selectedRemoteIds, imageRepo, previewRatio, Modifier.weight(1f)) { onToggleRemote(asset) }
                        }
                        repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
        }
    }
    if (showSelection) {
        AlertDialog(
            onDismissRequest = { showSelection = false },
            title = { Text("Mídias selecionadas • ${selectedItems.size}") },
            text = {
                if (selectedItems.isEmpty()) Text("Nenhuma mídia selecionada.") else LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.height(320.dp)) {
                    items(selectedItems, key = { it.uri }) { item ->
                        Row(Modifier.fillMaxWidth().background(SonusEditColors.SurfaceRaised, RoundedCornerShape(10.dp)).padding(horizontal = 9.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(if (item.isVideo) Icons.Default.VideoFile else Icons.Default.Image, null, tint = SonusEditColors.Cyan, modifier = Modifier.size(19.dp))
                            Column(Modifier.weight(1f).padding(start = 8.dp)) {
                                Text(item.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 11.sp)
                                if (item.isVideo) Text("VÍDEO", color = Color(0xFFE58B96), fontSize = 8.sp, fontWeight = FontWeight.Bold)
                            }
                            IconButton(onClick = { onRemove(item.uri) }, modifier = Modifier.size(32.dp)) {
                                Text("×", color = Color(0xFFFF6875), fontSize = 21.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showSelection = false }) { Text("FECHAR") } },
        )
    }
}

@Composable
private fun MediaCard18(uri: String, video: Boolean, selected: Boolean, previewAspectRatio: Float, modifier: Modifier, onClick: () -> Unit) {
    val context = LocalContext.current
    val bitmap by produceState<ImageBitmap?>(null, uri, video) {
        value = loadLocalMediaBitmap18(context, uri, video)?.asImageBitmap()
    }
    Card(
        modifier.clickable(onClick = onClick).border(1.dp, Color(0xFF374154), RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = SonusEditColors.SurfaceRaised), shape = RoundedCornerShape(12.dp),
    ) {
        Box(Modifier.fillMaxWidth().aspectRatio(previewAspectRatio)) {
            if (bitmap != null) Image(bitmap!!, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) else Box(Modifier.fillMaxSize().background(Color(0xFF202838)))
            Icon(if (video) Icons.Default.VideoFile else Icons.Default.Image, null, Modifier.align(Alignment.BottomStart).padding(5.dp).size(16.dp), tint = Color.White)
            if (video) Text("VÍDEO", Modifier.align(Alignment.BottomEnd).padding(4.dp).background(Color(0xDD9E3443), RoundedCornerShape(5.dp)).padding(horizontal = 5.dp, vertical = 2.dp), color = Color.White, fontSize = 7.sp, fontWeight = FontWeight.ExtraBold)
            if (selected) Icon(Icons.Default.Check, null, Modifier.align(Alignment.TopEnd).padding(4.dp).background(Color(0xFF287FA8), CircleShape).border(1.dp, Color(0xFF8BE4FF), CircleShape).padding(3.dp).size(17.dp), tint = Color.White)
        }
    }
}

@Composable
private fun RemoteAssetCard18(asset: PCloudAsset, selected: Boolean, repo: PCloudCatalogRepository, previewAspectRatio: Float, modifier: Modifier, onClick: () -> Unit) {
    val context = LocalContext.current
    val isVideo = asset.extension.lowercase() in videoExt18
    // Disk cache keeps catalogue scrolling/search responsive without lowering source/export quality.
    var thumbnailFailed by remember(asset.stableKey, asset.modified, asset.size) { mutableStateOf(false) }
    val thumb by produceState<ImageBitmap?>(null, asset.stableKey, asset.modified, asset.size, repo) {
        thumbnailFailed = false
        repeat(2) { attempt ->
            val loaded = loadRemoteAssetThumbnail18(context, asset, repo)
            if (loaded != null) {
                value = loaded.asImageBitmap()
                return@produceState
            }
            if (attempt == 0) {
                repo.invalidateThumbnailUrl(asset)
                delay(250L)
            }
        }
        thumbnailFailed = true
    }
    Card(
        modifier.clickable(onClick = onClick).border(1.dp, Color(0xFF374154), RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = SonusEditColors.SurfaceRaised), shape = RoundedCornerShape(12.dp),
    ) {
        Box(Modifier.fillMaxWidth().aspectRatio(previewAspectRatio)) {
            if (thumb != null) Image(thumb!!, asset.name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) else Box(Modifier.fillMaxSize().background(Color(0xFF202838)), contentAlignment = Alignment.Center) {
                if (thumbnailFailed) Text("Miniatura indisponível", color = SonusEditColors.TextMuted, fontSize = 7.sp, maxLines = 2)
                else CircularProgressIndicator(Modifier.size(17.dp), color = SonusEditColors.Cyan, strokeWidth = 1.5.dp)
            }
            if (isVideo) {
                Icon(Icons.Default.VideoFile, null, Modifier.align(Alignment.BottomStart).padding(5.dp).size(17.dp), tint = Color.White)
                Text("VÍDEO", Modifier.align(Alignment.BottomEnd).padding(4.dp).background(Color(0xDD9E3443), RoundedCornerShape(5.dp)).padding(horizontal = 5.dp, vertical = 2.dp), color = Color.White, fontSize = 7.sp, fontWeight = FontWeight.ExtraBold)
            }
            if (selected) Icon(Icons.Default.Check, null, Modifier.align(Alignment.TopEnd).padding(4.dp).background(Color(0xFF287FA8), CircleShape).border(1.dp, Color(0xFF8BE4FF), CircleShape).padding(3.dp).size(17.dp), tint = Color.White)
        }
    }
}

@Composable
private fun StyleStep18(
    font: FontPresetId, visibleFonts: List<FontPresetId>, dynamicFontSelected: Boolean,
    color: LyricColorPreset, filter: FilterPresetId,
    captionEnabled: Boolean, captionsGloballyEnabled: Boolean,
    captionGenerating: Boolean, captionCompleted: Boolean, captionError: String?,
    captionProgressPercent: Int?,
    estimatedRemainingMs: Long?,
    favoriteFonts: Set<FontPresetId>, favoriteFilters: Set<FilterPresetId>,
    previewUri: String?, previewIsVideo: Boolean,
    onFont: (FontPresetId) -> Unit, onDynamicFont: () -> Unit, onToggleFontFavorite: (FontPresetId) -> Unit,
    onColor: (LyricColorPreset) -> Unit, onFilter: (FilterPresetId) -> Unit, onToggleFilterFavorite: (FilterPresetId) -> Unit,
    onCaptionsEnabled: (Boolean) -> Unit,
    captionStyle: CaptionStyleId,
    onCaptionStyle: (CaptionStyleId) -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val filterPreview by produceState<ImageBitmap?>(null, previewUri, previewIsVideo) {
        value = previewUri?.let { loadLocalMediaBitmap18(context, it, previewIsVideo)?.asImageBitmap() }
    }
    val fontRowsHeight = 88.dp
    BoxWithConstraints(modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 6.dp)) {
        val filterImageHeight = (maxHeight * 0.075f).coerceIn(48.dp, 64.dp)
        val filterCardHeight = filterImageHeight + 18.dp
        Column(
            Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(7.dp),
        ) {
            Card(
                Modifier.fillMaxWidth().weight(0.63f),
                colors = CardDefaults.cardColors(containerColor = SonusEditColors.Surface),
                shape = RoundedCornerShape(14.dp),
            ) {
                Column(
                    Modifier.fillMaxSize().padding(8.dp),
                    verticalArrangement = Arrangement.spacedBy(5.dp),
                ) {
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text("Letra sincronizada", modifier = Modifier.weight(1f), fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                        CaptionStatusPill20(captionEnabled, captionGenerating, captionCompleted, captionError, estimatedRemainingMs, captionProgressPercent)
                    }
                    Text("Fonte • segure para favoritar", color = SonusEditColors.TextMuted, fontSize = 8.sp, maxLines = 1)
                    Row(
                        Modifier.fillMaxWidth().height(fontRowsHeight),
                        horizontalArrangement = Arrangement.spacedBy(5.dp),
                    ) {
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                visibleFonts.take(4).forEach { preset ->
                                    FontChoice18(
                                        preset = preset,
                                        selected = preset == font && !dynamicFontSelected,
                                        favorite = preset in favoriteFonts,
                                        modifier = Modifier.weight(1f),
                                        onClick = { onFont(preset) },
                                        onLongClick = { onToggleFontFavorite(preset) },
                                    )
                                }
                            }
                            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                visibleFonts.drop(4).take(4).forEach { preset ->
                                    FontChoice18(
                                        preset = preset,
                                        selected = preset == font && !dynamicFontSelected,
                                        favorite = preset in favoriteFonts,
                                        modifier = Modifier.weight(1f),
                                        onClick = { onFont(preset) },
                                        onLongClick = { onToggleFontFavorite(preset) },
                                    )
                                }
                            }
                        }
                        Column(Modifier.width(98.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Box(
                                Modifier.fillMaxWidth().weight(1f)
                                    .clip(RoundedCornerShape(9.dp))
                                    .background(Color(0xFF030711))
                                    .border(1.dp, Color(0xFF252D3B), RoundedCornerShape(9.dp)),
                            ) {
                                CaptionOverlayCanvas(
                                    captions = listOf(CaptionSegment(0L, 3_700L, "Sua legenda aqui")),
                                    timeMs = 1_000L,
                                    font = font,
                                    color = color,
                                    style = captionStyle,
                                    position = CaptionPosition.MIDDLE,
                                    modifier = Modifier.fillMaxSize().padding(3.dp),
                                    textScale = 6.0f,
                                )
                            }
                            Card(
                                modifier = Modifier.fillMaxWidth().height(42.dp).clickable(onClick = onDynamicFont),
                                colors = CardDefaults.cardColors(containerColor = if (dynamicFontSelected) Color(0xFF173F58) else SonusEditColors.SurfaceRaised),
                                shape = RoundedCornerShape(9.dp),
                            ) {
                                Box(
                                    Modifier.fillMaxSize().border(
                                        if (dynamicFontSelected) 2.dp else 1.dp,
                                        if (dynamicFontSelected) Color(0xFF57D8FF) else Color(0xFF394154),
                                        RoundedCornerShape(9.dp),
                                    ),
                                    contentAlignment = Alignment.Center,
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                                        Text("Aa ✦", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        Spacer(Modifier.width(4.dp))
                                        Text("Fonte dinâmica", color = Color.White, fontSize = 7.sp, maxLines = 1)
                                    }
                                    if (dynamicFontSelected) Icon(Icons.Default.Check, null, Modifier.align(Alignment.TopEnd).padding(3.dp).size(10.dp), tint = Color(0xFF57D8FF))
                                }
                            }
                        }
                    }
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Legendas neste vídeo", color = SonusEditColors.TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            Text(
                                if (captionsGloballyEnabled) "Desative para pular a sincronização deste projeto." else "Ative Legenda automática nos Ajustes para gerar legendas.",
                                color = SonusEditColors.TextMuted, fontSize = 7.sp, maxLines = 1,
                            )
                        }
                        androidx.compose.material3.Switch(
                            checked = captionEnabled,
                            onCheckedChange = onCaptionsEnabled,
                            enabled = captionsGloballyEnabled,
                        )
                    }
                    Text("Cor", color = SonusEditColors.TextMuted, fontSize = 8.sp)
                    LazyRow(
                        modifier = Modifier.fillMaxWidth().height(40.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        items(visibleLyricColors24) { preset ->
                            LyricColorButton24(preset, selected = preset == color, modifier = Modifier.width(48.dp)) { onColor(preset) }
                        }
                    }
                    Text("Estilo da legenda • deslize para ver todos", color = SonusEditColors.TextMuted, fontSize = 8.sp)
                    CaptionStylePicker(
                        selected = captionStyle, font = font, color = color, onStyle = onCaptionStyle,
                        cardWidth = 104.dp, cardHeight = 78.dp, previewHeight = 56.dp,
                        previewTextScale = 5.8f, labelFontSize = 8.sp,
                    )
                }
            }
            Card(
                Modifier.fillMaxWidth().weight(0.37f),
                colors = CardDefaults.cardColors(containerColor = SonusEditColors.Surface),
                shape = RoundedCornerShape(14.dp),
            ) {
                Column(
                    Modifier.fillMaxSize().padding(8.dp),
                    verticalArrangement = Arrangement.spacedBy(5.dp),
                ) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("FILTROS", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        Text("Deslize para o lado • toque para aplicar • segure para favoritar", color = SonusEditColors.TextMuted, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Clip, modifier = Modifier.weight(1f))
                    }
                    Text("15 efeitos gratuitos", color = SonusEditColors.TextMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                    LazyRow(modifier = Modifier.height(filterCardHeight), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(freeFilters18) { preset ->
                            FilterPreview18(
                                preset, preset == filter, preset in favoriteFilters, filterPreview,
                                Modifier.width(108.dp).height(filterCardHeight), false,
                                previewHeight = filterImageHeight.value.toInt(),
                                onClick = { onFilter(preset) }, onLongClick = { onToggleFilterFavorite(preset) },
                            )
                        }
                    }
                    Text("👑 10 efeitos Premium", color = Color(0xFFFFD45C), fontSize = 8.sp, fontWeight = FontWeight.Bold)
                    LazyRow(modifier = Modifier.height(filterCardHeight), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(premiumFilters18) { preset ->
                            FilterPreview18(
                                preset, preset == filter, preset in favoriteFilters, filterPreview,
                                Modifier.width(108.dp).height(filterCardHeight), true,
                                previewHeight = filterImageHeight.value.toInt(),
                                onClick = { onFilter(preset) }, onLongClick = { onToggleFilterFavorite(preset) },
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
internal fun LyricColorButton24(
    preset: LyricColorPreset,
    selected: Boolean,
    modifier: Modifier,
    onClick: () -> Unit,
) {
    val accent = Color(LyricColorPalette24.argb(preset, 0))
    Column(
        modifier = modifier.height(40.dp)
            .clip(RoundedCornerShape(7.dp))
            .background(if (selected) Color(0xFF19445C) else SonusEditColors.SurfaceRaised)
            .border(if (selected) 1.5.dp else 0.75.dp, if (selected) Color(0xFF57D8FF) else Color(0xFF394154), RoundedCornerShape(7.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        if (preset == LyricColorPreset.DYNAMIC) {
            Row(horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.CenterVertically) {
                listOf(0, 2, 3).forEach { index ->
                    Box(Modifier.size(5.dp, 12.dp).background(Color(LyricColorPalette24.argb(preset, index)), RoundedCornerShape(2.dp)))
                }
            }
        } else {
            Box(Modifier.size(11.dp).background(accent, CircleShape).border(0.75.dp, if (preset == LyricColorPreset.BLACK) Color.White else Color.Black.copy(alpha = .28f), CircleShape))
        }
        Spacer(Modifier.height(3.dp))
        Row(horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            Text(preset.label, color = Color.White, fontSize = 7.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium, maxLines = 1)
            if (preset == LyricColorPreset.DYNAMIC) Text("👑", color = Color(0xFFFFD45C), fontSize = 5.sp, maxLines = 1)
        }
    }
}

@Composable
internal fun CaptionStatusPill20(
    enabled: Boolean,
    generating: Boolean,
    completed: Boolean,
    error: String?,
    estimatedRemainingMs: Long?,
    progressPercent: Int? = null,
) {
    val background = when {
        !enabled -> Color(0xFF252A35)
        error != null -> Color(0xFF4B4015)
        generating || !completed -> Color(0xFF4A1B20)
        else -> Color(0xFF123C27)
    }
    val (line1, line2, color) = when {
        !enabled -> Triple("LEGENDA OFF", "", SonusEditColors.TextMuted)
        error != null -> Triple("🟡 ERRO", "PODE CONTINUAR", Color(0xFFFFDD55))
        generating || !completed -> Triple("AGUARDE...", "SINCRONIZANDO", Color(0xFFFF707A))
        else -> Triple("🟢 SINCRONIZADA", "", Color(0xFF67E69A))
    }
    val context = LocalContext.current
    // Casio-style digital clock face (DS-Digital Bold) used only for the remaining-time counter.
    val digitalClockFamily = remember {
        runCatching { FontFamily(android.graphics.Typeface.createFromAsset(context.assets, "ui_fonts/DS-DIGIB.TTF")) }
            .getOrDefault(FontFamily.Monospace)
    }
    val showClock = enabled && error == null && generating && !completed
    Card(
        modifier = Modifier.width(190.dp).height(46.dp),
        colors = CardDefaults.cardColors(containerColor = background),
        shape = RoundedCornerShape(12.dp),
    ) {
        Row(
            Modifier.fillMaxSize().padding(start = if (showClock) 10.dp else 7.dp, end = 7.dp, top = 4.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = if (showClock) Arrangement.Start else Arrangement.Center,
        ) {
            if (showClock) {
                // Fixed minimum width keeps the block steady when narrow digits (like 1) change.
                Column(Modifier.widthIn(min = 40.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Text(CaptionEtaEstimator13.formatRemaining(estimatedRemainingMs), color = Color(0xFFFFCED1),
                        fontFamily = digitalClockFamily, fontSize = 16.sp, letterSpacing = 0.5.sp, maxLines = 1)
                    Text("ESTIMADO", color = Color(0xFFF2A2A9), fontSize = 6.sp, maxLines = 1)
                }
                Spacer(Modifier.width(7.dp))
                Box(Modifier.size(18.dp), contentAlignment = Alignment.Center) {
                    if (progressPercent != null) {
                        CircularProgressIndicator(
                            progress = { progressPercent.coerceIn(0, 100) / 100f },
                            modifier = Modifier.fillMaxSize(),
                            color = Color(0xFFFF4555),
                            trackColor = Color(0xFF74343B),
                            strokeWidth = 2.2.dp,
                        )
                        Text(
                            progressPercent.coerceIn(0, 100).toString(),
                            color = Color.White,
                            fontSize = 5.sp,
                            fontWeight = FontWeight.ExtraBold,
                            maxLines = 1,
                        )
                    } else {
                        CircularProgressIndicator(
                            modifier = Modifier.fillMaxSize(), color = Color(0xFFFF4555),
                            strokeWidth = 2.2.dp,
                        )
                    }
                }
                Spacer(Modifier.width(4.dp))
            }
            Column(
                modifier = if (showClock) Modifier.weight(1f) else Modifier,
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Text(line1, color = color, fontSize = if (line2.isBlank()) 11.sp else 9.sp, fontWeight = FontWeight.Black, maxLines = 1)
                if (line2.isNotBlank()) Text(line2, color = if (error != null) Color.White else color, fontSize = 8.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun FontChoice18(
    preset: FontPresetId,
    selected: Boolean,
    favorite: Boolean,
    modifier: Modifier,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
) {
    val context = LocalContext.current
    val previewStyle = remember(preset) { fontPreviewStyle18(preset, context) }
    Card(
        modifier = modifier
            .height(42.dp)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .border(
                if (selected) 2.dp else 1.dp,
                if (selected) Color(0xFF57D8FF) else Color(0xFF394154),
                RoundedCornerShape(10.dp),
            ),
        colors = CardDefaults.cardColors(containerColor = if (selected) Color(0xFF173F58) else SonusEditColors.SurfaceRaised),
        shape = RoundedCornerShape(10.dp),
    ) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Aa", style = previewStyle, maxLines = 1)
                Text(preset.label, color = Color.White, fontSize = 6.sp, maxLines = 1)
            }
            if (favorite) Icon(Icons.Default.Star, "Favorita", Modifier.align(Alignment.TopStart).padding(3.dp).size(10.dp), tint = Color(0xFFFFD54F))
            if (selected) Icon(Icons.Default.Check, null, Modifier.align(Alignment.TopEnd).padding(3.dp).size(10.dp), tint = Color(0xFF57D8FF))
        }
    }
}

internal fun fontPreviewStyle18(requested: FontPresetId, context: android.content.Context): TextStyle {
    val preset = requested.effective()
    val custom = preset.assetFileName?.let { name ->
        runCatching { androidx.compose.ui.text.font.FontFamily(android.graphics.Typeface.createFromAsset(context.assets, "fonts/$name")) }.getOrNull()
    }
    val family = custom ?: when (preset.systemTypefaceName) {
        "sans-serif" -> FontFamily.SansSerif
        "serif" -> FontFamily.Serif
        else -> when (preset) {
            FontPresetId.DEFAULT, FontPresetId.IMPACT, FontPresetId.RETRO -> FontFamily.Cursive
            FontPresetId.MODERN, FontPresetId.HANDWRITTEN -> FontFamily.SansSerif
            FontPresetId.ELEGANT, FontPresetId.NEON -> FontFamily.Serif
            FontPresetId.MINIMAL -> FontFamily.Monospace
            else -> FontFamily.SansSerif
        }
    }
    return TextStyle(
        fontSize = 13.sp,
        fontFamily = family,
        fontStyle = if (preset == FontPresetId.RETRO || preset == FontPresetId.HANDWRITTEN) FontStyle.Italic else FontStyle.Normal,
        fontWeight = if (preset == FontPresetId.MODERN || preset == FontPresetId.IMPACT) FontWeight.Bold else FontWeight.Normal,
    )
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FilterPreview18(
    preset: FilterPresetId,
    selected: Boolean,
    favorite: Boolean,
    imageBitmap: ImageBitmap?,
    modifier: Modifier,
    premium: Boolean,
    previewHeight: Int = 39,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
) {
    Card(
        modifier = modifier
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
             .border(if (selected) 2.dp else 1.dp, if (selected) Color(0xFF57D8FF) else Color(0xFF394154), RoundedCornerShape(9.dp)),
        colors = CardDefaults.cardColors(containerColor = if (selected) Color(0xFF173F58) else SonusEditColors.SurfaceRaised),
        shape = RoundedCornerShape(9.dp),
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.fillMaxWidth().height(previewHeight.dp).clip(RoundedCornerShape(topStart = 11.dp, topEnd = 11.dp))) {
                if (imageBitmap != null) {
                    Image(imageBitmap, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, colorFilter = filterPreviewColor18(preset))
                } else {
                    Box(Modifier.fillMaxSize().background(Color(0xFF39445C)))
                }
                if (favorite) Icon(Icons.Default.Star, "Favorito", Modifier.align(Alignment.TopStart).padding(4.dp).background(Color(0x99000000), CircleShape).padding(2.dp).size(11.dp), tint = Color(0xFFFFD54F))
                if (premium) Text("👑", Modifier.align(Alignment.BottomStart).padding(2.dp), color = Color(0xFFFFD45C), fontSize = 9.sp)
                if (selected) Icon(Icons.Default.Check, null, Modifier.align(Alignment.TopEnd).padding(4.dp).background(Color(0xFF287FA8), CircleShape).padding(2.dp).size(12.dp), tint = Color.White)
            }
            Text(preset.label, Modifier.padding(vertical = 2.dp, horizontal = 3.dp), color = Color.White, fontSize = 8.sp, maxLines = 1)
        }
    }
}

private fun filterPreviewColor18(preset: FilterPresetId): ColorFilter? {
    if (preset == FilterPresetId.ORIGINAL) return null
    data class PreviewGrade(
        val saturation: Float,
        val contrast: Float,
        val brightness: Float,
        val redGain: Float = 1f,
        val greenGain: Float = 1f,
        val blueGain: Float = 1f,
    )
    val grade = when (preset) {
        FilterPresetId.CINEMATIC -> PreviewGrade(.90f, 1.09f, -.01f, .99f, 1.00f, 1.03f)
        FilterPresetId.SUNSET -> PreviewGrade(1.07f, 1.09f, 0f, 1.02f, 1.00f, .98f)
        FilterPresetId.NIGHT_CITY -> PreviewGrade(1.025f, 1.105f, -.008f, .97f, 1.00f, 1.035f)
        FilterPresetId.NATURAL_PLUS -> PreviewGrade(1.135f, 1.035f, 0f)
        FilterPresetId.GOLDEN -> PreviewGrade(1.015f, 1.035f, 0f)
        FilterPresetId.SPRING -> PreviewGrade(1.14f, 1.045f, .008f, 1.035f, 1.04f, .99f)
        FilterPresetId.BLACK_AND_WHITE -> PreviewGrade(0f, 1.045f, 0f)
        FilterPresetId.SOFT_CONTRAST -> PreviewGrade(1.035f, .955f, .012f)
        FilterPresetId.WARM_NATURAL -> PreviewGrade(1.07f, 1.04f, .010f, 1.085f, 1.015f, .925f)
        FilterPresetId.COOL_NATURAL -> PreviewGrade(1.02f, 1.045f, .004f, .94f, 1.00f, 1.09f)
        FilterPresetId.STUDIO_FILM -> PreviewGrade(.92f, 1.06f, -.005f, 1.01f, 1.0f, 1.03f)
        FilterPresetId.PORTRAIT_GLOW -> PreviewGrade(1.045f, 1.025f, .015f, 1.01f, 1.0f, .99f)
        FilterPresetId.GOLDEN_HOUR -> PreviewGrade(1.08f, 1.04f, .01f, 1.08f, 1.02f, .94f)
        FilterPresetId.TEAL_ORANGE -> PreviewGrade(1.08f, 1.07f, -.005f, 1.05f, 1.0f, 1.08f)
        FilterPresetId.MOODY_BLUE -> PreviewGrade(.94f, 1.10f, -.015f, .95f, 1.0f, 1.09f)
        FilterPresetId.SOFT_MATTE -> PreviewGrade(.92f, .95f, .02f)
        FilterPresetId.VIBRANT_POP -> PreviewGrade(1.18f, 1.08f, .005f)
        FilterPresetId.WARM_FILM -> PreviewGrade(.90f, 1.02f, .012f, 1.06f, 1.0f, .95f)
        FilterPresetId.CRISP_HDR -> PreviewGrade(1.04f, 1.11f, -.004f)
        FilterPresetId.DREAM_LIGHT -> PreviewGrade(1.07f, .97f, .025f, 1.03f, 1.02f, 1.0f)
        else -> PreviewGrade(1f, 1f, 0f)
    }
    val inv = 1f - grade.saturation
    val r = .213f * inv
    val g = .715f * inv
    val b = .072f * inv
    val translate = ((.5f - .5f * grade.contrast + grade.brightness) * 255f)
    return ColorFilter.colorMatrix(
        ColorMatrix(
            floatArrayOf(
                (r + grade.saturation) * grade.contrast * grade.redGain, g * grade.contrast * grade.redGain, b * grade.contrast * grade.redGain, 0f, translate,
                r * grade.contrast * grade.greenGain, (g + grade.saturation) * grade.contrast * grade.greenGain, b * grade.contrast * grade.greenGain, 0f, translate,
                r * grade.contrast * grade.blueGain, g * grade.contrast * grade.blueGain, (b + grade.saturation) * grade.contrast * grade.blueGain, 0f, translate,
                0f, 0f, 0f, 1f, 0f,
            )
        )
    )
}

@Composable
private fun SelectPill18(label: String, selected: Boolean, modifier: Modifier, compact: Boolean = false, height: Int = 36, onClick: () -> Unit) {
    Button(
        onClick = onClick, modifier = modifier.height(height.dp), shape = RoundedCornerShape(11.dp),
        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp),
        colors = ButtonDefaults.buttonColors(containerColor = if (selected) Color(0xFF287FA8) else SonusEditColors.SurfaceRaised),
        border = BorderStroke(if (selected) 2.dp else 1.dp, if (selected) Color(0xFF57D8FF) else Color(0xFF394154)),
    ) {
        if (selected) Icon(Icons.Default.Check, null, Modifier.size(if (compact) 9.dp else 11.dp))
        Text((if (selected) " " else "") + label, fontSize = if (compact) 7.sp else 8.sp, maxLines = 1, color = Color.White)
    }
}

@Composable
private fun ReviewStep18(
    audioUri: String?, imageUris: List<String>, localVideoUris: Set<String>, durationMs: Long, startMs: Long,
    captions: List<CaptionSegment>, visualTransitionIds: List<String>,
    particlesEnabled: Boolean, onParticlesEnabled: (Boolean) -> Unit,
    font: FontPresetId, lyricColor: LyricColorPreset, filter: FilterPresetId,
    effectsEnabled: Boolean, effectId: String, effectOpacity: Float,
    title: String, artist: String, resolution: ExportResolution, fps: Int, aspectRatio: String,
    onTitle: (String) -> Unit, onArtist: (String) -> Unit, onResolution: (ExportResolution) -> Unit, onFps: (Int) -> Unit,
    captionStyle: CaptionStyleId, onRefreshStyle: () -> Unit,
    captionSizeScale: Float, onCaptionSizeScale: (Float) -> Unit,
    captionPositionPercent: Float, onCaptionPositionPercent: (Float) -> Unit,
    onCaptionEdit: (Int, String) -> Unit,
) {
    val reviewContext = LocalContext.current
    // What this phone's encoder can really do: options it cannot deliver are greyed out, and a choice
    // that is not available (for example 1080p 60 FPS on a basic phone) is lowered before it can fail.
    val capabilities = remember { ExportCapabilities02.probe(reviewContext) }
    LaunchedEffect(resolution, fps) {
        if (!capabilities.supports(resolution, fps)) {
            if (fps >= 60 && capabilities.supports(resolution, 30)) onFps(30)
            else {
                onFps(30)
                onResolution(capabilities.best(30))
            }
        }
    }
    BoxWithConstraints(Modifier.fillMaxSize()) {
        // Keep controls above Exportar on small screens, enlarge the preview where room permits.
        val ratio = ProjectAspectRatios.parts(aspectRatio).let { it.first.toFloat() / it.second.toFloat() }
        val imageHeightBudget = (maxHeight.value - 312f).coerceAtLeast(170f)
        val previewWidth = if (ProjectAspectRatios.isHorizontal(aspectRatio))
            (maxWidth.value * .66f).coerceAtMost(340f).dp
        else (imageHeightBudget * ratio).coerceIn(104f, 176f).dp
        Section18("") {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                title, onTitle, Modifier.weight(1.15f).height(56.dp),
                label = { Text("Nome da música", maxLines = 1) }, singleLine = true,
                textStyle = TextStyle(fontSize = 13.sp),
            )
            OutlinedTextField(
                artist, onArtist, Modifier.weight(.85f).height(56.dp),
                label = { Text("Artista", maxLines = 1) }, singleLine = true,
                textStyle = TextStyle(fontSize = 13.sp),
            )
        }
        Row(Modifier.fillMaxWidth().background(SonusEditColors.SurfaceRaised, RoundedCornerShape(10.dp)).padding(horizontal = 10.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Partículas neste vídeo", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                Text("Pode desativar antes de exportar.", fontSize = 8.sp, color = SonusEditColors.TextMuted)
            }
            androidx.compose.material3.Switch(checked = particlesEnabled, onCheckedChange = onParticlesEnabled)
        }
        ReviewPreview23(
            audioUri = audioUri,
            imageUris = imageUris,
            localVideoUris = localVideoUris,
            startMs = startMs,
            durationMs = durationMs,
            captions = captions,
            visualTransitionIds = visualTransitionIds,
            aspectRatio = aspectRatio,
            font = font,
            lyricColor = lyricColor,
            filter = filter,
            effectsEnabled = effectsEnabled,
            effectId = effectId,
            effectOpacity = effectOpacity,
            portraitWidth = previewWidth,
            captionStyle = captionStyle,
            onRefreshStyle = onRefreshStyle,
            captionSizeScale = captionSizeScale,
            captionPositionPercent = captionPositionPercent,
            onCaptionEdit = onCaptionEdit,
        )
        CaptionAdjustSliders(
            sizeScale = captionSizeScale, onSizeScale = onCaptionSizeScale,
            positionPercent = captionPositionPercent, onPositionPercent = onCaptionPositionPercent,
        )
        Text("Qualidade", fontWeight = FontWeight.Bold, fontSize = 11.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            ExportResolution.entries.forEach { q ->
                QualityButton18(q.label, q == resolution, Modifier.weight(1f), enabled = capabilities.supports(q, fps)) { onResolution(q) }
            }
        }
        }
    }
}

@Composable
private fun ReviewPreview23(
    audioUri: String?,
    imageUris: List<String>,
    localVideoUris: Set<String>,
    startMs: Long,
    durationMs: Long,
    captions: List<CaptionSegment>,
    visualTransitionIds: List<String>,
    aspectRatio: String,
    font: FontPresetId,
    lyricColor: LyricColorPreset,
    filter: FilterPresetId,
    effectsEnabled: Boolean,
    effectId: String,
    effectOpacity: Float,
    portraitWidth: androidx.compose.ui.unit.Dp,
    captionStyle: CaptionStyleId,
    onRefreshStyle: () -> Unit,
    captionSizeScale: Float,
    captionPositionPercent: Float,
    onCaptionEdit: (Int, String) -> Unit,
) {
    val context = LocalContext.current
    var editingCaptionIndex by remember { mutableStateOf<Int?>(null) }
    var editingCaptionText by remember { mutableStateOf("") }
    val overlayDecoder = remember { PreviewEffectFrames(context.applicationContext) }
    DisposableEffect(overlayDecoder) { onDispose { overlayDecoder.close() } }
    val player = remember { ExoPlayer.Builder(context).build() }
    var playing by remember { mutableStateOf(false) }
    var resumeAfterCaptionEdit by remember { mutableStateOf(false) }
    var positionMs by remember(startMs, durationMs) { mutableStateOf(0L) }
    // Until the user plays or scrubs, the first caption loops so every style can be seen moving.
    var interacted by remember(startMs, durationMs) { mutableStateOf(false) }
    LaunchedEffect(captionStyle) { interacted = false }
    val demoMs by produceState(0L, captionStyle, interacted) {
        val began = System.currentTimeMillis()
        while (!interacted) {
            value = System.currentTimeMillis() - began
            delay(100L)
        }
    }
    val demoCaption = captions.firstOrNull()
    val captionTimeMs = if (!interacted && demoCaption != null) {
        val length = (demoCaption.endMs - demoCaption.startMs).coerceAtLeast(800L)
        demoCaption.startMs + demoMs % (length + 900L)
    } else positionMs

    DisposableEffect(player) { onDispose { player.release() } }
    LaunchedEffect(audioUri, startMs, durationMs) {
        player.stop()
        playing = false
        positionMs = 0L
        val value = audioUri ?: return@LaunchedEffect
        player.setMediaItem(MediaItem.fromUri(Uri.parse(value)))
        player.prepare()
        player.seekTo(startMs)
    }
    LaunchedEffect(playing, startMs, durationMs) {
        while (playing) {
            val rel = (player.currentPosition - startMs).coerceIn(0L, durationMs.coerceAtLeast(1L))
            positionMs = rel
            // Media3's export uses equal-power fade-in/out. Mirror the volume envelope in preview.
            val intro = (rel.toFloat() / 2_500f).coerceIn(0f, 1f)
            val outro = ((durationMs - rel).toFloat() / 2_500f).coerceIn(0f, 1f)
            player.volume = kotlin.math.sin(minOf(intro, outro) * Math.PI.toFloat() / 2f)
            if (rel >= durationMs.coerceAtLeast(1L) - 80L) {
                player.pause(); player.seekTo(startMs); positionMs = 0L; playing = false
                break
            }
            delay(100)
        }
    }

    fun finishCaptionEditing() {
        editingCaptionIndex = null
        if (resumeAfterCaptionEdit) {
            player.seekTo(startMs + positionMs.coerceIn(0L, durationMs.coerceAtLeast(1L)))
            player.play()
            playing = true
            resumeAfterCaptionEdit = false
        }
    }

    // Match the export's MediaDistributionPlanner rather than dividing by image count approximately.
    val durations = remember(durationMs, imageUris) {
        if (imageUris.isEmpty()) emptyList() else MediaDistributionPlanner.durationsForTotalMs(durationMs.coerceAtLeast(1L), imageUris.size)
    }
    var visualIndex = 0
    var visualStart = 0L
    for (index in durations.indices) {
        val end = visualStart + durations[index]
        if (positionMs < end || index == durations.lastIndex) { visualIndex = index; break }
        visualStart = end
    }
    val visualLength = durations.getOrNull(visualIndex)?.coerceAtLeast(1L) ?: 1L
    val localPosition = (positionMs - visualStart).coerceIn(0L, visualLength)
    val transitionId = visualTransitionIds.getOrNull(visualIndex) ?: "fade"
    val fadeMs = minOf(1_500L, visualLength / 2L).coerceAtLeast(1L)
    val entranceProgress = (localPosition.toFloat() / fadeMs).coerceIn(0f, 1f)
    val exitProgress = ((localPosition - (visualLength - fadeMs)).toFloat() / fadeMs).coerceIn(0f, 1f)
    val transitionEaseIn = entranceProgress * entranceProgress * (3f - 2f * entranceProgress)
    val transitionEaseOut = exitProgress * exitProgress * (3f - 2f * exitProgress)
    val fadeOpacity = if (transitionId == "fade") minOf(entranceProgress, 1f - exitProgress).coerceIn(0f, 1f) else 1f
    val visualUri = imageUris.getOrNull(visualIndex)
    val visualIsVideo = visualUri != null && visualUri in localVideoUris
    val previewBitmap by produceState<ImageBitmap?>(null, visualUri, visualIsVideo, if (visualIsVideo) positionMs / 550L else 0L) {
        val raw = visualUri
        value = if (raw == null) null else withContext(Dispatchers.IO) {
            val bitmap = if (raw.startsWith("http://") || raw.startsWith("https://")) {
                loadMediaBitmap18(raw)
            } else {
                if (visualIsVideo) loadVideoFrame11(context, raw, localPosition)
                else loadLocalMediaBitmap18(context, raw, false)
            }
            bitmap?.asImageBitmap()
        }
    }
    val particleFrame by produceState<ImageBitmap?>(null, effectId, effectsEnabled, positionMs / 450L) {
        value = if (!effectsEnabled || effectId == EffectIds.NONE || effectOpacity <= 0f) null else {
            withContext(Dispatchers.IO) { overlayDecoder.frameAt(effectId, positionMs, effectOpacity) }
        }
    }
    val caption = captions.lastOrNull { positionMs in it.startMs..it.endMs }
    val horizontal = ProjectAspectRatios.isHorizontal(aspectRatio)

    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        BoxWithConstraints(
            Modifier
                .then(
                    if (horizontal) Modifier.fillMaxWidth().aspectRatio(16f / 9f)
                    else Modifier.width(portraitWidth).aspectRatio(ProjectAspectRatios.parts(aspectRatio).let { it.first.toFloat() / it.second })
                )
                .background(Color(0xFF050711), RoundedCornerShape(12.dp))
                .clip(RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center,
        ) {
            val previewDensity = androidx.compose.ui.platform.LocalDensity.current
            val previewWidthPx = with(previewDensity) { maxWidth.toPx() }
            if (previewBitmap != null) {
                val enterActive = localPosition < fadeMs
                val exitActive = localPosition > visualLength - fadeMs
                val eased = if (enterActive) transitionEaseIn else if (exitActive) transitionEaseOut else 1f
                val scale = when (transitionId) {
                    "zoom" -> if (enterActive) 1f + .12f * eased else if (exitActive) 1.12f - .12f * eased else 1.12f
                    "slide", "rise" -> 1.14f
                    "rotate" -> 1.13f
                    "push" -> if (enterActive) 1.08f - .08f * eased else if (exitActive) 1f + .08f * eased else 1f
                    "parallax" -> if (enterActive) 1.10f - .04f * eased else if (exitActive) 1.06f + .04f * eased else 1.06f
                    else -> 1f
                }
                val translateX = when (transitionId) {
                    "slide" -> if (enterActive) -.065f * (1f - eased) else if (exitActive) .065f * eased else 0f
                    "push" -> if (enterActive) .0275f * (1f - eased) else if (exitActive) -.0275f * eased else 0f
                    "parallax" -> if (enterActive) .0175f * (1f - eased) else if (exitActive) -.0175f * eased else 0f
                    else -> 0f
                }
                val translateY = when (transitionId) {
                    "rise" -> if (enterActive) .065f * (1f - eased) else if (exitActive) -.065f * eased else 0f
                    "parallax" -> if (enterActive) .0125f * (1f - eased) else if (exitActive) -.0125f * eased else 0f
                    else -> 0f
                }
                val rotation = if (transitionId == "rotate") {
                    if (enterActive) -3.5f * (1f - eased) else if (exitActive) 3.5f * eased else 0f
                } else 0f
                val blurRadius = if (transitionId == "blur") {
                    val blurProgress = if (enterActive) (1f - eased) else if (exitActive) eased else 0f
                    val previewSigmaPx = (17f * previewWidthPx / 1080f) * blurProgress
                    with(previewDensity) { previewSigmaPx.toDp() }
                } else 0.dp
                Image(
                    previewBitmap!!,
                    null,
                    Modifier.fillMaxSize().blur(blurRadius).graphicsLayer {
                        alpha = fadeOpacity
                        scaleX = scale
                        scaleY = scale
                        translationX = translateX * size.width
                        translationY = translateY * size.height
                        rotationZ = rotation
                    },
                    contentScale = ContentScale.Crop,
                    colorFilter = filterPreviewColor18(filter),
                )
                if (transitionId == "wipe" && (enterActive || exitActive)) {
                    val cover = if (enterActive) 1f - transitionEaseIn else transitionEaseOut
                    Box(
                        Modifier.fillMaxHeight().fillMaxWidth(cover.coerceIn(0f, 1f))
                            .align(Alignment.CenterStart).background(Color.Black),
                    )
                }
                if (transitionId == "light" && (enterActive || exitActive)) {
                    val p = if (enterActive) transitionEaseIn else transitionEaseOut
                    val bandWidth = .38f
                    // Position the preview band's left edge to match the export overlay's centered shader band.
                    val x = if (enterActive) (-bandWidth * 1.5f + p * (1f + bandWidth))
                        else (p * (1f + bandWidth) - bandWidth / 2f)
                    Box(
                        Modifier.fillMaxWidth(bandWidth).fillMaxHeight()
                            .graphicsLayer { translationX = x * size.width }
                            .background(Brush.horizontalGradient(listOf(Color.Transparent, Color.White.copy(alpha = .29f), Color.Transparent))),
                    )
                }
            }
            if (particleFrame != null) {
                Image(
                    particleFrame!!,
                    "Efeito visual em prévia",
                    Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                )
            }
            if (visualIsVideo) {
                Icon(Icons.Default.VideoFile, null, Modifier.align(Alignment.TopStart).padding(6.dp).size(16.dp), tint = Color.White)
            }
            CaptionOverlayCanvas(
                captions = captions,
                timeMs = captionTimeMs,
                font = font,
                color = lyricColor,
                style = captionStyle,
                position = CaptionPosition.MIDDLE,
                modifier = Modifier.fillMaxSize().clickable {
                    val activeIndex = captions.indexOfLast { captionTimeMs in it.startMs..it.endMs }
                    if (activeIndex >= 0) {
                        resumeAfterCaptionEdit = playing
                        if (playing) {
                            positionMs = (player.currentPosition - startMs).coerceIn(0L, durationMs.coerceAtLeast(1L))
                            player.pause()
                            playing = false
                        }
                        editingCaptionIndex = activeIndex
                        editingCaptionText = captions[activeIndex].text
                        interacted = true
                    }
                },
                textScale = 1.8f,
                sizeScale = captionSizeScale,
                positionPercent = captionPositionPercent,
            )
            if (captions.isNotEmpty()) {
                Text("Toque na legenda para corrigir", Modifier.align(Alignment.BottomCenter).padding(bottom = 18.dp), color = Color.White.copy(alpha = .72f), fontSize = 8.sp)
            }
            Text(
                captionStyle.label,
                Modifier.align(Alignment.BottomCenter).padding(bottom = 3.dp),
                color = Color.White.copy(alpha = .8f),
                fontSize = 8.sp,
                maxLines = 1,
            )
            Row(
                Modifier
                    .align(Alignment.TopEnd)
                    .padding(4.dp)
                    .background(Color(0xAA000000), RoundedCornerShape(10.dp))
                    .clickable(onClick = onRefreshStyle)
                    .padding(horizontal = 6.dp, vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Default.Refresh, null, Modifier.size(10.dp), tint = SonusEditColors.Cyan)
                Text(" ESTILO", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            }
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(
                onClick = {
                    interacted = true
                    if (playing) { player.pause(); playing = false }
                    else {
                        if (positionMs >= durationMs - 100L) { positionMs = 0L; player.seekTo(startMs) }
                        player.play(); playing = true
                    }
                },
                modifier = Modifier.size(34.dp),
            ) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = SonusEditColors.Cyan) }
            Slider(
                value = positionMs.toFloat(),
                onValueChange = {
                    interacted = true
                    val next = it.toLong().coerceIn(0L, durationMs.coerceAtLeast(1L))
                    positionMs = next
                    player.seekTo(startMs + next)
                },
                valueRange = 0f..durationMs.coerceAtLeast(1L).toFloat(),
                modifier = Modifier.weight(1f).height(16.dp),
            )
            Text(formatTime18(positionMs), color = SonusEditColors.TextMuted, fontSize = 9.sp, modifier = Modifier.width(36.dp))
        }
    }
    editingCaptionIndex?.let { index ->
        AlertDialog(
            onDismissRequest = { finishCaptionEditing() },
            title = { Text("Corrigir legenda") },
            text = {
                OutlinedTextField(
                    value = editingCaptionText,
                    onValueChange = { editingCaptionText = it },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2,
                    maxLines = 5,
                    label = { Text("Texto da legenda") },
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    onCaptionEdit(index, editingCaptionText.trim())
                    finishCaptionEditing()
                }) { Text("SALVAR") }
            },
            dismissButton = { TextButton(onClick = { finishCaptionEditing() }) { Text("CANCELAR") } },
        )
    }
}

@Composable
private fun ReviewToggleButton20(label: String, selected: Boolean, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.width(92.dp).height(32.dp),
        shape = RoundedCornerShape(10.dp),
        colors = ButtonDefaults.buttonColors(containerColor = if (selected) Color(0xFF3A79A8) else SonusEditColors.SurfaceRaised),
        contentPadding = PaddingValues(0.dp),
    ) {
        Text(label, color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
internal fun QualityButton18(label: String, selected: Boolean, modifier: Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Button(
        onClick = onClick, enabled = enabled, modifier = modifier.height(38.dp), shape = RoundedCornerShape(10.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (selected) Color(0xFF3A79A8) else Color(0xFF234B3A),
            disabledContainerColor = Color(0xFF1A2A22),
        ),
        contentPadding = PaddingValues(0.dp),
    ) {
        Text(label, color = if (enabled) Color.White else Color(0xFF68736D), fontWeight = FontWeight.ExtraBold, fontSize = 10.sp,
            style = androidx.compose.ui.text.TextStyle(shadow = Shadow(Color.Black, Offset(1f, 1f), 1.5f)))
    }
}

@Composable
private fun ReviewLine18(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 1.dp)) {
        Text("$label  ", color = SonusEditColors.TextMuted, fontSize = 10.sp)
        Text(value, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 1)
    }
}

@Composable
internal fun Section18(title: String, subtitle: String? = null, compact: Boolean = false, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = SonusEditColors.Surface), shape = RoundedCornerShape(if (compact) 14.dp else 20.dp)) {
        Column(Modifier.fillMaxWidth().padding(if (compact) 8.dp else 13.dp), verticalArrangement = Arrangement.spacedBy(if (compact) 4.dp else 9.dp)) {
            if (title.isNotBlank()) Text(title, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            subtitle?.let { Text(it, color = SonusEditColors.TextMuted, fontSize = 9.sp) }
            content()
        }
    }
}

private fun sourceLabel18(source: AudioSource): String = when (source) {
    AudioSource.SONUS_STREAM -> "Sonus Stream"
    AudioSource.LOCAL -> "Local"
    AudioSource.LINK -> "Link"
    AudioSource.SHARED -> "Compartilhado"
    AudioSource.VIDEO_EXTRACTED -> "Áudio de vídeo"
}

internal fun formatTime18(ms: Long): String {
    val total = (ms.coerceAtLeast(0L) / 1000L).toInt()
    return "%02d:%02d".format(total / 60, total % 60)
}


private fun normalizeLookup18(value: String): String = Normalizer.normalize(value, Normalizer.Form.NFD)
    .replace(Regex("\\p{M}+"), "")
    .lowercase()
    .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
    .trim()
    .replace(Regex("\\s+"), " ")

private fun cleanExportTitle18(value: String, artist: String?): String {
    var text = value.substringBeforeLast('.', value).trim()
    val junk = Regex("(?i)\\s*[\\[(](vídeo oficial|video oficial|official video|official audio|lyric video|lyrics?|visualizer|audio|hd|4k)[^\\])]*[\\])]\\s*")
    text = text.replace(junk, " ")
    val a = artist.orEmpty().trim()
    if (a.isNotBlank()) {
        text = text.replace(Regex("(?i)^${Regex.escape(a)}\\s*[-–—|•:]\\s*"), "")
        text = text.replace(Regex("(?i)\\s*[-–—|•:]\\s*${Regex.escape(a)}$"), "")
    }
    return text.replace(Regex("\\s+"), " ").trim(' ', '-', '–', '—', '|', '•').ifBlank { value.trim() }
}

private fun lyricColor18(preset: LyricColorPreset, index: Int): Color =
    Color(LyricColorPalette24.argb(preset, index))

private suspend fun loadMediaBitmap18(value: String): Bitmap? = withContext(Dispatchers.IO) {
    runCatching {
        val uri = Uri.parse(value)
        when (uri.scheme?.lowercase()) {
            "http", "https" -> {
                val connection = (URI.create(value).toURL().openConnection() as HttpURLConnection).apply {
                    connectTimeout = 7_000
                    readTimeout = 10_000
                    instanceFollowRedirects = true
                    setRequestProperty("Accept", "image/*,*/*;q=0.8")
                    setRequestProperty("User-Agent", "Sonus-Edit/1.0 Android")
                }
                try {
                    if (connection.responseCode !in 200..299) return@runCatching null
                    connection.inputStream.use { stream ->
                        decodeThumbnail18(stream.readBytes())
                    }
                } finally {
                    connection.disconnect()
                }
            }
            "file" -> uri.path?.let { decodeThumbnailFile18(it) }
            else -> decodeThumbnailFile18(value)
        }
    }.getOrNull()
}

private suspend fun loadLocalMediaBitmap18(context: Context, value: String, video: Boolean): Bitmap? = withContext(Dispatchers.IO) {
    runCatching {
        val uri = Uri.parse(value)
        if (video) {
            val retriever = MediaMetadataRetriever()
            try {
                when (uri.scheme?.lowercase()) {
                    "content", "file" -> retriever.setDataSource(context, uri)
                    "http", "https" -> retriever.setDataSource(value, emptyMap())
                    else -> retriever.setDataSource(value)
                }
                retriever.getFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)?.thumbnail18()
            } finally {
                runCatching { retriever.release() }
            }
        } else {
            when (uri.scheme?.lowercase()) {
                "content" -> {
                    val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    bytes?.let { decodeThumbnail18(it) }
                }
                "file" -> uri.path?.let { path -> decodeThumbnailFile18(path) }
                "http", "https" -> loadMediaBitmap18(value)
                else -> decodeThumbnailFile18(value)
            }
        }
    }.getOrNull()
}

private fun decodeThumbnail18(bytes: ByteArray, maxWidth: Int = 300, maxHeight: Int = 450): Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    val options = BitmapFactory.Options().apply { inSampleSize = sampleSize18(bounds.outWidth, bounds.outHeight, maxWidth, maxHeight) }
    return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)?.thumbnail18(maxWidth, maxHeight)
}

private fun decodeThumbnailFile18(path: String, maxWidth: Int = 300, maxHeight: Int = 450): Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(path, bounds)
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    val options = BitmapFactory.Options().apply { inSampleSize = sampleSize18(bounds.outWidth, bounds.outHeight, maxWidth, maxHeight) }
    return BitmapFactory.decodeFile(path, options)?.thumbnail18(maxWidth, maxHeight)
}

private fun sampleSize18(width: Int, height: Int, targetWidth: Int, targetHeight: Int): Int {
    var sample = 1
    while (width / (sample * 2) >= targetWidth && height / (sample * 2) >= targetHeight) sample *= 2
    return sample
}

private fun Bitmap.thumbnail18(maxWidth: Int = 300, maxHeight: Int = 450): Bitmap {
    if (width <= maxWidth && height <= maxHeight) return this
    val scale = minOf(maxWidth.toFloat() / width.toFloat(), maxHeight.toFloat() / height.toFloat())
    val targetWidth = (width * scale).roundToInt().coerceAtLeast(1)
    val targetHeight = (height * scale).roundToInt().coerceAtLeast(1)
    return Bitmap.createScaledBitmap(this, targetWidth, targetHeight, true).also { scaled ->
        if (scaled !== this) recycle()
    }
}

/**
 * Resolve a compact 240x360 gallery thumbnail and cache it on disk. The original media URL is
 * untouched and remains the source for project preview/export. For remote videos, decode one frame
 * instead of trying to parse MP4 bytes as a bitmap.
 */
private suspend fun loadRemoteAssetThumbnail18(
    context: Context,
    asset: PCloudAsset,
    repo: PCloudCatalogRepository,
): Bitmap? = galleryThumbnailSemaphore18.withPermit {
    withContext(Dispatchers.IO) {
    runCatching {
        val cacheDir = File(context.cacheDir, "sonus_gallery_thumbs_v2").apply { mkdirs() }
        val identity = "${asset.stableKey}|${asset.modified.orEmpty()}|${asset.size}"
        val digest = MessageDigest.getInstance("SHA-256").digest(identity.toByteArray())
            .joinToString("") { "%02x".format(it) }
        val cacheFile = File(cacheDir, "$digest.jpg")
        if (cacheFile.isFile && cacheFile.length() > 0L) {
            decodeThumbnailFile18(cacheFile.absolutePath, 240, 360)?.let { return@runCatching it }
        }

        var thumbnailUrl = repo.thumbnailUrl(asset)
        var bitmap = thumbnailUrl?.let { loadMediaBitmap18(it) }
        if (bitmap == null && thumbnailUrl != null) {
            repo.invalidateThumbnailUrl(asset)
            thumbnailUrl = repo.thumbnailUrl(asset)
            bitmap = thumbnailUrl?.let { loadMediaBitmap18(it) }
        }
        if (bitmap == null) {
            var mediaUrl = repo.downloadUrl(asset)
            if (mediaUrl != null && asset.extension.lowercase() !in videoExt18) {
                bitmap = loadMediaBitmap18(mediaUrl)
                if (bitmap == null) {
                    repo.invalidateDownloadUrl(asset)
                    mediaUrl = repo.downloadUrl(asset)
                }
            }
            if (mediaUrl != null && bitmap == null) {
                bitmap = if (asset.extension.lowercase() in videoExt18) {
                    val retriever = MediaMetadataRetriever()
                    try {
                        retriever.setDataSource(mediaUrl, emptyMap())
                        if (android.os.Build.VERSION.SDK_INT >= 27) {
                            retriever.getScaledFrameAtTime(650_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 240, 360)
                        } else {
                            retriever.getFrameAtTime(650_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                        }?.thumbnail18(240, 360)
                    } finally { runCatching { retriever.release() } }
                } else loadMediaBitmap18(mediaUrl)
            }
        }
        bitmap?.let { image ->
            val compact = image.thumbnail18(240, 360)
            runCatching { cacheFile.outputStream().use { compact.compress(Bitmap.CompressFormat.JPEG, 78, it) } }
            compact
        }
    }.getOrNull()
    }
}

/** Preview local video at the relevant playback position; always downscale for memory safety. */
private fun loadVideoFrame11(context: Context, source: String, timeMs: Long): Bitmap? {
    val retriever = MediaMetadataRetriever()
    return try {
        retriever.setDataSource(context, Uri.parse(source))
        if (android.os.Build.VERSION.SDK_INT >= 27) {
            retriever.getScaledFrameAtTime(timeMs * 1_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 240, 426)
        } else {
            retriever.getFrameAtTime(timeMs * 1_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
        }
    } catch (_: Exception) { null }
    finally { runCatching { retriever.release() } }
}
