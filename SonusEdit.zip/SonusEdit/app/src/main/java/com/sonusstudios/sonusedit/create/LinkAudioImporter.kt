package com.sonusstudios.sonusedit.create

import android.content.Context
import android.net.Uri
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Compatibility facade for the creation flow. The editor receives a temporary media file and
 * keeps treating it as a local source, while the implementation is delegated to SONUS Link Engine.
 */
class LinkAudioImporter(private val context: Context) {
    data class Progress(
        val title: String = "Importando link",
        val status: String,
        val percent: Int? = null,
        val processId: String? = null,
    )

    data class Result(
        val localUri: Uri,
        val metadata: AudioMetadata,
        val originalUrl: String,
        val providerLabel: String,
        val thumbnailUrl: String? = null,
        val originalTitle: String? = null,
        val usageSummary: String? = null,
    )

    private val engine = SonusLinkEngine(context.applicationContext)

    suspend fun prewarm() = engine.prewarm()

    fun usageSummary(): String = engine.currentCobaltUsageSummary()

    suspend fun syncUsageSummary(): String = engine.syncCobaltUsageSummary()

    suspend fun import(
        rawUrl: String,
        onProgress: (Progress) -> Unit,
    ): Result = withContext(Dispatchers.IO) {
        val downloaded = engine.download(rawUrl) { update ->
            onProgress(Progress(status = update.status, percent = update.percent, processId = update.processId))
        }
        val uri = Uri.fromFile(downloaded.file)
        val embedded = runCatching { AudioMetadataReader.read(context, uri) }.getOrNull()
        val rawTitle = embedded?.title?.takeIf { it.isNotBlank() && it != "Música selecionada" }
            ?: downloaded.displayTitle
        val cleaned = MetadataSanitizer.clean(rawTitle, embedded?.artist)
        val metadata = AudioMetadata(
            title = cleaned.title,
            artist = cleaned.artist,
            durationMs = embedded?.durationMs?.takeIf { it > 0L } ?: 0L,
            album = embedded?.album,
            genre = embedded?.genre,
        )
        Result(
            localUri = uri,
            metadata = metadata,
            originalUrl = downloaded.normalizedUrl,
            providerLabel = downloaded.providerLabel,
            originalTitle = rawTitle,
            usageSummary = downloaded.usageSummary,
        )
    }

    fun cancel(processId: String?) = engine.cancel(processId)

    companion object {
        const val CACHE_FOLDER = "sonus_edit_link_audio"

        /** Delete only files created inside the dedicated link-import cache. */
        fun deleteImportedAudio(context: Context, uriString: String) {
            val uri = runCatching { Uri.parse(uriString) }.getOrNull() ?: return
            if (uri.scheme != "file") return
            val file = uri.path?.let(::File) ?: return
            val root = File(context.cacheDir, CACHE_FOLDER)
            val insideCache = runCatching {
                file.canonicalPath.startsWith(root.canonicalPath + File.separator)
            }.getOrDefault(false)
            if (insideCache) runCatching { file.delete() }
        }
    }
}
