package com.sonusstudios.sonusedit.create

import android.content.Context
import android.net.Uri
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import android.util.Log
import java.io.IOException
import java.io.File
import java.net.URI
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

/**
 * Resolves a public media page to a temporary local audio-capable file.
 * The editor never needs provider-specific logic: once imported, the result behaves like Local.
 */
class LinkAudioImporter(private val context: Context) {
    data class Progress(
        val title: String = "Importando link",
        val status: String,
        val percent: Int? = null,
        val processId: String? = null,
    )

    data class Result(
        val localUri: Uri,
        val metadata: AudioMetadata,
        val originalUrl: String,
        val providerLabel: String,
        val thumbnailUrl: String? = null,
        val originalTitle: String? = null,
    )

    private val cacheRoot = File(context.cacheDir, CACHE_FOLDER).apply { mkdirs() }
    private val json = Json { ignoreUnknownKeys = true }

    /** Warm only the local resolver. Network/catalog work never blocks opening the Link UI. */
    suspend fun prewarm() = withContext(Dispatchers.IO) {
        ensureInitialized()
    }

    private fun ensureInitialized() {
        if (initialized) return
        synchronized(initLock) {
            if (!initialized) {
                YoutubeDL.getInstance().init(context.applicationContext)
                // youtubedl-android always advertises an ffmpeg location to yt-dlp. Shipping and
                // initialising the matching 0.18.1 module prevents the intermittent
                // "libffmpeg.so does not exist" first-attempt failure seen on device.
                FFmpeg.getInstance().init(context.applicationContext)
                initialized = true
            }
        }
    }

    suspend fun import(
        rawUrl: String,
        onProgress: (Progress) -> Unit,
    ): Result = withContext(Dispatchers.IO) {
        val url = normalizeUrl(rawUrl)
        require(url.startsWith("https://") || url.startsWith("http://")) {
            "Cole um link válido começando com http:// ou https://."
        }
        cleanupStaleFiles()

        val provider = providerLabel(url)
        val processId = "sonus_link_${UUID.randomUUID()}"
        onProgress(Progress(status = "Preparando importador…", processId = processId))

        runCatching { ensureInitialized() }
            .getOrElse { throw IllegalStateException("Não foi possível preparar o importador de links: ${it.message}", it) }

        // Refresh the extractor before its first use (and at most once per 24h).
        // The native Python/QuickJS/FFmpeg bundle is NOT replaced by this updater.
        refreshResolverIfDue(onProgress)
        onProgress(Progress(status = "Identificando fonte…", processId = processId))
        val token = "link_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(8)}"
        val outputTemplate = File(cacheRoot, "$token.%(ext)s").absolutePath
        val request = YoutubeDLRequest(url).apply {
            addOption("--no-playlist")
            addOption("--no-part")
            addOption("--no-mtime")
            addOption("--write-info-json")
            addOption("--no-write-playlist-metafiles")
            // Retry transient CDN/fragment failures commonly seen on social short-video links.
            // These options do not change extractor selection or the existing YouTube format rule.
            addOption("--retries", "2")
            addOption("--extractor-retries", "2")
            addOption("--fragment-retries", "2")
            addOption("--socket-timeout", "20")
            // Prefer a native audio stream. If the provider exposes only a combined media file,
            // fall back to it; Media3 consumes its audio track directly without a second pipeline.
            addOption("-f", "bestaudio[ext=m4a]/bestaudio/best")
            addOption("-o", outputTemplate)
        }

        onProgress(Progress(status = "Obtendo áudio…", percent = null, processId = processId))
        try {
            YoutubeDL.getInstance().execute(request, processId) { progress, _, line ->
                val safe = progress.toInt().coerceIn(0, 100)
                val status = when {
                    line.contains("Extracting", ignoreCase = true) -> "Preparando mídia…"
                    line.contains("Destination", ignoreCase = true) -> "Baixando áudio…"
                    else -> "Obtendo áudio…"
                }
                onProgress(Progress(status = status, percent = safe.takeIf { it > 0 }, processId = processId))
            }
        } catch (error: Throwable) {
            cacheRoot.listFiles().orEmpty().filter { it.name.startsWith(token) }.forEach { it.delete() }
            Log.e("SONUS-Link", "yt-dlp failed for provider=$provider", error)
            throw IllegalStateException(linkFailureText(error), error)
        }

        onProgress(Progress(status = "Preparando trecho…", percent = 100, processId = processId))
        val files = cacheRoot.listFiles().orEmpty().filter { it.name.startsWith(token) }
        val mediaFile = files
            .filterNot { it.name.endsWith(".info.json") || it.name.endsWith(".part") || it.name.endsWith(".ytdl") }
            .maxByOrNull { it.length() }
            ?: error("O link foi lido, mas nenhum áudio utilizável foi criado.")
        val infoFile = files.firstOrNull { it.name.endsWith(".info.json") }
        val sourceInfo = infoFile?.let(::readInfo)

        val embedded = runCatching { AudioMetadataReader.read(context, Uri.fromFile(mediaFile)) }.getOrNull()
        val rawTitle = sourceInfo?.title?.takeIf { it.isNotBlank() }
            ?: embedded?.title?.takeIf { it.isNotBlank() && !it.startsWith("link_") }
            ?: "Áudio importado"
        val rawArtist = sourceInfo?.artist ?: embedded?.artist
        val cleaned = MetadataSanitizer.clean(rawTitle, rawArtist)
        val metadata = AudioMetadata(
            title = cleaned.title,
            artist = cleaned.artist,
            durationMs = embedded?.durationMs?.takeIf { it > 0 }
                ?: sourceInfo?.durationMs?.takeIf { it > 0 }
                ?: 0L,
            album = sourceInfo?.album ?: embedded?.album,
            genre = sourceInfo?.genre ?: embedded?.genre,
        )
        infoFile?.delete()

        Result(
            localUri = Uri.fromFile(mediaFile),
            metadata = metadata,
            originalUrl = url,
            providerLabel = provider,
            thumbnailUrl = sourceInfo?.thumbnail,
            originalTitle = rawTitle,
        )
    }

    /**
     * Code28: the system-bundled yt-dlp becomes stale even when the APK has not changed.
     * Maintain the Python/QuickJS/FFmpeg package from the known 0.18.1 release, and update ONLY
     * the yt-dlp executable through the wrapper's stable-channel updater.
     *
     * Protect against an incompatible upstream binary: backup before an update, verify it with
     * --version on the installed Python, and restore the last working executable if verification
     * fails. Import continues with the old resolver when network is unavailable.
     */
    private fun refreshResolverIfDue(onProgress: (Progress) -> Unit) {
        synchronized(updateLock) {
            val prefs = context.getSharedPreferences("sonus_link_resolver_v14", Context.MODE_PRIVATE)
            val now = System.currentTimeMillis()
            val lastCheck = prefs.getLong("last_check", 0L)
            if (lastCheck in 1..now && now - lastCheck < UPDATE_INTERVAL_MS) return
            onProgress(Progress(status = "Verificando atualizações do Link…"))
            val upstreamPrefs = context.getSharedPreferences("youtubedl-android", Context.MODE_PRIVATE)
            val oldVersion = upstreamPrefs.getString("dlpVersion", null)
            val oldVersionName = upstreamPrefs.getString("dlpVersionName", null)
            val installed = File(File(context.noBackupFilesDir, YoutubeDL.baseName),
                "${YoutubeDL.ytdlpDirName}/${YoutubeDL.ytdlpBin}")
            val backup = File(context.cacheDir, "sonus_ytdlp_last_working")
            val backedUp = runCatching {
                if (installed.isFile && installed.length() > 0L) {
                    installed.copyTo(backup, overwrite = true); true
                } else false
            }.getOrDefault(false)
            try {
                // The updater is synchronized internally; never update during execute().
                val status = YoutubeDL.getInstance().updateYoutubeDL(
                    context.applicationContext, YoutubeDL.UpdateChannel.STABLE)
                // --version alone does not exercise Python imports/extractor dependencies.
                YoutubeDL.getInstance().execute(YoutubeDLRequest("--version"))
                YoutubeDL.getInstance().execute(YoutubeDLRequest("--list-extractors"))
                prefs.edit().putLong("last_check", now).apply()
                Log.i("SONUS-Link", "Resolver checked: $status")
            } catch (error: Exception) {
                if (backedUp) {
                    runCatching {
                        backup.copyTo(installed, overwrite = true)
                        upstreamPrefs.edit().putString("dlpVersion", oldVersion)
                            .putString("dlpVersionName", oldVersionName).apply()
                    }.onFailure { Log.e("SONUS-Link", "Could not restore yt-dlp binary", it) }
                }
                // On a network failure, continue with the bundled/previously verified binary.
                // Retry the check next import instead of marking the stale resolver current.
                Log.w("SONUS-Link", "Resolver update/verification unavailable; using fallback", error)
                onProgress(Progress(status = "Usando importador disponível…"))
            } finally {
                backup.delete()
            }
        }
    }

    private fun linkFailureText(error: Throwable): String {
        val description = generateSequence(error) { it.cause }
            .mapNotNull { it.message }.joinToString(" • ").take(600)
        return when {
            description.contains("Sign in", true) || description.contains("login", true) ->
                "Esta mídia exige autenticação na origem. Experimente outro link público."
            description.contains("HTTP Error 403", true) || description.contains("403 Forbidden", true) ->
                "O site recusou o download (403). Verifique o link e tente novamente."
            description.contains("Unsupported URL", true) ->
                "O endereço não é reconhecido pelo importador. Cole o link completo."
            description.contains("no formats", true) ->
                "Não foi encontrada uma faixa de áudio disponível nesse link."
            description.contains("python", true) && description.contains("requires", true) ->
                "O motor do Link precisa de compatibilidade com Python mais recente. Verifique a atualização do aplicativo."
            description.isNotBlank() -> "Falha na importação: ${description.take(220)}"
            else -> "Não foi possível importar o Link. Tente novamente mais tarde."
        }
    }

    fun cancel(processId: String?) {
        if (!processId.isNullOrBlank()) runCatching { YoutubeDL.getInstance().destroyProcessById(processId) }
    }

    private data class SourceInfo(
        val title: String?,
        val artist: String?,
        val durationMs: Long?,
        val album: String?,
        val genre: String?,
        val thumbnail: String?,
    )

    private fun readInfo(file: File): SourceInfo? = runCatching {
        val root = json.parseToJsonElement(file.readText()).jsonObject
        val durationMs = root["duration"]?.jsonPrimitive?.doubleOrNull?.let { (it * 1_000.0).toLong() }
        val categories = root["categories"]?.toString()
            ?.removePrefix("[")?.removeSuffix("]")?.replace("\"", "")
            ?.split(',')?.firstOrNull()?.trim()?.takeIf { it.isNotBlank() }
        SourceInfo(
            title = root["title"]?.jsonPrimitive?.contentOrNull,
            artist = root["artist"]?.jsonPrimitive?.contentOrNull
                ?: root["uploader"]?.jsonPrimitive?.contentOrNull
                ?: root["channel"]?.jsonPrimitive?.contentOrNull,
            durationMs = durationMs,
            album = root["album"]?.jsonPrimitive?.contentOrNull,
            genre = root["genre"]?.jsonPrimitive?.contentOrNull ?: categories,
            thumbnail = root["thumbnail"]?.jsonPrimitive?.contentOrNull,
        )
    }.getOrNull()

    private fun normalizeUrl(value: String): String {
        val raw = value.trim()
        if (raw.isBlank()) return raw
        val withScheme = if (raw.startsWith("http://", true) || raw.startsWith("https://", true)) raw else "https://$raw"
        val uri = runCatching { URI.create(withScheme) }.getOrNull() ?: return withScheme
        val host = uri.host?.lowercase().orEmpty()
        // TikTok share URLs commonly include tracking query parameters and redirects. Keep the
        // complete path (including /t/ short IDs) but drop fragments that do not identify media.
        val canonicalHost = when {
            host == "vm.tiktok.com" || host == "vt.tiktok.com" -> host
            host == "m.tiktok.com" || host == "www.tiktok.com" -> "www.tiktok.com"
            host == "m.youtube.com" || host == "music.youtube.com" -> host
            host == "youtu.be" -> "youtu.be"
            else -> host
        }
        return runCatching {
            URI(uri.scheme ?: "https", uri.userInfo, canonicalHost.ifBlank { host }, uri.port,
                uri.path, uri.query, null).toASCIIString()
        }.getOrDefault(withScheme)
    }

    private fun providerLabel(url: String): String = runCatching {
        val host = URI.create(url).host.orEmpty().lowercase()
        when {
            "youtu.be" in host || "youtube.com" in host || "music.youtube.com" in host -> "YouTube"
            "tiktok.com" in host -> "TikTok"
            "instagram.com" in host -> "Instagram"
            "facebook.com" in host || "fb.watch" in host -> "Facebook"
            "x.com" == host || "twitter.com" in host -> "X"
            "soundcloud.com" in host -> "SoundCloud"
            else -> host.removePrefix("www.").ifBlank { "Link" }
        }
    }.getOrDefault("Link")

    private fun cleanupStaleFiles() {
        val cutoff = System.currentTimeMillis() - 24L * 60L * 60L * 1_000L
        cacheRoot.listFiles().orEmpty().filter { it.lastModified() < cutoff }.forEach { it.delete() }
    }

    companion object {
        const val CACHE_FOLDER = "sonus_edit_link_audio"
        @Volatile private var initialized = false
        private val initLock = Any()
        private val updateLock = Any()
        private const val UPDATE_INTERVAL_MS = 24L * 60L * 60L * 1_000L

        /** Delete only files created inside the dedicated link-import cache. */
        fun deleteImportedAudio(context: Context, uriString: String) {
            val uri = runCatching { Uri.parse(uriString) }.getOrNull() ?: return
            if (uri.scheme != "file") return
            val file = uri.path?.let(::File) ?: return
            val root = File(context.cacheDir, CACHE_FOLDER)
            val insideCache = runCatching { file.canonicalPath.startsWith(root.canonicalPath + File.separator) }.getOrDefault(false)
            if (insideCache) runCatching { file.delete() }
        }
    }
}

private val kotlinx.serialization.json.JsonPrimitive.contentOrNull: String?
    get() = runCatching { content }.getOrNull()
