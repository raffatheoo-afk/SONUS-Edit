package com.sonusstudios.sonusedit.create

import android.content.Context
import android.net.Uri
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import java.io.File
import java.net.URI
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

/**
 * Resolves a public media page to a temporary local audio-capable file.
 * The editor never needs provider-specific logic: once imported, the result behaves like Local.
 */
class LinkAudioImporter(private val context: Context) {
    data class Progress(
        val title: String = "Importando link",
        val status: String,
        val percent: Int? = null,
        val processId: String? = null,
    )

    data class Result(
        val localUri: Uri,
        val metadata: AudioMetadata,
        val originalUrl: String,
        val providerLabel: String,
        val thumbnailUrl: String? = null,
        val originalTitle: String? = null,
    )

    private val cacheRoot = File(context.cacheDir, CACHE_FOLDER).apply { mkdirs() }
    private val json = Json { ignoreUnknownKeys = true }

    /** Warm only the local resolver. Network/catalog work never blocks opening the Link UI. */
    suspend fun prewarm() = withContext(Dispatchers.IO) {
        ensureInitialized()
    }

    private fun ensureInitialized() {
        if (initialized) return
        synchronized(initLock) {
            if (!initialized) {
                YoutubeDL.getInstance().init(context.applicationContext)
                // youtubedl-android always advertises an ffmpeg location to yt-dlp. Shipping and
                // initialising the matching 0.18.1 module prevents the intermittent
                // "libffmpeg.so does not exist" first-attempt failure seen on device.
                FFmpeg.getInstance().init(context.applicationContext)
                initialized = true
            }
        }
    }

    suspend fun import(
        rawUrl: String,
        onProgress: (Progress) -> Unit,
    ): Result = withContext(Dispatchers.IO) {
        val url = normalizeUrl(rawUrl)
        require(url.startsWith("https://") || url.startsWith("http://")) {
            "Cole um link válido começando com http:// ou https://."
        }
        cleanupStaleFiles()

        val provider = providerLabel(url)
        val processId = "sonus_link_${UUID.randomUUID()}"
        onProgress(Progress(status = "Preparando importador…", processId = processId))

        runCatching { ensureInitialized() }
            .getOrElse { throw IllegalStateException("Não foi possível preparar o importador de links: ${it.message}", it) }

        onProgress(Progress(status = "Identificando fonte…", processId = processId))
        val token = "link_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(8)}"
        val outputTemplate = File(cacheRoot, "$token.%(ext)s").absolutePath
        val request = YoutubeDLRequest(url).apply {
            addOption("--no-playlist")
            addOption("--no-part")
            addOption("--no-mtime")
            addOption("--write-info-json")
            addOption("--no-write-playlist-metafiles")
            // Prefer a native audio stream. If the provider exposes only a combined media file,
            // fall back to it; Media3 consumes its audio track directly without a second pipeline.
            addOption("-f", "bestaudio[ext=m4a]/bestaudio/best")
            addOption("-o", outputTemplate)
        }

        onProgress(Progress(status = "Obtendo áudio…", percent = null, processId = processId))
        try {
            YoutubeDL.getInstance().execute(request, processId) { progress, _, line ->
                val safe = progress.toInt().coerceIn(0, 100)
                val status = when {
                    line.contains("Extracting", ignoreCase = true) -> "Preparando mídia…"
                    line.contains("Destination", ignoreCase = true) -> "Baixando áudio…"
                    else -> "Obtendo áudio…"
                }
                onProgress(Progress(status = status, percent = safe.takeIf { it > 0 }, processId = processId))
            }
        } catch (error: Throwable) {
            cacheRoot.listFiles().orEmpty().filter { it.name.startsWith(token) }.forEach { it.delete() }
            throw error
        }

        onProgress(Progress(status = "Preparando trecho…", percent = 100, processId = processId))
        val files = cacheRoot.listFiles().orEmpty().filter { it.name.startsWith(token) }
        val mediaFile = files
            .filterNot { it.name.endsWith(".info.json") || it.name.endsWith(".part") || it.name.endsWith(".ytdl") }
            .maxByOrNull { it.length() }
            ?: error("O link foi lido, mas nenhum áudio utilizável foi criado.")
        val infoFile = files.firstOrNull { it.name.endsWith(".info.json") }
        val sourceInfo = infoFile?.let(::readInfo)

        val embedded = runCatching { AudioMetadataReader.read(context, Uri.fromFile(mediaFile)) }.getOrNull()
        val rawTitle = sourceInfo?.title?.takeIf { it.isNotBlank() }
            ?: embedded?.title?.takeIf { it.isNotBlank() && !it.startsWith("link_") }
            ?: "Áudio importado"
        val rawArtist = sourceInfo?.artist ?: embedded?.artist
        val cleaned = MetadataSanitizer.clean(rawTitle, rawArtist)
        val metadata = AudioMetadata(
            title = cleaned.title,
            artist = cleaned.artist,
            durationMs = embedded?.durationMs?.takeIf { it > 0 }
                ?: sourceInfo?.durationMs?.takeIf { it > 0 }
                ?: 0L,
            album = sourceInfo?.album ?: embedded?.album,
            genre = sourceInfo?.genre ?: embedded?.genre,
        )
        infoFile?.delete()

        Result(
            localUri = Uri.fromFile(mediaFile),
            metadata = metadata,
            originalUrl = url,
            providerLabel = provider,
            thumbnailUrl = sourceInfo?.thumbnail,
            originalTitle = rawTitle,
        )
    }

    fun cancel(processId: String?) {
        if (!processId.isNullOrBlank()) runCatching { YoutubeDL.getInstance().destroyProcessById(processId) }
    }

    private data class SourceInfo(
        val title: String?,
        val artist: String?,
        val durationMs: Long?,
        val album: String?,
        val genre: String?,
        val thumbnail: String?,
    )

    private fun readInfo(file: File): SourceInfo? = runCatching {
        val root = json.parseToJsonElement(file.readText()).jsonObject
        val durationMs = root["duration"]?.jsonPrimitive?.doubleOrNull?.let { (it * 1_000.0).toLong() }
        val categories = root["categories"]?.toString()
            ?.removePrefix("[")?.removeSuffix("]")?.replace("\"", "")
            ?.split(',')?.firstOrNull()?.trim()?.takeIf { it.isNotBlank() }
        SourceInfo(
            title = root["title"]?.jsonPrimitive?.contentOrNull,
            artist = root["artist"]?.jsonPrimitive?.contentOrNull
                ?: root["uploader"]?.jsonPrimitive?.contentOrNull
                ?: root["channel"]?.jsonPrimitive?.contentOrNull,
            durationMs = durationMs,
            album = root["album"]?.jsonPrimitive?.contentOrNull,
            genre = root["genre"]?.jsonPrimitive?.contentOrNull ?: categories,
            thumbnail = root["thumbnail"]?.jsonPrimitive?.contentOrNull,
        )
    }.getOrNull()

    private fun normalizeUrl(value: String): String = value.trim()

    private fun providerLabel(url: String): String = runCatching {
        val host = URI.create(url).host.orEmpty().lowercase()
        when {
            "youtu.be" in host || "youtube.com" in host || "music.youtube.com" in host -> "YouTube"
            "tiktok.com" in host -> "TikTok"
            "instagram.com" in host -> "Instagram"
            "soundcloud.com" in host -> "SoundCloud"
            else -> host.removePrefix("www.").ifBlank { "Link" }
        }
    }.getOrDefault("Link")

    private fun cleanupStaleFiles() {
        val cutoff = System.currentTimeMillis() - 24L * 60L * 60L * 1_000L
        cacheRoot.listFiles().orEmpty().filter { it.lastModified() < cutoff }.forEach { it.delete() }
    }

    companion object {
        const val CACHE_FOLDER = "sonus_edit_link_audio"
        @Volatile private var initialized = false
        private val initLock = Any()

        /** Delete only files created inside the dedicated link-import cache. */
        fun deleteImportedAudio(context: Context, uriString: String) {
            val uri = runCatching { Uri.parse(uriString) }.getOrNull() ?: return
            if (uri.scheme != "file") return
            val file = uri.path?.let(::File) ?: return
            val root = File(context.cacheDir, CACHE_FOLDER)
            val insideCache = runCatching { file.canonicalPath.startsWith(root.canonicalPath + File.separator) }.getOrDefault(false)
            if (insideCache) runCatching { file.delete() }
        }
    }
}

private val kotlinx.serialization.json.JsonPrimitive.contentOrNull: String?
    get() = runCatching { content }.getOrNull()
