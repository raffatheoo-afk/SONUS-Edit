package com.sonusstudios.sonusedit.create

import kotlin.math.ceil
import kotlin.math.abs

/**
 * Lightweight deterministic planner for automatic projects.
 * 15 seconds intentionally never appears here: it remains a manual-only preset.
 */
object AutomationPlanner {
    private val automaticDurations = listOf(30, 40, 50, 60, 65, 90, 120)

    fun duration(metadata: AudioMetadata, syncedLyrics: String?): DurationPreset? {
        val available = automaticDurations.filter { it * 1_000L <= metadata.durationMs }
        if (available.isEmpty()) return null
        val text = listOfNotNull(metadata.title, metadata.artist, metadata.genre, syncedLyrics?.take(700))
            .joinToString(" ").lowercase()

        val target = when {
            text.containsAny("instrumental", "ambient", "relax", "chuva", "sleep", "medita") -> 90
            text.containsAny("católic", "catholic", "maria", "jesus", "worship", "gospel", "eucar") -> 60
            text.containsAny("românt", "romantic", "amor", "sofr", "arrocha", "sertanejo") -> 60
            text.containsAny("trap", "funk", "rap", "drill", "hip hop", "eletr") -> 40
            else -> 30
        }
        val chosen = available.minByOrNull { abs(it - target) } ?: available.first()
        return DurationPreset.all.firstOrNull { it.seconds == chosen }
    }

    fun imageCount(durationSeconds: Int, mode: ImageQuantityMode): Int {
        val divisor = when (mode) {
            ImageQuantityMode.FEW -> 15.0
            ImageQuantityMode.BALANCED -> 10.0
            ImageQuantityMode.DYNAMIC -> 7.0
        }
        val desired = ceil(durationSeconds / divisor).toInt().coerceAtLeast(1)
        return desired.coerceAtMost(MediaDistributionPlanner.maxImages(durationSeconds))
    }

    fun filter(
        metadata: AudioMetadata,
        syncedLyrics: String?,
        favorites: Set<FilterPresetId> = emptySet(),
        nonce: Int = 0,
    ): FilterPresetId {
        val preferred = contextualFilter(metadata, syncedLyrics)
        if (favorites.isEmpty()) return preferred
        if (preferred in favorites && nonce == 0) return preferred
        val pool = favorites.sortedBy { it.ordinal }
        return pool[stableIndex(metadata, nonce, pool.size)]
    }

    fun alternativeFilter(
        current: FilterPresetId,
        metadata: AudioMetadata,
        syncedLyrics: String?,
        nonce: Int,
        favorites: Set<FilterPresetId> = emptySet(),
    ): FilterPresetId {
        if (favorites.isNotEmpty()) {
            val pool = favorites.sortedBy { it.ordinal }.let { all ->
                if (all.size > 1) all.filterNot { it == current } else all
            }
            return pool[stableIndex(metadata, nonce, pool.size)]
        }

        val preferred = contextualFilter(metadata, syncedLyrics)
        val pool = listOf(
            preferred,
            FilterPresetId.CINEMA_CLEAN,
            FilterPresetId.NATURAL_PLUS,
            FilterPresetId.SOFT_LIGHT,
            FilterPresetId.CINEMATIC,
            FilterPresetId.GOLDEN,
            FilterPresetId.CLARITY_PLUS,
        ).distinct().filterNot { it == current }
        return pool.getOrNull(abs(nonce) % pool.size.coerceAtLeast(1)) ?: preferred
    }

    fun font(
        metadata: AudioMetadata,
        favorites: Set<FontPresetId> = emptySet(),
        nonce: Int = 0,
    ): FontPresetId {
        val preferred = contextualFont(metadata)
        if (favorites.isEmpty()) return preferred
        if (preferred in favorites && nonce == 0) return preferred
        val pool = favorites.sortedBy { it.ordinal }
        return pool[stableIndex(metadata, nonce, pool.size)]
    }

    private fun contextualFilter(metadata: AudioMetadata, syncedLyrics: String?): FilterPresetId {
        val text = listOfNotNull(metadata.title, metadata.artist, metadata.genre, syncedLyrics?.take(600))
            .joinToString(" ").lowercase()
        return when {
            text.containsAny("católic", "catholic", "maria", "jesus", "worship", "gospel") -> FilterPresetId.GOLDEN
            text.containsAny("trap", "funk", "rap", "drill", "hip hop", "urban") -> FilterPresetId.NIGHT_CITY
            text.containsAny("românt", "romantic", "amor", "sofr", "arrocha", "sertanejo") -> FilterPresetId.SOFT_LIGHT
            text.containsAny("ambient", "instrumental", "relax", "sleep", "chuva") -> FilterPresetId.COOL_NATURAL
            else -> FilterPresetId.CINEMA_CLEAN
        }
    }

    private fun contextualFont(metadata: AudioMetadata): FontPresetId {
        val text = listOfNotNull(metadata.title, metadata.artist, metadata.genre).joinToString(" ").lowercase()
        return when {
            text.containsAny("românt", "amor", "sofr", "acúst", "acoustic") -> FontPresetId.ELEGANT
            text.containsAny("trap", "funk", "rap", "drill") -> FontPresetId.IMPACT
            text.containsAny("católic", "maria", "jesus", "worship", "gospel") -> FontPresetId.HANDWRITTEN
            else -> FontPresetId.MODERN
        }
    }

    private fun stableIndex(metadata: AudioMetadata, nonce: Int, size: Int): Int {
        if (size <= 1) return 0
        val seed = listOfNotNull(metadata.title, metadata.artist, metadata.genre).joinToString("|").hashCode()
        return Math.floorMod(seed + nonce, size)
    }
}

private fun String.containsAny(vararg needles: String): Boolean = needles.any { contains(it) }
