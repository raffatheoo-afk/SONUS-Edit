package com.sonusstudios.sonusedit.create

/** Idempotency key for one logical caption request. Metadata/title changes do not create a new job. */
object CaptionRequestGuard14 {
    fun key(audioUri: String, startMs: Long, durationMs: Long): String =
        "$audioUri|${startMs.coerceAtLeast(0L)}|${durationMs.coerceAtLeast(0L)}"

    fun canStart(
        requestKey: String,
        activeRequestKey: String?,
        jobActive: Boolean,
        completed: Boolean,
    ): Boolean = requestKey.isNotBlank() && !jobActive && !completed && activeRequestKey != requestKey
}
