package com.sonusstudios.sonusedit.lyrics

import android.content.Context
import com.sonusstudios.sonusedit.catalog.PCloudAsset
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/** Coordinates the lightweight pCloud index and on-demand lyric download for Stream tracks. */
class StreamLyricsResolver(
    context: Context,
    private val library: PCloudLyricsRepository = PCloudLyricsRepository(context.applicationContext),
    private val sonus: SonusLyricsResolver = FirebaseSonusLyricsResolver(),
    private val external: LrclibLyricsProvider = LrclibLyricsProvider(),
) {
    private val indexMutex = Mutex()
    @Volatile private var inMemoryIndex: List<PCloudAsset>? = null

    suspend fun cachedIndex(): List<PCloudAsset> {
        inMemoryIndex?.let { return it }
        val cached = library.cachedIndex()
        if (cached.isNotEmpty()) inMemoryIndex = cached
        return cached
    }

    suspend fun refreshIndex(): List<PCloudAsset> = indexMutex.withLock {
        val refreshed = library.refreshIndex()
        if (refreshed.isNotEmpty()) inMemoryIndex = refreshed
        refreshed
    }

    fun hasIndexedLyrics(index: List<PCloudAsset>, metadata: LyricsMetadata): Boolean =
        library.hasMatch(index, metadata.trackName, metadata.artistName)

    /**
     * Called only after a song was selected for a project. This is the first point at which the
     * pCloud LRC body may be downloaded.
     */
    suspend fun resolveSelected(trackId: String?, metadata: LyricsMetadata, allowFallback: Boolean = true): String? {
        var index = inMemoryIndex ?: library.cachedIndex().also { if (it.isNotEmpty()) inMemoryIndex = it }
        if (index.isEmpty()) {
            index = refreshIndex()
        }

        library.loadSelected(index, metadata.trackName, metadata.artistName)?.let { return it }
        if (!allowFallback) return null

        trackId?.takeIf { it.isNotBlank() }?.let { id ->
            runCatching { sonus.syncedLyrics(id) }.getOrNull()
                ?.takeIf(PCloudLyricsRepository::isValidLrc)
                ?.let { return it }
        }

        val externalMatch = runCatching {
            if (metadata.artistName.isNotBlank()) {
                external.bestMatch(metadata)
            } else {
                external.search(metadata.trackName, null).firstOrNull { it.hasSyncedLyrics }
            }
        }.getOrNull()
        return externalMatch?.syncedLyrics?.takeIf(PCloudLyricsRepository::isValidLrc)
    }

    suspend fun search(trackName: String, artistName: String?): List<LyricsMatch> =
        runCatching { external.search(trackName, artistName?.takeIf { it.isNotBlank() }) }
            .getOrDefault(emptyList())
            .filter { it.hasSyncedLyrics && PCloudLyricsRepository.isValidLrc(it.syncedLyrics) }
}
