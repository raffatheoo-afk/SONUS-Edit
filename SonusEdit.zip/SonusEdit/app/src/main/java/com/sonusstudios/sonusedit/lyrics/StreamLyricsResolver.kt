package com.sonusstudios.sonusedit.lyrics

import android.content.Context
import com.sonusstudios.sonusedit.catalog.PCloudAsset
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/** Coordinates the lightweight pCloud index and on-demand lyric download for Stream tracks. */
class StreamLyricsResolver(
    context: Context,
    private val library: PCloudLyricsRepository = PCloudLyricsRepository(context.applicationContext),
    private val sonus: SonusLyricsResolver = FirebaseSonusLyricsResolver(),
    private val external: LrclibLyricsProvider = LrclibLyricsProvider(),
) {
    suspend fun cachedIndexState(): LyricsIndexState {
        sharedIndexState?.let { return it }
        val cached = library.cachedIndexState()
        if (cached.ready) sharedIndexState = cached
        return cached
    }

    suspend fun refreshIndexState(force: Boolean = false): LyricsIndexState = sharedIndexMutex.withLock {
        val now = System.currentTimeMillis()
        val current = sharedIndexState
        if (!force && current?.ready == true && now - sharedIndexRefreshedAtMs < SESSION_INDEX_TTL_MS) {
            return@withLock current
        }

        val refreshed = library.refreshIndexState()
        if (refreshed.ready) {
            sharedIndexState = refreshed
            sharedIndexRefreshedAtMs = now
            return@withLock refreshed
        }
        current ?: refreshed
    }

    suspend fun cachedIndex(): List<PCloudAsset> = cachedIndexState().assets
    suspend fun refreshIndex(): List<PCloudAsset> = refreshIndexState().assets

    fun hasIndexedLyrics(index: List<PCloudAsset>, metadata: LyricsMetadata): Boolean =
        library.hasMatch(index, metadata.trackName, metadata.artistName)

    /**
     * Called only after a song was selected for a project. This is the first point at which the
     * pCloud LRC body may be downloaded.
     */
    suspend fun resolveSelected(trackId: String?, metadata: LyricsMetadata, allowFallback: Boolean = true): String? {
        var state = sharedIndexState ?: library.cachedIndexState().also {
            if (it.ready) sharedIndexState = it
        }
        if (!state.ready) state = refreshIndexState()

        library.loadSelected(state.assets, metadata.trackName, metadata.artistName)?.let { return it }
        if (!allowFallback) return null

        trackId?.takeIf { it.isNotBlank() }?.let { id ->
            runCatching { sonus.syncedLyrics(id) }.getOrNull()
                ?.takeIf(PCloudLyricsRepository::isValidLrc)
                ?.let { return it }
        }

        val externalMatch = runCatching {
            if (metadata.artistName.isNotBlank()) {
                external.bestMatch(metadata)
            } else {
                external.search(metadata.trackName, null).firstOrNull { it.hasSyncedLyrics }
            }
        }.getOrNull()
        return externalMatch?.syncedLyrics?.takeIf(PCloudLyricsRepository::isValidLrc)
    }

    suspend fun search(trackName: String, artistName: String?): List<LyricsMatch> =
        runCatching { external.search(trackName, artistName?.takeIf { it.isNotBlank() }) }
            .getOrDefault(emptyList())
            .filter { it.hasSyncedLyrics && PCloudLyricsRepository.isValidLrc(it.syncedLyrics) }

    companion object {
        private const val SESSION_INDEX_TTL_MS = 5 * 60 * 1000L
        private val sharedIndexMutex = Mutex()
        @Volatile private var sharedIndexState: LyricsIndexState? = null
        @Volatile private var sharedIndexRefreshedAtMs: Long = 0L
    }
}
