package com.sonusstudios.sonusedit.media

import android.content.Context
import android.opengl.GLES20
import androidx.media3.common.VideoFrameProcessingException
import androidx.media3.common.util.GlProgram
import androidx.media3.common.util.GlUtil
import androidx.media3.common.util.Size
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BaseGlShaderProgram
import androidx.media3.effect.GlEffect
import androidx.media3.effect.GlShaderProgram
import com.sonusstudios.sonusedit.R

/** GPU-native enhancement filters. No veil/overlay is drawn over the image. */
@OptIn(UnstableApi::class)
class NaturalFilterEffect(private val preset: Preset) : GlEffect {
    data class Preset(
        val sharpen: Float = 0f,
        val contrast: Float = 1f,
        val saturation: Float = 1f,
        val brightness: Float = 0f,
        val blackPoint: Float = 0f,
        val temperature: Float = 0f,
    )

    override fun toGlShaderProgram(context: Context, useHdr: Boolean): GlShaderProgram =
        NaturalFilterShaderProgram(context, useHdr, preset)
}

@OptIn(UnstableApi::class)
private class NaturalFilterShaderProgram(
    context: Context,
    useHdr: Boolean,
    private val preset: NaturalFilterEffect.Preset,
) : BaseGlShaderProgram(useHdr, 1) {
    private val glProgram = try {
        GlProgram(context, R.raw.sonus_video_key_vertex, R.raw.sonus_natural_filter_fragment).apply {
            setBufferAttribute(
                "aFramePosition",
                GlUtil.getNormalizedCoordinateBounds(),
                GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE,
            )
            val identity = GlUtil.create4x4IdentityMatrix()
            setFloatsUniform("uTransformationMatrix", identity)
            setFloatsUniform("uTexTransformationMatrix", identity)
            setFloatUniform("uSharpen", preset.sharpen.coerceIn(0f, 0.35f))
            setFloatUniform("uContrast", preset.contrast.coerceIn(0.75f, 1.35f))
            setFloatUniform("uSaturation", preset.saturation.coerceIn(0f, 1.4f))
            setFloatUniform("uBrightness", preset.brightness.coerceIn(-0.12f, 0.12f))
            setFloatUniform("uBlackPoint", preset.blackPoint.coerceIn(0f, 0.12f))
            setFloatUniform("uTemperature", preset.temperature.coerceIn(-0.12f, 0.12f))
        }
    } catch (e: Exception) {
        throw VideoFrameProcessingException(e)
    }

    override fun configure(inputWidth: Int, inputHeight: Int): Size {
        try {
            glProgram.setFloatsUniform(
                "uTexelSize",
                floatArrayOf(1f / inputWidth.coerceAtLeast(1), 1f / inputHeight.coerceAtLeast(1)),
            )
        } catch (e: Exception) {
            throw VideoFrameProcessingException(e)
        }
        return Size(inputWidth, inputHeight)
    }

    override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
        try {
            glProgram.use()
            glProgram.setSamplerTexIdUniform("uTexSampler", inputTexId, 0)
            glProgram.bindAttributesAndUniforms()
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e, presentationTimeUs)
        }
    }

    override fun release() {
        super.release()
        try {
            glProgram.delete()
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e)
        }
    }
}
