package com.sonusstudios.sonusedit.create

/** Palette shared by preview and export. Dynamic mode never chooses black to preserve contrast. */
object LyricColorPalette24 {
    private val dynamicColors = intArrayOf(
        0xFF00E8FF.toInt(), 0xFF70FF70.toInt(), 0xFFFF4FA3.toInt(), 0xFFFFE040.toInt(),
        0xFFB85CFF.toInt(), 0xFFFF5252.toInt(), 0xFF468CFF.toInt(), 0xFFFFFFFF.toInt(),
        0xFFFF982D.toInt(), 0xFF25B9A6.toInt(), 0xFFFF7F50.toInt(), 0xFFC0C0C0.toInt(),
    )

    fun argb(preset: LyricColorPreset, index: Int): Int = when (preset) {
        LyricColorPreset.DYNAMIC -> dynamicColors[Math.floorMod(index, dynamicColors.size)]
        LyricColorPreset.WHITE -> 0xFFFFFFFF.toInt()
        LyricColorPreset.BLACK -> 0xFF000000.toInt()
        LyricColorPreset.YELLOW -> 0xFFFFE040.toInt()
        LyricColorPreset.ORANGE -> 0xFFFF982D.toInt()
        LyricColorPreset.RED -> 0xFFFF5252.toInt()
        LyricColorPreset.PINK -> 0xFFFF4FA3.toInt()
        LyricColorPreset.PURPLE -> 0xFFB85CFF.toInt()
        LyricColorPreset.BLUE -> 0xFF468CFF.toInt()
        LyricColorPreset.CYAN -> 0xFF00E8FF.toInt()
        LyricColorPreset.GREEN -> 0xFF70FF70.toInt()
        LyricColorPreset.GRAY -> 0xFF808080.toInt()
        LyricColorPreset.SILVER -> 0xFFC0C0C0.toInt()
        LyricColorPreset.DARK_GRAY -> 0xFF40434A.toInt()
        LyricColorPreset.BROWN -> 0xFF9A6236.toInt()
        LyricColorPreset.MAGENTA -> 0xFFFF00B8.toInt()
        LyricColorPreset.TURQUOISE -> 0xFF40E0D0.toInt()
        LyricColorPreset.NAVY -> 0xFF183A72.toInt()
        LyricColorPreset.LIME -> 0xFFB6E62E.toInt()
        LyricColorPreset.CORAL -> 0xFFFF7F70.toInt()
        LyricColorPreset.GOLD -> 0xFFFFC928.toInt()
        LyricColorPreset.MINT -> 0xFF9BE7C4.toInt()
        LyricColorPreset.LAVENDER -> 0xFFC7A5FF.toInt()
        LyricColorPreset.TEAL -> 0xFF087E79.toInt()
        LyricColorPreset.WINE -> 0xFF7D1F43.toInt()
    }

    fun dynamicColorCount(): Int = dynamicColors.size
}
