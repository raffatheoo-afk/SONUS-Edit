package com.sonusstudios.sonusedit.create

/**
 * Palette shared by the editor preview and final video renderer.
 * Dynamic mode cycles through all nine legacy selectable colors, while black is a new
 * opt-in solid color and deliberately not included in the dynamic sequence.
 */
object LyricColorPalette24 {
    private val dynamicColors = intArrayOf(
        0xFF00E8FF.toInt(), // Cyan
        0xFF70FF70.toInt(), // Green
        0xFFFF4FA3.toInt(), // Pink
        0xFFFFE040.toInt(), // Yellow
        0xFFB85CFF.toInt(), // Purple
        0xFFFF5252.toInt(), // Red
        0xFF468CFF.toInt(), // Blue
        0xFFFFFFFF.toInt(), // White
        0xFFFF982D.toInt(), // Orange
    )

    fun argb(preset: LyricColorPreset, index: Int): Int = when (preset) {
        LyricColorPreset.DYNAMIC -> dynamicColors[Math.floorMod(index, dynamicColors.size)]
        LyricColorPreset.WHITE -> 0xFFFFFFFF.toInt()
        LyricColorPreset.BLACK -> 0xFF000000.toInt()
        LyricColorPreset.YELLOW -> 0xFFFFE040.toInt()
        LyricColorPreset.ORANGE -> 0xFFFF982D.toInt()
        LyricColorPreset.RED -> 0xFFFF5252.toInt()
        LyricColorPreset.PINK -> 0xFFFF4FA3.toInt()
        LyricColorPreset.PURPLE -> 0xFFB85CFF.toInt()
        LyricColorPreset.BLUE -> 0xFF468CFF.toInt()
        LyricColorPreset.CYAN -> 0xFF00E8FF.toInt()
        LyricColorPreset.GREEN -> 0xFF70FF70.toInt()
    }

    fun dynamicColorCount(): Int = dynamicColors.size
}
