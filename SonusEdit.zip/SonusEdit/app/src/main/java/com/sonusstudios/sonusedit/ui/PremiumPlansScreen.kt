package com.sonusstudios.sonusedit.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonusstudios.sonusedit.designsystem.SonusEditColors

private data class DisplayPlan(
    val name: String,
    val price: String,
    val limit: String,
    val note: String,
    val recommended: Boolean = false,
    val available: Boolean = false,
)

private val displayPlans = listOf(
    DisplayPlan("Edit Free", "Grátis", "10 vídeos por mês", "Edição automática e efeitos internos", available = true),
    DisplayPlan("Edit Creator", "R$ 4,90", "30 vídeos por mês", "Mais volume de produção • benefícios Premium planejados"),
    DisplayPlan("Edit Pro", "R$ 9,90", "75 vídeos por mês", "Para quem publica com frequência • pacote completo planejado", recommended = true),
    DisplayPlan("Edit Studio", "R$ 19,90", "Vídeos ilimitados*", "Para produção de alto volume • benefícios Studio planejados"),
)

/** Informational plans only: no billing, quota enforcement, or feature gates are enabled. */
@Composable
fun PremiumPlansScreen(onBack: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(SonusEditColors.Black)
            .verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(13.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar", tint = Color.White)
            }
            PremiumCrownIcon()
            Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                Text("SONUS EDIT PREMIUM", fontWeight = FontWeight.ExtraBold, color = Color.White, fontSize = 19.sp)
                Text("Planos para cada ritmo de criação", color = SonusEditColors.TextMuted, fontSize = 10.sp)
            }
        }

        Box(
            Modifier.fillMaxWidth().background(
                Color(0xFF17182B), RoundedCornerShape(20.dp),
            ).padding(horizontal = 17.dp, vertical = 16.dp),
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Default.Star, null, tint = Color(0xFFFFD45C), modifier = Modifier.size(17.dp))
                    Text("MAIS LIBERDADE PARA CRIAR", color = Color(0xFFFFD45C), fontWeight = FontWeight.Bold, fontSize = 10.sp)
                }
                Text("Seu editor. Seu ritmo.", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                Text(
                    "Escolha a quantidade de vídeos que combina com sua produção. Os recursos Premium estão em desenvolvimento.",
                    color = Color(0xFFB6BDCE), fontSize = 11.sp,
                )
            }
        }

        displayPlans.forEach { plan ->
            val border = if (plan.recommended) BorderStroke(1.5.dp, Color(0xFF9564FF)) else null
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                border = border,
                colors = CardDefaults.cardColors(
                    containerColor = if (plan.recommended) Color(0xFF1C1B35) else SonusEditColors.Surface,
                ),
            ) {
                Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(plan.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.weight(1f))
                        if (plan.recommended) {
                            Row(
                                Modifier.background(Color(0xFF7650D8), RoundedCornerShape(20.dp)).padding(horizontal = 9.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Icon(Icons.Default.EmojiEvents, null, tint = Color.White, modifier = Modifier.size(12.dp))
                                Spacer(Modifier.size(4.dp))
                                Text("RECOMENDADO", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 8.sp)
                            }
                        } else {
                            Text(if (plan.price == "Grátis") plan.price else "${plan.price}/mês", color = Color(0xFF7ED9FF), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                    if (plan.recommended) {
                        Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(plan.price, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 23.sp)
                            Text("/mês", color = SonusEditColors.TextMuted, fontSize = 10.sp)
                        }
                    }
                    Text(plan.limit, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(Icons.Default.CheckCircle, null, tint = if (plan.available) Color(0xFF58D5B0) else Color(0xFF9C83E8), modifier = Modifier.size(15.dp))
                        Text(plan.note, color = SonusEditColors.TextMuted, fontSize = 10.sp)
                    }
                    Text(
                        if (plan.available) "DISPONÍVEL" else "BENEFÍCIOS EM BREVE",
                        color = if (plan.available) Color(0xFF58D5B0) else Color(0xFFFFD45C),
                        fontWeight = FontWeight.Bold,
                        fontSize = 9.sp,
                    )
                }
            }
        }

        Text(
            "Benefícios planejados para os planos pagos: efeitos especiais da nuvem, presets profissionais e recursos adicionais de produtividade.",
            color = SonusEditColors.TextMuted, fontSize = 10.sp,
        )
        Text(
            "*O plano Studio deverá ter uma política de uso justo. Durante o desenvolvimento, todos os recursos permanecem liberados para todos. Nenhuma cobrança ou limitação está ativa.",
            color = SonusEditColors.TextMuted, fontSize = 10.sp,
        )
        Spacer(Modifier.height(6.dp))
    }
}
