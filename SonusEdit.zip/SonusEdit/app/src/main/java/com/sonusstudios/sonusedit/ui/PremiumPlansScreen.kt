package com.sonusstudios.sonusedit.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonusstudios.sonusedit.designsystem.SonusEditColors

private data class DisplayPlan(
    val name: String,
    val price: String,
    val quota: String,
    val benefits: List<String>,
    val recommended: Boolean = false,
)

private val displayPlans = listOf(
    DisplayPlan(
        "Edit Free", "Grátis", "20 vídeos por mês",
        listOf("Efeitos internos", "Exportação até 720p", "Catálogo padrão"),
    ),
    DisplayPlan(
        "Edit Creator", "R$ 2,90/mês", "50 vídeos por mês",
        listOf("Efeitos internos", "Exportação até 1080p", "Catálogo padrão"),
    ),
    DisplayPlan(
        "Edit Pro", "R$ 5,90/mês", "100 vídeos por mês",
        listOf("Efeitos internos e efeitos da nuvem", "Exportação até 2K", "Catálogo padrão"),
        recommended = true,
    ),
    DisplayPlan(
        "Edit Studio", "R$ 9,90/mês", "Vídeos ilimitados*",
        listOf("Todos os efeitos internos e da nuvem", "Exportação até 4K", "Catálogo completo + servidor exclusivo"),
    ),
)

/** Plans are informational only. All current app features remain open until explicit activation. */
@Composable
fun PremiumPlansScreen(onBack: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(SonusEditColors.Black)
            .verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar", tint = Color.White)
            }
            PremiumCrownIcon()
            Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                Text("SONUS EDIT PREMIUM", fontWeight = FontWeight.ExtraBold, color = Color.White, fontSize = 19.sp)
                Text("Planos planejados para cada criador", color = SonusEditColors.TextMuted, fontSize = 10.sp)
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = Color.Transparent), shape = RoundedCornerShape(22.dp)) {
            Column(
                Modifier.fillMaxWidth().background(
                    Brush.linearGradient(listOf(Color(0xFF302064), Color(0xFF17445C), Color(0xFF14283B)))
                ).padding(17.dp),
                verticalArrangement = Arrangement.spacedBy(7.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Star, null, tint = Color(0xFFFFD45C))
                    Text("  PLANOS EM PREPARAÇÃO", color = Color(0xFFFFD45C), fontWeight = FontWeight.Bold, fontSize = 10.sp)
                }
                Text("Mais recursos para sua produção.", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold)
                Text(
                    "Os valores e benefícios abaixo são a proposta planejada. Ainda não há cobrança, limite mensal nem bloqueio de recursos ativo.",
                    color = Color(0xFFD7E6F3), fontSize = 10.sp, lineHeight = 15.sp,
                )
            }
        }

        displayPlans.forEach { plan ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(19.dp),
                border = if (plan.recommended) BorderStroke(1.5.dp, Color(0xFF9564FF)) else BorderStroke(1.dp, Color(0xFF303B50)),
                colors = CardDefaults.cardColors(containerColor = if (plan.recommended) Color(0xFF1C1B35) else SonusEditColors.Surface),
            ) {
                Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(plan.name, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, modifier = Modifier.weight(1f))
                        if (plan.recommended) {
                            Row(
                                Modifier.background(Color(0xFF7650D8), RoundedCornerShape(20.dp)).padding(horizontal = 9.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Icon(Icons.Default.EmojiEvents, null, tint = Color.White, modifier = Modifier.height(13.dp))
                                Text("  RECOMENDADO", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 8.sp)
                            }
                        }
                    }
                    Text(plan.price, color = Color(0xFF7ED9FF), fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                    Text(plan.quota, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    plan.benefits.forEach { benefit ->
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            Icon(Icons.Default.CheckCircle, null, tint = Color(0xFF67D6B3), modifier = Modifier.height(14.dp))
                            Text(benefit, color = SonusEditColors.TextMuted, fontSize = 10.sp)
                        }
                    }
                    Text("PLANEJADO • AINDA NÃO ATIVADO", color = Color(0xFFFFD45C), fontWeight = FontWeight.Bold, fontSize = 8.sp)
                }
            }
        }
        Text(
            "*O plano Studio deverá respeitar uma política de uso justo para serviços que gerem custo em nuvem. A edição e a exportação locais não serão limitadas artificialmente. O servidor exclusivo e as regras de ativação ainda dependem de preparação.",
            color = SonusEditColors.TextMuted, fontSize = 9.sp, lineHeight = 14.sp,
        )
        Text(
            "Enquanto os planos não forem ativados, todos continuam com acesso aos recursos atuais do aplicativo.",
            color = Color(0xFF83DCC4), fontSize = 10.sp, fontWeight = FontWeight.Bold,
        )
        Spacer(Modifier.height(8.dp))
    }
}
