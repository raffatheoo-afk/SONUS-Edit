package com.sonusstudios.sonusedit.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonusstudios.sonusedit.designsystem.SonusEditColors

private data class DisplayPlan(val name: String, val price: String, val limit: String, val cloudFuture: Boolean)
private val displayPlans = listOf(
    DisplayPlan("Edit Free", "Grátis", "10 vídeos/mês", false),
    DisplayPlan("Edit Creator", "R$ 4,90/mês", "30 vídeos/mês", true),
    DisplayPlan("Edit Pro", "R$ 9,90/mês", "75 vídeos/mês", true),
    DisplayPlan("Edit Studio", "R$ 19,90/mês", "Vídeos ilimitados", true),
)

/** Display only. No purchases, quotas, subscriptions, or authorization gates in 1.1. */
@Composable
fun PremiumPlansScreen(onBack: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(SonusEditColors.Black)
            .verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(11.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar", tint = Color.White) }
            PremiumCrownIcon()
            Spacer(Modifier.size(10.dp))
            Text("SONUS Edit Premium", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 22.sp)
        }
        Text("Conheça os planos", color = SonusEditColors.TextMuted, fontSize = 13.sp)
        displayPlans.forEach { plan ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SonusEditColors.Surface),
            ) {
                Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(plan.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text(plan.price, color = Color(0xFF7ED9FF), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    Text(plan.limit, color = Color.White, fontSize = 13.sp)
                    Text(if (plan.cloudFuture) "Efeitos da nuvem • benefício Premium futuro" else "Efeitos internos incluídos", color = SonusEditColors.TextMuted, fontSize = 11.sp)
                    Text(if (plan.name == "Edit Free") "Disponível" else "EM BREVE", color = Color(0xFFFFD45C), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
        }
        Text("Durante o desenvolvimento, todos os recursos estão liberados para todos.", color = SonusEditColors.TextMuted, fontSize = 12.sp)
    }
}
