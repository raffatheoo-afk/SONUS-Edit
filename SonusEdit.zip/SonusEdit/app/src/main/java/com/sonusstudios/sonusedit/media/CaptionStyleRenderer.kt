package com.sonusstudios.sonusedit.media

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import com.sonusstudios.sonusedit.create.CaptionPosition
import com.sonusstudios.sonusedit.create.CaptionSegment
import com.sonusstudios.sonusedit.create.CaptionStyleId
import com.sonusstudios.sonusedit.create.CaptionWordTimer
import com.sonusstudios.sonusedit.create.LyricColorPalette24
import com.sonusstudios.sonusedit.create.LyricColorPreset
import com.sonusstudios.sonusedit.create.TimedWord
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * One drawing code for captions, used by the video export overlay AND by every on-screen preview, so
 * what the user sees is what gets exported. Pure Android Canvas; it receives the pixel size explicitly.
 * Any failure while drawing is swallowed on purpose: a styling problem must never break an export.
 */
class CaptionStyleRenderer {
    data class Caption(val startMs: Long, val endMs: Long, val text: String)

    class Config(
        val style: CaptionStyleId,
        val position: CaptionPosition,
        val typeface: Typeface,
        val colorPreset: LyricColorPreset,
        /** 1f in exports; the small in-app previews enlarge the text so it stays readable. */
        val textScale: Float = 1f,
    )

    private class Layout(
        val size: Float,
        val spacing: Float,
        val lines: List<IntArray>,
        val wordWidths: FloatArray,
        val spaceWidth: Float,
        val lineWidths: FloatArray,
    )

    private class Block(val top: Float, val lineHeight: Float, val total: Float, val fm: Paint.FontMetrics)

    private class Ctx(
        val canvas: Canvas,
        val w: Float,
        val h: Float,
        val base: Float,
        val maxWidth: Float,
        val centerY: Float,
        val safeTop: Float,
        val safeBottom: Float,
        val legacy: Int,
        val baseColor: Int,
        val hi: Int,
        val outline: Int,
        val config: Config,
        val index: Int,
        val caption: Caption,
        val t: Long,
    )

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val wordCache = HashMap<String, List<TimedWord>>()
    private val layoutCache = HashMap<String, Layout>()
    private var cachedCaptions: List<Caption>? = null

    fun draw(canvas: Canvas, width: Int, height: Int, timeMs: Long, captions: List<Caption>, config: Config) {
        if (captions.isEmpty() || width <= 0 || height <= 0) return
        if (captions !== cachedCaptions) {
            wordCache.clear()
            layoutCache.clear()
            cachedCaptions = captions
        }
        val index = indexAt(captions, timeMs)
        if (index < 0) return
        try {
            drawCaption(canvas, width.toFloat(), height.toFloat(), timeMs, captions[index], index, config)
        } catch (_: Throwable) {
            // Never let caption styling break the preview or an export.
        }
    }

    // ---------------------------------------------------------------- dispatch

    private fun drawCaption(canvas: Canvas, w: Float, h: Float, t: Long, caption: Caption, index: Int, config: Config) {
        val base = min(w, h)
        val horizontal = w > h
        val anchor = anchorFor(h, horizontal, config.position)
        val legacy = LyricColorPalette24.argb(config.colorPreset, index)
        val (baseColor, hi) = colorsFor(config.colorPreset, legacy)
        val ctx = Ctx(
            canvas = canvas, w = w, h = h, base = base,
            maxWidth = w * (if (horizontal) 0.76f else 0.84f),
            centerY = anchor[0], safeTop = anchor[1], safeBottom = anchor[2],
            legacy = legacy, baseColor = baseColor, hi = hi,
            outline = if (config.colorPreset == LyricColorPreset.BLACK) Color.WHITE else Color.BLACK,
            config = config, index = index, caption = caption, t = t,
        )
        when (config.style) {
            CaptionStyleId.CLASSIC -> drawClassic(ctx)
            CaptionStyleId.WORD_BY_WORD -> drawWordByWord(ctx)
            CaptionStyleId.KARAOKE -> drawKaraoke(ctx)
            CaptionStyleId.POP_IN -> drawPopIn(ctx)
            CaptionStyleId.BUILD_UP -> drawBuildUp(ctx)
            CaptionStyleId.HIGHLIGHT_BOX -> drawHighlightBox(ctx)
            CaptionStyleId.NEON -> drawNeon(ctx)
            CaptionStyleId.RISE -> drawRise(ctx)
            CaptionStyleId.NEWS_BAR -> drawNewsBar(ctx)
            CaptionStyleId.CINEMA -> drawCinema(ctx)
        }
    }

    // ---------------------------------------------------------------- the ten looks

    private fun drawClassic(ctx: Ctx) {
        val words = wordsFor(ctx, false)
        if (words.isEmpty()) return
        val layout = layoutCached(ctx, "p", words.map { it.text }, 0.03881f, 0.01254f, 2, 0f)
        val block = blockFor(ctx, layout)
        val alpha = envelope(ctx, 140f, 140f)
        eachWord(ctx, layout, block, 0f, 0f) { wi, x, y ->
            drawWord(ctx, words[wi].text, x, y, layout.size, 0f, ctx.legacy, alpha)
        }
    }

    private fun drawWordByWord(ctx: Ctx) {
        val words = wordsFor(ctx, true)
        if (words.isEmpty()) return
        val k = activeIndex(words, ctx.t).coerceAtLeast(0)
        val word = words[k]
        val layout = layoutCached(ctx, "w$k", listOf(word.text), 0.085f, 0.03f, 1, 0f)
        val block = blockFor(ctx, layout)
        val elapsed = (ctx.t - word.startMs).coerceAtLeast(0L)
        val p = (elapsed / 140f).coerceIn(0f, 1f)
        val scale = 0.82f + 0.18f * p + sin(p * Math.PI.toFloat()) * 0.10f
        val alpha = min((elapsed / 90f).coerceIn(0f, 1f), ((ctx.caption.endMs - ctx.t) / 100f).coerceIn(0f, 1f))
        val pivotY = block.top + block.total / 2f
        ctx.canvas.save()
        ctx.canvas.scale(scale, scale, ctx.w / 2f, pivotY)
        eachWord(ctx, layout, block, 0f, 0f) { _, x, y ->
            drawWord(ctx, word.text, x, y, layout.size, 0f, ctx.legacy, alpha)
        }
        ctx.canvas.restore()
    }

    private fun drawKaraoke(ctx: Ctx) {
        val words = wordsFor(ctx, false)
        if (words.isEmpty()) return
        val layout = layoutCached(ctx, "p", words.map { it.text }, 0.050f, 0.02f, 3, 0f)
        val block = blockFor(ctx, layout)
        val k = activeIndex(words, ctx.t)
        val alpha = envelope(ctx, 120f, 120f)
        eachWord(ctx, layout, block, 0f, 0f) { wi, x, y ->
            drawWord(ctx, words[wi].text, x, y, layout.size, 0f, if (wi <= k) ctx.hi else ctx.baseColor, alpha)
        }
    }

    private fun drawPopIn(ctx: Ctx) {
        val words = wordsFor(ctx, true)
        if (words.isEmpty()) return
        val k = activeIndex(words, ctx.t).coerceAtLeast(0)
        val group = groupsFor(words).firstOrNull { k in it } ?: return
        val texts = group.map { words[it].text }
        val layout = layoutCached(ctx, "g${group.first}", texts, 0.070f, 0.03f, 2, 0f)
        val block = blockFor(ctx, layout)
        val groupStart = words[group.first].startMs
        val elapsed = (ctx.t - groupStart).coerceAtLeast(0L)
        val p = (elapsed / 170f).coerceIn(0f, 1f)
        val scale = 0.72f + 0.28f * p + sin(p * Math.PI.toFloat()) * 0.16f
        val alpha = min((elapsed / 80f).coerceIn(0f, 1f), ((ctx.caption.endMs - ctx.t) / 120f).coerceIn(0f, 1f))
        ctx.canvas.save()
        ctx.canvas.scale(scale, scale, ctx.w / 2f, block.top + block.total / 2f)
        eachWord(ctx, layout, block, 0f, 0f) { wi, x, y ->
            val global = group.first + wi
            drawWord(ctx, words[global].text, x, y, layout.size, 0f, if (global == k) ctx.hi else ctx.baseColor, alpha)
        }
        ctx.canvas.restore()
    }

    private fun drawBuildUp(ctx: Ctx) {
        val words = wordsFor(ctx, false)
        if (words.isEmpty()) return
        val layout = layoutCached(ctx, "p", words.map { it.text }, 0.050f, 0.02f, 3, 0f)
        val block = blockFor(ctx, layout)
        val k = activeIndex(words, ctx.t)
        val out = ((ctx.caption.endMs - ctx.t) / 160f).coerceIn(0f, 1f)
        eachWord(ctx, layout, block, 0f, 0f) { wi, x, y ->
            if (wi <= k) {
                val p = ((ctx.t - words[wi].startMs) / 150f).coerceIn(0f, 1f)
                drawWord(ctx, words[wi].text, x, y + (1f - easeOut(p)) * layout.size * 0.25f, layout.size, 0f, ctx.legacy, p * out)
            }
        }
    }

    private fun drawHighlightBox(ctx: Ctx) {
        val words = wordsFor(ctx, false)
        if (words.isEmpty()) return
        val layout = layoutCached(ctx, "p", words.map { it.text }, 0.052f, 0.02f, 3, 0f)
        val block = blockFor(ctx, layout)
        val k = activeIndex(words, ctx.t)
        val alpha = envelope(ctx, 100f, 120f)
        val padX = layout.size * 0.14f
        eachWord(ctx, layout, block, 0f, 0f) { wi, x, y ->
            if (wi == k) {
                paint.reset()
                paint.isAntiAlias = true
                paint.style = Paint.Style.FILL
                paint.color = withAlpha(ctx.hi, alpha * 0.96f)
                rect.set(x - padX, y + block.fm.ascent * 0.88f, x + layout.wordWidths[wi] + padX, y + block.fm.descent * 0.95f)
                ctx.canvas.drawRoundRect(rect, layout.size * 0.22f, layout.size * 0.22f, paint)
                drawWord(ctx, words[wi].text, x, y, layout.size, 0f, 0xFF111111.toInt(), alpha, strokeScale = 0f)
            } else {
                drawWord(ctx, words[wi].text, x, y, layout.size, 0f, ctx.baseColor, alpha)
            }
        }
    }

    private fun drawNeon(ctx: Ctx) {
        val words = wordsFor(ctx, false)
        if (words.isEmpty()) return
        val layout = layoutCached(ctx, "p", words.map { it.text }, 0.052f, 0.02f, 3, 0f)
        val block = blockFor(ctx, layout)
        val k = activeIndex(words, ctx.t)
        val alpha = envelope(ctx, 120f, 140f)
        eachWord(ctx, layout, block, 0f, 0f) { wi, x, y ->
            if (wi == k) drawWord(ctx, words[wi].text, x, y, layout.size, 0f, ctx.hi, alpha, glow = ctx.hi)
            else drawWord(ctx, words[wi].text, x, y, layout.size, 0f, ctx.baseColor, alpha * 0.55f)
        }
    }

    private fun drawRise(ctx: Ctx) {
        val words = wordsFor(ctx, false)
        if (words.isEmpty()) return
        val layout = layoutCached(ctx, "p", words.map { it.text }, 0.046f, 0.02f, 3, 0f)
        val block = blockFor(ctx, layout)
        val pIn = ((ctx.t - ctx.caption.startMs) / 280f).coerceIn(0f, 1f)
        val pOut = ((ctx.t - (ctx.caption.endMs - 220L)) / 220f).coerceIn(0f, 1f)
        val dy = (1f - easeOut(pIn)) * ctx.base * 0.035f - pOut * ctx.base * 0.02f
        val alpha = easeOut(pIn) * (1f - pOut)
        eachWord(ctx, layout, block, 0f, dy) { wi, x, y ->
            drawWord(ctx, words[wi].text, x, y, layout.size, 0f, ctx.legacy, alpha)
        }
    }

    private fun drawNewsBar(ctx: Ctx) {
        val words = wordsFor(ctx, false)
        if (words.isEmpty()) return
        val layout = layoutCached(ctx, "p", words.map { it.text }, 0.040f, 0.018f, 2, 0f)
        val block = blockFor(ctx, layout)
        val alpha = envelope(ctx, 150f, 150f)
        val padX = layout.size * 0.55f
        val padY = layout.size * 0.35f
        val widest = layout.lineWidths.maxOrNull() ?: 0f
        paint.reset()
        paint.isAntiAlias = true
        paint.style = Paint.Style.FILL
        paint.color = withAlpha(if (ctx.config.colorPreset == LyricColorPreset.BLACK) Color.argb(205, 255, 255, 255) else Color.argb(165, 0, 0, 0), alpha)
        rect.set(ctx.w / 2f - widest / 2f - padX, block.top - padY, ctx.w / 2f + widest / 2f + padX, block.top + block.total + padY)
        ctx.canvas.drawRoundRect(rect, layout.size * 0.35f, layout.size * 0.35f, paint)
        eachWord(ctx, layout, block, 0f, 0f) { wi, x, y ->
            drawWord(ctx, words[wi].text, x, y, layout.size, 0f, ctx.legacy, alpha, strokeScale = 0f)
        }
    }

    private fun drawCinema(ctx: Ctx) {
        val words = wordsFor(ctx, false)
        if (words.isEmpty()) return
        val spacing = 0.06f
        val layout = layoutCached(ctx, "p", words.map { it.text }, 0.033f, 0.016f, 2, spacing)
        val block = blockFor(ctx, layout)
        val alpha = envelope(ctx, 380f, 380f) * 0.94f
        eachWord(ctx, layout, block, 0f, 0f) { wi, x, y ->
            drawWord(ctx, words[wi].text, x, y, layout.size, spacing, ctx.legacy, alpha, strokeScale = 0.6f)
        }
    }

    // ---------------------------------------------------------------- layout helpers

    private fun wordsFor(ctx: Ctx, upper: Boolean): List<TimedWord> {
        val key = "${ctx.index}|$upper"
        wordCache[key]?.let { return it }
        val text = if (upper) ctx.caption.text.uppercase() else ctx.caption.text
        val words = CaptionWordTimer.split(text, ctx.caption.startMs, ctx.caption.endMs)
        wordCache[key] = words
        return words
    }

    private fun activeIndex(words: List<TimedWord>, t: Long): Int = words.indexOfLast { it.startMs <= t }

    /** Up to three consecutive words per pop-in card; punctuation closes a card early. */
    private fun groupsFor(words: List<TimedWord>): List<IntRange> {
        val groups = ArrayList<IntRange>()
        var start = 0
        var chars = 0
        for (i in words.indices) {
            val size = words[i].text.length
            val count = i - start
            if (count > 0 && (count >= 3 || chars + size + 1 > 22)) {
                groups += start until i
                start = i
                chars = 0
            }
            chars += size + 1
            val last = words[i].text.last()
            if (last == '.' || last == '!' || last == '?' || last == ',') {
                groups += start..i
                start = i + 1
                chars = 0
            }
        }
        if (start < words.size) groups += start until words.size
        return groups
    }

    private fun layoutCached(ctx: Ctx, suffix: String, texts: List<String>, startF: Float, floorF: Float, maxLines: Int, spacing: Float): Layout {
        val scale = ctx.config.textScale
        val key = "${ctx.index}|$suffix|${ctx.w.toInt()}x${ctx.h.toInt()}|${ctx.config.style.ordinal}|${System.identityHashCode(ctx.config.typeface)}|$scale"
        layoutCache[key]?.let { return it }
        if (layoutCache.size > 96) layoutCache.clear()
        val layout = layoutWords(texts, startF * scale, floorF * scale, ctx.base, ctx.maxWidth, maxLines, ctx.config.typeface, spacing)
        layoutCache[key] = layout
        return layout
    }

    private fun layoutWords(texts: List<String>, startF: Float, floorF: Float, base: Float, maxWidth: Float, maxLines: Int, typeface: Typeface, spacing: Float): Layout {
        var size = base * startF
        val floor = base * floorF
        while (true) {
            paint.reset()
            paint.isAntiAlias = true
            paint.typeface = typeface
            paint.textSize = size
            paint.letterSpacing = spacing
            val widths = FloatArray(texts.size) { paint.measureText(texts[it]) }
            val space = paint.measureText(" ")
            val lines = breakLines(widths, space, maxWidth, maxLines)
            if (lines != null) return makeLayout(size, spacing, lines, widths, space)
            if (size <= floor) return makeLayout(size, spacing, forcedRows(texts.size, maxLines), widths, space)
            size = max(size * 0.92f, floor)
        }
    }

    private fun breakLines(widths: FloatArray, space: Float, maxWidth: Float, maxLines: Int): List<IntArray>? {
        val n = widths.size
        if (n == 0) return null
        val prefix = FloatArray(n + 1)
        for (i in 0 until n) prefix[i + 1] = prefix[i] + widths[i]
        fun span(from: Int, to: Int): Float = prefix[to] - prefix[from] + space * (to - from - 1).coerceAtLeast(0)
        if (span(0, n) <= maxWidth) return listOf(IntArray(n) { it })
        if (maxLines >= 2 && n >= 2) {
            var best = -1
            var bestScore = Float.MAX_VALUE
            for (split in 1 until n) {
                val a = span(0, split)
                val b = span(split, n)
                if (a <= maxWidth && b <= maxWidth) {
                    val score = max(a, b) + abs(a - b) * 0.12f
                    if (score < bestScore) {
                        bestScore = score
                        best = split
                    }
                }
            }
            if (best > 0) return listOf(IntArray(best) { it }, IntArray(n - best) { best + it })
        }
        if (maxLines >= 3) {
            val lines = ArrayList<IntArray>()
            var start = 0
            while (start < n) {
                if (widths[start] > maxWidth) return null
                var end = start + 1
                while (end < n && span(start, end + 1) <= maxWidth) end++
                val from = start
                lines += IntArray(end - from) { from + it }
                start = end
                if (lines.size > maxLines) return null
            }
            return if (lines.size <= maxLines) lines else null
        }
        return null
    }

    private fun forcedRows(n: Int, maxLines: Int): List<IntArray> {
        val rows = min(maxLines, n).coerceAtLeast(1)
        val result = ArrayList<IntArray>()
        var start = 0
        for (r in 0 until rows) {
            val end = start + (n - start + (rows - r) - 1) / (rows - r)
            val from = start
            result += IntArray(end - from) { from + it }
            start = end
        }
        return result
    }

    private fun makeLayout(size: Float, spacing: Float, lines: List<IntArray>, widths: FloatArray, space: Float): Layout {
        val lineWidths = FloatArray(lines.size) { li ->
            var sum = 0f
            lines[li].forEach { sum += widths[it] }
            sum + space * (lines[li].size - 1).coerceAtLeast(0)
        }
        return Layout(size, spacing, lines, widths, space, lineWidths)
    }

    private fun blockFor(ctx: Ctx, layout: Layout): Block {
        paint.reset()
        paint.isAntiAlias = true
        paint.typeface = ctx.config.typeface
        paint.textSize = layout.size
        paint.letterSpacing = layout.spacing
        val fm = paint.fontMetrics
        val lineHeight = (fm.descent - fm.ascent) * 1.08f
        val total = lineHeight * layout.lines.size
        val top = clampSafe(ctx.centerY - total / 2f, ctx.safeTop, ctx.safeBottom - total)
        return Block(top, lineHeight, total, fm)
    }

    private fun eachWord(ctx: Ctx, layout: Layout, block: Block, offsetX: Float, offsetY: Float, action: (Int, Float, Float) -> Unit) {
        var baseline = block.top - block.fm.ascent + offsetY
        layout.lines.forEachIndexed { li, line ->
            var x = ctx.w / 2f - layout.lineWidths[li] / 2f + offsetX
            line.forEach { wi ->
                action(wi, x, baseline)
                x += layout.wordWidths[wi] + layout.spaceWidth
            }
            baseline += block.lineHeight
        }
    }

    // ---------------------------------------------------------------- drawing primitives

    private fun drawWord(
        ctx: Ctx, text: String, x: Float, y: Float, size: Float, spacing: Float,
        fill: Int, alpha: Float, strokeScale: Float = 1f, glow: Int = 0,
    ) {
        if (alpha <= 0.01f) return
        paint.reset()
        paint.isAntiAlias = true
        paint.typeface = ctx.config.typeface
        paint.textSize = size
        paint.letterSpacing = spacing
        paint.textAlign = Paint.Align.LEFT
        paint.strokeJoin = Paint.Join.ROUND
        paint.strokeMiter = 4f
        val shadowR = ctx.base * 0.0036f
        val shadowDy = ctx.base * 0.0012f
        val shadow = withAlpha(Color.argb(100, 0, 0, 0), alpha)
        if (strokeScale > 0f) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = max(1f, size * 0.05f) * strokeScale
            paint.color = withAlpha(ctx.outline, alpha)
            paint.setShadowLayer(shadowR, 0f, shadowDy, shadow)
            ctx.canvas.drawText(text, x, y, paint)
        }
        paint.style = Paint.Style.FILL
        paint.strokeWidth = 0f
        paint.color = withAlpha(fill, alpha)
        if (glow != 0) {
            paint.setShadowLayer(ctx.base * 0.024f, 0f, 0f, withAlpha(glow, alpha))
            ctx.canvas.drawText(text, x, y, paint)
        }
        paint.setShadowLayer(shadowR, 0f, shadowDy, shadow)
        ctx.canvas.drawText(text, x, y, paint)
        paint.clearShadowLayer()
    }

    private fun envelope(ctx: Ctx, inMs: Float, outMs: Float): Float =
        min(((ctx.t - ctx.caption.startMs) / inMs).coerceIn(0f, 1f), ((ctx.caption.endMs - ctx.t) / outMs).coerceIn(0f, 1f))

    private fun easeOut(p: Float): Float {
        val q = 1f - p.coerceIn(0f, 1f)
        return 1f - q * q * q
    }

    private fun withAlpha(color: Int, alpha: Float): Int {
        val a = ((color ushr 24) and 0xFF) * alpha.coerceIn(0f, 1f)
        return (color and 0x00FFFFFF) or (a.toInt().coerceIn(0, 255) shl 24)
    }

    private fun clampSafe(value: Float, lo: Float, hi: Float): Float = if (hi < lo) lo else value.coerceIn(lo, hi)

    /** [centerY, safeTop, safeBottom]. MIDDLE keeps exactly the position used by every version before 1.7. */
    private fun anchorFor(h: Float, horizontal: Boolean, position: CaptionPosition): FloatArray = when (position) {
        CaptionPosition.MIDDLE -> floatArrayOf(h * 0.49f, h * 0.27f, h * 0.72f)
        CaptionPosition.TOP ->
            if (horizontal) floatArrayOf(h * 0.18f, h * 0.08f, h * 0.34f) else floatArrayOf(h * 0.20f, h * 0.11f, h * 0.34f)
        CaptionPosition.BOTTOM ->
            if (horizontal) floatArrayOf(h * 0.80f, h * 0.66f, h * 0.92f) else floatArrayOf(h * 0.70f, h * 0.58f, h * 0.80f)
    }

    /** Resting color and spoken-word highlight. Dynamic keeps white text and highlights with the vivid dynamic color. */
    private fun colorsFor(preset: LyricColorPreset, legacy: Int): Pair<Int, Int> = when (preset) {
        LyricColorPreset.DYNAMIC -> Color.WHITE to legacy
        LyricColorPreset.BLACK -> Color.BLACK to 0xFFFFE040.toInt()
        LyricColorPreset.WHITE -> Color.WHITE to 0xFFFFE040.toInt()
        LyricColorPreset.YELLOW -> legacy to 0xFF00E8FF.toInt()
        else -> legacy to 0xFFFFE040.toInt()
    }

    companion object {
        fun sanitize(value: String): String = value
            .replace(Regex("\\[[^\\]]*]"), " ")
            .replace(Regex("\\([^)]*\\)"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        fun prepare(segments: List<CaptionSegment>): List<Caption> = segments.mapNotNull { segment ->
            val text = sanitize(segment.text)
            if (text.isBlank()) null else Caption(
                startMs = segment.startMs.coerceAtLeast(0L),
                endMs = segment.endMs.coerceAtLeast(segment.startMs + 120L),
                text = text,
            )
        }

        private fun indexAt(captions: List<Caption>, timeMs: Long): Int {
            var lo = 0
            var hi = captions.lastIndex
            var found = -1
            while (lo <= hi) {
                val mid = (lo + hi) ushr 1
                if (captions[mid].startMs <= timeMs) {
                    found = mid
                    lo = mid + 1
                } else hi = mid - 1
            }
            return if (found >= 0 && timeMs <= captions[found].endMs) found else -1
        }
    }
}
