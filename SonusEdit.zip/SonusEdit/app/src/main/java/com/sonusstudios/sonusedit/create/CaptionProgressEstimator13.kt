package com.sonusstudios.sonusedit.create

/** Percentage and countdown share the same calibrated total; completion is confirmed by Whisper. */
object CaptionProgressEstimator13 {
    @Suppress("UNUSED_PARAMETER")
    fun percent(
        reportedPercent: Int?,
        processedAudioMs: Long?,
        durationMs: Long,
        elapsedMs: Long,
        expectedTotalMs: Long,
        waitingForModel: Boolean,
        completed: Boolean,
    ): Int? {
        if (completed) return 100
        if (waitingForModel || durationMs <= 0L || expectedTotalMs <= 0L) return null
        return ((elapsedMs.coerceAtLeast(0L).toDouble() / expectedTotalMs.toDouble()) * 100.0)
            .toInt().coerceIn(0, 98)
    }
}
