package com.sonusstudios.sonusedit.create

/**
 * Produces a compact estimated percentage between Whisper's real chunk checkpoints.
 * Engine-reported progress is treated as a floor; elapsed-time interpolation is capped at 98%
 * and never claims completion before the transcription engine confirms it.
 */
object CaptionProgressEstimator13 {
    fun percent(
        reportedPercent: Int?,
        processedAudioMs: Long?,
        durationMs: Long,
        elapsedMs: Long,
        expectedTotalMs: Long,
        waitingForModel: Boolean,
        completed: Boolean,
    ): Int? {
        if (completed) return 100
        if (waitingForModel || durationMs <= 0L) return null

        val reported = reportedPercent?.coerceIn(0, 98) ?: 0
        val audioPercent = processedAudioMs?.let { processed ->
            ((processed.coerceIn(0L, durationMs).toDouble() / durationMs.toDouble()) * 100.0)
                .toInt().coerceIn(0, 98)
        } ?: 0
        val elapsedPercent = if (expectedTotalMs > 0L) {
            ((elapsedMs.coerceAtLeast(0L).toDouble() / expectedTotalMs.toDouble()) * 100.0)
                .toInt().coerceIn(0, 98)
        } else 0
        return maxOf(reported, audioPercent, elapsedPercent).coerceIn(0, 98)
    }
}
