package com.sonusstudios.sonusedit.create

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

/**
 * Android hand-off to the official OpenDownloader web app.
 * The web app is not an Android SDK: the URL is copied, its page is opened in the browser,
 * and the downloaded media is returned to SONUS EDIT through Android's Share action.
 */
object OpenDownloaderHandoff {
    const val WEB_APP_URL = "https://opendownloader.app/"

    fun open(context: Context, rawUrl: String): Boolean {
        val normalized = normalizeHttpUrl(rawUrl) ?: run {
            Toast.makeText(context, "Cole um link HTTPS válido primeiro.", Toast.LENGTH_LONG).show()
            return false
        }
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        clipboard?.setPrimaryClip(ClipData.newPlainText("Link para OpenDownloader", normalized))

        val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(WEB_APP_URL)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return runCatching {
            context.startActivity(browserIntent)
            Toast.makeText(
                context,
                "Link copiado. No OpenDownloader, cole o link. Depois use Compartilhar > SONUS EDIT.",
                Toast.LENGTH_LONG,
            ).show()
            true
        }.getOrElse {
            Toast.makeText(context, "Não foi possível abrir o navegador.", Toast.LENGTH_LONG).show()
            false
        }
    }

    internal fun normalizeHttpUrl(rawUrl: String): String? {
        val raw = rawUrl.trim()
        if (raw.isBlank()) return null
        val candidate = if (raw.startsWith("http://", true) || raw.startsWith("https://", true)) raw else "https://$raw"
        val uri = runCatching { java.net.URI(candidate) }.getOrNull() ?: return null
        if (uri.scheme?.lowercase() != "https" || uri.host.isNullOrBlank() || uri.userInfo != null) return null
        return uri.toASCIIString().substringBefore('#')
    }
}
