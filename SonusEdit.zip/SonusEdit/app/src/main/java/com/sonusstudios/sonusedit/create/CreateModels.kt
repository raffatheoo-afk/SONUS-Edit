package com.sonusstudios.sonusedit.create

import kotlinx.serialization.Serializable

@Serializable
enum class AudioSource { LOCAL, SONUS_STREAM, LINK, SHARED, VIDEO_EXTRACTED }

object ProjectAspectRatios {
    const val VERTICAL = "9:16"
    const val HORIZONTAL = "16:9"

    fun isHorizontal(value: String): Boolean = value == HORIZONTAL
}

@Serializable
data class CaptionSegment(
    val startMs: Long,
    val endMs: Long,
    val text: String,
)

@Serializable
enum class ExportResolution(
    val label: String,
    val width: Int,
    val height: Int,
) {
    P720("720p", 720, 1280),
    P1080("1080p", 1080, 1920),
    P2K("2K", 1440, 2560),
    P4K("4K", 2160, 3840);

    /**
     * The stored width/height remain the legacy 9:16 values so old drafts stay compatible.
     * Horizontal output swaps the long/short sides into the conventional 16:9 dimensions.
     */
    fun outputWidth(aspectRatio: String): Int =
        if (ProjectAspectRatios.isHorizontal(aspectRatio)) height else width

    fun outputHeight(aspectRatio: String): Int =
        if (ProjectAspectRatios.isHorizontal(aspectRatio)) width else height
}

@Serializable
data class CreateProjectDraft(
    val audioUri: String,
    val audioTitle: String,
    val audioArtist: String? = null,
    val audioAlbum: String? = null,
    val audioDurationMs: Long,
    val audioSource: AudioSource = AudioSource.LOCAL,
    val sourceTrackId: String? = null,
    val sourcePublicCode: String? = null,
    val sourceGenre: String? = null,
    val segmentStartMs: Long,
    val segmentDurationMs: Long,
    val signatureText: String,
    val signaturePhotoUri: String? = null,
    val signatureFontPreset: SignatureFontPreset = SignatureFontPreset.PATRICK_HAND,
    val signatureColorPreset: SignatureColorPreset = SignatureColorPreset.WHITE,
    val imageUris: List<String>,
    val localVideoUris: List<String> = emptyList(),
    // Internal schedule overrides used by the long-project exporter. Normal projects leave these empty.
    val visualDurationsMs: List<Long> = emptyList(),
    val visualSourceOffsetsMs: List<Long> = emptyList(),
    val visualFadeInFlags: List<Boolean> = emptyList(),
    val visualFadeOutFlags: List<Boolean> = emptyList(),
    val fontPreset: FontPresetId,
    val lyricColorPreset: LyricColorPreset = LyricColorPreset.DYNAMIC,
    val filterPreset: FilterPresetId = FilterPresetId.ORIGINAL,
    val aspectRatio: String = ProjectAspectRatios.VERTICAL,
    val minimumImageDurationMs: Long = 5_000L,
    val imageFadeInMs: Long = 1_500L,
    val imageFadeOutMs: Long = 1_500L,
    val audioFadeInMs: Long = 2_500L,
    val audioFadeOutMs: Long = 2_500L,
    val autoFillVertical: Boolean = true,
    val lyricsPolicy: LyricsPolicy = LyricsPolicy.AUTO,
    val syncedLyrics: String? = null, // legacy code17 draft compatibility only
    val captionSegments: List<CaptionSegment> = emptyList(),
    val exportTitle: String = audioTitle,
    val exportArtist: String = audioArtist.orEmpty(),
    val automaticEffectId: String = "raw_green_60",
    val automaticEffectOpacity: Float = 0.50f,
    val particlesEnabled: Boolean = true,
    val metadataOverlayEnabled: Boolean = true,
    val exportResolution: ExportResolution = ExportResolution.P1080,
    val exportFps: Int = 60,
    val sessionStartedEpochMs: Long = System.currentTimeMillis(),
    /** Start of active editing after the selected audio is ready; export duration is excluded. */
    val editingStartedEpochMs: Long? = null,
    val manualWorkMs: Long = 0L,
    val automaticWorkMs: Long = 0L,
)

@Serializable
enum class LyricsPolicy { AUTO, SONUS_ONLY, EXTERNAL_ALLOWED, OFF }

@Serializable
enum class FontPresetId(
    val label: String,
    val assetFileName: String? = null,
    val systemTypefaceName: String? = null,
) {
    // Stable ids from previous releases remain available for saved drafts/favorites.
    DEFAULT("Patrick Hand"),
    MODERN("Concert One"),
    ELEGANT("Amatic SC"),
    IMPACT("Rancho"),
    HANDWRITTEN("Sheila Crayon"),
    MINIMAL("Schoolwork-Regular"),
    NEON("Alley Garden"),
    RETRO("Playball"),
    NORMAL_SANS("Sans-serif", systemTypefaceName = "sans-serif"),
    NORMAL_SERIF("Serif", systemTypefaceName = "serif"),
    MAGIC_CLOVER("Magic Clover", assetFileName = "Magic Clover.otf"),
    IMPACT_STONE("Impact Stone", assetFileName = "Impact Stone.otf"),
    ROOMBOY("Roomboy", assetFileName = "Roomboy.otf"),
    THE_BROTHER_HOOPS("The Brother Hoops", assetFileName = "The Brother Hoops.otf"),
    CASA_PINADA("Casa Pinada", assetFileName = "Casa Pinada.ttf"),
    PAINTBRUSHSCRIPT_REGULAR("Paint Brush Script", assetFileName = "PaintBrushScript-Regular.ttf"),
    ALWAYS_LOVELY("Always Lovely", assetFileName = "Always Lovely.ttf"),
    ROCKY_TTF("Rocky", assetFileName = "Rocky TTF.ttf"),
    ELIONE("Elione", assetFileName = "Elione.otf"),
    THARON("Tharon", assetFileName = "Tharon.ttf"),
    DIFFERENTSUNSET("Different Sunset", assetFileName = "DifferentSunset.ttf"),
    ROCKY_BRUSH_ITALIC("Rocky Brush Italic", assetFileName = "Rocky Brush Italic.ttf"),
    ROCKY_BRUSH("Rocky Brush", assetFileName = "Rocky Brush.ttf"),
    JABAWOKY("Jabawoky", assetFileName = "Jabawoky.ttf"),
    MILLIWATTS_DEMO("Milliwatts", assetFileName = "Milliwatts demo.otf"),
    VALID_HARMONY("Valid Harmony", assetFileName = "Valid Harmony.ttf"),
    FLORIDA_ORANGE_PERSONAL_USE("Florida Orange", assetFileName = "Florida Orange - Personal Use.ttf"),
    DEEPABYSS("Deep Abyss", assetFileName = "DeepAbyss.otf"),
    FOLDERS("Folders", assetFileName = "Folders.ttf"),
    MYLOVE("MyLove", assetFileName = "MyLove.ttf"),
    ADELICIUS("Adelicius", assetFileName = "Adelicius.ttf"),
    GLOVERLEY("Gloverley", assetFileName = "Gloverley.ttf"),
    MY_KIDS_HANDWRITTEN("My Kids Handwritten", assetFileName = "My Kids Handwritten.otf"),
    KABUT_HITAM("Kabut Hitam", assetFileName = "Kabut Hitam.ttf"),
    I_LOVE_JANUARY("I Love January", assetFileName = "I_Love_January.otf"),
    THEABSOLUTE("The Absolute", assetFileName = "TheAbsolute.otf"),
    ON_THE_WAY("On The Way", assetFileName = "On The Way.ttf"),
    UNFORGOTTENMORE1("Unforgotten More", assetFileName = "UnforgottenMore1.otf"),
    PANTERICK_SWASH("Panterick Swash", assetFileName = "Panterick Swash.ttf"),
    EPICENTRUM("Epicentrum", assetFileName = "EPICENTRUM.ttf"),
    FAKE_SERIF("Fake Serif", assetFileName = "Fake Serif.ttf"),
    GAMBLER_IN_TOWN("Gambler in Town", assetFileName = "Gambler in Town.ttf"),
    OLIVER_RICHARDS("Oliver Richards", assetFileName = "Oliver Richards.ttf"),
    RJOETRIAL("Regular Joe", assetFileName = "RJOETRIAL.ttf"),
    BAARS("Baar Sophia", assetFileName = "BAARS___.TTF"),
}

@Serializable
enum class LyricColorPreset(val label: String) {
    DYNAMIC("Dinâmico"),
    WHITE("Branco"),
    YELLOW("Amarelo"),
    ORANGE("Laranja"),
    RED("Vermelho"),
    PINK("Rosa"),
    PURPLE("Roxo"),
    BLUE("Azul"),
    CYAN("Ciano"),
    GREEN("Verde"),
    BLACK("Preto"),
}

@Serializable
enum class SignatureFontPreset(val label: String) {
    PATRICK_HAND("Patrick Hand"),
    RANCHO("Rancho"),
    PLAYBALL("Playball"),
}

@Serializable
enum class SignatureColorPreset(val label: String) {
    WHITE("Branco"),
    YELLOW("Amarelo"),
    BLACK("Preto"),
}

@Serializable
enum class FilterPresetId(val label: String) {
    ORIGINAL("Natural"),
    CINEMATIC("Cinemático"),
    SUNSET("HDR Natural"),
    VINTAGE_FILM("Filme Vintage"),
    NIGHT_CITY("Preto Profundo"),
    NATURAL_PLUS("Vívido Natural"),
    SOFT_LIGHT("HDR Suave"),
    WARM_NATURAL("Quente Natural"),
    COOL_NATURAL("Frio Natural"),
    SOFT_CONTRAST("Contraste Suave"),
    CINEMA_CLEAN("Cinema Natural"),
    GOLDEN("Nitidez+"),
    CLEAN_NIGHT("Noite Limpa"),
    PASTEL_NATURAL("Pastel Natural"),
    CLARITY_PLUS("Clareza+"),
}

data class DurationPreset(val seconds: Int, val label: String, val untilEnd: Boolean = false) {
    fun durationMs(trackDurationMs: Long, startMs: Long): Long =
        if (untilEnd) (trackDurationMs - startMs).coerceAtLeast(1_000L)
        else seconds * 1_000L

    companion object {
        val all = listOf(
            DurationPreset(15, "15s"),
            DurationPreset(30, "30s"),
            DurationPreset(40, "40s"),
            DurationPreset(50, "50s"),
            DurationPreset(60, "60s"),
            DurationPreset(65, "65s"),
            DurationPreset(0, "∞", untilEnd = true),
        )

        val INFINITE: DurationPreset get() = all.last()
    }
}

object MediaDistributionPlanner {
    const val MIN_IMAGE_SECONDS = 5
    const val HARD_IMAGE_CAP = 50

    fun maxImages(durationSeconds: Int): Int = maxImagesForDurationMs(durationSeconds * 1_000L)

    // Target ~5 seconds per image, selecting the nearest sensible integer count.
    // 30s -> 6; 32s -> 6; 34s -> 7; each allocated image then has equal duration.
    fun maxImagesForDurationMs(durationMs: Long): Int =
        ((durationMs.coerceAtLeast(1L) + 2_500L) / (MIN_IMAGE_SECONDS * 1_000L))
            .toInt().coerceIn(1, HARD_IMAGE_CAP)

    fun durationsMs(durationSeconds: Int, imageCount: Int): List<Long> =
        durationsForTotalMs(durationSeconds * 1_000L, imageCount)

    fun durationsForTotalMs(totalMs: Long, imageCount: Int): List<Long> {
        require(totalMs > 0) { "totalMs must be > 0" }
        require(imageCount > 0) { "imageCount must be > 0" }
        require(imageCount <= maxImagesForDurationMs(totalMs)) {
            "imageCount exceeds the supported image limit"
        }
        val base = totalMs / imageCount
        var remainder = totalMs % imageCount
        return List(imageCount) { index ->
            // The last frames absorb integer rounding so the visual sequence closes exactly at
            // the requested video duration with no black gap.
            base + if (remainder-- > 0) 1L else 0L
        }
    }
}
