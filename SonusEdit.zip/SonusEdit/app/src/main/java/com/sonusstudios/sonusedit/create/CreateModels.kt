package com.sonusstudios.sonusedit.create

import kotlinx.serialization.Serializable

@Serializable
enum class AudioSource { LOCAL, SONUS_STREAM, SHARED }

@Serializable
enum class ExportResolution(
    val label: String,
    val width: Int,
    val height: Int,
) {
    P720("720p", 720, 1280),
    P1080("1080p", 1080, 1920),
    P2K("2K", 1440, 2560),
    P4K("4K", 2160, 3840),
}

@Serializable
data class CreateProjectDraft(
    val audioUri: String,
    val audioTitle: String,
    val audioArtist: String? = null,
    val audioAlbum: String? = null,
    val audioDurationMs: Long,
    val audioSource: AudioSource = AudioSource.LOCAL,
    val sourceTrackId: String? = null,
    val sourcePublicCode: String? = null,
    val sourceGenre: String? = null,
    val segmentStartMs: Long,
    val segmentDurationMs: Long,
    val signatureText: String,
    val signaturePhotoUri: String? = null,
    val imageUris: List<String>,
    val fontPreset: FontPresetId,
    val filterPreset: FilterPresetId = FilterPresetId.ORIGINAL,
    val aspectRatio: String = "9:16",
    val minimumImageDurationMs: Long = 5_000L,
    val imageFadeInMs: Long = 1_500L,
    val imageFadeOutMs: Long = 1_500L,
    val audioFadeInMs: Long = 2_500L,
    val audioFadeOutMs: Long = 2_500L,
    val autoFillVertical: Boolean = true,
    val lyricsPolicy: LyricsPolicy = LyricsPolicy.AUTO,
    val syncedLyrics: String? = null,
    val exportTitle: String = audioTitle,
    val exportArtist: String = audioArtist.orEmpty(),
    val automaticEffectId: String = "particles_star",
    val automaticEffectOpacity: Float = 0.50f,
    val metadataOverlayEnabled: Boolean = true,
    val exportResolution: ExportResolution = ExportResolution.P1080,
    val exportFps: Int = 60,
)

@Serializable
enum class LyricsPolicy { AUTO, SONUS_ONLY, EXTERNAL_ALLOWED, OFF }

@Serializable
enum class FontPresetId(val label: String) {
    DEFAULT("Padrão"),
    MODERN("Moderna"),
    ELEGANT("Elegante"),
    IMPACT("Impacto"),
    HANDWRITTEN("Manuscrita"),
    MINIMAL("Minimal"),
    NEON("Neon"),
    RETRO("Retrô"),
}

@Serializable
enum class FilterPresetId(val label: String) {
    ORIGINAL("Original"),
    CINEMATIC("Cinemático"),
    SUNSET("Pôr do Sol"),
    VINTAGE_FILM("Filme Vintage"),
    NIGHT_CITY("Cidade Noturna"),
    NATURAL_PLUS("Natural+"),
    SOFT_LIGHT("Luz Suave"),
    WARM_NATURAL("Quente Natural"),
    COOL_NATURAL("Frio Natural"),
    SOFT_CONTRAST("Contraste Suave"),
    CINEMA_CLEAN("Cinema Clean"),
    GOLDEN("Dourado"),
    CLEAN_NIGHT("Noite Limpa"),
    PASTEL_NATURAL("Pastel Natural"),
    CLARITY_PLUS("Clareza+"),
}

data class DurationPreset(val seconds: Int, val label: String) {
    companion object {
        // SONUS Edit is an automatic clip editor. Long 5/10 minute presets were intentionally
        // removed since code03 to keep the workflow automatic and avoid hundreds of photos.
        val all = listOf(
            DurationPreset(15, "15s"),
            DurationPreset(30, "30s"),
            DurationPreset(40, "40s"),
            DurationPreset(50, "50s"),
            DurationPreset(60, "60s"),
            DurationPreset(65, "65s"),
            DurationPreset(90, "90s"),
            DurationPreset(120, "120s"),
        )
    }
}

object MediaDistributionPlanner {
    const val MIN_IMAGE_SECONDS = 5
    const val HARD_IMAGE_CAP = 50

    fun maxImages(durationSeconds: Int): Int =
        (durationSeconds / MIN_IMAGE_SECONDS).coerceAtLeast(1).coerceAtMost(HARD_IMAGE_CAP)

    fun durationsMs(durationSeconds: Int, imageCount: Int): List<Long> {
        require(durationSeconds > 0) { "durationSeconds must be > 0" }
        require(imageCount > 0) { "imageCount must be > 0" }
        require(imageCount <= maxImages(durationSeconds)) {
            "imageCount exceeds the supported image limit"
        }
        val totalMs = durationSeconds * 1_000L
        val base = totalMs / imageCount
        var remainder = totalMs % imageCount
        return List(imageCount) { index ->
            // The last frames absorb integer rounding so the visual sequence closes exactly at
            // the requested video duration with no black gap.
            base + if (remainder-- > 0) 1L else 0L
        }
    }
}
