package com.sonusstudios.sonusedit.create

import kotlinx.serialization.Serializable

@Serializable
enum class AudioSource { LOCAL, SONUS_STREAM, LINK, SHARED, VIDEO_EXTRACTED }

object ProjectAspectRatios {
    const val VERTICAL = "9:16"
    const val HORIZONTAL = "16:9"
    const val SQUARE = "1:1"
    const val PORTRAIT_4_5 = "4:5"
    const val PORTRAIT_3_4 = "3:4"

    /** Offered by the "Outra proporção" button, besides 9:16 and 16:9. */
    val OTHER: List<String> = listOf(SQUARE, PORTRAIT_4_5, PORTRAIT_3_4)
    val ALL: List<String> = listOf(VERTICAL, HORIZONTAL) + OTHER

    fun isValid(value: String): Boolean = value in ALL

    /** Width and height parts of the ratio; 9:16 for anything unknown. */
    fun parts(value: String): Pair<Int, Int> {
        val pieces = value.split(":")
        val w = pieces.getOrNull(0)?.toIntOrNull()
        val h = pieces.getOrNull(1)?.toIntOrNull()
        return if (w != null && h != null && w > 0 && h > 0) w to h else 9 to 16
    }

    fun isHorizontal(value: String): Boolean {
        val (w, h) = parts(value)
        return w > h
    }
}

@Serializable
data class CaptionSegment(
    val startMs: Long,
    val endMs: Long,
    val text: String,
)

@Serializable
enum class ExportResolution(
    val label: String,
    val width: Int,
    val height: Int,
) {
    P720("720p", 720, 1280),
    P1080("1080p", 1080, 1920),
    P2K("2K", 1440, 2560),
    P4K("4K", 2160, 3840);

    /**
     * The stored width/height remain the legacy 9:16 values so old drafts stay compatible.
     * Horizontal output swaps the long/short sides into the conventional 16:9 dimensions.
     */
    fun outputWidth(aspectRatio: String): Int = dimensions(aspectRatio).first

    fun outputHeight(aspectRatio: String): Int = dimensions(aspectRatio).second

    /**
     * 9:16 and 16:9 keep their exact legacy sizes. Any other ratio keeps the short side of the
     * resolution (720 / 1080 / 1440 / 2160) and derives the long side, always with even numbers.
     */
    private fun dimensions(aspectRatio: String): Pair<Int, Int> {
        if (aspectRatio == ProjectAspectRatios.HORIZONTAL) return height to width
        if (aspectRatio == ProjectAspectRatios.VERTICAL) return width to height
        val (a, b) = ProjectAspectRatios.parts(aspectRatio)
        val shortSide = width
        return if (a >= b) {
            val longSide = shortSide * a / b
            (longSide - longSide % 2) to shortSide
        } else {
            val longSide = shortSide * b / a
            shortSide to (longSide - longSide % 2)
        }
    }
}

@Serializable
data class CreateProjectDraft(
    val audioUri: String,
    val audioTitle: String,
    val audioArtist: String? = null,
    val audioAlbum: String? = null,
    val audioDurationMs: Long,
    val audioSource: AudioSource = AudioSource.LOCAL,
    val sourceTrackId: String? = null,
    val sourcePublicCode: String? = null,
    val sourceGenre: String? = null,
    val segmentStartMs: Long,
    val segmentDurationMs: Long,
    val signatureText: String,
    val signaturePhotoUri: String? = null,
    val signatureFontPreset: SignatureFontPreset = SignatureFontPreset.PATRICK_HAND,
    val signatureColorPreset: SignatureColorPreset = SignatureColorPreset.WHITE,
    val imageUris: List<String>,
    val localVideoUris: List<String> = emptyList(),
    /** Stable pCloud media keys are committed to the cooldown only after MP4 export succeeds. */
    val imageHistoryKeys: List<String> = emptyList(),
    // Internal schedule overrides used by the long-project exporter. Normal projects leave these empty.
    val visualDurationsMs: List<Long> = emptyList(),
    val visualSourceOffsetsMs: List<Long> = emptyList(),
    val visualFadeInFlags: List<Boolean> = emptyList(),
    val visualFadeOutFlags: List<Boolean> = emptyList(),
    val fontPreset: FontPresetId,
    val lyricColorPreset: LyricColorPreset = LyricColorPreset.DYNAMIC,
    val filterPreset: FilterPresetId = FilterPresetId.ORIGINAL,
    val aspectRatio: String = ProjectAspectRatios.VERTICAL,
    val minimumImageDurationMs: Long = 5_000L,
    val imageFadeInMs: Long = 1_500L,
    val imageFadeOutMs: Long = 1_500L,
    val audioFadeInMs: Long = 2_500L,
    val audioFadeOutMs: Long = 2_500L,
    val autoFillVertical: Boolean = true,
    val lyricsPolicy: LyricsPolicy = LyricsPolicy.AUTO,
    val syncedLyrics: String? = null, // legacy code17 draft compatibility only
    val captionSegments: List<CaptionSegment> = emptyList(),
    val captionStyle: CaptionStyleId = CaptionStyleId.CLASSIC,
    val captionPosition: CaptionPosition = CaptionPosition.MIDDLE,
    /** Captions-only exports keep the whole source frame (no crop) inside the 9:16 / 16:9 canvas. */
    val fitFullFrame: Boolean = false,
    /** Exact export size for captions-only videos (the original frame). 0 = derive from resolution and ratio. */
    val customOutputWidth: Int = 0,
    val customOutputHeight: Int = 0,
    /** 1f is the default caption size; the user slider goes from 0.5f (tiny) to 2.4f (extra large). */
    val captionSizeScale: Float = 1f,
    /** 0f = bottom, 1f = top. The default reproduces the legacy "middle" placement. */
    val captionPositionPercent: Float = 0.52f,
    val exportTitle: String = audioTitle,
    val exportArtist: String = audioArtist.orEmpty(),
    val automaticEffectId: String = "raw_green_60",
    val automaticEffectOpacity: Float = 0.50f,
    val particlesEnabled: Boolean = true,
    val metadataOverlayEnabled: Boolean = true,
    val exportResolution: ExportResolution = ExportResolution.P1080,
    val exportFps: Int = 30,
    val sessionStartedEpochMs: Long = System.currentTimeMillis(),
    /** Start of active editing after the selected audio is ready; export duration is excluded. */
    val editingStartedEpochMs: Long? = null,
    val manualWorkMs: Long = 0L,
    val automaticWorkMs: Long = 0L,
) {
    private fun hasCustomOutput(): Boolean = customOutputWidth > 0 && customOutputHeight > 0

    fun outputWidth(): Int = if (hasCustomOutput()) customOutputWidth else exportResolution.outputWidth(aspectRatio)

    fun outputHeight(): Int = if (hasCustomOutput()) customOutputHeight else exportResolution.outputHeight(aspectRatio)

    fun isHorizontalOutput(): Boolean = outputWidth() > outputHeight()

    /** Label used in messages, e.g. "1080p 9:16" or "1080x1350". */
    fun outputLabel(): String =
        if (hasCustomOutput()) "${customOutputWidth}x$customOutputHeight" else "${exportResolution.label} $aspectRatio"
}

@Serializable
enum class LyricsPolicy { AUTO, SONUS_ONLY, EXTERNAL_ALLOWED, OFF }

@Serializable
enum class FontPresetId(
    val label: String,
    val assetFileName: String? = null,
    val systemTypefaceName: String? = null,
    val systemTypefaceStyle: Int = 0,
) {
    // Stable ids from previous releases remain available for saved drafts/favorites.
    DEFAULT("Patrick Hand"),
    MODERN("Concert One"),
    ELEGANT("Amatic SC"),
    IMPACT("Rancho"),
    HANDWRITTEN("Sheila Crayon"),
    MINIMAL("Schoolwork-Regular"),
    NEON("Alley Garden"),
    RETRO("Playball"),
    NORMAL_SANS("Sans-serif", systemTypefaceName = "sans-serif"),
    NORMAL_SERIF("Serif", systemTypefaceName = "serif"),
    MAGIC_CLOVER("Magic Clover", assetFileName = "Magic Clover.otf"),
    IMPACT_STONE("Impact Stone", assetFileName = "Impact Stone.otf"),
    ROOMBOY("Roomboy"),
    THE_BROTHER_HOOPS("The Brother Hoops"),
    CASA_PINADA("Casa Pinada"),
    PAINTBRUSHSCRIPT_REGULAR("Paint Brush Script", assetFileName = "PaintBrushScript-Regular.ttf"),
    ALWAYS_LOVELY("Always Lovely", assetFileName = "Always Lovely.ttf"),
    ROCKY_TTF("Rocky"),
    ELIONE("Elione", assetFileName = "Elione.otf"),
    THARON("Tharon"),
    DIFFERENTSUNSET("Different Sunset"),
    ROCKY_BRUSH_ITALIC("Rocky Brush Italic"),
    ROCKY_BRUSH("Rocky Brush"),
    JABAWOKY("Jabawoky"),
    MILLIWATTS_DEMO("Milliwatts"),
    VALID_HARMONY("Valid Harmony", assetFileName = "Valid Harmony.ttf"),
    FLORIDA_ORANGE_PERSONAL_USE("Florida Orange"),
    DEEPABYSS("Deep Abyss"),
    FOLDERS("Folders"),
    MYLOVE("MyLove"),
    ADELICIUS("Adelicius", assetFileName = "Adelicius.ttf"),
    GLOVERLEY("Gloverley"),
    MY_KIDS_HANDWRITTEN("My Kids Handwritten"),
    KABUT_HITAM("Kabut Hitam", assetFileName = "Kabut Hitam.ttf"),
    I_LOVE_JANUARY("I Love January"),
    THEABSOLUTE("The Absolute"),
    ON_THE_WAY("On The Way"),
    UNFORGOTTENMORE1("Unforgotten More"),
    PANTERICK_SWASH("Panterick Swash"),
    EPICENTRUM("Epicentrum"),
    FAKE_SERIF("Fake Serif", assetFileName = "Fake Serif.ttf"),
    GAMBLER_IN_TOWN("Gambler in Town"),
    OLIVER_RICHARDS("Oliver Richards"),
    RJOETRIAL("Regular Joe"),
    BAARS("Baar Sophia", assetFileName = "BAARS___.TTF"),
    SANS_CLEAN("Sans Clean", systemTypefaceName = "sans-serif-light", systemTypefaceStyle = 1),
    SANS_MEDIUM("Sans Médio", systemTypefaceName = "sans-serif-medium"),
    SANS_LIGHT("Sans Leve", systemTypefaceName = "sans-serif-light"),
    SANS_BLACK("Sans Forte", systemTypefaceName = "sans-serif-black"),
    SANS_CONDENSED("Sans Compacta", systemTypefaceName = "sans-serif-condensed"),
    SANS_CONDENSED_LIGHT("Sans Compacta Leve", systemTypefaceName = "sans-serif-condensed-light"),
    SANS_CONDENSED_MEDIUM("Sans Compacta Média", systemTypefaceName = "sans-serif-condensed-medium"),
    SANS_CONDENSED_BLACK("Sans Compacta Forte", systemTypefaceName = "sans-serif-condensed-black"),
    SANS_ROUNDED("Sans Arredondada", systemTypefaceName = "sans-serif-rounded"),
    SANS_SMALLCAPS("Sans Versalete", systemTypefaceName = "sans-serif-smallcaps"),
    SERIF_CLEAN("Serif Limpa", systemTypefaceName = "serif"),
    SERIF_MEDIUM("Serif Média", systemTypefaceName = "serif", systemTypefaceStyle = 1),
    SERIF_BOLD("Serif Forte", systemTypefaceName = "serif-monospace", systemTypefaceStyle = 1),
    SERIF_ITALIC("Serif Itálica", systemTypefaceName = "serif", systemTypefaceStyle = 2),
    SERIF_BOLD_ITALIC("Serif Forte Itálica", systemTypefaceName = "serif", systemTypefaceStyle = 3),
    MONO_CLEAN("Mono Limpa", systemTypefaceName = "monospace"),
    MONO_MEDIUM("Mono Média", systemTypefaceName = "monospace", systemTypefaceStyle = 1),
    MONO_BOLD("Mono Forte", systemTypefaceName = "monospace", systemTypefaceStyle = 3),
    SANS_ITALIC("Sans Itálica", systemTypefaceName = "sans-serif", systemTypefaceStyle = 2),
    SANS_MEDIUM_ITALIC("Sans Média Itálica", systemTypefaceName = "sans-serif-medium", systemTypefaceStyle = 2),
    SANS_BOLD("Sans Forte", systemTypefaceName = "sans-serif", systemTypefaceStyle = 1),
    SANS_BOLD_ITALIC("Sans Forte Itálica", systemTypefaceName = "sans-serif", systemTypefaceStyle = 3),
    SANS_THIN("Sans Fina", systemTypefaceName = "sans-serif-thin"),
    SANS_EXTRA_LIGHT("Sans Extra Leve", systemTypefaceName = "sans-serif-thin", systemTypefaceStyle = 1),
    SANS_BLACK_ITALIC("Sans Forte Itálica 2", systemTypefaceName = "sans-serif-black", systemTypefaceStyle = 2),
    SERIF_MONO("Serif Mono", systemTypefaceName = "serif-monospace"),
    CASUAL_SYSTEM("Sans Leve Itálica", systemTypefaceName = "sans-serif-light", systemTypefaceStyle = 2),
    SANS_BOLD_ROUNDED("Sans Arredondada Forte", systemTypefaceName = "sans-serif-rounded", systemTypefaceStyle = 1),
    SANS_NARROW("Sans Estreita", systemTypefaceName = "sans-serif-condensed-medium", systemTypefaceStyle = 1),
}

/**
 * 30 curated, built-in Android typeface family/weight variants. They require no bundled font assets
 * and keep captions readable on entry-level devices. Legacy display-font ids remain serializable for
 * old drafts and map to the closest natural system family through [effective].
 */
object CaptionFontPool {
    val approved: List<FontPresetId> = listOf(
        FontPresetId.NORMAL_SANS,
        FontPresetId.SANS_CLEAN, FontPresetId.SANS_MEDIUM, FontPresetId.SANS_LIGHT,
        FontPresetId.SANS_BLACK, FontPresetId.SANS_CONDENSED, FontPresetId.SANS_CONDENSED_LIGHT,
        FontPresetId.SANS_CONDENSED_MEDIUM, FontPresetId.SANS_CONDENSED_BLACK,
        FontPresetId.SANS_ROUNDED, FontPresetId.SANS_SMALLCAPS, FontPresetId.SERIF_CLEAN,
        FontPresetId.SERIF_MEDIUM, FontPresetId.SERIF_BOLD, FontPresetId.SERIF_ITALIC,
        FontPresetId.SERIF_BOLD_ITALIC, FontPresetId.MONO_CLEAN, FontPresetId.MONO_MEDIUM,
        FontPresetId.MONO_BOLD, FontPresetId.SANS_ITALIC, FontPresetId.SANS_MEDIUM_ITALIC,
        FontPresetId.SANS_BOLD, FontPresetId.SANS_BOLD_ITALIC, FontPresetId.SANS_THIN,
        FontPresetId.SANS_EXTRA_LIGHT, FontPresetId.SANS_BLACK_ITALIC, FontPresetId.SERIF_MONO,
        FontPresetId.CASUAL_SYSTEM, FontPresetId.SANS_BOLD_ROUNDED, FontPresetId.SANS_NARROW,
    )

    private val retiredReplacement: Map<FontPresetId, FontPresetId> = mapOf(
        FontPresetId.DEFAULT to FontPresetId.SANS_CLEAN,
        FontPresetId.MODERN to FontPresetId.SANS_BOLD,
        FontPresetId.ELEGANT to FontPresetId.SERIF_CLEAN,
        FontPresetId.IMPACT to FontPresetId.SANS_BLACK,
        FontPresetId.HANDWRITTEN to FontPresetId.SANS_ROUNDED,
        FontPresetId.MINIMAL to FontPresetId.MONO_CLEAN,
        FontPresetId.NEON to FontPresetId.SANS_MEDIUM,
        FontPresetId.RETRO to FontPresetId.SERIF_ITALIC,
        FontPresetId.NORMAL_SERIF to FontPresetId.SERIF_CLEAN,
        FontPresetId.MAGIC_CLOVER to FontPresetId.SANS_CLEAN,
        FontPresetId.IMPACT_STONE to FontPresetId.SANS_BOLD,
        FontPresetId.PAINTBRUSHSCRIPT_REGULAR to FontPresetId.SERIF_CLEAN,
        FontPresetId.ALWAYS_LOVELY to FontPresetId.SANS_ROUNDED,
        FontPresetId.ELIONE to FontPresetId.SANS_MEDIUM,
        FontPresetId.VALID_HARMONY to FontPresetId.SANS_CLEAN,
        FontPresetId.ADELICIUS to FontPresetId.SANS_MEDIUM,
        FontPresetId.KABUT_HITAM to FontPresetId.SANS_BOLD,
        FontPresetId.FAKE_SERIF to FontPresetId.SERIF_CLEAN,
        FontPresetId.BAARS to FontPresetId.SANS_CLEAN,
        FontPresetId.ROCKY_TTF to FontPresetId.NORMAL_SANS,
        FontPresetId.THE_BROTHER_HOOPS to FontPresetId.NORMAL_SANS,
        FontPresetId.GLOVERLEY to FontPresetId.NORMAL_SANS,
        FontPresetId.ROCKY_BRUSH_ITALIC to FontPresetId.NORMAL_SANS,
        FontPresetId.ROCKY_BRUSH to FontPresetId.NORMAL_SANS,
        FontPresetId.EPICENTRUM to FontPresetId.NORMAL_SANS,
        FontPresetId.ROOMBOY to FontPresetId.NORMAL_SANS,
        FontPresetId.CASA_PINADA to FontPresetId.SANS_CLEAN,
        FontPresetId.THARON to FontPresetId.NORMAL_SANS,
        FontPresetId.DIFFERENTSUNSET to FontPresetId.SANS_CLEAN,
        FontPresetId.JABAWOKY to FontPresetId.SANS_MEDIUM,
        FontPresetId.MILLIWATTS_DEMO to FontPresetId.SANS_BOLD,
        FontPresetId.FLORIDA_ORANGE_PERSONAL_USE to FontPresetId.SANS_CLEAN,
        FontPresetId.DEEPABYSS to FontPresetId.SANS_CLEAN,
        FontPresetId.FOLDERS to FontPresetId.NORMAL_SANS,
        FontPresetId.MYLOVE to FontPresetId.SANS_CLEAN,
        FontPresetId.MY_KIDS_HANDWRITTEN to FontPresetId.SANS_BOLD,
        FontPresetId.I_LOVE_JANUARY to FontPresetId.SERIF_CLEAN,
        FontPresetId.THEABSOLUTE to FontPresetId.SANS_MEDIUM,
        FontPresetId.ON_THE_WAY to FontPresetId.NORMAL_SANS,
        FontPresetId.UNFORGOTTENMORE1 to FontPresetId.SERIF_CLEAN,
        FontPresetId.PANTERICK_SWASH to FontPresetId.SANS_CLEAN,
        FontPresetId.GAMBLER_IN_TOWN to FontPresetId.SANS_MEDIUM,
        FontPresetId.OLIVER_RICHARDS to FontPresetId.NORMAL_SANS,
        FontPresetId.RJOETRIAL to FontPresetId.SANS_ROUNDED,
    )

    fun isRetired(id: FontPresetId): Boolean = id in retiredReplacement

    fun effective(id: FontPresetId): FontPresetId = retiredReplacement[id] ?: id
}

fun FontPresetId.effective(): FontPresetId = CaptionFontPool.effective(this)

@Serializable
enum class LyricColorPreset(val label: String) {
    DYNAMIC("Dinâmico"),
    WHITE("Branco"),
    YELLOW("Amarelo"),
    ORANGE("Laranja"),
    RED("Vermelho"),
    PINK("Rosa"),
    PURPLE("Roxo"),
    BLUE("Azul"),
    CYAN("Ciano"),
    GREEN("Verde"),
    BLACK("Preto"),
    GRAY("Cinza"), SILVER("Prata"), DARK_GRAY("Grafite"),
    BROWN("Marrom"), MAGENTA("Magenta"), TURQUOISE("Turquesa"),
    NAVY("Azul-marinho"), LIME("Lima"), CORAL("Coral"),
    GOLD("Dourado"), MINT("Menta"), LAVENDER("Lavanda"),
    TEAL("Verde-petróleo"), WINE("Vinho"),
}

@Serializable
enum class SignatureFontPreset(val label: String) {
    PATRICK_HAND("Patrick Hand"),
    RANCHO("Rancho"),
    PLAYBALL("Playball"),
}

@Serializable
enum class SignatureColorPreset(val label: String) {
    WHITE("Branco"),
    YELLOW("Amarelo"),
    BLACK("Preto"),
}

@Serializable
enum class FilterPresetId(val label: String, val premiumIllustrative: Boolean = false, val automaticEligible: Boolean = true) {
    // The original IDs remain stable for saved drafts and favorites.
    // so projects created by older versions still open without losing their saved selection.
    ORIGINAL("Natural"),
    CINEMATIC("Cinemático"),
    SUNSET("HDR Natural"),
    VINTAGE_FILM("Filme Vintage", automaticEligible = false),
    NIGHT_CITY("Preto Profundo"),
    NATURAL_PLUS("Vivido"),
    SOFT_LIGHT("HDR Suave"),
    WARM_NATURAL("Quente Natural"),
    COOL_NATURAL("Frio Natural"),
    SOFT_CONTRAST("Contraste Suave"),
    CINEMA_CLEAN("Cinema Natural"),
    GOLDEN("Nitidez+"),
    CLEAN_NIGHT("Noite Limpa"),
    PASTEL_NATURAL("Pastel Natural"),
    CLARITY_PLUS("Clareza+", automaticEligible = false),
    SPRING("Primavera"),
    BLACK_AND_WHITE("Preto e branco"),
    STUDIO_FILM("Filme Studio", true),
    PORTRAIT_GLOW("Retrato Glow", true),
    GOLDEN_HOUR("Hora Dourada", true),
    TEAL_ORANGE("Teal & Orange", true),
    MOODY_BLUE("Azul Cinemático", true),
    SOFT_MATTE("Matte Suave", true),
    VIBRANT_POP("Vibrante", true),
    WARM_FILM("Filme Quente", true),
    CRISP_HDR("HDR Nítido", true),
    DREAM_LIGHT("Luz dos Sonhos", true),
}

data class DurationPreset(val seconds: Int, val label: String, val untilEnd: Boolean = false) {
    fun durationMs(trackDurationMs: Long, startMs: Long): Long =
        if (untilEnd) (trackDurationMs - startMs).coerceAtLeast(1_000L)
        else seconds * 1_000L

    companion object {
        val all = listOf(
            DurationPreset(15, "15s"),
            DurationPreset(30, "30s"),
            DurationPreset(40, "40s"),
            DurationPreset(50, "50s"),
            DurationPreset(60, "60s"),
            DurationPreset(65, "65s"),
            DurationPreset(0, "∞", untilEnd = true),
        )

        val INFINITE: DurationPreset get() = all.last()
    }
}

object MediaDistributionPlanner {
    const val MIN_IMAGE_SECONDS = 5
    const val HARD_IMAGE_CAP = 50

    fun maxImages(durationSeconds: Int): Int = maxImagesForDurationMs(durationSeconds * 1_000L)

    // Target ~5 seconds per image, selecting the nearest sensible integer count.
    // 30s -> 6; 32s -> 6; 34s -> 7; each allocated image then has equal duration.
    fun maxImagesForDurationMs(durationMs: Long): Int =
        ((durationMs.coerceAtLeast(1L) + 2_500L) / (MIN_IMAGE_SECONDS * 1_000L))
            .toInt().coerceIn(1, HARD_IMAGE_CAP)

    fun durationsMs(durationSeconds: Int, imageCount: Int): List<Long> =
        durationsForTotalMs(durationSeconds * 1_000L, imageCount)

    fun durationsForTotalMs(totalMs: Long, imageCount: Int): List<Long> {
        require(totalMs > 0) { "totalMs must be > 0" }
        require(imageCount > 0) { "imageCount must be > 0" }
        require(imageCount <= maxImagesForDurationMs(totalMs)) {
            "imageCount exceeds the supported image limit"
        }
        val base = totalMs / imageCount
        var remainder = totalMs % imageCount
        return List(imageCount) { index ->
            // The last frames absorb integer rounding so the visual sequence closes exactly at
            // the requested video duration with no black gap.
            base + if (remainder-- > 0) 1L else 0L
        }
    }
}
