package com.sonusstudios.sonusedit.create

import android.content.Context
import kotlinx.serialization.Serializable
import kotlin.random.Random

@Serializable
enum class VisualTransitionMode { SINGLE, MULTIPLE, RANDOM }

@Serializable
data class VisualTransitionSettings(
    val mode: VisualTransitionMode = VisualTransitionMode.SINGLE,
    val selectedIds: List<String> = listOf("fade"),
)

data class VisualTransitionFamily(val id: String, val label: String, val entrance: String, val exit: String)

object VisualTransitionCatalog {
    val families = listOf(
        VisualTransitionFamily("fade", "Fade", "Fade In", "Fade Out"),
        VisualTransitionFamily("zoom", "Zoom", "Zoom In", "Zoom Out"),
        VisualTransitionFamily("slide", "Slide", "Slide In", "Slide Out"),
        VisualTransitionFamily("rise", "Rise", "Rise In", "Drop Out"),
        VisualTransitionFamily("blur", "Blur", "Blur In", "Blur Out"),
        VisualTransitionFamily("rotate", "Rotate", "Rotate In", "Rotate Out"),
        VisualTransitionFamily("push", "Push", "Push In", "Push Out"),
        VisualTransitionFamily("wipe", "Wipe", "Wipe In", "Wipe Out"),
        VisualTransitionFamily("parallax", "Parallax", "Parallax In", "Parallax Out"),
        VisualTransitionFamily("light", "Light", "Light In", "Light Out"),
    )

    fun normalize(settings: VisualTransitionSettings): VisualTransitionSettings {
        val valid = settings.selectedIds.filter { id -> families.any { it.id == id } }.distinct().take(4)
        return when (settings.mode) {
            VisualTransitionMode.SINGLE -> settings.copy(selectedIds = listOf(valid.firstOrNull() ?: "fade"))
            VisualTransitionMode.MULTIPLE -> settings.copy(selectedIds = valid.ifEmpty { listOf("fade") })
            VisualTransitionMode.RANDOM -> settings.copy(selectedIds = listOf("fade"))
        }
    }

    /** Chooses the allowed family pool once for a project. RANDOM is not rerolled per media. */
    fun resolvePoolForProject(settings: VisualTransitionSettings, seed: Long): List<String> {
        val normalized = normalize(settings)
        return when (normalized.mode) {
            VisualTransitionMode.SINGLE -> normalized.selectedIds
            VisualTransitionMode.MULTIPLE -> normalized.selectedIds.take(4)
            VisualTransitionMode.RANDOM -> families.map { it.id }.shuffled(Random(seed)).take(4)
        }.ifEmpty { listOf("fade") }
    }

    /** Extends/truncates assignments without changing already assigned media in the same project. */
    fun appendAssignments(existing: List<String>, allowedPool: List<String>, mediaCount: Int, seed: Long): List<String> {
        if (mediaCount <= 0) return emptyList()
        val allowed = allowedPool.filter { id -> families.any { it.id == id } }.distinct().take(4).ifEmpty { listOf("fade") }
        val result = existing.filter { it in allowed }.take(mediaCount).toMutableList()
        val order = allowed.shuffled(Random(seed xor 0x534F4E5553L))
        while (result.size < mediaCount) {
            val candidate = order[result.size % order.size]
            // A multi-family pool is evenly cycled in a randomized order: no immediate repeats,
            // every allowed family appears once per cycle, and extending the project preserves
            // every assignment already stored in the draft.
            result += candidate
        }
        return result
    }

    /** Convenience for tests/callers that do not need to persist the pool separately. */
    fun resolveForProject(settings: VisualTransitionSettings, mediaCount: Int, seed: Long): List<String> =
        appendAssignments(emptyList(), resolvePoolForProject(settings, seed), mediaCount, seed)

    /**
     * Export compatibility: a completely empty list is a legacy draft and keeps factory Fade.
     * A partial or unknown assignment is a broken project state and must not silently become Fade.
     */
    fun assignmentsForExport(assignments: List<String>, mediaCount: Int): List<String> {
        if (mediaCount <= 0) return emptyList()
        if (assignments.isEmpty()) return List(mediaCount) { "fade" }
        require(assignments.size == mediaCount) {
            "O projeto possui ${assignments.size} transições para $mediaCount mídias. Reabra o projeto antes de exportar."
        }
        val validIds = families.map { it.id }.toSet()
        require(assignments.all { it in validIds }) {
            "O projeto contém uma família de transição desconhecida. Reabra o projeto antes de exportar."
        }
        return assignments.toList()
    }
}

class VisualTransitionPreferences(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("sonus_edit_visual_transitions", Context.MODE_PRIVATE)

    fun load(): VisualTransitionSettings {
        val mode = runCatching { VisualTransitionMode.valueOf(prefs.getString("mode", VisualTransitionMode.SINGLE.name)!!) }
            .getOrDefault(VisualTransitionMode.SINGLE)
        val ids = prefs.getString("selected_ids", "fade").orEmpty().split(',').filter { it.isNotBlank() }
        return VisualTransitionCatalog.normalize(VisualTransitionSettings(mode, ids))
    }

    fun save(value: VisualTransitionSettings) {
        val normalized = VisualTransitionCatalog.normalize(value)
        prefs.edit().putString("mode", normalized.mode.name)
            .putString("selected_ids", normalized.selectedIds.joinToString(",")).apply()
    }

    fun resolvePoolForProject(seed: Long): List<String> =
        VisualTransitionCatalog.resolvePoolForProject(load(), seed)

    fun appendAssignments(existing: List<String>, pool: List<String>, mediaCount: Int, seed: Long): List<String> =
        VisualTransitionCatalog.appendAssignments(existing, pool, mediaCount, seed)

    fun resolveForProject(mediaCount: Int, seed: Long): List<String> =
        VisualTransitionCatalog.resolveForProject(load(), mediaCount, seed)
}
