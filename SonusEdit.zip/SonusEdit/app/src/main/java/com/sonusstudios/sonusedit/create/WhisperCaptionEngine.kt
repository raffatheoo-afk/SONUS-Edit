package com.sonusstudios.sonusedit.create

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import dev.ffmpegkit.whisper.Whisper
import dev.ffmpegkit.whisper.WhisperConfig
import java.io.File
import java.net.HttpURLConnection
import java.net.URI
import java.security.MessageDigest
import java.text.Normalizer
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * code22 on-device automatic captions.
 *
 * Accuracy is preferred over minimum latency: the multilingual Whisper Small model listens
 * directly to the selected audio. Version 1.1 improves language consistency,
 * uses overlapping windows to reduce long-form drift in sung vocals, and reconciles overlap
 * duplicates before the existing caption compositor consumes the timed segments.
 *
 * The upstream whisper-android 1.0.0 AAR hard-codes greedy decoding in native code and does not
 * expose sampling strategy to Kotlin. We therefore improve precision without replacing that proven
 * native dependency: language locking + a first-chunk PT/auto comparison + tighter context windows.
 */
class WhisperCaptionEngine(private val context: Context) {
    data class Progress(
        val status: String,
        val percent: Int? = null,
        val processedAudioMs: Long? = null,
    )

    data class Result(
        val segments: List<CaptionSegment>,
        val processingMs: Long,
        val fromCache: Boolean,
    )

    private val appContext = context.applicationContext
    private val modelDir = File(appContext.filesDir, "whisper_models").apply { mkdirs() }
    private val cacheDir = File(appContext.cacheDir, "sonus_caption_cache").apply { mkdirs() }
    private val json = Json { ignoreUnknownKeys = true }
    private val transcriptionMutex = Mutex()

    suspend fun generate(
        audioUri: Uri,
        startMs: Long,
        durationMs: Long,
        titleHint: String = "",
        onProgress: (Progress) -> Unit = {},
    ): Result = withContext(Dispatchers.IO) {
        require(durationMs > 0L) { "Trecho de áudio inválido para gerar legenda." }
        val languageHint = CaptionLanguageHint.fromTitle(titleHint)
        val sourceKey = audioIdentity(audioUri)
        val cache = cacheFile(sourceKey, startMs, durationMs, languageHint)
        readCache(cache)?.let { cached ->
            onProgress(Progress(if (cached.isEmpty()) "Sem voz detectada" else "Letra sincronizada", 100))
            return@withContext Result(cached, 0L, true)
        }

        // A changed trim cannot load a second native Whisper model while the old inference unwinds.
        transcriptionMutex.withLock {
            readCache(cache)?.let { cached ->
                onProgress(Progress(if (cached.isEmpty()) "Sem voz detectada" else "Letra sincronizada", 100))
                return@withLock Result(cached, 0L, true)
            }

            val started = System.currentTimeMillis()
            val modelFile = ensureModel(onProgress)
            ensureActive()

            onProgress(Progress("Carregando Whisper Small…"))
            val model = Whisper.loadModel(appContext, modelFile.absolutePath)
            try {
                val threads = (Runtime.getRuntime().availableProcessors() - 1).coerceIn(2, 4)
                val merged = mutableListOf<CaptionSegment>()
                var lockedLanguage: String? = null
                val projectLanguageCache = languageCacheFile(sourceKey, startMs, durationMs, languageHint)
                val cachedLanguage = runCatching {
                    projectLanguageCache.takeIf { it.isFile }?.readText()?.trim()?.takeIf { it in setOf("pt", "en", "auto") }
                }.getOrNull()
                lockedLanguage = cachedLanguage
                val longProject = durationMs >= LONG_PROJECT_MS
                val chunkWindowMs = if (longProject) LONG_CHUNK_MS else CHUNK_MS
                val chunkOverlapMs = if (longProject) LONG_CHUNK_OVERLAP_MS else CHUNK_OVERLAP_MS

                suspend fun consumeChunk(offsetMs: Long, chunkMs: Long, wav: File?) {
                    ensureActive()
                    val chunkCache = chunkCacheFile(sourceKey, startMs + offsetMs, chunkMs, languageHint)
                    val cachedChunk = if (lockedLanguage != null) readCache(chunkCache) else null
                    val localSegments = if (cachedChunk != null) {
                        cachedChunk
                    } else {
                        val prepared = requireNotNull(wav) { "Áudio temporário da legenda não foi preparado." }
                        onProgress(Progress("Ouvindo e sincronizando letra…", progressAt(offsetMs, durationMs)))
                        val result = if (lockedLanguage == null) {
                            // First voiced window: compare auto-detection with an explicit Portuguese
                            // pass on PT-BR devices. This costs a little more once per song, but avoids
                            // the frequent sung-vocal failure mode where auto detection drifts language.
                            val autoResult = transcribeChunk(model, prepared, threads, "auto")
                            if (autoResult.text.isBlank()) {
                                autoResult // Keep probing on a later voiced chunk.
                            } else {
                                // Title only raises a hypothesis: compare it against a voiced sample.
                                // English must not be forced into Portuguese on a PT-BR Android phone.
                                val candidate = when {
                                    languageHint == "pt" -> "pt"
                                    languageHint == "en" -> "en"
                                    shouldProbePortuguese(autoResult.text) -> "pt"
                                    else -> null
                                }
                                if (candidate == null) {
                                    lockedLanguage = "auto"
                                    autoResult
                                } else {
                                    onProgress(Progress("Conferindo idioma da música…", progressAt(offsetMs, durationMs)))
                                    ensureActive()
                                    val retry = transcribeChunk(model, prepared, threads, candidate)
                                    if (CaptionLanguageHint.acceptCandidate(candidate, retry.text, autoResult.text)) {
                                        lockedLanguage = candidate
                                        retry
                                    } else {
                                        lockedLanguage = "auto"
                                        autoResult
                                    }
                                }
                            }
                        } else {
                            transcribeChunk(model, prepared, threads, lockedLanguage!!)
                        }

                        if (lockedLanguage != null) runCatching { projectLanguageCache.writeText(lockedLanguage!!) }
                        result.segments.mapNotNull { segment ->
                            val text = cleanCaption(segment.text)
                            if (text.isBlank()) return@mapNotNull null
                            val localStart = segment.startMs.coerceIn(0L, chunkMs)
                            val localEnd = segment.endMs.coerceIn(0L, chunkMs)
                                .coerceAtLeast(localStart + MIN_CAPTION_MS)
                                .coerceAtMost(chunkMs)
                            if (localEnd <= localStart) null else CaptionSegment(localStart, localEnd, text)
                        }.also { runCatching { chunkCache.writeText(json.encodeToString(it)) } }
                    }

                    localSegments.forEach { local ->
                        val absoluteStart = (offsetMs + local.startMs).coerceAtMost(durationMs)
                        val absoluteEnd = (offsetMs + local.endMs).coerceAtMost(durationMs)
                        if (absoluteStart < durationMs && absoluteEnd > absoluteStart) {
                            merged += CaptionSegment(absoluteStart, absoluteEnd, local.text)
                        }
                    }
                    onProgress(
                        Progress(
                            status = if (longProject) "Legenda longa • progresso salvo" else "Sincronizando próximos trechos…",
                            percent = progressAt((offsetMs + chunkMs - chunkOverlapMs).coerceAtLeast(offsetMs), durationMs),
                            processedAudioMs = (offsetMs + chunkMs).coerceAtMost(durationMs),
                        )
                    )
                }

                if (longProject) {
                    // Decode the selected 60–90+ minute audio range once, sequentially. Each Whisper
                    // window is persisted as soon as it completes, so cancelling/reopening can reuse
                    // completed chunks instead of starting transcription from zero.
                    onProgress(Progress("Preparando legenda longa…", 0))
                    AudioSegmentWavExtractor.extractSequentialChunks(
                        context = appContext,
                        source = audioUri,
                        startMs = startMs,
                        durationMs = durationMs,
                        chunkMs = chunkWindowMs,
                        overlapMs = chunkOverlapMs,
                        tempDir = appContext.cacheDir,
                    ) { offsetMs, plannedChunkMs, wav ->
                        consumeChunk(offsetMs, plannedChunkMs, wav)
                    }
                } else {
                    var offsetMs = 0L
                    while (offsetMs < durationMs) {
                        ensureActive()
                        val chunkMs = minOf(chunkWindowMs, durationMs - offsetMs)
                        val chunkCache = chunkCacheFile(sourceKey, startMs + offsetMs, chunkMs, languageHint)
                        if (projectLanguageExists(sourceKey, startMs, durationMs, languageHint) && readCache(chunkCache) != null) {
                            consumeChunk(offsetMs, chunkMs, null)
                        } else {
                            val wav = File.createTempFile("sonus_caption_", ".wav", appContext.cacheDir)
                            try {
                                onProgress(Progress("Preparando áudio para legenda…", progressAt(offsetMs, durationMs)))
                                AudioSegmentWavExtractor.extract(
                                    context = appContext,
                                    source = audioUri,
                                    startMs = startMs + offsetMs,
                                    durationMs = chunkMs,
                                    output = wav,
                                )
                                consumeChunk(offsetMs, chunkMs, wav)
                            } finally {
                                wav.delete()
                            }
                        }
                        if (offsetMs + chunkMs >= durationMs) break
                        offsetMs += (chunkMs - chunkOverlapMs).coerceAtLeast(1_000L)
                    }
                }

                onProgress(Progress("Finalizando legenda…", 99))
                val segments = merged
                    .sortedBy { it.startMs }
                    .deduplicateOverlap()
                    .normalizeCaptionGaps(durationMs)

                // Empty is a valid cached answer (instrumental/silence), avoiding repeated work.
                runCatching { cache.writeText(json.encodeToString(segments)) }
                onProgress(Progress(if (segments.isEmpty()) "Sem voz detectada" else "Letra sincronizada", 100))
                Result(
                    segments = segments,
                    processingMs = System.currentTimeMillis() - started,
                    fromCache = false,
                )
            } finally {
                // Never let Whisper compete with Media3 export for native memory.
                Whisper.releaseModel(model)
            }
        }
    }

    private suspend fun transcribeChunk(
        model: dev.ffmpegkit.whisper.WhisperModel,
        wav: File,
        threads: Int,
        language: String,
    ) = Whisper.transcribe(
        model = model,
        audioPath = wav.absolutePath,
        config = WhisperConfig(
            language = language,
            translate = false,
            threads = threads,
            maxSegmentLength = 64,
            printTimestamps = true,
        ),
    )

    private fun shouldProbePortuguese(text: String): Boolean {
        if (text.isBlank()) return false
        if (Locale.getDefault().language.equals("pt", ignoreCase = true)) return true
        return languageScore(text, PORTUGUESE_HINT_WORDS) >= PORTUGUESE_PROBE_THRESHOLD
    }

    private fun preferPortuguese(ptText: String, autoText: String): Boolean {
        if (ptText.isBlank()) return false
        val ptPortuguese = languageScore(ptText, PORTUGUESE_HINT_WORDS)
        val ptEnglish = languageScore(ptText, ENGLISH_HINT_WORDS)
        val autoPortuguese = languageScore(autoText, PORTUGUESE_HINT_WORDS)
        val accentedPortuguese = ptText.count { it.lowercaseChar() in PORTUGUESE_MARKS }

        // Require actual Portuguese evidence so an English song on a PT-BR phone can stay on auto.
        val hasPortugueseEvidence = ptPortuguese >= PORTUGUESE_LOCK_THRESHOLD || accentedPortuguese >= 2
        if (!hasPortugueseEvidence) return false
        if (ptEnglish > ptPortuguese + 0.05) return false
        return ptPortuguese + 0.02 >= autoPortuguese
    }

    private fun languageScore(text: String, dictionary: Set<String>): Double {
        val folded = Normalizer.normalize(text.lowercase(), Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
        val words = normalizeText(folded).split(' ').filter { it.length > 1 }
        if (words.isEmpty()) return 0.0
        val hits = words.count { it in dictionary }
        return hits.toDouble() / words.size.toDouble()
    }

    private suspend fun ensureModel(onProgress: (Progress) -> Unit): File = withContext(Dispatchers.IO) {
        val target = File(modelDir, MODEL_NAME)
        val verified = File(modelDir, "$MODEL_NAME.verified")
        if (target.exists() && target.length() >= MIN_MODEL_BYTES) {
            if ((verified.exists() && verified.readText().trim() == MODEL_SHA1) || sha1(target).equals(MODEL_SHA1, ignoreCase = true)) {
                if (!verified.exists()) runCatching { verified.writeText(MODEL_SHA1) }
                cleanupLegacyTinyModel()
                return@withContext target
            }
            target.delete()
            verified.delete()
        }

        val partial = File(modelDir, "$MODEL_NAME.part")
        partial.delete()
        onProgress(Progress("Conectando ao motor de legenda…"))
        val connection = (URI.create(MODEL_URL).toURL().openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 60_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "Sonus-Edit/1.0 Android")
        }
        try {
            connection.connect()
            if (connection.responseCode !in 200..299) {
                error("Não foi possível baixar o motor de legenda (${connection.responseCode}).")
            }
            val total = connection.contentLengthLong.takeIf { it > 0L }
            connection.inputStream.use { input ->
                partial.outputStream().buffered().use { output ->
                    val buffer = ByteArray(DEFAULT_BUFFER_SIZE * 4)
                    var copied = 0L
                    var lastPercent = -1
                    while (true) {
                        ensureActive()
                        val read = input.read(buffer)
                        if (read <= 0) break
                        output.write(buffer, 0, read)
                        copied += read
                        val percent = total?.let { ((copied * 100L) / it).toInt().coerceIn(0, 100) }
                        if (percent != null && percent != lastPercent) {
                            lastPercent = percent
                            onProgress(Progress("Baixando Whisper Small…", percent))
                        }
                    }
                }
            }
            require(partial.length() >= MIN_MODEL_BYTES) { "Download do motor de legenda ficou incompleto." }
            require(sha1(partial).equals(MODEL_SHA1, ignoreCase = true)) {
                "O motor de legenda baixado ficou corrompido. Tente novamente."
            }
            if (target.exists()) target.delete()
            check(partial.renameTo(target)) { "Não foi possível instalar o motor de legenda." }
            runCatching { verified.writeText(MODEL_SHA1) }
            cleanupLegacyTinyModel()
            onProgress(Progress("Whisper Small pronto", 100))
            target
        } finally {
            connection.disconnect()
            if (partial.exists() && (!target.exists() || target.length() < MIN_MODEL_BYTES)) partial.delete()
        }
    }

    private fun cleanupLegacyTinyModel() {
        runCatching { File(modelDir, "ggml-tiny.bin").delete() }
        runCatching { File(modelDir, "ggml-tiny.bin.verified").delete() }
        // Small replaces Base; reclaim storage only after the Small model was verified.
        runCatching { File(modelDir, "ggml-base.bin").delete() }
        runCatching { File(modelDir, "ggml-base.bin.verified").delete() }
    }

    private fun readCache(file: File): List<CaptionSegment>? = runCatching {
        if (!file.exists()) return@runCatching null
        json.decodeFromString<List<CaptionSegment>>(file.readText())
    }.getOrNull()

    private fun chunkCacheFile(uri: String, startMs: Long, durationMs: Long, languageHint: String?) : File {
        val raw = "chunk|${uri}|$startMs|$durationMs|$ENGINE_VERSION|$MODEL_SHA1|$languageHint"
        val key = MessageDigest.getInstance("SHA-256")
            .digest(raw.toByteArray())
            .joinToString("") { "%02x".format(it) }
        return File(cacheDir, "chunk_$key.json")
    }

    private fun cacheFile(uri: String, startMs: Long, durationMs: Long, languageHint: String?) : File {
        val raw = "${uri}|$startMs|$durationMs|$ENGINE_VERSION|$MODEL_SHA1|$languageHint"
        val key = MessageDigest.getInstance("SHA-256")
            .digest(raw.toByteArray())
            .joinToString("") { "%02x".format(it) }
        return File(cacheDir, "$key.json")
    }

    /** Cache also changes when a document URI points at updated audio bytes. */
    private fun audioIdentity(uri: Uri): String {
        if (uri.scheme == "file") {
            val file = File(uri.path.orEmpty())
            return "${uri}|${file.length()}|${file.lastModified()}"
        }
        if (uri.scheme == "content") {
            return runCatching {
                appContext.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    cursor.moveToFirst()
                    val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                    val changedIndex = cursor.getColumnIndex("last_modified")
                    val size = if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) cursor.getLong(sizeIndex) else -1L
                    val changed = if (changedIndex >= 0 && !cursor.isNull(changedIndex)) cursor.getLong(changedIndex) else -1L
                    "${uri}|$size|$changed"
                } ?: uri.toString()
            }.getOrDefault(uri.toString())
        }
        return uri.toString()
    }

    private fun languageCacheFile(uri: String, startMs: Long, durationMs: Long, hint: String?): File {
        val raw = "language|${uri}|$startMs|$durationMs|$ENGINE_VERSION|$MODEL_SHA1|$hint"
        val key = MessageDigest.getInstance("SHA-256").digest(raw.toByteArray()).joinToString("") { "%02x".format(it) }
        return File(cacheDir, "lang_$key.txt")
    }

    private fun projectLanguageExists(uri: String, startMs: Long, durationMs: Long, hint: String?): Boolean =
        languageCacheFile(uri, startMs, durationMs, hint).isFile

    private fun cleanCaption(value: String): String {
        val cleaned = value.replace(Regex("\\s+"), " ").trim()
        if (cleaned.matches(Regex("(?i)^\\[(music|música|musica|instrumental|applause|aplausos)]$"))) return ""
        if (cleaned.matches(Regex("(?i)^\\((music|música|musica|instrumental|applause|aplausos)\\)$"))) return ""
        return cleaned
    }

    private fun List<CaptionSegment>.deduplicateOverlap(): List<CaptionSegment> {
        if (size < 2) return this
        val result = mutableListOf<CaptionSegment>()
        for (segment in this) {
            val duplicateIndex = result.indexOfLast { previous ->
                kotlin.math.abs(previous.startMs - segment.startMs) <= DUPLICATE_TIME_WINDOW_MS &&
                    textEquivalent(previous.text, segment.text)
            }
            if (duplicateIndex < 0) {
                result += segment
            } else {
                val previous = result[duplicateIndex]
                val chosenText = if (segment.text.length > previous.text.length) segment.text else previous.text
                result[duplicateIndex] = CaptionSegment(
                    startMs = minOf(previous.startMs, segment.startMs),
                    endMs = maxOf(previous.endMs, segment.endMs),
                    text = chosenText,
                )
            }
        }
        return result.sortedBy { it.startMs }
    }

    private fun textEquivalent(a: String, b: String): Boolean {
        val left = normalizeText(a)
        val right = normalizeText(b)
        if (left.isBlank() || right.isBlank()) return false
        if (left == right || left.contains(right) || right.contains(left)) return true
        val leftWords = left.split(' ').filter { it.length > 1 }.toSet()
        val rightWords = right.split(' ').filter { it.length > 1 }.toSet()
        if (leftWords.isEmpty() || rightWords.isEmpty()) return false
        val intersection = leftWords.intersect(rightWords).size.toFloat()
        val union = leftWords.union(rightWords).size.toFloat().coerceAtLeast(1f)
        return intersection / union >= 0.78f
    }

    private fun normalizeText(value: String): String = value
        .lowercase()
        .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
        .trim()
        .replace(Regex("\\s+"), " ")

    private fun List<CaptionSegment>.normalizeCaptionGaps(durationMs: Long): List<CaptionSegment> {
        if (isEmpty()) return this
        return mapIndexedNotNull { index, item ->
            val safeStart = item.startMs.coerceIn(0L, durationMs)
            if (safeStart >= durationMs) return@mapIndexedNotNull null
            val nextStart = getOrNull(index + 1)?.startMs?.coerceIn(0L, durationMs)
            val desiredEnd = if (nextStart != null) minOf(item.endMs, nextStart) else minOf(item.endMs, durationMs)
            val safeEnd = desiredEnd.coerceAtLeast(safeStart + MIN_CAPTION_MS).coerceAtMost(durationMs)
            if (safeEnd <= safeStart) null else item.copy(startMs = safeStart, endMs = safeEnd)
        }
    }

    private fun progressAt(offsetMs: Long, durationMs: Long): Int? =
        if (durationMs <= CHUNK_MS) null else ((offsetMs * 100L) / durationMs).toInt().coerceIn(0, 98)

    private fun sha1(file: File): String {
        val digest = MessageDigest.getInstance("SHA-1")
        file.inputStream().buffered().use { input ->
            val buffer = ByteArray(DEFAULT_BUFFER_SIZE * 8)
            while (true) {
                val read = input.read(buffer)
                if (read <= 0) break
                digest.update(buffer, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    companion object {
        private const val ENGINE_VERSION = 11
        private const val CHUNK_MS = 24_000L
        private const val CHUNK_OVERLAP_MS = 3_000L
        private const val LONG_PROJECT_MS = 10L * 60_000L
        private const val LONG_CHUNK_MS = 45_000L
        private const val LONG_CHUNK_OVERLAP_MS = 1_500L
        private const val DUPLICATE_TIME_WINDOW_MS = 2_250L
        private const val MIN_CAPTION_MS = 120L
        private const val PORTUGUESE_PROBE_THRESHOLD = 0.10
        private const val PORTUGUESE_LOCK_THRESHOLD = 0.08
        private val PORTUGUESE_MARKS = setOf('á', 'à', 'â', 'ã', 'é', 'ê', 'í', 'ó', 'ô', 'õ', 'ú', 'ç')
        private val PORTUGUESE_HINT_WORDS = setOf(
            "que", "de", "do", "da", "dos", "das", "eu", "voce", "nao", "pra", "para",
            "meu", "minha", "uma", "um", "com", "sem", "por", "se", "me", "te", "em",
            "foi", "vai", "ela", "ele", "amor", "coracao", "aqui", "agora", "quando", "mais",
            "mas", "bem", "quem", "porque", "so", "sou", "estou", "tem", "toda", "todo"
        )
        private val ENGLISH_HINT_WORDS = setOf(
            "the", "and", "you", "your", "i", "me", "my", "we", "they", "is", "are", "was",
            "to", "of", "in", "on", "for", "with", "not", "love", "baby", "just", "know", "want",
            "need", "when", "where", "what", "why", "this", "that", "can", "will", "dont"
        )

        // Official multilingual Whisper Small GGML model. The SHA-1 is published by whisper.cpp.
        private const val MODEL_NAME = "ggml-small.bin"
        private const val MODEL_URL = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-small.bin"
        private const val MIN_MODEL_BYTES = 450L * 1024L * 1024L
        private const val MODEL_SHA1 = "55356645c2b361a969dfd0ef2c5a50d530afd8d5"
    }
}
