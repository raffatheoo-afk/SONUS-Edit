package com.sonusstudios.sonusedit.catalog

import android.content.Context
import java.io.File
import java.text.Normalizer
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

open class PCloudCatalogRepository(
    context: Context,
    private val publicCodes: List<String>,
    private val cacheName: String,
    private val client: PCloudPublicCatalogClient = PCloudPublicCatalogClient(),
    private val json: Json = Json { ignoreUnknownKeys = true },
) {
    constructor(
        context: Context,
        publicCode: String,
        cacheName: String,
        client: PCloudPublicCatalogClient = PCloudPublicCatalogClient(),
        json: Json = Json { ignoreUnknownKeys = true },
    ) : this(context, listOf(publicCode), cacheName, client, json)

    private val appContext = context.applicationContext
    private val cacheFile = File(appContext.filesDir, "catalog_$cacheName.json")
    private val searchRotationPrefs = appContext.getSharedPreferences("sonus_gallery_search_rotation", Context.MODE_PRIVATE)
    private val urlResolveSemaphore = Semaphore(6)
    private val downloadUrlCache = ConcurrentHashMap<String, String>()
    private val thumbnailUrlCache = ConcurrentHashMap<String, String>()

    private fun urlKey(asset: PCloudAsset): String =
        "${asset.sourcePublicCode ?: publicCodes.firstOrNull().orEmpty()}:${asset.fileId}"

    suspend fun cached(): List<PCloudAsset> = withContext(Dispatchers.IO) {
        runCatching {
            if (!cacheFile.exists()) return@runCatching emptyList()
            json.decodeFromString<CatalogSnapshot>(cacheFile.readText()).assets
        }.getOrDefault(emptyList())
    }

    suspend fun refresh(): List<PCloudAsset> = refreshProgressively { }

    /**
     * Fetches configured public folders concurrently and publishes the growing catalogue as each
     * folder responds. A failed folder retains its cached entries; a successful empty folder clears
     * only that folder. The final snapshot is persisted once all sources have reported.
     */
    suspend fun refreshProgressively(onPartial: suspend (List<PCloudAsset>) -> Unit): List<PCloudAsset> = coroutineScope {
        val previous = cached()
        val channel = Channel<Pair<String, List<PCloudAsset>?>>(Channel.UNLIMITED)
        publicCodes.forEach { code ->
            launch(Dispatchers.IO) {
                val assets = runCatching { client.listAssetsOrNull(code) }.getOrNull()
                channel.send(code to assets)
            }
        }

        val mergedByCode = previous.groupBy { it.sourcePublicCode.orEmpty() }.toMutableMap()
        var successfulSources = 0
        repeat(publicCodes.size) {
            val (code, assets) = channel.receive()
            if (assets != null) {
                successfulSources++
                mergedByCode[code] = assets
            }
            val partial = publicCodes.flatMap { source ->
                mergedByCode[source].orEmpty()
            }.distinctBy { it.stableKey }
            onPartial(partial)
        }
        channel.close()

        val fresh = publicCodes.flatMap { code -> mergedByCode[code].orEmpty() }
            .distinctBy { it.stableKey }
        if (successfulSources > 0) {
            withContext(Dispatchers.IO) {
                runCatching { cacheFile.writeText(json.encodeToString(CatalogSnapshot(System.currentTimeMillis(), fresh))) }
            }
            lastSuccessfulRefresh[cacheName] = System.currentTimeMillis()
            fresh
        } else previous
    }

    /**
     * Search refresh is deliberately cache-first and sequential. It rotates the first source,
     * skips folders known to contain no image/video assets, and only falls through when the
     * selected source has no match for the current query. This avoids spending three quotas on
     * every search while keeping a fallback path when a folder has no matching media.
     */
    suspend fun refreshSearchProgressively(
        query: String,
        mediaExtensions: Set<String>,
        onPartial: suspend (List<PCloudAsset>) -> Unit,
    ): List<PCloudAsset> = coroutineScope {
        val previous = cached()
        onPartial(previous)
        val normalizedExtensions = mediaExtensions.map { it.lowercase() }.toSet()
        val mediaPrevious = previous.filter { it.extension in normalizedExtensions }
        val terms = normalizeSearchText(query).split(' ').filter { it.isNotBlank() }

        // Only skip a source after a successful response proved that it has no supported media.
        // A source absent from an old/partial cache is unknown, not necessarily empty.
        fun hasCachedMedia(code: String) = mediaPrevious.any { it.sourcePublicCode == code }
        fun knownPresence(code: String): Boolean? = searchRotationPrefs.getString(
            "media_${cacheName}_${mediaExtensions.sorted().joinToString("-")}_$code", null,
        )?.toBooleanStrictOrNull()

        val availableCodes = publicCodes.filter { code ->
            hasCachedMedia(code) || knownPresence(code) != false
        }
        if (availableCodes.isEmpty() || terms.isEmpty()) return@coroutineScope previous

        val cachedHasMatch = mediaPrevious.any { asset ->
            val text = normalizeSearchText("${asset.name} ${asset.folderPath}")
            terms.all { term -> text.contains(term) }
        }
        val rotationKey = "next_$cacheName"
        val next = searchRotationPrefs.getInt(rotationKey, 0)
        if (cachedHasMatch) {
            // The local match is immediate. Rotate the next cold search across eligible folders.
            searchRotationPrefs.edit().putInt(rotationKey, GallerySearchRotation.nextIndex(next, availableCodes.size)).apply()
            return@coroutineScope previous
        }

        // Search available folders concurrently instead of serially. A cold query previously
        // waited for server 1, then 2, then 3 (up to ~20–30 seconds). Each source now publishes
        // as soon as it responds; the overall wait is bounded by the slowest eligible source.
        // Starting order rotates between queries, keeping the request pattern balanced.
        val ordered = GallerySearchRotation.order(availableCodes, next)
        val mergedByCode = previous.groupBy { it.sourcePublicCode.orEmpty() }.toMutableMap()
        val channel = Channel<Pair<String, List<PCloudAsset>?>>(Channel.UNLIMITED)
        val jobs = ordered.map { code ->
            launch(Dispatchers.IO) {
                val assets = runCatching { client.listAssetsOrNull(code) }.getOrNull()
                channel.send(code to assets)
            }
        }
        var anySuccess = false
        repeat(ordered.size) {
            val (code, assets) = channel.receive()
            if (assets != null) {
                anySuccess = true
                val hasMedia = assets.any { it.extension.lowercase() in normalizedExtensions }
                searchRotationPrefs.edit().putString(
                    "media_${cacheName}_${mediaExtensions.sorted().joinToString("-")}_$code", hasMedia.toString(),
                ).apply()
                mergedByCode[code] = assets
                val partial = publicCodes.flatMap { mergedByCode[it].orEmpty() }
                    .distinctBy { it.stableKey }
                onPartial(partial)
            }
        }
        jobs.forEach { it.join() }
        channel.close()
        searchRotationPrefs.edit().putInt(rotationKey, GallerySearchRotation.nextIndex(next, availableCodes.size)).apply()

        val fresh = publicCodes.flatMap { mergedByCode[it].orEmpty() }.distinctBy { it.stableKey }
        if (anySuccess) {
            withContext(Dispatchers.IO) {
                runCatching { cacheFile.writeText(json.encodeToString(CatalogSnapshot(System.currentTimeMillis(), fresh))) }
            }
            lastSuccessfulRefresh[cacheName] = System.currentTimeMillis()
            fresh
        } else previous
    }

    private fun normalizeSearchText(value: String): String = Normalizer.normalize(value, Normalizer.Form.NFD)
        .replace(Regex("\\p{Mn}+"), "")
        .lowercase()
        .replace(Regex("[^a-z0-9]+"), " ")
        .trim()

    /** Avoid repeating the same network refresh while still publishing the cache immediately. */
    suspend fun refreshIfStale(maxAgeMs: Long = 45_000L): List<PCloudAsset> {
        val last = lastSuccessfulRefresh[cacheName] ?: 0L
        return if (System.currentTimeMillis() - last < maxAgeMs) cached() else refresh()
    }

    suspend fun refreshIfStaleProgressively(
        maxAgeMs: Long = 45_000L,
        onPartial: suspend (List<PCloudAsset>) -> Unit,
    ): List<PCloudAsset> {
        val last = lastSuccessfulRefresh[cacheName] ?: 0L
        return if (System.currentTimeMillis() - last < maxAgeMs) cached() else refreshProgressively(onPartial)
    }

    suspend fun downloadUrl(asset: PCloudAsset): String? {
        val code = asset.sourcePublicCode ?: publicCodes.firstOrNull() ?: return null
        val key = urlKey(asset)
        downloadUrlCache[key]?.let { return it }
        return urlResolveSemaphore.withPermit {
            downloadUrlCache[key]?.let { return@withPermit it }
            client.resolveDownloadUrl(code, asset.fileId)?.also { downloadUrlCache[key] = it }
        }
    }

    suspend fun thumbnailUrl(asset: PCloudAsset): String? {
        val code = asset.sourcePublicCode ?: publicCodes.firstOrNull() ?: return null
        val key = urlKey(asset)
        thumbnailUrlCache[key]?.let { return it }
        return urlResolveSemaphore.withPermit {
            thumbnailUrlCache[key]?.let { return@withPermit it }
            client.resolveThumbnailUrl(code, asset.fileId)?.also { thumbnailUrlCache[key] = it }
        }
    }

    companion object {
        private val lastSuccessfulRefresh = ConcurrentHashMap<String, Long>()
    }
}

class PCloudMusicRepository(context: Context) : PCloudCatalogRepository(
    context = context,
    publicCodes = SonusPublicCatalogs.MUSIC_PUBLIC_CODES,
    cacheName = "music",
)

class PCloudImageRepository(context: Context) : PCloudCatalogRepository(
    context = context,
    publicCodes = SonusPublicCatalogs.IMAGE_PUBLIC_CODES,
    cacheName = "images",
)

class PCloudHorizontalImageRepository(context: Context) : PCloudCatalogRepository(
    context = context,
    publicCodes = SonusPublicCatalogs.IMAGE_HORIZONTAL_PUBLIC_CODES,
    cacheName = "images_horizontal",
)
