package com.sonusstudios.sonusedit.catalog

import android.content.Context
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

open class PCloudCatalogRepository(
    context: Context,
    private val publicCodes: List<String>,
    private val cacheName: String,
    private val client: PCloudPublicCatalogClient = PCloudPublicCatalogClient(),
    private val json: Json = Json { ignoreUnknownKeys = true },
) {
    constructor(
        context: Context,
        publicCode: String,
        cacheName: String,
        client: PCloudPublicCatalogClient = PCloudPublicCatalogClient(),
        json: Json = Json { ignoreUnknownKeys = true },
    ) : this(context, listOf(publicCode), cacheName, client, json)

    private val cacheFile = File(context.filesDir, "catalog_$cacheName.json")
    private val urlResolveSemaphore = Semaphore(6)
    private val downloadUrlCache = ConcurrentHashMap<String, String>()
    private val thumbnailUrlCache = ConcurrentHashMap<String, String>()

    private fun urlKey(asset: PCloudAsset): String =
        "${asset.sourcePublicCode ?: publicCodes.firstOrNull().orEmpty()}:${asset.fileId}"

    suspend fun cached(): List<PCloudAsset> = withContext(Dispatchers.IO) {
        runCatching {
            if (!cacheFile.exists()) return@runCatching emptyList()
            json.decodeFromString<CatalogSnapshot>(cacheFile.readText()).assets
        }.getOrDefault(emptyList())
    }

    suspend fun refresh(): List<PCloudAsset> = refreshProgressively { }

    /**
     * Fetches configured public folders concurrently and publishes the growing catalogue as each
     * folder responds. A failed folder retains its cached entries; a successful empty folder clears
     * only that folder. The final snapshot is persisted once all sources have reported.
     */
    suspend fun refreshProgressively(onPartial: suspend (List<PCloudAsset>) -> Unit): List<PCloudAsset> = coroutineScope {
        val previous = cached()
        val channel = Channel<Pair<String, List<PCloudAsset>?>>(Channel.UNLIMITED)
        publicCodes.forEach { code ->
            launch(Dispatchers.IO) {
                val assets = runCatching { client.listAssetsOrNull(code) }.getOrNull()
                channel.send(code to assets)
            }
        }

        val mergedByCode = previous.groupBy { it.sourcePublicCode.orEmpty() }.toMutableMap()
        var successfulSources = 0
        repeat(publicCodes.size) {
            val (code, assets) = channel.receive()
            if (assets != null) {
                successfulSources++
                mergedByCode[code] = assets
            }
            val partial = publicCodes.flatMap { source ->
                mergedByCode[source].orEmpty()
            }.distinctBy { it.stableKey }
            onPartial(partial)
        }
        channel.close()

        val fresh = publicCodes.flatMap { code -> mergedByCode[code].orEmpty() }
            .distinctBy { it.stableKey }
        if (successfulSources > 0) {
            withContext(Dispatchers.IO) {
                runCatching { cacheFile.writeText(json.encodeToString(CatalogSnapshot(System.currentTimeMillis(), fresh))) }
            }
            lastSuccessfulRefresh[cacheName] = System.currentTimeMillis()
            fresh
        } else previous
    }

    /** Avoid repeating the same network refresh while still publishing the cache immediately. */
    suspend fun refreshIfStale(maxAgeMs: Long = 45_000L): List<PCloudAsset> {
        val last = lastSuccessfulRefresh[cacheName] ?: 0L
        return if (System.currentTimeMillis() - last < maxAgeMs) cached() else refresh()
    }

    suspend fun refreshIfStaleProgressively(
        maxAgeMs: Long = 45_000L,
        onPartial: suspend (List<PCloudAsset>) -> Unit,
    ): List<PCloudAsset> {
        val last = lastSuccessfulRefresh[cacheName] ?: 0L
        return if (System.currentTimeMillis() - last < maxAgeMs) cached() else refreshProgressively(onPartial)
    }

    suspend fun downloadUrl(asset: PCloudAsset): String? {
        val code = asset.sourcePublicCode ?: publicCodes.firstOrNull() ?: return null
        val key = urlKey(asset)
        downloadUrlCache[key]?.let { return it }
        return urlResolveSemaphore.withPermit {
            downloadUrlCache[key]?.let { return@withPermit it }
            client.resolveDownloadUrl(code, asset.fileId)?.also { downloadUrlCache[key] = it }
        }
    }

    suspend fun thumbnailUrl(asset: PCloudAsset): String? {
        val code = asset.sourcePublicCode ?: publicCodes.firstOrNull() ?: return null
        val key = urlKey(asset)
        thumbnailUrlCache[key]?.let { return it }
        return urlResolveSemaphore.withPermit {
            thumbnailUrlCache[key]?.let { return@withPermit it }
            client.resolveThumbnailUrl(code, asset.fileId)?.also { thumbnailUrlCache[key] = it }
        }
    }

    companion object {
        private val lastSuccessfulRefresh = ConcurrentHashMap<String, Long>()
    }
}

class PCloudMusicRepository(context: Context) : PCloudCatalogRepository(
    context = context,
    publicCodes = SonusPublicCatalogs.MUSIC_PUBLIC_CODES,
    cacheName = "music",
)

class PCloudImageRepository(context: Context) : PCloudCatalogRepository(
    context = context,
    publicCodes = SonusPublicCatalogs.IMAGE_PUBLIC_CODES,
    cacheName = "images",
)

class PCloudHorizontalImageRepository(context: Context) : PCloudCatalogRepository(
    context = context,
    publicCodes = SonusPublicCatalogs.IMAGE_HORIZONTAL_PUBLIC_CODES,
    cacheName = "images_horizontal",
)
