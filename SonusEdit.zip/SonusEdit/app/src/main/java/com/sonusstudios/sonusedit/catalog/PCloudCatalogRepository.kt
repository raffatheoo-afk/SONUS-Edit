package com.sonusstudios.sonusedit.catalog

import android.content.Context
import java.io.File
import java.text.Normalizer
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

open class PCloudCatalogRepository(
    context: Context,
    private val publicCodes: List<String>,
    private val cacheName: String,
    private val client: PCloudPublicCatalogClient = PCloudPublicCatalogClient(),
    private val json: Json = Json { ignoreUnknownKeys = true },
) {
    constructor(
        context: Context,
        publicCode: String,
        cacheName: String,
        client: PCloudPublicCatalogClient = PCloudPublicCatalogClient(),
        json: Json = Json { ignoreUnknownKeys = true },
    ) : this(context, listOf(publicCode), cacheName, client, json)

    private val appContext = context.applicationContext
    private val cacheFile = File(appContext.filesDir, "catalog_$cacheName.json")
    private val searchRotationPrefs = appContext.getSharedPreferences("sonus_gallery_search_rotation", Context.MODE_PRIVATE)
    private val urlResolveSemaphore = Semaphore(6)
    private data class CachedUrl(val value: String, val resolvedAtMs: Long)
    private val downloadUrlCache = ConcurrentHashMap<String, CachedUrl>()
    private val thumbnailUrlCache = ConcurrentHashMap<String, CachedUrl>()
    private val urlCacheTtlMs = 50L * 60_000L

    private fun urlKey(asset: PCloudAsset): String =
        "${asset.sourcePublicCode ?: publicCodes.firstOrNull().orEmpty()}:${asset.fileId}"

    suspend fun cached(): List<PCloudAsset> = withContext(Dispatchers.IO) {
        runCatching {
            if (!cacheFile.exists()) return@runCatching emptyList()
            json.decodeFromString<CatalogSnapshot>(cacheFile.readText()).assets
        }.getOrDefault(emptyList())
    }

    suspend fun refresh(): List<PCloudAsset> = refreshProgressively { }

    /**
     * Fetches configured public folders concurrently and publishes the growing catalogue as each
     * folder responds. A failed folder retains its cached entries; a successful empty folder clears
     * only that folder. The final snapshot is persisted once all sources have reported.
     */
    suspend fun refreshProgressively(onPartial: suspend (List<PCloudAsset>) -> Unit): List<PCloudAsset> = coroutineScope {
        val previous = cached()
        val channel = Channel<Pair<String, List<PCloudAsset>?>>(Channel.UNLIMITED)
        publicCodes.forEach { code ->
            launch(Dispatchers.IO) {
                val assets = runCatching { client.listAssetsOrNull(code) }.getOrNull()
                channel.send(code to assets)
            }
        }

        val mergedByCode = previous.groupBy { it.sourcePublicCode.orEmpty() }.toMutableMap()
        var successfulSources = 0
        repeat(publicCodes.size) {
            val (code, assets) = channel.receive()
            if (assets != null) {
                successfulSources++
                mergedByCode[code] = assets
            }
            val partial = publicCodes.flatMap { source ->
                mergedByCode[source].orEmpty()
            }.distinctBy { it.stableKey }
            onPartial(partial)
        }
        channel.close()

        val fresh = publicCodes.flatMap { code -> mergedByCode[code].orEmpty() }
            .distinctBy { it.stableKey }
        if (successfulSources > 0) {
            withContext(Dispatchers.IO) {
                runCatching { cacheFile.writeText(json.encodeToString(CatalogSnapshot(System.currentTimeMillis(), fresh))) }
            }
            lastSuccessfulRefresh[cacheName] = System.currentTimeMillis()
            fresh
        } else previous
    }

    /**
     * Search is cache-first, but only skips network work when the cache already contains enough
     * exact-query, unblocked matches using the same matcher as the visible gallery. Otherwise all
     * eligible sources are queried progressively so blocked cache hits cannot hide fresh assets.
     */
    suspend fun refreshSearchProgressively(
        query: String,
        mediaExtensions: Set<String>,
        blockedKeys: Set<String> = emptySet(),
        minimumFreshMatches: Int = 11,
        onPartial: suspend (List<PCloudAsset>) -> Unit,
    ): List<PCloudAsset> = coroutineScope {
        val previous = cached()
        onPartial(previous)
        val normalizedExtensions = mediaExtensions.map { it.lowercase() }.toSet()
        val mediaPrevious = previous.filter { it.extension.lowercase() in normalizedExtensions }
        val normalizedQuery = normalizeSearchText(query)

        // A source previously marked as empty may receive new files later. For an explicit
        // search with fewer than 11 fresh cache hits, query every configured source; old
        // "empty folder" flags must never hide newly uploaded images indefinitely.
        val availableCodes = publicCodes
        if (availableCodes.isEmpty() || normalizedQuery.isBlank()) return@coroutineScope previous

        // Use the exact same token/boundary matcher as the visible manual gallery. A loose
        // substring count can overestimate usable results (for example, "amor" inside
        // "amores"), incorrectly skip other pCloud folders, and make a populated search look empty.
        val hasEnoughCachedMatches = PCloudSearchCachePolicy.hasEnoughFreshMatches(
            assets = mediaPrevious,
            query = query,
            mediaExtensions = normalizedExtensions,
            blockedKeys = blockedKeys,
            minimumFreshMatches = minimumFreshMatches,
        )
        val rotationKey = "next_$cacheName"
        val next = searchRotationPrefs.getInt(rotationKey, 0)
        if (hasEnoughCachedMatches) {
            // The cache already contains enough usable images for this exact query. If every
            // matching cached image is protected, or only a handful remain, search all folders.
            searchRotationPrefs.edit().putInt(rotationKey, GallerySearchRotation.nextIndex(next, availableCodes.size)).apply()
            return@coroutineScope previous
        }

        // Search available folders concurrently instead of serially. A cold query previously
        // waited for server 1, then 2, then 3 (up to ~20–30 seconds). Each source now publishes
        // as soon as it responds; the overall wait is bounded by the slowest eligible source.
        // Starting order rotates between queries, keeping the request pattern balanced.
        val ordered = GallerySearchRotation.order(availableCodes, next)
        val mergedByCode = previous.groupBy { it.sourcePublicCode.orEmpty() }.toMutableMap()
        val channel = Channel<Pair<String, List<PCloudAsset>?>>(Channel.UNLIMITED)
        val jobs = ordered.map { code ->
            launch(Dispatchers.IO) {
                val assets = runCatching { client.listAssetsOrNull(code) }.getOrNull()
                channel.send(code to assets)
            }
        }
        var anySuccess = false
        repeat(ordered.size) {
            val (code, assets) = channel.receive()
            if (assets != null) {
                anySuccess = true
                mergedByCode[code] = assets
                val partial = publicCodes.flatMap { mergedByCode[it].orEmpty() }
                    .distinctBy { it.stableKey }
                onPartial(partial)
            }
        }
        jobs.forEach { it.join() }
        channel.close()
        searchRotationPrefs.edit().putInt(rotationKey, GallerySearchRotation.nextIndex(next, availableCodes.size)).apply()

        val fresh = publicCodes.flatMap { mergedByCode[it].orEmpty() }.distinctBy { it.stableKey }
        if (anySuccess) {
            withContext(Dispatchers.IO) {
                runCatching { cacheFile.writeText(json.encodeToString(CatalogSnapshot(System.currentTimeMillis(), fresh))) }
            }
            lastSuccessfulRefresh[cacheName] = System.currentTimeMillis()
            fresh
        } else previous
    }

    private fun normalizeSearchText(value: String): String = Normalizer.normalize(value, Normalizer.Form.NFD)
        .replace(Regex("\\p{Mn}+"), "")
        .lowercase()
        .replace(Regex("[^a-z0-9]+"), " ")
        .trim()

    /** Avoid repeating the same network refresh while still publishing the cache immediately. */
    suspend fun refreshIfStale(maxAgeMs: Long = 45_000L): List<PCloudAsset> {
        val last = lastSuccessfulRefresh[cacheName] ?: 0L
        return if (System.currentTimeMillis() - last < maxAgeMs) cached() else refresh()
    }

    suspend fun refreshIfStaleProgressively(
        maxAgeMs: Long = 45_000L,
        onPartial: suspend (List<PCloudAsset>) -> Unit,
    ): List<PCloudAsset> {
        val last = lastSuccessfulRefresh[cacheName] ?: 0L
        return if (System.currentTimeMillis() - last < maxAgeMs) cached() else refreshProgressively(onPartial)
    }

    suspend fun downloadUrl(asset: PCloudAsset): String? {
        val code = asset.sourcePublicCode ?: publicCodes.firstOrNull() ?: return null
        val key = urlKey(asset)
        downloadUrlCache[key]?.takeIf { System.currentTimeMillis() - it.resolvedAtMs < urlCacheTtlMs }?.let { return it.value }
        return urlResolveSemaphore.withPermit {
            downloadUrlCache[key]?.takeIf { System.currentTimeMillis() - it.resolvedAtMs < urlCacheTtlMs }?.let { return@withPermit it.value }
            client.resolveDownloadUrl(code, asset.fileId)?.also { downloadUrlCache[key] = CachedUrl(it, System.currentTimeMillis()) }
        }
    }

    suspend fun thumbnailUrl(asset: PCloudAsset): String? {
        val code = asset.sourcePublicCode ?: publicCodes.firstOrNull() ?: return null
        val key = urlKey(asset)
        thumbnailUrlCache[key]?.takeIf { System.currentTimeMillis() - it.resolvedAtMs < urlCacheTtlMs }?.let { return it.value }
        return urlResolveSemaphore.withPermit {
            thumbnailUrlCache[key]?.takeIf { System.currentTimeMillis() - it.resolvedAtMs < urlCacheTtlMs }?.let { return@withPermit it.value }
            client.resolveThumbnailUrl(code, asset.fileId)?.also { thumbnailUrlCache[key] = CachedUrl(it, System.currentTimeMillis()) }
        }
    }

    fun invalidateDownloadUrl(asset: PCloudAsset) { downloadUrlCache.remove(urlKey(asset)) }
    fun invalidateThumbnailUrl(asset: PCloudAsset) { thumbnailUrlCache.remove(urlKey(asset)) }

    companion object {
        private val lastSuccessfulRefresh = ConcurrentHashMap<String, Long>()
    }
}

class PCloudMusicRepository(context: Context) : PCloudCatalogRepository(
    context = context,
    publicCodes = SonusPublicCatalogs.MUSIC_PUBLIC_CODES,
    cacheName = "music",
)

class PCloudImageRepository(context: Context) : PCloudCatalogRepository(
    context = context,
    publicCodes = SonusPublicCatalogs.IMAGE_PUBLIC_CODES,
    cacheName = "images",
)

class PCloudHorizontalImageRepository(context: Context) : PCloudCatalogRepository(
    context = context,
    publicCodes = SonusPublicCatalogs.IMAGE_HORIZONTAL_PUBLIC_CODES,
    cacheName = "images_horizontal",
)
