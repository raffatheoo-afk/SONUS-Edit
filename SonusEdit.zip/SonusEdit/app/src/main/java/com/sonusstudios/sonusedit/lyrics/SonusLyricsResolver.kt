package com.sonusstudios.sonusedit.lyrics

import java.net.HttpURLConnection
import java.net.URI
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

/** Same public synchronized-lyrics source used by the SONUS Stream player. */
interface SonusLyricsResolver {
    suspend fun syncedLyrics(trackId: String): String?
}

/**
 * SONUS stores sanitized Stream metadata/lyrics in Firebase RTDB under:
 * publicConfig/sonusMusic/trackOverrides/{fileId}.
 *
 * This resolver reads only that public node. No admin token, password or private Firebase
 * credential is bundled in Sonus Edit.
 */
class FirebaseSonusLyricsResolver(
    private val json: Json = Json { ignoreUnknownKeys = true },
) : SonusLyricsResolver {
    private val cache = ConcurrentHashMap<String, String>()
    private val root = "https://streenpulse-default-rtdb.firebaseio.com/publicConfig/sonusMusic/trackOverrides"

    override suspend fun syncedLyrics(trackId: String): String? {
        cache[trackId]?.let { return it.takeIf(String::isNotBlank) }
        if (!trackId.all(Char::isDigit)) return null
        val value = withContext(Dispatchers.IO) {
            val connection = (URI.create("$root/$trackId.json").toURL().openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 5_000
                readTimeout = 7_000
                setRequestProperty("Accept", "application/json")
                setRequestProperty("User-Agent", "Sonus-Edit/0.0.7 Android")
            }
            try {
                if (connection.responseCode != HttpURLConnection.HTTP_OK) return@withContext null
                val body = connection.inputStream.bufferedReader().use { it.readText() }
                if (body == "null" || body.isBlank()) return@withContext null
                val obj = runCatching { json.parseToJsonElement(body).jsonObject }.getOrNull() ?: return@withContext null
                val lyrics = obj["lyrics"]?.jsonPrimitive?.content.orEmpty().trim()
                val format = obj["lyricsFormat"]?.jsonPrimitive?.content.orEmpty().uppercase()
                lyrics.takeIf { candidate ->
                    candidate.isNotBlank() && (format == "LRC" || LRC_TIMESTAMP.containsMatchIn(candidate))
                }
            } finally {
                connection.disconnect()
            }
        }
        cache[trackId] = value.orEmpty()
        return value
    }

    private companion object {
        val LRC_TIMESTAMP = Regex("\\[\\d{1,2}:\\d{2}(?:[.,:]\\d{1,3})?]")
    }
}

class LyricsRepository(
    private val sonus: SonusLyricsResolver,
    private val external: LyricsProvider,
) {
    suspend fun forSonusTrack(trackId: String): String? = sonus.syncedLyrics(trackId)

    suspend fun forExternalTrack(metadata: LyricsMetadata): String? =
        external.bestMatch(metadata)?.syncedLyrics
}
