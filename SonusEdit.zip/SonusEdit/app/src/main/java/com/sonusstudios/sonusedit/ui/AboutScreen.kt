package com.sonusstudios.sonusedit.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonusstudios.sonusedit.designsystem.SonusEditColors

@Composable
fun AboutScreen(onBack: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(SonusEditColors.Black)
            .verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(13.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar", tint = Color.White)
            }
            Column(Modifier.weight(1f)) {
                Text("Sobre o Sonus Edit", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
                Text("Versão atual e informações do aplicativo", color = SonusEditColors.TextMuted, fontSize = 10.sp)
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = Color.Transparent),
            shape = RoundedCornerShape(22.dp),
        ) {
            Column(
                Modifier.fillMaxWidth().background(
                    Brush.linearGradient(listOf(Color(0xFF302064), Color(0xFF17445C), Color(0xFF14283B)))
                ).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AutoAwesome, null, tint = Color(0xFF8FE6FF))
                    Text("  SONUS EDIT", color = Color.White, fontWeight = FontWeight.Black, fontSize = 12.sp)
                }
                Text("Versão 1.0.1", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
                Text("CODE 11 • Atualização Sonus Edit", color = Color(0xFFD7E6F3), fontSize = 10.sp)
            }
        }

        ReleaseCard(
            version = "1.0.1 • CODE 11",
            items = listOf(
                "Catálogo de fontes ampliado com cinco famílias adicionais aprovadas para redistribuição e com cobertura dos principais caracteres portugueses.",
                "Bloqueio de imagens recentes independente por formato: últimos 20 projetos 9:16 e 15 projetos 16:9, com opção para ativar ou desativar nos Ajustes.",
                "Ajustes reorganizados por categoria, com automações individuais e sem o controle mestre de Automação Total.",
                "Painel de estatísticas refinado para destacar produtividade, exportações e uso dos recursos.",
                "Tela inicial renovada com cartões coloridos, botões em degradê, logotipo sem placa preta e detalhes luminosos na coroa e no destaque principal."
            ),
        )

        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF151D2B)),
            shape = RoundedCornerShape(16.dp),
        ) {
            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.Top) {
                Icon(Icons.Default.Info, null, tint = SonusEditColors.Cyan)
                Text(
                    "Os recursos de planos ainda estão em preparação. Todos os recursos continuam liberados durante esta etapa; não há cobrança nem bloqueio por plano.",
                    Modifier.padding(start = 10.dp), color = SonusEditColors.TextMuted, fontSize = 10.sp, lineHeight = 15.sp,
                )
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun ReleaseCard(version: String, items: List<String>) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SonusEditColors.Surface),
        shape = RoundedCornerShape(20.dp),
    ) {
        Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text(version, color = SonusEditColors.Cyan, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
            items.forEach { item ->
                Row(verticalAlignment = Alignment.Top) {
                    Text("•", color = Color(0xFF8CE5FF), fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                    Text(item, Modifier.padding(start = 8.dp), color = Color.White, fontSize = 10.sp, lineHeight = 15.sp)
                }
            }
        }
    }
}
