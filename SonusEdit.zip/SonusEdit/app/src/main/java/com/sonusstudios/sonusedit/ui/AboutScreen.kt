package com.sonusstudios.sonusedit.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonusstudios.sonusedit.designsystem.SonusEditColors

@Composable
fun AboutScreen(onBack: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(SonusEditColors.Black)
            .verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(13.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar", tint = Color.White)
            }
            Column(Modifier.weight(1f)) {
                Text("Sobre o Sonus Edit", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
                Text("Versão atual e informações do aplicativo", color = SonusEditColors.TextMuted, fontSize = 10.sp)
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = Color.Transparent),
            shape = RoundedCornerShape(22.dp),
        ) {
            Column(
                Modifier.fillMaxWidth().background(
                    Brush.linearGradient(listOf(Color(0xFF302064), Color(0xFF17445C), Color(0xFF14283B)))
                ).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AutoAwesome, null, tint = Color(0xFF8FE6FF))
                    Text("  SONUS EDIT", color = Color.White, fontWeight = FontWeight.Black, fontSize = 12.sp)
                }
                Text("Versão 1.0.7", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
                Text("CODE 17 • SONUS Link Engine", color = Color(0xFFD7E6F3), fontSize = 10.sp)
            }
        }

        ReleaseCard(
            version = "1.0.7 • CODE 17",
            items = listOf(
                "SONUS Link Engine: o importador foi refeito em Kotlin, sem empacotar yt-dlp, Python, QuickJS ou o módulo FFmpeg do antigo importador no APK.",
                "Links diretos autorizados: transferência em fluxo com progresso, cancelamento, verificação de resposta e armazenamento temporário; arquivos de áudio e vídeos com faixa de áudio são aceitos quando servidos diretamente.",
                "OpenDownloader: encaminhamento opcional ao site oficial pelo navegador, com o link copiado automaticamente; o arquivo baixado pode ser compartilhado de volta ao SONUS EDIT.",
                "Compatibilidade web: o site informa suporte a links colados de YouTube, X e Twitch; TikTok, Instagram e Facebook exigem a extensão de navegador para computador, não disponível neste fluxo Android.",
                "Privacidade e acesso: o processamento ocorre no navegador/relay do OpenDownloader conforme o próprio serviço; o SONUS não contorna login, DRM, criptografia ou controles de acesso.",
                "Qualidade: o arquivo original é preservado, sem transcodificação automática ou conversão AAC com perda.",
                "Sem servidor SONUS: este encaminhamento não exige VPS, chave de API ou créditos. O download é concluído no navegador e o retorno ao editor é feito pelo compartilhamento nativo do Android.",
                "Limpeza: arquivos temporários antigos são removidos automaticamente; o arquivo importado é excluído pelo fluxo de exportação já existente.",
                "Preservações: applicationId, assinatura persistente, interface, galeria pCloud, fontes de música, Whisper Small, transições, filtros, rascunhos e exportação."
            ),
        )

        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF151D2B)),
            shape = RoundedCornerShape(16.dp),
        ) {
            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.Top) {
                Icon(Icons.Default.Info, null, tint = SonusEditColors.Cyan)
                Text(
                    "Os recursos de planos ainda estão em preparação. Todos os recursos continuam liberados durante esta etapa; não há cobrança nem bloqueio por plano.",
                    Modifier.padding(start = 10.dp), color = SonusEditColors.TextMuted, fontSize = 10.sp, lineHeight = 15.sp,
                )
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun ReleaseCard(version: String, items: List<String>) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SonusEditColors.Surface),
        shape = RoundedCornerShape(20.dp),
    ) {
        Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text(version, color = SonusEditColors.Cyan, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
            items.forEach { item ->
                Row(verticalAlignment = Alignment.Top) {
                    Text("•", color = Color(0xFF8CE5FF), fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                    Text(item, Modifier.padding(start = 8.dp), color = Color.White, fontSize = 10.sp, lineHeight = 15.sp)
                }
            }
        }
    }
}
