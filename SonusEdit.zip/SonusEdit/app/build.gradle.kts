plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("org.jetbrains.kotlin.plugin.serialization")
}

android {
    namespace = "com.sonusstudios.sonusedit"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.sonusstudios.sonusedit"
        minSdk = 26
        targetSdk = 36
        versionCode = 7
        versionName = "0.0.7"
    }

    // Persistent signing: Codemagic may provide a secure keystore through environment
    // variables. The Codemagic workflow MUST provide the same persistent signer used by code03;
    // it intentionally fails rather than silently creating a different key.
    val secureKeystorePath = System.getenv("SONUS_KEYSTORE_PATH")
    val secureKeystorePassword = System.getenv("SONUS_KEYSTORE_PASSWORD")
    val secureKeyAlias = System.getenv("SONUS_KEY_ALIAS")
    val secureKeyPassword = System.getenv("SONUS_KEY_PASSWORD")

    signingConfigs {
        if (!secureKeystorePath.isNullOrBlank() && !secureKeystorePassword.isNullOrBlank() &&
            !secureKeyAlias.isNullOrBlank() && !secureKeyPassword.isNullOrBlank()) {
            create("sonusPersistent") {
                storeFile = file(secureKeystorePath)
                storePassword = secureKeystorePassword
                keyAlias = secureKeyAlias
                keyPassword = secureKeyPassword
            }
        }
    }

    val persistentSigning = signingConfigs.findByName("sonusPersistent")
    buildTypes {
        getByName("debug") {
            persistentSigning?.let { signingConfig = it }
        }
        getByName("release") {
            isMinifyEnabled = false
            persistentSigning?.let { signingConfig = it }
        }
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2026.06.00")
    implementation(composeBom)

    implementation("androidx.activity:activity-compose:1.13.0")
    implementation("androidx.core:core-ktx:1.17.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.9.2")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.navigation:navigation-compose:2.9.8")
    implementation("androidx.datastore:datastore-preferences:1.2.1")

    implementation("androidx.media3:media3-common:1.11.1")
    implementation("androidx.media3:media3-exoplayer:1.11.1")
    implementation("androidx.media3:media3-ui:1.11.1")
    implementation("androidx.media3:media3-effect:1.11.1")
    implementation("androidx.media3:media3-transformer:1.11.1")

    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.9.0")

    debugImplementation("androidx.compose.ui:ui-tooling")
    testImplementation("junit:junit:4.13.2")
}
