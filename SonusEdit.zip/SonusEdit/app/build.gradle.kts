plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("org.jetbrains.kotlin.plugin.serialization")
}


// CODE17: caption fonts are fetched from the official Google Fonts repositories on first build.
// The sources are SIL Open Font License; downloads are validated before Android packages assets.
val downloadCaptionFonts17 by tasks.registering {
    doLast {
        // This Gradle script belongs to :app, so resolve source paths from the repository root.
        val fontDir = rootProject.file("app/src/main/assets/fonts")
        val licenseDir = rootProject.file("app/src/main/assets/fonts/licenses")
        fontDir.mkdirs()
        licenseDir.mkdirs()
        data class FontSource(val fileName: String, val fontUrl: String, val licenseFile: String, val licenseUrl: String)
        val sources = listOf(
            FontSource("Caveat[wght].ttf", "https://raw.githubusercontent.com/google/fonts/main/ofl/caveat/Caveat%5Bwght%5D.ttf", "Caveat-OFL.txt", "https://raw.githubusercontent.com/google/fonts/main/ofl/caveat/OFL.txt"),
            FontSource("DancingScript[wght].ttf", "https://raw.githubusercontent.com/google/fonts/main/ofl/dancingscript/DancingScript%5Bwght%5D.ttf", "DancingScript-OFL.txt", "https://raw.githubusercontent.com/google/fonts/main/ofl/dancingscript/OFL.txt"),
            FontSource("PatrickHand-Regular.ttf", "https://raw.githubusercontent.com/google/fonts/main/ofl/patrickhand/PatrickHand-Regular.ttf", "PatrickHand-OFL.txt", "https://raw.githubusercontent.com/google/fonts/main/ofl/patrickhand/OFL.txt"),
            FontSource("Kalam-Regular.ttf", "https://raw.githubusercontent.com/google/fonts/main/ofl/kalam/Kalam-Regular.ttf", "Kalam-OFL.txt", "https://raw.githubusercontent.com/google/fonts/main/ofl/kalam/OFL.txt"),
            FontSource("KaushanScript-Regular.ttf", "https://raw.githubusercontent.com/google/fonts/main/ofl/kaushanscript/KaushanScript-Regular.ttf", "KaushanScript-OFL.txt", "https://raw.githubusercontent.com/google/fonts/main/ofl/kaushanscript/OFL.txt"),
        )
        fun fetch(url: String, target: java.io.File, minimumBytes: Long) {
            if (target.isFile && target.length() >= minimumBytes) return
            val connection = java.net.URL(url).openConnection().apply {
                connectTimeout = 20_000
                readTimeout = 45_000
                setRequestProperty("User-Agent", "SONUS-EDIT-CODE17/1.0")
            }
            val temporary = java.io.File(target.parentFile, target.name + ".part")
            try {
                connection.getInputStream().use { input -> temporary.outputStream().use { output -> input.copyTo(output) } }
                require(temporary.isFile && temporary.length() >= minimumBytes) { "Download inválido: ${target.name}" }
                if (target.exists()) target.delete()
                check(temporary.renameTo(target)) { "Não foi possível instalar ${target.name}" }
            } finally {
                temporary.delete()
                (connection as? java.net.HttpURLConnection)?.disconnect()
            }
        }
        sources.forEach { source ->
            val target = java.io.File(fontDir, source.fileName)
            fetch(source.fontUrl, target, 8_000L)
            val header = target.inputStream().use { input -> ByteArray(4).also { input.read(it) } }
            require(header.contentEquals(byteArrayOf(0, 1, 0, 0)) || String(header, Charsets.US_ASCII) == "OTTO") {
                "Fonte inválida ou resposta HTTP inesperada: ${source.fileName}"
            }
            fetch(source.licenseUrl, java.io.File(licenseDir, source.licenseFile), 1_000L)
        }
    }
}

val verifyCaptionFonts17 by tasks.registering(Exec::class) {
    dependsOn(downloadCaptionFonts17)
    commandLine(
        "python3",
        rootProject.file("scripts/verify_caption_fonts17.py").absolutePath,
        rootProject.file("app/src/main/assets/fonts").absolutePath,
    )
}

tasks.named("preBuild").configure {
    dependsOn(verifyCaptionFonts17)
}


android {
    namespace = "com.sonusstudios.sonusedit"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.sonusstudios.sonusedit"
        minSdk = 26
        targetSdk = 36
        versionCode = 17
        versionName = "1.0.7"
    }

    // Persistent signing: Codemagic may provide a secure keystore through environment
    // variables. The Codemagic workflow MUST provide the same persistent signer already configured in Codemagic;
    // it intentionally fails rather than silently creating a different key.
    val secureKeystorePath = System.getenv("SONUS_KEYSTORE_PATH")
    val secureKeystorePassword = System.getenv("SONUS_KEYSTORE_PASSWORD")
    val secureKeyAlias = System.getenv("SONUS_KEY_ALIAS")
    val secureKeyPassword = System.getenv("SONUS_KEY_PASSWORD")

    signingConfigs {
        if (!secureKeystorePath.isNullOrBlank() && !secureKeystorePassword.isNullOrBlank() &&
            !secureKeyAlias.isNullOrBlank() && !secureKeyPassword.isNullOrBlank()) {
            create("sonusPersistent") {
                storeFile = file(secureKeystorePath)
                storePassword = secureKeystorePassword
                keyAlias = secureKeyAlias
                keyPassword = secureKeyPassword
            }
        }
    }

    val persistentSigning = signingConfigs.findByName("sonusPersistent")
    buildTypes {
        getByName("debug") {
            persistentSigning?.let { signingConfig = it }
        }
        getByName("release") {
            isMinifyEnabled = false
            persistentSigning?.let { signingConfig = it }
        }
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    androidResources {
        // code14 particle sources are already compressed H.264 MP4. Keep them byte-for-byte.
        noCompress += "mp4"
    }

    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2026.06.00")
    implementation(composeBom)

    implementation("androidx.activity:activity-compose:1.13.0")
    implementation("androidx.core:core-ktx:1.17.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.9.2")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.navigation:navigation-compose:2.9.8")
    implementation("androidx.datastore:datastore-preferences:1.2.1")

    implementation("androidx.media3:media3-common:1.10.1")
    implementation("androidx.media3:media3-exoplayer:1.10.1")
    implementation("androidx.media3:media3-ui:1.10.1")
    implementation("androidx.media3:media3-effect:1.10.1")
    implementation("androidx.media3:media3-transformer:1.10.1")

    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.9.0")

    // code16: isolated social-link resolver (YouTube/TikTok/etc.) backed by yt-dlp.
    implementation("io.github.junkfood02.youtubedl-android:library:0.18.1")
    implementation("io.github.junkfood02.youtubedl-android:ffmpeg:0.18.1")

    // code19: offline automatic captions powered by whisper.cpp through a prebuilt Android AAR.
    implementation("dev.ffmpegkit-maintained:whisper-android:1.0.0")

    debugImplementation("androidx.compose.ui:ui-tooling")
    testImplementation("junit:junit:4.13.2")
}
