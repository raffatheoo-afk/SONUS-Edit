# SONUS Edit 0.0.22 / code22

## Scope
Surgical accuracy/search update based on code21. Link/yt-dlp/FFmpeg, particle files/effects, filters, 9:16/16:9 output and export logic remain unchanged.

## Whisper precision
- Multilingual Whisper Base remains the model.
- First voiced chunk is transcribed with `auto`; on PT-BR devices or Portuguese evidence, a second `pt` pass is run and selected only when it contains real Portuguese evidence.
- Once Portuguese is selected, later chunks use `language="pt"`; English/non-Portuguese tracks remain on `auto`.
- Window: 24 seconds (was 30 seconds).
- Overlap: 3 seconds (was 1.5 seconds).
- Existing overlap deduplication remains.
- `ENGINE_VERSION=4` invalidates old caption JSON caches so code21 text cannot mask the new behavior.
- Whisper model is still released immediately after transcription.

## Gallery search / title matching
- The approved 16:9 pCloud code is unchanged: `kZpRVYJZCVInrVg53M8t2JVi0nyFVjrg28ik`.
- A typed Gallery search now scans `imageCatalog`, i.e. the complete catalog of whichever aspect ratio is active. It no longer searches only the artist/category-ranked subset.
- Search normalizes accents, case, underscores, hyphens and punctuation, ignores connector words, requires every meaningful keyword, and ranks exact phrase/name matches first.
- If a typed query has no local-catalog match, code22 waits 350 ms and performs one forced pCloud refresh for that query so newly uploaded images can appear without restarting the app.
- This fixes searches such as `Nossa Senhora Aparecida` matching `Nossa_Senhora_da_Aparecida_hora_01.png`.
- Automatic selection now treats an explicit song-title filename as an intentional override of a conflicting artist-category tag. A different religious/categorical image is still blocked, so the Gustavo Mioto protection remains.
- Added `Code22GallerySearchTest` for separator normalization, keyword precision and title/category override protection.

## Beam-search note
The current `dev.ffmpegkit-maintained:whisper-android:1.0.0` JNI hard-codes greedy sampling and exposes no Kotlin switch for beam search. Replacing/forking that native layer would be a much larger regression risk, so code22 keeps the stable native dependency and applies the safe high-precision changes above instead.

## Version
`versionName=0.0.22`, `versionCode=22`.
