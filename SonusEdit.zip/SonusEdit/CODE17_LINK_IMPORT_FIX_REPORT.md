# SONUS EDIT 1.0.7 / CODE 17 — Ajuste corretivo do importador

## Objetivo
Corrigir a experiência de importação sem alterar a versão 1.0.7, o CODE 17, a assinatura ou a identidade do aplicativo.

## Alterações
- O SONUS Link Engine não bloqueia um endereço somente por reconhecer o domínio de uma plataforma. Ele faz uma requisição HTTPS normal, segue redirecionamentos públicos e só mantém o resultado se a resposta final for um arquivo de mídia compatível.
- O motor não lê, desmonta ou faz scraping de páginas sociais. Respostas HTML, erros de acesso ou formatos não-mídia geram uma mensagem contextual e um botão para selecionar um vídeo salvo.
- O Android Sharesheet agora aceita links compartilhados como texto. O SONUS EDIT abre o fluxo de criação com o campo Link preenchido.
- Vídeos compartilhados como arquivo agora têm sua faixa de áudio verificada e podem ser usados diretamente como fonte do projeto.
- O Codemagic valida a nova rota de compartilhamento, o botão de recuperação e os testes de extração segura de URL.

## O que permanece igual
- `versionName`: 1.0.7
- `versionCode`: 17
- `applicationId`: com.sonusstudios.sonusedit
- Configuração e bloco de assinatura persistente
- Dependências e modelo Whisper
- Remoção de yt-dlp e FFmpeg do APK

## Validações executadas neste ambiente
- Script de validação estática do CODE 17: aprovado.
- XML do AndroidManifest: válido.
- YAML do Codemagic: válido.
- Compilação isolada do SONUS Link Engine Kotlin com stubs Android: aprovada.
- Compilação isolada do IncomingIntentRouter Kotlin com stubs Android e 4 verificações de URL: aprovada.

## Limite conhecido
Não foi executado um build Android completo nem teste de aparelho neste ambiente (Android SDK/Gradle não disponíveis). Links de páginas sociais só serão importados automaticamente se uma resposta HTTPS pública/autorizada redirecionar para um arquivo de mídia direto. Quando a página não fornece o arquivo, a recuperação é selecionar ou compartilhar o arquivo salvo por uma opção permitida pela plataforma. Esta manutenção não adiciona extração de páginas nem contorna autenticação, DRM ou controles anti-bot.
