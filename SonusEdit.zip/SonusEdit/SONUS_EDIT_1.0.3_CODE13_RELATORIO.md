# SONUS EDIT — Relatório técnico 1.0.3 / CODE 13

Data: 20/11/2026  
Base: Sonus Edit 1.0.2 / CODE 12 (compilada e testada pelo usuário)  
Tipo: manutenção de emergência

## 1. Escopo implementado

### Pesquisa de imagens e catálogo contextual
- Pesquisa digitada passa a executar atualização específica para o termo atual nas fontes públicas pCloud configuradas, sem encerrar a consulta apenas porque o cache global contém alguma correspondência.
- Consultas por fonte são limitadas a três operações simultâneas por repositório.
- Resultados parciais continuam sendo publicados progressivamente.
- Resultados atrasados de uma consulta antiga ou de outra proporção não podem substituir a pesquisa atualmente aberta; essa regra está centralizada em `GalleryQueryResultGate13` e coberta por teste.
- O pré-carregamento inicial da galeria também verifica o termo e a proporção capturados no início antes de publicar resultados, evitando corrida com pesquisas digitadas depois.
- Busca manual mantém normalização de acentos e caixa e agora reconhece variações frequentes como cidade/cidades/city, noite/noites/night/noturno/noturna, romântico/romântica/romance e sertanejo/sertaneja.
- Adicionado `app/src/main/assets/music_image_keywords.txt` com grupos de vocabulário compartilhado por contexto musical (religioso, rap/trap/hip-hop, sertanejo/piseiro/forró/funk, romântico, cidade/noite, pop, rock, eletrônico e MPB/samba/reggae).
- A classificação usa título e gênero da faixa. Imagens religiosas são retiradas das sugestões automáticas quando a faixa não indica contexto religioso; a pesquisa manual explícita permanece livre para localizar o termo solicitado.
- Solicitações remotas de miniaturas passam a pedir 384x384, mantendo a resolução maior das mídias de origem para exportação.
- Política e limites do histórico FIFO (20 projetos 9:16 / 15 projetos 16:9), toggle e regras de liberação não foram alterados nesta manutenção.

### Sonus Stream / metadados
- `PCloudAsset` aceita campos opcionais título, artista, álbum e gênero retornados no catálogo pCloud, com valores padrão nulos para manter compatibilidade com cache serializado anterior.
- `PCloudPublicCatalogClient` mapeia os campos de metadados fornecidos por `showpublink`.
- `StreamCatalogMetadataMapper` e `StreamMetadataStore` preferem esses metadados do catálogo; leitura remota ID3 permanece como fallback quando a identidade ainda não está disponível.
- Indexação remota mantém três trabalhadores fixos, sem criar uma coroutine pendente para cada arquivo do catálogo.

### Áudio local e seleção de trecho
- Novo `AudioDurationProbe13` utiliza `MediaExtractor` para ler `MediaFormat.KEY_DURATION` da faixa de áudio, sem decodificar o arquivo.
- A leitura ocorre em `Dispatchers.IO`, paralela à preparação do ExoPlayer e à leitura descritiva ID3.
- Duração técnica válida cria/atualiza metadados provisórios e libera a timeline e os controles de corte sem aguardar o término da leitura ID3.
- Os comandos de seek/play podem ser enfileirados durante `BUFFERING`; os controles não são bloqueados aguardando `Player.STATE_READY`.
- Fontes local, compartilhada e vídeo com áudio extraído usam o probe; outras fontes mantêm seus caminhos existentes.
- Quando o probe não consegue obter duração, o fluxo de duração do ExoPlayer e o leitor de metadados existente permanecem como fallback.

### Sincronização de legendas
- Relógio regressivo existente preservado.
- Indicador percentual circular compacto adicionado ao lado do relógio.
- Barra grande/overlay que cobria fontes, estilos e filtros removida.
- Controle individual de legendas por vídeo continua podendo cancelar a geração e liberar Avançar; ao reativar, o fluxo verifica/reutiliza cache ou gera quando necessário.

### Exportação sem identificação
- `ExportMetadataPolicy` distingue campos intocados de campos editados/apagados intencionalmente.
- Flags de edição manual do título e artista são persistidas em rascunhos.
- `VideoVisualEffects` respeita valores intencionalmente vazios e não desenha identificação quando ambos os campos foram apagados.
- Fallback de nome usado somente para nome de arquivo/notificação não altera o texto gravado no vídeo.

## 2. Preservações
- Versão: `versionName=1.0.3`, `versionCode=13`.
- `applicationId`: `com.sonusstudios.sonusedit`.
- Workflow ID: `sonus-edit-0-0-3-code03-debug`.
- Bloco de restauração da assinatura persistente foi comparado com o CODE 12 e permanece byte a byte idêntico. Nenhum cadastro manual no Codemagic foi introduzido.
- Catálogo de fontes, rodízio de oito fontes, redesign da tela inicial/Ajustes/Estatísticas, toggle e limites de bloqueio CODE 12 preservados.
- Catálogo e preferências das dez famílias de transição permanecem; `VisualTransitionPreferences.kt` está idêntico ao CODE 12 e o pipeline de transições não foi modificado. A alteração em `VideoVisualEffects.kt` limita-se ao tratamento dos campos de identificação apagados intencionalmente.
- Relógio regressivo de legendas preservado.

## 3. Testes e verificações executados neste ambiente
- `scripts/validate_v1_0_3_code13.py`: passou.
- YAML: parseado com sucesso.
- Sintaxe Bash de todos os scripts do workflow: passou.
- Bloco de assinatura persistente do CODE 12 versus CODE 13: idêntico.
- Testes direcionados com `kotlinc` e stubs locais para helpers puros de classificação/pesquisa, metadados do Stream, estimativa de progresso, campos de exportação e gate de consulta: passaram.
- `AudioDurationProbe13.kt` compilado isoladamente com stubs Android e funções puras de normalização/seleção de duração verificadas.
- Testes JUnit adicionados para `AudioDurationProbe13` e `GalleryQueryResultGate13` e listados na etapa de validação do Codemagic.
- Não existe Gradle, Gradle Wrapper nem Android SDK disponível neste ambiente. Portanto `:app:compileDebugKotlin`, `:app:testDebugUnitTest` e `:app:assembleDebug` não foram executados aqui; não se declara compilação Android nem APK aprovados.

## 4. Novos arquivos principais
- `app/src/main/assets/music_image_keywords.txt`
- `app/src/main/java/com/sonusstudios/sonusedit/create/AudioDurationProbe13.kt`
- `app/src/main/java/com/sonusstudios/sonusedit/create/GalleryQueryResultGate13.kt`
- `app/src/test/java/com/sonusstudios/sonusedit/create/AudioDurationProbe13Test.kt`
- `app/src/test/java/com/sonusstudios/sonusedit/create/GalleryQueryResultGate13Test.kt`

## 5. Próxima validação
Executar o workflow original no Codemagic para confirmar compilação Kotlin, JUnit completo e geração do APK. Depois testar no dispositivo: pesquisas consecutivas por termos sabidamente existentes, contexto religioso e não religioso, áudio local longo, indicador de legendas e exportação com título/artista vazios.
