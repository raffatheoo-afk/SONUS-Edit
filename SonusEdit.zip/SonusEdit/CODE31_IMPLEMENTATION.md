# SONUS Edit 1.7 / code31 — Legendas automáticas e estilos de legenda

## Home
- Botão ⚙️ ao lado da coroa Premium; o card "Ajustes" saiu da parte de baixo (nenhuma função de Ajustes foi removida).
- Ordem: Criar vídeo automático · Criar com Link | Legendas automáticas · Estatísticas | Rascunho.

## Dez estilos de legenda (`CaptionStyleId`)
Clássico limpo, Palavra por palavra, Karaokê, Pop-in, Acúmulo, Marca-texto, Neon, Subida suave, Tarja e Cinema, mais o botão **Dinâmico**.
- **Um só desenhista** (`CaptionStyleRenderer`) para a prévia e para a exportação: o que aparece na tela é o que sai no MP4. Ele só precisa de Canvas, tamanho em pixels e tempo.
- O Whisper (whisper-android 1.0.0) entrega o tempo da frase, não da palavra. O tempo por palavra é **estimado** (`CaptionWordTimer`): a duração da frase é repartida pelo tamanho das palavras, com pausa maior depois de pontuação. Funciona bem em fala; em música com notas longas fica menos exato. Clássico, Subida suave, Tarja e Cinema não dependem disso.
- Qualquer falha ao desenhar é engolida de propósito: um problema de estilo nunca derruba o preview nem a exportação.
- Escolha automática (`CaptionStyleSelector`): gênero (trap/funk/rap → ritmo rápido; católica/romântica/acústica → calmo), depois palavras por segundo. Nunca repete o último estilo. A preferência do usuário nos Ajustes ("Automático" ou um estilo fixo) sempre vence.
- Projetos por Link, Stream e Local ganham a linha de estilos (3+ visíveis, deslizando) na etapa de fontes, a prévia ao vivo na revisão e o botão **ESTILO** para trocar por outro. Rascunhos antigos continuam abrindo (todo campo novo tem valor padrão).

## Legendas automáticas (tela `AutoCaptionsScreen`, rota `auto_captions`)
1. Abre o gerenciador de arquivos já filtrado por vídeo.
2. Lê duração, proporção (considerando rotação), fps, tamanho e se há áudio. Sem áudio: avisa e volta.
3. Acima de **3 minutos** mostra o aviso de demora com a estimativa do mesmo estimador do relógio.
4. Sincronização com o relógio vermelho (tela ligada durante o processo). Sem voz detectada: mensagem clara.
5. **Ajustar legenda**: posição (Topo/Meio/Embaixo, calculada para 9:16 ou 16:9 dentro da área segura), estilo, fonte (as 16 aprovadas) e cor, com a prévia do vídeo real.
6. **Revisão**: prévia maior, botão ATUALIZAR ESTILO, qualidade e FPS (padrão automático pela origem, sem aumentar a resolução) e EXPORTAR.
- A exportação reutiliza o exportador existente com o vídeo como imagem/vídeo local e o próprio vídeo como fonte de áudio. O enquadramento original é mantido (`fitFullFrame`, sem corte), sem partículas, filtro, assinatura ou título; vídeos longos usam o modo em partes já existente (retomada por trecho e junção final).
- Antes de exportar o app confere o espaço livre.
- Ao terminar a exportação, "voltar" leva à Home.

## Ajustes
- Novo item "Estilo da legenda" (Automático + 10 estilos).

## Validação
- `scripts/validate_v1_7_code31.py` e `codemagic.yaml` atualizados; testes unitários `Code31CaptionStylesTest` (tempo por palavra, escolha de estilo).
- A validação estática não substitui a compilação Android nem o teste em aparelho.
