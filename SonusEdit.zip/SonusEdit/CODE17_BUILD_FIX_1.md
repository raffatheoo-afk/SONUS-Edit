# SONUS Edit 0.0.17 / code17 — Build fix 1

Codemagic `compileDebugKotlin` failed because `PCloudLyricsRepository.loadAssetBody()` was not a suspend function while it called the suspend API `PCloudPublicCatalogClient.resolveDownloadUrl()`.

Fix:
- `loadAssetBody(...)` is now `private suspend fun`.
- No product behavior, version, exporter, particle assets, Media3 version, signing lineage, or UI was changed.
- Version remains `0.0.17` / `versionCode 17` because no APK from code17 had been produced yet.
