# Sonus Edit 0.0.3 — code03

## Escopo desta atualização

Esta versão reúne melhorias do pacote autorizado, mantendo o projeto maduro e a arquitetura existente. O número 0.0.3/code03 continua a sequência de distribuição após a troca anterior da chave de assinatura; não representa um aplicativo novo.

### Gallery e nuvem
- Adicionadas as novas pastas públicas pCloud de músicas, Gallery 9:16 e Gallery 16:9, mantendo os códigos anteriores.
- Atualização da Gallery passou a agregar os catálogos configurados e preservar em cache os arquivos de uma pasta que falhar temporariamente enquanto as demais respondem.
- Pesquisa trabalha sobre o catálogo local imediatamente e atualiza a nuvem em segundo plano; o botão de lupa executa atualização explícita.
- Campo de pesquisa foi reorganizado com lupa fora do campo.
- Gallery aceita imagens e vídeos compatíveis; miniaturas remotas são reduzidas e armazenadas em cache. Para vídeo, usa quadro do MediaMetadataRetriever quando não há miniatura pCloud.
- URLs originais permanecem como fonte para edição/exportação; a miniatura compacta serve somente para a grade.

### Repetição de mídia
- Histórico persistente é gravado somente depois que o MP4 é salvo com sucesso e bloqueia imagens usadas nos quatro projetos anteriores.
- A regra foi alinhada ao exemplo aprovado: imagens do vídeo 1 voltam no vídeo 6; imagens do vídeo 2 voltam no vídeo 7.
- O bloqueio também se aplica à pesquisa manual; quando não há conteúdo elegível, o aplicativo não reutiliza silenciosamente mídias bloqueadas e apresenta aviso.
- Sugestões são embaralhadas/pesadas dentro do conjunto elegível.

### Legendas, fontes e filtros
- Estilo de legenda dinâmico removido da seleção; Clássico limpo é o padrão para novos projetos.
- Inclusão de edição textual diretamente na prévia, preservando os tempos do segmento e usando o texto corrigido na exportação.
- Fonte sans-serif padrão na primeira posição; Rocky, Epicentrum, Gloverley e The Brother Hoops retiradas da seleção e dos assets do aplicativo; IDs antigos migram para Sans-serif. IDs antigos continuam compatíveis com rascunhos existentes.
- Grade visual contém seis filtros: Natural, Preto profundo, Vivido, Nitidez+, Primavera e Preto e branco.
- Natural permanece neutro por padrão. O shader permite saturação zero para preto e branco monocromático.

### Reprodução e link
- Ao ajustar os limites do trecho, o áudio continua tocando; Avançar interrompe a reprodução.
- Normalização de links sociais e rótulos para TikTok, Instagram, Facebook e X; opções moderadas de retry para erros transitórios do yt-dlp. Formato de áudio e caminho de importação existente foram mantidos.

### Identidade visual e Premium
- Ícone Android e símbolo do splash substituídos pela referência fornecida; animação e transições da abertura foram preservadas.
- Tela Premium reorganizada e com Edit Pro em destaque. Continua informativa: não ativa cobrança, bloqueio de recursos nem cotas.
- Benefícios que ainda não existem são identificados como planejados/em breve.

### Whisper
- Mantido Whisper Small multilíngue local, a configuração de inferência e a quantidade de threads existentes; nenhuma quantização ou modelo menor foi aplicada.
- Ajustada a lógica de hipótese/validação de idioma para depender de evidência no texto reconhecido, sem usar o idioma do telefone como motivo para forçar português.
- ENGINE_VERSION elevada para invalidar caches de transcrição gerados pela lógica anterior.
- A prioridade desta versão foi preservar a precisão. Não há alegação de que o tempo tenha sido reduzido; a meta de 10–20 s para áudio de 40 s permanece condicionada a benchmark real nos aparelhos.

## Integridade e compatibilidade
- `applicationId` mantido: `com.sonusstudios.sonusedit`.
- Media3 mantido em 1.10.1; `AutomaticVideoExporter.kt` não foi alterado.
- yt-dlp/FFmpeg mantidos em 0.18.1; whisper-android mantido em 1.0.0.
- Chave permanente e passo de assinatura do Codemagic preservados sem alteração.
- Workflow mantido: `sonus-edit-0-0-3-code03-debug`.

## Validação realizada neste ambiente
- Validador estático `scripts/validate_v0_0_3_code03.py`.
- Script de validação do passo `Validate Sonus Edit 0.0.3` extraído do YAML executado localmente.
- YAML analisado com PyYAML.
- Smoke test local da detecção conservadora `CaptionLanguageHint`.
- Verificação de versão, catálogo, seis filtros, fontes, arquivos de logotipo, chaves de assinatura e contratos críticos.

## Não verificado neste ambiente
- Compilação Android Gradle, APK final e testes unitários Gradle: não foi possível executar aqui porque o pacote não contém Gradle Wrapper e o ambiente não dispõe de Gradle/Android SDK configurados.
- Codemagic ainda precisa executar compile, testes unitários e assembleDebug.
- Comportamento real em Galaxy S10e e Galaxy A15.
- Acesso em tempo real a cada conteúdo público pCloud e extração individual de URLs TikTok/Instagram/Facebook/X.
- Precisão e duração reais do Whisper com músicas em PT/EN e narrações com silêncio; esses testes exigem áudio de referência e aparelhos.
- Resultado final de MP4 remoto e exportação, incluindo prévia, posição e sincronização de legendas, deve ser verificado no APK.

## Testes recomendados no aparelho
1. Gallery 9:16/16:9: pesquisa por cidade, carregamento cache-first, novas pastas e vídeos MP4.
2. Anti-repetição: usar A/D/E no vídeo 1; confirmar ausência nos vídeos 2–5 e retorno no 6; imagens do vídeo 2 devem retornar no 7.
3. Música: Play, ajustar início e final sem interromper; Avançar deve parar o áudio.
4. Legendas: editar texto na prévia, alterar tamanho/posição e exportar; conferir início do vídeo e trechos de silêncio.
5. Filtros: confirmar seis opções, Natural padrão e Preto e branco sem cor.
6. Links: repetir testes YouTube já aprovados; experimentar links públicos TikTok e outras plataformas suportadas.
7. Whisper: medir etapas separadas em PT/EN no Galaxy S10e e A15 sem sacrificar a precisão.
8. Ícone e splash: observar dimensões, margens, centralização e animação.
