# Sonus Edit 1.0.0 — CODE 10

## Escopo aprovado
- Aumentar somente a tipografia da prévia na janela preta da seleção de fontes; manter a janela no mesmo tamanho.
- Aumentar os cartões de estilo somente na etapa principal do editor para 104 × 78 dp, com prévia proporcional e rótulo maior.
- Manter os filtros, suas posições relativas e os botões inferiores; não adicionar rolagem vertical à etapa de estilo.
- Atualizar os identificadores visíveis e do Android para versão 1.0.0 / versionCode 10.
- No ecrã Sobre, exibir somente a versão atual e as novidades da CODE 10, removendo os cartões das versões antigas.

## Preservação
O picker de estilos usado em outras telas mantém suas dimensões padrão (96 × 60 dp, prévia 42 dp). O ajuste ampliado é passado apenas pela tela principal de criação. Nenhuma fonte, efeito, mecanismo de renderização ou fluxo de exportação foi removido.

## Verificação
A validação estática CODE 10 está em `scripts/validate_v1_0_0_code10.py`. Os testes JUnit e a compilação Android devem ser executados no Codemagic; não são declarados aprovados antes da execução.
