# Sonus Edit 0.0.10 / code10

Base: 0.0.9 / code09 funcional.

## Partículas
- Removidos os 13 assets antigos de efeitos.
- O vídeo 1080x1920 enviado para code10 foi preparado com chroma key e convertido em um único atlas transparente 9:16 (`effect_particles_source.webp`).
- Um único motor de partículas gera cinco variações: Arco-íris, Brilhante, Vagalume, Estrela e Glitter.
- Modo Dinâmico integrado ao Auto Edit escolhe entre as cinco variações por shuffle bag persistente, sem repetir antes de completar o ciclo.
- Controle de partículas liga/desliga preservado nas automações.
- Intensidades fixas: 30%, 50% e 100%.

## Texto e interface
- Letra sincronizada reduzida mais 10% em relação à code09 (`0.0478f` -> `0.0430f`).
- Tipografia exportada da letra ficou mais delicada; tamanhos/posições de assinatura, título e artista foram preservados.
- Integração SONUS -> Edit exibe popup verde suave `Sincronizando…` durante a entrada do projeto.

## Assinatura
- `Salvar padrão` passa a salvar imediatamente quando ativado e é reforçado novamente ao finalizar o projeto, evitando perder a assinatura em fluxos de navegação alternativos.

## Exportação
- A notificação de exportação existe somente durante o render.
- Ao concluir, falhar ou cancelar, o foreground é removido e a notificação é encerrada definitivamente.

## Compatibilidade preservada
- package: `com.sonusstudios.sonusedit`
- workflow Codemagic ID preservado: `sonus-edit-0-0-3-code03-debug`
- assinatura persistente do APK preservada pelo mesmo fluxo Codemagic.
- Mantidas as regras estáveis da code09: seleção de imagens por título+gênero, LRC, favoritos, shuffle de fontes/filtros e exportação em segundo plano.
