# SONUS Edit 0.0.1 / code01 — nova chave de assinatura e recomeço da contagem de versão

## Por quê
A chave de assinatura antiga existia só no cache do Codemagic e não foi mais restaurada (o passo "Restore persistent Sonus Edit signing" parou o build de propósito para não trocar a assinatura). Ela não estava em nenhum ZIP nem `codemagic.yaml`, então não havia como recuperá-la.

## O que mudou
- **Nova chave permanente** (alias `sonusedit`, RSA 2048, válida até 2054) embutida no `codemagic.yaml`. O passo "Restore persistent Sonus Edit signing" grava o keystore a partir do próprio arquivo e exporta as variáveis `SONUS_*` que o `build.gradle.kts` já usa. Nada depende mais do cache do Codemagic.
- Cada build publica `KEY_SHA256.txt` (impressão digital da chave), para conferir que a assinatura é sempre a mesma.
- O cache do Codemagic deixou de guardar a pasta da chave.
- Versão: **0.0.1 / versionCode 1** (antes 1.7 / 31). Home, tela de criação, `build.gradle.kts`, `BUILD_VERSION.txt`, `codemagic.yaml` e o validador `scripts/validate_v0_0_1_code01.py` foram atualizados.
- O app em si é o mesmo da 1.7/code31: nenhuma função mudou.

## Importante
- A assinatura mudou e a versão voltou para 1: o Android **não instala por cima** do app antigo. É preciso **desinstalar o Sonus Edit antigo** antes. Rascunhos, ajustes, estatísticas e o modelo Whisper baixado (que será baixado de novo) ficam para trás.
- A chave está dentro do `codemagic.yaml`. Se o repositório for público, qualquer pessoa pode ler o arquivo e assinar APKs como Sonus Edit. Mantenha o repositório privado e guarde uma cópia da chave fora do GitHub.
- O ID do workflow (`sonus-edit-0-0-3-code03-debug`) não mudou.
