# SONUS Edit — 1.0.7 / CODE 17

Aplicativo Android para criação, legendagem e exportação automática de vídeos musicais.

## Novidades do CODE 17
- O relógio e a barra de progresso da sincronização automática usam a mesma previsão calibrada, com 100% reservado à conclusão confirmada.
- A estimativa de legendas começa pelos tempos medidos de 15, 30, 40, 50 e 60 segundos e aprende com as últimas dez execuções bem-sucedidas, separando orientação e quantidade de mídias.
- A extração de áudio registra MIME, PTS, buffers e duração PCM; uma extração por seek insuficiente é repetida do início da faixa.
- O Whisper verifica que todos os blocos planejados foram processados e usa uma nova versão de cache.
- O progresso/ETA de exportação compartilham a mesma curva; o histórico local aprende com até dez exportações limpas comparáveis.
- Os tempos medidos pelo usuário são preservados exatamente, incluindo os resultados não monotônicos obtidos com a mesma música e as mesmas imagens.
- Cinco fontes manuscritas (Caveat, Dancing Script, Patrick Hand, Kalam e Kaushan Script) foram incluídas no catálogo. Os TTFs e licenças SIL OFL são obtidos do repositório oficial Google Fonts durante o `preBuild`, quando ausentes, e validados quanto a glifos portugueses antes da compilação. Montepetrum Thin saiu das opções e projetos antigos são direcionados a Patrick Hand.
- Pré-visualizações de imagens usam decodificação reduzida e miniaturas em cache; quadros de vídeo usam decodificação escalada quando o Android oferece suporte.
- A exportação registra detalhes de falha por resolução/FPS para investigação do 4K 60 FPS.

## Histórico do CODE 16 (base anterior)
- A tela de legendas automáticas passa a exibir progresso percentual sincronizado com os checkpoints reais do Whisper e com o estimador já usado na criação normal.
- A exportação de legendas automáticas evita redimensionamentos GPU redundantes por clipe e aplica a dimensão de saída uma única vez na composição, mantendo o quadro completo e o áudio original.
- A mensagem interna de calibração 0/5 não aparece mais para o usuário; a coleta das amostras e a previsão de ETA permanecem ativas.

## Identidade e compatibilidade
- `applicationId`: `com.sonusstudios.sonusedit`
- `versionName`: `1.0.7`; `versionCode`: `17`
- Workflow Codemagic: `sonus-edit-1-0-7-code17`.
- `applicationId`, namespace e keystore persistente configurado pelo usuário permanecem os mesmos. O YAML não contém keystore, Base64 ou senhas; espera as variáveis seguras `SONUS_KEYSTORE_PATH`, `SONUS_KEYSTORE_PASSWORD`, `SONUS_KEY_ALIAS` e `SONUS_KEY_PASSWORD` (ou equivalentes `CM_*`). Para usar uma identidade em **Codemagic > Code signing identities**, é necessário informar no YAML o nome exato da referência já cadastrada em `environment.android_signing`; essa referência não foi presumida nem inventada.

## Preservações desta rodada
Galeria pCloud, fontes Stream/Local/Link, Whisper Small, transições, filtros, interface geral, histórico, estatísticas e demais fluxos não foram alterados.

O histórico do pacote anterior permanece em `CODE16_IMPLEMENTATION.md` e `CODE16_APPROVED_CHECKLIST.txt`. Consulte `CODE17_IMPLEMENTATION_2026-11-28.md` para as alterações desta versão e limitações de validação.


## Manutenção 23/11/2026 (sem alterar a versão)
- Rascunhos com gravação atômica, disponibilidade atualizada na Home e restauração fiel do recorte, inclusive a posição da prévia de áudio.
- Exportação com proteção contra falhas síncronas de composição/Transformer, tentativas mais leves em erros de muxer/codec/memória e janela maior para o primeiro quadro.
- A tela Sobre descreve as correções mantendo 1.0.6 / CODE 16.


## Validação CODE17
- O workflow seleciona apenas o pacote explicitamente nomeado CODE17 ou a pasta `SonusEdit/`; pacotes históricos CODE14 não são mais candidatos.
- O pipeline verifica a identidade 1.0.7 / 17, compila Kotlin, executa testes unitários e gera APK debug.
- A validação de fontes acontece em `preBuild`; os arquivos TTF e licenças são obtidos de Google Fonts quando não estiverem presentes e conferidos antes da compilação.
- A compilação Android completa e o comportamento em aparelho ainda precisam ser validados no Codemagic/dispositivo. A causa definitiva das falhas 4K60 ainda depende de Logcat/reprodução real; CODE17 melhora a instrumentação, mas não declara esse defeito resolvido.
