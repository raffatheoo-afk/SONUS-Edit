# SONUS Edit — 1.0.3 / CODE 13

Aplicativo Android para criação, legendagem e exportação automática de vídeos musicais.

## Novidades do CODE 13
- Pesquisa de imagens por termo: consultas não dependem apenas da idade do cache global; cada busca verifica correspondências para o termo atual e continua consultando fontes quando necessário.
- Classificação contextual local por título/gênero, alimentada por `app/src/main/assets/music_image_keywords.txt`, com vocabulários compartilhados entre estilos semelhantes e proteção contra sugestões religiosas fora do contexto religioso.
- Galeria: correspondência manual com variações frequentes do português e miniaturas solicitadas em tamanho moderado, mantendo o bloqueio recente existente sem alterar seus limites.
- Sincronização de legendas: relógio regressivo preservado e indicador circular compacto de porcentagem; as opções de fonte, estilo e filtro permanecem acessíveis durante a geração.
- Sonus Stream: aproveita título, artista, álbum e gênero dos metadados do catálogo pCloud e mantém leitura ID3 remota em segundo plano quando necessária.
- Exportação: campos de nome da música e artista apagados intencionalmente na revisão permanecem vazios no vídeo final.
- Áudio local: duração técnica identificada em segundo plano por metadados do contêiner/faixa, sem decodificar a música inteira; controles de trecho não aguardam a leitura descritiva ID3.

## Preservações técnicas
- `applicationId`: `com.sonusstudios.sonusedit`
- `versionName`: `1.0.3`; `versionCode`: `13`
- Workflow Codemagic fixo: `sonus-edit-0-0-3-code03-debug`
- Media3 1.10.1; Whisper Small multilíngue local / ENGINE_VERSION 16; integração Link, yt-dlp e FFmpeg.
- Catálogo de fontes, histórico de imagens, transições e redesign da tela inicial/Ajustes/Estatísticas do CODE 12 foram preservados; o pipeline de exportação das transições não foi alterado nesta manutenção.
- O workflow mantém a restauração automática da assinatura persistente original, sem cadastro manual de identidade no painel Codemagic.

Consulte `SONUS_EDIT_1.0.3_CODE13_RELATORIO.md` para o escopo e as verificações desta versão.
