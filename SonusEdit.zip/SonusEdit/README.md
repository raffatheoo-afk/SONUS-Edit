# SONUS Edit — 1.0.2 / CODE 12

Aplicativo Android para criação, legendagem e exportação automática de vídeos musicais.

## Novidades do CODE 12
- Sonus Stream: indexação limitada de metadados em segundo plano, pesquisa por título/artista/álbum e cache persistente, mantendo os códigos pCloud como identificadores internos.
- Galeria pCloud: pesquisa progressiva só encerra com pelo menos 11 correspondências exatas e não bloqueadas; miniaturas tentam renovar URLs expiradas e deixam de carregar indefinidamente.
- Áudio local: preparação imediata do ExoPlayer libera a duração para o recorte, enquanto os metadados descritivos são lidos em segundo plano.
- Histórico de imagens: identidades estáveis registradas na seleção, FIFO independente por formato (20 projetos 9:16 / 15 projetos 16:9), lista de referências por vídeo e filtro antes da exibição.
- Transições: nove novas famílias além do Fade existente (Zoom, Slide, Rise, Blur, Rotate, Push, Wipe, Parallax e Light), com no máximo quatro famílias por projeto.
- Controles por projeto: Legendas neste vídeo na etapa de sincronização e Partículas na revisão final.

## Preservações técnicas
- `applicationId`: `com.sonusstudios.sonusedit`
- `versionName`: `1.0.2`; `versionCode`: `12`
- Workflow Codemagic fixo: `sonus-edit-0-0-3-code03-debug`
- Media3 1.10.1; Whisper Small multilíngue local / ENGINE_VERSION 16; integração Link, yt-dlp e FFmpeg.
- Catálogo CODE 11 de 16 opções de fonte, rodízio de oito opções visíveis e redesign da tela inicial, Ajustes e Estatísticas foram preservados sem reimplementação.
- O workflow mantém a restauração da assinatura persistente já usada no CODE 10/11; não exige cadastro manual de identidade de assinatura no painel Codemagic.

Consulte `SONUS_EDIT_1.0.2_CODE12_RELATORIO.md` para o escopo e as verificações desta versão. O histórico do CODE 11 permanece em `CODE11_IMPLEMENTATION.md` e `SONUS_EDIT_1.0.1_CODE11_RELATORIO.md`.
