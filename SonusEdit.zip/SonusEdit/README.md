# SONUS Edit — 1.0.1 / CODE 11

Aplicativo Android para criação, legendagem e exportação automática de vídeos musicais.

## CODE 11
- Catálogo com 16 opções aprovadas (15 fontes personalizadas + Sans-serif); oito opções são exibidas por vez e o modo dinâmico considera o catálogo completo.
- Bloqueio independente de imagens recentes: 20 projetos verticais (9:16) e 15 horizontais (16:9), ativável nos Ajustes.
- Ajustes reorganizados com automações individuais, sem o controle mestre Automação Total.
- Tela inicial renovada e painel de estatísticas com identidade visual Sonus.
- Detalhes e critérios de licença das fontes em `FONT_LICENSES_CODE11.md`.

## Preservações técnicas
- `applicationId`: `com.sonusstudios.sonusedit`
- `versionName`: `1.0.1`; `versionCode`: `11`
- Workflow Codemagic fixo: `sonus-edit-0-0-3-code03-debug`
- Media3 1.10.1; Whisper Small multilíngue local / ENGINE_VERSION 16; integração Link, yt-dlp e FFmpeg.

Consulte `CODE11_IMPLEMENTATION.md` e `SONUS_EDIT_1.0.1_CODE11_RELATORIO.md` para o escopo e as verificações. O workflow Codemagic requer a keystore de assinatura persistente cadastrada como variáveis de ambiente seguras; consulte `CODE11_CODEMAGIC_SECRETS.md`.
