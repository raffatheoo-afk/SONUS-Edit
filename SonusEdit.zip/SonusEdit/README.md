# SONUS Edit — 1.0.7 / CODE 17

Aplicativo Android para criação, legendagem e exportação automática de vídeos musicais.

## Novidades do CODE 17
- Novo SONUS Link Engine em Kotlin, sem o stack de extração yt-dlp + módulo FFmpeg no APK; Whisper foi preservado.
- Importação de URLs HTTPS diretas autorizadas de áudio e vídeo, com transferência em fluxo, progresso, cancelamento e cache temporário.
- Identificação das principais plataformas sociais; páginas de plataforma exigem uma integração oficial/autorizada e não são extraídas por scraping.
- Preservação do arquivo original para evitar recodificação com perda.

## Identidade e compatibilidade
- `applicationId`: `com.sonusstudios.sonusedit`
- `versionName`: `1.0.7`; `versionCode`: `17`
- Workflow Codemagic: `sonus-edit-0-0-3-code03-debug` (ID preservado).
- A assinatura persistente original e a configuração de restauração do Codemagic foram preservadas.

## Preservações
Galeria pCloud, fontes Stream/Local/Link, Whisper Small, transições, filtros, interface, histórico, estatísticas, rascunhos e exportação foram preservados.

Consulte `CODE17_IMPLEMENTATION.md` e `CODE17_APPROVED_CHECKLIST.txt` para o escopo e as validações desta versão.
