# SONUS Edit — 1.0.6 / CODE 16

Aplicativo Android para criação, legendagem e exportação automática de vídeos musicais.

## Novidades do CODE 16
- A tela de legendas automáticas passa a exibir progresso percentual sincronizado com os checkpoints reais do Whisper e com o estimador já usado na criação normal.
- A exportação de legendas automáticas evita redimensionamentos GPU redundantes por clipe e aplica a dimensão de saída uma única vez na composição, mantendo o quadro completo e o áudio original.
- A mensagem interna de calibração 0/5 não aparece mais para o usuário; a coleta das amostras e a previsão de ETA permanecem ativas.

## Identidade e compatibilidade
- `applicationId`: `com.sonusstudios.sonusedit`
- `versionName`: `1.0.6`; `versionCode`: `16`
- Workflow Codemagic: `sonus-edit-0-0-3-code03-debug` (ID preservado).
- A assinatura persistente original e a configuração de restauração do Codemagic foram preservadas.

## Preservações desta rodada
Galeria pCloud, fontes Stream/Local/Link, Whisper Small, transições, filtros, interface geral, histórico, estatísticas e demais fluxos não foram alterados.

Consulte `CODE16_IMPLEMENTATION.md` e `CODE16_APPROVED_CHECKLIST.txt` para o escopo e as validações desta versão.
