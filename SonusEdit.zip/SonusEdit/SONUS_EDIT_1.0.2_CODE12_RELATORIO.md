# Sonus Edit 1.0.2 — CODE 12

## Base e versão
- Base de desenvolvimento: Sonus Edit 1.0.1 / CODE 11.
- `versionName`: 1.0.2.
- `versionCode`: 12.
- `applicationId`: `com.sonusstudios.sonusedit`.
- Workflow Codemagic preservado: `sonus-edit-0-0-3-code03-debug`.
- Arquivos externos de entrega: `SonusEdit.zip` e `codemagic.yaml`.

## Alterações desta versão

### Sonus Stream e metadados pCloud
- Indexação dos metadados de faixa em segundo plano, com três trabalhadores fixos e cache persistente.
- Pesquisa e apresentação priorizam título, artista e álbum; o código do arquivo permanece como identificador técnico e fallback quando não há tags.

### Galeria pCloud
- A busca cache-first só é encerrada quando há pelo menos 11 correspondências exatas e não bloqueadas segundo o mesmo matcher usado na galeria.
- Quando o cache não fornece resultados novos suficientes, a busca prossegue pelas fontes configuradas.
- URLs de miniatura e download têm validade limitada e mecanismos de invalidação/renovação.
- Falhas de miniatura deixam de manter o indicador de carregamento indefinidamente e passam a apresentar estado recuperável.

### Áudio local
- A preparação do player e a duração técnica liberam os controles de reprodução e seleção de trecho sem aguardar a leitura de tags ID3.
- A leitura descritiva dos metadados acontece em segundo plano.

### Proteção de imagens
- Identidade estável `sourcePublicCode:fileId` capturada no momento da seleção e persistida no rascunho.
- O histórico é gravado após a exportação bem-sucedida.
- FIFO independente: 20 projetos 9:16 e 15 projetos 16:9, incluindo projetos exportados sem mídia remota para manter a janela de projetos.
- Filtro aplicado antes de apresentar resultados; histórico consultável nos Ajustes por formato e agrupado por projeto, em modo somente leitura.
- Liberação progressiva de itens antigos somente quando a consulta atual tem no máximo 10 imagens frescas elegíveis.
- Revisão reativa do histórico ao retornar à galeria.

### Transições
- Fade existente preservado; duração identificada de 1.500 ms para entrada e 1.500 ms para saída, com progressão original linear.
- Nove novas famílias pareadas: Zoom, Slide, Rise, Blur, Rotate, Push, Wipe, Parallax e Light.
- Novas famílias usam a mesma duração-base de 1.500 ms, reduzida proporcionalmente para clipes com duração inferior a 3 segundos, e curvas suaves.
- Seleção individual persistente; seleção múltipla limitada a quatro famílias; modo aleatório define quatro famílias uma vez por projeto e mantém o conjunto nas mídias do projeto.
- Efeitos aplicados a imagens e vídeos, com tratamento para 9:16 e 16:9 e implementação de prévia/exportação.

### Controles por projeto
- `Legendas neste vídeo` foi movido para a etapa de sincronização/estilo; desligar interrompe a sincronização/estimativa e libera o avanço; religar reativa o processamento.
- `Partículas neste vídeo` foi movido para a revisão final e permanece ativado por padrão, com possibilidade de desativação antes da exportação.

### Sobre o Edit e versão
- Tela Sobre atualizada para 1.0.2 / CODE 12 e novidades desta versão.

## Verificações executadas neste ambiente
- `scripts/validate_v1_0_2_code12.py`: aprovado.
- YAML Codemagic: parseado com sucesso.
- Sintaxe Bash de todos os scripts do workflow (`bash -n`): aprovada.
- Teste isolado das regras puras de transições: 10 famílias, máximo de quatro por projeto, conjunto aleatório estável e extensão sem rerrolar atribuições existentes: aprovado.
- Teste isolado das regras puras de histórico: 320 imagens, 50 bloqueadas, zero liberações com amplo conjunto fresco; liberação progressiva em consulta pequena; FIFO independente de 20/15 e projeto vazio: aprovado.
- Integridade do ZIP e correspondência entre YAML externo e interno: verificados no empacotamento.

## Verificações ainda pendentes
Este ambiente não contém Gradle, Gradle Wrapper, Android SDK nem as dependências Android/Compose/Media3 necessárias. Portanto, não foi possível executar aqui:
- `:app:compileDebugKotlin`;
- `:app:testDebugUnitTest`;
- `:app:assembleDebug`.

O workflow Codemagic entregue mantém essas etapas para execução no ambiente de build. A versão só deve ser considerada validada para instalação após o Codemagic concluir compilação, testes e geração do APK e após os testes funcionais nos aparelhos-alvo.

## Segurança e assinatura
- O mecanismo histórico de restauração da keystore no próprio workflow Codemagic foi preservado para não exigir novos cadastros manuais, conforme solicitado.
- Nenhum arquivo `.jks`, `.keystore` ou `local.properties` foi incluído no ZIP.
- Como o YAML contém o mecanismo privado de assinatura incorporado, o repositório deve permanecer privado e com acesso restrito.
