# SONUS EDIT 1.0.7 / CODE 17 — SONUS Link Engine

## Objetivo
Substituir o stack grande de extração yt-dlp + módulo FFmpeg do APK por um motor de importação enxuto, implementado internamente em Kotlin, preservando a integração existente entre a fonte Link, o editor e o fluxo temporário de mídia.

## O que foi alterado
- Removidas as dependências `io.github.junkfood02.youtubedl-android:library:0.18.1` e `io.github.junkfood02.youtubedl-android:ffmpeg:0.18.1`.
- Criado `SonusLinkEngine.kt`, com classificação de fontes, validação HTTP, transferência em fluxo, progresso, cancelamento e cache temporário.
- `LinkAudioImporter.kt` permanece como fachada compatível com o restante do editor e converte o arquivo recebido em `Result` com metadados.
- O fluxo de criação só repete falhas transitórias de rede; páginas de plataformas e respostas permanentes falham imediatamente.
- Arquivos temporários com mais de 24 horas são limpos. O arquivo de uma fonte Link continua sendo removido pelo fluxo de exportação existente.
- A mídia original é mantida sem uma conversão AAC adicional. O Media3/Android continua responsável pela reprodução e pelo restante da edição.
- Whisper Android / Whisper Small foram preservados: a dependência separada fornece Whisper.cpp para reconhecimento local, não o módulo FFmpeg usado pelo antigo importador.

## Cobertura atual e limitações
O motor transfere URLs HTTPS que entregam diretamente arquivos de mídia. Para URLs de páginas, o SONUS apresenta um encaminhamento ao OpenDownloader oficial: copia o link e abre `https://opendownloader.app/` no navegador. Após concluir um download compatível, o usuário pode compartilhar o arquivo de volta para o SONUS EDIT pelo menu Compartilhar do Android. Isso é um hand-off pelo navegador, não uma API/SDK Android nem um retorno automático do arquivo.

De acordo com o FAQ público do OpenDownloader, a página web aceita links colados de YouTube, X e Twitch, além de links diretos e playlists de mídia. TikTok, Instagram, Facebook, Bilibili, Vimeo e Dailymotion exigem a extensão de navegador para computador; portanto, não são suportados por este fluxo Android. O README do projeto informa que aplicativo móvel está fora do escopo. A página web utiliza o relay do serviço por padrão, como fluxo de passagem, e declara não manter uma cópia do arquivo. Não há créditos por uso segundo a página oficial.

O SONUS não contorna login, DRM, criptografia ou controles de acesso. Links de páginas que não funcionem na página web precisam ser salvos/compartilhados por um meio autorizado ou escolhidos como arquivo local. Links diretos HTTPS continuam sendo transferidos pelo cliente nativo.

## Identidade preservada
- `applicationId`: `com.sonusstudios.sonusedit`
- `versionName`: `1.0.7`
- `versionCode`: `17`
- Workflow ID: `sonus-edit-0-0-3-code03-debug`
- Bloco de assinatura persistente do Codemagic não deve ser alterado.

## Validação
Foram adicionados testes unitários para classificação de URLs e um script estático de release. Este ambiente não tem Gradle nem Android SDK configurados; portanto, não foi produzido APK nem declarada compilação Android. A confirmação final exige o workflow do Codemagic e teste do APK em aparelho.


## Ajuste corretivo do importador (mesma versão 1.0.7 / CODE 17)
- O motor agora permite que URLs HTTPS de plataformas sigam redirecionamentos HTTP públicos normais; só aceita a resposta se ela for um arquivo de mídia compatível. Não faz scraping, não extrai streams de páginas e não contorna autenticação, DRM ou controles anti-bot.
- Quando uma plataforma responde com página HTML, 401/403 ou formato não-mídia, o fluxo apresenta uma orientação contextual e um botão para selecionar o vídeo salvo.
- O Android Sharesheet agora pode enviar URLs como texto para o SONUS EDIT, que abre o campo Link já preenchido.
- Arquivos de vídeo compartilhados por outros aplicativos agora são verificados quanto à faixa de áudio e podem ser usados como fonte sonora, além de continuarem disponíveis como mídia visual.
- `versionName`, `versionCode`, `applicationId`, chave de assinatura e identidade visual permanecem inalterados.


## Integração OpenDownloader (manutenção do mesmo CODE 17)
- Links de páginas reconhecidas apresentam a ação `ABRIR OPENDOWNLOADER` em vez de tentar uma API Cobalt inexistente no projeto Android.
- O SONUS valida o link, copia para a área de transferência e abre o site oficial no navegador.
- Depois do download pelo site, o usuário usa Compartilhar -> SONUS EDIT. O Android Sharesheet já está configurado para receber áudio e vídeo; o vídeo compartilhado pode ser usado como fonte sonora.
- O cliente e o servidor Cobalt não fazem mais parte do projeto ativo. Não há VPS, URL de gateway, chave de API ou contador de créditos necessário para esse fluxo.
- O rótulo de uso informa que o OpenDownloader não trabalha com créditos. Não representa uma contagem individual por instalação.
- O limite de plataforma é explícito: YouTube/X/Twitch via página web; TikTok/Instagram/Facebook exigem extensão de computador e não funcionam pelo hand-off Android.
- `versionName`, `versionCode`, `applicationId`, bloco de assinatura, Whisper e identidade visual permanecem inalterados.
