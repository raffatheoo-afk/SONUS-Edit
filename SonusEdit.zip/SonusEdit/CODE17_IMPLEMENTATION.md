# SONUS EDIT 1.0.7 / CODE 17 — SONUS Link Engine

## Objetivo
Substituir o stack grande de extração yt-dlp + módulo FFmpeg do APK por um motor de importação enxuto, implementado internamente em Kotlin, preservando a integração existente entre a fonte Link, o editor e o fluxo temporário de mídia.

## O que foi alterado
- Removidas as dependências `io.github.junkfood02.youtubedl-android:library:0.18.1` e `io.github.junkfood02.youtubedl-android:ffmpeg:0.18.1`.
- Criado `SonusLinkEngine.kt`, com classificação de fontes, validação HTTP, transferência em fluxo, progresso, cancelamento e cache temporário.
- `LinkAudioImporter.kt` permanece como fachada compatível com o restante do editor e converte o arquivo recebido em `Result` com metadados.
- O fluxo de criação só repete falhas transitórias de rede; páginas de plataformas e respostas permanentes falham imediatamente.
- Arquivos temporários com mais de 24 horas são limpos. O arquivo de uma fonte Link continua sendo removido pelo fluxo de exportação existente.
- A mídia original é mantida sem uma conversão AAC adicional. O Media3/Android continua responsável pela reprodução e pelo restante da edição.
- Whisper Android / Whisper Small foram preservados: a dependência separada fornece Whisper.cpp para reconhecimento local, não o módulo FFmpeg usado pelo antigo importador.

## Cobertura atual e limitações
O motor identifica páginas de YouTube/YouTube Music, TikTok, Instagram, Facebook, SoundCloud, Spotify, Vimeo e X, mas não tenta extrair suas páginas por scraping nem contornar login, DRM, tokens, assinaturas, anti-bot ou controles de acesso. O download é suportado para URLs HTTPS diretas autorizadas que entreguem uma representação de áudio/vídeo por HTTP(S). A integração de páginas de cada plataforma exige um endpoint/API oficial ou outro contrato de distribuição autorizado; esse serviço não foi fornecido neste pacote.

## Identidade preservada
- `applicationId`: `com.sonusstudios.sonusedit`
- `versionName`: `1.0.7`
- `versionCode`: `17`
- Workflow ID: `sonus-edit-0-0-3-code03-debug`
- Bloco de assinatura persistente do Codemagic não deve ser alterado.

## Validação
Foram adicionados testes unitários para classificação de URLs e um script estático de release. Este ambiente não tem Gradle nem Android SDK configurados; portanto, não foi produzido APK nem declarada compilação Android. A confirmação final exige o workflow do Codemagic e teste do APK em aparelho.
