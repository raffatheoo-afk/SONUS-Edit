# SONUS EDIT 1.0.7 / CODE 17 — SONUS Link Engine

## Objetivo
Substituir o stack grande de extração yt-dlp + módulo FFmpeg do APK por um motor de importação enxuto, implementado internamente em Kotlin, preservando a integração existente entre a fonte Link, o editor e o fluxo temporário de mídia.

## O que foi alterado
- Removidas as dependências `io.github.junkfood02.youtubedl-android:library:0.18.1` e `io.github.junkfood02.youtubedl-android:ffmpeg:0.18.1`.
- Criado `SonusLinkEngine.kt`, com classificação de fontes, validação HTTP, transferência em fluxo, progresso, cancelamento e cache temporário.
- `LinkAudioImporter.kt` permanece como fachada compatível com o restante do editor e converte o arquivo recebido em `Result` com metadados.
- O fluxo de criação só repete falhas transitórias de rede; páginas de plataformas e respostas permanentes falham imediatamente.
- Arquivos temporários com mais de 24 horas são limpos. O arquivo de uma fonte Link continua sendo removido pelo fluxo de exportação existente.
- A mídia original é mantida sem uma conversão AAC adicional. O Media3/Android continua responsável pela reprodução e pelo restante da edição.
- Whisper Android / Whisper Small foram preservados: a dependência separada fornece Whisper.cpp para reconhecimento local, não o módulo FFmpeg usado pelo antigo importador.

## Cobertura atual e limitações
O motor identifica páginas sociais e, quando `SONUS_LINK_GATEWAY_URL` está configurado, encaminha-as ao gateway SONUS que utiliza uma instância Cobalt hospedada pelo operador. O Cobalt processa somente serviços que estiverem habilitados na versão/configuração instalada e conteúdo acessível publicamente; nem todo link individual é garantido. Links diretos HTTPS continuam sendo transferidos pelo cliente nativo. O aplicativo não recebe chave Cobalt, cookies, tokens de sessão ou credenciais de plataformas e não implementa contorno de login, DRM, anti-bot ou controles de acesso. Se o gateway não estiver configurado ou a fonte não puder entregar áudio, o app oferece a seleção de um arquivo salvo/compartilhado.

## Identidade preservada
- `applicationId`: `com.sonusstudios.sonusedit`
- `versionName`: `1.0.7`
- `versionCode`: `17`
- Workflow ID: `sonus-edit-0-0-3-code03-debug`
- Bloco de assinatura persistente do Codemagic não deve ser alterado.

## Validação
Foram adicionados testes unitários para classificação de URLs e um script estático de release. Este ambiente não tem Gradle nem Android SDK configurados; portanto, não foi produzido APK nem declarada compilação Android. A confirmação final exige o workflow do Codemagic e teste do APK em aparelho.


## Ajuste corretivo do importador (mesma versão 1.0.7 / CODE 17)
- O motor agora permite que URLs HTTPS de plataformas sigam redirecionamentos HTTP públicos normais; só aceita a resposta se ela for um arquivo de mídia compatível. Não faz scraping, não extrai streams de páginas e não contorna autenticação, DRM ou controles anti-bot.
- Quando uma plataforma responde com página HTML, 401/403 ou formato não-mídia, o fluxo apresenta uma orientação contextual e um botão para selecionar o vídeo salvo.
- O Android Sharesheet agora pode enviar URLs como texto para o SONUS EDIT, que abre o campo Link já preenchido.
- Arquivos de vídeo compartilhados por outros aplicativos agora são verificados quanto à faixa de áudio e podem ser usados como fonte sonora, além de continuarem disponíveis como mídia visual.
- `versionName`, `versionCode`, `applicationId`, chave de assinatura e identidade visual permanecem inalterados.


## Integração Cobalt e contador de usos (manutenção do mesmo CODE 17)
- Links de páginas reconhecidas passam pelo `CobaltGatewayClient` quando `SONUS_LINK_GATEWAY_URL` é configurado no ambiente de build. Links diretos continuam usando o transporte HTTPS nativo do Android.
- O cliente solicita áudio no gateway SONUS, recebe o arquivo em streaming e mantém o arquivo apenas no cache temporário do aplicativo. A API key do Cobalt não é inserida no APK.
- `server/sonus-cobalt-gateway/` contém o gateway Node, implantação Docker Compose de Cobalt + gateway + Caddy, proteção por chave Cobalt e contador SQLite por instalação.
- O contador soma apenas transferências concluídas. A cota mensal padrão é ilimitada (`SONUS_MONTHLY_LIMIT=0`), mantendo a contagem total/mensal/diária; a cota pode ser configurada no servidor sem atualização do APK. O limite por IP e o limite por chave da API Cobalt continuam ativos.
- O identificador por instalação é um hash de `ANDROID_ID`; não equivale a uma conta autenticada e não deve ser usado isoladamente para faturamento/plano pago.
- Para ativar, hospedar o servidor, configurar DNS/TLS, `.env` e `keys.json`, depois definir `SONUS_LINK_GATEWAY_URL` na variável de ambiente do Codemagic antes de compilar.
- Sem o endereço de gateway configurado durante a compilação, URLs diretas continuam funcionando, mas páginas sociais não usam Cobalt.
- Não são incluídos cookies, tokens de sessão, mecanismos de login ou contorno de controles de acesso. A configuração usa conteúdo público e autorizado.
