# SONUS Edit — code17 / 0.0.17

Base: code16 / 0.0.16.

## Objetivo
Aprimorar letras e qualidade visual sem reescrever o pipeline estável de exportação.

## Letras / LRC
- Novo `LyricsMatching` compartilhado entre pCloud e LRCLIB.
- Limpeza de títulos de Link antes da busca (`Vídeo Oficial`, `Official Audio`, `Lyrics`, `Visualizer`, `HD`, `4K` etc.).
- Preserva qualificadores que realmente identificam versão (`ao vivo`, `acústico`, `remix`, `remaster`, `sped up`, `slowed`, `instrumental`, `cover`).
- LRCLIB agora faz múltiplas buscas normalizadas e ranqueia candidatos por título, artista, versão e duração.
- Duração do áudio selecionado ganha peso forte; o último timestamp do LRC pode servir como duração aproximada quando necessário.
- pCloud deixa de depender de um único nome exato: cria shortlist por título/artista/versão e, na seleção da música, compara os timestamps reais de até poucos LRCs candidatos com a duração do áudio.
- Versões explicitamente diferentes não são escolhidas silenciosamente quando a duração não confirma compatibilidade.
- Local e Link também consultam pCloud antes do fallback LRCLIB, reutilizando o mesmo resolvedor do Stream.
- Busca manual continua disponível e recebe resultados LRCLIB ordenados pela compatibilidade com a duração atual.

## Qualidade visual
- `Cinema Clean` mantém o mesmo ID interno para compatibilidade com preferências antigas, mas passa a se chamar `Cinema Natural` e usa somente ajuste real de imagem, sem véu branco/cinza.
- Imagens: primeiro são enquadradas em 9:16 mantendo a resolução de origem; depois são reamostradas com `LanczosResample` para 720p/1080p/2K/4K; filtro é aplicado depois.
- O compositor é fixado na resolução final mesmo sem partículas, garantindo canvas final consistente para overlays e texto.
- Letras, título, artista e assinatura continuam desenhados pelo `CanvasOverlay` no frame final; sombra da letra foi reduzida para ~39% de alpha e blur/offset discretos.
- Não há sharpening automático agressivo nem IA de upscale.

## Partículas preservadas
- MP4s brutos continuam sendo a fonte.
- Verde continua 60 FPS nativo; preto continua 30 FPS nativo.
- Chroma/luma key continua no motor atual.
- Após o keying, o overlay 9:16 é apenas reamostrado com Lanczos para a resolução final.
- Sem atlas, sem sprites, sem zoom/crop, sem interpolação de movimento e sem sharpen das partículas.

## Exportação preservada
- Media3 permanece 1.10.1.
- H.264/AAC, foreground service, background export, timing layer, áudio fades e fluxo salvar/abrir/compartilhar/concluir permanecem.
- FPS permanece 30/60.
- Resoluções permanecem 720p/1080p/2K/4K e 9:16.
- Workflow id de assinatura permanece `sonus-edit-0-0-3-code03-debug`.

## Validação
- Adicionado teste unitário para limpeza de título, duração por timestamp e rejeição automática de versão incompatível.
- Codemagic recebeu guards específicos da code17 para letras e qualidade visual.
- Build/aparelho real ainda devem confirmar compilação, exportação e ganho visual antes de considerar a code17 validada em produção.
