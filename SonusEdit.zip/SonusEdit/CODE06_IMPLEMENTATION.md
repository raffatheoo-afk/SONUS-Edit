# Sonus Edit 0.0.6 / code06

Base: 0.0.4 / code04 Build Fix 1 (stable base restored before reapplying improvements).

## Stability corrections
- Restored Home suggestion flow so music suggestion is not blocked by lyric synchronization.
- Version shown to users is only `0.0.6`; internal `code06` is not displayed.
- Institutional signature appears only on splash: `by SONUS STUDIOS - RΛFΛ亗`.
- Removed institutional signature from Home and Automation Settings.
- Contextual image ranking is calculated off the UI thread and only follows a committed timeline position (slider finish / fine adjustment / Smart Start), avoiding recalculation for every slider movement.

## Stream lyrics / pCloud LRC folder
Public code: `kZNiXQJZTobHXlzVPjzsj9LyASRI77DUtfJk`

New lifecycle:
1. On app opening, read/refresh only the LRC folder index (file metadata such as filename/id/path/modified/size).
2. Do not download LRC bodies while browsing the catalog.
3. The green dot is based on title/artist matching against this lightweight index.
4. Only after the user selects a Stream track for a video, download the single matched LRC.
5. Validate timestamps before accepting synchronized lyrics.
6. Cache only LRC files that were actually selected/downloaded and reuse them while the pCloud file version remains unchanged.
7. Existing SONUS synchronized source and automatic external synchronized lookup remain safe fallbacks when enabled.
8. Manual `Pesquisar letra` remains available without exposing provider names or technical details in UI.

## LRC matching safety
- Normalize accents, case, punctuation and separators.
- Prefer exact title+artist filename matches.
- Accept title-only filename only when unambiguous.
- Use folder artist context when available.
- Do not guess between equal-strength ambiguous matches.

## Contextual images
- Title and genre anchor the song context.
- Synchronized lyric text refines each image slot around the selected segment.
- Expensive ranking runs on `Dispatchers.Default`.
- Slider movement itself only seeks audio; image reranking occurs when movement is committed.

## Preserved from code04
- Persistent signing behavior.
- Two-source Stream catalog.
- Smart Start.
- 15s manual-only rule.
- 30/40/50/60/65/90/120 automatic durations.
- Timeline minimum 5s/image and fade rules.
- 9:16 visual orientation validation.
- 720p/1080p/2K/4K and 30/60/90 FPS options.
- Existing filters, fonts, effects, metadata overlay, user signature and export flow.
