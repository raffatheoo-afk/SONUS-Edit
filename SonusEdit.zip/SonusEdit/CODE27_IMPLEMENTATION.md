# SONUS Edit 1.3 / versionCode 27 — atualização do cronômetro de legendas

## Escopo autorizado
Ajuste cirúrgico sobre o source **1.2 / code26**, instalado e aprovado pelo usuário.

- Pill de estado da legenda ampliada de 168 para 190 dp, preservando os textos e estados da versão anterior.
- Countdown pequeno à esquerda, seguido pelo spinner circular existente e pelos textos `AGUARDE...` / `SINCRONIZANDO`. Quando fica verde `🟢 SINCRONIZADA`, cronômetro e spinner desaparecem.
- Tempo inicial estimado a partir da medição fornecida pelo usuário: 60 segundos de áudio ≈ 184 segundos de processamento (3min04s). Presets: 15s → 46s, 30s → 92s, 40s → 123s, 50s → 153s, 60s → 184s, 65s → 199s.
- Usa duração real do corte manual, não apenas presets.
- Começa a contar na Gallery assim que `startCaptionIfNeeded()` inicia; ao entrar em Estilo desconta o tempo passado.
- Atualiza a cada segundo, com `SystemClock.elapsedRealtime()` (relógio monotônico).
- Atualiza a estimativa após conclusão real de janelas do Whisper. Novo campo **`Progress.processedAudioMs`**, sem misturar o percentual de download do modelo com o andamento do áudio.
- Se o Whisper Small precisar ser baixado pela primeira vez, estimativa mostra `--:--` durante o download (tempo de rede desconhecido). O relógio reinicia após o download ao começar o processamento.
- Se o tempo previsto for ultrapassado, mostra `--:--` enquanto a animação continua, evitando `00:00` congelado e falsas garantias.
- Ao cancelar/trocar trecho, limpa medidas da legenda antiga e exige correspondência de geração, preservando a proteção code26.
- Cores, filtros, Home, Premium, Gallery, efeitos internos/pCloud, assinatura, projeto e exportador NÃO alterados.

## Arquivos modificados
- `BUILD_VERSION.txt`
- `app/build.gradle.kts`
- `app/src/main/java/com/sonusstudios/sonusedit/ui/HomeScreen.kt` (somente rótulo de versão)
- `app/src/main/java/com/sonusstudios/sonusedit/ui/CreateFlowScreen18.kt`
- `app/src/main/java/com/sonusstudios/sonusedit/create/WhisperCaptionEngine.kt` (somente metadados de progresso)
- `codemagic.yaml` (versão e guards)

## Arquivos adicionados
- `app/src/main/java/com/sonusstudios/sonusedit/create/CaptionEtaEstimator13.kt`
- `app/src/test/java/com/sonusstudios/sonusedit/create/Code27CaptionEtaTest.kt`
- `scripts/validate_v1_3_code27.py`
- este relatório

## Validação e limitações
- Guards estáticos da 1.2 e 1.3: PASS.
- Testes com `kotlinc` (estimativas e contagem inicial, projeção por progresso, expiração, saída hh:mm:ss): PASS.
- Hash dos dois MP4s internos preservado em byte a byte.
- `codemagic.yaml` preserva signer persistente: se estiver ausente, falha em vez de criar outro.
- Necessário executar `:app:compileDebugKotlin`, `:app:testDebugUnitTest`, `:app:assembleDebug` no Codemagic.
- Não há SDK Android completo local para compilar APK; **não declarar build ou teste em aparelho realizados**.
- Os tempos apresentados são estimativas e variam por áudio, carregamento do modelo, temperatura, aparelho e carga de processamento.
