# CODE 12 — Build fix 2 (20/11/2026)

## Cause
Codemagic reached `:app:compileDebugKotlin` and reported two unresolved references to `fillMaxHeight` in `CreateFlowScreen18.kt` (the Wipe and Light transition preview overlays).

## Correction
Added the missing Compose extension import:
`androidx.compose.foundation.layout.fillMaxHeight`

No UI layout, animation, export behavior, signing logic, workflow step, or application behavior was changed. Both existing `Modifier.fillMaxHeight()` call sites now resolve to the Compose Foundation layout extension.

## Verification limitation
The current container has Java but no Gradle executable, Gradle Wrapper, or Android SDK, so a local Android Kotlin compilation cannot be performed here. The previous Codemagic log reports only these two Kotlin compilation errors. The static validator, YAML parsing, shell syntax, and ZIP integrity are checked during repackaging. A new Codemagic run is required to confirm `compileDebugKotlin`, unit tests, and APK assembly.
