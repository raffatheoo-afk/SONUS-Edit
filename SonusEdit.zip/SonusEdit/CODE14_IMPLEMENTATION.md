# Sonus Edit 1.0.4 / CODE 14

Base: Sonus Edit 1.0.3 / CODE 13.

## CODE 14 changes
- Remote gallery selections now use `sourcePublicCode:fileId` as the authoritative URL-map key through draft persistence and successful-export history.
- CODE 13 draft URLs are migrated only when the old fileId mapping is unambiguous; ambiguous selected media are re-resolved against the active catalog by stable key.
- pCloud catalog parsing accepts the documented boolean/numeric folder flags and rejects malformed root metadata rather than treating it as a successful empty catalog.
- Gallery request generations prevent late results from an older identical query overwriting the latest request.
- Caption request identity prevents duplicate Whisper jobs for the same audio URI and trim. Explicit track/trim/enable changes invalidate the prior identity. The existing ETA estimator and Whisper engine configuration are preserved.
- Caption status panel keeps the countdown and spinner and adds a larger centered percentage with a compact horizontal red/yellow/green progress bar.
- Added regression tests for stable image identity, caption request idempotency, pCloud folder flags, and stale gallery requests.
- Export metadata policy remains unchanged; CODE 14 adds regression coverage for intentionally cleared title and artist fields.

## Explicitly preserved
- CODE 13 Stream metadata search and metadata mapper.
- CODE 13 contextual keyword catalog and manual gallery search behavior.
- Image cooldown limits: 20 vertical projects and 15 horizontal projects.
- Existing transition/export pipeline.
- Existing Whisper Small model, language handling, and `CaptionEtaEstimator14` calculation.
- Original Codemagic workflow and embedded persistent signing mechanism.
