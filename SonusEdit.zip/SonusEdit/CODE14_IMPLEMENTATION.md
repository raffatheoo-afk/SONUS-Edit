# SONUS Edit 0.0.14 / code14

Base: 0.0.13 / code13.

## Raw particle engine
- Removed the old atlas renderer and every synthetic style (Arco-íris, Brilhante, Vagalume, Estrela, Glitter).
- Removed `effect_particles_source.webp` and `effect_particles_source_alt.webp`.
- Added the two user-provided original 9:16 MP4 sources as independent effects; they are NEVER mixed.
- Bundled compact ~60 second excerpts selected for a subtle loop seam instead of carrying 121 seconds of each source.
- Black source loop excerpt: approximately 27s -> 87s. Green source loop excerpt: approximately 41s -> 101s.
- Both cuts use `-c copy` with audio removed: no video re-encode, so the original H.264 frames, resolution, bitrate and cadence are preserved.
- Exports longer than one excerpt concatenate the same ~60s effect segment until the requested duration is covered (maximum 120s). No cross-blend or synthetic interpolation is added at the loop boundary.
- Green original: 1080x1920, ~60 fps, GPU chroma key around the measured green background, soft edge, neutral-white output to eliminate green spill.
- Black original: 720x1280, ~30 fps, GPU luma key / screen-like alpha removal.
- `RawParticleVideoEffect` runs as a lightweight Media3 GlEffect; no CPU bitmap extraction and no frame interpolation.
- A transparent 9:16 timing sequence is registered first at the selected output FPS (30/60/90). It is alpha=0 and never visible.
- The raw particle video is registered second and the main image sequence third. Media3 composites earlier registered video sources above later ones, so particles stay above the main image while the transparent timing source drives output cadence.
- Effect source is 9:16 and uses `Presentation.LAYOUT_SCALE_TO_FIT`: only proportional resolution scaling, no crop, no cover zoom and no stretching.
- 60/90 fps exports do not synthesize fake particle motion. Output cadence follows the transparent timing source; secondary particle frames are reused between native source frames instead of blended/interpolated.

## Automatic effect choices
- Dynamic
- Original 60 FPS
- Original 30 FPS

Dynamic rotates the two sources without mixing them in one export.

## Signature color UI
- Replaced tiny color dots with full-width color sample buttons.
- White button = white surface + black label.
- Yellow button = yellow surface + black label.
- Black button = black surface + white label.
- Selected color receives a 2dp cyan border; unselected receives a 1dp muted border.
- Equal-width 42dp buttons preserve readability on small phones.

## Preserved from code13
- New lyric fonts.
- Fixed/dynamic lyric colors.
- Independent signature fonts/colors.
- Sonus Gallery search.
- Stable image timing/fades, lyrics, metadata, export validation and persistent signer lineage.
