# SONUS Edit 0.0.14 / code14 — build fix 1

Correções de compilação Kotlin após o primeiro build Codemagic:

- `RawParticleKeyShaderProgram` deixou de ser `private-in-file`, evitando exposição de tipo privado pelo `GlEffect`.
- `toGlShaderProgram` agora possui corpo e retorno `GlShaderProgram` explícitos.
- Estado `automaticEffectId` usa `mutableStateOf<String>(EffectIds.RAW_GREEN_60)` explicitamente.
- Qualquer referência residual a `EffectIds.STAR` permanece proibida pelo validador do Codemagic.

Nenhuma alteração foi feita na arquitetura visual da code14, nos MP4s de efeito, no loop, chroma/luma key, proporção 9:16, fontes, legendas, Gallery ou assinatura.
