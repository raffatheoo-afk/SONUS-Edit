# Sonus Edit — 0.0.5 / Code 05

## Escopo aplicado

- Versão do aplicativo atualizada para `0.0.5` / `versionCode 5`.
- Nova tela **Sobre o Sonus Edit**, acessível em Ajustes, com histórico de novidades por versão.
- Revisão de legendas automáticas: pausa ao iniciar a correção e retoma do ponto salvo somente depois de salvar e somente quando a reprodução estava ativa antes da edição. Cancelar/fechar mantém a reprodução pausada.
- Renderização das legendas: busca eficiente do último trecho ativo, inclusive quando há tempos sobrepostos, preservando a apresentação na prévia/exportação sem alterar o motor Whisper.
- Estatísticas e Ajustes com cabeçalhos, agrupamentos e apresentação visual modernizados, preservando opções e funções existentes.
- Galeria: histórico de 15 projetos concluídos; bloqueio das mídias recentes e liberação progressiva das mais antigas somente para cobrir a insuficiência do catálogo.
- Galeria: contador de catálogo, disponíveis, bloqueadas, liberadas por insuficiência e vídeos considerados no histórico.
- Pesquisa da Galeria: estado imediato de busca e publicação incremental dos resultados à medida que cada pasta pública responde; o catálogo continua sendo atualizado até o fim da consulta.
- Mídias de vídeo identificadas com o selo **VÍDEO**.
- Planos Edit Free, Creator, Pro e Studio apresentados como proposta, com preços/benefícios planejados. Nenhuma cobrança, cota, limitação ou bloqueio foi ativado; recursos atuais permanecem liberados.

## Valores exibidos (ainda não ativos)

- Edit Free: grátis, 20 vídeos/mês, efeitos internos, até 720p e catálogo padrão.
- Edit Creator: R$ 2,90/mês, 50 vídeos/mês, efeitos internos, até 1080p e catálogo padrão.
- Edit Pro: R$ 5,90/mês, 100 vídeos/mês, efeitos internos e da nuvem, até 2K e catálogo padrão.
- Edit Studio: R$ 9,90/mês, vídeos ilimitados*, todos os efeitos, até 4K e catálogo completo com servidor exclusivo futuro.

O asterisco do Studio explica que serviços de nuvem poderão ter política de uso justo transparente; edição e exportação locais não devem ser artificialmente limitadas.

## Contratos preservados

- Package `com.sonusstudios.sonusedit`.
- Workflow ID `sonus-edit-0-0-3-code03-debug` (mantido por compatibilidade).
- Chave permanente de assinatura e respectivo material do Codemagic, sem regeneração.
- Media3 1.10.1 e regra do compositor: somente para múltiplas faixas de vídeo; faixa única mantém Presentation final.
- Whisper Small / ENGINE_VERSION 16 sem alteração do motor ou quantização.
- Dependências e integrações existentes de Link, yt-dlp e FFmpeg mantidas.

## Validação desta entrega

- Validador estático `scripts/validate_v0_0_5_code05.py`: aprovado no ambiente de preparação.
- Estrutura YAML do Codemagic: parseada com sucesso; workflow ID preservado.
- Compilação Android e testes Gradle: pendentes de execução no Codemagic, pois este ambiente não contém wrapper Gradle nem Android SDK configurado.
- A aprovação do validador estático não substitui a compilação, testes instrumentados nem teste de uso em aparelho.
