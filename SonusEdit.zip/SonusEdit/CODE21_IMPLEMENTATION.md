# SONUS Edit 0.0.21 / code21

Correção cirúrgica autorizada após teste real da code20.

## Escopo

1. **Sonus Gallery / pCloud**
   - Mantém a corrida `api.pcloud.com` / `eapi.pcloud.com` apenas para a leitura fria do catálogo.
   - Uma região só é aceita como vencedora quando a resposta pCloud é semanticamente válida, não apenas HTTP 200.
   - `getpubthumblink` e `getpublinkdownload` validam `result`, `hosts` e `path`; uma resposta 200 inválida cai imediatamente para a outra região.
   - URLs válidas são cacheadas localmente em memória por repositório.
   - Resolução de URLs é limitada a 6 operações concorrentes para evitar saturar o pCloud.
   - Cards usam `stableKey + repository`, evitando colisão de `fileId` ao alternar 9:16/16:9.
   - Se a miniatura falhar no CDN, o card tenta o URL de download real antes de desistir.

2. **Partículas 16:9**
   - Mantém os mesmos MP4s verticais aprovados, byte-for-byte.
   - 9:16 permanece inalterado.
   - 16:9 aplica chroma/luma no frame original, faz center-crop para o aspecto horizontal e só então reamostra para a resolução final.
   - Nenhum asset horizontal novo, reencode, esticamento ou interpolação de movimento.

## Intencionalmente não alterado
- yt-dlp / FFmpeg e a leitura de Link.
- Whisper Base e pipeline de legendas.
- filtros, assinatura e banco Artista → Categoria.
- resoluções, 30/60 FPS e exportação.
- duração dos MP4s de partículas.
- Media3 1.10.1 e assinatura persistente.
