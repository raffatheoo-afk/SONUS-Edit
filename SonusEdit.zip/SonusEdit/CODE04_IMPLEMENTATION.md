# Sonus Edit 0.0.4 / code04

## Alterações

- Corrigida a reprodução do trecho: o limite `playbackEndMs`, antes definido mas não monitorado, agora encerra a prévia no final escolhido.
- Os controles INÍCIO e FINAL alternam corretamente entre reprodução completa do trecho e prévia dos últimos cinco segundos.
- Ajustes finos e arraste da faixa fazem o áudio acompanhar o novo ponto sem pausar.
- A tela de revisão ganhou um controle de legenda específico do vídeo atual; a preferência global permanece independente.
- A escolha local de legenda é persistida no rascunho.
- A galeria mostra o número da pasta de origem e oferece uma lista ordenada das seleções com remoção individual.
- Miniaturas em cache começam a ser aquecidas em segundo plano, com placeholders durante o carregamento.
- Em erro de memória comprovado numa exportação 4K, a recuperação pula a tentativa redundante em 4K/30 e segue diretamente para 2K/30. Outros erros mantêm o fluxo de fallback existente.

## Testes/limitações

- `scripts/validate_v0_0_4_code04.py`: aprovado.
- YAML validado por parser.
- `TrimPreviewPlanner04.kt`: compilado isoladamente com `kotlinc`.
- Testes JUnit e compilação Android ainda precisam rodar no Codemagic. Não há Android SDK nem Gradle Wrapper no ambiente de edição.
- O diagnóstico definitivo de falhas de encoder 4K que não sejam OutOfMemoryError depende do log do build/export no aparelho; não se deve interpretar o fallback como prova de limitação permanente do hardware.
