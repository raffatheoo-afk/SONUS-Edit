# SONUS Edit 1.6 / code30 — Fontes de legenda e relógio digital

## Fontes de legenda
- Checagem de todas as 35 fontes embutidas com o texto "Calça ÇÃO Coração áéíóú âêô õü ì": mapa de caracteres, contorno dos glifos e renderização.
- **19 fontes reprovadas e removidas** (arquivos apagados): Roomboy, Casa Pinada, Tharon, Different Sunset, Jabawoky, Milliwatts, Florida Orange, Deep Abyss, Folders, MyLove, My Kids Handwritten, I Love January, The Absolute, On The Way, Unforgotten More, Panterick Swash, Gambler in Town, Oliver Richards e Regular Joe.
  - Sem as letras acentuadas: o Android usava outra fonte para o "Ç", fora do tema.
  - Glifo existe mas vazio: o acento/cedilha sumia na exportação.
  - Letra desenhada sem o acento: "Calça" saía "Calca".
  - Panterick Swash só desenha arabescos e não forma palavras legíveis.
- **16 fontes aprovadas**: Magic Clover, Impact Stone, The Brother Hoops, Paint Brush Script, Always Lovely, Rocky, Elione, Rocky Brush Italic, Rocky Brush, Valid Harmony, Adelicius, Gloverley, Kabut Hitam, Epicentrum, Fake Serif e Baar Sophia.
- `CaptionFontPool.approved` é a única origem das oito fontes da grade, da fonte inicial aleatória e do botão **Fonte dinâmica**. Favoritos de automação são filtrados pelo mesmo pool.
- Os ids das 19 fontes removidas continuam no enum `FontPresetId` apenas para abrir rascunhos/favoritos antigos sem erro; `effective()` troca cada uma por uma fonte aprovada de estilo parecido, na prévia e na exportação do vídeo.
- Sans-serif, Serif e os oito presets antigos (fontes do sistema) continuam existindo, mas não entram mais no sorteio.

## Relógio do contador
- Fonte DS-Digital Bold (estilo relógio digital) em `assets/ui_fonts`, usada somente no contador "ESTIMADO". O arquivo original não foi modificado e o `DIGITAL.TXT` do autor acompanha a fonte.
- Tamanho 11 sp → 16 sp (a fonte digital tem dígitos mais baixos), largura mínima fixa para o bloco não "andar" quando muda o dígito 1, relógio deslocado para a esquerda; texto AGUARDE/SINCRONIZANDO centralizado no espaço restante. Nada sai do bloco vermelho.
- Os estados LEGENDA OFF, ERRO e SINCRONIZADA mantêm o layout centralizado de antes.

## Validação
- `scripts/validate_v1_6_code30.py` (versão 1.6/30, 16 fontes, pool, mapeamento, relógio) e `codemagic.yaml` atualizados.
- Testes unitários: `Code30CaptionFontPoolTest` novo; `Code29FontAndImageRotationTest` ajustado para 16 fontes com arquivo.
- A validação estática não substitui compilação Android nem teste em aparelho real. Rodar o Codemagic e conferir a legenda com "ç ã á â é ê í ó ô õ ú ü" nas 16 fontes e o relógio durante a sincronização.

## Licença da fonte do relógio
- DS-Digital (Dusit Supasawat) é shareware: US$ 20 uso pessoal e US$ 45 uso comercial, conforme o `DIGITAL.TXT`. Para publicar o app, registrar a licença comercial com o autor.
