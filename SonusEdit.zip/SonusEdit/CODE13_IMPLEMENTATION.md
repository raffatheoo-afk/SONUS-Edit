# Sonus Edit 0.0.13 / code13

Base: reconstructed 0.0.12 / code12 stable behavior.

## Caption fonts
Visible collection:
- Patrick Hand
- Concert One
- Amatic SC
- Rancho
- Sheila Crayon
- Schoolwork-Regular
- Alley Garden
- Playball

The internal enum ids were deliberately kept stable to preserve saved favorites from earlier versions. No external/dubious font binaries are bundled; Android system-safe visual equivalents are used for rendering where a licensed binary is not part of the project.

## Caption colors
Added independent `LyricColorPreset`:
- Dinâmico
- Branco
- Amarelo
- Laranja
- Vermelho
- Rosa
- Roxo
- Azul
- Ciano
- Verde

Dynamic mode preserves the rotating per-line palette. Fixed modes keep the selected color for all lyric lines.

## Signature
Signature styling is independent from lyric styling.
Fonts:
- Patrick Hand
- Rancho
- Playball

Colors:
- Branco
- Amarelo
- Preto

Saved signature defaults now retain text, image, font, and color.

## Sonus Gallery search
A search icon now sits beside the Sonus Gallery button. It opens a direct catalog search that matches loaded image names, folders, and genre metadata. Search scans the whole loaded catalog rather than only the first displayed thumbnails.

## Particle refinement
The code12 120-frame/30-fps geometry remains unchanged. Code13 only refines appearance:
- Arco-íris: slow temporal color morph, no hard vertical color bands;
- Brilhante: soft warm halo plus white luminous core;
- Vagalume: warm gold core with subtle green halo and slow breathing;
- Estrela: cool halo, neutral white core, restrained twinkle;
- Glitter: softer pink/cyan/white shimmer without rapid strobing.

All styles continue to respect the configured intensity (30/50/100%).
