# CODE17 — Build Fix 2 (Gradle Kotlin DSL font downloader)

Date: 2026-11-28

## Reported failure

Codemagic reached `Compile debug Kotlin`, then Gradle failed while compiling `app/build.gradle.kts` with unresolved references for `java.net`, `java.io`, `connectTimeout`, `readTimeout`, `setRequestProperty`, and inferred `use` lambda parameters.

## Root cause

In a Gradle Kotlin DSL script, the unqualified identifier `java` can resolve to the Gradle Java extension/accessor rather than the Java package. Expressions such as `java.net.URL(...)` and `java.io.File(...)` therefore fail during script compilation. The later property and lambda type errors are cascading errors from the unresolved connection/file types.

## Correction

- Added explicit imports for `java.io.File`, `java.net.URL`, `java.net.URLConnection`, and `java.net.HttpURLConnection`.
- Replaced ambiguous fully-qualified package expressions with the imported types.
- Explicitly typed the connection as `URLConnection`, which gives Kotlin the correct Java API for timeout and request-property methods.
- Preserved download timeouts, temporary `.part` file handling, header validation, license retrieval, and font verification.
- Extended `scripts/validate_v1_0_7_code17.py` with regression guards so the ambiguous expressions cannot be reintroduced unnoticed.

## Validation

- CODE17 static validation: passed.
- Isolated Kotlin compilation of the corrected font-download function using the local Kotlin compiler: passed (one deprecation warning for `URL(String)`, not an error).
- YAML syntax: checked separately.
- Full Android Gradle build: not executed in this environment because Gradle/Android SDK are not installed here and network access to download the Gradle distribution is unavailable. Codemagic must run the full build.

## Preserved

- `versionName=1.0.7`, `versionCode=17`, `applicationId=com.sonusstudios.sonusedit`.
- Existing importers, Whisper, Media3, project source, and signing flow are unchanged by this build-script correction.
