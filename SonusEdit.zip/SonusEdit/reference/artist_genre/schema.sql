CREATE TABLE artists (
  id INTEGER PRIMARY KEY,
  artist TEXT NOT NULL,
  normalized_name TEXT NOT NULL UNIQUE,
  category TEXT NOT NULL,
  image_keyword TEXT NOT NULL,
  secondary_keywords TEXT,
  confidence TEXT NOT NULL,
  source TEXT NOT NULL
);
CREATE INDEX idx_artists_normalized ON artists(normalized_name);
CREATE INDEX idx_artists_category ON artists(category);

CREATE TABLE aliases (
  id INTEGER PRIMARY KEY,
  alias TEXT NOT NULL,
  normalized_alias TEXT NOT NULL UNIQUE,
  canonical_normalized TEXT NOT NULL,
  category TEXT NOT NULL
);
CREATE INDEX idx_alias_normalized ON aliases(normalized_alias);
