# SONUS Edit 0.0.2 / code02 — correções de exportação, tamanho e posição da legenda, proporções

A chave de assinatura é a mesma da 0.0.1 (embutida no `codemagic.yaml`; o validador confere o SHA-256 do arquivo da chave).

## Exportação
- **Causa do erro da Legendas automáticas** ("SingleInputVideoGraph does not use VideoCompositor…"): o exportador sempre configurava o compositor de vídeo, que só existe quando há mais de uma faixa de vídeo (partículas). Sem partículas o Media3 usa uma faixa só e recusa a configuração. Agora o compositor só é ligado com partículas; sem elas o tamanho exato de saída é travado por uma `Presentation` final antes do overlay. O caminho com partículas ficou igual. O mesmo erro também ocorria nas outras funções com Partículas desativadas.
- **Celulares básicos (`ExportCapabilities02`)**: o app lê o que o codificador H.264 do aparelho realmente suporta (tamanho, 30/60 FPS, alinhamento) e desliga as opções que ele não entrega. Uma escolha indisponível (ex.: 1080p 60 FPS) é rebaixada antes de falhar. Aparelhos que suportam tudo (como o S10e) não mudam. Aparelho com pouca RAM só oferece até 1080p.
- **Escada de qualidade (`ExportFallbackLadder02`)**: se a exportação falha por motivo que uma exportação mais leve resolve (codificador, resolução, memória), o app tenta de novo sozinho em 60→30 FPS e depois em resolução menor, avisando na tela. Erros que isso não resolve (arquivo ausente, cancelado) aparecem normalmente. A trava que recusa vídeo com tamanho/FPS diferente do pedido continua.
- Arquivo parcial é apagado quando a exportação curta falha (menos lixo em celulares com pouco espaço).
- Mensagem de erro em português, com botão **Copiar detalhes** para o texto técnico.
- Legendas automáticas não apaga mais o rascunho do fluxo de criação ao terminar a exportação.

## Proporções
- Novas: 1:1, 4:5 e 3:4. Na primeira tela: 9:16 | 16:9 | **Outra proporção** (abre as demais e volta mostrando a escolhida). Os tamanhos de 9:16 e 16:9 não mudaram; as demais mantêm o lado menor da resolução, sempre com números pares. Partículas são cortadas ao centro nas proporções diferentes de 9:16.
- **Legendas automáticas** exporta no formato e tamanho originais do vídeo (ajustado para baixo, com lados alinhados, só se o codificador do aparelho não alcança). A tela mostra "Original • largura×altura • FPS" e o botão exportar, sem 720/1080/2K/4K nem FPS.

## Legenda
- Todos os estilos partem do mesmo tamanho pequeno. Barra de **tamanho** (minúsculo a extra grande) e barra de **posição** livre (do rodapé ao topo), azuis e mais finas que a barra roxa do player; o texto sempre é reduzido para caber na área segura (largura e altura).
- As barras ficam na última tela, abaixo da barra de progresso do vídeo e acima de Qualidade/FPS, tanto em Legendas automáticas quanto no fluxo de criação. Qualidade e FPS ficaram mais baixos. O último tamanho, posição e estilo escolhido à mão são lembrados.
- Legendas automáticas: título do topo removido, botões Topo/Meio/Embaixo removidos (a posição agora é a barra), sem assinaturas (nome da música/cantor).

## Validação
- `scripts/validate_v0_0_2_code02.py`, `codemagic.yaml` e o teste `Code02ExportAndRatiosTest` (tamanhos por proporção, escada de qualidade).
- A validação estática não substitui a compilação Android nem o teste em aparelho.
