# Codemagic — variáveis seguras necessárias

O workflow CODE 11 não contém mais keystore, senha ou chave privada embutida no YAML. Para manter a assinatura compatível com instalações existentes, configure no Codemagic as seguintes variáveis como **Secret** usando os mesmos dados da keystore persistente original do Sonus Edit:

- `SONUS_KEYSTORE_BASE64` — conteúdo Base64 da keystore original (`sonus-edit-dev.jks`).
- `SONUS_KEYSTORE_PASSWORD` — senha do armazenamento.
- `SONUS_KEY_ALIAS` — alias original (`sonusedit`).
- `SONUS_KEY_PASSWORD` — senha da chave.

Não gere uma nova keystore para substituir a original: isso pode impedir a instalação da atualização sobre a versão já instalada. O workflow falha explicitamente se alguma variável estiver ausente ou se a keystore/alias não puderem ser abertos. Nunca inclua `.jks` no ZIP do projeto ou no repositório.
