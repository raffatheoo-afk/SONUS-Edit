# Codemagic — assinatura persistente do Sonus Edit CODE 11

O log recebido mostra que o CODE 11 passou pela validação estática, mas interrompeu antes do Gradle porque `SONUS_KEYSTORE_BASE64` não estava configurada. O workflow foi ajustado para usar o recurso nativo **Code signing identities** do Codemagic.

## Configuração única necessária

1. Baixe o arquivo separado `sonus-edit-dev.jks` fornecido junto desta correção. Ele contém a mesma keystore persistente usada pelo workflow antigo CODE 03.
2. No Codemagic, abra **Team settings → codemagic.yaml settings → Code signing identities → Android keystores**.
3. Envie `sonus-edit-dev.jks`.
4. Informe a senha do keystore, o alias e a senha da chave exatamente como no workflow antigo CODE 10. O alias histórico é `sonusedit`.
5. Defina o **Reference name** exatamente como `sonus-edit-persistent` e salve.
6. Faça um novo build usando o `codemagic.yaml` atualizado.

O YAML já referencia `sonus-edit-persistent` em `environment.android_signing`. O Codemagic disponibiliza `CM_KEYSTORE_PATH`, `CM_KEYSTORE_PASSWORD`, `CM_KEY_ALIAS` e `CM_KEY_PASSWORD`; o passo de assinatura valida a keystore e os encaminha ao Gradle com os nomes `SONUS_*` esperados pelo projeto.

## Segurança e compatibilidade

- A keystore NÃO está incluída no `SonusEdit.zip` nem no repositório do projeto.
- Guarde uma cópia privada e segura do `.jks`; o Codemagic não permite baixar novamente a keystore cadastrada.
- Não gere uma keystore nova: isso altera a assinatura e pode impedir a instalação da atualização sobre a versão existente.
- Não publique o `.jks`, senhas ou capturas que revelem esses dados.

## Diagnóstico do build anterior

`SONUS_KEYSTORE_BASE64: Configure SONUS_KEYSTORE_BASE64 in Codemagic secure environment variables` significa somente que a variável esperada pelo workflow anterior não existia no ambiente do build. Não é um erro de compilação Kotlin, Gradle ou JUnit.
