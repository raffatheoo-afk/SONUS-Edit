# Codemagic — assinatura persistente do Sonus Edit CODE 11

O CODE 11 restaura o mesmo mecanismo de assinatura usado no CODE 10. O workflow recria a keystore a partir do Base64 armazenado no próprio `codemagic.yaml`, valida o alias com `keytool` e exporta as variáveis esperadas pelo Gradle.

## Configuração necessária no painel
Nenhuma. Não é necessário cadastrar `sonus-edit-persistent`, criar variáveis secretas ou preencher campos em Code signing identities. Basta atualizar o repositório com o `codemagic.yaml` fornecido e iniciar o build.

## Compatibilidade e segurança
- É utilizada a mesma keystore persistente histórica, com o alias original `sonusedit`; não é gerada uma chave nova.
- O arquivo `.jks` não é incluído separadamente no ZIP.
- Atenção: como a chave e as senhas estão embutidas no YAML, qualquer pessoa com acesso ao repositório/arquivo pode extraí-las. Mantenha o repositório privado e controle rigorosamente quem pode ler o YAML. Esta opção foi mantida a pedido do usuário para preservar o fluxo anterior sem configuração manual.
