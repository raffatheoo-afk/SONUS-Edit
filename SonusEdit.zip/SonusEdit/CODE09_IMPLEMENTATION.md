# Sonus Edit 0.0.9 / code09

- Legendas ~8% menores; assinatura pessoal e metadata ~4% menores, mantendo posições.
- Favoritos de fontes e filtros usam shuffle bag persistente: todas as opções favoritas rodam antes de repetir.
- Efeitos usam os 13 assets aprovados em shuffle bag persistente, sem repetição até completar o ciclo.
- Seleção de efeito é estável por projeto/nonce para recomposições não consumirem o histórico.
- Efeitos mais delicados: escala visual 92% e intensidades Suave 0.40 / Equilibrada 0.56 / Marcante 0.72.
- Preserva code08: letras seguras, revisão compacta, exportação em segundo plano, Home/Stream/LRC, título+gênero para imagens e assinatura persistente.
