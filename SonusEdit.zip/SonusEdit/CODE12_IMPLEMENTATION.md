# Sonus Edit 0.0.12 / code12

Base oficial: code11 estável.

## Objetivo
Suavizar e naturalizar o overlay de partículas do Sonus Edit, mantendo o mesmo efeito visual aprovado e sem zoom no overlay.

## O que mudou
- Novo atlas principal gerado a partir do vídeo com fundo preto já tratado, em 9:16.
- Novo atlas alternativo gerado a partir do vídeo com fundo verde, processado individualmente com chroma key mais conservador.
- O app usa o atlas principal `effect_particles_source.webp` como fonte ativa.
- O atlas alternativo `effect_particles_source_alt.webp` fica no projeto como referência de processamento/backup.
- Loop animado agora usa 120 frames (4 segundos a 30 FPS) em vez de 60 frames a 6 FPS.
- O overlay continua cobrindo a tela inteira em 9:16 sem aplicar zoom/crop adicional.
- Mantidas as variações Arco-íris, Brilhante, Vagalume, Estrela e Glitter.
- Mantida a legenda 5% menor do ajuste anterior.

## Parâmetros técnicos do atlas ativo
- Colunas: 12
- Linhas: 10
- Frames: 120
- FPS do efeito: 30
- Tamanho do atlas: 3240 x 4800
- Tamanho de cada célula: 270 x 480

## Resultado esperado
- Movimento mais fluido mesmo quando a exportação final estiver em 720p / 30 FPS.
- Partículas cobrindo todo o quadro 9:16, inclusive bordas.
- Menos sensação de bolinhas “pulando” ou “teletransportando”.
