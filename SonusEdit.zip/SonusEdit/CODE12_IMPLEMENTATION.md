# Sonus Edit 0.0.12 / code12 — reconstructed stable baseline

Base: 0.0.11 / code11.

The code12 stability changes are preserved in code13:
- particle atlas doubled from 60 frames / 6 fps to 120 frames / 30 fps;
- atlas grid 12 x 10, 270 x 480 per cell, final 3240 x 4800;
- direct 9:16 full-frame overlay with no zoom/crop transform;
- `effect_particles_source.webp` remains the active source;
- `effect_particles_source_alt.webp` is retained as an alternate/fallback asset;
- automatic intensity continues to use 30%, 50%, and 100%;
- lyric maximum size remains calibrated ~5% below the older code11 value (`0.03881f`).
