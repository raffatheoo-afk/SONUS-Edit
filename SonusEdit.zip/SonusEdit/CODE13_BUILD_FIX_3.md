# CODE 13 — correção dos dois testes unitários

## Causa identificada no relatório do Codemagic

- `StreamCatalogMetadataMapper13Test.opaqueFilenameIsNotPretendedToBeARealTitle`: o identificador opaco usado pelo catálogo tem 16 caracteres, mas a regra só reconhecia códigos com 18 ou mais. Isso permitia que o código fosse tratado como título legível.
- `MusicImageKeywordCatalog13Test.religiousContextRequiresReligiousTitleOrGenre`: o classificador dependia exclusivamente dos gatilhos carregados no TXT. O termo inequívoco `louvor` não era reconhecido como gatilho religioso em configurações mínimas do catálogo.

## Correções

- Ajustado o reconhecimento de identificadores opacos para tokens alfanuméricos/`_`/`-` com 16 ou mais caracteres. O identificador continua sendo usado internamente; não é apresentado como título real.
- Adicionada uma lista compacta de gatilhos religiosos de alta confiança no classificador, incluindo `louvor`, `gospel`, `Jesus`, `Cristo`, `Nossa Senhora`, `adoração` e termos equivalentes. Palavras ambíguas como `santo`, `céu`, `fé` e `anjo` não foram adicionadas como gatilhos genéricos de título.
- Mantida a separação entre contexto da música e detecção visual de arquivos religiosos. A regra de bloqueio de imagens religiosas continua usando marcadores visuais estritos.

## Verificações executadas

- `scripts/validate_v1_0_3_code13.py`: passou.
- Compilação isolada dos dois componentes Kotlin alterados e smoke tests focados nos dois cenários: passou.
- O ambiente desta correção não contém Gradle Wrapper nem instalação Gradle; portanto, a suíte Android completa não pôde ser executada localmente. O Codemagic deve executar novamente os 107 testes unitários. Nenhum teste foi removido ou desativado.

## Arquivos preservados

- Versão mantida em `1.0.3`, código `13`.
- `codemagic.yaml` mantido byte a byte, sem alteração da configuração de assinatura.
- Nenhuma mudança no pipeline de transições, exportação, histórico/bloqueio de imagens ou UI além das duas correções acima.
