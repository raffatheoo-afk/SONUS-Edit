# SONUS Edit 0.0.20 / code20

Implementation authorized from `CHECKLIST_SONUS_16X9_AUDIO_PROPOSTA.txt`.

## Main additions

- Project aspect ratio selector with **9:16 as default** and new **16:9** mode.
- 9:16 keeps 15/30/40/50/60/65/∞; 16:9 forces ∞ from the selected start to audio end.
- Dedicated horizontal pCloud gallery using public code `kZpRVYJZCVInrVg53M8t2JVi0nyFVjrg28ik`; it never mixes with the existing vertical automatic gallery.
- Horizontal exports map the same quality buttons to 1280×720, 1920×1080, 2560×1440 and 3840×2160.
- Local video can now be selected in Music as an **audio-only source** (`VIDEO_EXTRACTED`). MediaExtractor validates an audio track without loading/copying the whole video; Media3 removes its video track during final composition.
- Review screen adds project-level Particles On/Off and slightly larger detail lines.
- Caption status in Style is compact and inline with the title; the font preview is vertically centered against both font rows.
- Statistics can be fully reset without touching projects, drafts, settings, signature, favorites or artist database. A reset epoch prevents a foreground session started before the reset from reinserting old time later.
- Link importer ships/initializes the matching youtubedl-android ffmpeg module and silently retries once to remove the intermittent first-attempt `libffmpeg.so` failure.
- pCloud catalog cold reads race the two official API regions and remember the winning region, reducing the previous sequential fallback delay. Automatic image URL resolution is concurrent and progressively updates the selected image list.
- Whisper Base accuracy pipeline is preserved unchanged in model/chunk/overlap behavior.

## Export preservation

- Media3 remains 1.10.1.
- 30/60 FPS only.
- H.264/AAC.
- Raw green/black particle MP4s remain byte-for-byte unchanged.
- 16:9 particle overlay is fit without stretching the original source.
- Final output dimensions are validated against the active aspect ratio.
- Audio source is explicitly video-removed in the audio sequence, enabling video-as-audio safely.

## Signing/build

Persistent signing workflow ID remains exactly:

`sonus-edit-0-0-3-code03-debug`

The workflow must fail rather than generate a replacement signer.
