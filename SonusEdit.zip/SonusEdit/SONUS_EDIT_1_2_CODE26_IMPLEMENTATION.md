# SONUS Edit 1.2 / versionCode 26 — implementação

**Base:** SONUS Edit 1.1 / code25, ZIP oficial enviado na conversa.  
**Objetivo:** controle preciso do intervalo musical, distribuição dinâmica de imagens e feedback da sincronização, sem regressão da Gallery.

## Mudanças no código-fonte

1. **Dois pontos na timeline:** início roxo, saída vermelha. O preset (15/30/40/50/60/65s ou ∞) define inicialmente o ponto de saída; mover o marcador final ou o inicial permite um corte personalizado. O marcador de reprodução ciano acompanha o tempo atual. Faixa mínima: 1 segundo; nunca ultrapassa a duração real do áudio.
2. **Dois controles de audição separados:** botão ciano para ouvir desde o início e botão vermelho para ouvir os últimos 5 segundos antes do fim selecionado. Ambos têm ajuste preciso -5/-1/+1/+5 segundos, com reprodução encerrada no ponto de saída do vídeo e identificação visual independente.
3. **Corte salvo:** `manualEndMs` serializado no `CreationDraftSnapshot`, opcional para compatibilidade com rascunhos antigos; escolha de outro preset remove o ajuste manual. A exportação continua recebendo `segmentStartMs` + `segmentDurationMs`, agora calculado pelo intervalo real.
4. **Fotos proporcionais:** `MediaDistributionPlanner.maxImagesForDurationMs()` passa a selecionar a contagem inteira mais próxima de 5 segundos/foto (arredondamento por 2,5s) e respeita o teto histórico de 50 mídias. Ex.: 30s = 6, 32s = 6, 34s = 7. `durationsForTotalMs()` mantém a distribuição exata e uniforme, sem sobra de 2s em uma foto final. Mesmo cálculo atende Gallery, seleção local e exportação; vídeo 16:9 e longo seguem preservados.
5. **Legendas antecipadas:** `startCaptionIfNeeded()` é acionado na transição Música → Imagens, portanto Whisper já trabalha durante a seleção. Retomada em Gallery/Estilo continua suportada. Mudanças no áudio/corte invalidam os dados anteriores, cancelam o trabalho e usam `captionGeneration` para evitar que callbacks/transcrições antigas contaminem o estado atual. `WhisperCaptionEngine` já inclui mutex nativo para não rodar dois modelos simultaneamente.
6. **Status visual:** `CaptionStatusPill20` passa a usar `CircularProgressIndicator` indeterminado vermelho enquanto sincroniza; status verde de conclusão e aviso de erro mantidos.
7. **Gallery:** nenhuma alteração no carregador, pool de imagens ou pesquisa. A busca continua como na 1.1 para não arriscar desempenho ou precisão.
8. **Versão:** Home e cabeçalho exibem 1.2; Gradle e BUILD_VERSION: `versionName=1.2`, `versionCode=26`. Codemagic preserva workflow e assinatura histórica.

## Preservações

- Whisper Small multilíngue + regra atual de idioma, sem reinstalar Base/Tiny.
- Efeitos locais e pCloud, cache, loop e controle único de partículas.
- Premium informativo, sem cobrança, franquia ativa nem bloqueio comercial.
- Media3 1.10.1, FFmpeg, yt-dlp, 9:16 e 16:9, filtros, fontes, player de revisão e exportação longa.
- MP4 RAW de partículas mantidos byte a byte.
- `codemagic.yaml` exige assinatura persistente; falha caso ausente, sem criar chave nova.

## Validações executadas

- Parser Kotlin (PSI) dos cinco arquivos Kotlin mais relevantes: zero erros de sintaxe.
- Teste isolado compilado e executado com `kotlinc`: faixas, saídas, contagem de imagens, distribuição exata e teto de 50 mídias passaram.
- Suite estática e script `Validate Sonus Edit 1.2` do próprio workflow Codemagic: passaram.
- SHA256 dos MP4 internos conferidos com a versão anterior.
- ZIP final reaberto, com versão e arquivos verificados, antes da entrega.

## Validação Android ainda necessária

**Não há Android SDK nem Gradle completo neste ambiente.** Por isso **não foi gerado nem testado APK**. O Codemagic precisa executar `:app:compileDebugKotlin`, `:app:testDebugUnitTest` e `:app:assembleDebug` e validar interface e reprodução em dispositivo antes de instalar/distribuir.

Checklist manual: arrastar início/fim; presets e personalizado; ouvir começo e últimos 5s; tocar até ponto final; 30/32/34s = 6/6/7 fotos; trocar áudio depois de legenda em andamento; retornar da Gallery à Música; rascunho antigo/novo; Gallery rápida; 9:16 e 16:9; fonte de Android grande; link/Stream/local/vídeo extraído; indicadores vermelho, verde, erro; testar Whisper Small com PT/EN, nuvem de efeitos e assinatura histórica.
