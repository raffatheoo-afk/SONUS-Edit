# Sonus Edit 1.0.1 — CODE 11

## Implementado
- Catálogo ampliado de 11 para 16 escolhas: 10 fontes customizadas originais, Sans-serif e cinco novas famílias aprovadas. O seletor continua exibindo oito opções por abertura; o modo dinâmico usa todo o catálogo aprovado.
- Novas fontes: Bainsley Bold Italic, Fundamental Brigade, Torid Bold, Montepetrum Thin e Andika Basic. Fontes com licença não comprovada/restritiva ou glifos portugueses essenciais ausentes não foram incorporadas.
- Histórico de bloqueio de imagens separado por proporção: 20 projetos 9:16 e 15 projetos 16:9. O histórico é atualizado somente após exportação salva com sucesso.
- Preferência “Bloquear imagens recentes” ativada por padrão e controlável nos Ajustes. Históricos legados mistos não são migrados para evitar classificar incorretamente projetos antigos.
- Controle mestre “Automação Total” removido da interface e do modelo de preferências; controles individuais permanecem independentes e ligados por padrão.
- Ajustes organizados por grupos, estatísticas preservadas em seções e cartões, tela inicial com logotipo transparente, cartões destacados, botões em degradê e animação leve das estrelas; coroa com brilho vetorial.
- Sobre o Edit atualizado para 1.0.1 / CODE 11.

## Preservações
- applicationId, Media3 1.10.1, Whisper Small multilíngue local / ENGINE_VERSION 16, integração Link/yt-dlp/FFmpeg, renderização compartilhada de legendas e exportação foram mantidos.
- Workflow ID `sonus-edit-0-0-3-code03-debug` preservado.
- Nenhuma keystore ou credencial privada deve ser incluída no pacote. A assinatura persistente usa o recurso Code signing identities do Codemagic, com referência `sonus-edit-persistent`; a keystore original é fornecida separadamente e não entra no ZIP nem no repositório.

## Verificações
- Fontes: mapa de caracteres validado por FontTools para glifos portugueses essenciais.
- ZIP: será validado com `unzip -t`; YAML com parser; comparado com o workflow dentro do projeto.
- Não há Gradle/Android SDK disponível neste ambiente; compilação e JUnit não podem ser declarados executados.


## Correção posterior do workflow de assinatura
- Diagnóstico do primeiro build CODE 11: validação estática passou, mas o passo de assinatura abortou porque `SONUS_KEYSTORE_BASE64` não estava cadastrada.
- Correção: usar `environment.android_signing` com a referência `sonus-edit-persistent`, recebendo as variáveis `CM_KEYSTORE_*` padrão do Codemagic e mapeando-as para `SONUS_*` consumidas pelo Gradle.
- O build depende de cadastrar uma vez a keystore original CODE 03 em Codemagic Code signing identities.
