# SONUS Edit 1.1 — code25 (pacote consolidado)

**Base oficial:** SonusEdit_code24.zip, versão 1.0 / versionCode 24. **Nova versão candidata:** versionName `1.1`, versionCode `25`.

## Escopo implementado no source

1. **Legenda Whisper Small multilíngue:** troca do arquivo de modelo GGML (`ggml-small.bin`, 488 MB de download na primeira sincronização), verificação SHA-1 oficial (`55356645c2b361a969dfd0ef2c5a50d530afd8d5`), carregamento sob demanda e descarregamento em `finally`. Os modelos Base/Tiny anteriores só são removidos após Small validado. O wrapper `whisper-android:1.0.0` e seu modo greedy foram mantidos; **Beam Search não foi habilitado** por não haver API compatível comprovada.
2. **Idioma:** `CaptionLanguageHint` extrai indicação do título. A primeira janela com voz é ouvida em modo automático; em caso de indício, uma segunda transcrição com idioma `pt` ou `en` é comparada com o automático. Só fixa idioma quando houver suporte textual mínimo; evita forçar português quando o título aponta inglês. A língua confirmada é salva para retomada. Cache separado por modelo/versão, sugestão de língua, recorte e assinatura do arquivo/URI (quando disponível); sem reaproveitar caches antigos do Base.
3. **Home e Premium:** coroa desenhada em Compose, navegação própria, cards de mesma altura, redução de espaço antes da seção Central e botões Link/Rascunho em azul. Tela de planos apenas informativa: Free 10 grátis; Creator R$ 4,90/30; Pro R$ 9,90/75; Studio R$ 19,90/ilimitado. Compras `EM BREVE`, efeito da nuvem identificado como benefício futuro dos pagos. **Nenhum limitador, assinatura, cobrança nem bloqueio ativo.**
4. **Nuvem de efeitos:** biblioteca pública pCloud código `kZ6cTYJZ17xlSBf2QdbwBCvGBonokuAOGiw7`, aleatorização dos dois efeitos internos com MP4 válidos da nuvem, download no fluxo após escolha da faixa (sem rede na Home), cache em disco, checagens MIME/extensão, origem do link, duração, resolução, tamanho, proteção contra download parcial e identificação segura do fundo pelo nome ou quadros. Chroma verde ou Luma preta usa shader GPU anterior; seleção única por exportação e fallback para MP4 interno em falha. MP4 externo de até 20 MiB e 30 s para proteção de dados; padrão **recomendado** para envios é 15 s/720x1280/30fps/H.264/sem áudio/1–2Mbps. Cache até 120 MiB. Repetição do mesmo MP4 sem download a cada loop até cobrir vídeo longo. `Ativado/Desativado` controla local e nuvem.
5. **Proporções e Gallery:** remoção dos pictogramas sociais e centralização do indicador 9:16 e 16:9; contador da Gallery ligeiramente aumentado. Sem outras modificações intencionais de Gallery/listagem/cache/imagens.
6. **Mini player:** tamanho vertical adaptativo até 170dp de largura; qualidade/FPS continuam abaixo e Exportar no rodapé. Preview leve inclui os fades individuais de 1,5s, filtro, legendas, amostras de vídeo local e efeito (verde/preto) com composição de transparência CPU reduzida, usando source/cache e mesma escolha da exportação. A composição de efeitos da exportação continua no shader GPU Media3. A prévia de efeitos **não é pixel-perfect**, usa amostragem em intervalos de 450ms para economizar CPU; a validação em aparelho precisa conferir aspecto/ritmo/sincronia.

## Preservação

- Dois MP4s internos RAW byte-a-byte com hashes originais.
- Media3 `1.10.1`, Link/yt-dlp/FFmpeg, Stream, Gallery, filtros, fontes/favoritos, 9:16/16:9, 720p/1080p/2K/4K, 30/60 FPS, exportação longa e assinatura histórica.
- Sem ativação dos benefícios Premium comerciais. Sem introduzir 90 FPS.
- Workflow Codemagic mantém ID histórico `sonus-edit-0-0-3-code03-debug` e falha se signer histórico não for encontrado. Kotlin compile -> unit tests -> assemble debug.

## Verificações feitas neste ambiente

- `scripts/validate_code11.py`: passou (versões, escopo, rotas, invariantes estáticas, MP4 SHA256).
- Passo de validação do `codemagic.yaml` executado no source: passou.
- Teste isolado Kotlin das regras de idioma: 8 assertions passaram.
- Kotlin parser conferido nos arquivos modificados: nenhum erro de sintaxe de parser detectado; **não é compilação Android**.
- ZIP final extraído/reaberto para reconferir versão, hashes e arquivos (executar após empacotamento).

## Pendências obrigatórias de aceitação antes de instalar/divulgar

- O ambiente desta sessão **não tem Android SDK nem Gradle instalado**, portanto APK não foi compilado, instalado ou testado. Compilar no Codemagic e corrigir eventuais erros de tipos/dependências.
- Testar o Whisper Small real em dispositivo, uso de RAM, download de cerca de 488 MB, consumo de bateria e estabilidade para músicas PT e EN; comparar a mesma música em execuções repetidas. Beam Search segue indisponível nesse wrapper.
- Testar a pasta pCloud vazia e com MP4 preto/verde reais, rede ruim, download cancelado, cache reutilizado, overlays desligados, loops de 15s/longos, 9:16 e 16:9.
- Comparar prévia e vídeo exportado para fades, filtros, partículas e legendas; validar UI em telas diferentes, inclusive fontes grandes.
- Antes de enviar a alguma loja, verificar se versionCode 25 não foi usado/publicado no histórico do Play Console. O code25 isolado 1.0.1 foi **desconsiderado como release oficial**, mas não temos acesso ao histórico da loja.

