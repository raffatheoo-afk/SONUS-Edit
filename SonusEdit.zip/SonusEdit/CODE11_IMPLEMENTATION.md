# Sonus Edit 1.0.1 — CODE 11

## Implementado
- Catálogo ampliado de 11 para 16 escolhas: 10 fontes customizadas originais, Sans-serif e cinco novas famílias aprovadas. O seletor continua exibindo oito opções por abertura; o modo dinâmico usa todo o catálogo aprovado.
- Novas fontes: Bainsley Bold Italic, Fundamental Brigade, Torid Bold, Montepetrum Thin e Andika Basic. Fontes com licença não comprovada/restritiva ou glifos portugueses essenciais ausentes não foram incorporadas.
- Histórico de bloqueio de imagens separado por proporção: 20 projetos 9:16 e 15 projetos 16:9. O histórico é atualizado somente após exportação salva com sucesso.
- Preferência “Bloquear imagens recentes” ativada por padrão e controlável nos Ajustes. Históricos legados mistos não são migrados para evitar classificar incorretamente projetos antigos.
- Controle mestre “Automação Total” removido da interface e do modelo de preferências; controles individuais permanecem independentes e ligados por padrão.
- Ajustes organizados por grupos, estatísticas preservadas em seções e cartões, tela inicial com logotipo transparente, cartões destacados, botões em degradê e animação leve das estrelas; coroa com brilho vetorial.
- Sobre o Edit atualizado para 1.0.1 / CODE 11.

## Preservações
- applicationId, Media3 1.10.1, Whisper Small multilíngue local / ENGINE_VERSION 16, integração Link/yt-dlp/FFmpeg, renderização compartilhada de legendas e exportação foram mantidos.
- Workflow ID `sonus-edit-0-0-3-code03-debug` preservado.
- Assinatura persistente restaurada ao mecanismo original CODE 10: o passo do YAML recria a mesma keystore no ambiente temporário do build e exporta os valores `SONUS_KEYSTORE_*` usados pelo Gradle. Não exige cadastro manual em Code signing identities.
- O material de assinatura permanece embutido no YAML, como no workflow CODE 10 solicitado para manter compatibilidade operacional. Isso significa que qualquer pessoa com acesso ao repositório/YAML pode extrair a chave; mantenha o repositório privado e restrinja acessos.

## Verificações
- Fontes: mapa de caracteres validado por FontTools para glifos portugueses essenciais.
- ZIP: será validado com `unzip -t`; YAML com parser; comparado com o workflow dentro do projeto.
- Não há Gradle/Android SDK disponível neste ambiente; compilação e JUnit não podem ser declarados executados.


## Restauração do mecanismo de assinatura CODE 10
- A migração para `environment.android_signing` foi revertida porque exigia o cadastro manual `sonus-edit-persistent` no painel Codemagic.
- O CODE 11 volta a utilizar o passo original de restauração: decodifica o Base64 da keystore persistente para o diretório temporário do runner, valida alias/senha com `keytool` e publica `SONUS_KEYSTORE_PATH`, `SONUS_KEYSTORE_PASSWORD`, `SONUS_KEY_ALIAS` e `SONUS_KEY_PASSWORD` em `CM_ENV`.
- Nenhuma configuração adicional no painel Codemagic é necessária para a assinatura.
