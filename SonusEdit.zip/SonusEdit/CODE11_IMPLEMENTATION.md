# Sonus Edit 0.0.11 / code11

Base: 0.0.10 / code10 estável.

## Correção principal — partículas
- Mantido o vídeo original de partículas 1080x1920 / 60 fps como fonte de qualidade.
- O atlas transparente foi reconstruído em 360x640 por quadro (antes 180x320), com 60 quadros em uma grade 10x6.
- A animação interna passou de 3 fps para 6 fps.
- O chroma key foi refeito estimando o fundo verde quadro a quadro e recuperando o matte da partícula branca antes do downscale.
- O alpha recebeu curva de preservação de halo/núcleo para evitar que pontos pequenos desapareçam na exportação.
- A interpolação linear foi trocada por crossfade equal-power (`sqrt`) para não reduzir demais o brilho no meio da transição.
- A Automação Total continua escolhendo uma das cinco variações para todo projeto, sem bloquear o efeito por gênero.
- A intensidade usada no draft agora respeita `effectIntensity` salvo; não é mais forçada para 50% apenas porque a Automação Total está ativa.

## Legenda
- Redução adicional de 5% no tamanho da legenda exportada em relação à code10.
- Máximo: 0.0430f -> 0.04085f.
- Limites mínimos também foram reduzidos proporcionalmente para manter o comportamento de quebra em até duas linhas.

## Compatibilidade preservada
- package: `com.sonusstudios.sonusedit`
- workflow Codemagic ID preservado: `sonus-edit-0-0-3-code03-debug`
- assinatura persistente preservada pela mesma linhagem de build.
- Mantidas as correções estáveis da code10 para assinatura, integração SONUS, exportação em segundo plano e encerramento de notificação.
