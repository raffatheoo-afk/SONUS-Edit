# SONUS Edit 0.0.23 / code23

Implementação consolidada sobre a code22.

## Integração SONUS -> Edit
- `IncomingIntentRouter` aceita o deep link legado por `trackId` e intents explícitos mais ricos.
- Faixas podem chegar com URI, título, artista, álbum, gênero e segmentos de legenda.
- O fallback legado procura a faixa no catálogo Stream por id/nome e força uma atualização única se o cache estiver obsoleto.
- A tela mostra sincronização somente enquanto a faixa compartilhada está sendo resolvida.

## Stream
- O cartão da faixa mostra arte embutida/thumbnail quando disponível.
- Para Stream aparecem ações compactas para trocar aleatoriamente e pesquisar.
- A busca abre uma lista temporária sem ocupar permanentemente a tela Música.

## Gallery
- O banco Artista -> Gênero foi retirado do APK/runtime desta versão.
- A sugestão normal volta ao ranking simples do SONUS com aleatoriedade por projeto.
- Nenhuma imagem remota é marcada automaticamente em projeto novo.
- O cabeçalho permanece fixo: `Imagens e vídeos`, contador azul, busca e mídia local.
- Apenas a grade rola.
- Seleção usa check vetorial branco sobre círculo azul/ciano.
- Busca manual continua normalizada nas pastas 9:16 e 16:9.

## Navegação compacta
- Os quatro cards grandes foram removidos do fluxo.
- Após a Home, o cabeçalho usa logo + quatro círculos com ícones + versão azul + badge 9:16/16:9 vermelho.
- O conteúdo das etapas sobe sem alterar a Home.

## Estilo / Revisão
- Partículas ON/OFF foi movido para Estilo.
- Revisão removeu o título e as linhas textuais de resumo.
- Campos Música/Artista ganharam altura e tipografia segura.
- Mini preview adapta 9:16/16:9, reproduz áudio, percorre a timeline visual e usa os CaptionSegments reais.
- Qualidade/FPS permanecem no rodapé do conteúdo e o botão Exportar continua no bottom bar.

## Projetos longos
- A partir de 10 minutos, exportação é dividida em blocos de 4 minutos.
- Cada bloco mantém posição do áudio, timeline visual, fades e legendas relativos ao trecho.
- Um bloco que falhar é tentado novamente sem descartar os blocos já renderizados.
- Os MP4 intermediários são unidos por `MediaMuxer`, sem uma segunda re-encode completa.
- A concatenação abre um extractor novo por faixa para preservar vídeo e áudio.
- O progresso agrega blocos concluídos + progresso do bloco atual.

## Legenda longa
- Whisper Base permanece.
- Acima de 10 minutos, o áudio selecionado é decodificado sequencialmente uma única vez.
- Janelas longas: 45 s com 1,5 s de sobreposição.
- Cada chunk é salvo em cache assim que termina; ao retomar, chunks existentes são reutilizados.
- O modelo continua liberado da RAM antes da exportação.

## Preservado
- Link/yt-dlp/FFmpeg da code22.
- Pastas 9:16 e 16:9 e busca manual da code22.
- Partículas raw byte-for-byte.
- Media3 1.10.1.
- 720p/1080p/2K/4K, 30/60 FPS.
- signing workflow `sonus-edit-0-0-3-code03-debug`.
