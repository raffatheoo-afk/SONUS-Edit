# SONUS Edit 0.0.18 / code18

Implementação autorizada em 06/10/2026 sobre a code17 buildfix1.

## Principais mudanças
- Home leve: sem sugestão/consulta Stream na abertura; criar automático, Link direto, Rascunho, Estatísticas e Ajustes.
- Stream, Local e Link são carregados somente quando escolhidos.
- Link Fast Path abre diretamente no campo de URL; resolver é pré-aquecido apenas depois da escolha.
- Rascunho local persistente restaura o último progresso de criação.
- Novo motor de legenda automática local com whisper.cpp via `whisper-android`.
  - Sem PCloud LRC/LRCLIB no fluxo automático.
  - O áudio real do trecho é a fonte da legenda e dos timestamps.
  - `ggml-tiny.bin` multilíngue é baixado uma única vez sob demanda e armazenado localmente.
  - Transcrição ocorre em segundo plano enquanto o usuário escolhe mídia/estilo.
  - Modelo é liberado da RAM antes da exportação.
  - Trechos longos são processados em janelas de 60 s.
- Legenda final preserva compositor/posição/fonte/cores/sombra do SONUS Edit.
- Durações visíveis: 15/30/40/50/60/65/∞; ∞ usa o restante real do áudio.
- Mídia Local aceita fotos e vídeos; áudio dos vídeos visuais é removido; timeline permanece exata.
- Seleção de Gallery usa feedback otimista e agrupa selecionadas primeiro na ordem da timeline.
- UI Estilo compactada; apenas 6 filtros visíveis: Natural, Cinemático, HDR Natural, Preto Profundo, Vívido Natural, Nitidez+.
- Assinatura foi movida para Ajustes e permanece persistida/aplicada automaticamente.
- Estatísticas locais por mês civil, com tempo no app, tempo de trabalho, automação e estimativa de tempo economizado baseada no benchmark de 4m24s para 30s.
- Splash sem câmera: centro do logo fixo e setas procedurais girando; assinatura inferior preservada.

## Preservado
- workflow id `sonus-edit-0-0-3-code03-debug` e assinatura persistente;
- Media3 1.10.1;
- 9:16, 720p/1080p/2K/4K e 30/60 FPS;
- Lanczos da code17;
- partículas MP4 brutas, sem atlas/interpolação/zoom/crop;
- foreground/background export e fluxo salvar/abrir/compartilhar/concluir.

## Observações
- O primeiro uso da legenda automática precisa baixar o modelo `ggml-tiny.bin` (~75 MiB). Depois o motor funciona localmente/offline.
- O AAR open-source usado é arm64-v8a. Em aparelhos sem suporte ao native library, a legenda falha de forma isolada e o restante do editor continua disponível.
- Música cantada é mais difícil para ASR do que fala; a code18 remove o risco de timestamps de outra versão, mas a precisão textual depende da gravação.

## Build fix 1 — 07/10/2026
- Corrigida compilação Kotlin em `CreateFlowScreen18.kt`.
- `Image` do Material Icons é uma extension property; o alias `ImageIcon` estava sendo usado sem o receiver `Icons.Filled/Default`.
- Substituído por `Icons.Default.Image` com o import padrão `androidx.compose.material.icons.filled.Image`.
- Nenhuma lógica de produto, Whisper, exportação, partículas, assinatura ou versão foi alterada.
