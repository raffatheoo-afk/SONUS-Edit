# SONUS EDIT 1.0.7 / CODE 17 — OpenDownloader browser hand-off

## Implemented
- The existing direct-media HTTPS importer remains native Kotlin.
- Platform-page links now show a dedicated OpenDownloader hand-off instead of calling the old Cobalt gateway.
- SONUS validates the shared URL, copies it to the clipboard and opens https://opendownloader.app/.
- The already-existing Android Sharesheet import receives the downloaded audio/video back into SONUS EDIT.
- The old Cobalt gateway client and server deployment were removed from the active project. No VPS URL, API key or credit counter is required for this hand-off.
- Version stays 1.0.7 / versionCode 17. Application ID and signing configuration are preserved.

## Verified compatibility limits (official site FAQ)
- Pasted links handled by the website: YouTube, X and Twitch, plus direct media links/playlists.
- TikTok, Instagram, Facebook, Bilibili, Vimeo and Dailymotion require the browser extension according to the website FAQ; that extension is not part of this Android hand-off.
- The OpenDownloader project README says a mobile app is out of scope.
- Therefore this is a practical browser/share integration, not an embedded Android SDK or zero-touch transfer to the editor. After download, user shares the file from Android Downloads to SONUS EDIT.

## Validation
- CODE17 Python static validator updated for the OpenDownloader hand-off.
- YAML syntax and shell syntax validated.
- Added JUnit tests for safe URL normalization.
- Full Gradle/Android build is not claimed: the Android SDK and Gradle wrapper are not present in this environment.
