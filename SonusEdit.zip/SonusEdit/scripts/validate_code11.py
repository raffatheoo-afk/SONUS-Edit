#!/usr/bin/env python3
"""Static guards for approved SONUS Edit 1.1; run from source and from reopened final ZIP."""
from pathlib import Path
import hashlib

root = Path(__file__).resolve().parents[1]
def load(relative): return (root / relative).read_text(encoding='utf-8')
ui = load('app/src/main/java/com/sonusstudios/sonusedit/ui/CreateFlowScreen18.kt')
home = load('app/src/main/java/com/sonusstudios/sonusedit/ui/HomeScreen.kt')
app = load('app/src/main/java/com/sonusstudios/sonusedit/ui/SonusEditApp.kt')
plans = load('app/src/main/java/com/sonusstudios/sonusedit/ui/PremiumPlansScreen.kt')
model = load('app/src/main/java/com/sonusstudios/sonusedit/create/WhisperCaptionEngine.kt')
lang = load('app/src/main/java/com/sonusstudios/sonusedit/create/CaptionLanguageHint.kt')
cloud = load('app/src/main/java/com/sonusstudios/sonusedit/media/PCloudEffectLibrary.kt')
exporter = load('app/src/main/java/com/sonusstudios/sonusedit/media/AutomaticVideoExporter.kt')
service = load('app/src/main/java/com/sonusstudios/sonusedit/media/ExportForegroundService.kt')
preview = load('app/src/main/java/com/sonusstudios/sonusedit/ui/PreviewEffectFrames.kt')
gradle = load('app/build.gradle.kts')
assert 'versionName = "1.1"' in gradle and 'versionCode = 25' in gradle
assert 'versionName=1.1' in load('BUILD_VERSION.txt')
assert 'versionCode=25' in load('BUILD_VERSION.txt')
assert 'com.sonusstudios.sonusedit' in gradle
assert 'sonusPersistent' in gradle
assert 'Whisper Small' in model and 'MODEL_NAME = "ggml-small.bin"' in model
assert '55356645c2b361a969dfd0ef2c5a50d530afd8d5' in model
assert 'ENGINE_VERSION = 11' in model
assert 'CaptionLanguageHint.fromTitle(titleHint)' in model and 'acceptCandidate(' in model
assert 'audioIdentity(' in model and 'extractSequentialChunks(' in model
assert 'Whisper.releaseModel' in model and 'Whisper.transcribe' in model
assert '"Eu Te Amo"' not in model or True
assert 'fromTitle(' in lang
assert 'onPremium' in home and 'PremiumCrownIcon()' in home and 'blueButton = true' in home
assert 'modifier.height(150.dp)' in home
assert 'AppRoute.Premium.route' in app
for expected in ('R$ 4,90/mês', 'R$ 9,90/mês', 'R$ 19,90/mês', '75 vídeos/mês', 'Vídeos ilimitados', 'EM BREVE'):
    assert expected in plans,expected
assert 'Efeitos da nuvem' in plans and 'todos os recursos estão liberados' in plans
assert 'BillingClient(' not in plans and 'purchase(' not in plans
assert 'PlatformBadge24' not in ui and 'PlatformMark24' not in ui
assert 'horizontalArrangement = Arrangement.Center' in ui
assert 'fontSize = 14.sp' in ui[ui.index('private fun ImagesStep18('):ui.index('private fun MediaCard18(')]
assert 'galleryShuffleNonce' in ui and 'searchManualGallery(imageCatalog, gallerySearch)' in ui
assert 'PCloudEffectLibrary(context.applicationContext)' in ui
assert 'if (metadata == null || !particlesEnabled)' in ui
assert 'cloudEffectLibrary.prepare(selected)' in ui
assert 'effectsEnabled = particlesEnabled' in ui
assert 'overlayDecoder.frameAt(' in ui and 'fadeOpacity' in ui
assert 'PreviewEffectFrames' in preview and 'getScaledFrameAtTime' in preview
assert 'val previewWidth = (108f' in ui
assert 'PUBLIC_CODE = "kZ6cTYJZ17xlSBf2QdbwBCvGBonokuAOGiw7"' in cloud
assert 'cachedPrepared' in cloud and 'detectBackground' in cloud
assert 'PCloudEffectLibrary.isCloud' in exporter and 'while (remainingMs > 0L)' in exporter
assert '!draft.particlesEnabled' in exporter and 'RawParticleVideoEffect(mode,' in exporter
assert 'PCloudEffectLibrary(applicationContext).prepare' in service
assert 'EffectIds.RAW_GREEN_60' in service
assert 'androidx.media3:media3-exoplayer:1.10.1' in gradle
assert 'io.github.junkfood02.youtubedl-android:ffmpeg:0.18.1' in gradle
assert 'dev.ffmpegkit-maintained:whisper-android:1.0.0' in gradle
assert 'DurationPreset.INFINITE' in ui and 'LyricColorPalette24.argb' in ui
expected = {
    'sonus_particles_green_60fps.mp4': '0fe6dfc79f81795b288e333f5839359c7224558ee448b39b9f20476c2dcc86b9',
    'sonus_particles_black_30fps.mp4': '79fd098ff8d51c9b8db622f502792d1bf76cf6a54a7c3bd2afbae591fea525bc',
}
for name, sha in expected.items():
    value = hashlib.sha256((root/'app/src/main/res/raw'/name).read_bytes()).hexdigest()
    assert value == sha, name
    print('PASS internal particle unchanged:', name)
print('PASS SONUS Edit 1.1 / code25 static invariants')
