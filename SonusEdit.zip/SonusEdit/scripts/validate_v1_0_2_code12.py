#!/usr/bin/env python3
from pathlib import Path
import re
ROOT=Path(__file__).resolve().parents[1]
def read(p): return (ROOT/p).read_text(encoding="utf-8")
def need(ok,msg):
    if not ok: raise SystemExit("CODE12 validation failed: "+msg)
build=read("app/build.gradle.kts"); version=read("BUILD_VERSION.txt")
models=read("app/src/main/java/com/sonusstudios/sonusedit/create/CreateModels.kt")
flow=read("app/src/main/java/com/sonusstudios/sonusedit/ui/CreateFlowScreen18.kt")
history=read("app/src/main/java/com/sonusstudios/sonusedit/create/SmartImageSelector.kt")
prefs=read("app/src/main/java/com/sonusstudios/sonusedit/create/AutomationPreferences.kt")
settings=read("app/src/main/java/com/sonusstudios/sonusedit/ui/AutomationSettingsScreen.kt")
home=read("app/src/main/java/com/sonusstudios/sonusedit/ui/HomeScreen.kt")
about=read("app/src/main/java/com/sonusstudios/sonusedit/ui/AboutScreen.kt")
yaml=read("codemagic.yaml")
need('versionCode = 12' in build and 'versionName = "1.0.2"' in build, "Gradle version")
need('versionName=1.0.2' in version and 'versionCode=12' in version, "version file")
need('applicationId = "com.sonusstudios.sonusedit"' in build, "applicationId")
need('sonus-edit-0-0-3-code03-debug:' in yaml, "fixed workflow ID")
need('android_signing:' not in yaml and 'sonus-edit-persistent' not in yaml, 'no manual Code Signing Identities dependency')
need('data = \"' in yaml and 'SONUS_KEYSTORE_PATH=$KEYSTORE' in yaml and 'SONUS_KEYSTORE_PASSWORD=$SONUS_KEYSTORE_PASSWORD' in yaml and 'SONUS_KEY_ALIAS=$SONUS_KEY_ALIAS' in yaml and 'SONUS_KEY_PASSWORD=$SONUS_KEY_PASSWORD' in yaml, 'original embedded persistent signer restoration')
need('keytool -list' in yaml and 'python3 - "$KEYSTORE"' in yaml, 'embedded keystore reconstruction and alias validation')
need('ENGINE_VERSION = 16' in read('app/src/main/java/com/sonusstudios/sonusedit/create/WhisperCaptionEngine.kt'), "Whisper engine")
need(build.count('androidx.media3:media3-') == 5 and ':1.10.1"' in build, "Media3 dependencies")
need('VERTICAL_PROJECTS_TO_BLOCK = 20' in history and 'HORIZONTAL_PROJECTS_TO_BLOCK = 15' in history, "format-specific cooldown limits")
need('recent_project_image_keys_vertical_v2' in history and 'recent_project_image_keys_horizontal_v2' in history, "separate history stores")
need('recordProjectKeys(draft.imageHistoryKeys, draft.aspectRatio)' in read('app/src/main/java/com/sonusstudios/sonusedit/media/ExportForegroundService.kt'), "record cooldown by project ratio")
need('blockRecentImages: Boolean = true' in prefs and 'BlockRecentImages' in prefs, "default image cooldown preference")
need('title = "Bloquear imagens recentes"' in settings and 'AUTOMAÇÃO TOTAL' not in settings, "settings control and removed master switch")
need('totalAutomation' not in settings and 'totalAutomation' not in flow, "no master automation behavior")
need('CaptionFontPool.approved' in flow and 'take(8)' in flow and 'CaptionFontPool.approved.random()' in flow, "eight-font carousel and dynamic catalog")
fontblock=models.split('val approved: List<FontPresetId> = listOf(',1)[1].split('    )',1)[0]
ids=re.findall(r'FontPresetId\.([A-Z0-9_]+)',fontblock)
need(len(ids)==16 and len(set(ids))==16, f"font pool count expected 16, got {len(ids)}")
assets=re.findall(r'assetFileName = "([^"]+)"',models)
need(len(assets)==15, f"custom font refs expected 15, got {len(assets)}")
for name in assets: need((ROOT/'app/src/main/assets/fonts'/name).is_file(), "missing font asset: "+name)
for name in ['Bainsley_Bold_Italic.otf','Fundamental Brigade.ttf','ToridBold.ttf','Montepetrum Thin.ttf','AndBasR.ttf']:
    need((ROOT/'app/src/main/assets/fonts'/name).is_file(), "new font absent: "+name)
need('sonus_edit_logo_center' in home and '1.0.2' in home and 'sonus-sparkles' in home, "home identity refresh preserved")
need('Versão 1.0.2' in about and 'CODE 12' in about, "About screen release notes")
need('UsageStatsStore' in read('app/src/main/java/com/sonusstudios/sonusedit/ui/StatisticsScreen.kt'), "statistics source preserved")
# CODE12 — Stream metadata indexing and visible title search.
stream_store = read('app/src/main/java/com/sonusstudios/sonusedit/catalog/StreamMetadataStore.kt')
repo = read('app/src/main/java/com/sonusstudios/sonusedit/catalog/PCloudCatalogRepository.kt')
search_policy = read('app/src/main/java/com/sonusstudios/sonusedit/catalog/PCloudSearchCachePolicy.kt')
need('indexCatalog(' in stream_store and 'val workers = List(3)' in stream_store and 'Dispatchers.Main.immediate' in stream_store, 'bounded Stream metadata indexing')
need('displayTitle(asset)' in flow and 'cached?.artist' in flow and 'cached?.album' in flow and 'isOpaqueCode(parts[0])' in stream_store, 'Stream metadata search, labels and retryable unresolved code fallback')
need('minimumFreshMatches: Int = 11' in repo and 'hasEnoughFreshMatches' in repo and 'SmartImageSelector.searchManualGallery' in search_policy, 'PCloud search requires enough exact fresh/unblocked cached matches')
need((ROOT/'app/src/test/java/com/sonusstudios/sonusedit/catalog/PCloudSearchCachePolicyTest.kt').is_file(), 'PCloud exact-query cache threshold tests')
need('urlCacheTtlMs' in repo and 'invalidateThumbnailUrl' in repo and 'invalidateDownloadUrl' in repo, 'expiring and invalidatable pCloud URL caches')

# CODE12 — stable image selection identity, FIFO policy and query-scoped filtering.
need('selectedRemoteStableKeys = selectedRemoteStableKeys + asset.stableKey' in flow, 'capture stable image key on selection')
need('imageHistoryKeys = selectedRemoteStableKeys.filter' in flow and 'selectedRemoteStableKeys = selectedRemoteStableKeys.toList()' in flow, 'draft persists selected stable keys and exports only resolved media')
need('ImageCooldownPlanner.calculate' in history and 'MAX_FRESH_BEFORE_RELEASE = 10' in history, 'query-scoped cooldown release policy')
need('recordProjectKeys(draft.imageHistoryKeys, draft.aspectRatio)' in read('app/src/main/java/com/sonusstudios/sonusedit/media/ExportForegroundService.kt'), 'successful-export history persistence')
need('recent_project_image_keys_vertical_v2' in history and 'recent_project_image_keys_horizontal_v2' in history, 'independent image histories')
need('ImageCooldownPlannerTest' in read('app/src/test/java/com/sonusstudios/sonusedit/create/ImageCooldownPlannerTest.kt'), 'large-search cooldown regression tests')
need((ROOT/'app/src/test/java/com/sonusstudios/sonusedit/create/SmartImageSelectorManualSearchTest.kt').is_file(), 'manual gallery exact-match regression tests')
need('320' in read('app/src/test/java/com/sonusstudios/sonusedit/create/SmartImageSelectorManualSearchTest.kt') and 'blocked' in read('app/src/test/java/com/sonusstudios/sonusedit/create/SmartImageSelectorManualSearchTest.kt'), '300+ asset blocked-image regression coverage')

# CODE12 — local audio trim can be unlocked from ExoPlayer duration while ID3 read runs separately.
need('player.prepare()' in flow and 'launch {\n                val embedded' in flow, 'local audio metadata extraction remains background')
need('Provisional metadata unlocks the trim UI' in flow and 'playerDurationMs' in flow, 'player duration unlocks trim controls')

# CODE12 — ten transition families with paired entry/exit and four-family cap.
transitions = read('app/src/main/java/com/sonusstudios/sonusedit/create/VisualTransitionPreferences.kt')
visual = read('app/src/main/java/com/sonusstudios/sonusedit/media/VideoVisualEffects.kt')
preview = flow
family_block = transitions.split('val families = listOf(', 1)[1].split('    )', 1)[0]
need('VisualTransitionFamily("fade"' in family_block and family_block.count('VisualTransitionFamily(') == 10, 'ten transition families total')
need('take(4)' in transitions and 'VisualTransitionMode.RANDOM' in transitions and 'resolvePoolForProject' in transitions and 'appendAssignments' in transitions, 'maximum four families and fixed per-project random pool')
need('visualTransitionIds' in models and 'visualTransitionIds' in read('app/src/main/java/com/sonusstudios/sonusedit/create/CreationDraftStore.kt'), 'transition assignments persist in drafts')
need('transitionEffects(' in visual and 'GaussianFunction' in visual and 'TransitionCanvasOverlay' in visual, 'export transition effects')
need('Modifier.fillMaxSize().blur(blurRadius)' in preview and 'transitionId == "wipe"' in preview and 'transitionId == "light"' in preview, 'preview coverage for blur, wipe and light')
need('BoxWithConstraints(' in preview and 'previewWidthPx = with(previewDensity) { maxWidth.toPx() }' in preview, 'preview blur uses a defined aspect-aware container width')
need('bandWidth * 1.5f' in preview and 'p * (1f + bandWidth) - bandWidth / 2f' in preview, 'Light transition preview aligns to export overlay geometry')
need('1_500L' in visual and 'imageFadeOverlay(' in visual, 'new effects share the measured 1.5s fade duration while original Fade method remains')
need((ROOT/'app/src/test/java/com/sonusstudios/sonusedit/create/VisualTransitionCatalogTest.kt').is_file(), 'transition selection regression tests')

# CODE12 — captions and particles are swapped between their existing steps.
need('Legendas neste vídeo' in flow and 'onCaptionsEnabled' in flow, 'caption toggle appears in style/sync step')
need('Partículas neste vídeo' in flow and 'onParticlesEnabled' in flow, 'particles toggle appears in review step')
need('if (step == CreateStep18.STYLE && captionJob?.isActive == true)' in flow, 'caption progress overlay limited to the synchronization screen')

need('Versão 1.0.2' in about and 'CODE 12' in about and 'nove novas famílias' in about.lower(), 'About screen CODE12 release notes')
print('CODE12 static validation passed')
