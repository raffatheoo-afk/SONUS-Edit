#!/usr/bin/env python3
from pathlib import Path
import hashlib
r=Path(__file__).resolve().parents[1]
def rd(p): return (r/p).read_text(encoding='utf-8')
g=rd('app/build.gradle.kts'); ui=rd('app/src/main/java/com/sonusstudios/sonusedit/ui/CreateFlowScreen18.kt')
link=rd('app/src/main/java/com/sonusstudios/sonusedit/create/LinkAudioImporter.kt')
exp=rd('app/src/main/java/com/sonusstudios/sonusedit/media/AutomaticVideoExporter.kt')
whisper=rd('app/src/main/java/com/sonusstudios/sonusedit/create/WhisperCaptionEngine.kt')
service=rd('app/src/main/java/com/sonusstudios/sonusedit/media/ExportForegroundService.kt')
eta=rd('app/src/main/java/com/sonusstudios/sonusedit/create/CaptionEtaEstimator14.kt')
assert (r/'app/src/test/java/com/sonusstudios/sonusedit/create/Code28StabilityTest.kt').exists()
assert 'versionCode = 31' in g and 'versionName = "1.7"' in g
assert 'versionCode=31' in rd('BUILD_VERSION.txt')
assert 'versionName=1.7' in rd('BUILD_VERSION.txt')
assert 'sonusPersistent' in g and 'io.github.junkfood02.youtubedl-android:ffmpeg:0.18.1' in g
assert 'androidx.media3:media3-transformer:1.10.1' in g
assert 'UpdateChannel.STABLE' in link and 'updateYoutubeDL(' in link
assert 'verify' in link and 'copyTo(installed, overwrite = true)' in link
assert 'refreshResolverIfDue(onProgress)' in link and 'FFmpeg.getInstance().init' in link
assert 'startLongExport(draft, onCompleted, onError, RETRY_SEGMENT_MS)' in exp
assert 'ExportRecoveryPolicy14.shouldRetryInChunks' in exp
assert 'setMaxDelayBetweenMuxerSamplesMs(MUXER_WATCHDOG_MS)' in exp
assert 'visualDurationsMs' in exp and 'buildRawParticleSequence(draft)' in exp
assert 'ENGINE_VERSION = 14' in whisper and 'Whisper Small' in whisper
assert 'CaptionLanguageHint.fromTranscription' in whisper and 'lockedLanguage' in whisper
assert 'CaptionEtaEstimator14.expectedTotalMs' in ui and 'CaptionEtaEstimator14.record' in ui
assert '"sonus_caption_eta_code28"' in eta
assert 'SonusEditExport' in service and 'Build.MANUFACTURER' in service
for path in ['app/src/main/res/raw/sonus_particles_green_60fps.mp4','app/src/main/res/raw/sonus_particles_black_30fps.mp4']:
    p=r/path
    assert p.is_file() and p.stat().st_size > 100_000, path
assert 'Text("1.7"' in ui

models=rd('app/src/main/java/com/sonusstudios/sonusedit/create/CreateModels.kt')
images=rd('app/src/main/java/com/sonusstudios/sonusedit/create/SmartImageSelector.kt')
stats=rd('app/src/main/java/com/sonusstudios/sonusedit/stats/UsageStatsStore.kt')
visual=rd('app/src/main/java/com/sonusstudios/sonusedit/media/VideoVisualEffects.kt')
preview=rd('app/src/main/java/com/sonusstudios/sonusedit/ui/PreviewEffectFrames.kt')
shader=rd('app/src/main/res/raw/sonus_video_key_fragment.glsl')
assert 'NORMAL_SANS' in models and 'NORMAL_SERIF' in models
assert 'assetFileName' in models and 'Magic Clover.otf' in models
assert 'recentAcrossLastProjects()' in images and 'take(3)' in images
assert 'if (freshAllowed.size >= count) freshAllowed else policy.allowed' in images
assert 'automaticWorkMs = old.automaticWorkMs + draft.automaticWorkMs,' in stats
assert 'editingStartedEpochMs' in ui and 'imageHistoryStore.recordProject' in ui
assert 'cloudOptimized = remoteSource != null' in rd('app/src/main/java/com/sonusstudios/sonusedit/media/AutomaticVideoExporter.kt')
assert 'uMode < 2.5' in shader and 'brightness < 0.105' in shader
assert 'cloudOptimized' in preview and 'smooth(.105f, .315f, brightness)' in preview
font_assets=list((r/'app/src/main/assets/fonts').glob('*'))
assert len(font_assets) == 16, len(font_assets)  # 19 fonts removed in code30
font_hashes=[hashlib.sha256(p.read_bytes()).hexdigest() for p in font_assets]
assert len(set(font_hashes)) == len(font_hashes), 'duplicate font binaries remain'
import re
entries=re.findall(r'\w+\("[^"]*", assetFileName = "([^"]+)"\)', models)
assert len(entries)==16 and set(entries)=={p.name for p in font_assets}, entries
for entry in entries:
    assert (r/'app/src/main/assets/fonts'/entry).is_file(), entry
assert 'CaptionFontPool.approved.shuffled().take(8)' in ui and 'Fonte dinâmica' in ui
assert 'FontPresetId.entries.shuffled()' not in ui and 'FontPresetId.entries.random()' not in ui
assert 'CaptionFontPool.approved.random()' in ui and 'object CaptionFontPool' in models
assert 'requested.effective()' in visual and 'requested.effective()' in ui
for gone in ['Roomboy.otf','Casa Pinada.ttf','Tharon.ttf','DifferentSunset.ttf','Jabawoky.ttf','Milliwatts demo.otf','Florida Orange - Personal Use.ttf','DeepAbyss.otf','Folders.ttf','MyLove.ttf','My Kids Handwritten.otf','I_Love_January.otf','TheAbsolute.otf','On The Way.ttf','UnforgottenMore1.otf','Panterick Swash.ttf','Gambler in Town.ttf','Oliver Richards.ttf','RJOETRIAL.ttf']:
    assert not (r/'app/src/main/assets/fonts'/gone).exists(), gone
    assert gone not in models, gone
assert (r/'app/src/test/java/com/sonusstudios/sonusedit/create/Code30CaptionFontPoolTest.kt').is_file()
# Digital clock: DS-Digital Bold, license text shipped beside it, counter uses it
assert (r/'app/src/main/assets/ui_fonts/DS-DIGIB.TTF').stat().st_size == 24896
assert 'Dusit Supasawat' in (r/'app/src/main/assets/ui_fonts/DIGITAL.TXT').read_text(encoding='latin-1')
assert 'ui_fonts/DS-DIGIB.TTF' in ui and 'fontFamily = digitalClockFamily' in ui and 'Modifier.widthIn(min = 40.dp)' in ui
# ---------------------------------------------------------------- code31: caption styles + Legendas automáticas
J='app/src/main/java/com/sonusstudios/sonusedit/'
for f in ['create/CaptionStyles.kt','media/CaptionStyleRenderer.kt','media/CaptionTypefaces.kt','ui/AutoCaptionsScreen.kt','ui/CaptionPreviewViews.kt']:
    assert (r/(J+f)).is_file(), f
assert (r/'app/src/test/java/com/sonusstudios/sonusedit/create/Code31CaptionStylesTest.kt').is_file()
styles = rd(J+'create/CaptionStyles.kt'); renderer = rd(J+'media/CaptionStyleRenderer.kt')
enum_body = styles.split('enum class CaptionStyleId')[1].split('\n}')[0]
assert len(re.findall(r'^\s+[A-Z_]+\("', enum_body, flags=re.M)) == 10
for name in ['CLASSIC','WORD_BY_WORD','KARAOKE','POP_IN','BUILD_UP','HIGHLIGHT_BOX','NEON','RISE','NEWS_BAR','CINEMA']:
    assert f'CaptionStyleId.{name} ->' in renderer, name
assert 'val textScale: Float = 1f' in renderer
# one renderer for preview and export
assert 'CaptionStyleRenderer' in visual and 'draft.captionStyle' in visual and 'draft.captionPosition' in visual
assert 'CaptionStyleRenderer' in rd(J+'ui/CaptionPreviewViews.kt')
# draft/model/settings contracts (old drafts keep loading: every new field has a default)
for field in ['val captionStyle: CaptionStyleId = CaptionStyleId.CLASSIC','val captionPosition: CaptionPosition = CaptionPosition.MIDDLE','val fitFullFrame: Boolean = false']:
    assert field in models, field
assert 'val captionStyle: CaptionStyleId = CaptionStyleId.CLASSIC' in rd(J+'create/CreationDraftStore.kt')
assert 'preferredCaptionStyle' in rd(J+'create/AutomationPreferences.kt') and 'preferredCaptionStyle' in rd(J+'ui/AutomationSettingsScreen.kt')
assert 'draft.captionStyle' in rd(J+'media/ExportForegroundService.kt')
exporter = rd(J+'media/AutomaticVideoExporter.kt')
assert 'draft.fitFullFrame' in exporter and 'Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP' in exporter
# style row, live preview and refresh button in the create flow
assert 'CaptionStylePicker(' in ui and 'CaptionStyleSelector.refresh(captionStyle)' in ui and 'CaptionOverlayCanvas(' in ui
# Home: gear beside the crown; Link | Legendas automáticas; Estatísticas | Rascunho
home = rd(J+'ui/HomeScreen.kt')
assert 'onAutoCaptions' in home and 'IconButton(onClick = onSettings' in home and 'title = "Ajustes"' not in home
assert home.index('"Criar com Link"') < home.index('"Legendas"') < home.index('"Estatísticas"') < home.index('"Rascunho"')
# navigation + screen
assert 'AutoCaptions' in rd('app/src/main/java/com/sonusstudios/sonusedit/navigation/AppRoute.kt')
app = rd(J+'ui/SonusEditApp.kt')
assert 'AutoCaptionsScreen(' in app and 'onAutoCaptions' in app and 'editorFromAutoCaptions' in app
auto = rd(J+'ui/AutoCaptionsScreen.kt')
assert 'LONG_VIDEO_WARNING_MS = 3L * 60_000L' in auto and 'ActivityResultContracts.OpenDocument()' in auto
assert 'fitFullFrame = true' in auto and 'particlesEnabled = false' in auto and 'metadataOverlayEnabled = false' in auto
assert 'CaptionPositionPicker' in auto and 'CaptionStylePicker' in auto and 'onRefreshStyle' in auto
assert 'androidx.compose.foundation.clickable(onClick' not in auto
print('CODE31 / SONUS Edit 1.7 static guards passed')
