#!/usr/bin/env python3
"""Static release checks for Sonus Edit 1.0.7 / CODE 17."""
from pathlib import Path

root = Path(__file__).resolve().parents[1]
def read(path): return (root / path).read_text(encoding="utf-8")
def need(condition, label):
    if not condition:
        raise SystemExit(f"FAIL: {label}")
    print(f"PASS: {label}")

build = read("app/build.gradle.kts")
version = read("BUILD_VERSION.txt")
home = read("app/src/main/java/com/sonusstudios/sonusedit/ui/HomeScreen.kt")
flow = read("app/src/main/java/com/sonusstudios/sonusedit/ui/CreateFlowScreen18.kt")
about = read("app/src/main/java/com/sonusstudios/sonusedit/ui/AboutScreen.kt")
auto = read("app/src/main/java/com/sonusstudios/sonusedit/ui/AutoCaptionsScreen.kt")
editor = read("app/src/main/java/com/sonusstudios/sonusedit/ui/EditorScreen.kt")
exporter = read("app/src/main/java/com/sonusstudios/sonusedit/media/AutomaticVideoExporter.kt")
service = read("app/src/main/java/com/sonusstudios/sonusedit/media/ExportForegroundService.kt")
fallback = read("app/src/main/java/com/sonusstudios/sonusedit/media/ExportCapabilities02.kt")
drafts = read("app/src/main/java/com/sonusstudios/sonusedit/create/CreationDraftStore.kt")
trim = read("app/src/main/java/com/sonusstudios/sonusedit/create/SegmentTrimPlanner12.kt")
home_screen = home
whisper = read("app/src/main/java/com/sonusstudios/sonusedit/create/WhisperCaptionEngine.kt")

need('applicationId = "com.sonusstudios.sonusedit"' in build, "applicationId preserved")
need('versionCode = 17' in build and 'versionName = "1.0.7"' in build, "Gradle version 1.0.7 / 17")
need('versionName=1.0.7' in version and 'versionCode=17' in version, "BUILD_VERSION version 1.0.7 / 17")
need('Text("1.0.7"' in home and 'Text("1.0.7"' in flow, "home and creation UI show 1.0.7")
need('Versão 1.0.7' in about and '1.0.7 • CODE 17' in about, "About screen release identity")

need('import com.sonusstudios.sonusedit.create.CaptionProgressEstimator13' in auto, "automatic captions uses the shared progress estimator")
need('val captionProgressPercent = CaptionProgressEstimator13.percent(' in auto, "automatic captions computes a visible percentage")
need('processedAudioMs = captionProgress?.processedAudioMs ?: etaProcessedAudioMs' in auto, "processed audio checkpoints feed the percentage")
need('progressPercent = captionProgressPercent' in auto, "percentage is passed into the red status pill")
need('waitingForModel =' in auto and 'completed = captionCompleted' in auto, "model load and completion are handled without false 100 percent")
need('processedAudioProvidesVisiblePercentWhenWhisperCheckpointHasNoPercent' in read("app/src/test/java/com/sonusstudios/sonusedit/create/CaptionProgressEstimator13Test.kt"), "regression test for the automatic captions percentage")

need('if (draft.fitFullFrame)' in exporter and 'return@buildList' in exporter, "caption-only full-frame path bypasses per-clip resizing")
fullframe_branch = exporter.split('if (draft.fitFullFrame)', 1)[1].split('val outputWidth = draft.outputWidth()', 1)[0]
need('LanczosResample.scaleToFit' not in fullframe_branch and 'Presentation.createForAspectRatio' not in fullframe_branch, "no redundant per-clip Presentation/Lanczos in captions-only mode")
need('Presentation.createForWidthAndHeight(draft.outputWidth(), draft.outputHeight()' in exporter, "final composition still applies exact output size")
need('VideoVisualEffects.globalOverlay(context, draft)' in exporter, "caption overlay remains in the composition")
need('fullFrame=${draft?.fitFullFrame}' in service and 'captions=${draft?.captionSegments?.size}' in service, "device error diagnostics include caption export context")

need('Previsão disponível após 5 exportações' not in editor and '(${serviceState.etaSampleCount}/5)' not in editor, "internal ETA sample count is hidden from users")
need('estimatedRemainingMs?.let' in editor, "available ETA remains visible")
need('MODEL_NAME = "ggml-small.bin"' in whisper and 'ENGINE_VERSION = 16' in whisper, "Whisper Small engine preserved")
need('SONUS_KEYSTORE_PATH' in read("app/build.gradle.kts") and 'SONUS_KEYSTORE_PASSWORD' in read("app/build.gradle.kts"), "persistent signing environment contract preserved")
need('AtomicFile(' in drafts and 'startWrite()' in drafts and 'finishWrite(stream)' in drafts and 'failWrite(it)' in drafts, "drafts use crash-safe atomic persistence")
need('shouldApplySmartStart' in trim and 'trimIsProtected' in trim, "restored trim is protected from automatic start recalculation")
need('mutableStateOf(resumeDraft != null)' in flow and 'initialTrimSeekApplied' in flow and 'playerReadyUri != selectedUri' in flow and 'player.seekTo(initialPosition)' in flow, "restored draft locks and seeks to its saved audio trim after media is ready")
need('Lifecycle.Event.ON_RESUME' in home_screen and 'draftStore.exists()' in home_screen, "draft availability refreshes on Home resume")
need('MUXER_WATCHDOG_MS = 90_000L' in exporter, "initial muxer output has a 90-second device-safe window")
need('catch (error: OutOfMemoryError)' in exporter and 'buildComposition(draft)' in exporter, "composition construction and memory errors are handled")
need('SonusEdit-Composition' in exporter and 'renderGeneration' in exporter and 'main.post {' in exporter, "composition preparation runs off-main with cancellation protection")
need('totalMs - 1_000L' in trim and 'remember(audioUri, audioSource)' in flow, "restored trim seek respects minimum segment and source identity")
need('no output sample' in fallback and 'muxer error' in fallback, "muxer stalls can retry with a lighter export")
need('catch (error: Throwable)' in service and 'startExportForeground(buildNotification(0, "Vídeo"' in service, "foreground service starts promptly and guards export failures")
need('CODE 17 • SONUS Link Engine' in about and '1.0.7 • CODE 17' in about, "About screen describes CODE17")

link_importer = read("app/src/main/java/com/sonusstudios/sonusedit/create/LinkAudioImporter.kt")
link_engine = read("app/src/main/java/com/sonusstudios/sonusedit/create/SonusLinkEngine.kt")
need('versionCode = 17' in build and 'versionName = "1.0.7"' in build, "CODE17 app version")
need('SonusEdit_1.0.7_CODE17.zip' in read("codemagic.yaml"), "Codemagic prioritizes the CODE17 source package")
need('io.github.junkfood02.youtubedl-android' not in build, "yt-dlp dependency removed")
need('io.github.junkfood02.youtubedl-android:ffmpeg' not in build, "yt-dlp FFmpeg module removed")
need('dev.ffmpegkit-maintained:whisper-android:1.0.0' in build, "Whisper Android dependency preserved")
need('SonusLinkEngine(context.applicationContext)' in link_importer, "importer delegates to SONUS Link Engine")
need('HttpURLConnection' in link_engine and 'BufferedInputStream' in link_engine, "native HTTP streaming implementation present")
need('SonusLinkSourceClassifier' in link_engine and 'isPlatformPage' in link_engine, "platform links are classified without page scraping")
need('activeConnections' in link_engine and 'fun cancel(' in link_engine, "active transfer cancellation is available")
need('CACHE_MAX_AGE_MS' in link_engine and 'cleanupStaleFiles' in link_engine, "temporary media cleanup is available")
need('retryable' in link_engine and 'LinkImportFailure' in link_engine, "retry policy distinguishes transient failures")
need('class SonusLinkEngineTest' in read("app/src/test/java/com/sonusstudios/sonusedit/create/SonusLinkEngineTest.kt") and 'additionalSocialAndMediaPlatformsAreRecognized' in read("app/src/test/java/com/sonusstudios/sonusedit/create/SonusLinkEngineTest.kt"), "SONUS Link Engine regression tests exist")
need('import com.yausername.youtubedl_android.YoutubeDL' not in link_importer, "legacy yt-dlp imports removed")
need('import com.yausername.ffmpeg.FFmpeg' not in link_importer, "legacy FFmpeg imports removed")
print("Sonus Edit 1.0.7 / CODE 17 static validation passed.")
