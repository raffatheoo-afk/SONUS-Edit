#!/usr/bin/env python3
"""Static release-contract validation for Sonus Edit 0.0.7 / CODE 07."""
from pathlib import Path
import base64
import hashlib
import re

ROOT = Path(__file__).resolve().parents[1]

def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")

def require(condition: bool, message: str) -> None:
    if not condition:
        raise SystemExit(f"CODE07 validation failed: {message}")

BUILD = read("app/build.gradle.kts")
VERSION = read("BUILD_VERSION.txt")
YAML = read("codemagic.yaml")
FLOW = read("app/src/main/java/com/sonusstudios/sonusedit/ui/CreateFlowScreen18.kt")
MODELS = read("app/src/main/java/com/sonusstudios/sonusedit/create/CreateModels.kt")
WHISPER = read("app/src/main/java/com/sonusstudios/sonusedit/create/WhisperCaptionEngine.kt")
EXPORTER = read("app/src/main/java/com/sonusstudios/sonusedit/media/AutomaticVideoExporter.kt")
VISUAL = read("app/src/main/java/com/sonusstudios/sonusedit/media/VideoVisualEffects.kt")
REPO = read("app/src/main/java/com/sonusstudios/sonusedit/catalog/PCloudCatalogRepository.kt")
CATALOG = read("app/src/main/java/com/sonusstudios/sonusedit/catalog/PCloudCatalog.kt")
AUTO = read("app/src/main/java/com/sonusstudios/sonusedit/ui/AutoCaptionsScreen.kt")
ABOUT = read("app/src/main/java/com/sonusstudios/sonusedit/ui/AboutScreen.kt")
PLANS = read("app/src/main/java/com/sonusstudios/sonusedit/ui/PremiumPlansScreen.kt")
SETTINGS = read("app/src/main/java/com/sonusstudios/sonusedit/ui/AutomationSettingsScreen.kt")
PREFS = read("app/src/main/java/com/sonusstudios/sonusedit/create/AutomationPreferences.kt")
FONT_COLOR = read("app/src/main/java/com/sonusstudios/sonusedit/create/LyricColorPalette24.kt")
RENDERER = read("app/src/main/java/com/sonusstudios/sonusedit/media/CaptionStyleRenderer.kt")
PICKER = read("app/src/main/java/com/sonusstudios/sonusedit/ui/CaptionPreviewViews.kt")

# Version, application identity, workflow, Media3 and protected signing identity.
require('applicationId = "com.sonusstudios.sonusedit"' in BUILD, "applicationId changed")
require('versionCode = 7' in BUILD and 'versionName = "0.0.7"' in BUILD, "Gradle version is not 0.0.6 / code06")
require('versionName=0.0.7' in VERSION and 'versionCode=7' in VERSION, "BUILD_VERSION.txt mismatch")
require('sonus-edit-0-0-3-code03-debug:' in YAML, "Codemagic workflow ID changed")
require('sonusPersistent' in BUILD and "SONUS_KEY_ALIAS='sonusedit'" in YAML, "persistent signing contract missing")
embedded = re.search(r'data = "([A-Za-z0-9+/=]+)"', YAML)
require(embedded is not None, "embedded signing material missing")
require(hashlib.sha256(base64.b64decode(embedded.group(1))).hexdigest() ==
        'b3884a61a389fcc2090846ff47926935337cfc522cf367418f68eab879fb0295',
        "permanent signing key fingerprint changed")
require(BUILD.count('androidx.media3:media3-') == 5 and ':1.10.1"' in BUILD, "Media3 dependency contract changed")
for dep in [
    'io.github.junkfood02.youtubedl-android:library:0.18.1',
    'io.github.junkfood02.youtubedl-android:ffmpeg:0.18.1',
    'dev.ffmpegkit-maintained:whisper-android:1.0.0',
]:
    require(dep in BUILD, f"dependency missing: {dep}")
require('ENGINE_VERSION = 16' in WHISPER and 'Whisper Small' in WHISPER, "Whisper engine/model contract changed")
require('setVideoCompositorSettings' in EXPORTER and 'if (layered)' in EXPORTER, "Media3 single-layer compositor contract changed")
require('ExportRecoveryPolicy14.shouldRetryInChunks' in EXPORTER and 'setMaxDelayBetweenMuxerSamplesMs' in EXPORTER,
        "long-export fallback/watchdog contract missing")

# Captions: 20 distinct looks, exactly ten illustrative Premium; preview and export share renderer.
styles = read("app/src/main/java/com/sonusstudios/sonusedit/create/CaptionStyles.kt")
style_enum = styles.split('enum class CaptionStyleId')[1].split('\n}')[0]
style_names = re.findall(r'^\s*([A-Z_]+)\("', style_enum, flags=re.M)
require(len(style_names) == 20, f"expected 20 caption styles, found {len(style_names)}")
require(len(re.findall(r'^\s*[A-Z_]+\([^\n]*, true\),?$', style_enum, flags=re.M)) == 10,
        "expected exactly ten illustrative Premium caption styles")
for name in style_names:
    require(f'CaptionStyleId.{name} ->' in RENDERER, f"style renderer missing: {name}")
require('items(CaptionStyleId.entries.toList())' in PICKER and '👑' in PICKER,
        "caption style picker must stay horizontally browsable with a small crown marker")
require('Modifier.width(96.dp).height(60.dp)' in PICKER and '.height(42.dp)' in PICKER,
        "caption style preview cards were not shortened")
require('CaptionStyleRenderer' in VISUAL and 'draft.captionStyle' in VISUAL, "export renderer not connected")
require('boundedEnd' in styles and 'totalMs < tokens.size.toLong()' in styles,
        "word timings are not bounded to the original phrase interval")

# Fonts: only thirty selected natural system-family variants appear in the active pool.
font_block = MODELS.split('object CaptionFontPool')[1].split('private val retiredReplacement')[0]
font_ids = re.findall(r'FontPresetId\.([A-Z0-9_]+)', font_block.split('val approved:')[1])
require(len(font_ids) == 11 and len(set(font_ids)) == 11, "CODE05 font pool must expose exactly 11 authentic choices")
require(font_ids[0] == 'NORMAL_SANS', "neutral Sans-serif option must remain first")
font_assets = sorted(re.findall(r'assetFileName = \"([^\"]+)\"', MODELS))
require(len(font_assets) == 10 and len(set(font_assets)) == 10, "ten custom font asset references must be restored")
for asset in font_assets:
    require((ROOT / 'app/src/main/assets/fonts' / asset).is_file(), f"restored font asset missing: {asset}")
require('CaptionFontPool.approved' in FLOW and 'randomOpeningFont' in FLOW,
        "font selector or legacy random opening font missing")
require('Modifier.width(64.dp)' in FLOW and 'Fonte • deslize para o lado' in FLOW,
        "restored fonts are not presented in a compact horizontal selector")
typefaces = read('app/src/main/java/com/sonusstudios/sonusedit/media/CaptionTypefaces.kt')
require('Typeface.createFromAsset(context.assets, "fonts/$asset")' in typefaces,
        "custom font asset resolver was not restored")
require('fontPreviewStyle18' in FLOW and 'createFromAsset(context.assets, "fonts/$name")' in FLOW,
        "font previews do not use the restored custom assets")
for prefix in ['SANS_', 'SERIF_', 'MONO_']:
    require(prefix in MODELS, f"legacy CODE06 identifiers must remain serializable: {prefix}")
require('CaptionFontPool.isRetired(it)' in read('app/src/test/java/com/sonusstudios/sonusedit/create/Code30CaptionFontPoolTest.kt'),
        "legacy system font alias regression coverage missing")

# Palette: dynamic + 24 named colors, horizontally scrollable; dynamic remains illustrative only.
color_enum = MODELS.split('enum class LyricColorPreset')[1].split('\n}')[0]
color_ids = re.findall(r'([A-Z_]+)\("', color_enum)
require(len(color_ids) == 25, f"expected 25 color options, found {len(color_ids)}")
for name in color_ids:
    require(f'LyricColorPreset.{name} ->' in FONT_COLOR, f"color palette mapping missing: {name}")
require('dynamicColorCount(): Int = dynamicColors.size' in FONT_COLOR and '0xFF000000' not in FONT_COLOR.split('private val dynamicColors')[1].split('fun argb')[0],
        "dynamic palette must retain contrast and exclude black")
require('items(visibleLyricColors24)' in FLOW and 'Text("👑"' in FLOW,
        "compact horizontal palette or small Dynamic crown marker missing")
require('Modifier.width(56.dp)' in FLOW and 'height(34.dp)' in FLOW,
        "color selector tiles were not compacted")

# Filters: 15 free + 10 illustrative Premium, all visible effects have a real renderer.
filter_enum = MODELS.split('enum class FilterPresetId')[1].split('\n}')[0]
filter_names = re.findall(r'^\s*([A-Z_]+)\("', filter_enum, flags=re.M)
require(len(filter_names) == 27, f"expected 27 stable filter IDs, found {len(filter_names)}")
free_block = FLOW.split('private val freeFilters18')[1].split('private val premiumFilters18')[0]
premium_block = FLOW.split('private val premiumFilters18')[1].split('internal val visibleLyricColors24')[0]
require(len(re.findall(r'FilterPresetId\.[A-Z_]+', free_block)) == 15, "free filter row must have 15 options")
require(len(re.findall(r'FilterPresetId\.[A-Z_]+', premium_block)) == 10, "Premium filter row must have 10 options")
require(len(re.findall(r'^\s+[A-Z_]+\("[^"]+", true\),?$', filter_enum, flags=re.M)) == 10,
        "expected 10 Premium filter badges")
for name in filter_names:
    require(f'FilterPresetId.{name} ->' in VISUAL, f"filter effect missing: {name}")
require('FilterPresetId.BLACK_AND_WHITE' in read('app/src/main/java/com/sonusstudios/sonusedit/create/AutomationPlanner.kt'),
        "automatic filter selection must exclude black and white")
require('automaticFilter: Boolean = false' in PREFS and 'automaticFilter = prefs[Keys.Filter] ?: false' in PREFS,
        "automatic filter must keep the neutral default while preserving explicit saved choices")
require('items(freeFilters18)' in FLOW and 'items(premiumFilters18)' in FLOW and '👑 10 efeitos Premium' in FLOW,
        "two horizontal filter rows or small Premium crown marker missing")
require('Deslize para o lado • toque para aplicar • segure para favoritar' in FLOW and 'Text("FILTROS"' in FLOW,
        "filter hint is not aligned beside its heading")
require('Modifier.width(88.dp)' in FLOW and 'height(39.dp)' in FLOW,
        "filter preview cards were not compacted")

# Gallery: cache-first, three portrait sources, server presence memory, concurrent progressive requests.
require('IMAGE_PUBLIC_CODES = listOf(IMAGE_PUBLIC_CODE, IMAGE_PUBLIC_CODE_SECONDARY, IMAGE_PUBLIC_CODE_TERTIARY)' in CATALOG,
        "portrait image servers 1/2/3 missing")
require('IMAGE_HORIZONTAL_PUBLIC_CODES = listOf(IMAGE_HORIZONTAL_PUBLIC_CODE, IMAGE_HORIZONTAL_PUBLIC_CODE_SECONDARY)' in CATALOG,
        "horizontal source configuration unexpectedly changed")
require('refreshSearchProgressively' in REPO and 'onPartial(previous)' in REPO,
        "search must publish the cached catalog immediately")
require('knownPresence(code)' in REPO and 'toBooleanStrictOrNull()' in REPO,
        "empty/unknown server state is not distinguished")
require('launch(Dispatchers.IO)' in REPO and 'channel.receive()' in REPO,
        "gallery source searches are not concurrent/progressive")
require('GallerySearchRotation.order' in REPO and 'GallerySearchRotation.nextIndex' in REPO,
        "round-robin server rotation missing")
require('PROJECTS_TO_BLOCK = 15' in read('app/src/main/java/com/sonusstudios/sonusedit/create/SmartImageSelector.kt'),
        "15-video anti-repeat history changed")
require('CircularProgressIndicator' in FLOW and 'Color(0xFF35E77C)' in FLOW and 'BUSCANDO' in FLOW,
        "visible green gallery search status missing")
require('if (elapsed < 1_800L) delay(1_800L - elapsed)' in FLOW,
        "gallery status minimum visibility changed")
require('if (video) Text("VÍDEO"' in FLOW and 'if (isVideo)' in FLOW,
        "video badge must be exclusive to video assets")
require('galleryServerNumber18' not in FLOW and 'serverNumber' not in FLOW,
        "gallery source-number badges should not label image cards")

# Auto-caption audio presence: real track probe with retriever fallback, no artificial 30s minimum.
require('MediaExtractor()' in AUTO and 'MediaFormat.KEY_MIME' in AUTO and 'startsWith("audio/")' in AUTO,
        "auto-caption flow does not inspect actual audio tracks")
require('retrieverHasAudio' in AUTO, "legacy metadata fallback missing")
WAV = read('app/src/main/java/com/sonusstudios/sonusedit/create/AudioSegmentWavExtractor.kt')
require('TARGET_RATE / 10L' in WAV, "short audio chunk threshold unexpectedly changed")
require('durationMs <= 0L' in WHISPER or 'durationMs > 0L' in WHISPER,
        "Whisper duration contract missing")

# Local MP3 preview: player prepares before embedded metadata is read; ready-state metadata unlocks controls.
audio_effect = FLOW.split('LaunchedEffect(audioUri) {', 1)[1].split('LaunchedEffect(playerDurationMs', 1)[0]
require(audio_effect.index('player.prepare()') < audio_effect.index('AudioMetadataReader.read'),
        "ExoPlayer preparation is still waiting for embedded metadata")
require('playerDurationMs' in FLOW and 'playerReady' in FLOW and 'Música selecionada' in FLOW,
        "early metadata fallback/player-ready state missing")
require('if (!playerReady)' in FLOW and 'Preparando áudio' in FLOW,
        "trim preview controls must wait only for ExoPlayer readiness")

# Review screen: compact toggle, slim timeline, larger responsive preview, no visible FPS row, default 30.
review = FLOW.split('private fun ReviewStep18(')[1].split('\n@Composable', 1)[0]
require('Legendas nesse vídeo' in review and 'Switch(' in review, "compact caption toggle missing")
require('height(16.dp)' in FLOW, "review progress bar is not slim")
require('imageHeightBudget' in review and 'previewWidth' in review, "responsive review preview sizing missing")
require('Text("FPS' not in review, "FPS control remains visible in review")
require('val defaultFps: Int = 30' in PREFS and 'else 30' in FLOW,
        "30 FPS must remain the default")
require('ExportResolution.entries' in review and all(label in MODELS for label in ['720p','1080p','2K','4K']),
        "review resolution choices missing")
require('verticalScroll' not in review, "review screen must not require vertical scrolling")
require('Text("FPS padrão"' in SETTINGS, "FPS setting should remain available under Ajustes")

# Release notes, plan pricing and explicit no-gating policy.
require('Versão 0.0.7' in ABOUT and '0.0.7 • Code 07' in ABOUT and '20 estilos de legenda' in ABOUT,
        "About screen release notes for CODE07 missing")
for price in ['R$ 1,90', 'R$ 3,90', 'R$ 7,90', 'R$ 11,90']:
    require(price in PLANS, f"planned price missing: {price}")
require('não há cobrança, limite mensal nem bloqueio' in PLANS and 'Nenhuma opção está bloqueada' in PLANS,
        "Premium preview must not enable payments, quotas or gating")

# Preserve required image/brand assets and key export pipeline components.
for path in [
    'app/src/main/res/drawable-nodpi/sonus_edit_icon_foreground.png',
    'app/src/main/res/drawable-nodpi/sonus_edit_logo_center.png',
    'app/src/main/res/mipmap-xxxhdpi/ic_launcher.png',
    'app/src/main/res/raw/sonus_particles_green_60fps.mp4',
    'app/src/main/res/raw/sonus_particles_black_30fps.mp4',
    'app/src/main/res/raw/sonus_video_key_fragment.glsl',
]:
    require((ROOT / path).is_file(), f"brand/effect asset missing: {path}")
require('import com.yausername.ffmpeg.FFmpeg' in read('app/src/main/java/com/sonusstudios/sonusedit/create/LinkAudioImporter.kt'),
        "FFmpeg Link integration missing")
require('repeat(2)' in FLOW, "Link importer retry path changed")

# Tests added or updated with the new model changes.
for path in [
    'app/src/test/java/com/sonusstudios/sonusedit/create/Code24LyricPaletteTest.kt',
    'app/src/test/java/com/sonusstudios/sonusedit/create/Code29FontAndImageRotationTest.kt',
    'app/src/test/java/com/sonusstudios/sonusedit/create/Code30CaptionFontPoolTest.kt',
    'app/src/test/java/com/sonusstudios/sonusedit/create/Code31CaptionStylesTest.kt',
    'app/src/test/java/com/sonusstudios/sonusedit/create/Code07CaptionPositionTest.kt',
    'app/src/test/java/com/sonusstudios/sonusedit/create/AutomationPlannerTest.kt',
    'app/src/test/java/com/sonusstudios/sonusedit/catalog/GallerySearchRotationTest.kt',
]:
    require((ROOT / path).is_file(), f"CODE06 regression test missing: {path}")

print('Sonus Edit 0.0.7 / CODE 07 static validation passed.')
