#!/usr/bin/env python3
from pathlib import Path
import hashlib
r=Path(__file__).resolve().parents[1]
def rd(p): return (r/p).read_text(encoding='utf-8')
g=rd('app/build.gradle.kts'); ui=rd('app/src/main/java/com/sonusstudios/sonusedit/ui/CreateFlowScreen18.kt')
link=rd('app/src/main/java/com/sonusstudios/sonusedit/create/LinkAudioImporter.kt')
exp=rd('app/src/main/java/com/sonusstudios/sonusedit/media/AutomaticVideoExporter.kt')
whisper=rd('app/src/main/java/com/sonusstudios/sonusedit/create/WhisperCaptionEngine.kt')
service=rd('app/src/main/java/com/sonusstudios/sonusedit/media/ExportForegroundService.kt')
eta=rd('app/src/main/java/com/sonusstudios/sonusedit/create/CaptionEtaEstimator14.kt')
assert (r/'app/src/test/java/com/sonusstudios/sonusedit/create/Code28StabilityTest.kt').exists()
assert 'versionCode = 30' in g and 'versionName = "1.6"' in g
assert 'versionCode=30' in rd('BUILD_VERSION.txt')
assert 'versionName=1.6' in rd('BUILD_VERSION.txt')
assert 'sonusPersistent' in g and 'io.github.junkfood02.youtubedl-android:ffmpeg:0.18.1' in g
assert 'androidx.media3:media3-transformer:1.10.1' in g
assert 'UpdateChannel.STABLE' in link and 'updateYoutubeDL(' in link
assert 'verify' in link and 'copyTo(installed, overwrite = true)' in link
assert 'refreshResolverIfDue(onProgress)' in link and 'FFmpeg.getInstance().init' in link
assert 'startLongExport(draft, onCompleted, onError, RETRY_SEGMENT_MS)' in exp
assert 'ExportRecoveryPolicy14.shouldRetryInChunks' in exp
assert 'setMaxDelayBetweenMuxerSamplesMs(MUXER_WATCHDOG_MS)' in exp
assert 'visualDurationsMs' in exp and 'buildRawParticleSequence(draft)' in exp
assert 'ENGINE_VERSION = 14' in whisper and 'Whisper Small' in whisper
assert 'CaptionLanguageHint.fromTranscription' in whisper and 'lockedLanguage' in whisper
assert 'CaptionEtaEstimator14.expectedTotalMs' in ui and 'CaptionEtaEstimator14.record' in ui
assert '"sonus_caption_eta_code28"' in eta
assert 'SonusEditExport' in service and 'Build.MANUFACTURER' in service
for path in ['app/src/main/res/raw/sonus_particles_green_60fps.mp4','app/src/main/res/raw/sonus_particles_black_30fps.mp4']:
    p=r/path
    assert p.is_file() and p.stat().st_size > 100_000, path
assert 'Text("1.6"' in ui

models=rd('app/src/main/java/com/sonusstudios/sonusedit/create/CreateModels.kt')
images=rd('app/src/main/java/com/sonusstudios/sonusedit/create/SmartImageSelector.kt')
stats=rd('app/src/main/java/com/sonusstudios/sonusedit/stats/UsageStatsStore.kt')
visual=rd('app/src/main/java/com/sonusstudios/sonusedit/media/VideoVisualEffects.kt')
preview=rd('app/src/main/java/com/sonusstudios/sonusedit/ui/PreviewEffectFrames.kt')
shader=rd('app/src/main/res/raw/sonus_video_key_fragment.glsl')
assert 'NORMAL_SANS' in models and 'NORMAL_SERIF' in models
assert 'assetFileName' in models and 'Magic Clover.otf' in models
assert 'recentAcrossLastProjects()' in images and 'take(3)' in images
assert 'if (freshAllowed.size >= count) freshAllowed else policy.allowed' in images
assert 'automaticWorkMs = old.automaticWorkMs + draft.automaticWorkMs,' in stats
assert 'editingStartedEpochMs' in ui and 'imageHistoryStore.recordProject' in ui
assert 'cloudOptimized = remoteSource != null' in rd('app/src/main/java/com/sonusstudios/sonusedit/media/AutomaticVideoExporter.kt')
assert 'uMode < 2.5' in shader and 'brightness < 0.105' in shader
assert 'cloudOptimized' in preview and 'smooth(.105f, .315f, brightness)' in preview
font_assets=list((r/'app/src/main/assets/fonts').glob('*'))
assert len(font_assets) == 16, len(font_assets)  # 19 fonts removed in code30
font_hashes=[hashlib.sha256(p.read_bytes()).hexdigest() for p in font_assets]
assert len(set(font_hashes)) == len(font_hashes), 'duplicate font binaries remain'
import re
entries=re.findall(r'\w+\("[^"]*", assetFileName = "([^"]+)"\)', models)
assert len(entries)==16 and set(entries)=={p.name for p in font_assets}, entries
for entry in entries:
    assert (r/'app/src/main/assets/fonts'/entry).is_file(), entry
assert 'CaptionFontPool.approved.shuffled().take(8)' in ui and 'Fonte dinâmica' in ui
assert 'FontPresetId.entries.shuffled()' not in ui and 'FontPresetId.entries.random()' not in ui
assert 'CaptionFontPool.approved.random()' in ui and 'object CaptionFontPool' in models
assert 'requested.effective()' in visual and 'requested.effective()' in ui
for gone in ['Roomboy.otf','Casa Pinada.ttf','Tharon.ttf','DifferentSunset.ttf','Jabawoky.ttf','Milliwatts demo.otf','Florida Orange - Personal Use.ttf','DeepAbyss.otf','Folders.ttf','MyLove.ttf','My Kids Handwritten.otf','I_Love_January.otf','TheAbsolute.otf','On The Way.ttf','UnforgottenMore1.otf','Panterick Swash.ttf','Gambler in Town.ttf','Oliver Richards.ttf','RJOETRIAL.ttf']:
    assert not (r/'app/src/main/assets/fonts'/gone).exists(), gone
    assert gone not in models, gone
assert (r/'app/src/test/java/com/sonusstudios/sonusedit/create/Code30CaptionFontPoolTest.kt').is_file()
# Digital clock: DS-Digital Bold, license text shipped beside it, counter uses it
assert (r/'app/src/main/assets/ui_fonts/DS-DIGIB.TTF').stat().st_size == 24896
assert 'Dusit Supasawat' in (r/'app/src/main/assets/ui_fonts/DIGITAL.TXT').read_text(encoding='latin-1')
assert 'ui_fonts/DS-DIGIB.TTF' in ui and 'fontFamily = digitalClockFamily' in ui and 'Modifier.widthIn(min = 40.dp)' in ui
print('CODE30 / SONUS Edit 1.6 static guards passed')
