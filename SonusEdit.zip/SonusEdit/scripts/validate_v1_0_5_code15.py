#!/usr/bin/env python3
"""Static release checks for Sonus Edit 1.0.5 / CODE 15."""
from pathlib import Path

root = Path(__file__).resolve().parents[1]
def read(path): return (root / path).read_text(encoding="utf-8")
def need(condition, label):
    if not condition:
        raise SystemExit(f"FAIL: {label}")
    print(f"PASS: {label}")

build = read("app/build.gradle.kts")
version = read("BUILD_VERSION.txt")
home = read("app/src/main/java/com/sonusstudios/sonusedit/ui/HomeScreen.kt")
flow = read("app/src/main/java/com/sonusstudios/sonusedit/ui/CreateFlowScreen18.kt")
about = read("app/src/main/java/com/sonusstudios/sonusedit/ui/AboutScreen.kt")
exporter = read("app/src/main/java/com/sonusstudios/sonusedit/media/AutomaticVideoExporter.kt")
transitions = read("app/src/main/java/com/sonusstudios/sonusedit/create/VisualTransitionPreferences.kt")
service = read("app/src/main/java/com/sonusstudios/sonusedit/media/ExportForegroundService.kt")
eta = read("app/src/main/java/com/sonusstudios/sonusedit/media/ExportEtaEstimator15.kt")
stats = read("app/src/main/java/com/sonusstudios/sonusedit/stats/UsageStatsStore.kt")
whisper = read("app/src/main/java/com/sonusstudios/sonusedit/create/WhisperCaptionEngine.kt")

need('applicationId = "com.sonusstudios.sonusedit"' in build, "applicationId preserved")
need('versionCode = 15' in build and 'versionName = "1.0.5"' in build, "Gradle version 1.0.5 / 15")
need('versionName=1.0.5' in version and 'versionCode=15' in version, "BUILD_VERSION version 1.0.5 / 15")
need('Text("1.0.5"' in home and 'Text("1.0.5"' in flow, "home and creation UI show 1.0.5")
need('Versão 1.0.5' in about and '1.0.5 • CODE 15' in about, "About screen release identity and notes")

thumb_start = flow.index("private suspend fun loadRemoteAssetThumbnail18(")
thumb_end = flow.index("/** LRU-style cap", thumb_start)
thumb_fn = flow[thumb_start:thumb_end]
need('File(context.filesDir, "sonus_gallery_thumbs_v3")' in thumb_fn, "gallery thumbnail cache is durable")
need('repo.downloadUrl(asset)' not in thumb_fn, "gallery cards never download original media for thumbnails")
need('repo.invalidateThumbnailUrl(asset)' in thumb_fn, "expired thumbnail URL gets one refresh")
need('galleryThumbnailSemaphore18 = Semaphore(3)' in flow and 'assets.distinctBy { it.stableKey }.take(10)' in flow, "gallery prefetch is capped at ten with three concurrent workers")
need('galleryThumbnailInFlight15' in thumb_fn, "duplicate thumbnail requests share in-flight work")
need('searchManualGallery' in flow, "manual gallery search remains independent")

need('assignmentsForExport' in transitions and 'transitionAssignments[index]' in exporter, "export consumes validated saved transition assignments")
need('require(assignments.size == mediaCount)' in transitions and 'require(assignments.all { it in validIds })' in transitions, "partial or unknown transitions are rejected")
need('transitionAssignmentInvalid' in flow and 'Transição não definida' in flow, "preview surfaces missing transition assignments")
need('transitionAssignments[index]' in exporter and 'getOrNull(index) ?: "fade"' not in exporter, "export no longer silently defaults a missing assignment to Fade")
need('onError(error)' in exporter and 'assignmentsForExport(draft.visualTransitionIds' in exporter, "invalid transition draft returns a handled export error")

need('recentExportSamples' in stats and 'MAX_EXPORT_TIMING_SAMPLES = 20' in stats, "last twenty individual successful exports are stored locally")
need('MIN_SAMPLES = 5' in eta and 'take(10)' in eta, "ETA uses at least five historical samples")
need('reported?.coerceAtMost(99)' in service and 'estimatedRemainingMs' in service, "export holds at 99 until saved and updates ETA")
need('Tempo restante estimado' in read("app/src/main/java/com/sonusstudios/sonusedit/ui/EditorScreen.kt"), "export ETA is displayed")
need('MODEL_NAME = "ggml-small.bin"' in whisper and 'ENGINE_VERSION = 16' in whisper, "Whisper Small engine preserved")
need((root/"app/src/test/java/com/sonusstudios/sonusedit/media/ExportEtaEstimator15Test.kt").is_file(), "ETA tests present")
need((root/"app/src/test/java/com/sonusstudios/sonusedit/create/VisualTransitionCatalogTest.kt").is_file(), "transition regression tests present")
print("Sonus Edit 1.0.5 / CODE 15 static validation passed.")
