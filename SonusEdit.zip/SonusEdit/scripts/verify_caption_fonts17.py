#!/usr/bin/env python3
"""Verify Latin Extended Portuguese glyph coverage in bundled CODE17 caption TTFs."""
from pathlib import Path
import struct
import sys

FONT_FILES = [
    "Caveat[wght].ttf",
    "DancingScript[wght].ttf",
    "PatrickHand-Regular.ttf",
    "Kalam-Regular.ttf",
    "KaushanScript-Regular.ttf",
]
# Every Portuguese letter (including acute, grave, circumflex, tilde, cedilla and diaeresis),
# plus basic Latin letters/digits and the punctuation used by caption text.
REQUIRED = [ord(c) for c in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 áàâãéêíóôõúüçÁÀÂÃÉÊÍÓÔÕÚÜÇºª.,!?;:'\"-()"]
LICENSE_FILES = [
    "Caveat-OFL.txt",
    "DancingScript-OFL.txt",
    "PatrickHand-OFL.txt",
    "Kalam-OFL.txt",
    "KaushanScript-OFL.txt",
]


def u16(data, offset):
    return struct.unpack_from(">H", data, offset)[0]


def u32(data, offset):
    return struct.unpack_from(">I", data, offset)[0]


def cmap_glyphs(data):
    if len(data) < 12 or data[:4] not in (b"\x00\x01\x00\x00", b"OTTO", b"true"):
        raise ValueError("arquivo não é uma fonte SFNT TTF/OTF válida")
    table_count = u16(data, 4)
    tables = {}
    for i in range(table_count):
        pos = 12 + i * 16
        tag = data[pos:pos + 4].decode("ascii", "replace")
        tables[tag] = (u32(data, pos + 8), u32(data, pos + 12))
    if "cmap" not in tables:
        raise ValueError("tabela cmap ausente")
    base, length = tables["cmap"]
    cmap = data[base:base + length]
    records = u16(cmap, 2)
    maps = []
    for i in range(records):
        pos = 4 + i * 8
        off = u32(cmap, pos + 4)
        fmt = u16(cmap, off)
        if fmt == 12:
            groups = u32(cmap, off + 12)
            found = set()
            for j in range(groups):
                g = off + 16 + j * 12
                start, end, start_glyph = u32(cmap, g), u32(cmap, g + 4), u32(cmap, g + 8)
                for cp in REQUIRED:
                    if start <= cp <= end and start_glyph + cp - start != 0:
                        found.add(cp)
            maps.append(found)
        elif fmt == 4:
            seg_count = u16(cmap, off + 6) // 2
            end_base = off + 14
            start_base = end_base + seg_count * 2 + 2
            delta_base = start_base + seg_count * 2
            range_base = delta_base + seg_count * 2
            found = set()
            for cp in REQUIRED:
                if cp > 0xFFFF:
                    continue
                for i in range(seg_count):
                    end = u16(cmap, end_base + i * 2)
                    start = u16(cmap, start_base + i * 2)
                    if start <= cp <= end and end != 0xFFFF:
                        delta = u16(cmap, delta_base + i * 2)
                        ro_pos = range_base + i * 2
                        ro = u16(cmap, ro_pos)
                        if ro == 0:
                            glyph = (cp + delta) & 0xFFFF
                        else:
                            glyph_pos = ro_pos + ro + 2 * (cp - start)
                            glyph = u16(cmap, glyph_pos)
                            if glyph:
                                glyph = (glyph + delta) & 0xFFFF
                        if glyph:
                            found.add(cp)
                        break
            maps.append(found)
    return set.union(*maps) if maps else set()


def main():
    font_dir = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("app/src/main/assets/fonts")
    failed = []
    for name in FONT_FILES:
        path = font_dir / name
        try:
            data = path.read_bytes()
            if len(data) < 8_000:
                raise ValueError(f"arquivo muito pequeno ({len(data)} bytes)")
            missing = sorted(set(REQUIRED) - cmap_glyphs(data))
            if missing:
                raise ValueError("glifos ausentes: " + ", ".join(f"U+{cp:04X}" for cp in missing))
            print(f"OK {name}: {len(data)} bytes; glifos portugueses conferidos")
        except Exception as exc:
            failed.append((name, str(exc)))
    license_dir = font_dir / "licenses"
    for license_name in LICENSE_FILES:
        license_path = license_dir / license_name
        try:
            license_text = license_path.read_text(encoding="utf-8", errors="replace")
            if "SIL OPEN FONT LICENSE" not in license_text.upper():
                raise ValueError("licença SIL Open Font License 1.1 ausente ou inválida")
            print(f"OK licença {license_name}")
        except Exception as exc:
            failed.append((license_name, str(exc)))
    if failed:
        for name, error in failed:
            print(f"ERRO {name}: {error}", file=sys.stderr)
        return 1
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
