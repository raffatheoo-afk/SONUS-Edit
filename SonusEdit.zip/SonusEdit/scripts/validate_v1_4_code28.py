#!/usr/bin/env python3
from pathlib import Path
import hashlib
r=Path(__file__).resolve().parents[1]
def rd(p): return (r/p).read_text(encoding='utf-8')
g=rd('app/build.gradle.kts'); ui=rd('app/src/main/java/com/sonusstudios/sonusedit/ui/CreateFlowScreen18.kt')
link=rd('app/src/main/java/com/sonusstudios/sonusedit/create/LinkAudioImporter.kt')
exp=rd('app/src/main/java/com/sonusstudios/sonusedit/media/AutomaticVideoExporter.kt')
whisper=rd('app/src/main/java/com/sonusstudios/sonusedit/create/WhisperCaptionEngine.kt')
service=rd('app/src/main/java/com/sonusstudios/sonusedit/media/ExportForegroundService.kt')
eta=rd('app/src/main/java/com/sonusstudios/sonusedit/create/CaptionEtaEstimator14.kt')
assert (r/'app/src/test/java/com/sonusstudios/sonusedit/create/Code28StabilityTest.kt').exists()
assert 'versionCode = 28' in g and 'versionName = "1.4"' in g
assert 'versionCode=28' in rd('BUILD_VERSION.txt')
assert 'versionName=1.4' in rd('BUILD_VERSION.txt')
assert 'sonusPersistent' in g and 'io.github.junkfood02.youtubedl-android:ffmpeg:0.18.1' in g
assert 'androidx.media3:media3-transformer:1.10.1' in g
assert 'UpdateChannel.STABLE' in link and 'updateYoutubeDL(' in link
assert 'verify' in link and 'copyTo(installed, overwrite = true)' in link
assert 'refreshResolverIfDue(onProgress)' in link and 'FFmpeg.getInstance().init' in link
assert 'startLongExport(draft, onCompleted, onError, RETRY_SEGMENT_MS)' in exp
assert 'ExportRecoveryPolicy14.shouldRetryInChunks' in exp
assert 'setMaxDelayBetweenMuxerSamplesMs(MUXER_WATCHDOG_MS)' in exp
assert 'visualDurationsMs' in exp and 'buildRawParticleSequence(draft)' in exp
assert 'ENGINE_VERSION = 14' in whisper and 'Whisper Small' in whisper
assert 'CaptionLanguageHint.fromTranscription' in whisper and 'lockedLanguage' in whisper
assert 'CaptionEtaEstimator14.expectedTotalMs' in ui and 'CaptionEtaEstimator14.record' in ui
assert '"sonus_caption_eta_code28"' in eta
assert 'SonusEditExport' in service and 'Build.MANUFACTURER' in service
for path in ['app/src/main/res/raw/sonus_particles_green_60fps.mp4','app/src/main/res/raw/sonus_particles_black_30fps.mp4']:
    p=r/path
    assert p.is_file() and p.stat().st_size > 100_000, path
assert 'Text("1.4"' in ui
print('CODE28 static guards passed')
