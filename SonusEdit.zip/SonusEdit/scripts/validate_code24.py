#!/usr/bin/env python3
"""Code24 preflight: test source and compatibility invariants without Android SDK."""
from pathlib import Path
import hashlib

root = Path(__file__).resolve().parent.parent
file = lambda name: (root / name).read_text(encoding='utf-8')
ui = file('app/src/main/java/com/sonusstudios/sonusedit/ui/CreateFlowScreen18.kt')
models = file('app/src/main/java/com/sonusstudios/sonusedit/create/CreateModels.kt')
palette = file('app/src/main/java/com/sonusstudios/sonusedit/create/LyricColorPalette24.kt')
visual = file('app/src/main/java/com/sonusstudios/sonusedit/media/VideoVisualEffects.kt')
gradle = file('app/build.gradle.kts')
assert 'versionCode = 24' in gradle and 'versionName = "1.0"' in gradle
assert 'versionName=1.0' in file('BUILD_VERSION.txt') and 'versionCode=24' in file('BUILD_VERSION.txt')
assert 'Text("1.0"' in ui and 'Text("1.0"' in file('app/src/main/java/com/sonusstudios/sonusedit/ui/HomeScreen.kt')
assert '.size(35.dp)' in ui and 'Arrangement.spacedBy(9.dp)' in ui
assert 'PlatformMark24.TIKTOK' in ui and 'PlatformMark24.YOUTUBE' in ui
assert 'networkSymbols' not in ui
assert 'visibleLyricColors24.forEach' in ui
row = ui[ui.index('private val visibleLyricColors24'):ui.index('private val musicExt18')]
assert row.count('LyricColorPreset.') == 7
assert 'LyricColorPreset.DYNAMIC' in row and 'LyricColorPreset.BLACK' in row
assert 'BLACK("Preto")' in models
assert 'fun dynamicColorCount(): Int = dynamicColors.size' in palette
assert 'Color(LyricColorPalette24.argb(preset, index))' in ui
assert 'LyricColorPalette24.argb(preset, index)' in visual
assert 'Color.WHITE else Color.BLACK' in visual
assert 'BoxWithConstraints(Modifier.fillMaxSize())' in ui
assert 'portraitWidth = previewWidth' in ui
assert 'Modifier.width(portraitWidth).aspectRatio(9f / 16f)' in ui
assert 'ReviewToggleButton20("Ativado", particlesEnabled)' in ui
# Crucial preserved code23 features.
assert 'SmartImageSelector.searchManualGallery(imageCatalog, gallerySearch)' in ui
assert 'galleryShuffleNonce' in ui and 'only the gallery scrolls' in ui
assert 'private fun ReviewPreview23' in ui and 'captions.lastOrNull' in ui
assert 'extractSequentialChunks' in file('app/src/main/java/com/sonusstudios/sonusedit/create/WhisperCaptionEngine.kt')
exporter = file('app/src/main/java/com/sonusstudios/sonusedit/media/AutomaticVideoExporter.kt')
assert 'startLongExport' in exporter and 'concatenateMp4' in exporter
assert 'io.github.junkfood02.youtubedl-android:ffmpeg:0.18.1' in gradle
assert 'androidx.media3:media3-exoplayer:1.10.1' in gradle
assert 'dev.ffmpegkit-maintained:whisper-android:1.0.0' in gradle
assert 'sonusPersistent' in gradle
EXPECTED = {
    'sonus_particles_green_60fps.mp4':'0fe6dfc79f81795b288e333f5839359c7224558ee448b39b9f20476c2dcc86b9',
    'sonus_particles_black_30fps.mp4':'79fd098ff8d51c9b8db622f502792d1bf76cf6a54a7c3bd2afbae591fea525bc',
}
for filename, digest in EXPECTED.items():
    b=(root/'app/src/main/res/raw'/filename).read_bytes()
    assert hashlib.sha256(b).hexdigest()==digest,filename
    print('PASS particle SHA256:',filename)
print('PASS SONUS Edit 1.0/code24 source and compatibility guards')
