#!/usr/bin/env python3
"""Static release checks for Sonus Edit 1.0.6 / CODE 16."""
from pathlib import Path

root = Path(__file__).resolve().parents[1]
def read(path): return (root / path).read_text(encoding="utf-8")
def need(condition, label):
    if not condition:
        raise SystemExit(f"FAIL: {label}")
    print(f"PASS: {label}")

build = read("app/build.gradle.kts")
version = read("BUILD_VERSION.txt")
home = read("app/src/main/java/com/sonusstudios/sonusedit/ui/HomeScreen.kt")
flow = read("app/src/main/java/com/sonusstudios/sonusedit/ui/CreateFlowScreen18.kt")
about = read("app/src/main/java/com/sonusstudios/sonusedit/ui/AboutScreen.kt")
auto = read("app/src/main/java/com/sonusstudios/sonusedit/ui/AutoCaptionsScreen.kt")
editor = read("app/src/main/java/com/sonusstudios/sonusedit/ui/EditorScreen.kt")
exporter = read("app/src/main/java/com/sonusstudios/sonusedit/media/AutomaticVideoExporter.kt")
service = read("app/src/main/java/com/sonusstudios/sonusedit/media/ExportForegroundService.kt")
whisper = read("app/src/main/java/com/sonusstudios/sonusedit/create/WhisperCaptionEngine.kt")

need('applicationId = "com.sonusstudios.sonusedit"' in build, "applicationId preserved")
need('versionCode = 16' in build and 'versionName = "1.0.6"' in build, "Gradle version 1.0.6 / 16")
need('versionName=1.0.6' in version and 'versionCode=16' in version, "BUILD_VERSION version 1.0.6 / 16")
need('Text("1.0.6"' in home and 'Text("1.0.6"' in flow, "home and creation UI show 1.0.6")
need('Versão 1.0.6' in about and '1.0.6 • CODE 16' in about, "About screen release identity")

need('import com.sonusstudios.sonusedit.create.CaptionProgressEstimator13' in auto, "automatic captions uses the shared progress estimator")
need('val captionProgressPercent = CaptionProgressEstimator13.percent(' in auto, "automatic captions computes a visible percentage")
need('processedAudioMs = captionProgress?.processedAudioMs ?: etaProcessedAudioMs' in auto, "processed audio checkpoints feed the percentage")
need('progressPercent = captionProgressPercent' in auto, "percentage is passed into the red status pill")
need('waitingForModel =' in auto and 'completed = captionCompleted' in auto, "model load and completion are handled without false 100 percent")
need('processedAudioProvidesVisiblePercentWhenWhisperCheckpointHasNoPercent' in read("app/src/test/java/com/sonusstudios/sonusedit/create/CaptionProgressEstimator13Test.kt"), "regression test for the automatic captions percentage")

need('if (draft.fitFullFrame)' in exporter and 'return@buildList' in exporter, "caption-only full-frame path bypasses per-clip resizing")
fullframe_branch = exporter.split('if (draft.fitFullFrame)', 1)[1].split('val outputWidth = draft.outputWidth()', 1)[0]
need('LanczosResample.scaleToFit' not in fullframe_branch and 'Presentation.createForAspectRatio' not in fullframe_branch, "no redundant per-clip Presentation/Lanczos in captions-only mode")
need('Presentation.createForWidthAndHeight(draft.outputWidth(), draft.outputHeight()' in exporter, "final composition still applies exact output size")
need('VideoVisualEffects.globalOverlay(context, draft)' in exporter, "caption overlay remains in the composition")
need('fullFrame=${draft?.fitFullFrame}' in service and 'captions=${draft?.captionSegments?.size}' in service, "device error diagnostics include caption export context")

need('Previsão disponível após 5 exportações' not in editor and '(${serviceState.etaSampleCount}/5)' not in editor, "internal ETA sample count is hidden from users")
need('estimatedRemainingMs?.let' in editor, "available ETA remains visible")
need('MODEL_NAME = "ggml-small.bin"' in whisper and 'ENGINE_VERSION = 16' in whisper, "Whisper Small engine preserved")
need('SONUS_KEYSTORE_PATH' in read("app/build.gradle.kts") and 'SONUS_KEYSTORE_PASSWORD' in read("app/build.gradle.kts"), "persistent signing environment contract preserved")
print("Sonus Edit 1.0.6 / CODE 16 static validation passed.")
