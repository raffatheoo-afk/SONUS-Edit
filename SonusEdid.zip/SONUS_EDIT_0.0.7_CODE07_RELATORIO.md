# Sonus Edit 0.0.7 — CODE 07 (correção de teste)

## Falha reportada

`Code30CaptionFontPoolTest > code06SystemAliasesRemainReadableInOldDraftsButAreNotOffered` falhou na linha 38.

## Causa confirmada

O teste esperava 30 IDs temporários do CODE 06. A enumeração `FontPresetId` do CODE 06 e do CODE 07 contém exatamente os mesmos 29 IDs temporários. A comparação dos dois códigos não encontrou IDs ausentes no CODE 07. Portanto, a expectativa `30` no teste estava incorreta.

## Alteração

- Alterada apenas a expectativa do teste de `30` para `29`.
- Nenhum arquivo de fonte, preset aprovado, resolução de fonte, UI ou comportamento de rascunhos foi alterado nesta correção.
- Mantido o catálogo CODE 05: 11 escolhas aprovadas, 10 arquivos TTF/OTF personalizados e Sans-serif.

## Verificações realizadas

- Comparação dos IDs temporários CODE 06 x CODE 07: 29 em cada, conjuntos idênticos.
- Verificação dos 10 arquivos TTF/OTF listados no catálogo: presentes no projeto.
- Conferência da alteração do teste: expectativa ajustada para 29.
- ZIP recriado e teste de integridade ZIP executado.
- YAML do Codemagic preservado.

## Pendente

A suíte JUnit completa e o build Android não foram executados neste ambiente: não há Gradle instalado, Gradle wrapper no pacote ou Android SDK configurado. É necessário rodar novamente no Codemagic e confirmar os 75 testes.
