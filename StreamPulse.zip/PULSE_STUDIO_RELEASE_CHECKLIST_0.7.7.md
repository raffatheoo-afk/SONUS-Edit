# Pulse Studio 0.7.7 — code39

## Reconstrução do contrato do editor
- [x] Project canvas usado no preview e export.
- [x] Fit/Fill persistido no rascunho.
- [x] Trim continua não destrutivo e imagens mantêm duração virtual.
- [x] Exportação reencoda no tamanho selecionado.
- [x] Bitrate varia com resolução/FPS.
- [x] Progresso e cancelamento do Transformer.
- [x] Validação pós-export de resolução, duração e proporção.
- [x] HDR condicionado a suporte de encoder.
- [x] Preto e branco real via RgbFilter.
- [x] Saturação 0–200% na UI, neutro 100%.
- [x] Contraste/brilho/HSL/RGB no render.
- [x] Efeitos live temporais no preview/export.
- [x] Texto renderizado como overlay temporal.
- [x] Legendas/captions renderizadas como overlays temporais.
- [x] Modelos Bars/Wave/Halo/Orbital/Disco/3D usam a análise real também no export.
- [x] Visualizer ligado à trilha de áudio real.
- [x] FFT 2048 + RMS + spectral flux + 64 bandas logarítmicas.
- [x] Visualizer silencioso sem áudio; nada de batida inventada.
- [x] Offset de áudio respeitado por gap no Composition.
- [x] presets_pulsestudio.json embarcado em assets.
- [x] Rascunho persiste canvas e fit mode.

## Validação obrigatória no aparelho
- [ ] GitHub Actions / Build APK verde.
- [ ] Testar 9:16 -> 16:9 e confirmar arquivo final em 16:9.
- [ ] Comparar tamanho 1080p/2K/4K.
- [ ] Confirmar progresso e cancelamento.
- [ ] Confirmar texto, efeito e visualizer no arquivo exportado.
- [ ] Confirmar áudio sem ruído/estática e sincronizado.
