# SONUS 0.8.21 • code66

- [x] `versionName 0.8.21` / `versionCode 66`.
- [x] Splash/abertura protegida contra quadro preto entre inicialização e conteúdo.
- [x] Contraste de ícones/textos revisado, especialmente Distribuição/Pagamentos.
- [x] Sino de notificações visível em dourado e fora do player.
- [x] Central do sino contém somente histórico; configurações ficam em Ajustes.
- [x] Notificações externas usam identidade SONUS.
- [x] Usos globais: FREE 20 / Bronze 70 / Prata 200 / Ouro 500 / Diamante ilimitado.
- [x] FREE Rewarded +1 até 20/20; pré-carregamento, retry e recarga automática.
- [x] Card grande de usos removido de Destaques; marcador compacto no Studio e painel detalhado no Premium.
- [x] Ferramentas úteis de Destaques monetizadas; Karaokê permanece livre.
- [x] Conversões em lote: 1 uso por saída concluída; falhas/cancelamentos sem consumo.
- [x] Spectro PCM Media3 + FFT SONUS + watchdog; Native/PCM Compat mantidos como fallback.
- [x] Diagnóstico do motor do Spectro restrito ao OWNER.
- [x] Player/áudio/crossfade, Vídeo → Áudio, Gravador, Login/Convidado, Premium e Dynamic Island preservados no código.
- [x] README e CHANGELOG atualizados.
- [ ] Compilação Android final: validar no GitHub Actions.
- [ ] Teste em aparelho: validar S10e + S10+ e fluxo Rewarded.
