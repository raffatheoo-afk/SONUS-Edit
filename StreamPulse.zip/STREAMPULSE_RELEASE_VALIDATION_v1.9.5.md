# StreamPulse — Validação de entrega v1.9.5-beta (26)

Data do pacote: 22/08/2026 (fechamento da atualização)

## Base e identidade
- Fonte de verdade usada: `StreamPulse-GitHub-v1.9.4-beta-code25.zip`.
- SHA-256 da base conferido: `ab1879fe90dd90ebf4e4fa6f93c793155c597ffdcd878a25220d65610fabd494`.
- `applicationId`: `com.sonusstudios.streampulse`.
- `versionName`: `1.9.5-beta`.
- `versionCode`: `26`.
- Keystore preservado byte a byte em relação à base v1.9.4.
- SHA-256 do keystore: `8022cbfa0df8120aba76d113054670604854323e0433de9ba29f27da8f1b7aa6`.

## Firebase
- As regras v1.9.4 foram preservadas sem alteração.
- SHA-256: `b8488cbc50743d30a2a760a7f99760e2dabd20786b1e1770ba4c85cc8ef13328`.
- Não é necessária republicação das Firebase Realtime Database Rules para esta atualização.

## Verificações locais concluídas
- XML e JSON do projeto parseados sem erro estrutural.
- Nenhum marcador de conflito de merge encontrado.
- Delimitadores/strings/comentários dos arquivos Kotlin/KTS verificados estruturalmente.
- Identidade, versão, temas, ordem de Ferramentas e presença dos novos motores/funções verificadas por assertivas estáticas.
- 38 temas do Pulse Player confirmados: 8 Free, 5 Plus, 10 Studio, 15 Max.
- 14 temas gerais novos confirmados no modelo.
- Cadeias FFmpeg de PulseOrbit 3D/8D testadas em áudio estéreo local.
- Cadeias FFmpeg de Alterar Tom, Removedor Vocal e Mesclar Áudio (direto/crossfade/intervalo) testadas localmente.
- `git diff --no-index --check` sem erros de whitespace.

## Limite desta validação
Este ambiente não possui Android SDK/Gradle Wrapper configurado para confirmar uma build Android completa. Portanto, este documento **não afirma que o APK compilou**. A confirmação de compilação permanece a cargo do GitHub Actions, conforme a regra do projeto.

## ZIPs
- Estrutura esperada: pasta raiz `StreamPulse/`.
- `StreamPulse-GitHub.zip`: validação final registrada no checklist de release.
- `StreamPulse-GitHub-v1.9.5-beta-code26.zip`: validação final registrada no checklist de release.
- SHA-256 dos ZIPs é informado externamente junto com a entrega, para evitar auto-referência do próprio pacote.
