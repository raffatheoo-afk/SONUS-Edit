# Pulse Studio 0.7.3 — code35

- [x] Rascunhos protegidos contra JSON/URI inválidos e thumbnails pesadas.
- [x] Importação múltipla de fotos/vídeos não substitui mídia existente.
- [x] Fotos grandes usam bitmap reduzido no preview/thumbnail.
- [x] Timeline principal separada de camadas de áudio.
- [x] Áudio: arquivo local e extrair áudio de vídeo.
- [x] Play/Pause avança a timeline com fotos e vídeos.
- [x] Camadas de áudio sincronizadas ao playhead.
- [x] Handles de trim/duração com área de toque maior.
- [x] Fotos podem aumentar/reduzir duração até 60s.
- [x] Layout contextual e mais limpo.
- [x] Falha individual de mídia não deve fechar o editor.
- [ ] Validar build no GitHub Actions.
- [ ] Testar Rascunhos, 4+ fotos, play/pause, trim e áudio em aparelho real.
