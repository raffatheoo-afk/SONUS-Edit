# PULSE STUDIO 0.7.11 — code 43

Pacote autorizado em 26/08/2026.

## Implementado neste pacote
- Inspector inferior padronizado em uma área segura e fixa, elevado acima da barra de navegação do Android.
- Cabeçalho contextual compacto preservado com X, confirmação individual e duplo check quando aplicável.
- Texto: Fonte/Cor/Entrada/Saída/Loop permanecem recolhidos e abrem dentro da mesma área; troca de subpainel ganhou fade suave.
- Sliders do inspector ficaram mais finos e com espaço seguro nas bordas.
- Áudio/Ajustar/Visualizer continuam no modelo horizontal com um parâmetro por vez, sem voltar ao painel vertical longo.
- Snapping leve e funcional para movimentação de áudio e faixas de efeito/filtro/ajuste: início, playhead e final do projeto.
- Exportação: diálogo mostra as dimensões reais calculadas para o canvas antes de renderizar.
- Exportação: novo progresso circular Pulse com gradiente azul/ciano/roxo, percentual real, fase do render e ETA aproximada somente quando há amostra suficiente.
- Ao atingir 100%, o indicador circular transiciona para estado concluído.
- Mantida a correção estrutural 0.7.10 de proporção/canvas em 360p–4K e containers suportados.

## Proteção de estabilidade
Os recursos avançados brainstormados que exigem mudança profunda do renderer (crossfade/transições completas, keyframes de render, chroma key, máscaras, reverse e proxy automático) não foram expostos como botões nesta build. Isso evita violar a regra do projeto de não criar controles sem processamento real. A infraestrutura atual foi mantida preparada para evolução posterior sem quebrar a edição já estabilizada.

## Validação necessária
- GitHub Actions / compileDebugKotlin.
- Testar Texto em aparelhos com barra de navegação por gestos e por 3 botões.
- Testar todos os subpainéis para confirmar ausência de corte inferior.
- Testar exportação curta e longa para validar animação/ETA.
- Testar snapping de áudio e faixas próximo ao playhead/início/fim.
