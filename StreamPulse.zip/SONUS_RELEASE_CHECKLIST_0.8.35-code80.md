# SONUS v0.8.35 — code80

## Melhorias desta versão

- Splash refinada para evitar corte do nome Sonus e aproximar o texto do símbolo.
- Reprodução de músicas da nuvem com fila por pasta e transição preparada para a próxima faixa.
- Ajustes reorganizados e mais compactos.
- Nova Caixa Preta SONUS com gravação contínua local, buffer circular e reprodução retroativa.
- Proteção da Caixa Preta por PIN de 3 ou 4 dígitos.
- MP3 ajustável de 24 a 320 kbps com estimativas de armazenamento.
- Salvamento de trechos com numeração, horário e data brasileira.
- Tela Sobre o SONUS simplificada para mostrar somente novidades da versão atual.

## Versão
- versionName: 0.8.35
- versionCode: 80
- Player de Música: 0.8
- Player de Vídeo: 0.3
