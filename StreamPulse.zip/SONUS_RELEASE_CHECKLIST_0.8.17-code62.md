# SONUS v0.8.17 • code62

- [x] Player reorganizado: capa maior, Spectro próximo aos controles, progresso percentual 0–100%.
- [x] Um único Spectro SONUS reativo ao FFT; removidos modelos antigos.
- [x] 8 paletas: 4 Free e 4 PRO, incluindo Dynamic Color e Dynamic SONUS+ por cores da capa.
- [x] Configurações do Spectro simplificadas para paletas.
- [x] Ajustes: removidos Prévia da aparência, Foto no fundo, Painéis compactos e Privacidade dos anúncios.
- [x] Sobre o SONUS atualizado com changelog da versão.
- [x] PulseTune renomeado para SONUS TUNE e acesso Bronze+ / recompensa no Free.
- [x] Premium atualizado: Bronze R$4,99/R$49,90; Prata R$8,90/R$89,90; Ouro R$14,90/R$149,90; Diamante R$24,90/R$249,90.
- [x] Limites de artistas: Free 1, Bronze 2, Prata 5, Ouro 10, Diamante ilimitado.
- [x] Franquia definida por ferramenta: Bronze 10, Prata 25, Ouro 40, Diamante ilimitado; consumo ligado a conclusão bem-sucedida no Studio.
- [x] Personalizações continuam por selo/plano e não consomem franquia.
- [x] Dynamic Island permanece PRO; temas/fontes/ícones preservam níveis existentes.
- [x] Financeiro/projeções, Resumo Inteligente, Previsões Avançadas e Backup Online mantêm arquitetura Premium para evolução por nível.
- [x] versionName 0.8.17 / versionCode 62.
- [x] applicationId preservado.

## Hotfix code62 — correção pós-teste
- [x] Hub de Ajustes compacto redesenhado em cards menores e ordem aprovada.
- [x] Conta e Desenvolvedor agrupados; Desenvolvedor continua exclusivo do OWNER.
- [x] Premium, Uso do app e Dynamic Island reorganizados no topo.
- [x] Personalização → Monitor de dados → Assinatura tátil SONUS → Código promocional → Análises → Backup e Restauração → Sobre → Segurança.
- [x] Backup Online integrado à área de Backup e Restauração e limitado a Bronze+.
- [x] Bug de Pause/Play ao navegar ou reabrir corrigido com estado de transporte preservado no serviço.
- [x] Player: capa aumentada; Spectro e progresso deslocados para baixo; progresso aproximado dos controles.
- [x] Mesma versão 0.8.17 / code62 mantida por ser hotfix do pacote.

- [x] Limite de artistas efetivamente aplicado ao fluxo de adicionar perfil, sem apagar perfis existentes em downgrade.
- [x] Financeiro e Projeções efetivamente bloqueados no Free e liberados no Bronze+.
- [x] Simulador do OWNER atualizado para 1/2/5/10/∞ artistas e 0/10/25/40/∞ usos por ferramenta, sem carteira Coins visível.
- [x] Controle de ativar/desativar Dynamic Island restaurado dentro do card PRO.
