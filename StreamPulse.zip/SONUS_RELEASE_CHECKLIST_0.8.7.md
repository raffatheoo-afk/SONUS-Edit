# SONUS v0.8.7 (code 52)

- Player: pausa automática quando a rota de áudio fica "noisy" (ex.: Bluetooth A2DP/fone desconectado), evitando salto inesperado para o alto-falante.
- Studio/Áudio: removidos da grade Comparador A/B e Gravador Studio duplicado.
- Imagem e Capa: removidos Removedor de Fundo e Kit Divulgação; Marca d'água ampliada com texto, 6 estilos, assinatura, transparência, tamanhos e PNG transparente.
- Edição e Arquivo: adicionados Divisor de Áudio, Juntar Arquivos, Tags em Lote, Renomeador em Lote e Localizar Duplicados, com tiers definidos.
- Redes Sociais: adicionadas ferramentas explicitamente identificadas por plataforma para engajamento YouTube/TikTok/Instagram, retenção YouTube e crescimento Instagram. Cálculos usam apenas números informados pelo usuário e não inventam benchmarks.
- Mantidos applicationId, Firebase, assinatura e compatibilidade de atualização.

Compilação final deve ser confirmada pelo GitHub Actions.
