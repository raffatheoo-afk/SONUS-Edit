# Pulse Studio 0.7.6 — code38

Pacote de correção profunda do editor de vídeo.

- Timeline central com playhead fixo e trilhas V1/T1/A1 sincronizadas.
- Fotos usam 5 s por padrão e handles maiores/mais diretos para duração/trim.
- Áudio ganhou handles, deslocamento temporal, split, volume e fade in/out.
- Texto agora tem janela temporal própria, aparece no preview e como camada amarela na timeline.
- Undo/Redo no topo do editor.
- Pinch/pan no preview para escala e reposicionamento da mídia.
- Proporção passa a alterar o canvas real do preview, com presets sociais.
- Filtros e ajustes revisados, saturação/nitidez e nomes de filtros alinhados ao comportamento.
- Efeitos animados revisados (chuva, neve, partículas, neon/light leak, glitch, raios etc.).
- Visualizer deixa de inventar movimento sem áudio e usa a análise local sincronizada à camada de áudio.
- Navegação por swipe do Pulse Studio é bloqueada somente durante projeto imersivo; Home do editor mantém navegação normal.
- Voltar do editor salva rascunho e restaura navegação principal.
- Firebase Rules preservadas.

Validação final: GitHub Actions + testes reais em aparelho.
