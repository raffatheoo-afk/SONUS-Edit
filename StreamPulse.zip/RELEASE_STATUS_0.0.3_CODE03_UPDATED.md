# SONUS 0.0.3 / code 03 — pacote-fonte atualizado

## Escopo desta atualização

- Downloads offline no mini-player do Stream e no player principal para a faixa atual.
- Download em lote nas coleções de álbuns e nas playlists selecionadas.
- Progresso de download, confirmação na interface e remoção pelo mesmo botão.
- Biblioteca offline separada dentro do Stream. Sem conectividade validada, o Stream exibe somente as faixas baixadas.
- Arquivos de áudio armazenados em `cacheDir/sonus_stream_downloads`, privado do aplicativo e fora da galeria/gerenciador de arquivos. Limpar cache, limpar dados ou desinstalar remove os downloads.
- Reprodução de faixas já baixadas pelo serviço normal do player, com `file://` e fonte local; sem depender do link online.
- Monitor de Áudio Premium em Aplicativos > MÚSICAS: seleção de entradas/saídas disponíveis, ganho, AEC/NS quando suportados e monitoramento do microfone para fone.
- Saída de caixa de som bloqueada no monitor para reduzir risco de realimentação. A seleção Bluetooth A2DP é conservadora, baseada em nomes identificáveis de fones.
- Filtro da LIVE separado em conteúdo religioso, secular e neutro. Somente a seleção de mídia foi alterada; o fluxo de transmissão permaneceu intacto.
- Compartilhamento de faixas do Stream com endereço HTTPS e página `sonusShare` que apresenta um botão explícito para abrir o deep link do SONUS.
- Categorias existentes, identidade do botão Renomear Áudios, telas restantes e os seis códigos públicos pCloud preservados.

## Limitações que precisam ser consideradas

1. O Android não permite capturar genericamente o áudio reproduzido por qualquer caixa Bluetooth. O monitor trabalha com entradas de áudio realmente expostas pelo aparelho e retorna para fone compatível. Latência zero não é garantida; Bluetooth pode acrescentar atraso. A lista A2DP é filtrada por identificação do nome do dispositivo, portanto um nome Bluetooth não identificável pode ficar indisponível por segurança.
2. A classificação religiosa/secular da LIVE utiliza gênero/tema informado e palavras no nome do arquivo. Mídia sem identificação fica neutra. O conteúdo visual interno de cada imagem/vídeo não foi analisado semanticamente; catálogo com nomes genéricos pode exigir tags/nomes melhores para classificação mais precisa.
3. A função HTTPS `sonusShare` está incluída no código de Firebase Functions, mas não foi publicada nesta atualização. Para publicá-la pelo Codemagic, habilite `SONUS_DEPLOY_SHARE_FUNCTION=true` e configure `FIREBASE_SERVICE_ACCOUNT_JSON_B64` como variável segura com permissão de deploy no projeto `streenpulse`. Sem publicação, o endereço HTTPS não resolverá até o deploy.
4. Os downloads usam o escopo de execução do app; encerrar o processo durante um download pode interrompê-lo. Arquivos incompletos são removidos e podem ser baixados novamente. A função não depende de WorkManager nesta versão.

## Verificações feitas neste ambiente

- YAML parseado e workflow `sonus-0-0-3-code03` encontrado.
- Oito blocos de shell do Codemagic passaram em `bash -n`.
- Validador "Preparar e validar SONUS 0.0.3" executado após descompactar o ZIP: passou.
- JavaScript da função Firebase passou em `node --check`.
- 51 XMLs Android parseados sem erro.
- Os seis códigos públicos pCloud conferidos.
- Arquivos protegidos `AudioToolEngine.kt`, `PulsePlayerService.kt` e `SonusStreamPlatform.kt` conferidos por SHA-256.
- Keystore embutido no YAML conferido por SHA-256 do arquivo; o workflow mantém a checagem da impressão digital do certificado oficial e bloqueia fallback debug.
- ZIP final testado com verificação de integridade.

## O que não foi validado

Este ambiente não possui Gradle instalado, Gradle Wrapper ou Android SDK local. Portanto, não foi executada uma compilação Android nem teste em aparelho. O Codemagic baixa Gradle 8.13, valida o Android SDK 36, executa `:app:assembleDebug` com a chave permanente e confere a assinatura do APK antes de publicar os artefatos. O ZIP é um pacote-fonte atualizado, não um APK já compilado.
