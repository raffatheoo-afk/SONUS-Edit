# SONUS 0.8.0 — code 45

## Nova identidade
- Nome público do aplicativo: SONUS.
- applicationId preservado: `com.sonusstudios.streampulse` para manter compatibilidade de atualização.
- SONUS MUSIC substitui a marca pública Pulse Player.
- Destaques permanece como área de recursos em evidência.
- STUDIO SONUS substitui a antiga aba Ferramentas.
- Distribuição & Pagamentos concentra informações de artistas, distribuidoras, streams, ganhos e pagamentos.
- Ajustes permanece como área de configuração.

## Remoção do editor de vídeo
- Editor de vídeo removido do fluxo principal e do código-fonte.
- Timeline, composição, FX, presets e exportadores específicos do antigo editor removidos.
- Dependências Media3 Transformer/Effect/Common removidas por não serem mais necessárias ao editor.
- O analisador FFT foi preservado e movido para o módulo de áudio porque também atende o SONUS MUSIC e o SONUS VISUALIZER.

## SONUS VISUALIZER — primeira versão
- Reutiliza o catálogo de 34 visualizers do SONUS MUSIC.
- Seleção de música local.
- Análise local FFT da música para resposta real às frequências.
- Imagem de fundo personalizada.
- Capa/foto circular central personalizada.
- Capa central pulsa conforme graves e spectral flux.
- Controle de sensibilidade e intensidade.
- Preview com play/pause e seek.
- Respeita os níveis de acesso dos visualizers por plano.

## Próximas etapas
- Exportação do visualizer para vídeo.
- Proporções 16:9, 9:16 e 1:1.
- Opções de blur/escurecimento do fundo e formatos da capa.
- Nome da música/artista opcional.
