# SONUS — 1.0.2 (code 105)

Release corretiva sobre a base estável 1.0.1/code104. O SONUS Stream mantém a verificação automática de músicas aprovadas a cada 5 minutos, agora com identificação reforçada por Music ID/metadados e confirmação manual opcional por OWNER/SUPPORT. Envios com LRC continuam levando a letra incorporada no MP3 e passam a enviar também o `.lrc` separado. Rejeitadas podem ser ocultadas do histórico do usuário sem apagar o registro administrativo.

> As seções históricas abaixo documentam módulos e decisões de versões anteriores e são mantidas como referência do projeto.

---

SONUS é uma suíte Android para música, criação e acompanhamento de distribuição: player local, interfaces Premium, visualização PCM Media3, ferramentas de áudio/imagem, artistas, distribuidoras, streams, saldo estimado, Pulso ao Vivo, financeiro, projeções, backup e recursos Premium.

## SONUS Stream — code100
A versão 0.9.4/code100 concentra o fluxo do artista no SONUS Stream: Analytics interno, períodos 24h/7d/15d/mês atual/90d, músicas em análise, projeção mensal e envio processado para a caixa pCloud **🔴 SONUS ARTISTAS**. O áudio enviado é normalizado localmente para MP3 160 kbps e recebe capa 1:1 incorporada; LRC/TXT é opcional. A pasta de submissões permanece separada da pasta oficial usada pelo catálogo.


## Identidade técnica
- Nome público: **SONUS**.
- `applicationId`: `com.sonusstudios.streampulse`.
- Raiz técnica dos pacotes: `StreamPulse/`.
- Arquivo principal para GitHub: `StreamPulse-GitHub.zip`.

## Recursos para Artistas — code69
A navegação profissional agora é opcional. Em **Ajustes > Recursos para Artistas**, o usuário ativa separadamente **Distribuição & Pagamentos** e **Painéis das Distribuidoras** e decide se cada recurso também deve ficar fixo na barra principal. Ambos começam desligados por padrão.

Os novos Painéis das Distribuidoras oferecem acesso integrado às 13 distribuidoras já reconhecidas pelo SONUS, com favoritos, última utilizada, modo celular/computador por serviço e troca de perfil/artista. O SONUS não armazena senhas; sessões são mantidas apenas quando o serviço permite e o navegador externo permanece como fallback.

## SONUS MUSIC / interfaces do Player
O player continua gratuito, sem anúncios e com a interface **SONUS Classic** disponível no FREE. A code69 preserva as oito interfaces visuais Premium, sem alterar o motor de transporte, a qualidade do áudio ou o funcionamento dos temas:

- **Bronze** — `Pure`.
- **Prata** — `Flow`.
- **Ouro** — `Orbit`.
- **Diamante** — `Vinyl Glow`, `Arc Light`, `Neon Disc`, `Cassette Retro` e `Turntable Classic`.

As interfaces bloqueadas permanecem visíveis em Ajustes do Player com o selo do plano necessário. O botão especial do **YouTube** continua disponível em todas as interfaces.

## Visualização / PCM Media3
- Todas as interfaces compartilham um único motor visual SONUS alimentado pelo **PCM Media3**; Native e PCM Compat continuam como fallbacks.
- O analisador consome o buffer PCM completo, usa FFT de 512 amostras, normalização adaptativa e entrega dados em alta cadência; a UI interpola no clock da tela para movimento mais macio.
- O espectro usa um `StateFlow` próprio, reduzindo recomposições do restante do Player.
- `Pure` e `Flow` usam barras SONUS fluidas; `Orbit` e `Neon Disc` também adotam barras no lugar das linhas antigas.
- `Vinyl Glow` usa arte central ampliada e barras reposicionadas.
- `Arc Light` tem modo Claro/Escuro rápido e persistente, com contraste de texto/ícones/progresso adequado ao fundo.
- `Cassette Retro` oferece seis skins SONUS, VU estéreo e carretéis mecânicos que variam quantidade de fita e velocidade de rotação conforme o progresso.
- `Turntable Classic` mantém prato/braço e usa VU/LEDs responsivos ao mesmo motor.
- Em Pause, as barras/VU permanecem desenhadas enquanto decaem suavemente a zero; vinil, prato e carretéis param.
- Ajustes compartilhados: intensidade **50–200%**, sensibilidade e suavidade `Rápida / Equilibrada / Suave`.
- Sem `RECORD_AUDIO`; qualidade e caminho audível do player permanecem preservados.

## Ajustes do Player
- Interface do Player, temas, visualização, intensidade, sensibilidade, suavidade, cores, crossfade e velocidade.
- Aleatório e repetição passam a ficar salvos após sair/voltar ao player.
- Biblioteca ganha **Reproduzir** (ordem normal) e **Aleatório** (inicia imediatamente em shuffle).
- Última música e posição são restauradas sem iniciar playback automaticamente se o usuário havia parado/pausado.
- Fila: reorganizar, remover, **Tocar a seguir** e limpar.
- Temporizador: 15/30/60 minutos ou **Fim da música**.
- Opção para manter a tela ligada enquanto o Player estiver aberto.
- Controles Bluetooth/fones continuam atendidos pela MediaSession; Anterior/Próxima usam contraste explícito adequado à interface.

## Destaques / Usos Premium
As ferramentas úteis de Destaques usam o saldo global de Usos Premium; **Karaokê SONUS permanece livre**. Abrir tela/cancelar/erro não desconta. Operações concluídas descontam uso conforme a ação; conversões em lote descontam **1 uso por arquivo/imagem concluído**.

- **FREE** — 20 usos/mês; anúncio recompensado repõe +1 até 20/20.
- **Bronze** — R$ 4,90/mês ou R$ 49,90/ano • 70 usos/mês.
- **Prata** — R$ 8,90/mês ou R$ 89,90/ano • 200 usos/mês.
- **Ouro** — R$ 14,90/mês ou R$ 149,90/ano • 500 usos/mês.
- **Diamante** — R$ 24,90/mês ou R$ 249,90/ano • ilimitado.

## Rewarded Ads
- AdMob/UMP inicializam na abertura; um Rewarded é pré-carregado e mantido pronto em memória.
- Depois de fechar/concluir/falhar, o próximo anúncio é carregado automaticamente.
- Enquanto ainda não estiver pronto, a interface informa **Carregando anúncio…**.
- Builds comuns usam o bloco oficial de teste; anúncios reais exigem `SONUS_REAL_ADS=true`.
- Recompensa FREE só é concedida no callback oficial e nunca ultrapassa 20/20.

## Preservação
Vídeo → Áudio, Gravador, Login/Convidado, Premium, Dynamic Island, dados de artistas, AdMob, PCM Media3, crossfade e qualidade de áudio devem permanecer funcionais. Originais nunca são sobrescritos nas ferramentas de conversão.

## Build
Este pacote passa por verificações estáticas/estruturais e de integridade antes de ser entregue. A compilação Android final continua sendo validada pelo **GitHub Actions** antes de considerar a code69 estável em aparelho.
