# Status de entrega — SONUS 0.0.9 / CODE09 consolidada

**Estado:** projeto e workflow atualizados; validação estática e execução no Android ainda dependem dos testes finais descritos abaixo.

## Escopo incluído
- Cartão Letras no Painel Desenvolvedor OWNER: conteúdo encaixado no espaço do cartão.
- LIVE: cinco transições existentes agora são escolhidas aleatoriamente, sem repetição imediata; legendas centralizadas no retrato e na metade direita em paisagem; cinco estilos de exibição; remoção de tags entre colchetes; ajuste progressivo para caber em até duas linhas.
- LIVE e Sonus Edit Lite: busca de LRC original do Stream, LRC comunitário e LRCLIB, mantendo texto simples como fallback.
- Player: removido o botão Compartilhar música; a ação principal passa a ser Sonus Edit Lite; removido o caminho para abrir o editor externo.
- Sonus Edit Lite: fluxo de criação direto; seleção de fotos e vídeos com selo de tipo; até 50 opções visíveis; busca semântica por gênero/título; filtro de imagens religiosas nas sugestões automáticas; exportação de clipes de vídeo com a trilha de áudio da música.
- Permissões: usuários comuns continuam com 30 dias entre alterações do nome artístico; OWNER pode alterar a qualquer momento.
- Identidade de versão e código preservadas: `0.0.9` / `9`.

## Limitações conhecidas
1. O código do projeto configura três pastas públicas pCloud (não iCloud). Os códigos foram conferidos, mas os links não puderam ser consultados externamente nesta sessão por indisponibilidade de DNS/rede.
2. As opções de fontes aparecem no seletor, mas os arquivos exatos ainda não foram embutidos. O seletor usa famílias do sistema como aproximação. Impact Stone requer licença App/Game para incorporação em aplicativo; Bainsley Bold Italic é listado sob SIL OFL 1.1; “Alione” não foi validado como nome exato de fonte.
3. O texto de erro de carregamento de imagem relatado na abertura da LIVE não aparece nas telas e strings Kotlin inspecionadas. O carregamento já usa fallback sem interromper a LIVE; não foi alterado o pipeline de carregamento.
4. Não foi identificado um gargalo novo e isolado no STREAM. Foram mantidas as otimizações existentes de paginação/cache/on-demand, evitando mudanças especulativas na reprodução.

## Arquivos de entrega
- `StreamPulse.zip` — projeto Android completo CODE09.
- `codemagic.yaml` — workflow alinhado à CODE09 e às verificações novas.
- `CHANGELOG_0.0.9_CODE09.md` — alterações e limitações.
- `SONUS_CHECKLIST_INTERNO_0.0.9_CODE09.md` — checklist de alterações e testes pendentes.
- `RELEASE_STATUS_0.0.9_CODE09.md` — este status.
- `SHA256SONUS_CODE09.txt` — hashes SHA-256.

## Validações executadas
- O YAML foi carregado por parser e validado.
- Todos os oito blocos shell do workflow passaram em `bash -n`.
- O script completo “Preparar e validar SONUS 0.0.9” foi executado contra o ZIP CODE09 e passou, inclusive as verificações de assinatura permanente e Firebase.
- Os seis arquivos Kotlin modificados passaram pela checagem estática de balanceamento de delimitadores.

## Compilação
O ambiente local não contém Android SDK nem Gradle executável, e o ZIP não contém wrapper Gradle. Portanto, não afirmamos que `:app:assembleDebug` foi executado. O Codemagic permanece como ambiente de compilação oficial e exige a variável segura `SONUS_KEYSTORE_PASSWORD` e a chave permanente configurada; não há fallback para debug.
