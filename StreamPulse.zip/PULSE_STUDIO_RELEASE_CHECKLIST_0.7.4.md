# Pulse Studio 0.7.4 — code36

## Objetivo
Refinar o editor de vídeo com foco em fluxo imersivo, seleção de mídia, timeline, texto, efeitos/filtros, proporção, visualizer e estabilidade de rascunhos.

## Implementado neste pacote
- Editor Home mantém navegação principal e swipe do Pulse Studio.
- Ao abrir Novo Projeto, Projeto Musical ou um Rascunho, entra em modo imersivo: barra principal escondida e swipe entre abas desativado.
- Seta voltar / Back do Android salva rascunho e retorna à Home do Editor.
- Seletor de mídia visual abre diretamente o Photo Picker com fotos e vídeos, seleção múltipla, sem popup intermediário.
- Handles de duração/trim maiores e mais sensíveis.
- Duração de foto: slider 1s–10min, presets e valor manual.
- Texto: biblioteca de 75 presets tipográficos usando famílias do Android, distribuída 20 Free / 10 Bronze / 10 Prata / 15 Ouro / 20 Diamante.
- Paleta ampla de cores.
- 20 animações de entrada, 20 de saída e 20+ loops com preview em tempo real.
- Texto, estilo, cor e animações persistem nos rascunhos.
- Legendas manuais no playhead e legenda automática beta via Pulse Transcribe + detecção local de regiões de voz.
- Overlay de imagem/PNG funcional: mover, pinçar para escala/rotação, opacidade e persistência no rascunho.
- Efeitos: 50 opções, 10 por nível Free/Bronze/Prata/Ouro/Diamante, favoritos por long press e preview reativo.
- Filtros: 50 opções, mesma divisão de planos, favoritos e preview.
- Ajustar: sliders independentes para brilho, saturação, contraste, temperatura, highlights, shadows, nitidez, fade, vinheta e grão.
- Canvas renomeado para Proporção, com presets sociais e guia de enquadramento no preview.
- Visualizer: novos modelos (círculo, wave ring, duplo anel, halo, orbital, disco, CD+espectro, vinil, bass circle, neon spikes, minimal).
- Partículas: nenhuma, poeira, glitter, chuva, neve, fumaça, subindo, órbita e explosão.
- Girar, espelhar e escala de clipes agora funcionam no preview e persistem em rascunhos.
- Rascunhos persistem também efeitos, filtros, ajustes, overlay, legendas, visualizer e proporção.

## Mantido / preservado
- Áudio em camada separada da trilha visual.
- Play/pause e playhead unificados.
- Importação múltipla acrescenta mídia sem substituir o projeto.
- Cache de thumbnails e imagens amostradas para reduzir pressão de memória.
- Exportação atual segura preservada; o compositor multiclipe completo continua sendo a próxima etapa da engine.

## Deliberadamente não fingido como concluído
- Chroma key, máscara custom, PIP de vídeo multicamada e stickers completos ainda exigem a engine de composição multicamada.
- Export de todos os efeitos/camadas em projetos multiclipe ainda depende do compositor Media3 avançado.
- Legenda automática usa reconhecimento local disponível no aparelho; precisão/timestamps dependem do motor Android e da detecção de voz.

## Testes prioritários
1. Home Editor → swipe entre abas funciona.
2. Novo Projeto → barra inferior some e swipe entre abas fica bloqueado.
3. Seta voltar → salva rascunho e barra inferior reaparece.
4. + → Photo Picker abre direto e permite seleção múltipla.
5. Foto → handles alteram duração com um único gesto longo.
6. Texto → fonte/cor/entrada/saída/loop respondem no preview.
7. Efeitos/Filtros/Ajustar → preview muda e favoritos persistem.
8. Proporção → guia muda conforme preset.
9. Visualizer → modelos e partículas mudam em tempo real.
10. Rascunho → reabre sem crash e restaura estado.
