# Checklist interno — SONUS 0.0.9 / CODE09

## Identidade e base
- [x] Partir do projeto CODE08 conferido e preservar o ajuste do cartão Letras já introduzido na CODE09 inicial.
- [x] Manter `versionName = "0.0.9"`.
- [x] Manter `versionCode = 9`.
- [x] Preservar `applicationId = "com.sonusstudios.streampulse"`.
- [x] Atualizar as validações e comentários do Codemagic para CODE09.

## Painel OWNER — cartão Letras
- [x] Retirar espaçadores verticais redundantes e distribuir o conteúdo com `Arrangement.SpaceEvenly`.
- [x] Preservar cores, ícone, borda, altura da linha e ação.
- [ ] Confirmar visualmente em aparelho com escala de fonte padrão e ampliada.

## LIVE — transições
- [x] Confirmar que já existiam cinco transições: fade, slide horizontal, zoom/scale + fade, slide vertical e slide horizontal reverso.
- [x] Alterar a escolha sequencial para sorteio entre os cinco efeitos.
- [x] Evitar repetição imediata do efeito anterior.
- [ ] Testar trocas repetidas com sequência de fotos e vídeos no aparelho.

## LIVE — legendas e fontes
- [x] Posicionar a legenda no centro da imagem vertical.
- [x] Posicionar a legenda na metade direita do modo horizontal.
- [x] Não usar superfície/fundo próprio atrás do texto; preservar apenas sombra para leitura.
- [x] Criar cinco estilos: Karaokê (preenchimento progressivo), Palavra por palavra (uma palavra ativa), Clássica, Neon e Minimalista.
- [x] Aplicar famílias do sistema (sans-serif, serif, monospace e cursiva) para diferenciar visualmente os estilos sem incorporar fontes de licença não validada.
- [x] Persistir a escolha do estilo.
- [x] Remover textos/tags entre colchetes antes de exibir a letra.
- [x] Redimensionar progressivamente para evitar overflow e limitar a duas linhas.
- [x] Resolver letra sincronizada na ordem: LRC original do Stream, LRC comunitário, LRCLIB e texto simples como fallback.
- [ ] Testar sincronização e leitura em retrato e paisagem, inclusive com frases longas.
- [ ] Identificar a mensagem de erro visual relatada na abertura, caso ainda apareça no aparelho: nenhum texto de erro de carregamento de imagem foi localizado nas telas/código Kotlin inspecionados; falhas de preparação visual já são absorvidas pelo fallback do palco SONUS.

## STREAM e permissões
- [x] Preservar cache, paginação progressiva e carregamento sob demanda existentes.
- [x] Não alterar `AudioToolEngine.kt` nem `PulsePlayerService.kt`.
- [x] Aplicar exceção OWNER no caminho da operação de renomeação.
- [x] Manter intervalo de 30 dias para usuários comuns.
- [x] Atualizar a interface com a regra de cada tipo de conta.
- [ ] Medir travamentos em aparelho real antes/depois; sem perfil de execução não foi identificado gargalo isolado que justifique alteração no pipeline de áudio.

## Player / Sonus Edit Lite
- [x] Remover botão “Compartilhar música” do player.
- [x] Renomear o botão principal para “SONUS EDIT LITE”.
- [x] Remover opção de abrir o SONUS Edit externo e excluir a ponte interna não utilizada.
- [x] Abrir diretamente o formulário de criação, sem menu intermediário.
- [x] Preservar o compartilhamento do vídeo já exportado como ação posterior à criação.

## Galeria e exportação do Sonus Edit Lite
- [x] Buscar fotos/vídeos nas três pastas públicas configuradas.
- [x] Classificar mídia pelo MIME type e extensão.
- [x] Exibir selo FOTO/VÍDEO.
- [x] Não reproduzir vídeos na galeria.
- [x] Exibir até 50 opções por vez e manter conjunto maior para busca.
- [x] Ranking automático usa gênero, título, artista, álbum e contexto da letra.
- [x] Filtrar conteúdo religioso das sugestões automáticas para faixa sem contexto religioso.
- [x] Permitir pesquisa manual explícita por imagens religiosas.
- [x] Exportar fotos e vídeos; vídeo visual sem áudio próprio; música da faixa como áudio principal.
- [x] Remover downloads temporários em falha de download e após exportação.
- [ ] Testar acesso real às três pastas pCloud no Android conectado à internet.
- [ ] Testar MP4/MOV/WEBM reais e o fluxo completo de exportação no aparelho.

## Legendas do Sonus Edit Lite
- [x] Usar letra sincronizada do Stream/comunidade/LRCLIB para faixas Stream.
- [x] Reduzir tamanho-base em ~10%.
- [x] Aumentar ligeiramente luminosidade das cores.
- [x] Quebrar texto em até duas linhas e usar auto-fit do exportador.
- [x] Mostrar quatro escolhas de fonte no seletor.
- [ ] Incorporar os arquivos tipográficos exatos. Alione não foi identificado com segurança; Impact Stone requer licença App/Game; Bainsley Bold Italic é listado como SIL OFL 1.1, mas o arquivo não pôde ser obtido aqui. Atualmente há fallbacks de famílias do sistema, explicitados na interface.

## Integridade / build
- [x] Hashes de `AudioToolEngine.kt` e `PulsePlayerService.kt` conferidos contra CODE08.
- [x] Atualizar hash validado de `SonusStreamPlatform.kt` no workflow CODE09.
- [x] Validar YAML e scripts shell após a montagem final do ZIP.
- [x] Executar script completo de pré-validação do Codemagic contra o ZIP de validação CODE09 (versão, Firebase, assinatura, arquivos e verificações estáticas aprovadas).
- [ ] Executar `:app:assembleDebug` no Codemagic.
- [ ] Instalar e testar APK no aparelho real.
- [ ] Conferir assinatura permanente do APK gerado.

## Observações de ambiente
- O container desta preparação não possui Android SDK nem Gradle executável, portanto não pode produzir uma compilação Android real.
- A rede externa/DNS não está disponível no container; as pastas pCloud e os arquivos de fontes não puderam ser testados/baixados daqui.
- A confirmação do fluxo de vídeo, transições e renderização de legendas depende de teste funcional no Android.
