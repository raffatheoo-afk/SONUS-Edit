# SONUS v0.8.15 • code60 — pacote aprovado

## Conversor de áudio
- Conversão livre, desvinculada de presets obrigatórios de distribuidora.
- Último preset continua persistido localmente por perfil.
- MP3 → MP3 suportado pelo pipeline FFmpeg, incluindo alteração de bitrate.
- Restaurar padrão volta ao preset livre SONUS.

## Player
- Preservada a sessão persistente e a regra de não iniciar playback ao apenas carregar/reconectar fila.
- Revisada a proteção contra autoplay implícito: fila é carregada com autoPlay=false e a intenção de playback permanece explícita.

## Converter e redimensionar imagens • PRO
- Redimensionador consolidado em uma ferramenta PRO nos Destaques.
- Absorve redimensionamento, conversão, compressão/qualidade e lote.
- Seleção múltipla e processamento em lote.
- Configurações recentes persistidas (dimensão, formato, qualidade e enquadramento).
- Presets e controles reorganizados verticalmente, sem carrossel obrigatório.
- Formatos: JPG/JPEG, PNG, WEBP, BMP, TIFF/TIF e HEIC/HEIF em Android compatível.
- Removidos cards duplicados: Redimensionador antigo, Compressor, Conversor Imagem e Imagens em Lote.

## Limpeza do Studio
- Removido Metrônomo Pro duplicado (PulseTune permanece).
- Removido Crossfade individual duplicado (SONUS AUTOMIX permanece).
- Mantidas as ferramentas individuais sem substituto equivalente.

## Streams / distribuidoras
- Novo seletor: Total do período ou Valor do dia.
- Total do período mantém lógica acumulada/delta.
- Valor do dia grava o valor diário diretamente e permite soma correta no histórico.
- Novo atraso de dados de 0 a 14 dias, escolhido pelo usuário.
- Data do dado é calculada separadamente da data/hora real de registro.
- Modo e atraso ficam lembrados por artista/perfil.

## Histórico e painéis
- Histórico geral de navegação/ferramentas descontinuado; novos eventos de uso deixam de ser persistidos.
- Histórico visual fica focado em streams e ciclos.
- Removido painel/velocímetro de Atividade recente da visão principal.
- Previsões, metas, análises úteis e financeiro permanecem.

## Pulso ao Vivo
- Mantido.
- Saldo estimado incorpora uma parcela intradiária estimada do Pulso, reconciliada quando dados reais alteram o forecast.

## Proteções
- Gravador, Dynamic Island e demais áreas estabilizadas não foram reformuladas.
- applicationId preservado.
