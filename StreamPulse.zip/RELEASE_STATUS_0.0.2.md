# SONUS 0.0.2 / code 02 — estado de entrega

**Pacote:** fonte Android atualizada — candidato, não release compilada.

A base 0.0.1 foi preservada como origem; as alterações foram feitas na cópia de trabalho. O `codemagic.yaml` deste pacote já valida a versão 0.0.2 / code 02 e aceita o ZIP com o nome `SONUS_0.0.2_CODE02_CANDIDATE.zip` na raiz do repositório (ou o nome legado `StreamPulse.zip`).

## É necessário antes de distribuir o APK

1. Colocar este ZIP na raiz do repositório privado do Codemagic com o `codemagic.yaml` ativo.
2. Confirmar que o grupo seguro `sonus_signing` contém `SONUS_KEYSTORE_PASSWORD` correta (e, se aplicável, `SONUS_KEY_PASSWORD`). Sem ela, o workflow agora falha antes de compilar; não há mais APK de teste assinado com chave debug.
3. Executar o workflow `sonus-0-0-2-code02` e revisar `BUILD.log`, impressão digital e SHA-256 do APK. O arquivo JKS recebido é byte a byte igual ao keystore embutido no YAML; o workflow valida o alias e o certificado esperado antes de liberar o APK.
4. Instalar em aparelho e testar: primeira instalação/Stream; reprodução nas três pastas; compartilhamento de faixa; Social Edit/Live; conversor com um vídeo pesado e lote; exportação de PDF; ícones de cada categoria; Pulse com troca automática em 20 s e rotação em 6 h.
5. Concluir a implementação e os testes de downloads offline antes de anunciar a função como entregue.

Não publique o APK nem o repositório como versão estável enquanto o build, a assinatura e os testes em aparelho não forem aprovados. Mantenha o repositório privado porque o YAML contém o keystore codificado em Base64 protegido por senha. O build não gera nem publica APK se não conseguir comprovar a assinatura oficial.

## Correção solicitada após o primeiro APK 0.0.2

- O arquivo `sonus-edit-dev.jks` enviado foi comparado byte a byte com o bloco Base64 do YAML: ambos têm 2.199 bytes e o mesmo SHA-256 de arquivo.
- O Gradle não aceita mais assinatura debug como alternativa.
- O Codemagic exige `SONUS_KEYSTORE_PASSWORD`, restaura o keystore oficial e confirma o SHA-256 do certificado no APK antes de copiar o APK para os Artifacts.
- As 28 artes de ícones tiveram o tamanho do símbolo reduzido para aproximadamente 46% do quadrado, mantendo fundos, cores e efeitos existentes; previews e mipmaps foram sincronizados.
- Não foi produzido APK nesta sessão; o build depende da senha configurada no grupo seguro do Codemagic e da compilação Android remota.
