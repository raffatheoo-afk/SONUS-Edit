# Pulse Studio 0.6.1 — code 31

## Player
- [x] Política única de intenção de reprodução no serviço.
- [x] Voltar para a aba Player com autoplay desligado força estado pausado.
- [x] Entrada do app cancela pedido residual de reprodução antes da splash quando autoplay está desligado.
- [x] Ajuste Reprodução automática disponível no Player, desligado por padrão.
- [x] Autoplay ligado restaura a última faixa lembrada; navegação entre abas não é tratada como comando Play.
- [x] Biblioteca persistente/cache da 0.6.0 preservados e atualização em segundo plano mantida.

## YouTube no Player
- [x] Histórico local persistente com até 200 itens.
- [x] Favoritos locais persistentes.
- [x] Botões de Histórico e Favoritos na tela YouTube.
- [x] Limpar histórico.
- [x] Reproduzir rapidamente itens salvos.

## Entrada / identidade
- [x] Splash visual alvo de 2 segundos.
- [x] Textos brancos de alto contraste.
- [x] Etapas decorativas com ícones Compose em vez de emojis.
- [x] Logo oficial reenquadrado para maior presença visual.
- [x] Variações de launcher reenquadradas de forma consistente.

## Versionamento
- [x] versionName 0.6.1
- [x] versionCode 31
- [x] applicationId preservado
- [x] Firebase Rules preservadas sem alteração

## Validação
- [x] ZIP final mantém raiz StreamPulse/
- [x] Integridade do ZIP deve ser validada com unzip -t antes da entrega
- [ ] Compilação final: GitHub Actions
