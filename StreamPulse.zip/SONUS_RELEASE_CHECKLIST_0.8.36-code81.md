# SONUS v0.8.36 — code81

## Entrega
- versionName: 0.8.36
- versionCode: 81
- Player de Música: 0.9
- Player de Vídeo: 0.4
- Build: Codemagic / assembleDebug
- APK esperado: `SONUS-v0.8.36-code81.apk`

## Mudanças principais
- Estabilidade da abertura do app.
- Remoção da nuvem pessoal dos players.
- Música Online SONUS com catálogo por gêneros e leitura dos metadados dos MP3.
- Streaming sob demanda com leitura parcial e fila corrigida.
- Novo acabamento premium dos Destaques.
- Sobre o SONUS simplificado para exibir somente as novidades atuais.

## Configuração Codemagic
Para habilitar Música Online SONUS na compilação, definir como variáveis seguras:
- `DROPBOX_APP_KEY`
- `DROPBOX_APP_SECRET`

A pasta compartilhada oficial já está configurada no projeto.
