# Relatório de manutenção — SONUS 0.0.4 / CODE 04

## Base e identidade

- Base: pacote-fonte 0.0.3 / CODE 03 recebido da biblioteca.
- `versionName`: `0.0.4`.
- `versionCode`: `4`.
- `applicationId`: preservado (`com.sonusstudios.streampulse`).
- Assinatura Android oficial: configuração e keystore embutida preservadas; sem fallback debug.
- Três códigos públicos pCloud preservados.

## Alterações no código

1. **Categorias do Studio:** grupos reorganizados em IMAGENS, ÁUDIO, VÍDEOS e OUTROS; Caixa Preta SONUS, Editor LRC e PDF ficam em OUTROS. Funções de áudio e vídeo foram movidas conforme o tipo real. Itens existentes relevantes foram mantidos nas categorias.
2. **Monitor de áudio:** tela passou a permitir rolagem vertical; atualização automática da lista de dispositivos ao conectar/desconectar; desconexão do fone selecionado interrompe o monitor por segurança.
3. **Conversão vídeo → áudio:** engine passa a receber estatísticas de progresso do FFmpeg e reportar avanço por arquivo e lote; o progresso inclui preparação e gravação final.
4. **Conversor de vídeo:** tela passou a aceitar rolagem vertical para manter acessíveis as configurações e o botão Converter com equalizador expandido.
5. **Rádio:** estações automáticas exigem mais de 15 faixas do gênero (mínimo 16).
6. **Volume Bluetooth:** o player não aplica mais redução manual de ganho em eventos `AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK`; o evento e a rota de saída são registrados para diagnóstico. A alteração precisa ser validada com a caixa Bluetooth que apresentou o problema.
7. **LIVE horizontal:** a mesma imagem vertical é usada como fundo ampliado e desfocado; a imagem principal permanece centralizada e ajustada sem corte. Vídeos usam modo de ajuste para preservar a composição no modo horizontal.
8. **LIVE sem letra:** painel alternativo mostra título, artista e visual animado em vez de permanecer vazio.
9. **LIVE transições:** cinco estilos de transição foram adicionados.
10. **LIVE chamadas:** ciclo de chamadas de interação passou a manter cada mensagem por 7 segundos e ganhou chamadas de compartilhamento, notificações e seguir o canal.
11. **Divulgação dos apps:** slides alternados SONUS/SONUS EDIT a cada 2 minutos em momentos sem letra ou locuções; o player de rádio também mostra chamada individual durante locuções, com intervalo local de 2 minutos.
12. **Premium:** conversa individual com `@sonuspremiumofc` continua sendo o destino; mensagem inclui plano, valores, versão, ID da conta e código único de solicitação.
13. **Compartilhamento HTTPS:** app usa uma base pública separada do endpoint de API (`SONUS_SHARE_BASE`); Firebase Hosting recebe rewrite `/share` para `sonusShare` e inclui página inicial de fallback. Codemagic tenta publicar função e Hosting com a credencial Firebase segura.
14. **Sobre o SONUS:** resumo de novidades reescrito em linguagem para o usuário, sem detalhes internos.

## Preservado da versão anterior

- Download offline no Stream e controles do player.
- Terceira fonte musical pCloud e identificação separada de MÚSICAS 3.
- Filtro de mídia religiosa/secular existente na LIVE.
- Canal ATUALIZAÇÃO SONUS nas Configurações.
- Planos Premium existentes e seus valores no catálogo atual.
- Identidade do pacote e configuração da assinatura oficial.

## Verificações executadas

- YAML do Codemagic: parse válido.
- `firebase.json`: JSON válido e duas regras de rewrite para `/share`.
- JavaScript da função Firebase: `node --check` passou.
- 51 arquivos XML: parse válido.
- 8 scripts shell do Codemagic: `bash -n` passou.
- Validador estático de preparação do Codemagic 0.0.4: passou, incluindo identidade do app, assinatura configurada, arquivos obrigatórios, três códigos pCloud e regras existentes.
- Hashes dos três arquivos protegidos verificados contra os valores do YAML; hash do `PulsePlayerService.kt` foi atualizado após a alteração de diagnóstico/ducking.
- Checagem sintática exploratória com `kotlinc` em vários arquivos alterados não apontou erros de parser nos arquivos que terminaram a análise; não substitui compilação Gradle.

## Pendências que exigem ambiente externo ou aparelho real

- **Compilação Android:** não executada neste ambiente porque o pacote não inclui Gradle Wrapper e não há instalação local do Gradle. O build final deve ser executado no Codemagic.
- **Compartilhamento:** a página `https://streenpulse.web.app/share` só passa a responder depois do deploy de Hosting e `sonusShare`. Configure `FIREBASE_SERVICE_ACCOUNT_JSON_B64` como variável segura no Codemagic. O deploy não foi executado nesta sessão.
- **Monitor de áudio:** validar microfone e saída com fone com fio, USB e Bluetooth em aparelhos reais. Bluetooth pode acrescentar latência.
- **Volume Bluetooth:** a alteração elimina o ducking manual do SONUS e adiciona diagnóstico, mas não pode interceptar todo comando de volume absoluto enviado diretamente pela caixa/Android. Repetir o teste na caixa problemática e comparar logs.
- **Telegram Premium:** o fluxo é conversa privada com o perfil de atendimento; não foi criado bot Telegram, pois isso exigiria um bot/credencial e backend próprios. O link prepara uma mensagem individual, mas o envio ainda depende do usuário tocar em enviar.
- **TikTok:** efeitos visuais e chamadas melhoram a experiência, mas não contornam nem garantem elegibilidade para recompensas; manter interação real e cumprir as regras da plataforma.

## Resultado

Pacote-fonte e YAML preparados para SONUS 0.0.4 / CODE 04. As verificações estáticas listadas passaram. **Não declarar APK compilado, assinado ou testado em aparelho até o Codemagic concluir o build e os testes reais.**
