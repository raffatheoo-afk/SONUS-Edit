# SONUS v0.8.10 • code55 — auditoria estática final

Base: v0.8.9 code54 testada pelo usuário.

## Confirmado no código
- `applicationId = com.sonusstudios.streampulse`, versionName `0.8.10`, versionCode `55`.
- Crossfade aprovado da code54 preservado; não houve reintrodução do preload/gapless antigo.
- Conversor aceita múltiplos documentos e pasta de entrada, processa lote sequencial e cria as saídas automaticamente em `Music/SONUS/Audio` via MediaStore.
- Conversor força apenas o primeiro stream de áudio (`-map 0:a:0`) e descarta vídeo/capa anexada, subtitles e data (`-vn -sn -dn`), com retry limpo.
- `SonusStorage` centraliza áudio, imagens, gravações, AutoMix, Masters e Visualizer. Ferramentas de mídia migradas para `SonusAutoCreateDocument`/`SonusStorage`; seletores manuais restantes são de ENTRADA ou exportações administrativas (PDF/backup).
- Dynamic Island SONUS possui permissão opt-in, explicação anterior ao Android Settings, serviço overlay, controles de player/gravador, progresso, posição arrastável, escala, transparência e estilos por plano.
- SONUS BOOST™ e SONUS SPATIAL™ não possuem cobrança, anúncio ou gate público.
- Recursos Studio Free não debitam SONUS COINS. Coins ficam para uso avulso de ferramentas/qualidades Premium.
- Studio ordena FREE → Bronze → Prata → Ouro → Diamante; Redes Sociais estão Free.
- SONUS LAB e AutoMix recebem o plano atual e aplicam a divisão Free/Prata/Ouro definida.
- Estatísticas SONUS MUSIC possuem Hoje, 7 dias, Mês, 90 dias, 6 meses, 1 ano, Total e intervalo personalizado; limpeza continua independente.
- Visualizer possui exportação MP4 real, saída automática SONUS, níveis 1080p/2K/4K por plano/Coins, progresso FFmpeg e cancelamento.
- Destaques permanece em grade 2×.
- Catálogo Premium removido de BOOST/SPATIAL e reorganizado por produtividade/Creator/profissional/experiência máxima.

## Verificações estáticas executadas
- Manifest XML parseado com sucesso.
- Delimitadores Kotlin `{}`, `[]` e `()` verificados em todos os fontes.
- Nenhuma referência pública a `Pulse Coin`, `Pulse Coins` ou `Passe Pulse`.
- Nenhum texto público cobrando SONUS BOOST™ ou SONUS SPATIAL™.
- Nenhum `CreateDocument` permanece em ferramentas de mídia; apenas relatório PDF e backup ZIP continuam deliberadamente escolhidos pelo usuário.
- `OpenDocumentTree` restante é usado apenas para selecionar pastas de ENTRADA (biblioteca/player e lote do conversor).

## Limite da validação local
O pacote não contém Gradle Wrapper e o ambiente local não possui Gradle/Android SDK configurado. Portanto esta auditoria não equivale à compilação Android. A compilação final deve ser confirmada pelo GitHub Actions antes de considerar o APK aprovado.
