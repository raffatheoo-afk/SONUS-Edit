# SONUS 0.8.6 • code51

- Corrige proteção da navegação de Pastas no SONUS MUSIC para evitar crash ao montar agrupamentos.
- STUDIO SONUS recebe novas ferramentas de áudio: Normalizador, Fade In/Out, Silêncio Inteligente, Comparador A/B, Detector de Clipping e Criador de Loop.
- Conversor de Áudio, Crossfade e Gravador Studio reutilizam motores já existentes em vez de duplicar recursos.
- Imagem e Capa ganha atalhos e ferramentas para redimensionamento/conversão/recorte/verificação, compressor, paleta, marca d'água, remoção local de fundo, lote e Kit de Divulgação.
- Planos aplicados às novas ferramentas conforme escopo aprovado: Free, Bronze, Prata e Ouro; recursos Diamante continuam concentrados nos recursos premium já existentes/temas.
- Arquivos originais não são sobrescritos.
