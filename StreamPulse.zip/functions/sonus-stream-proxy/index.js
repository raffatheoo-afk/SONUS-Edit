const { onRequest } = require("firebase-functions/v2/https");
const { onSchedule } = require("firebase-functions/v2/scheduler");
const { initializeApp } = require("firebase-admin/app");
const { getAuth } = require("firebase-admin/auth");
const { getDatabase } = require("firebase-admin/database");
const { getStorage } = require("firebase-admin/storage");
const { Readable } = require("node:stream");

initializeApp();

const REGION = "southamerica-east1";
const PCLOUD_CODE = "kZoiqzJZYKnSUcvcE3yhv2kogYMgtzmoSLyX";
const PCLOUD_APIS = ["https://api.pcloud.com", "https://eapi.pcloud.com"];
const MIN_VALID_PLAY_MS = 20_000;
const VIEW_COOLDOWN_MS = 8 * 60_000;
const LISTENING_WINDOW_MS = 24 * 60 * 60_000;
const MAX_QUALIFIED_LISTENING_PER_SONG_WINDOW_MS = 60 * 60_000;
const DAY_MS = 86_400_000;

function json(res, status, body) {
  res.status(status).set("cache-control", "private, no-store, max-age=0").json(body);
}

function childrenOf(snapshot) {
  const out = [];
  if (snapshot && typeof snapshot.forEach === "function") snapshot.forEach((child) => { out.push(child); return false; });
  return out;
}

async function resolvePCloud(fileId) {
  let last;
  for (const base of PCLOUD_APIS) {
    try {
      const u = new URL(base + "/getpublinkdownload");
      u.searchParams.set("code", PCLOUD_CODE);
      u.searchParams.set("fileid", String(fileId));
      const r = await fetch(u, { headers: { accept: "application/json" } });
      const j = await r.json();
      if (j.result !== 0) throw new Error(j.error || `pCloud ${j.result}`);
      const rawHost = Array.isArray(j.hosts) ? j.hosts[0] : null;
      if (!rawHost || !j.path) throw new Error("pCloud não retornou host/path");
      const host = rawHost.startsWith("http") ? rawHost.replace(/\/$/, "") : `https://${rawHost}`;
      return `${host}/${String(j.path).replace(/^\/+/, "")}`;
    } catch (e) { last = e; }
  }
  throw last || new Error("Falha ao resolver pCloud");
}

let catalogCache = { at: 0, files: new Map() };
async function publishedCatalog() {
  if (Date.now() - catalogCache.at < 60_000 && catalogCache.files.size) return catalogCache.files;
  let data;
  let last;
  for (const base of PCLOUD_APIS) {
    try {
      const u = new URL(base + "/showpublink");
      u.searchParams.set("code", PCLOUD_CODE);
      const r = await fetch(u, { headers: { accept: "application/json" } });
      const j = await r.json();
      if (j.result !== 0) throw new Error(j.error || `pCloud ${j.result}`);
      data = j;
      break;
    } catch (e) { last = e; }
  }
  if (!data) throw last || new Error("Catálogo pCloud indisponível");

  const db = getDatabase();
  const [publishedSnap, removedSnap] = await Promise.all([
    db.ref("publicConfig/sonusMusic/publishedGenres").get(),
    db.ref("publicConfig/sonusMusic/removedFileIds").get()
  ]);
  const publishedRaw = publishedSnap.val();
  const published = new Set(Array.isArray(publishedRaw) ? publishedRaw.filter(Boolean) : Object.values(publishedRaw || {}).filter(v => typeof v === "string"));
  const removedRaw = removedSnap.val() || {};
  const removed = new Set(Object.entries(removedRaw).filter(([, enabled]) => enabled === true).map(([id]) => Number(id)).filter(Number.isSafeInteger));
  const files = new Map();
  const root = (data.metadata && Array.isArray(data.metadata.contents)) ? data.metadata.contents : [];
  for (const genre of root) {
    if (!genre || !genre.isfolder || !published.has(String(genre.name || ""))) continue;
    const walk = (nodes) => {
      for (const node of Array.isArray(nodes) ? nodes : []) {
        if (node && node.isfolder) walk(node.contents);
        else if (node && Number(node.fileid) > 0 && !removed.has(Number(node.fileid))) files.set(Number(node.fileid), {
          genre: String(genre.name || ""), name: String(node.name || ""), path: String(node.path || ""),
          title: String(node.title || ""), artist: String(node.artist || ""), size: Number(node.size || 0),
          modified: String(node.modified || node.created || ""), created: String(node.created || "")
        });
      }
    };
    walk(genre.contents);
  }
  catalogCache = { at: Date.now(), files };
  return files;
}


function cleanMusicId(raw) {
  return String(raw || "").trim().toLowerCase().replace(/[^a-z0-9_-]/g, "").slice(0, 120);
}

function normalizeCatalogText(raw) {
  return String(raw || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim().replace(/\s+/g, " ").toLowerCase();
}

function findCatalogFileForSubmission(catalog, submission) {
  // Music ID é sempre a identificação prioritária e mais segura.
  const needle = cleanMusicId(submission && submission.musicId);
  if (needle) {
    for (const [fileId, meta] of catalog.entries()) {
      const name = String(meta && meta.name || "").toLowerCase();
      const path = String(meta && meta.path || "").toLowerCase();
      if (name.includes(needle) || path.includes(needle)) return { fileId: Number(fileId), meta: meta || {}, matchedBy: "MUSIC_ID" };
    }
  }
  // Se a submissão já possui um vínculo explícito de fileId, ele vem antes dos fallbacks por texto.
  const linkedFileId = Number(submission && (submission.publishedFileId || submission.fileId) || 0);
  if (Number.isSafeInteger(linkedFileId) && linkedFileId > 0 && catalog.has(linkedFileId)) {
    return { fileId: linkedFileId, meta: catalog.get(linkedFileId) || {}, matchedBy: "LINKED_FILE_ID" };
  }
  // Compatibilidade com uploads anteriores: o Worker code103 nomeava o arquivo
  // físico pelo submissionId (ex.: -P21...mp3). Music ID continua prioritário.
  const legacySubmissionId = String(submission && submission.id || "").trim().toLowerCase();
  if (legacySubmissionId) {
    for (const [fileId, meta] of catalog.entries()) {
      const name = String(meta && meta.name || "").toLowerCase();
      const path = String(meta && meta.path || "").toLowerCase();
      if (name.includes(legacySubmissionId) || path.includes(legacySubmissionId)) return { fileId: Number(fileId), meta: meta || {}, matchedBy: "SUBMISSION_ID" };
    }
  }
  // Alguns gerenciadores/Telegram podem trocar o filename físico. Nessa situação,
  // pCloud ainda pode expor title/artist ID3; só aceitamos fallback EXATO e único.
  const title = normalizeCatalogText(submission && submission.title);
  const artist = normalizeCatalogText(submission && submission.artistName);
  if (!title || !artist) return null;
  const candidates = [];
  for (const [fileId, meta] of catalog.entries()) {
    if (normalizeCatalogText(meta && meta.title) === title && normalizeCatalogText(meta && meta.artist) === artist) {
      candidates.push({ fileId: Number(fileId), meta: meta || {}, matchedBy: "EXACT_ID3" });
    }
  }
  return candidates.length === 1 ? candidates[0] : null;
}

function id3Synchsafe(bytes, offset) {
  return ((bytes[offset] & 0x7f) << 21) | ((bytes[offset + 1] & 0x7f) << 14) | ((bytes[offset + 2] & 0x7f) << 7) | (bytes[offset + 3] & 0x7f);
}
function decodeId3Text(bytes) {
  if (!bytes || !bytes.length) return "";
  const enc = bytes[0];
  const data = bytes.subarray(1);
  try {
    if (enc === 0 || enc === 3) return Buffer.from(data).toString(enc === 3 ? "utf8" : "latin1").replace(/\0/g, "").trim();
    if (enc === 1) {
      let buf = Buffer.from(data);
      if (buf.length >= 2 && buf[0] === 0xff && buf[1] === 0xfe) return buf.subarray(2).toString("utf16le").replace(/\0/g, "").trim();
      if (buf.length >= 2 && buf[0] === 0xfe && buf[1] === 0xff) { const body = Buffer.from(buf.subarray(2)); if (body.length % 2 === 0) body.swap16(); return body.toString("utf16le").replace(/\0/g, "").trim(); }
      return buf.toString("utf16le").replace(/\0/g, "").trim();
    }
    if (enc === 2) return Buffer.from(data).swap16().toString("utf16le").replace(/\0/g, "").trim();
  } catch (_) {}
  return Buffer.from(data).toString("utf8").replace(/\0/g, "").trim();
}
function parseId3Identity(buffer) {
  const out = { musicId: "", title: "", artist: "" };
  if (!buffer || buffer.length < 10 || buffer.toString("ascii", 0, 3) !== "ID3") {
    const raw = buffer ? buffer.toString("latin1").replace(/\0/g, "") : "";
    const m = raw.match(/sonusmusic[a-z0-9_-]{6,120}/i); if (m) out.musicId = cleanMusicId(m[0]);
    return out;
  }
  const version = buffer[3];
  const tagSize = Math.min(buffer.length, 10 + id3Synchsafe(buffer, 6));
  let pos = 10;
  while (pos + 10 <= tagSize) {
    const id = buffer.toString("ascii", pos, pos + 4);
    if (!/^[A-Z0-9]{4}$/.test(id)) break;
    const size = version === 4 ? id3Synchsafe(buffer, pos + 4) : buffer.readUInt32BE(pos + 4);
    if (!size || size < 0 || pos + 10 + size > tagSize) break;
    const payload = buffer.subarray(pos + 10, pos + 10 + size);
    if (id === "TIT2") out.title = decodeId3Text(payload);
    else if (id === "TPE1") out.artist = decodeId3Text(payload);
    else if (id === "TXXX") {
      const text = decodeId3Text(payload);
      const compact = text.replace(/\0/g, " ");
      const m = compact.match(/sonusmusic[a-z0-9_-]{6,120}/i); if (m) out.musicId = cleanMusicId(m[0]);
    }
    pos += 10 + size;
  }
  if (!out.musicId) {
    const raw = buffer.toString("latin1").replace(/\0/g, "");
    const m = raw.match(/sonusmusic[a-z0-9_-]{6,120}/i); if (m) out.musicId = cleanMusicId(m[0]);
  }
  return out;
}
async function readCatalogIdentity(fileId, meta = {}) {
  const db = getDatabase();
  const fingerprint = `${String(meta.name || "")}|${Number(meta.size || 0)}|${String(meta.modified || "")}`;
  const ref = db.ref(`streamCatalogIdentity/${fileId}`);
  const cached = (await ref.get()).val() || null;
  if (cached && String(cached.fingerprint || "") === fingerprint) return cached;
  let identity = { musicId: "", title: "", artist: "" };
  try {
    const url = await resolvePCloud(Number(fileId));
    let response = await fetch(url, { headers: { Range: "bytes=0-524287", accept: "audio/mpeg,*/*" } });
    if (!response.ok && response.status !== 206) throw new Error(`HTTP ${response.status}`);
    let buf = Buffer.from(await response.arrayBuffer());
    if (buf.length >= 10 && buf.toString("ascii",0,3) === "ID3") {
      const need = 10 + id3Synchsafe(buf, 6);
      if (need > buf.length && need <= 6 * 1024 * 1024) {
        response = await fetch(url, { headers: { Range: `bytes=0-${need - 1}`, accept: "audio/mpeg,*/*" } });
        if (response.ok || response.status === 206) buf = Buffer.from(await response.arrayBuffer());
      }
    }
    identity = parseId3Identity(buf);
  } catch (e) { console.warn("catalog identity", fileId, e.message); }
  const value = { fileId: Number(fileId), fingerprint, musicId: cleanMusicId(identity.musicId), title: String(identity.title || "").slice(0,160), artist: String(identity.artist || "").slice(0,160), scannedAt: Date.now() };
  await ref.set(value).catch(()=>{});
  if (value.musicId) await db.ref(`streamCatalogIdentityByMusicId/${value.musicId}`).set(Number(fileId)).catch(()=>{});
  return value;
}
async function findCatalogFileForSubmissionDeep(catalog, submission) {
  const fast = findCatalogFileForSubmission(catalog, submission);
  if (fast) return fast;
  const musicId = cleanMusicId(submission && submission.musicId);
  const db = getDatabase();
  if (musicId) {
    const indexed = Number((await db.ref(`streamCatalogIdentityByMusicId/${musicId}`).get()).val() || 0);
    if (indexed > 0 && catalog.has(indexed)) return { fileId: indexed, meta: catalog.get(indexed) || {}, matchedBy: "EMBEDDED_MUSIC_ID_CACHE" };
  }
  const targetTitle = normalizeCatalogText(submission && submission.title);
  const targetArtist = normalizeCatalogText(submission && submission.artistName);
  const entries = [...catalog.entries()].sort((a,b) => {
    const ta = Date.parse(String(a[1] && a[1].modified || a[1] && a[1].created || "")) || 0;
    const tb = Date.parse(String(b[1] && b[1].modified || b[1] && b[1].created || "")) || 0;
    return tb - ta;
  });
  // Arquivos recém-publicados são examinados primeiro. O cache torna scans seguintes baratos.
  const candidates = entries.slice(0, Math.min(entries.length, 80));
  const exact = [];
  for (let i = 0; i < candidates.length; i += 5) {
    const batch = candidates.slice(i, i + 5);
    const ids = await Promise.all(batch.map(async ([fileId, meta]) => [fileId, meta, await readCatalogIdentity(fileId, meta)]));
    for (const [fileId, meta, identity] of ids) {
      if (musicId && cleanMusicId(identity.musicId) === musicId) return { fileId: Number(fileId), meta, matchedBy: "EMBEDDED_MUSIC_ID" };
      if (targetTitle && targetArtist && normalizeCatalogText(identity.title) === targetTitle && normalizeCatalogText(identity.artist) === targetArtist) exact.push({ fileId: Number(fileId), meta, matchedBy: "EMBEDDED_EXACT_ID3" });
    }
  }
  return exact.length === 1 ? exact[0] : null;
}


async function notifyArtistFollowers(artistId, title, fileId) {
  if (!artistId) return 0;
  const db = getDatabase();
  const artist = (await db.ref(`streamArtistProfilesById/${artistId}`).get()).val() || null;
  if (!artist) return 0;
  const followers = await db.ref(`streamArtistFollowers/${artistId}`).get();
  const tasks = [];
  followers.forEach(c => {
    const uid = c.key;
    if (uid) tasks.push(pushNotice(uid, `${artist.artistName || "Artista"} lançou música nova`, `${title || "Nova música"} já está disponível no SONUS Stream.`, "ARTIST_RELEASE", "STREAM"));
  });
  await Promise.all(tasks);
  return tasks.length;
}

async function finalizePublishedSubmission(submissionId, rawSubmission, fileId, publishedBy = "BACKEND") {
  const db = getDatabase();
  const submission = rawSubmission || (await db.ref(`streamSubmissions/${submissionId}`).get()).val() || null;
  if (!submission) return { ok: false, reason: "SUBMISSION_NOT_FOUND" };
  if (!Number.isSafeInteger(Number(fileId)) || Number(fileId) <= 0) return { ok: false, reason: "INVALID_FILE" };
  const catalog = await publishedCatalog();
  if (!catalog.has(Number(fileId))) return { ok: false, reason: "NOT_IN_PUBLIC_CATALOG" };
  const status = String(submission.status || "");
  if (!["APPROVED", "PUBLISHED"].includes(status)) return { ok: false, reason: "STATUS_NOT_APPROVED" };
  if (status === "PUBLISHED" && Number(submission.publishedFileId || 0) === Number(fileId)) {
    return {
      ok: true,
      fileId: Number(fileId),
      liveAt: Number(submission.liveAt || submission.publishedAt || Date.now()),
      notified: false,
      alreadyLive: true
    };
  }

  const now = Date.now();
  const artistId = String(submission.artistId || "").trim();
  let artist = artistId ? (await db.ref(`streamArtistProfilesById/${artistId}`).get()).val() || null : null;
  if (!artist && submission.uid) {
    const legacy = (await db.ref(`streamArtistProfiles/${submission.uid}`).get()).val() || null;
    if (legacy) artist = legacy;
  }
  const publishedArtistId = artistId || String(artist && artist.artistId || "");
  const artistName = String(artist && artist.artistName || submission.artistName || "").trim();
  const title = String(submission.title || "Nova música").trim();
  const genre = String(submission.genre || "").trim();
  const updates = {};
  updates[`streamSubmissions/${submissionId}/status`] = "PUBLISHED";
  updates[`streamSubmissions/${submissionId}/publishedFileId`] = Number(fileId);
  updates[`streamSubmissions/${submissionId}/publishedAt`] = Number(submission.publishedAt || now);
  updates[`streamSubmissions/${submissionId}/liveAt`] = Number(submission.liveAt || now);
  const wasManualLive = status === "PUBLISHED" && (submission.manualLive === true || String(submission.publicationMode || "") === "MANUAL");
  if (!wasManualLive) {
    const publicationSource = String(publishedBy || "BACKEND");
    const automaticSource = publicationSource.startsWith("BACKEND");
    updates[`streamSubmissions/${submissionId}/publishedBy`] = publicationSource;
    updates[`streamSubmissions/${submissionId}/publicationMode`] = "AUTO";
    updates[`streamSubmissions/${submissionId}/publicationMethod`] = "AUTO_MATCH";
    updates[`streamSubmissions/${submissionId}/publicationActorUid`] = automaticSource ? "SYSTEM" : publicationSource;
    updates[`streamSubmissions/${submissionId}/publicationRecordedAt`] = now;
    updates[`streamSubmissions/${submissionId}/manualLive`] = false;
  }
  // Se a equipe marcou Ao Vivo antes de o catálogo ser identificado, preserve o auditor manual
  // e registre o match automático em campos separados.
  updates[`streamSubmissions/${submissionId}/catalogMatchedBy`] = String(publishedBy || "BACKEND");
  updates[`streamSubmissions/${submissionId}/catalogMatchedAt`] = now;
  updates[`streamPublishedArtists/${fileId}`] = {
    fileId: Number(fileId), uid: String(submission.uid || ""), artistId: publishedArtistId,
    artistName, title, genre, updatedAt: now
  };
  // O arquivo público continua sendo um único MP3. Estes metadados leves permitem ao
  // app apresentar título/artista/letra imediatamente sem um TXT/LRC solto na nuvem.
  updates[`publicConfig/sonusMusic/trackOverrides/${fileId}/title`] = title;
  updates[`publicConfig/sonusMusic/trackOverrides/${fileId}/artist`] = artistName;
  updates[`publicConfig/sonusMusic/trackOverrides/${fileId}/genre`] = genre;
  const embeddedLyrics = String(submission.lrc || submission.lyrics || "").trim();
  if (embeddedLyrics) {
    updates[`publicConfig/sonusMusic/trackOverrides/${fileId}/lyrics`] = embeddedLyrics.slice(0, 120000);
    updates[`publicConfig/sonusMusic/trackOverrides/${fileId}/lyricsFormat`] = String(submission.lrc || "").trim() ? "LRC" : "TEXT";
  }
  updates[`publicConfig/sonusMusic/removedFileIds/${fileId}`] = null;
  updates[`publicConfig/sonusMusic/catalogRevision`] = { ".sv": { "increment": 1 } };
  await db.ref().update(updates);

  const noticeRef = db.ref(`streamSubmissions/${submissionId}/liveNotifiedAt`);
  const noticeTx = await noticeRef.transaction(v => v ? undefined : now);
  let followersNotified = 0;
  if (noticeTx.committed) {
    await pushNotice(String(submission.uid || ""), "Sua música está ao vivo", `${title} já está disponível no SONUS Stream.`, "SUBMISSION_PUBLISHED", "STREAM_CREATOR");
    followersNotified = await notifyArtistFollowers(publishedArtistId, title, Number(fileId));
  }
  return { ok: true, fileId: Number(fileId), liveAt: Number(submission.liveAt || now), notified: noticeTx.committed, followersNotified };
}

async function setManualPublicationState(submissionId, rawSubmission, live, actorUid, optionalFileId = 0) {
  const db = getDatabase();
  const submission = rawSubmission || (await db.ref(`streamSubmissions/${submissionId}`).get()).val() || null;
  if (!submission) return { ok: false, reason: "SUBMISSION_NOT_FOUND" };
  const now = Date.now();
  const status = String(submission.status || "");
  if (live) {
    if (!["APPROVED", "PUBLISHED"].includes(status)) return { ok: false, reason: "STATUS_NOT_APPROVED" };
    let fileId = Number(optionalFileId || submission.publishedFileId || 0);
    let match = null;
    if (!Number.isSafeInteger(fileId) || fileId <= 0) {
      try {
        catalogCache.at = 0;
        const catalog = await publishedCatalog();
        match = await findCatalogFileForSubmissionDeep(catalog, submission);
        fileId = Number(match && match.fileId || 0);
      } catch (e) { console.warn("manual live catalog match", e.message); }
    }
    if (!Number.isSafeInteger(fileId) || fileId <= 0) {
      return { ok: false, reason: "PUBLIC_FILE_NOT_FOUND" };
    }
    if (status === "PUBLISHED" && Number(submission.publishedFileId || 0) === fileId && Number(submission.liveAt || 0) > 0) {
      return { ok: true, alreadyLive: true, fileId: fileId > 0 ? fileId : null, liveAt: Number(submission.liveAt), notified: false };
    }
    const updates = {};
    updates[`streamSubmissions/${submissionId}/status`] = "PUBLISHED";
    updates[`streamSubmissions/${submissionId}/publishedAt`] = Number(submission.publishedAt || now);
    updates[`streamSubmissions/${submissionId}/liveAt`] = now;
    updates[`streamSubmissions/${submissionId}/publishedBy`] = actorUid;
    updates[`streamSubmissions/${submissionId}/publicationMode`] = "MANUAL";
    updates[`streamSubmissions/${submissionId}/publicationMethod`] = "MANUAL";
    updates[`streamSubmissions/${submissionId}/publicationActorUid`] = actorUid;
    updates[`streamSubmissions/${submissionId}/publicationRecordedAt`] = now;
    updates[`streamSubmissions/${submissionId}/manualLive`] = true;
    if (Number.isSafeInteger(fileId) && fileId > 0) {
      const artistId = String(submission.artistId || "").trim();
      const artist = artistId ? (await db.ref(`streamArtistProfilesById/${artistId}`).get()).val() || null : null;
      const publishedArtistId = artistId || String(artist && artist.artistId || "");
      const artistName = String(artist && artist.artistName || submission.artistName || "").trim();
      const title = String(submission.title || "Nova música").trim();
      const genre = String(submission.genre || "").trim();
      updates[`streamSubmissions/${submissionId}/publishedFileId`] = fileId;
      updates[`streamPublishedArtists/${fileId}`] = { fileId, uid: String(submission.uid || ""), artistId: publishedArtistId, artistName, title, genre, updatedAt: now };
      updates[`publicConfig/sonusMusic/trackOverrides/${fileId}/title`] = title;
      updates[`publicConfig/sonusMusic/trackOverrides/${fileId}/artist`] = artistName;
      updates[`publicConfig/sonusMusic/trackOverrides/${fileId}/genre`] = genre;
      const embeddedLyrics = String(submission.lrc || submission.lyrics || "").trim();
      if (embeddedLyrics) {
        updates[`publicConfig/sonusMusic/trackOverrides/${fileId}/lyrics`] = embeddedLyrics.slice(0,120000);
        updates[`publicConfig/sonusMusic/trackOverrides/${fileId}/lyricsFormat`] = String(submission.lrc || "").trim() ? "LRC" : "TEXT";
      }
      updates[`publicConfig/sonusMusic/catalogRevision`] = { ".sv": { "increment": 1 } };
    }
    await db.ref().update(updates);
    const noticeRef = db.ref(`streamSubmissions/${submissionId}/liveNotifiedAt`);
    const noticeTx = await noticeRef.transaction(v => v ? undefined : now);
    if (noticeTx.committed) await pushNotice(String(submission.uid || ""), "Sua música está ao vivo", `${String(submission.title || "Sua música")} já está disponível no SONUS Stream.`, "SUBMISSION_PUBLISHED", "STREAM_CREATOR");
    return { ok: true, fileId: fileId > 0 ? fileId : null, liveAt: now, notified: noticeTx.committed, matchedBy: match && match.matchedBy || null };
  }

  if (status !== "PUBLISHED") return { ok: true, alreadyWaiting: true };
  const oldFileId = Number(submission.publishedFileId || 0);
  const updates = {};
  updates[`streamSubmissions/${submissionId}/status`] = "APPROVED";
  updates[`streamSubmissions/${submissionId}/publishedAt`] = null;
  updates[`streamSubmissions/${submissionId}/liveAt`] = null;
  updates[`streamSubmissions/${submissionId}/liveNotifiedAt`] = null;
  updates[`streamSubmissions/${submissionId}/publishedBy`] = actorUid;
  updates[`streamSubmissions/${submissionId}/publicationMode`] = "MANUAL_REVERT";
  updates[`streamSubmissions/${submissionId}/publicationMethod`] = "MANUAL_REVERT";
  updates[`streamSubmissions/${submissionId}/publicationActorUid`] = actorUid;
  updates[`streamSubmissions/${submissionId}/publicationRecordedAt`] = now;
  updates[`streamSubmissions/${submissionId}/manualLive`] = false;
  updates[`streamSubmissions/${submissionId}/publishedFileId`] = null;
  if (Number.isSafeInteger(oldFileId) && oldFileId > 0) {
    updates[`streamPublishedArtists/${oldFileId}`] = null;
    updates[`publicConfig/sonusMusic/catalogRevision`] = { ".sv": { "increment": 1 } };
  }
  await db.ref().update(updates);
  return { ok: true, reverted: true };
}

async function authenticate(req) {
  const raw = req.get("authorization") || "";
  if (!raw.startsWith("Bearer ")) throw new Error("AUTH_REQUIRED");
  return getAuth().verifyIdToken(raw.slice(7));
}

async function readRole(uid) {
  const db = getDatabase();
  const [roleSnap, teamSnap] = await Promise.all([
    db.ref(`roles/${uid}`).get(),
    db.ref(`supportTeam/${uid}`).get()
  ]);
  const role = roleSnap.child("active").val() === true ? String(roleSnap.child("role").val() || "USER") : "USER";
  const team = teamSnap.val() || {};
  return { role, team };
}

function hasSupportPermission(authz, permission) {
  return authz.role === "OWNER" || (
    authz.role === "SUPPORT" && authz.team.active === true && authz.team.permissions && authz.team.permissions[permission] === true
  );
}

async function rateLimit(uid) {
  const minute = Math.floor(Date.now() / 60000);
  const ref = getDatabase().ref(`sonusMusicRate/${uid}/${minute}`);
  const result = await ref.transaction(v => (Number(v || 0) >= 120 ? undefined : Number(v || 0) + 1));
  if (!result.committed) throw new Error("RATE_LIMIT");
  ref.set(result.snapshot.val()).catch(() => {});
}

async function pushNotice(uid, title, message, type, route = "") {
  await getDatabase().ref(`streamUserNotifications/${uid}`).push().set({
    title, message, type, route, createdAt: Date.now(), read: false
  });
}


function brDayKey(ts = Date.now()) {
  const parts = new Intl.DateTimeFormat("en-CA", { timeZone: "America/Sao_Paulo", year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(new Date(ts));
  const m = Object.fromEntries(parts.map(p => [p.type, p.value]));
  return `${m.year}-${m.month}-${m.day}`;
}
function brHourKey(ts = Date.now()) {
  return new Intl.DateTimeFormat("pt-BR", { timeZone: "America/Sao_Paulo", hour: "2-digit", hourCycle: "h23" }).format(new Date(ts)).replace(/\D/g, "").slice(0,2) || "00";
}
function cleanSource(raw) {
  const s = String(raw || "SONUS_STREAM").toUpperCase();
  if (s.includes("RÁDIO") || s.includes("RADIO")) return "RADIO";
  if (s.includes("PRA VOC") || s.includes("PARA VOC")) return "FOR_YOU";
  if (s.includes("BUSCA") || s.includes("SEARCH")) return "SEARCH";
  if (s.includes("PLAYLIST")) return "PLAYLIST";
  if (s.includes("GENERO") || s.includes("GÊNERO") || s.includes("GENRE")) return "GENRE";
  if (s.includes("IMPULS") || s.includes("BOOST")) return "BOOST";
  if (s.includes("ARTISTA") || s.includes("ARTIST")) return "ARTIST_PROFILE";
  if (s.includes("DIRET") || s.includes("DIRECT")) return "DIRECT";
  return "SONUS_STREAM";
}
async function commercialTier(uid) {
  const e=(await getDatabase().ref(`premiumEntitlements/${uid}`).get()).val()||{};
  if (e.active===true && Number(e.expiresAt||0)>Date.now()) {
    const t=String(e.tier||"FREE").toUpperCase();
    if (["PRATA","OURO","DIAMANTE"].includes(t)) return t;
  }
  return "FREE";
}
function artistLimit(tier) { return tier==="DIAMANTE" ? 9999 : tier==="OURO" ? 8 : tier==="PRATA" ? 3 : 1; }
async function publishedArtistFor(fileId) {
  const db=getDatabase();
  let map=(await db.ref(`streamPublishedArtists/${fileId}`).get()).val()||null;
  if (map && map.artistId) return map;
  const subs=await db.ref("streamSubmissions").orderByChild("publishedFileId").equalTo(Number(fileId)).limitToFirst(1).get();
  let found=null; subs.forEach(c=>{ if(!found) found={id:c.key,...(c.val()||{})}; });
  if (!found) return null;
  let artistId=String(found.artistId||"");
  if (!artistId) {
    const legacy=(await db.ref(`streamArtistProfiles/${found.uid}`).get()).val()||{};
    artistId=String(legacy.artistId||`ART-${String(found.uid||"").replace(/[^A-Za-z0-9]/g,"").slice(0,18).toUpperCase()}`);
  }
  map={ uid:String(found.uid||""), artistId, artistName:String(found.artistName||""), title:String(found.title||""), genre:String(found.genre||""), fileId:Number(fileId) };
  await db.ref(`streamPublishedArtists/${fileId}`).set(map);
  return map;
}
async function grantPremiumBonus(uid, days) {
  if (!days) return;
  const db=getDatabase(), ref=db.ref(`premiumEntitlements/${uid}`), now=Date.now();
  const cur=(await ref.get()).val()||{}; const base=Math.max(now,Number(cur.expiresAt||0));
  let tier=String(cur.tier||"PRATA").toUpperCase(); if(!["PRATA","OURO","DIAMANTE"].includes(tier)) tier="PRATA";
  await ref.update({tier,active:true,expiresAt:base+days*DAY_MS,bonusDays:Number(cur.bonusDays||0)+days,source:"ARTIST_MILESTONE",updatedAt:now});
}
async function grantUploadBonus(uid, count) {
  if (!count) return;
  const key=brDayKey().slice(0,7); const ref=getDatabase().ref(`streamCreatorBonuses/${uid}/uploads/${key}`);
  await ref.transaction(v=>Number(v||0)+count);
}
async function awardArtistMilestones(artistId, ownerUid) {
  const db=getDatabase(); const summary=(await db.ref(`streamArtistAnalytics/${artistId}/summary`).get()).val()||{};
  const followers=Number(summary.followers||0), hours=Number(summary.listeningMs||0)/3600000;
  const defs=[
    ["followers_50",followers>=50,"50 seguidores","BADGE",0],
    ["followers_100",followers>=100,"100 seguidores","UPLOAD",1],
    ["followers_250",followers>=250,"250 seguidores","PREMIUM",1],
    ["followers_500",followers>=500,"500 seguidores","UPLOAD",2],
    ["followers_1000",followers>=1000,"1.000 seguidores","PREMIUM",2],
    ["hours_500",hours>=500,"500 horas de reprodução","UPLOAD",1],
    ["hours_1000",hours>=1000,"1.000 horas de reprodução","PREMIUM",1],
    ["hours_2500",hours>=2500,"2.500 horas de reprodução","UPLOAD",2],
    ["hours_5000",hours>=5000,"5.000 horas de reprodução","PREMIUM",2]
  ];
  for (const [key,ok,label,type,value] of defs) {
    if(!ok) continue; const ref=db.ref(`streamArtistMilestones/${artistId}/${key}`);
    const tx=await ref.transaction(v=>v?undefined:{artistId,ownerUid,label,rewardType:type,rewardValue:value,achievedAt:Date.now()});
    if(!tx.committed) continue;
    if(type==="UPLOAD") await grantUploadBonus(ownerUid,value);
    if(type==="PREMIUM") await grantPremiumBonus(ownerUid,value);
    const reward=type==="UPLOAD"?`+${value} envio(s) extra(s) neste mês`:type==="PREMIUM"?`${value} dia(s) Premium`:`novo selo de conquista`;
    await pushNotice(ownerUid,"PARABÉNS! Nova meta SONUS",`Você atingiu ${label} e recebeu ${reward}. Continue crescendo!`,"ARTIST_MILESTONE","STREAM_ARTIST");
  }
}
async function recordValidPlay(fileId, uid, source) {
  const db=getDatabase(), map=await publishedArtistFor(fileId); if(!map||!map.artistId) return;
  const artistId=map.artistId, day=brDayKey(), hour=brHourKey(), src=cleanSource(source), now=Date.now();
  const listenerRef=db.ref(`streamArtistAudiencePrivate/${artistId}/${uid}`); const old=(await listenerRef.get()).val()||null;
  const songListenerRef=db.ref(`streamArtistSongAudiencePrivate/${artistId}/${fileId}/${uid}`); const oldSong=(await songListenerRef.get()).val()||null;
  const isNew=!old, isNewForSong=!oldSong;
  const updates={}; const base=`streamArtistAnalytics/${artistId}`;
  updates[`streamArtistAudiencePrivate/${artistId}/${uid}`]={firstSeenAt:Number(old&&old.firstSeenAt||now),lastSeenAt:now,plays:Number(old&&old.plays||0)+1,lastFileId:Number(fileId)};
  updates[`streamArtistSongAudiencePrivate/${artistId}/${fileId}/${uid}`]={firstSeenAt:Number(oldSong&&oldSong.firstSeenAt||now),lastSeenAt:now,plays:Number(oldSong&&oldSong.plays||0)+1};
  updates[`streamArtistDailyListenersPrivate/${artistId}/${day}/${uid}`]=true;
  updates[`streamArtistDailySongListenersPrivate/${artistId}/${day}/${fileId}/${uid}`]=true;
  updates[`${base}/ownerUid`]=map.uid; updates[`${base}/artistId`]=artistId; updates[`${base}/artistName`]=map.artistName||""; updates[`${base}/updatedAt`]=now;
  const inc=(path,n=1)=>updates[path]={".sv":{"increment":n}};
  inc(`${base}/summary/validPlays`); if(isNew) inc(`${base}/summary/uniqueListeners`); else inc(`${base}/summary/returningPlays`);
  inc(`${base}/songs/${fileId}/validPlays`); if(isNewForSong) inc(`${base}/songs/${fileId}/uniqueListeners`); else inc(`${base}/songs/${fileId}/returningPlays`);
  inc(`${base}/daily/${day}/plays`); if(isNew) inc(`${base}/daily/${day}/newListeners`); else inc(`${base}/daily/${day}/returningPlays`);
  inc(`${base}/daily/${day}/songs/${fileId}/validPlays`); if(isNewForSong) inc(`${base}/daily/${day}/songs/${fileId}/newListeners`); else inc(`${base}/daily/${day}/songs/${fileId}/returningPlays`);
  inc(`${base}/hourly/${hour}/plays`); inc(`${base}/sources/${src}/plays`); inc(`${base}/daily/${day}/hourly/${hour}/plays`); inc(`${base}/daily/${day}/sources/${src}/plays`);
  inc(`${base}/songs/${fileId}/sources/${src}/plays`); inc(`${base}/daily/${day}/songs/${fileId}/sources/${src}/plays`);
  if(src==="BOOST"){ inc(`${base}/summary/boostedPlays`); inc(`${base}/daily/${day}/boostedPlays`); inc(`${base}/songs/${fileId}/boostedPlays`); inc(`${base}/daily/${day}/songs/${fileId}/boostedPlays`); } else { inc(`${base}/summary/organicPlays`); inc(`${base}/daily/${day}/organicPlays`); inc(`${base}/songs/${fileId}/organicPlays`); inc(`${base}/daily/${day}/songs/${fileId}/organicPlays`); }
  Object.assign(updates,{[`${base}/songs/${fileId}/title`]:map.title||`Faixa ${fileId}`,[`${base}/songs/${fileId}/genre`]:map.genre||"",[`${base}/songs/${fileId}/fileId`]:Number(fileId),[`${base}/songs/${fileId}/updatedAt`]:now,[`${base}/daily/${day}/songs/${fileId}/title`]:map.title||`Faixa ${fileId}`,[`${base}/daily/${day}/songs/${fileId}/genre`]:map.genre||"",[`${base}/daily/${day}/songs/${fileId}/fileId`]:Number(fileId)});
  await db.ref().update(updates);
}

async function recordUserTimelineValidPlay(uid, fileId, now = Date.now()) {
  if (!uid || !Number.isSafeInteger(Number(fileId)) || Number(fileId) <= 0) return;
  const year = String(new Date(now).getFullYear());
  const ref = getDatabase().ref(`streamUserTimeline/${uid}/${year}/${fileId}`);
  await ref.transaction(current => {
    const value = current || {};
    const playCount = Math.min(5, Number(value.playCount || 0) + 1);
    return {
      ...value,
      playCount,
      lastPlayedAt: now,
      qualifiedAt: playCount >= 5 ? Number(value.qualifiedAt || now) : Number(value.qualifiedAt || 0)
    };
  });
}

exports.stream = onRequest({ region: REGION, timeoutSeconds: 120, memory: "256MiB", cors: false }, async (req, res) => {
  try {
    const user = await authenticate(req);
    await rateLimit(user.uid);
    const fileId = Number(req.query.fileId);
    if (!Number.isSafeInteger(fileId) || fileId <= 0) return res.status(400).send("Faixa inválida");

    const allowed = await publishedCatalog();
    if (!allowed.has(fileId)) return res.status(404).send("Faixa não publicada");

    const snap = await getDatabase().ref(`sonusMusicAdmin/streamOverrides/${fileId}/url`).get();
    const override = typeof snap.val() === "string" ? snap.val().trim() : "";
    const target = override || await resolvePCloud(fileId);
    if (!target.startsWith("https://")) return res.status(502).send("Origem insegura");

    const headers = { "user-agent": "SONUS-Secure-Stream/1", "accept-encoding": "identity" };
    const range = req.get("range");
    if (range) headers.range = range;
    const upstream = await fetch(target, { headers, redirect: "follow" });
    if (!upstream.ok && upstream.status !== 206) return res.status(upstream.status).send("Stream indisponível");

    res.status(upstream.status);
    for (const name of ["content-type", "content-length", "content-range", "accept-ranges", "etag", "last-modified"]) {
      const value = upstream.headers.get(name);
      if (value) res.set(name, value);
    }
    res.set("cache-control", "private, no-store, max-age=0");
    res.set("x-content-type-options", "nosniff");
    if (!upstream.body) return res.end();
    Readable.fromWeb(upstream.body).pipe(res);
  } catch (e) {
    const msg = String(e && e.message || e);
    if (msg === "AUTH_REQUIRED") return res.status(401).send("Autenticação necessária");
    if (msg === "RATE_LIMIT") return res.status(429).send("Limite temporário atingido");
    console.error("SONUS stream proxy", e);
    return res.status(502).send("Não foi possível iniciar o stream");
  }
});

/** Cria a sessão de play no servidor. O relógio válido nasce aqui, não no APK. */
exports.startPlay = onRequest({ region: REGION, timeoutSeconds: 20, memory: "128MiB", cors: false }, async (req, res) => {
  try {
    if (req.method !== "POST") return json(res, 405, { ok: false, error: "METHOD" });
    const user = await authenticate(req);
    const fileId = Number(req.body && req.body.fileId);
    const sessionId = String(req.body && req.body.sessionId || "").replace(/[^A-Za-z0-9_-]/g, "").slice(0, 120);
    if (!Number.isSafeInteger(fileId) || fileId <= 0 || sessionId.length < 10) return json(res, 400, { ok: false, error: "INVALID_SESSION" });
    const allowed = await publishedCatalog();
    if (!allowed.has(fileId)) return json(res, 404, { ok: false, error: "NOT_PUBLISHED" });
    const ref = getDatabase().ref(`streamPlaySessions/${sessionId}`);
    const snap = await ref.get();
    if (!snap.exists()) await ref.set({ uid: user.uid, fileId, startedAt: Date.now(), counted: false });
    return json(res, 200, { ok: true });
  } catch (e) {
    if (String(e.message) === "AUTH_REQUIRED") return json(res, 401, { ok: false, error: "AUTH_REQUIRED" });
    console.error("startPlay", e);
    return json(res, 500, { ok: false, error: "START_FAILED" });
  }
});

/** Valida os 20 segundos no servidor e incrementa o contador uma única vez. */

/** Cria o perfil de artista no backend para não depender de regras remotas desatualizadas no aparelho. */
exports.createArtistProfile = onRequest({ region: REGION, timeoutSeconds: 20, memory: "128MiB", cors: false }, async (req, res) => {
  try {
    if (req.method !== "POST") return json(res, 405, { ok: false, error: "METHOD" });
    const user = await authenticate(req); const db=getDatabase();
    const clean=String(req.body&&req.body.artistName||"").trim().replace(/\s+/g," ").slice(0,120);
    if(clean.length<2) return json(res,400,{ok:false,error:"INVALID_ARTIST"});
    const idxRef=db.ref(`streamArtistsByOwner/${user.uid}`); const idx=await idxRef.get();
    const ids=[]; idx.forEach(c=>ids.push(c.key));
    for(const id of ids){ const v=(await db.ref(`streamArtistProfilesById/${id}`).get()).val()||{}; if(String(v.artistName||"").toLowerCase()===clean.toLowerCase()) return json(res,200,{ok:true,...v}); }
    if(ids.length===0){ const legacy=(await db.ref(`streamArtistProfiles/${user.uid}`).get()).val()||null; if(legacy&&String(legacy.artistName||"").toLowerCase()===clean.toLowerCase()){ const aid=String(legacy.artistId||`ART-${user.uid.replace(/[^A-Za-z0-9]/g,"").slice(0,18).toUpperCase()}`); const v={...legacy,uid:user.uid,artistId:aid,artistName:clean}; await db.ref().update({[`streamArtistProfilesById/${aid}`]:v,[`streamArtistsByOwner/${user.uid}/${aid}`]:true}); return json(res,200,{ok:true,...v}); } }
    const tier=await commercialTier(user.uid), limit=artistLimit(tier); if(ids.length>=limit) return json(res,403,{ok:false,error:"ARTIST_LIMIT",limit,tier});
    const now=Date.now(), artistId=`ART-${db.ref("streamArtistProfilesById").push().key}`;
    const profile={uid:user.uid,artistId,artistName:clean,createdAt:now,updatedAt:now};
    const updates={}; updates[`streamArtistProfilesById/${artistId}`]=profile; updates[`streamArtistsByOwner/${user.uid}/${artistId}`]=true;
    if(ids.length===0) updates[`streamArtistProfiles/${user.uid}`]=profile;
    await db.ref().update(updates); return json(res,200,{ok:true,...profile});
  } catch(e){ if(String(e.message)==="AUTH_REQUIRED") return json(res,401,{ok:false,error:"AUTH_REQUIRED"}); console.error("createArtistProfile",e); return json(res,500,{ok:false,error:"ARTIST_CREATE_FAILED"}); }
});

/** Trial de 7 dias da área Distribuição & Pagamentos. Começa somente na primeira ativação. */
exports.distributionTrial = onRequest({ region: REGION, timeoutSeconds: 20, memory: "128MiB", cors: false }, async (req, res) => {
  try {
    if (req.method !== "POST") return json(res, 405, { ok: false, error: "METHOD" });
    const user = await authenticate(req);
    const db = getDatabase();
    const ref = db.ref(`distributionTrials/${user.uid}`);
    const tx = await ref.transaction(current => {
      if (current && Number(current.expiresAt || 0) > 0) return;
      const now = Date.now();
      return { uid: user.uid, startedAt: now, expiresAt: now + 7 * DAY_MS, source: "FREE_TRIAL" };
    });
    const value = (tx.snapshot && tx.snapshot.val()) || (await ref.get()).val() || {};
    const now = Date.now();
    return json(res, 200, { ok: true, startedAt: Number(value.startedAt || 0), expiresAt: Number(value.expiresAt || 0), active: Number(value.expiresAt || 0) > now });
  } catch (e) {
    if (String(e.message) === "AUTH_REQUIRED") return json(res, 401, { ok: false, error: "AUTH_REQUIRED" });
    console.error("distributionTrial", e);
    return json(res, 500, { ok: false, error: "TRIAL_FAILED" });
  }
});

exports.startPlaySession = onRequest({ region: REGION, timeoutSeconds: 20, memory: "128MiB", cors: false }, async (req, res) => {
  try {
    if (req.method !== "POST") return json(res, 405, { ok: false, error: "METHOD" });
    const user = await authenticate(req);
    const fileId = Number(req.body && req.body.fileId);
    const sessionId = String(req.body && req.body.sessionId || "").replace(/[^A-Za-z0-9_-]/g, "").slice(0, 120);
    const source = cleanSource(String(req.body && req.body.source || "SONUS Stream"));
    if (!Number.isSafeInteger(fileId) || fileId <= 0 || sessionId.length < 10) return json(res, 400, { ok: false, error: "INVALID_SESSION" });
    const ref = getDatabase().ref(`streamPlaySessions/${sessionId}`);
    const now = Date.now();
    const tx = await ref.transaction(current => {
      if (current) {
        if (current.uid !== user.uid || Number(current.fileId) !== fileId) return;
        return current;
      }
      return { uid: user.uid, fileId, source, startedAt: now, counted: false, eligible: false, analyticsFinalized: false };
    });
    if (!tx.committed) return json(res, 409, { ok: false, error: "SESSION_CONFLICT" });
    return json(res, 200, { ok: true, startedAt: Number((tx.snapshot.val() || {}).startedAt || now) });
  } catch (e) {
    if (String(e.message) === "AUTH_REQUIRED") return json(res, 401, { ok: false, error: "AUTH_REQUIRED" });
    console.error("startPlaySession", e);
    return json(res, 500, { ok: false, error: "SESSION_START_FAILED" });
  }
});

exports.claimPlay = onRequest({ region: REGION, timeoutSeconds: 20, memory: "128MiB", cors: false }, async (req, res) => {
  try {
    if (req.method !== "POST") return json(res, 405, { ok: false, error: "METHOD" });
    const user = await authenticate(req);
    const fileId = Number(req.body && req.body.fileId);
    const listenedMs = Math.max(0, Number(req.body && req.body.listenedMs || 0));
    const source = String(req.body && req.body.source || "SONUS Stream");
    const sessionId = String(req.body && req.body.sessionId || "").replace(/[^A-Za-z0-9_-]/g, "").slice(0, 120);
    if (!Number.isSafeInteger(fileId) || fileId <= 0 || listenedMs < MIN_VALID_PLAY_MS || sessionId.length < 10) {
      return json(res, 400, { ok: false, counted: false, error: "INVALID_PLAY" });
    }

    const db = getDatabase();
    const sessionRef = db.ref(`streamPlaySessions/${sessionId}`);
    const before = (await sessionRef.get()).val() || null;
    if (!before || before.uid !== user.uid || Number(before.fileId) !== fileId) {
      return json(res, 409, { ok: false, counted: false, error: "SESSION_NOT_STARTED" });
    }
    if (before.counted === true) {
      return json(res, 200, { ok: true, counted: true, eligible: before.eligible === true, playCount: Number(before.playCount || 0) });
    }
    if (Date.now() - Number(before.startedAt || Date.now()) < MIN_VALID_PLAY_MS - 1000) {
      return json(res, 200, { ok: true, counted: false, eligible: false });
    }

    const now = Date.now();
    const userStatsRef = db.ref(`streamUserSongStats/${user.uid}/${fileId}`);
    const lastViewRef = userStatsRef.child("lastViewAt");
    const lastViewTx = await lastViewRef.transaction(value => {
      const last = Number(value || 0);
      if (last > 0 && now - last < VIEW_COOLDOWN_MS) return;
      return now;
    });
    const eligible = lastViewTx.committed;

    const firstQualifiedRef = userStatsRef.child("firstQualifiedAt");
    const firstTx = await firstQualifiedRef.transaction(value => Number(value || 0) > 0 ? undefined : now);
    const firstQualified = firstTx.committed;

    const privateUpdates = {
      lastQualifiedAt: now,
      lastSessionId: sessionId,
      lastSource: cleanSource(source),
      updatedAt: now
    };
    await userStatsRef.update(privateUpdates);
    if (eligible) await userStatsRef.child("playCount").transaction(v => Number(v || 0) + 1);

    const sessionTx = await sessionRef.transaction(current => {
      if (!current || current.uid !== user.uid || Number(current.fileId) !== fileId || current.counted === true) return;
      return { ...current, counted: true, eligible, claimedAt: now, listenedMs: Math.floor(listenedMs), source: cleanSource(source) };
    });
    if (!sessionTx.committed) {
      const latest = (await sessionRef.get()).val() || {};
      return json(res, 200, { ok: true, counted: latest.counted === true, eligible: latest.eligible === true, playCount: Number(latest.playCount || 0) });
    }

    if (eligible) await recordUserTimelineValidPlay(user.uid, fileId, now).catch(() => {});

    const map = await publishedArtistFor(fileId);
    const ownArtist = !!(map && String(map.uid || "") === user.uid);
    let playCount = Number((await db.ref(`streamStats/${fileId}/playCount`).get()).val() || 0);
    if (eligible && !ownArtist) {
      const countTx = await db.ref(`streamStats/${fileId}/playCount`).transaction(v => Number(v || 0) + 1);
      playCount = Number(countTx.snapshot.val() || 0);
      const globalUpdates = { [`streamStats/${fileId}/updatedAt`]: now };
      if (firstQualified) globalUpdates[`streamStats/${fileId}/uniqueListeners`] = { ".sv": { "increment": 1 } };
      await db.ref().update(globalUpdates);
      await recordValidPlay(fileId, user.uid, source);
    }
    await sessionRef.update({ playCount });
    return json(res, 200, { ok: true, counted: true, eligible, ownArtist, playCount });
  } catch (e) {
    if (String(e.message) === "AUTH_REQUIRED") return json(res, 401, { ok: false, error: "AUTH_REQUIRED" });
    console.error("claimPlay", e);
    return json(res, 500, { ok: false, error: "CLAIM_FAILED" });
  }
});

exports.finishPlay = onRequest({ region: REGION, timeoutSeconds: 20, memory: "128MiB", cors: false }, async (req,res)=>{
  try {
    if(req.method!=="POST") return json(res,405,{ok:false,error:"METHOD"});
    const user=await authenticate(req), db=getDatabase();
    const fileId=Number(req.body&&req.body.fileId), listenedMs=Math.max(0,Number(req.body&&req.body.listenedMs||0)), durationMs=Math.max(0,Number(req.body&&req.body.durationMs||0));
    const completed=req.body&&req.body.completed===true, skipped=req.body&&req.body.skipped===true;
    const sessionId=String(req.body&&req.body.sessionId||"").replace(/[^A-Za-z0-9_-]/g,"").slice(0,120);
    if(!Number.isSafeInteger(fileId)||fileId<=0||sessionId.length<10) return json(res,400,{ok:false,error:"INVALID"});

    const sref=db.ref(`streamPlaySessions/${sessionId}`);
    const existing=(await sref.get()).val()||null;
    if(!existing||existing.uid!==user.uid||Number(existing.fileId)!==fileId) return json(res,409,{ok:false,error:"SESSION_NOT_STARTED"});
    if(existing.analyticsFinalized===true) return json(res,200,{ok:true,recorded:true,alreadyFinalized:true});
    if(existing.counted!==true) return json(res,200,{ok:true,recorded:false,reason:"NOT_QUALIFIED"});

    const tx=await sref.transaction(cur=>{
      if(!cur||cur.uid!==user.uid||Number(cur.fileId)!==fileId||cur.counted!==true||cur.analyticsFinalized===true)return;
      return {...cur,analyticsFinalized:true,finishedAt:Date.now(),finalListenedMs:Math.floor(listenedMs),durationMs:Math.floor(durationMs),completed,skipped};
    });
    if(!tx.committed) return json(res,200,{ok:true,recorded:false});

    const now=Date.now();
    const userRef=db.ref(`streamUserSongStats/${user.uid}/${fileId}`);
    const userSnap=(await userRef.get()).val()||{};
    let windowStart=Number(userSnap.qualifiedWindowStartedAt||0), windowMs=Number(userSnap.qualifiedWindowMs||0);
    if(windowStart<=0||now-windowStart>=LISTENING_WINDOW_MS){windowStart=now;windowMs=0;}
    const sessionCap=durationMs>0?Math.min(Math.min(durationMs,10*60_000)*3,30*60_000):10*60_000;
    const requestedQualified=Math.max(0,Math.min(Math.floor(listenedMs),sessionCap));
    const remaining=Math.max(0,MAX_QUALIFIED_LISTENING_PER_SONG_WINDOW_MS-windowMs);
    const applied=Math.min(requestedQualified,remaining);
    const completionUnits=durationMs>0?Math.max(0,Math.min(3,Math.floor(applied/durationMs))):0;
    const completions=Math.max(completed?1:0,completionUnits);
    const replays=Math.max(0,completions-1);
    const isSkip=skipped&&!completed;
    const earlySkip=isSkip&&durationMs>0&&applied<Math.min(30_000,Math.max(5_000,durationMs*.20));

    const personalUpdates={
      qualifiedWindowStartedAt:windowStart,
      qualifiedWindowMs:windowMs+applied,
      lastFinishedSessionId:sessionId,
      updatedAt:now
    };
    await userRef.update(personalUpdates);
    if(applied>0) await userRef.child("totalListeningMs").transaction(v=>Number(v||0)+applied);
    if(completions>0) await userRef.child("completions").transaction(v=>Number(v||0)+completions);
    if(replays>0) await userRef.child("replayCount").transaction(v=>Number(v||0)+replays);
    if(isSkip) await userRef.child("skips").transaction(v=>Number(v||0)+1);
    if(earlySkip) await userRef.child("earlySkips").transaction(v=>Number(v||0)+1);

    const map=await publishedArtistFor(fileId);
    const ownArtist=!!(map&&String(map.uid||"")===user.uid);
    if(!ownArtist){
      const retentionBp=durationMs>0?Math.max(0,Math.min(10_000,Math.floor((Math.min(applied,durationMs)*10_000)/durationMs))):0;
      const publicUpdates={};
      const inc=(path,n)=>publicUpdates[path]={".sv":{"increment":n}};
      if(applied>0) inc(`streamStats/${fileId}/listeningMs`,applied);
      inc(`streamStats/${fileId}/retentionBpTotal`,retentionBp); inc(`streamStats/${fileId}/retentionSamples`,1);
      if(completions>0) inc(`streamStats/${fileId}/completions`,completions);
      if(replays>0) inc(`streamStats/${fileId}/replayCount`,replays);
      if(isSkip) inc(`streamStats/${fileId}/skips`,1);
      if(earlySkip) inc(`streamStats/${fileId}/earlySkips`,1);
      publicUpdates[`streamStats/${fileId}/updatedAt`]=now;
      await db.ref().update(publicUpdates);

      if(map&&map.artistId){
        const base=`streamArtistAnalytics/${map.artistId}`, day=brDayKey(), hour=brHourKey(), retention=durationMs>0?Math.min(1,applied/durationMs):0, updates={}, add=(p,n)=>updates[p]={".sv":{"increment":n}};
        add(`${base}/summary/listeningMs`,Math.floor(applied)); add(`${base}/songs/${fileId}/listeningMs`,Math.floor(applied)); add(`${base}/daily/${day}/listeningMs`,Math.floor(applied)); add(`${base}/daily/${day}/songs/${fileId}/listeningMs`,Math.floor(applied)); add(`${base}/hourly/${hour}/listeningMs`,Math.floor(applied)); add(`${base}/daily/${day}/hourly/${hour}/listeningMs`,Math.floor(applied));
        add(`${base}/songs/${fileId}/retentionSum`,retention); add(`${base}/songs/${fileId}/retentionSamples`,1); add(`${base}/daily/${day}/songs/${fileId}/retentionSum`,retention); add(`${base}/daily/${day}/songs/${fileId}/retentionSamples`,1);
        if(completions){add(`${base}/summary/completions`,completions);add(`${base}/songs/${fileId}/completions`,completions);add(`${base}/daily/${day}/completions`,completions);add(`${base}/daily/${day}/songs/${fileId}/completions`,completions);}
        if(isSkip){add(`${base}/summary/skips`,1);add(`${base}/songs/${fileId}/skips`,1);add(`${base}/daily/${day}/skips`,1);add(`${base}/daily/${day}/songs/${fileId}/skips`,1);}
        if(earlySkip){add(`${base}/summary/earlySkips`,1);add(`${base}/songs/${fileId}/earlySkips`,1);add(`${base}/daily/${day}/earlySkips`,1);add(`${base}/daily/${day}/songs/${fileId}/earlySkips`,1);}
        updates[`${base}/updatedAt`]=now;
        await db.ref().update(updates);
        await awardArtistMilestones(map.artistId,map.uid);
      }
    }
    return json(res,200,{ok:true,recorded:true,appliedListeningMs:applied,ownArtist});
  }catch(e){
    if(String(e.message)==="AUTH_REQUIRED") return json(res,401,{ok:false,error:"AUTH_REQUIRED"});
    console.error("finishPlay",e);
    return json(res,500,{ok:false,error:"FINISH_FAILED"});
  }
});

exports.followArtist = onRequest({ region: REGION, timeoutSeconds: 20, memory: "128MiB", cors: false }, async (req,res)=>{
  try{
    if(req.method!=="POST") return json(res,405,{ok:false,error:"METHOD"}); const user=await authenticate(req), db=getDatabase(); const artistId=String(req.body&&req.body.artistId||"").replace(/[^A-Za-z0-9_-]/g,"").slice(0,120), following=req.body&&req.body.following!==false;
    const artist=(await db.ref(`streamArtistProfilesById/${artistId}`).get()).val()||null; if(!artist) return json(res,404,{ok:false,error:"ARTIST_NOT_FOUND"}); if(String(artist.uid||"")===user.uid) return json(res,400,{ok:false,error:"OWN_ARTIST"});
    const ref=db.ref(`streamArtistFollowers/${artistId}/${user.uid}`), existed=(await ref.get()).exists(), historyRef=db.ref(`streamArtistFollowerHistory/${artistId}/${user.uid}`), everFollowed=(await historyRef.get()).exists(), day=brDayKey();
    if(following&&!existed){
      await db.ref().update({[`streamArtistFollowers/${artistId}/${user.uid}`]:{followedAt:Date.now()},[`streamFollowingByUser/${user.uid}/${artistId}`]:true,[`streamArtistFollowerHistory/${artistId}/${user.uid}`]:true});
      await db.ref(`streamArtistAnalytics/${artistId}/summary/followers`).transaction(v=>Number(v||0)+1);
      if(!everFollowed){
        await db.ref(`streamArtistAnalytics/${artistId}/daily/${day}/newFollowers`).transaction(v=>Number(v||0)+1);
        const audience=(await db.ref(`streamArtistAudiencePrivate/${artistId}/${user.uid}`).get()).val()||{}; const lastFileId=Number(audience.lastFileId||0);
        if(lastFileId>0){ await db.ref(`streamArtistAnalytics/${artistId}/songs/${lastFileId}/followersGenerated`).transaction(v=>Number(v||0)+1); await db.ref(`streamArtistAnalytics/${artistId}/daily/${day}/songs/${lastFileId}/followersGenerated`).transaction(v=>Number(v||0)+1); }
      }
      const count=Number((await db.ref(`streamArtistAnalytics/${artistId}/summary/followers`).get()).val()||0); await db.ref(`streamArtistPublicStats/${artistId}`).update({followers:count,updatedAt:Date.now()});
      const dayCountRef=db.ref(`streamArtistFollowerNoticeDaily/${artistId}/${day}`);
      const dayTx=await dayCountRef.transaction(v=>Number(v||0)+1); const todayNew=Number(dayTx.snapshot.val()||1);
      if(todayNew===1||todayNew===5||todayNew%10===0) await pushNotice(String(artist.uid),"Novos seguidores",todayNew===1?"Seu artista ganhou um novo seguidor hoje.":`Você ganhou ${todayNew} novos seguidores hoje.`,"ARTIST_FOLLOWER","STREAM_ARTIST");
      await awardArtistMilestones(artistId,String(artist.uid));
    }
    if(!following&&existed){ await db.ref().update({[`streamArtistFollowers/${artistId}/${user.uid}`]:null,[`streamFollowingByUser/${user.uid}/${artistId}`]:null}); await db.ref(`streamArtistAnalytics/${artistId}/summary/followers`).transaction(v=>Math.max(0,Number(v||0)-1)); }
    const count=Number((await db.ref(`streamArtistAnalytics/${artistId}/summary/followers`).get()).val()||0); await db.ref(`streamArtistPublicStats/${artistId}`).update({followers:count,updatedAt:Date.now()}); return json(res,200,{ok:true,following,count});
  }catch(e){ if(String(e.message)==="AUTH_REQUIRED") return json(res,401,{ok:false,error:"AUTH_REQUIRED"}); console.error("followArtist",e); return json(res,500,{ok:false,error:"FOLLOW_FAILED"}); }
});

exports.setSongLike = onRequest({ region: REGION, timeoutSeconds: 20, memory: "128MiB", cors: false }, async (req,res)=>{
  try{
    if(req.method!=="POST") return json(res,405,{ok:false,error:"METHOD"}); const user=await authenticate(req), db=getDatabase(); const fileId=Number(req.body&&req.body.fileId), liked=req.body&&req.body.liked!==false;
    if(!Number.isSafeInteger(fileId)||fileId<=0) return json(res,400,{ok:false,error:"INVALID_FILE"}); const map=await publishedArtistFor(fileId); if(!map||!map.artistId) return json(res,404,{ok:false,error:"NOT_PUBLISHED"});
    const ref=db.ref(`streamSongLikes/${fileId}/${user.uid}`), existed=(await ref.get()).exists(), day=brDayKey();
    if(liked&&!existed){ await db.ref().update({[`streamSongLikes/${fileId}/${user.uid}`]:{likedAt:Date.now()},[`streamLikedByUser/${user.uid}/${fileId}`]:true}); await db.ref(`streamArtistAnalytics/${map.artistId}/summary/likes`).transaction(v=>Number(v||0)+1); await db.ref(`streamArtistAnalytics/${map.artistId}/songs/${fileId}/likes`).transaction(v=>Number(v||0)+1); await db.ref(`streamArtistAnalytics/${map.artistId}/daily/${day}/likes`).transaction(v=>Number(v||0)+1); await db.ref(`streamArtistAnalytics/${map.artistId}/daily/${day}/songs/${fileId}/likes`).transaction(v=>Number(v||0)+1); }
    if(!liked&&existed){ await db.ref().update({[`streamSongLikes/${fileId}/${user.uid}`]:null,[`streamLikedByUser/${user.uid}/${fileId}`]:null}); await db.ref(`streamArtistAnalytics/${map.artistId}/summary/likes`).transaction(v=>Math.max(0,Number(v||0)-1)); await db.ref(`streamArtistAnalytics/${map.artistId}/songs/${fileId}/likes`).transaction(v=>Math.max(0,Number(v||0)-1)); }
    const count=Number((await db.ref(`streamArtistAnalytics/${map.artistId}/songs/${fileId}/likes`).get()).val()||0); await db.ref(`streamSongPublicStats/${fileId}`).update({likes:count,updatedAt:Date.now()}); return json(res,200,{ok:true,liked,count});
  }catch(e){ if(String(e.message)==="AUTH_REQUIRED") return json(res,401,{ok:false,error:"AUTH_REQUIRED"}); console.error("setSongLike",e); return json(res,500,{ok:false,error:"LIKE_FAILED"}); }
});


exports.notifyArtistRelease = onRequest({ region: REGION, timeoutSeconds: 30, memory: "128MiB", cors: false }, async (req,res)=>{
  try{
    if(req.method!=="POST") return json(res,405,{ok:false,error:"METHOD"});
    const actor=await authenticate(req), authz=await readRole(actor.uid);
    if(!hasSupportPermission(authz,"streamModeration")&&!hasSupportPermission(authz,"adminActions")) return json(res,403,{ok:false,error:"FORBIDDEN"});
    const artistId=String(req.body&&req.body.artistId||"").replace(/[^A-Za-z0-9_-]/g,"").slice(0,120), title=String(req.body&&req.body.title||"Nova música").trim().slice(0,120), fileId=Number(req.body&&req.body.fileId||0);
    if(!artistId) return json(res,400,{ok:false,error:"ARTIST_REQUIRED"});
    const notified=await notifyArtistFollowers(artistId,title,fileId);
    return json(res,200,{ok:true,notified,fileId});
  }catch(e){ if(String(e.message)==="AUTH_REQUIRED") return json(res,401,{ok:false,error:"AUTH_REQUIRED"}); console.error("notifyArtistRelease",e); return json(res,500,{ok:false,error:"NOTIFY_RELEASE_FAILED"}); }
});

exports.confirmCatalogPublication = onRequest({ region: REGION, timeoutSeconds: 45, memory: "256MiB", cors: false }, async (req,res)=>{
  try{
    if(req.method!=="POST") return json(res,405,{ok:false,error:"METHOD"});
    const actor=await authenticate(req), authz=await readRole(actor.uid);
    if(authz.role!=="OWNER") return json(res,403,{ok:false,error:"FORBIDDEN"});
    const submissionId=String(req.body&&req.body.submissionId||"").replace(/[^A-Za-z0-9_-]/g,"").slice(0,160);
    const fileId=Number(req.body&&req.body.fileId||0);
    if(!submissionId||!Number.isSafeInteger(fileId)||fileId<=0) return json(res,400,{ok:false,error:"INVALID_REQUEST"});
    const snap=await getDatabase().ref(`streamSubmissions/${submissionId}`).get();
    const submission=snap.val()||null;
    if(!submission) return json(res,404,{ok:false,error:"SUBMISSION_NOT_FOUND"});
    const result=await finalizePublishedSubmission(submissionId,submission,fileId,actor.uid);
    if(!result.ok && result.reason==="NOT_IN_PUBLIC_CATALOG") return json(res,409,{ok:false,error:"NOT_IN_PUBLIC_CATALOG"});
    if(!result.ok) return json(res,400,{ok:false,error:result.reason||"PUBLICATION_FAILED"});
    return json(res,200,result);
  }catch(e){ if(String(e.message)==="AUTH_REQUIRED") return json(res,401,{ok:false,error:"AUTH_REQUIRED"}); console.error("confirmCatalogPublication",e); return json(res,500,{ok:false,error:"PUBLICATION_CONFIRM_FAILED"}); }
});


exports.scanApprovedPublicationNow = onRequest({ region: REGION, timeoutSeconds: 90, memory: "256MiB", cors: false }, async (req,res)=>{
  try{
    if(req.method!=="POST") return json(res,405,{ok:false,error:"METHOD"});
    const actor=await authenticate(req), authz=await readRole(actor.uid);
    await rateLimit(actor.uid);
    const submissionId=String(req.body&&req.body.submissionId||"").replace(/[^A-Za-z0-9_-]/g,"").slice(0,160);
    if(!submissionId) return json(res,400,{ok:false,error:"INVALID_REQUEST"});
    const snap=await getDatabase().ref(`streamSubmissions/${submissionId}`).get();
    const submission=snap.val()||null;
    if(!submission) return json(res,404,{ok:false,error:"SUBMISSION_NOT_FOUND"});
    const isOwnerOfSubmission=String(submission.uid||"")===actor.uid;
    const canModerate=hasSupportPermission(authz,"streamModeration")||hasSupportPermission(authz,"adminActions");
    if(!isOwnerOfSubmission&&!canModerate) return json(res,403,{ok:false,error:"FORBIDDEN"});
    if(String(submission.status||"")==="PUBLISHED") return json(res,200,{ok:true,found:true,alreadyLive:true,fileId:Number(submission.publishedFileId||0)||null});
    if(String(submission.status||"")!=="APPROVED") return json(res,400,{ok:false,error:"STATUS_NOT_APPROVED"});
    catalogCache.at=0;
    const catalog=await publishedCatalog();
    const match=await findCatalogFileForSubmissionDeep(catalog,submission);
    if(!match||match.fileId<=0) return json(res,200,{ok:true,found:false});
    const result=await finalizePublishedSubmission(submissionId,submission,match.fileId,`BACKEND_NOW:${match.matchedBy}`);
    return json(res,200,{...result,found:result.ok===true,matchedBy:match.matchedBy});
  }catch(e){
    if(String(e.message)==="AUTH_REQUIRED") return json(res,401,{ok:false,error:"AUTH_REQUIRED"});
    console.error("scanApprovedPublicationNow",e); return json(res,500,{ok:false,error:"PUBLICATION_SCAN_FAILED"});
  }
});

exports.setManualPublicationStatus = onRequest({ region: REGION, timeoutSeconds: 90, memory: "256MiB", cors: false }, async (req,res)=>{
  try{
    if(req.method!=="POST") return json(res,405,{ok:false,error:"METHOD"});
    const actor=await authenticate(req), authz=await readRole(actor.uid);
    if(!hasSupportPermission(authz,"streamModeration")&&!hasSupportPermission(authz,"adminActions")) return json(res,403,{ok:false,error:"FORBIDDEN"});
    const submissionId=String(req.body&&req.body.submissionId||"").replace(/[^A-Za-z0-9_-]/g,"").slice(0,160);
    const live=req.body&&req.body.live===true;
    const fileId=Number(req.body&&req.body.fileId||0);
    if(!submissionId) return json(res,400,{ok:false,error:"INVALID_REQUEST"});
    const snap=await getDatabase().ref(`streamSubmissions/${submissionId}`).get();
    const submission=snap.val()||null;
    if(!submission) return json(res,404,{ok:false,error:"SUBMISSION_NOT_FOUND"});
    const result=await setManualPublicationState(submissionId,submission,live,actor.uid,fileId);
    if(!result.ok) return json(res,400,{ok:false,error:result.reason||"MANUAL_PUBLICATION_FAILED"});
    return json(res,200,result);
  }catch(e){
    if(String(e.message)==="AUTH_REQUIRED") return json(res,401,{ok:false,error:"AUTH_REQUIRED"});
    console.error("setManualPublicationStatus",e); return json(res,500,{ok:false,error:"MANUAL_PUBLICATION_FAILED"});
  }
});

async function approvedSubmissionForCatalogFile(fileId) {
  const db = getDatabase();
  catalogCache.at = 0;
  const catalog = await publishedCatalog();
  const meta = catalog.get(Number(fileId)) || null;
  if (!meta) return null;
  const identity = await readCatalogIdentity(Number(fileId), meta).catch(() => ({ musicId: "", title: "", artist: "" }));
  const musicId = cleanMusicId(identity.musicId);
  const title = normalizeCatalogText(identity.title || meta.title);
  const artist = normalizeCatalogText(identity.artist || meta.artist);
  const fileName = String(meta.name || "").toLowerCase();
  const filePath = String(meta.path || "").toLowerCase();
  const snap = await db.ref("streamSubmissions").get();
  const candidates = [];
  snap.forEach(child => {
    const value = child.val() || {};
    value.id = String(value.id || child.key || "");
    const status = String(value.status || "");
    if (!["APPROVED", "PUBLISHED"].includes(status)) return;
    candidates.push(value);
  });
  if (musicId) {
    const exactMusic = candidates.filter(s => cleanMusicId(s.musicId) === musicId);
    if (exactMusic.length === 1) return exactMusic[0];
  }
  const byLegacyId = candidates.filter(s => {
    const id = String(s.id || "").toLowerCase();
    return id && (fileName.includes(id) || filePath.includes(id));
  });
  if (byLegacyId.length === 1) return byLegacyId[0];
  if (title && artist) {
    const exact = candidates.filter(s => normalizeCatalogText(s.title) === title && normalizeCatalogText(s.artistName) === artist);
    if (exact.length === 1) return exact[0];
  }
  return null;
}

exports.setManualPublicationByFile = onRequest({ region: REGION, timeoutSeconds: 90, memory: "256MiB", cors: false }, async (req,res)=>{
  try {
    if(req.method!=="POST") return json(res,405,{ok:false,error:"METHOD"});
    const actor=await authenticate(req), authz=await readRole(actor.uid);
    if(!hasSupportPermission(authz,"streamModeration")&&!hasSupportPermission(authz,"adminActions")) return json(res,403,{ok:false,error:"FORBIDDEN"});
    const fileId=Number(req.body&&req.body.fileId||0);
    if(!Number.isSafeInteger(fileId)||fileId<=0) return json(res,400,{ok:false,error:"INVALID_FILE"});
    const submission=await approvedSubmissionForCatalogFile(fileId);
    if(!submission) return json(res,404,{ok:false,error:"APPROVED_SUBMISSION_NOT_FOUND"});
    const submissionId=String(submission.id||"");
    const result=await setManualPublicationState(submissionId,submission,true,actor.uid,fileId);
    if(!result.ok) return json(res,400,{ok:false,error:result.reason||"MANUAL_PUBLICATION_FAILED"});
    return json(res,200,{...result,submissionId});
  } catch(e) {
    if(String(e.message)==="AUTH_REQUIRED") return json(res,401,{ok:false,error:"AUTH_REQUIRED"});
    console.error("setManualPublicationByFile",e);
    return json(res,500,{ok:false,error:"MANUAL_PUBLICATION_BY_FILE_FAILED"});
  }
});

exports.hideRejectedSubmission = onRequest({ region: REGION, timeoutSeconds: 30, memory: "128MiB", cors: false }, async (req,res)=>{
  try{
    if(req.method!=="POST") return json(res,405,{ok:false,error:"METHOD"});
    const actor=await authenticate(req);
    const submissionId=String(req.body&&req.body.submissionId||"").replace(/[^A-Za-z0-9_-]/g,"").slice(0,160);
    if(!submissionId) return json(res,400,{ok:false,error:"INVALID_REQUEST"});
    const ref=getDatabase().ref(`streamSubmissions/${submissionId}`);
    const snap=await ref.get(); const submission=snap.val()||null;
    if(!submission) return json(res,404,{ok:false,error:"SUBMISSION_NOT_FOUND"});
    if(String(submission.uid||"")!==actor.uid) return json(res,403,{ok:false,error:"FORBIDDEN"});
    if(String(submission.status||"")!=="REJECTED") return json(res,400,{ok:false,error:"ONLY_REJECTED"});
    await ref.update({userHiddenAt:Date.now(),userHiddenBy:actor.uid});
    return json(res,200,{ok:true});
  }catch(e){
    if(String(e.message)==="AUTH_REQUIRED") return json(res,401,{ok:false,error:"AUTH_REQUIRED"});
    console.error("hideRejectedSubmission",e); return json(res,500,{ok:false,error:"HIDE_FAILED"});
  }
});

exports.artistAnalytics = onRequest({ region: REGION, timeoutSeconds: 30, memory: "256MiB", cors: false }, async (req,res)=>{
  try{
    if(req.method!=="POST") return json(res,405,{ok:false,error:"METHOD"});
    const user=await authenticate(req), db=getDatabase();
    const artistId=String(req.body&&req.body.artistId||"").replace(/[^A-Za-z0-9_-]/g,"").slice(0,120);
    const periodDays=Math.max(0,Math.min(3650,Number(req.body&&req.body.periodDays||0)));
    const artist=(await db.ref(`streamArtistProfilesById/${artistId}`).get()).val()||null;
    if(!artist) return json(res,404,{ok:false,error:"ARTIST_NOT_FOUND"});
    const role=await readRole(user.uid);
    if(String(artist.uid||"")!==user.uid && role.role!=="OWNER" && role.role!=="SUPPORT") return json(res,403,{ok:false,error:"FORBIDDEN"});

    const root=(await db.ref(`streamArtistAnalytics/${artistId}`).get()).val()||{};
    const summary=root.summary||{}, allDaily=root.daily||{};
    const keys=Object.keys(allDaily).sort();
    let selectedKeys=keys;
    let periodStartMs=0;
    if(periodDays>0){
      const cutoff=new Date(Date.now()-(periodDays-1)*DAY_MS);
      const cutoffKey=brDayKey(cutoff.getTime());
      selectedKeys=keys.filter(k=>k>=cutoffKey);
      periodStartMs=Date.parse(`${cutoffKey}T00:00:00-03:00`);
    }

    const add=(o,k,n)=>o[k]=Number(o[k]||0)+Number(n||0);
    const sources={}, hourly={}, daily={}, dailyListeningMs={}, dailyFollowers={}, heatmap={}, weekday={}, songs={};
    let validPlays=0, returningPlays=0, listeningMs=0, organicPlays=0, boostedPlays=0, completions=0, skips=0, earlySkips=0, likes=0, newFollowers=0;

    const absorbSong=(fid,v)=>{
      const x=songs[fid]||(songs[fid]={fileId:Number(fid),title:v&&v.title||`Faixa ${fid}`,genre:v&&v.genre||"",validPlays:0,returningPlays:0,listeningMs:0,completions:0,skips:0,earlySkips:0,retentionSum:0,retentionSamples:0,likes:0,followersGenerated:0,organicPlays:0,boostedPlays:0,sources:{}});
      for(const k of ["validPlays","returningPlays","listeningMs","completions","skips","earlySkips","retentionSum","retentionSamples","likes","followersGenerated","organicPlays","boostedPlays"]) x[k]=Number(x[k]||0)+Number(v&&v[k]||0);
      if(v&&v.title) x.title=v.title; if(v&&v.genre) x.genre=v.genre;
      for(const [src,sv] of Object.entries(v&&v.sources||{})) add(x.sources,src,sv&&sv.plays);
      return x;
    };

    const dayName=(day)=>new Intl.DateTimeFormat("pt-BR",{timeZone:"UTC",weekday:"short"}).format(new Date(`${day}T12:00:00Z`)).replace(".","");

    if(periodDays===0){
      validPlays=Number(summary.validPlays||0); returningPlays=Number(summary.returningPlays||0); listeningMs=Number(summary.listeningMs||0);
      organicPlays=Number(summary.organicPlays||0); boostedPlays=Number(summary.boostedPlays||0); completions=Number(summary.completions||0); skips=Number(summary.skips||0); earlySkips=Number(summary.earlySkips||0); likes=Number(summary.likes||0);
      for(const [k,v] of Object.entries(root.sources||{})) sources[k]=Number(v&&v.plays||0);
      for(const [k,v] of Object.entries(root.hourly||{})) hourly[k]=Number(v&&v.plays||0);
      for(const [fid,v] of Object.entries(root.songs||{})){ songs[fid]={...(v||{}),fileId:Number(fid),sources:Object.fromEntries(Object.entries(v&&v.sources||{}).map(([k,x])=>[k,Number(x&&x.plays||0)]))}; }
      for(const day of keys){ const d=allDaily[day]||{}; daily[day]=Number(d.plays||0); dailyListeningMs[day]=Number(d.listeningMs||0); dailyFollowers[day]=Number(d.newFollowers||0); heatmap[day]=Object.fromEntries(Object.entries(d.hourly||{}).map(([h,x])=>[h,Number(x&&x.plays||0)])); add(weekday,dayName(day),d.plays); }
    } else {
      for(const day of selectedKeys){
        const d=allDaily[day]||{}; daily[day]=Number(d.plays||0); dailyListeningMs[day]=Number(d.listeningMs||0); dailyFollowers[day]=Number(d.newFollowers||0); heatmap[day]=Object.fromEntries(Object.entries(d.hourly||{}).map(([h,x])=>[h,Number(x&&x.plays||0)])); add(weekday,dayName(day),d.plays);
        validPlays+=Number(d.plays||0); returningPlays+=Number(d.returningPlays||0); listeningMs+=Number(d.listeningMs||0); organicPlays+=Number(d.organicPlays||0); boostedPlays+=Number(d.boostedPlays||0); completions+=Number(d.completions||0); skips+=Number(d.skips||0); earlySkips+=Number(d.earlySkips||0); likes+=Number(d.likes||0); newFollowers+=Number(d.newFollowers||0);
        for(const [k,v] of Object.entries(d.sources||{})) add(sources,k,v&&v.plays); for(const [k,v] of Object.entries(d.hourly||{})) add(hourly,k,v&&v.plays); for(const [fid,v] of Object.entries(d.songs||{})) absorbSong(fid,v);
      }
    }

    // Ouvintes são calculados no backend para nunca expor identidades ao artista.
    const listenerIds=new Set();
    if(periodDays>0){ for(const day of selectedKeys){ const snap=await db.ref(`streamArtistDailyListenersPrivate/${artistId}/${day}`).get(); snap.forEach(c=>listenerIds.add(c.key)); } }
    const audienceSnap=await db.ref(`streamArtistAudiencePrivate/${artistId}`).get();
    if(periodDays===0) audienceSnap.forEach(c=>listenerIds.add(c.key));
    const audienceByUid={}; audienceSnap.forEach(c=>audienceByUid[c.key]=c.val()||{});
    const uniqueListeners=listenerIds.size;
    let newListeners=0, returningListeners=0;
    for(const uid of listenerIds){ const x=audienceByUid[uid]||{}; const first=Number(x.firstSeenAt||0), plays=Number(x.plays||0); if(periodDays===0 ? first>0 : first>=periodStartMs) newListeners++; if(periodDays===0 ? plays>1 : first>0&&first<periodStartMs) returningListeners++; }

    const followersSnap=await db.ref(`streamArtistFollowers/${artistId}`).get();
    const followerIds=new Set(); followersSnap.forEach(c=>followerIds.add(c.key));
    let followerListeners=0; for(const uid of listenerIds) if(followerIds.has(uid)) followerListeners++;

    // Únicos por música no período.
    if(periodDays>0){
      for(const [fid,x] of Object.entries(songs)){ const setSong=new Set(); for(const day of selectedKeys){ const snap=await db.ref(`streamArtistDailySongListenersPrivate/${artistId}/${day}/${fid}`).get(); snap.forEach(c=>setSong.add(c.key)); } x.uniqueListeners=setSong.size; }
    } else {
      for(const x of Object.values(songs)) x.uniqueListeners=Number(x.uniqueListeners||0);
    }

    // Crescimento da faixa comparado ao período imediatamente anterior.
    if(periodDays>0 && selectedKeys.length){
      const first=selectedKeys[0], firstTs=Date.parse(`${first}T00:00:00-03:00`), prevStart=brDayKey(firstTs-periodDays*DAY_MS), prevEnd=brDayKey(firstTs-DAY_MS), prevSongPlays={};
      for(const [day,d] of Object.entries(allDaily)){ if(day<prevStart||day>prevEnd) continue; for(const [fid,v] of Object.entries(d&&d.songs||{})) add(prevSongPlays,fid,v&&v.validPlays); }
      for(const [fid,x] of Object.entries(songs)){ const prev=Number(prevSongPlays[fid]||0), cur=Number(x.validPlays||0); x.growthPercent=prev>0?((cur-prev)/prev)*100:(cur>0?100:0); }
    } else for(const x of Object.values(songs)) x.growthPercent=0;

    const publishedSnap=await db.ref("streamPublishedArtists").get(); const publishedByFile={};
    publishedSnap.forEach(c=>{const v=c.val()||{};if(String(v.artistId||"")===artistId) publishedByFile[String(v.fileId||c.key)]=Number(v.updatedAt||0);});
    for(const [fid,x] of Object.entries(songs)) x.publishedAt=Number(publishedByFile[fid]||0);

    const genres={}; for(const x of Object.values(songs)) if(String(x.genre||"").trim()) add(genres,String(x.genre).trim(),x.validPlays);
    const publishedSongs=Object.keys(publishedByFile).length || Object.keys(songs).length;

    let playGrowthPercent=0;
    if(periodDays>0&&selectedKeys.length){ const first=selectedKeys[0], firstTs=Date.parse(`${first}T00:00:00-03:00`), prevStart=brDayKey(firstTs-periodDays*DAY_MS), prevEnd=brDayKey(firstTs-DAY_MS); let prevPlays=0; for(const [k,d] of Object.entries(allDaily)){ if(k>=prevStart&&k<=prevEnd) prevPlays+=Number(d&&d.plays||0); } if(prevPlays>0) playGrowthPercent=((validPlays-prevPlays)/prevPlays)*100; else if(validPlays>0) playGrowthPercent=100; }
    const followers=Number((await db.ref(`streamArtistPublicStats/${artistId}/followers`).get()).val()||summary.followers||0);
    const averageFrequency=uniqueListeners>0?validPlays/uniqueListeners:0;

    return json(res,200,{ok:true,artistId,artistName:String(artist.artistName||root.artistName||""),periodDays,validPlays,uniqueListeners,newListeners,returningListeners,returningPlays,followerListeners,averageFrequency,listeningMs,followers,newFollowers,likes,publishedSongs,organicPlays,boostedPlays,completions,skips,earlySkips,playGrowthPercent,sources,hourly,daily,dailyListeningMs,dailyFollowers,heatmap,weekday,genres,songs:Object.values(songs)});
  }catch(e){ if(String(e.message)==="AUTH_REQUIRED") return json(res,401,{ok:false,error:"AUTH_REQUIRED"}); console.error("artistAnalytics",e); return json(res,500,{ok:false,error:"ANALYTICS_FAILED"}); }
});

/** Ações privilegiadas de suporte. A autorização real é verificada no backend. */
exports.supportAction = onRequest({ region: REGION, timeoutSeconds: 30, memory: "128MiB", cors: false }, async (req, res) => {
  try {
    if (req.method !== "POST") return json(res, 405, { ok: false, error: "METHOD" });
    const actor = await authenticate(req);
    const authz = await readRole(actor.uid);
    const action = String(req.body && req.body.action || "").toUpperCase();
    const targetUid = String(req.body && req.body.targetUid || "").trim();
    const ticketId = String(req.body && req.body.ticketId || "").trim().slice(0, 160);
    const payload = (req.body && req.body.payload && typeof req.body.payload === "object") ? req.body.payload : {};
    if (!targetUid) return json(res, 400, { ok: false, error: "TARGET_REQUIRED" });

    const permission = action === "GRANT_PREMIUM" ? "premium" : action === "RECHECK_PAYMENT" ? "payments" : action === "DELETE_RECEIPTS" ? "tickets" : action === "APPROVE_ARTIST_NAME" ? "streamModeration" : action === "REMOVE_STREAM_TRACK" ? "streamRemoval" : "premium";
    if (!hasSupportPermission(authz, permission) && !hasSupportPermission(authz, "adminActions")) return json(res, 403, { ok: false, error: "FORBIDDEN" });

    const db = getDatabase();
    const now = Date.now();
    let result = {};
    if (action === "GRANT_PREMIUM") {
      const tier = String(payload.tier || "").toUpperCase();
      const paidDays = Math.max(0, Math.min(3650, Number(payload.paidDays || 0)));
      const bonusDays = Math.max(0, Math.min(3650, Number(payload.bonusDays || 0)));
      const totalDays = paidDays + bonusDays;
      if (!["PRATA", "OURO", "DIAMANTE"].includes(tier) || totalDays <= 0) return json(res, 400, { ok: false, error: "INVALID_PREMIUM" });
      const entRef = db.ref(`premiumEntitlements/${targetUid}`);
      const current = (await entRef.get()).val() || {};
      const base = Math.max(now, Number(current.expiresAt || 0));
      const expiresAt = base + totalDays * DAY_MS;
      await entRef.set({
        tier, expiresAt, active: true, paidDays, bonusDays,
        reason: String(payload.reason || "Suporte SONUS").slice(0, 240),
        ticketId, source: "MANUAL_SUPPORT", updatedAt: now, updatedBy: actor.uid
      });
      await pushNotice(targetUid, "Premium atualizado", `Seu plano ${tier === "PRATA" ? "Prata" : tier === "OURO" ? "Ouro" : "Diamante"} foi ativado por ${totalDays} dia(s)${bonusDays ? `, incluindo ${bonusDays} dia(s) de cortesia` : ""}.`, "PREMIUM_GRANTED", "PREMIUM");
      result = { tier, expiresAt, paidDays, bonusDays, totalDays };
    } else if (action === "SYNC_PREMIUM") {
      const ent = (await db.ref(`premiumEntitlements/${targetUid}`).get()).val() || null;
      result = { entitlement: ent };
      await pushNotice(targetUid, "Premium sincronizado", "A equipe SONUS solicitou uma nova sincronização do seu benefício.", "PREMIUM_SYNC", "PREMIUM");
    } else if (action === "RECHECK_PAYMENT") {
      const payments = (await db.ref(`payments/${targetUid}`).get()).val() || {};
      const entries = Object.entries(payments).map(([id, p]) => ({ id, ...(p || {}) })).sort((a, b) => Number(b.updatedAt || b.createdAt || 0) - Number(a.updatedAt || a.createdAt || 0));
      result = { latestPayment: entries[0] || null };
    } else if (action === "APPROVE_ARTIST_NAME") {
      const requested = String(payload.requestedArtistName || "").trim().slice(0, 120);
      const artistId = String(payload.artistId || "").trim().slice(0, 180);
      if (requested.length < 2) return json(res, 400, { ok: false, error: "INVALID_ARTIST_NAME" });

      if (artistId) {
        const profileRef = db.ref(`streamArtistProfilesById/${artistId}`);
        const profile = await profileRef.get();
        if (!profile.exists() || String(profile.child("uid").val() || "") !== targetUid) {
          return json(res, 404, { ok: false, error: "ARTIST_NOT_FOUND" });
        }
        await profileRef.update({ artistName: requested, updatedAt: now, updatedBy: actor.uid });

        const legacyRef = db.ref(`streamArtistProfiles/${targetUid}`);
        const legacy = await legacyRef.get();
        if (legacy.exists() && String(legacy.child("artistId").val() || "") === artistId) {
          await legacyRef.update({ artistName: requested, updatedAt: now, updatedBy: actor.uid });
        }

        const submissions = await db.ref("streamSubmissions").orderByChild("uid").equalTo(targetUid).get();
        for (const node of childrenOf(submissions)) {
          if (String(node.child("artistId").val() || "") === artistId) {
            await node.ref.update({ artistName: requested, updatedAt: now });
          }
        }
        const published = await db.ref("streamPublishedArtists").get();
        for (const node of childrenOf(published)) {
          if (String(node.child("uid").val() || "") === targetUid && String(node.child("artistId").val() || "") === artistId) {
            await node.ref.update({ artistName: requested, updatedAt: now });
          }
        }
        await db.ref(`streamArtistAnalytics/${artistId}/artistName`).set(requested);
      } else {
        // Compatibilidade com chamados legados criados antes do artistId.
        const legacyRef = db.ref(`streamArtistProfiles/${targetUid}`);
        const legacy = await legacyRef.get();
        if (!legacy.exists()) return json(res, 404, { ok: false, error: "ARTIST_NOT_FOUND" });
        await legacyRef.update({ artistName: requested, updatedAt: now, updatedBy: actor.uid });
        const submissions = await db.ref("streamSubmissions").orderByChild("uid").equalTo(targetUid).get();
        for (const node of childrenOf(submissions)) await node.ref.update({ artistName: requested, updatedAt: now });
        const published = await db.ref("streamPublishedArtists").get();
        for (const node of childrenOf(published)) {
          if (String(node.child("uid").val() || "") === targetUid) await node.ref.update({ artistName: requested, updatedAt: now });
        }
      }
      await pushNotice(targetUid, "Nome artístico atualizado", `Seu perfil de artista agora usa o nome ${requested}.`, "ARTIST_NAME_CHANGED", "STREAM_CREATOR");
      result = { artistId: artistId || null, artistName: requested };
    } else if (action === "REMOVE_STREAM_TRACK") {
      const submissionId = String(payload.submissionId || "").trim().slice(0, 180);
      const musicId = String(payload.musicId || "").trim().slice(0, 80);
      const reason = String(payload.reason || "").trim().slice(0, 1000);
      if (!submissionId || !reason) return json(res, 400, { ok: false, error: "INVALID_REMOVAL_REQUEST" });
      const submissionRef = db.ref(`streamSubmissions/${submissionId}`);
      const submission = await submissionRef.get();
      if (!submission.exists() || String(submission.child("uid").val() || "") !== targetUid) {
        return json(res, 404, { ok: false, error: "SUBMISSION_NOT_FOUND" });
      }
      const storedMusicId = String(submission.child("musicId").val() || "");
      if (musicId && storedMusicId && musicId !== storedMusicId) return json(res, 409, { ok: false, error: "MUSIC_ID_MISMATCH" });
      const requestedFileId = Number(payload.fileId || 0);
      const storedFileId = Number(submission.child("publishedFileId").val() || 0);
      const fileId = Number.isSafeInteger(requestedFileId) && requestedFileId > 0 ? requestedFileId : storedFileId;
      if (!Number.isSafeInteger(fileId) || fileId <= 0) return json(res, 400, { ok: false, error: "FILE_ID_REQUIRED" });
      if (storedFileId > 0 && requestedFileId > 0 && storedFileId !== requestedFileId) return json(res, 409, { ok: false, error: "FILE_ID_MISMATCH" });

      await Promise.all([
        submissionRef.update({ status: "REMOVED", removedAt: now, removedBy: actor.uid, removalReason: reason }),
        db.ref(`streamPublishedArtists/${fileId}`).remove(),
        db.ref(`publicConfig/sonusMusic/removedFileIds/${fileId}`).set(true),
        db.ref(`sonusMusicAdmin/removedTracks/${fileId}`).set({
          fileId, submissionId, musicId: storedMusicId || musicId, uid: targetUid,
          title: String(submission.child("title").val() || payload.title || ""),
          artist: String(submission.child("artistName").val() || payload.artist || ""),
          reason, removedAt: now, removedBy: actor.uid
        })
      ]);
      catalogCache = { at: 0, files: new Map() };
      await pushNotice(targetUid, "Música removida do SONUS Stream", `${String(submission.child("title").val() || "Sua música")} foi removida do catálogo pela equipe SONUS.`, "STREAM_TRACK_REMOVED", "STREAM_CREATOR");
      result = { submissionId, musicId: storedMusicId || musicId, fileId, removed: true };
    } else if (action === "DELETE_RECEIPTS") {
      if (!ticketId) return json(res, 400, { ok: false, error: "TICKET_REQUIRED" });
      const ticketRef = db.ref(`supportTickets/${ticketId}`);
      const ticket = await ticketRef.get();
      if (!ticket.exists() || String(ticket.child("ownerUid").val() || "") !== targetUid) return json(res, 404, { ok: false, error: "TICKET_NOT_FOUND" });
      let deleted = 0;
      for (const m of childrenOf(ticket.child("messages"))) {
        const storagePath = m.child("attachmentStoragePath").val();
        if (storagePath) {
          await deleteStoragePath(storagePath);
          await m.ref.update({ attachmentUrl: null, attachmentStoragePath: null, attachmentPurgedAt: now, body: "Comprovante verificado e removido" });
          deleted++;
        }
      }
      result = { deleted };
    } else {
      return json(res, 400, { ok: false, error: "UNKNOWN_ACTION" });
    }

    const auditRef = db.ref("adminAudit").push();
    await auditRef.set({ actorUid: actor.uid, actorRole: authz.role, targetUid, ticketId, action, payload, result, createdAt: now });
    return json(res, 200, { ok: true, result });
  } catch (e) {
    if (String(e.message) === "AUTH_REQUIRED") return json(res, 401, { ok: false, error: "AUTH_REQUIRED" });
    console.error("supportAction", e);
    return json(res, 500, { ok: false, error: "SUPPORT_ACTION_FAILED" });
  }
});

async function deleteStoragePath(path) {
  if (!path || typeof path !== "string") return;
  try { await getStorage().bucket().file(path).delete({ ignoreNotFound: true }); } catch (e) { console.warn("cleanup storage", path, e.message); }
}

/** Detecta automaticamente SOMENTE músicas aprovadas que realmente chegaram ao catálogo público.
 *  code106: se não houver APPROVED pendente, encerra sem abrir/varrer o catálogo. */
exports.scanApprovedPublications = onSchedule({ region: REGION, schedule: "every 5 minutes", timeZone: "America/Sao_Paulo", timeoutSeconds: 180, memory: "256MiB" }, async () => {
  const db = getDatabase();
  const approved = await db.ref("streamSubmissions").orderByChild("status").equalTo("APPROVED").limitToFirst(100).get();
  const approvedChildren = childrenOf(approved);
  if (!approvedChildren.length) return;

  // Força uma leitura recente do pCloud somente quando existe APPROVED aguardando publicação.
  catalogCache.at = 0;
  const catalog = await publishedCatalog();
  const tasks = approvedChildren.map(child => {
    const submission = child.val() || {};
    return (async () => {
      const match = await findCatalogFileForSubmissionDeep(catalog, submission);
      if (!match || match.fileId <= 0) return { ok: false, reason: "NOT_FOUND", submissionId: child.key };
      return finalizePublishedSubmission(child.key, submission, match.fileId, `BACKEND_AUTO:${match.matchedBy}`);
    })();
  });

  const results = await Promise.allSettled(tasks);
  for (const r of results) if (r.status === "rejected") console.error("scanApprovedPublications item", r.reason);
});

/** Retenção curta: comprovantes/chats resolvidos e uploads recusados não viram arquivo permanente. */
exports.cleanupTemporaryData = onSchedule({ region: REGION, schedule: "every day 03:17", timeZone: "America/Sao_Paulo", timeoutSeconds: 300, memory: "256MiB" }, async () => {
  const db = getDatabase();
  const now = Date.now();
  const tickets = await db.ref("supportTickets").get();
  for (const t of childrenOf(tickets)) {
    const purgeAfter = Number(t.child("purgeAfter").val() || 0);
    if (!purgeAfter || purgeAfter > now) continue;
    const messages = t.child("messages");
    for (const m of childrenOf(messages)) await deleteStoragePath(m.child("attachmentStoragePath").val());
    const createdAt = Number(t.child("createdAt").val() || 0);
    const resolvedAt = Number(t.child("resolvedAt").val() || t.child("updatedAt").val() || 0);
    const archive = {
      category: String(t.child("category").val() || "OTHER"),
      rating: Number(t.child("rating").val() || 0) || null,
      createdAt,
      resolvedAt,
      resolutionTimeMs: createdAt && resolvedAt ? Math.max(0, resolvedAt - createdAt) : null,
      archivedAt: now
    };
    await db.ref(`supportMetricsArchive/${t.key}`).set(archive);
    await t.ref.remove();
  }

  const submissions = await db.ref("streamSubmissions").get();
  for (const s of childrenOf(submissions)) {
    const status = String(s.child("status").val() || "");
    const when = Number(s.child(status === "PUBLISHED" ? "publishedAt" : "reviewedAt").val() || s.child("createdAt").val() || 0);
    const expired = (status === "REJECTED" && now - when > 7 * DAY_MS) || (status === "PUBLISHED" && now - when > DAY_MS);
    if (!expired) continue;
    await deleteStoragePath(s.child("audioStoragePath").val());
    await deleteStoragePath(s.child("coverStoragePath").val());
    await s.ref.update({ temporaryFilesPurgedAt: now, audioDownloadUrl: null, coverDownloadUrl: null });
  }
});

/** Diagnóstico técnico OWNER. Não interfere na reprodução. */
exports.ownerStreamHealth = onRequest({ region: REGION, timeoutSeconds: 20, memory: "128MiB", cors: false }, async (req,res)=>{
  try{
    if(req.method!=="POST") return json(res,405,{ok:false,error:"METHOD"});
    const user=await authenticate(req); const authz=await readRole(user.uid); if(authz.role!=="OWNER") return json(res,403,{ok:false,error:"FORBIDDEN"});
    const db=getDatabase(); let catalog=false, counter=false, artists=false, notifications=false, storage=false;
    try{catalog=(await publishedCatalog()).size>=0}catch(_){catalog=false}
    try{await db.ref("streamStats").limitToFirst(1).get();counter=true}catch(_){counter=false}
    try{await db.ref("streamArtistProfilesById").limitToFirst(1).get();artists=true}catch(_){artists=false}
    try{await db.ref(`streamUserNotifications/${user.uid}`).limitToFirst(1).get();notifications=true}catch(_){notifications=false}
    try{storage=!!getStorage().bucket().name}catch(_){storage=false}
    return json(res,200,{ok:true,audio:true,catalog,counter,artists,functions:true,database:true,storage,notifications,checkedAt:Date.now()});
  }catch(e){if(String(e.message)==="AUTH_REQUIRED")return json(res,401,{ok:false,error:"AUTH_REQUIRED"});console.error("ownerStreamHealth",e);return json(res,500,{ok:false,error:"HEALTH_FAILED"});}
});
