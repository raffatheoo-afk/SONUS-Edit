# SONUS Stream — backend seguro code93

Backend Firebase opcional/necessário para operações que não devem ser confiadas ao APK.

## Funções incluídas
- `stream`: proxy seguro do catálogo pCloud, com Firebase ID token e suporte a Range/seek.
- `startPlay` / `claimPlay`: sessão de reprodução válida; só contabiliza play após pelo menos 20 segundos reais.
- `supportAction`: ações privilegiadas do suporte/OWNER, incluindo rechecagem de pagamento, sincronização/liberação de Premium e limpeza imediata de comprovantes.
- `cleanupTemporaryData`: retenção curta de comprovantes, tickets e uploads temporários; antes de apagar um ticket grava somente métricas mínimas e sem conversa em `supportMetricsArchive`.

## Segurança
- exige Firebase ID token nas ações autenticadas;
- valida papel/permissão no servidor;
- o APK não recebe credenciais privadas do pCloud;
- incrementos de plays e benefícios Premium não são autorizados apenas pelo cliente;
- comprovantes e submissões rejeitadas são temporários.

## Deploy Firebase
A raiz do projeto code93 inclui `firebase.json`, `.firebaserc`, regras do Realtime Database e Storage.
Com Firebase CLI autenticado no projeto correto, faça o deploy das regras/funções conforme o ambiente de produção.

Por padrão o app usa `https://southamerica-east1-streenpulse.cloudfunctions.net` como base das funções HTTP. `SONUS_STREAM_PROXY_BASE` pode sobrescrever essa URL no Codemagic se o backend for movido para outro ambiente. O streaming mantém o fallback público do catálogo quando o proxy não responde, porém validação server-side de plays e ações privilegiadas dependem das funções implantadas.

## Pagamentos
O checkout Pix não faz parte da code93 e ficou adiado para uma próxima versão. Nenhuma credencial ou lógica de cobrança Pix é distribuída neste pacote.
