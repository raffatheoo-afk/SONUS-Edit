# SONUS 0.8.24 • code69 — checklist de release

## Recursos para Artistas
- [x] Criada área **Recursos para Artistas** no topo de Ajustes.
- [x] **Distribuição & Pagamentos** permanece existente e independente.
- [x] **Painéis das Distribuidoras** criado como recurso separado.
- [x] Ambos começam desativados por padrão.
- [x] Ativar recurso não fixa automaticamente na barra principal.
- [x] Cada recurso possui opção própria **Mostrar na barra principal**.
- [x] Usuário pode manter nenhum, um ou os dois recursos fixos.

## Distribuição & Pagamentos
- [x] Área original preservada.
- [x] Dados de artistas, saldo, financeiro, previsões e histórico preservados.
- [x] Quando não fixada, deixa de ocupar espaço na navegação inferior.
- [x] Continua acessível pelos Ajustes após ser ativada.

## Painéis das Distribuidoras
- [x] SoundOn.
- [x] Ditto.
- [x] DistroKid.
- [x] TuneCore.
- [x] FreshTunes.
- [x] RouteNote.
- [x] CD Baby.
- [x] ONErpm.
- [x] UnitedMasters.
- [x] Amuse.
- [x] LANDR.
- [x] Symphonic.
- [x] Too Lost.
- [x] Ícone/identidade + nome em cada card, com fallback visual se o favicon não carregar.
- [x] Favoritos ficam acima das demais.
- [x] Última distribuidora utilizada ganha prioridade.
- [x] Interface integrada ao padrão SONUS sem barra de endereço/abas.
- [x] Fallback **Abrir no navegador** disponível.

## Mobile / Desktop e perfis
- [x] Preferência Mobile/Desktop persistente por distribuidora.
- [x] SoundOn inicia em modo computador.
- [x] Alternância manual disponível no menu do painel.
- [x] Artistas/perfis da mesma distribuidora podem ser selecionados no cabeçalho.
- [x] Sessão é salva/restaurada por distribuidora + perfil quando o serviço permitir.
- [x] Cookies do recurso protegidos com Android Keystore (AES/GCM).
- [x] SONUS não armazena senhas; `saveFormData` desativado no WebView.
- [x] Limpeza de cookies restrita ao domínio da distribuidora, sem limpeza global do WebView.

## Preservação
- [x] Player não alterado.
- [x] Motor de áudio/qualidade não alterados.
- [x] Crossfade não alterado.
- [x] MediaSession/Bluetooth não alterados.
- [x] AdMob/Rewarded não alterado.
- [x] Usos Premium não alterados fora da navegação aprovada.
- [x] Vídeo → Áudio, Gravador, Dynamic Island PRO e demais áreas preservados.
- [x] `applicationId=com.sonusstudios.streampulse` preservado.

## Versão / pacote
- [x] versionName 0.8.24.
- [x] versionCode 69.
- [x] schemaVersion 18.
- [x] CHANGELOG atualizado.
- [x] README atualizado.
- [x] Sobre o SONUS atualizado.
- [x] Estrutura Kotlin verificada estaticamente.
- [x] XML parseado sem falhas.
- [ ] GitHub Actions: validação final de compilação Android após upload.
