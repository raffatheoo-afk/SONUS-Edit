# SONUS Stream — alterações da versão 0.0.7 / CODE07

## Stream renovado
- Home preserva a abertura leve; não resolve links de áudio nem inicia downloads de músicas ao entrar no Stream.
- A seção Gêneros apresenta as 18 categorias oficiais como cartões em duas colunas, com gradientes coordenados, ícones, contagem e ação de favorito.
- Gêneros favoritos ficam primeiro; os demais seguem a ordem alfabética.
- “MÚSICAS”, “MÚSICAS 2” e “MÚSICAS 3” continuam como identificadores internos das fontes pCloud. A interface apresenta categorias oficiais e nunca usa esses nomes técnicos como gêneros.
- A classificação usa metadados de gênero/subpasta e, como alternativa, o catálogo local de artistas. Faixas sem classificação confiável não são apresentadas sob um gênero incorreto.

## Catálogo, desempenho e atualização
- “Adicionadas recentemente” passa a usar um índice local compacto com as 80 faixas mais recentes, evitando reconstruir a lista completa em cada abertura.
- Conteúdo existente permanece visível durante sincronizações; a atualização não exige tela vazia.
- Preferência de atualização: a cada abertura, 30 min, 1 h, 2 h, 3 h, 6 h, 12 h, 24 h ou Manual.
- Instalações novas usam “A cada abertura” como padrão. Uma preferência já salva pelo usuário é mantida.
- A atualização manual continua disponível no cabeçalho de Gêneros.
- Abrir o Stream atualiza somente os dados básicos de publicação. A leitura das faixas é postergada até o usuário abrir uma seção/gênero ou tocar em uma estação.

## Rádio e LIVE
- Rádio exibe os 18 gêneros oficiais como estações leves. O catálogo de faixas é consultado somente após o toque na estação.
- A LIVE mantém seus fluxos, preparação, controles e transições; somente a classificação das estações/gêneros é alinhada ao catálogo oficial.

## Sobre
- O resumo exibido em “Sobre o SONUS” foi atualizado para documentar as novidades da CODE07.

## Correção de preparação do CODE07
- Restaurada a validação de estações automáticas por gênero no novo fluxo sob demanda: somente iniciar com mais de 15 faixas únicas. A lista leve de gêneros continua visível antes da consulta.
- Ajustado o preflight do Codemagic para validar a implementação atual do CODE07, em vez de exigir a expressão antiga do CODE06.
