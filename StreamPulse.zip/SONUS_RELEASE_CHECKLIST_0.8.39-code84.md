# SONUS 0.8.39 — code84

## Entrega
- Base: SONUS 0.8.38 code83 HOTFIX1
- versionName: 0.8.39
- versionCode: 84
- Player de áudio: 0.12
- Player de vídeo: 0.5

## Mudanças principais
- Correção do caminho de streaming pCloud do Sonus Music, com leitura remota por blocos e erro visível quando o stream falha.
- Conversor de Áudio com Artista independente do perfil e pré-visualização da capa.
- Continuar assistindo remove itens locais apagados e aceita toque longo para remover atalho.
- Player de Vídeo com área Link/Online, navegador interno e suporte a links diretos compatíveis.
- Legenda ao vivo no vídeo, com idioma, tamanho, cor, fundo, posição e exportação TXT/LRC.
- Letras/Transcrição ao vivo no SONUS PLAYER, com idiomas PT/EN/ES, foco na voz, TXT/LRC e cópia MP3 com letra nos metadados.
- Mini display de letras adaptado às 9 interfaces do SONUS PLAYER.
- Diagnóstico de transcrição no Painel Desenvolvedor.
- Sobre o SONUS mostra somente as novidades desta versão.

## Validação
A validação de compilação Android é executada no Codemagic. O pacote inclui verificações estáticas de versão e arquivos obrigatórios antes da etapa de build.
