# SONUS 0.8.1 — code 46

Base obrigatória: SONUS 0.8.0 code45.

Foco desta atualização: SONUS Visualizer.

- Editor de vídeo não foi reintroduzido.
- Visualizer abre em tela própria de Novo projeto + Rascunhos.
- Rascunhos persistem configurações principais e URIs com permissão persistível.
- Proporções 16:9, 9:16 e 1:1 no preview.
- Fundo com seleção, zoom, reposicionamento por arraste e escurecimento.
- Capa com seleção, tamanho, rotação, opacidade e formato circular/quadrado.
- Visualizer com intensidade, sensibilidade e resposta independente de graves/médios/agudos.
- Áudio continua analisado localmente e visualizer reage à análise real.
- Exportação não foi falsificada: a base 0.8.0 não contém motor de renderização de vídeo dedicado. O botão fica bloqueado até uma implementação real; quando implementado, manter a barra circular SONUS de progresso.
- versionName 0.8.1 / versionCode 46.
