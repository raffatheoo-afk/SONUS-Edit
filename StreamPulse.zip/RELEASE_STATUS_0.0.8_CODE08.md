# Status de entrega — SONUS 0.0.8 / CODE08

**Estado:** correção pontual dos erros de compilação identificados no primeiro log aplicada; aguardando novo build Codemagic e validação em aparelho.

## Conteúdo
- Correção da tela LIVE para carregar e sincronizar letras da faixa atual do SONUS Stream.
- Popup dedicado ao tocar em gênero, com fundo desfocado e botão Fechar inferior direito.
- Lista do gênero simplificada para favorito e play.
- Ações “Tocar tudo” e “Aleatório”; play individual inicia pela faixa escolhida.
- Cursor progressivo do cache JSON do gênero: 20 faixas por página, sem revarrer os registros anteriores a cada rolagem; prefetch ao se aproximar do fim. A fila completa de metadados só é lida sob demanda para reproduzir o gênero ou a faixa selecionada.
- “Sobre o SONUS” usa o `BuildConfig.VERSION_NAME` e `VERSION_CODE`, atualizados para 0.0.8 / code 8; o resumo de novidades também foi atualizado.

## Arquivos
- `StreamPulse.zip` — projeto Android completo, nome original.
- `codemagic.yaml` — workflow CODE08.
- `SONUS_CHECKLIST_INTERNO_0.0.8_CODE08.md` — checklist de implementação e testes pendentes.
- `CHANGELOG_0.0.8_CODE08.md` — mudanças desta versão.

## Validação feita nesta preparação
- Inspeção do vídeo e captura enviados pelo usuário.
- Conferência estática dos trechos Kotlin alterados e das referências de função.
- Conferência do `versionCode=8` e `versionName=0.0.8`.
- Conferência das referências e hashes dos três componentes protegidos.
- Validação sintática do YAML com PyYAML.
- Integridade do ZIP e presença dos arquivos de entrega serão conferidas após empacotamento.

## Limitações
- Este ambiente não dispõe de Android SDK, `gradle` nem `gradlew`; a compilação Android não foi executada aqui.
- O teste de LIVE com faixas Arrocha e o teste de rolagem longa ainda precisam ser feitos no aparelho.
- Sem snapshot completo já carregado na sessão, o painel mantém um cursor de leitura sequencial no JSON local e retém 20 faixas por página, sem revarrer registros anteriores. Se outra área já carregou o snapshot completo, a lista reaproveita esse cache e ainda apresenta 20 itens por vez. O SharedPreferences entrega o JSON como `String`; não é streaming remoto do pCloud. Ações de reprodução completa carregam os metadados do gênero escolhido sob demanda. O áudio não é pré-carregado.
- A resolução de letra da LIVE agora procura a faixa pelo ID sem desserializar o catálogo inteiro a cada troca de música.
- Contagens baixas por gênero não foram corrigidas, pois podem depender dos metadados e o usuário pediu para não alterar essa classificação nesta versão.

## Correção aplicada após log de compilação
- Resolvido o símbolo `Surface` ausente em `SonusLiveStudio.kt` por meio do import do Material 3.
- Resolvidos os símbolos `TextAlign`, `CircleShape` e `border` ausentes em `SonusOnlineMusic.kt` por meio dos imports Compose correspondentes.
- O erro de contexto `@Composable` em `SonusLiveStudio.kt` era consequência do símbolo `Surface` não resolvido; o bloco interno já estava dentro de `AnimatedVisibility` e `Crossfade`, ambos composables.
- Os imports foram adicionados sem alterar lógica funcional.
