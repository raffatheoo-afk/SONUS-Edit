# SONUS 0.0.5 — CODE 05

## Funcionalidades e compatibilidade consolidadas

- Catálogo único de 18 gêneros, em ordem alfabética, compartilhado pelos editores, Stream e Rádio.
- Normalização de nomes antigos e variações de acentuação/grafia sem apagar metadados históricos. Frevo deixa de ser opção principal, mas continua reconhecível em registros antigos.
- Categorias de humor (Sofrência e Triste / Depressão / Melancólico) só são aplicadas quando o metadado as informa explicitamente; música lenta não é classificada automaticamente como triste.
- Estações automáticas da Rádio só aparecem com mais de 15 faixas válidas por categoria.
- Envio de músicas configurado para MP3 192 kbps. Um MP3 de origem já em 192 kbps pode seguir por cópia do fluxo de áudio, sem recodificação, quando a taxa é detectada com confiabilidade e não há processamento DSP ativo.
- Conversão preserva os metadados de origem e atualiza os campos informados pelo envio; capa e letra continuam sendo incorporadas/validadas pelo fluxo individual.
- LIVE: contagem regressiva padrão e mínima de 10 segundos, configurável em 10, 15, 20 ou 30 segundos.
- LIVE: prepara cinco imagens baixadas e decodificadas antes de iniciar; o palco consome a mesma fila após a contagem. A reposição ocorre em segundo plano, sem interromper a cena atual.
- LIVE: a reprodução musical é confirmada antes de declarar a transmissão no ar; vídeos continuam mudos e respeitam o fim/erro do player.
- LIVE: removido texto central gigante e painel antigo. Divulgação discreta no rodapé alterna SONUS / SONUS Edit e apresenta Telegram `@sonusappupdate`.
- Stream: tarefas pesadas de busca, filtros, agrupamentos, recomendações, playlists, álbuns e programação de Rádio foram movidas para corrotinas fora da thread principal.
- Stream: formulário responsivo mantém envio individual e adiciona envio real de vários arquivos, com título por faixa, estado/erro individual e reenvio seletivo. Capa e gênero são comuns ao lote; OWNER escolhe o artista de cada faixa; letras/LRC seguem no envio individual.
- OWNER: pode selecionar o perfil artístico público associado ao envio. O backend registra o artista escolhido separadamente da conta que enviou, e as regras Firebase verificam esse vínculo.
- Perfil artístico: avatar circular do cabeçalho abre edição de avatar/nome; o cartão duplicado do corpo foi removido. Janela de alteração de nome de 30 dias preservada.
- Aprovadas e rejeitadas: cores vivas em repouso e realce mais intenso quando selecionadas.
- Versão Android: `versionName = 0.0.5`, `versionCode = 5`.

## Compatibilidade preservada

- Identidade do pacote Android e assinatura permanente mantidas.
- Três fontes pCloud e seus identificadores permanecem separados.
- Player, cache, Rádio, LIVE, editor individual, letras TXT/LRC, capas e processamento MP3 preservados.
- Regras Firebase mantêm compatibilidade com registros legados sem os novos campos de associação artística.

## Verificação e distribuição

- Código Kotlin alterado revisado por parser sintático; YAML Codemagic, scripts shell e JSON Firebase validados estaticamente.
- A compilação Android e a assinatura oficial do APK precisam ser confirmadas pela execução do workflow Codemagic com credenciais seguras e Android SDK 36. A validação física de desempenho/ANR também depende de aparelho real.
