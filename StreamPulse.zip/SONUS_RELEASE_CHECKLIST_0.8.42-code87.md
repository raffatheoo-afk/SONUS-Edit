# SONUS v0.8.42 — code87

## Release
- [x] versionName 0.8.42
- [x] versionCode 87
- [x] Base code86 preservada
- [x] Importador TXT/LRC corrigido
- [x] LRC na Home do player
- [x] Campo LRC ampliado nos 9 layouts
- [x] Grupo Codemagic `sonus_youtube` importado
- [x] Build valida presença de `YOUTUBE_API_KEY`
- [x] Busca YouTube/Karaokê preparados com credencial Codemagic
- [x] Hub Playlists do YouTube implementado
- [x] Changelog atual sem chave/segredos
- [ ] Compilar no Codemagic
- [ ] Instalar e executar smoke test no aparelho
- [ ] Validar todos os layouts com LRC real
- [ ] Validar busca, Karaokê e playlist real do YouTube
