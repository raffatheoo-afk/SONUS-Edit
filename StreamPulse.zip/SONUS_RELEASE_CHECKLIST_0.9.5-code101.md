# SONUS 0.9.5 / code101

- Checklist final aprovado e integrado.
- Upload pCloud File Request configurável remotamente; default 38wXZ9gDeEpUY0mBlHR2VOYIpQR2fNory.
- MP3 160 kbps, capa 1:1, LRC/TXT opcional e progresso visível.
- Contador simplificado: view crítica separada de Analytics secundário.
- Stream redesenhado, Rádio no topo, seções redundantes removidas, shelves compactas.
- Analytics usuário + acesso ao Analytics artista.
- Ajustes funcionais: auto atualização, preload, fade, crossfade, monitor de dados, Modo Festa.
- Gêneros canônicos e seleção predefinida.
- Rules code101 com configuração remota e base para playlists públicas/privadas.
