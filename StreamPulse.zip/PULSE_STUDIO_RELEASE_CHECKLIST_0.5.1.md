# Pulse Studio — Checklist de entrega 0.5.1 (28)

- [x] `versionName=0.5.1` / `versionCode=28`.
- [x] applicationId preservado: `com.sonusstudios.streampulse`.
- [x] Assinatura/keystore preservados.
- [x] 34 visualizadores de áudio por plano.
- [x] PulseLift Natural / Boost / Max.
- [x] Ícones alternativos por plano.
- [x] Gravador de Voz Pro e Removedor Vocal promovidos para Destaques.
- [x] Removedor Vocal e Alterar Tom redesenhados.
- [x] Originais preservados e exportações em nova cópia.
- [ ] GitHub Actions deve confirmar a compilação do APK.
