# SONUS v0.8.34 — code79

## Splash
- Nome `Sonus` aproximado do símbolo, reduzido em ~5% e com margem/reveal ampliados para evitar clipping lateral.

## DESTAQUES SONUS
- Contraste de texto reforçado por camada escura discreta, preservando glass, degradês, ícones e grade aprovada.

## Nuvem — Player de Música
- Card completo de cada serviço passa a abrir/recolher o conteúdo.
- Primeira entrada solicita pasta autorizada; acessos seguintes reutilizam a pasta persistida.
- Várias pastas autorizadas podem ficar salvas por serviço; a pasta principal pode ser trocada dentro do card.
- Arquivos, favoritos e recentes aparecem dentro da nuvem correspondente.
- Favoritos de serviços e de faixas deixam de depender de um único favorito global.

## SONUS VIDEO
- Barra superior: Vídeos (roxo), Nuvem (azul), YouTube (vermelho), Karaokê (degradê verde/azul/lilás) e Ajustes; botão Início removido.
- Miniaturas com tamanhos Pequena/Média/Grande e preferência persistente.
- Continuar assistindo mantém até 3 itens, posição e progresso visual.
- Tela de Ajustes própria com temas, pastas, estatísticas, reprodução, legendas, histórico/favoritos, reprodução externa, formatos e versões dos players.
- Equalizador automático classifica títulos como Filme, Música, Jogos, Voz/Podcast/Entrevista, Entretenimento ou Neutro; correção manual pode ser salva por vídeo.
- Gestos de brilho/volume/seek, duplo toque ±10 s, fullscreen, bloqueio de controles, PiP, velocidade 0,5x–3x, timer e modos de reprodução.
- Legendas externas SRT/VTT com tamanho, cor, contraste e sincronização; seleção de faixas embutidas permanece pelo player Media3 quando disponível.
- Informações técnicas: resolução, codec de vídeo/áudio, FPS, bitrate, canais, duração e tamanho quando disponíveis.
- Pastas inteligentes com seleção explícita e filtros opcionais para WhatsApp/gravações de tela.

## Abertura pelo Android
- SONUS registrado como opção para arquivos de áudio compatíveis.
- SONUS VIDEO registrado para vídeo e adiciona Player Rápido dedicado para abertura externa, com PiP e retomada de posição.

## Versionamento independente
- Player de Música: v0.7.
- Player de Vídeo: v0.3.
- Versões dos players são independentes do versionName/versionCode do aplicativo.

## Sobre o SONUS
- Changelog da versão atualizado.
- Tela Sobre carrega `SONUS_CHANGELOG.txt`, consolidando as melhorias registradas nas versões SONUS 0.8.x disponíveis no projeto, incluindo entradas históricas sem checklist dedicado quando havia registro no material de migração/changelog.

## Versão do app
- versionName: 0.8.34
- versionCode: 79
- applicationId preservado: `com.sonusstudios.streampulse`

## Build
- Pacote preparado para Codemagic com Java 17 / Gradle 8.13 / compileSdk 36 / targetSdk 36 / minSdk 26.
- O ZIP externo de compilação contém somente `codemagic.yaml` e `StreamPulse-CodeMagic-code79.zip`.
- Compilação final deve ser confirmada pelo Codemagic; o ambiente de preparação não contém Android SDK/Gradle offline suficientes para executar `assembleDebug` localmente.
