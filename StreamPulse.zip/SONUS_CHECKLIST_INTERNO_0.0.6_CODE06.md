# SONUS Stream — Checklist interno de preparação
## Versão 0.0.6 • CODE06

**Projeto:** SONUS / StreamPulse — reprodutor de música com ferramentas de áudio  
**Base:** 0.0.5 / CODE05 (`applicationId`: `com.sonusstudios.streampulse`)  
**Alvo:** `versionName = 0.0.6` • `versionCode = 6`  
**Uso:** checklist técnico interno; não é anúncio de release.

> Escopo desta entrega: exclusivamente o projeto SONUS Stream/StreamPulse. O pacote e as funções do reprodutor e das ferramentas de áudio são preservados. Nenhum código do projeto de editor de vídeo foi usado como base.

---

## 1. Identidade, versão e proteção da base

- [x] Usar o `StreamPulse` 0.0.5/CODE05 como base real da atualização.
- [x] Manter `applicationId = com.sonusstudios.streampulse`.
- [x] Atualizar `versionName` para `0.0.6` e `versionCode` para `6`.
- [x] Atualizar workflow e verificações estáticas do Codemagic para CODE06.
- [x] Manter o fluxo de assinatura permanente e os segredos existentes no ambiente seguro; não introduzir assinatura debug como fallback.
- [x] Preservar sem edição os três arquivos protegidos: `AudioToolEngine.kt`, `PulsePlayerService.kt` e `SonusStreamPlatform.kt`.
- [x] Manter o caminho de áudio, o Player principal, equalizador e ferramentas de áudio fora desta refatoração.
- [ ] Confirmar build e assinatura oficial na execução CODE06 do Codemagic.

## 2. LIVE — preparação, início e palco

- [x] Retirar a exigência de cinco imagens decodificadas para habilitar **Iniciar LIVE**.
- [x] Preparar somente uma primeira cena durante a configuração (`count = 1`).
- [x] Limitar a espera da primeira transferência/decodificação a 14 segundos.
- [x] Permitir iniciar quando a fonte de áudio estiver disponível e houver tempo de LIVE; a quantidade de imagens não faz parte da condição de início.
- [x] Quando nenhuma imagem estiver pronta, usar o cenário oficial SONUS como fallback e continuar tentando preparar cenas em segundo plano.
- [x] Preservar a fila do palco e o limite de até cinco cenas preparadas para reposição.
- [x] Manter a cena atual na tela enquanto a próxima não estiver pronta; não baixar mídia no caminho de troca.
- [x] Preservar timeout por tentativa de mídia, tentativas alternativas e intervalo de nova tentativa no palco.
- [x] Preservar vídeos sem áudio e sua duração original; o intervalo configurado continua valendo somente para fotos.
- [x] Preservar transições do palco, modo imersivo, barra de controles, controles de volume/microfone, interação de tela, curtidas/apoio, encerramento e resumo da sessão.
- [x] Preservar contagem regressiva padrão/mínima de 10 segundos e opções 10, 15, 20 e 30 segundos.
- [x] Preservar os modos de fonte SONUS Rádio, SONUS Stream e Biblioteca interna.
- [x] Preservar a confirmação de reprodução real do player antes de mudar a LIVE para `ON_AIR`; em falha, voltar à configuração.
- [x] Preservar opção de silenciar o microfone ao iniciar, com possibilidade de religar no palco.
- [x] Remover a atualização repetitiva do catálogo de LIVE em intervalo fixo; usar cache inicial e atualização pontual já existente.
- [ ] Testar no aparelho: mídia sem rede, imagem lenta, primeira imagem ausente, vídeo longo, alternância de fonte e continuidade do áudio.
- [ ] Testar captura real de áudio no aplicativo de transmissão (ex.: TikTok), microfone, rotação, ANR e encerramento por limite.

## 3. SONUS Stream — abertura leve e carregamento sob demanda

- [x] Retirar o pré-aquecimento do catálogo e das capas do `Application.onCreate`.
- [x] Remover reconstrução automática do snapshot completo após invalidação; a leitura completa fica para a primeira ação do usuário que precisa do catálogo.
- [x] Não iniciar pré-carregamento de URLs/faixas de áudio ao abrir a Home.
- [x] Não baixar capas de faixas que ainda não estão visíveis; capas são carregadas quando a seção/lista correspondente é aberta.
- [x] Retirar chamadas de ranking/estatísticas e pré-resolução de descritores de playback da abertura da Home.
- [x] Manter catálogo em cache local e consultas pesadas fora da thread principal.
- [x] Carregar cache completo ao abrir Busca/atalho que precise da biblioteca; para página de gênero, carregar o cache daquele gênero.
- [x] Manter listas apresentadas com limites e rolagem; não converter a Home em uma leitura/transferência de toda a biblioteca de mídia.
- [x] Deixar atualização de catálogo em **Manual** por padrão (intervalo `0`); os intervalos configuráveis só são considerados quando uma ação do usuário abre o catálogo e o período venceu.
- [x] Manter o botão **Atualizar** como ação explícita para sincronização do catálogo.

## 4. SONUS Stream — Home e navegação

- [x] Ordem da Home: **Linha do Tempo → SONUS Rádio → Acesso rápido → Gêneros**.
- [x] Preservar a Linha do Tempo e sua apresentação; não criar uma prateleira dinâmica de recomendações em seu lugar.
- [x] Preservar a aparência amarela dos cartões da SONUS Rádio.
- [x] Deixar nomes/cartões de estação leves na Home; programação, voz e reprodução são preparados após a escolha da estação.
- [x] Atualizar vozes da Rádio em `SonusRadioEngine.prepare()` quando a estação for escolhida, em vez de buscar locuções no início do aplicativo.
- [x] Acesso rápido na ordem: **Adicionadas recentemente, Artistas, Playlists, Últimas tocadas, Favoritas**.
- [x] Dar prioridade visual às músicas adicionadas recentemente para facilitar a localização de novas submissões.
- [x] Exibir gênero e disponibilidade no Stream na lista de adicionadas; incluir atalho para o painel existente de edição de letras e metadados.
- [x] Mostrar cards de gênero com cores/gradientes, tipografia e ícones; sem thumbnails remotos na Home.
- [x] Abrir o conteúdo de gênero sob demanda, com abas **Músicas, Artistas e Playlists**.
- [x] Deixar playlists de oração/descanso dentro do contexto de Playlists, sem prateleiras independentes na Home.
- [x] Manter mixes automáticos por gênero dentro da página de gênero.
- [x] Remover da Home as prateleiras promocionais/dinâmicas antigas (Descobertas, Para você hoje, Mix para você hoje, Novidades do seu estilo, Continue no seu gênero, Ouça novamente e Coleção SONUS).
- [x] Remover a antiga prateleira promocional **PULSE** e seu ciclo de prévias/rotação da Home; **não** remover o Pulse Player nem as ferramentas de áudio.
- [x] Manter a biblioteca offline e a reprodução de faixas já baixadas.

## 5. Barra superior, Busca, Analytics e Ajustes

- [x] Manter as quatro ações superiores: **Enviar música, Analytics, Busca e Ajustes**.
- [x] Redesenhar os quatro botões em cards compactos coordenados, com cantos arredondados, borda de destaque e ícone/legenda legíveis.
- [x] Preservar as ações originais: abrir Central do Artista, Analytics, expandir Busca e abrir Ajustes.
- [x] Mostrar o campo de Busca imediatamente abaixo da barra superior quando o ícone for tocado.
- [x] Não executar busca ao abrir o campo vazio; aplicar a busca local somente depois de o usuário digitar.
- [x] Incluir correspondências locais de músicas, artistas, playlists e gêneros.
- [x] Manter Analytics como recurso do Stream; não criar atualização contínua de dados para essa tela.
- [x] Preservar configurações de reprodução existentes: pré-carregar próxima faixa, fade in/out, crossfade, monitor de dados, rolagem LRC, preferências de histórico/recomendações e visibilidade padrão de playlists.
- [x] Adicionar controles para permitir/bloquear reprodução com dados móveis e opção de aviso na primeira reprodução móvel.
- [x] Limpeza de cache deve excluir somente capas: limpar disco e memória de artwork sem apagar histórico, playlists, favoritos ou metadados.
- [ ] Verificar em diferentes larguras/tamanhos de tela se a barra superior não corta legendas ou ações.

## 6. Catálogo, envio e gerenciamento de músicas

- [x] Preservar fluxo de envio existente e abertura da Central do Artista pelo botão superior.
- [x] Preservar upload individual e envio múltiplo, progresso/erro por faixa, opção OWNER de artista por faixa e regras Firebase existentes.
- [x] Preservar edição de metadados e letras TXT/LRC no painel de gerenciamento existente.
- [x] Preservar histórico, favoritos, playlists, downloads offline e IDs canônicos das faixas.
- [x] Preservar classificação e publicação de gêneros controladas pelo OWNER; a Home continua respeitando o estado publicado/oculto.
- [x] Preservar limite de estações automáticas por quantidade de faixas e montagem da fila de Rádio fora da thread principal.
- [x] Preservar o envio em MP3 192 kbps e a lógica de cópia de MP3 compatível quando aplicável.
- [x] Não alterar regras/serviços de backend nesta entrega; manter arquivos e configuração vindos da base CODE05.
- [ ] Conferir no Codemagic e em produção o fluxo de envio individual/múltiplo e sincronização de catálogo após aprovação.

## 7. Integridade, validação e aceite

- [x] Checklist interno CODE06 criado e incluído no pacote.
- [x] Relatório de release e changelog CODE06 criados.
- [x] Codemagic atualizado para procurar `versionCode = 6` e `versionName = "0.0.6"`.
- [x] Guardas do Codemagic atualizadas para verificar primeira cena/fallback da LIVE e ausência do antigo PULSE promocional.
- [x] Verificar que os arquivos protegidos continuam idênticos à base aprovada.
- [x] Validar estrutura/CRC do ZIP, sintaxe do YAML, `bash -n` dos scripts e JSONs do projeto.
- [ ] Rodar `assembleDebug`/build oficial no Codemagic com as variáveis seguras e chave permanente.
- [ ] Instalar o APK resultante e executar teste de regressão completo em aparelho real.

## Limites declarados

O checklist marca como concluídas as alterações de fonte/configuração integradas neste pacote. Testes que exigem Android SDK, Gradle, aparelho real, rede de produção ou credenciais Codemagic permanecem pendentes e não são declarados como aprovados.


## Correção complementar — download de álbuns (após primeira validação CODE06)

- [x] Identificar a falha do Codemagic: o workflow exigia `downloadCollection(list, "Álbum...`, mas a interface não tinha uma ação de álbum, embora o download individual e de playlists existissem.
- [x] Adicionar a seção **Álbuns do catálogo** dentro de Playlists, agrupando faixas pelo nome do álbum e artista.
- [x] Adicionar ação para baixar o álbum inteiro para a biblioteca offline.
- [x] Permitir remover o álbum da biblioteca offline pelo mesmo controle quando todas as faixas já estiverem baixadas.
- [x] Reutilizar o gerenciador offline e o progresso/estado já usados pelos downloads de playlists, sem duplicar o mecanismo de download.
- [x] Manter a validação Codemagic que verifica a existência real da ação de download de álbum.
- [ ] Executar o workflow CODE06 no Codemagic e confirmar build APK e testes no aparelho.

## Correção complementar — erros Kotlin na compilação CODE06

- [x] Corrigir a nulabilidade de `activeSlide` no loop de apresentação da LIVE sem alterar o comportamento de troca de cena.
- [x] Corrigir os quatro callbacks `onFavorite` que referenciavam `it` sem parâmetro, usando o `fileId` da faixa corrente.
- [x] Implementar `resolveStreamDurationMs` para obter a duração do stream por `MediaMetadataRetriever`, usar cache existente e salvar a duração resolvida.
- [x] Atualizar changelog e status técnico com as correções.
- [ ] Reexecutar `assembleDebug` no Codemagic e confirmar que não há novos erros de compilação.
- [ ] Instalar o APK gerado e executar os testes de regressão em aparelho real.

