# Pulse Studio 0.7.5 — code37

## Editor de vídeo — fechamento do checklist 0.7.x
- [x] Home do editor mantém navegação principal; projeto aberto entra em modo imersivo.
- [x] Swipe das abas principais bloqueado apenas durante projeto aberto.
- [x] Voltar salva rascunho e retorna à Home do editor.
- [x] Galeria própria Fotos/Vídeos via MediaStore, grade, seleção múltipla e ordem de seleção.
- [x] Fallback para Photo Picker do Android quando a permissão de galeria não é concedida.
- [x] Timeline visual separada de camadas de áudio.
- [x] Handles de trim/duração com área de toque ampliada e sensibilidade maior.
- [x] Duração de fotos: presets 1s–10m + entrada manual.
- [x] Texto: 75 presets de fonte por plano, paleta ampliada e 20+ animações de entrada/saída/loop.
- [x] Legendas manuais e automáticas locais integradas ao estilo de texto.
- [x] Overlay foto/vídeo/PNG com manipulação no preview.
- [x] 50+ efeitos e 50 filtros com favoritos e níveis de assinatura.
- [x] Ajustes individuais por parâmetro e reset.
- [x] Canvas renomeado para Proporção com presets sociais.
- [x] Visualizer com biblioteca ampliada e partículas reativas.
- [x] Exportação multiclipe real com fotos/vídeos + primeira camada de áudio via Media3 Composition/Transformer.
- [x] HDR preservado quando solicitado e tone-map SDR quando desativado.
- [x] H.264 universal e HEVC quando encoder disponível.
- [x] Arquivo original nunca é alterado.

## Observações de plataforma
Media3 exporta MP4 como caminho universal nesta implementação. Contêineres sem muxer confiável no aparelho são normalizados para MP4 em vez de gerar um arquivo inválido. A composição mantém a primeira trilha musical no export; múltiplas mixagens arbitrárias dependem das capacidades atuais do compositor/codec do Android.

## Validação local
- [ ] GitHub Actions `:app:compileDebugKotlin` / build APK — veredito final.
- [ ] Testar fotos múltiplas, vídeos, áudio, texto, legendas, visualizer e export no aparelho.
- [ ] Testar Android/Samsung/Motorola e MediaTek/Snapdragon/Exynos quando disponíveis.
