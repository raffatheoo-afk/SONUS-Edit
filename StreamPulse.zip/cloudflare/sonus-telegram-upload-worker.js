// SONUS Telegram Upload Worker — SONUS 1.0.2 / code105.
// Secrets necessários no Cloudflare:
// TELEGRAM_BOT_TOKEN
// TELEGRAM_CHAT_ID
// Nunca coloque os valores desses Secrets neste arquivo ou no APK.

const FIREBASE_PROJECT_ID = "streenpulse";
const MAX_AUDIO_BYTES = 45 * 1024 * 1024;
let jwksCache = null;
let jwksCacheUntil = 0;

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json; charset=UTF-8",
      "Cache-Control": "no-store",
    },
  });
}

function cleanText(value, max = 100) {
  return String(value || "").replace(/[\r\n\t]+/g, " ").trim().slice(0, max);
}

function decodeBase64Url(value) {
  let base64 = value.replace(/-/g, "+").replace(/_/g, "/");
  while (base64.length % 4) base64 += "=";
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

function decodeJwtJson(value) {
  return JSON.parse(new TextDecoder().decode(decodeBase64Url(value)));
}

async function getFirebaseJwks() {
  const now = Date.now();
  if (jwksCache && now < jwksCacheUntil) return jwksCache;
  const response = await fetch(
    "https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com"
  );
  if (!response.ok) throw new Error("Não foi possível carregar as chaves do Firebase.");
  const body = await response.json();
  jwksCache = body.keys || [];
  jwksCacheUntil = now + 6 * 60 * 60 * 1000;
  return jwksCache;
}

async function verifyFirebaseToken(request) {
  const authorization = request.headers.get("Authorization") || "";
  if (!authorization.startsWith("Bearer ")) throw new Error("AUTH_MISSING");
  const token = authorization.substring(7).trim();
  const parts = token.split(".");
  if (parts.length !== 3) throw new Error("AUTH_INVALID");
  const header = decodeJwtJson(parts[0]);
  const payload = decodeJwtJson(parts[1]);
  if (header.alg !== "RS256" || !header.kid) throw new Error("AUTH_INVALID");
  const now = Math.floor(Date.now() / 1000);
  if (payload.aud !== FIREBASE_PROJECT_ID) throw new Error("AUTH_INVALID_AUDIENCE");
  if (payload.iss !== `https://securetoken.google.com/${FIREBASE_PROJECT_ID}`) throw new Error("AUTH_INVALID_ISSUER");
  if (!payload.sub || payload.sub.length > 128) throw new Error("AUTH_INVALID_UID");
  if (!payload.exp || payload.exp <= now) throw new Error("AUTH_EXPIRED");
  if (!payload.iat || payload.iat > now + 300) throw new Error("AUTH_INVALID_TIME");
  const keys = await getFirebaseJwks();
  const jwk = keys.find((key) => key.kid === header.kid);
  if (!jwk) {
    jwksCache = null;
    jwksCacheUntil = 0;
    throw new Error("AUTH_KEY_NOT_FOUND");
  }
  const publicKey = await crypto.subtle.importKey(
    "jwk", jwk,
    { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
    false, ["verify"]
  );
  const signedData = new TextEncoder().encode(`${parts[0]}.${parts[1]}`);
  const signature = decodeBase64Url(parts[2]);
  const valid = await crypto.subtle.verify("RSASSA-PKCS1-v1_5", publicKey, signature, signedData);
  if (!valid) throw new Error("AUTH_INVALID_SIGNATURE");
  return payload;
}

async function sendLyrics(env, lyrics, submissionId, musicId, title, replyMessageId) {
  if (!(lyrics instanceof File) || lyrics.size === 0) return null;
  const name = lyrics.name.toLowerCase();
  if (!name.endsWith(".lrc") && !name.endsWith(".txt")) return null;
  const caption = [
    "📄 Letra SONUS",
    title ? `Música: ${title}` : null,
    musicId ? `Music ID: ${musicId}` : null,
    `Submission: ${submissionId}`,
  ].filter(Boolean).join("\n").slice(0, 950);

  // Uma segunda tentativa curta evita perder o LRC por uma falha transitória do Telegram.
  for (let attempt = 1; attempt <= 2; attempt++) {
    const form = new FormData();
    form.append("chat_id", env.TELEGRAM_CHAT_ID);
    form.append("document", lyrics, lyrics.name);
    form.append("caption", caption);
    if (replyMessageId) form.append("reply_parameters", JSON.stringify({ message_id: replyMessageId }));
    const response = await fetch(
      `https://api.telegram.org/bot${env.TELEGRAM_BOT_TOKEN}/sendDocument`,
      { method: "POST", body: form }
    );
    const result = await response.json();
    if (result?.ok || attempt === 2) return result;
  }
  return null;
}

export default {
  async fetch(request, env) {
    try {
      const url = new URL(request.url);
      if (request.method === "GET" && (url.pathname === "/" || url.pathname === "/health")) {
        return json({ ok: true, service: "SONUS Telegram Upload", status: "online" });
      }
      if (url.pathname === "/test") return json({ ok: false, error: "TEST_DISABLED" }, 404);
      if (request.method !== "POST" || url.pathname !== "/upload") {
        return json({ ok: false, error: "NOT_FOUND" }, 404);
      }

      let firebaseUser;
      try { firebaseUser = await verifyFirebaseToken(request); }
      catch (_) { return json({ ok: false, error: "UNAUTHORIZED" }, 401); }

      const contentType = request.headers.get("Content-Type") || "";
      if (!contentType.includes("multipart/form-data")) {
        return json({ ok: false, error: "INVALID_CONTENT_TYPE" }, 400);
      }

      const body = await request.formData();
      const audio = body.get("audio");
      const lyrics = body.get("lyrics");
      const title = cleanText(body.get("title"), 64);
      const artist = cleanText(body.get("artist"), 64);
      const genre = cleanText(body.get("genre"), 64);
      const submissionId = cleanText(body.get("submissionId"), 80);
      const musicId = cleanText(body.get("musicId"), 120).replace(/[^A-Za-z0-9_-]/g, "");
      const usesAi = String(body.get("usesAi") || "false").toLowerCase() === "true";

      if (!title || !artist || !submissionId) return json({ ok: false, error: "MISSING_FIELDS" }, 400);
      if (!(audio instanceof File) || audio.size === 0) return json({ ok: false, error: "AUDIO_MISSING" }, 400);
      if (audio.size > MAX_AUDIO_BYTES) return json({ ok: false, error: "AUDIO_TOO_LARGE", maxMb: 45 }, 413);
      const fileName = audio.name.toLowerCase();
      if (!fileName.endsWith(".mp3") && audio.type !== "audio/mpeg") {
        return json({ ok: false, error: "AUDIO_MUST_BE_MP3" }, 400);
      }

      const captionLines = [
        "🎵 NOVA MÚSICA — SONUS Stream", "",
        `🎤 Artista: ${artist}`,
        `🎶 Título: ${title}`,
        `🎼 Gênero: ${genre || "Não informado"}`,
        `🤖 IA: ${usesAi ? "Sim" : "Não"}`,
        `🆔 ID: ${musicId || submissionId}`,
        `🔗 Submission: ${submissionId}`,
      ];

      const telegramForm = new FormData();
      telegramForm.append("chat_id", env.TELEGRAM_CHAT_ID);
      // code105: o nome físico preserva o Music ID para o pCloud detectar a publicação
      // mesmo se o arquivo for baixado do Telegram e enviado manualmente ao catálogo.
      telegramForm.append("audio", audio, `${musicId || submissionId}.mp3`);
      telegramForm.append("title", title);
      telegramForm.append("performer", artist);
      telegramForm.append("caption", captionLines.join("\n").slice(0, 950));
      const telegramResponse = await fetch(
        `https://api.telegram.org/bot${env.TELEGRAM_BOT_TOKEN}/sendAudio`,
        { method: "POST", body: telegramForm }
      );
      const telegramResult = await telegramResponse.json();
      if (!telegramResult.ok) {
        console.error("Telegram sendAudio error:", telegramResult.description || "unknown");
        return json({
          ok: false,
          error: "TELEGRAM_UPLOAD_FAILED",
          telegram: telegramResult.description || "Erro desconhecido",
        }, 502);
      }

      const messageId = telegramResult.result?.message_id || null;
      let lyricsSent = false;
      if (lyrics instanceof File && lyrics.size > 0) {
        try {
          const lyricsResult = await sendLyrics(env, lyrics, submissionId, musicId, title, messageId);
          lyricsSent = Boolean(lyricsResult?.ok);
        } catch (error) {
          console.error("Lyrics upload failed:", error?.message || "unknown");
        }
      }

      return json({
        ok: true,
        status: "SENT",
        submissionId,
        musicId: musicId || null,
        telegramMessageId: messageId,
        lyricsSent,
        uid: firebaseUser.sub,
      });
    } catch (error) {
      console.error("SONUS Worker error:", error?.message || "unknown");
      return json({ ok: false, error: "INTERNAL_ERROR" }, 500);
    }
  },
};
