# SONUS 0.8.4 (code49)

- Splash refinada com entrada/saída mais suave.
- Ícone principal aproximado, sem círculo externo, com margem segura.
- Variantes de ícone redesenhadas com fundos mais legíveis e identidades especiais por plano.
- Novos temas Diamante: Liquid Glass, 3D, Camaleon e Paralaxe.
- Camaleon solicita CAMERA ao ser ativado e usa análise local dos frames para adaptar a paleta; a imagem não é exibida nem salva.
- Paralaxe usa sensores do aparelho e possui fallback estático quando sensor não existe.
- Removedor Vocal/Pulse Transcribe permanece fora das áreas públicas.
- applicationId preservado: com.sonusstudios.streampulse.
- Build deve ser confirmado pelo GitHub Actions; não validado localmente por ausência do Gradle Wrapper no checkpoint.
