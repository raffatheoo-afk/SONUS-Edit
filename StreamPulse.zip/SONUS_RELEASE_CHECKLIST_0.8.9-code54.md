# SONUS v0.8.9 • code54 — release candidate

Base: v0.8.8 code53 instalada/testada pelo usuário.

## Alterações implementadas neste candidato
- Crossfade do SONUS MUSIC refeito com promoção contínua do player de entrada e curva equal-power; listener da faixa antiga é desligado durante a transição para evitar reinício/dupla promoção.
- SONUS BOOST™ e SONUS SPATIAL™ liberados no player e conversor, sem feature-pass.
- Studio reordenado por nível de plano; Redes Sociais liberada; catálogo Free ampliado e Premium concentrado em ferramentas avançadas.
- Destaques redesenhados em grade de 2 cards por linha.
- Pulse Coins renomeado publicamente para SONUS COINS.
- Aviso offline deixa de permanecer fixo e se recolhe após ~3 s.
- Cache local do papel OWNER para preservar autoridade em perda de conexão e revalidar quando online.
- Botões de limpeza independente para estatísticas do SONUS MUSIC e métricas de Uso do app.
- Conversor recebe segunda tentativa defensiva sem filtros/metadados opcionais quando o primeiro encode falha.
- SONUS Visualizer recebe exportação MP4 real inicial via FFmpeg, respeitando 16:9/9:16/1:1 e mantendo áudio + waveform sincronizado.

## Auditoria estática executada
- versionName 0.8.9 / versionCode 54.
- applicationId preservado: com.sonusstudios.streampulse.
- contagem estrutural de delimitadores Kotlin sem divergências grosseiras.
- referências públicas de “Pulse Coins” removidas.
- editor de vídeo antigo e Pulse Transcribe não foram reintroduzidos na UI.

## Validação pendente
Este pacote NÃO é declarado compilado. A validação final continua sendo o GitHub Actions, conforme regra do projeto.
