# SONUS 0.8.2 code47
- Nome público: Sonus
- Nova identidade/logo oficial aplicada ao launcher e splash
- Splash ampliada para 3,6 s e logo integrado ao fundo
- Pulse Transcribe removido novamente dos Destaques
- Studio Sonus: ícones com identidade de cor e badges de plano
- Ícones principais de planos redesenhados a partir da identidade Sonus
- Editor de vídeo permanece removido
- applicationId preservado: com.sonusstudios.streampulse
- Visualizer permanece prioridade; sem exportação falsa
