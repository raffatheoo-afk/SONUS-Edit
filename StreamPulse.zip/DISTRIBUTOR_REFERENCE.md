# StreamPulse — referências de royalties e distribuidoras

## Regra de estimativa

A v1.3 Beta deixa de usar uma única referência SoundOn para todos os artistas.
A referência inicial passa a ser definida por **distribuidora + plano/modalidade**, usando o benchmark de mix global da pesquisa fornecida ao projeto e o percentual estimado mantido pelo artista.

Esses valores são referências de planejamento, não tarifas contratuais por reprodução. O valor real depende da plataforma, países dos ouvintes, tipo de assinatura, período de competência, impostos, splits, publishing, UGC e outras deduções.

### Benchmark bruto de referência

- Mix global de DSPs: R$17,812471908 / 1.000 streams
- Spotify: R$15,6707964 / 1.000
- Apple Music: R$32,39 / 1.000
- Amazon Music: R$45,97 / 1.000
- YouTube: R$25,07 / 1.000
- TIDAL: R$35,52 / 1.000

### Cenários iniciais

- SoundOn Lite: 90% → R$16,0312247172 / 1.000
- SoundOn Core: 100% → R$17,812471908 / 1.000
- Ditto Music: 100% → R$17,812471908 / 1.000
- DistroKid: 100% → R$17,812471908 / 1.000
- TuneCore áudio DSP: 100% → R$17,812471908 / 1.000
- FreshTunes áudio DSP: 100% estimado → R$17,812471908 / 1.000
- RouteNote Free: 85% → R$15,1406011218 / 1.000
- RouteNote Premium: 100% → R$17,812471908 / 1.000
- CD Baby: 91% → R$16,20934943628 / 1.000
- ONErpm página pública: 85% → R$15,1406011218 / 1.000
- ONErpm acordo de masters: 80% → R$14,2499775264 / 1.000
- UnitedMasters DEBUT+/SELECT: 100% → R$17,812471908 / 1.000
- Amuse ativa: 100% → R$17,812471908 / 1.000
- Amuse pós-cancelamento: 75% → R$13,359353931 / 1.000
- LANDR ativa: 100% → R$17,812471908 / 1.000
- LANDR pós-cancelamento: 85% → R$15,1406011218 / 1.000
- Symphonic Starter áudio DSP: 100% → R$17,812471908 / 1.000
- Too Lost padrão: 100% → R$17,812471908 / 1.000

## Aprendizado personalizado

O valor acima é apenas a referência inicial. Pagamentos reais cadastrados continuam calibrando o RPM do artista:

- 1 pagamento: 30% do peso vem do histórico pessoal
- 2: 50%
- 3: 65%
- 4: 80%
- 5+: 90%

Assim, artistas na mesma distribuidora podem convergir para estimativas diferentes.

## Taxas fixas

Anuidades, taxas por lançamento, saque ou serviços extras não são descontadas automaticamente do saldo do ciclo. Elas permanecem separadas porque não representam uma tarifa por stream.

Os CSVs originais usados na implementação estão em `reference/`.
