# SONUS / Sonus 0.8.3 — code48

- [x] applicationId com.sonusstudios.streampulse preservado
- [x] versionName 0.8.3 / versionCode 48
- [x] ícone principal reenquadrado com safe zone
- [x] splash animada sem imagem quadrada
- [x] selo de plano movido para canto superior direito dos cards do Studio
- [x] catálogo de ícones substituído pela identidade Sonus
- [x] Removedor Vocal oculto das áreas públicas
- [x] Pulse Transcribe oculto das áreas públicas
- [ ] compilação/instalação: confirmar via GitHub Actions e teste no aparelho
