# SONUS v0.8.29 — code74

## Fase Widgets + integração Android

- Catálogo amplo de widgets nativos SONUS com acabamento Preto, Branco, Transparente e Seguir Player.
- Widgets redimensionáveis em perfis compacto, médio e grande.
- Painel grande do Player configurável: capa, controles e estatísticas podem ser ligados/desligados pelo usuário.
- Widgets FREE e PRO herdam a regra comercial da função representada.
- Itens PRO abrem o mesmo gate global de escolha de plano do aplicativo.
- Player: controles puros, capa + controles, player completo, visualizer, painel combinado e estatísticas.
- Estatísticas: total, 7 dias, mês atual, gráfico de 7 dias, hábitos e mais ouvidas.
- Equalizador: estado completo do EQ é PRO por expor EQ Automático; Bass Boost também é PRO.
- Destaques: ações rápidas, conversões, mescladores, último resultado e processamento.
- Conversões rápidas é PRO porque inclui o conversor de imagens, que é Premium.
- Studio SONUS: atalhos, recente e fila/processamento.
- Distribuição & Pagamentos PRO: Pulso, saldo, metas por artista, metas de todos os artistas,
  previsões, histórico, artista, financeiro, pagamentos, mercados, faixa em destaque,
  top artistas e painel executivo.
- Dados inexistentes (mercados/faixa) nunca são inventados: o widget informa que aguarda uma fonte real.

## Player reconhecido pelo Android

- MediaSession com controles de transporte e SessionActivity.
- Audio focus de música, pausa em perda de foco e retomada em perda transitória.
- Metadata de título, artista, álbum, gênero, duração e arte/capa incorporada.
- Notificação de mídia com capa, MediaStyle e controles.
- Bluetooth/fones, lockscreen e carrossel de mídia ligados à mesma sessão.
- Widgets do Player usam a mesma sessão/serviço de reprodução.

## Dynamic Island SONUS

- Capa menor, com clip arredondado e margem interna para não vazar das quinas.
- Barra de progresso mais legível e com cor dinâmica.
- Mini visualizer estilizado enquanto a música estiver tocando.
- Marquee discreto para títulos longos.
- Estado sincronizado com o Player.

## Nova abertura

- SONUS revelado em escrita cursiva suave, sem letras pulando.
- Último traço evolui para onda sonora com degradê.
- Pulso central e frase “Sua música. Seu som.” antes da entrada no app.
- Duração curta, aproximadamente 2,5 segundos.

## Versão

- versionCode: 74
- versionName: 0.8.29
