# SONUS 0.9.6 / code102

- [x] versionCode 102 / versionName 0.9.6
- [x] Worker Telegram configurado como destino de submissão
- [x] Firebase auth token enviado no upload
- [x] MP3 160 kbps + capa/tag preservados
- [x] LRC/TXT opcional
- [x] progresso visível e mensagens de sucesso/falha
- [x] topo SONUS Stream compacto
- [x] ícones quadrados com cores independentes do tema
- [x] Analytics separado de Ajustes
- [x] regras 20 s / 8 min preservadas
- [x] ajustes funcionais code101 preservados
- [ ] build Android real confirmado no CodeMagic
