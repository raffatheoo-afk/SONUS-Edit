# SONUS 0.0.5 / CODE 05 — Relatório técnico de fechamento do pacote-fonte

## Identidade preservada

- `versionName`: `0.0.5`
- `versionCode`: `5`
- `applicationId`: `com.sonusstudios.streampulse`
- Identidade pública de release mantida em 0.0.5 / CODE 05. Marcadores internos encontrados em componentes mais recentes não alteram a versão Android distribuída.
- Três fontes pCloud, seus identificadores, player, fluxo de áudio e assinatura permanente foram preservados.

## Alterações integradas

### LIVE

1. Contagem regressiva padrão e mínima de 10 segundos, com opções 10/15/20/30.
2. A preparação seleciona cinco imagens, faz download e decodifica antes de habilitar a entrada no ar. A primeira sequência é armazenada como `LiveSlide` e entregue ao palco sem refazer a seleção.
3. A reposição da sequência é assíncrona. Quando não há uma cena seguinte pronta, a cena atual permanece, em vez de iniciar download no caminho de troca.
4. A classificação da mídia usa `Dispatchers.Default`; download, cache e decodificação ficam em `Dispatchers.IO`. A preparação inicial limita a concorrência a três tarefas.
5. Transições de fade/deslocamento/escala mantidas; vídeos permanecem mudos e avançam no fim/erro do player.
6. O estado `ON_AIR` só é assumido quando `svc.state` confirma reprodução e faixa atual. Em timeout, a tela volta à configuração.
7. Painel central e texto gigante de letra removidos. Promoção inferior compacta alterna SONUS / SONUS Edit e exibe Telegram `@sonusappupdate` sem cobrir a cena com cartão central.

### SONUS Stream

1. Buscas, filtros, rankings, playlists, álbuns, recomendações e agrupamentos grandes foram movidos para `Dispatchers.Default`/`produceState`.
2. A montagem de filas e programação automática de Rádio sai do caminho síncrono da interface; uma proteção bloqueia acionamento repetido durante a preparação.
3. Leitura de catálogo, cache e capas segue em `Dispatchers.IO`; a consulta de perfis de artista não se repete a cada mudança de lista de envios.
4. Formulário de envio convertido para uma janela ampla responsiva, mantendo o envio individual.
5. Implementado envio real de múltiplos áudios por `OpenMultipleDocuments`, com título editável por faixa, status/erro separado, progresso de lote e recuperação por reenvio das faixas não aceitas. Capa e gênero são compartilhados no lote; OWNER escolhe o artista por faixa; letras continuam no modo individual.
6. OWNER pode escolher um perfil artístico público no envio individual e, no lote, em cada faixa separadamente. O backend recupera o perfil selecionado e persiste `artistId` e `artistOwnerUid`; o UID de quem enviou permanece separado.
7. Regras Firebase exigem os dois campos de vínculo ou nenhum em registros legados. Quando fornecidos, validam tipo, dono do perfil público, nome e papel OWNER ativo para vincular artista de outra conta.
8. Cartão duplicado do perfil foi removido do corpo. O avatar circular com lápis no cabeçalho abre a edição do avatar/nome e informa a próxima data de alteração.
9. Verde e vermelho permanecem vivos em estado não selecionado; o estado selecionado agora usa preenchimento/contorno ainda mais intenso.

### Versão, catálogo e integridade

- Mantidos os 18 gêneros centrais, aliases históricos e regra de estações automáticas acima de 15 faixas.
- Mantido MP3 192 kbps e o caminho de cópia para MP3 compatível quando permitido pelos critérios técnicos do conversor.
- O changelog e a seção Sobre foram atualizados para descrever os recursos integrados nesta versão.
- `codemagic.yaml` mantém o fluxo de assinatura oficial, checksums dos arquivos críticos e guardas estáticas dos novos comportamentos. A etapa de localização do projeto aceita `StreamPulse.zip`, checkout na raiz ou pasta `sonus_work`.
- O checksum protegido de `SonusStreamPlatform.kt` foi atualizado para o código revisado; os checksums de áudio e player permanecem iguais aos da base protegida.

## Correção aplicada após falha no Codemagic

O primeiro `assembleDebug` chegou à tarefa `:app:compileDebugKotlin` e falhou somente em dois símbolos usados pela promoção inferior da LIVE: `Icons.Default.Download` (linha 919) e `Icons.Default.Send` (linha 923) em `SonusLiveStudio.kt`. Os imports dessas duas classes não estavam presentes.

Correção aplicada no código-fonte:
- Adicionados `import androidx.compose.material.icons.filled.Download` e `import androidx.compose.material.icons.filled.Send`.
- Confirmado que `androidx.compose.material:material-icons-extended` já é dependência do app; nenhuma biblioteca ou versão adicional foi introduzida.
- Adicionadas verificações ao `codemagic.yaml` para conferir a dependência e os dois imports antes da compilação, evitando que a mesma omissão passe pela checagem estática.
- Sincronizada a cópia do YAML que acompanha o projeto dentro do ZIP.

As mensagens `Unable to strip ... libraries` do log são avisos do empacotamento de bibliotecas nativas; não são a causa da falha mostrada. O erro fatal foi a resolução dos dois nomes Kotlin. **A correção está aplicada, mas precisa de uma nova execução do Codemagic para confirmar que a compilação completa passou.**

## Verificações estáticas executadas

- Parser sintático Kotlin (PSI) nos quatro arquivos Kotlin grandes alterados nesta revisão: `SonusLiveMedia.kt`, `SonusLiveStudio.kt`, `SonusOnlineMusic.kt` e `SonusStreamPlatform.kt`.
- Após o log real do Codemagic, conferidos os usos/imports de `Download` e `Send` e adicionadas guardas de pré-build para ambos no YAML.
- Parse do YAML e validação `bash -n` dos scripts de cada etapa do workflow.
- Parse JSON dos dois arquivos de regras Firebase e comparação byte a byte das cópias espelhadas.
- Conferência de identidade de versão, checksums protegidos, checksums do ZIP e `unzip -t`.
- Conferência de que `firebase.json` aponta para `firebase-database-rules.json`.

## Limitações que permanecem explícitas

- Este ambiente não tem Gradle instalado, Gradle Wrapper no projeto nem Android SDK. Portanto, não foi possível compilar o APK aqui. O YAML prepara Gradle 8.13 e Android SDK 36 no Codemagic, executa `assembleDebug` e verifica assinatura com o certificado permanente. O APK só estará comprovado depois de uma execução bem-sucedida desse workflow com as variáveis seguras configuradas.
- O parser Kotlin é uma verificação de sintaxe, não substitui a compilação completa com as dependências Android/Compose/Media3/Firebase.
- ANR, tempo até a primeira imagem, FPS, memória, estabilidade de upload em rede real, tentativas de fraude via Firebase, Bluetooth e monitoramento de áudio precisam ser validados no aparelho/ambiente de teste.
- O modo de lote aplica uma capa e um gênero a todo o lote e não inclui letras/LRC independentes por arquivo; use o envio individual para anexar letra.
- Nenhuma limpeza ampla de recursos/assets foi feita sem prova de código morto, porque recursos Android podem ser referenciados por XML, reflection ou nomes dinâmicos.

## Resultado

**Pacote-fonte 0.0.5 / CODE 05 e configuração Codemagic atualizados após corrigir os dois imports identificados no primeiro build.** Ainda não é correto afirmar que o novo APK compilou: é necessária outra execução do workflow para comprovar. A etapa restante para distribuição é executar o workflow oficial e os testes de aceitação em dispositivo com as credenciais seguras originais.
