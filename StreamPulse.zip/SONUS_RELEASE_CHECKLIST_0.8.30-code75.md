# SONUS v0.8.30 — code75

- Splash redesenhada: símbolo desenhado à mão, nome `Sonus`, animação suave, onda e slogan.
- Splash simplificada para reduzir risco de crash e com fallback de fonte cursiva.
- Conversor de áudio: MP3 restringe automaticamente sample rate a 44,1/48 kHz e reamostra entradas Hi-Res.
- Conversor: fallback de encoder e mensagens de erro mais amigáveis.
- Feedback visual de processos: falha em vermelho, sucesso em verde, conteúdo dividido em linhas.
- Preserva originais e não altera ferramentas estáveis fora do escopo.
