# SONUS 0.0.6 — CODE 06

## Stream mais leve e navegação reorganizada

- Home reorganizada na ordem Linha do Tempo, SONUS Rádio, Acesso rápido e Gêneros.
- Quatro ações superiores redesenhadas: Enviar música, Analytics, Busca e Ajustes.
- Busca expandida sob a barra superior e com resultados locais de músicas, artistas, playlists e gêneros.
- Atalhos organizados por Adicionadas recentemente, Artistas, Playlists, Últimas tocadas e Favoritas.
- Gêneros apresentados em cards gráficos sem baixar capas remotas na Home; conteúdo específico é carregado ao abrir o gênero.
- Removidas as prateleiras antigas de descoberta/recomendação e a prateleira promocional PULSE da Home. O Pulse Player e as ferramentas de áudio permanecem.
- Catálogo, capas e locuções da Rádio deixam de ser preparados no início global do aplicativo; o acesso à biblioteca e à estação ocorre sob demanda.
- Atualização do catálogo em modo Manual por padrão, sem polling ao abrir a Home; intervalos escolhidos são verificados apenas em ações que pedem o catálogo.
- Ajustes adicionados para reprodução com dados móveis e aviso de consumo.
- Limpeza de capas passa a limpar o cache do disco e a memória de imagens, preservando histórico, playlists, favoritos e metadados.
- Adicionada a seção **Álbuns do catálogo** dentro de Playlists, agrupando faixas por álbum e artista; cada álbum pode ser baixado/removido em lote para a biblioteca offline, com progresso compartilhado.

## LIVE mais resiliente

- Início da LIVE não depende mais de cinco imagens prontas.
- Uma primeira cena é preparada com timeout de 14 segundos; o palco pode usar o fundo SONUS como fallback e preencher até cinco cenas em segundo plano.
- A cena atual permanece enquanto uma próxima cena não estiver pronta; vídeos continuam até o fim original e sem áudio.
- A contagem regressiva 10/15/20/30 segundos, confirmação real de áudio antes de entrar no ar, ajustes de microfone e controles do palco foram preservados.
- Removida a atualização repetitiva do catálogo durante a configuração da LIVE.

## Correções de compilação — segunda validação CODE06

- Corrigida a leitura da cena ativa da LIVE usando uma referência local não nula durante o loop de apresentação.
- Corrigidos os callbacks de favorito nas listas Adicionadas, Últimas tocadas, Favoritas e faixas por gênero; cada callback agora usa explicitamente o `fileId` da faixa da linha.
- Implementada a resolução da duração de streams no Social Edit, com leitura via `MediaMetadataRetriever`, reaproveitamento do cache local e persistência da duração encontrada.

## Compatibilidade preservada

- `applicationId`: `com.sonusstudios.streampulse`.
- Player, PulsePlayerService, AudioToolEngine, ferramentas DSP, equalizador e plataforma/backend de envios permanecem inalterados.
- Envio individual/múltiplo, perfis artísticos OWNER, letras, regras Firebase, MP3 192 kbps, Rádio, Timeline e biblioteca offline permanecem no projeto.
- `versionName = 0.0.6`; `versionCode = 6`.

## Verificação

O pacote recebeu validações estáticas (estrutura do ZIP, YAML, scripts e JSONs, além da comparação dos arquivos protegidos). A compilação completa do APK e os testes em aparelho permanecem pendentes de execução no Codemagic e em dispositivo Android.
