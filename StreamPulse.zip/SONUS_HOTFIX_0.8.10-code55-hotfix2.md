# SONUS 0.8.10 code55 hotfix2

Correção do erro de compilação reportado pelo GitHub Actions em `PulsePlayerStatsStore.kt`.

- Corrigido o uso de `LocalDate?` no loop de agregação de horas por período.
- O intervalo agora é materializado em `rangeStart`/`rangeEnd` não-nulos antes do loop.
- Mantidos versionName 0.8.10 e versionCode 55 por se tratar de hotfix de compilação da mesma versão.
- Nenhuma alteração de applicationId, Firebase ou compatibilidade de atualização.
