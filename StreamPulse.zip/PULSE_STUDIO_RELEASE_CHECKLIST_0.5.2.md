# Pulse Studio 0.5.2 — checklist técnico
- [x] versionName 0.5.2 / versionCode 29
- [x] applicationId preservado
- [x] hotfix @Composable/LaunchedEffect aplicado
- [x] splash decorativa reduzida para ~2 segundos
- [x] textos brancos na abertura
- [x] visualizador ampliado e reamostrado por toda a largura
- [x] ganho/movimento mínimo reforçado
- [x] visualizadores radiais ampliados
- [x] capa do Player ampliada
- [x] configurações do visualizador refinadas
- [x] monitor de dados contextual na função YouTube
- [x] Firebase Rules sem alterações
- [ ] validação final de compilação: GitHub Actions

Observação: a camada visual global FREE/Assistir anúncio deve continuar usando a infraestrutura Rewarded já existente; a ativação/UX definitiva de monetização fica condicionada à configuração real dos anúncios.
