# SONUS 0.8.22 • code67 — checklist de release

## Player
- [x] SONUS Classic permanece FREE e sem anúncios.
- [x] Pure = Bronze; Flow = Prata; Orbit = Ouro.
- [x] Diamante = Vinyl Glow, Arc Light, Neon Disc, Cassette Retro e Turntable Classic.
- [x] Temas permanecem compatíveis com todas as interfaces.
- [x] YouTube permanece disponível em todas as interfaces.
- [x] Anterior/Próxima com contraste explícito.

## Visualização
- [x] Interface específica usa barras/waveform/VU/disco em vez de um Spectro visual único obrigatório.
- [x] PCM Media3 preservado como fonte universal.
- [x] Pause zera visualização; animações de mídia param.
- [x] Intensidade 50–200%, sensibilidade e suavidade configuráveis.
- [x] Interpolação por frame para movimento macio.
- [x] Cassette: carretéis + VU Meter.
- [x] Turntable: prato + braço.

## Persistência e biblioteca
- [x] Aleatório persistente.
- [x] Repetição persistente.
- [x] Última música e posição persistentes sem autoplay indevido.
- [x] Biblioteca: Reproduzir / Aleatório.
- [x] Interface, tema, visualização, intensidade, sensibilidade, suavidade, crossfade e velocidade persistentes.

## Fila / extras
- [x] Reorganizar, remover, Tocar a seguir e Limpar fila.
- [x] Sleep Timer 15/30/60 min.
- [x] Parar ao fim da música.
- [x] Manter tela ligada enquanto Player estiver aberto.
- [x] MediaSession/Bluetooth/fones preservados.

## Preservação
- [x] Qualidade de áudio preservada.
- [x] Crossfade preservado.
- [x] SONUS BOOST/SPATIAL continuam removidos.
- [x] AdMob Rewarded preservado.
- [x] Vídeo → Áudio, Gravador, Login/Convidado, Premium e Dynamic Island preservados.

## Empacotamento
- [x] versionName 0.8.22.
- [x] versionCode 67.
- [x] CHANGELOG/README/Sobre o SONUS atualizados.
- [ ] GitHub Actions: validação final de compilação Android após upload.
