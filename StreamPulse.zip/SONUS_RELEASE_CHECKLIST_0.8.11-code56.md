# SONUS v0.8.11 • code56

Dynamic Island SONUS 2.0.

- applicationId preservado: com.sonusstudios.streampulse
- crossfade/player existente preservado
- acesso offline/Premium existente não alterado
- portrait only; landscape oculta a ilha
- painel próprio nos Ajustes
- tamanho 48–130%, transparência 35–100%
- posição X/Y, esquerda/centro/direita e Fixar posição
- câmera esquerda/centro/direita; vão central no modo expandido
- Standard/Glow/Glass + presets; Dinâmico usa cor contextual
- expandida → ~4s → compacta; ociosa → oculta
- player: capa, play/pause e progresso real posição/duração
- tarefa: percentual e barra; conclusão 100% por ~4s
- notificação do serviço recebe o mesmo percentual publicado pela tarefa
- conversor e Visualizer preservam publicação de progresso; Master/AutoMix integrados ao ciclo da ilha
- compilação final deve ser confirmada pelo GitHub Actions; o projeto não possui Gradle Wrapper local
