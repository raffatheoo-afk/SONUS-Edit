# SONUS 0.8.19 • code64

## Checklist consolidado dos 15 pontos

- [x] 1. Spectro mantém o visual atual e usa Native com detecção real de energia/variação, migrando automaticamente para PCM Compat/Fallback quando necessário.
- [x] 2. PCM Compat é progressivo, cancelável, fora da UI, sem análise integral automática e com cache limitado; falhas do Spectro não param a música.
- [x] 3. StreamMetricsEngine unifica o ciclo para Saldo, Pulso, Histórico, Análises, Financeiro, insights e projeções desde o primeiro registro em Total do período ou Valor do dia.
- [x] 4. Estimativa financeira positiva mínima exibida: R$ 0,02. Zero streams continua em R$ 0,00.
- [x] 5. Pulso ao Vivo calcula ritmo/projeção desde o primeiro registro e melhora conforme entram novas observações.
- [x] 6. Estado “calibrando” removido; Pulso mostra apenas Precisão com ponto vermelho/amarelo/verde conforme a confiança.
- [x] 7. Atraso de dados (0–14 dias) define a data real atribuída ao dado para todas as distribuidoras, inclusive atribuindo ao ciclo correto quando a data atrasada cruza a virada de ciclo.
- [x] 8. Campo mostra a data exata: “Total acumulado • data” ou “Streams do dia • data”, atualizada ao mover o slider.
- [x] 9. Registro retroativo separado, com DatePicker entre início do ciclo e ontem, aviso de substituição e sem vínculo com o slider de atraso.
- [x] 10. Foto individual por artista pela galeria, com compressão/redimensionamento e fallback SONUS.
- [x] 11. Seletor de identidade oferece Galeria ou Avatar SONUS com prévia e Aplicar.
- [x] 12. Catálogo inicial com 60 avatares 2D vetoriais: 10 instrumentos, 10 flores, 10 animais, 10 personagens originais e 20 Cosmos.
- [x] 13. Acesso por plano: FREE 10, Bronze 20, Prata 30, Ouro 40, Diamante 60; bloqueados ficam visíveis e troca não usa franquia mensal.
- [x] 14. Player visual, Vídeo → Áudio, Gravador, qualidade de áudio, Dynamic Island, login/convidado e preços Premium preservados.
- [x] 15. VersionName 0.8.19 / versionCode 64, Sobre o SONUS e CHANGELOG atualizados; pacote deve manter raiz StreamPulse/.

## Validação local possível neste ambiente
- [x] Teste puro do StreamMetricsEngine: primeiro registro diário, primeiro total acumulado, combinação e confiança.
- [x] Teste puro do RoyaltyEngine: piso de R$ 0,02 e forecast desde o primeiro registro.
- [x] Balanceamento léxico de chaves/parênteses/strings nos arquivos Kotlin alterados.
- [x] Conferência do catálogo: 60 avatares e hierarquia de planos.
- [x] Conferência de chamadas antigas: removido o uso residual da série HealthEngine.analyticsDailyEntries em Histórico/Análises/Financeiro/insights/relatório.
- [x] Última atualização considera tanto registros acumulados quanto registros diários.
- [ ] Compilação Android final: GitHub Actions (não há Gradle Wrapper/Android SDK local neste ambiente).
