# Pulse Studio 0.7.0 — code 32

## Entrega principal
- [x] versionName 0.7.0 / versionCode 32
- [x] Aba Vídeo deixa de ser placeholder e abre o Pulse Video Editor.
- [x] Novo projeto/importação via Storage Access Framework.
- [x] Preview local, play/pause, seek e timecode.
- [x] Timeline inicial não destrutiva com IN/OUT e split em metadados.
- [x] Barra priorizada: Editar, Áudio, Texto, Velocidade, Legendas, Overlay, Efeitos, Filtros, Ajustar, Canvas, Visualizer.
- [x] Texto overlay básico no preview.
- [x] Export P0 MP4 por stream-copy para trim compatível, salvo em Movies/Pulse Studio.

## Áudio Visualizer
- [x] Visualizador circular no editor.
- [x] Análise local do áudio independente de android.media.audiofx.Visualizer.
- [x] BPM estimado local.
- [x] Intensidade ajustável.
- [x] Partículas reativas ajustáveis.
- [x] Mistura neon ciano/violeta.
- [x] Logo/capa central importável.
- [x] Fundo em imagem importável.

## Compatibilidade do espectro do Player
- [x] Visualizer nativo continua sendo o caminho prioritário quando retorna dados válidos.
- [x] Novo fallback por análise PCM local do arquivo atual.
- [x] Fallback acompanha a posição real do player e não depende do firmware do AudioFX Visualizer.
- [x] Troca automática quando o Visualizer nativo fica sem dados por ~700 ms.

## Arquitetura preparada para 0.7.x
- [x] Editor separado em módulo `video`.
- [x] Projeto/preview/export desacopláveis para evolução.
- [x] Painéis já reservados para áudio, velocidade, legendas, overlay, efeitos, filtros, ajustes e canvas.
- [ ] Undo/redo completo por command pattern — próxima iteração 0.7.x.
- [ ] Timeline multicamada persistente — próxima iteração 0.7.x.
- [ ] Keyframes, máscaras, chroma key, HSL/LUT e transições avançadas — próximas iterações 0.7.x.
- [ ] Auto captions offline/IA local pesada — fase posterior, conforme blueprint.

## Preservação
- [x] applicationId preservado.
- [x] Firebase Rules preservadas sem alteração.
- [x] Recursos 0.6.1 preservados.

## Validação local
- [x] Estrutura do pacote validada com `unzip -t` após empacotamento.
- [ ] Compilação final depende do GitHub Actions.
