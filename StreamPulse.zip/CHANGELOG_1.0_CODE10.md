# SONUS 1.0 — CODE10

## Identidade
- `versionName`: `1.0`
- `versionCode`: `10`
- `applicationId`: `com.sonusstudios.streampulse`
- Base de origem: SONUS 0.0.9 — CODE09.
- Assinatura permanente: keystore `sonus-edit-dev.jks`, alias `sonusedit`, validada pelo workflow Codemagic.

## Player
- Faixa fixa de letras no espaço central do TopAppBar, substituindo o título SONUS PLAYER, com até duas linhas; a faixa não reduz a área do player e não fica sobre a capa/controles.
- Biblioteca permanece disponível nos controles inferiores do player; o título SONUS PLAYER e o botão Biblioteca do cabeçalho não ocupam mais o topo.
- Download offline em botão circular verde entre SONUS EDIT LITE e LIVE, preservando baixar/remover.
- Dez interfaces visuais adicionais: Aurora, Sonus Vibe, Pulse, Spectra, Neon Wave, Deep Blue, Prism, Verde Vivo, Ouro e Maré.
- Arc Light removido da seleção.
- Selo Auto Volume vermelho e pulsante junto ao contador de reproduções quando ativo.

## Equalizador e DSP
- Catálogo central de 43 presets públicos de 10 bandas.
- Quatro curvas antigas do painel compartilhado mantidas internamente para migração de preferências; não são exibidas como presets adicionais.
- Os sete presets legados do player permanecem com os valores originais.
- Volume Extra no player, painel compartilhado, Conversor PRO e configurações de equalização de vídeo; ganho em tempo real via LoudnessEnhancer e processamento de exportação via FFmpeg.
- Manutenção R1: removido o seletor de layouts TEMAS do equalizador por duplicar visualmente a função CORES; mantida uma única estrutura compacta e o seletor CORES para paletas.
- Bass Boost permanece separado do Volume Extra.
- EQ Auto combina gênero/metadados com análise espectral local por faixa e cache da curva calculada.

## SONUS SMART EQ
- Regras de gênero ordenadas do mais específico ao mais geral para reduzir colisões de substring.
- Fallback sem gênero confiável usa Neutro; removida a escolha baseada em hash de título/artista.
- A análise de faixa aproveita o LocalSpectrumAnalyzer existente e produz correções tímbricas moderadas.
- Não foi embarcado modelo Essentia/MTG-Jamendo, por exigir confirmação de licença comercial.

## SONUS AUTO VOLUME
- Dezenove perfis oficiais fixos e um modo Personalizado.
- Pedestre / Rua com teto de 60% do ganho interno e comportamento de redução diante de eventos/ruído externo.
- Modo Sono com redução de cinco pontos percentuais a cada dez minutos.
- Classificador acústico local YAMNet previsto no build, com modelo baixado e validado por SHA-256 durante a preparação do Codemagic.
- Microfone somente sob permissão; processamento local, sem gravação ou envio de áudio.
- O Auto Volume controla o ganho interno do player e não altera o volume global de outros aplicativos.

## Observações
- As imagens dos pacotes de referência não foram incorporadas ao APK; os visuais são construídos com Compose/Canvas e componentes nativos.
- Este changelog descreve as alterações no código-fonte candidato. A compilação Android, instalação por cima da CODE09 e testes em aparelho precisam ser concluídos no Codemagic/dispositivo real antes de declarar a release validada.

## Correção do erro de compilação do Gradle Kotlin DSL
- Adicionados imports explícitos para `InputStream`, `URL`, `URLConnection` e `MessageDigest` no `app/build.gradle.kts`.
- Removidas referências qualificadas `java.net` / `java.security` que eram resolvidas incorretamente pelo Kotlin DSL como extensão do projeto.
- Tipagem explícita do fluxo de entrada e conversão segura dos bytes SHA-256 para hexadecimal.
- A lógica de download e validação do modelo, a chave permanente e o workflow Codemagic foram preservados.
- A correção do script foi empacotada; a compilação Android CODE10 ainda precisa ser executada no Codemagic para verificar eventuais erros Kotlin posteriores.


## Manutenção corretiva R1 — Player e Equalizador (sem alterar versão)
- Mantidos `versionName = "1.0"` e `versionCode = 10`; nenhuma nova versão foi criada.
- Player: removido o recuo superior interno de 50 dp que reduzia/achatava o player; conteúdo voltou a ocupar a área original, conforme a estrutura da CODE09.
- Player: a faixa de letras foi colocada no slot central do `CenterAlignedTopAppBar`, substituindo o título; faixa compacta de 42 dp, até duas linhas e com truncamento interno.
- Player: removida a faixa de letras que ficava sobre o conteúdo do player; preservados capa, transporte, ações inferiores Biblioteca/Equalizador e demais controles.
- Player: preservado o botão circular de download entre SONUS EDIT LITE e LIVE.
- Equalizador: removidos seletor TEMAS/layouts e bloco decorativo associado; CORES permanece como único seletor visual.
- Equalizador: removido o card grande “Equalizador SONUS”; Bass Boost e Liga/Desliga ficam lado a lado no topo, em controles compactos.
- Equalizador: gráfico CURVA EQ reduzido para 66 dp, preservando as dez bandas, curva e rótulos.
- Equalizador: removido cabeçalho AJUSTE FINO duplicado. Presets, EQ Auto, Grave/Médio/Agudo e Volume Extra foram preservados.


## Manutenção corretiva R2 — Validador Codemagic
- Corrigida a validação estática que ainda exigia o layout `SONUS ONDA AZUL`, removido por decisão do usuário na R1.
- O workflow agora valida o equalizador compacto e verifica a presença de CURVA EQ, CORES, Bass Boost e Liga/Desliga, além de impedir o retorno do antigo seletor TEMAS e do card grande.
- Nenhuma alteração de funcionalidade de áudio ou incremento de versão.
- `versionName = "1.0"` e `versionCode = 10` permanecem inalterados.
