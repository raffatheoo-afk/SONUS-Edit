# SONUS — Manutenção corretiva 0.0.3 / code 03

Esta manutenção mantém a versão **0.0.3** e o **versionCode 3**. O objetivo foi corrigir os pontos relatados sem alterar a identidade da versão nem remover os recursos existentes.

## Alterações realizadas

### Player
- O botão grande de download abaixo dos controles foi removido.
- Para músicas do SONUS Stream, o download ocupa o espaço do botão de fixar, com ícone verde menor e discreto.
- O ícone apresenta progresso durante o download e indica quando a música já está salva.
- O botão de fixar continua disponível para as músicas locais.

### Aplicativos SONUS
- A ordem ficou: **IMAGENS → ÁUDIO → VÍDEOS → OUTROS**.
- Caixa Preta SONUS, Editor LRC e Leitor/Editor de PDF ficam em **OUTROS**.
- Conversão, edição e organização de vídeos ficam em **VÍDEOS**.
- As ações de abertura das ferramentas foram preservadas.

### SONUS Stream
- As três coleções aparecem separadamente como **MÚSICAS**, **MÚSICAS 2** e **MÚSICAS 3**, cada uma com seu próprio interruptor no painel do desenvolvedor.
- A leitura percorre também as subpastas e mantém os nomes de estilo encontrados nos arquivos/pastas.
- Os identificadores das três fontes continuam separados para que uma faixa de uma fonte não seja confundida com outra.
- Quando MÚSICAS e MÚSICAS 2 já estão publicadas, a terceira coleção é incluída automaticamente na publicação após ser encontrada. Se a gravação dessa alteração não for confirmada, o painel informa que o interruptor deve ser ativado manualmente.

### Compartilhamento
- O aplicativo monta a rota HTTPS de compartilhamento de forma consistente, inclusive quando o endereço-base já termina com `sonusShare`.
- O Codemagic deixou de depender da opção `SONUS_DEPLOY_SHARE_FUNCTION=true`: com a credencial segura do Firebase disponível, o build tenta publicar a função `sonusShare` automaticamente.
- **A função não foi publicada a partir deste ambiente.** Para que os links deixem de retornar página inexistente, configure `FIREBASE_SERVICE_ACCOUNT_JSON_B64` como variável segura no Codemagic, com uma conta autorizada a publicar a função, e execute o workflow. Sem essa variável, o log avisa que a função não foi publicada; o APK pode continuar o build, mas o link ainda não estará ativo.

### Telegram e informações da versão
- Configurações agora mostram **ATUALIZAÇÃO SONUS**, que abre `https://t.me/sonusappupdate`.
- Cada plano pago tem a opção **Comprar pelo Telegram**, apontando para `https://t.me/sonuspremiumofc`.
- A mensagem é preparada com o plano, valores mensal/anual disponíveis, versão do app e ID da conta quando há uma conta autenticada. O usuário ainda precisa confirmar e enviar a mensagem no Telegram; o app não envia mensagens automaticamente.
- O texto de **Sobre o SONUS** foi atualizado com uma descrição voltada ao usuário, sem caminhos internos ou nomes de arquivos.

### Erros anteriores do build
- A lista de downloads offline agora tem tipo mutável explícito antes de adicionar e atualizar registros.
- A montagem dos endereços e o corte de espaços finais foram ajustados para evitar o erro `trimEnd` mostrado no log anterior.

## Integridade e verificações

- Versão preservada: **0.0.3 / code 03**.
- Os três códigos públicos pCloud permaneceram no projeto.
- A seção de assinatura oficial no `codemagic.yaml` foi comparada com a versão anterior: o bloco da chave foi mantido sem alteração.
- O Gradle continua exigindo a chave oficial; não foi introduzido fallback de assinatura debug.
- YAML do Codemagic analisado com parser; os 8 scripts shell passaram por `bash -n`.
- O arquivo da função Firebase passou por `node --check`.
- As verificações estáticas das categorias, botões, três coleções, Telegram e rota HTTPS passaram.

## Limite desta entrega

A compilação Android **não foi executada neste ambiente**, pois o pacote-fonte não inclui Gradle Wrapper e não há comando Gradle instalado aqui. Portanto, esta entrega é um pacote de código corrigido e validado estaticamente, não um APK compilado ou testado em aparelho. O próximo resultado conclusivo será o log do Codemagic após executar este pacote.
