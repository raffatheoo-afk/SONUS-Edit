# PULSE STUDIO 0.7.8 • code 40 • HOTFIX3

Pacote de estabilização do Editor autorizado em 26/08/2026.

## Implementado neste hotfix
- transição suave entre barra principal e menus contextuais;
- botão global de mute/unmute antes da timeline;
- trim com captura de gesto para evitar rolagem simultânea da timeline;
- toque em área livre para remover seleção;
- camadas temporais de Efeitos, Filtros e Ajustes;
- handles independentes nas duas extremidades das camadas;
- arraste da camada inteira pelo centro, limitado ao início/fim do projeto;
- botão Criar faixa e Aplicar a todos em Efeitos/Filtros/Ajustar;
- painel Ajustar convertido para faixa horizontal de ícones + um slider por vez;
- persistência das novas camadas e do estado mute em Rascunhos;
- Undo/Redo passa a capturar camadas temporais e mute;
- preview considera os intervalos das camadas;
- exportador recebe os intervalos temporais de efeito/filtro/ajuste;
- exportação respeita mute global do projeto;
- versionName 0.7.8 e versionCode 40 preservados.

## Validação local realizada
- estrutura/chaves Kotlin balanceadas nos arquivos alterados;
- varredura de sintaxe Kotlin sem erros `expecting`, `conflicting overloads`, `redeclaration` ou parâmetro nomeado inválido;
- estrutura do ZIP deve permanecer `StreamPulse/...`;
- veredito de compilação continua sendo o GitHub Actions.
