# SONUS v0.8.31 — code76

## Hotfix
- Splash: mantém símbolo atual; nome "Sonus" inteiro, com S maiúsculo e restante minúsculo.
- Splash: revelação do nome sem deslocamento/tremor; texto permanece fixo enquanto o traço é revelado.
- Splash: área ampliada para evitar corte de glifos cursivos.
- Conversor de áudio: conclusão sem falhas usa mensagem explícita de sucesso.
- Conversor de áudio: card verde quando o lote conclui sem falhas; vermelho reservado a falhas reais.
- Preserva conversão MP3 corrigida do code75 e demais recursos existentes.
