# Pulse Studio 0.7.1 — code33

## Implementado neste pacote
- Splash simplificada: somente logo por 1,5 s; removidos checklist/spinner/animação decorativa.
- Importador do Pulse Video aceita vídeo, imagem e áudio via SAF, com atalhos Todos / Vídeos / Fotos / Áudio.
- Fotos entram no projeto/timeline como clipe estático de 5 s e aparecem no preview sem depender de VideoView.
- PNG/JPG/WebP e demais imagens decodificáveis pelo Android usam o mesmo fluxo persistente do projeto.
- Painel de exportação 0.7.1 introduz formatos MP4/MOV/MKV/WebM/3GP/AVI, resoluções 360p–4K, 24–120 fps, codecs detectados no aparelho e opção HDR.
- MediaCompatibility consulta encoders reais do dispositivo (H.264/HEVC/VP9/AV1) para a evolução do pipeline.

## Limite honesto da fundação 0.7.1
O exportador efetivo herdado do code32 ainda é o caminho MP4/trim. As opções avançadas aparecem como configuração da nova engine, mas não são anunciadas como renderizadas nativamente até que muxers/encoders correspondentes sejam ligados e validados. Projetos compostos apenas por foto também não fingem exportação concluída: a UI informa que a renderização composta ainda é etapa seguinte da engine 0.7.x.

## Validação
- ZIP deve passar `unzip -t`.
- Build Kotlin final deve ser confirmado pelo GitHub Actions, pois este pacote não contém Gradle Wrapper local.
