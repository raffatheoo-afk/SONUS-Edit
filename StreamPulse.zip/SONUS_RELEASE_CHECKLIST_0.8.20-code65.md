# SONUS 0.8.20 • code65

## Checklist da atualização

- [x] VersionName 0.8.20 / versionCode 65.
- [x] Franquia global: FREE 10 / Bronze 100 / Prata 250 / Ouro 500 / Diamante ilimitado.
- [x] FREE recebe +1 Uso Premium por anúncio recompensado e nunca ultrapassa 10/10.
- [x] Passe SONUS 24h retirado do fluxo comercial; rewarded ads não concedem mais desbloqueio temporal.
- [x] Operações com erro/canceladas não consomem saldo; ferramentas monitoradas descontam somente após sucesso.
- [x] Ferramentas Premium monitoradas bloqueiam novas operações quando o saldo chega a zero.
- [x] Painel de Usos Premium mostra saldo, progresso, renovação, consumo do ciclo, estimativa de duração e sugestão de upgrade.
- [x] Histórico de operações Premium e estimativa de anúncios evitados adicionados.
- [x] Sino de notificações adicionado em Destaques; player permanece sem sino/elemento novo.
- [x] Central interna com badge, histórico, marcar como lida, excluir, limpar e abrir a tela relacionada.
- [x] Categorias: Financeiro, Previsões, Usos Premium, Ferramentas, Backup/Segurança e avisos SONUS.
- [x] Notificações externas dependem de opt-in/permissão e ficam reservadas para eventos importantes.
- [x] Marcos financeiros de R$50 em R$50 por distribuidora, sem repetição do mesmo marco no ciclo.
- [x] Previsão diária limitada a 1 resumo/dia; horário padrão 23h e configurável.
- [x] Mudanças fortes de previsão durante o dia ficam apenas na Central interna.
- [x] AdMob App ID e Rewarded ID do SONUS configurados; UMP preservado.
- [x] Anúncio oficial de teste é o padrão; anúncios reais exigem `SONUS_REAL_ADS=true` no ambiente de build.
- [x] README, CHANGELOG e “O que mudou nesta versão” atualizados.
- [x] Player, áudio, Spectro, Vídeo → Áudio, Gravador, Login/Convidado, Premium existente e Dynamic Island preservados sem redesign solicitado.
- [x] Raiz técnica continua `StreamPulse/` e applicationId continua `com.sonusstudios.streampulse`.

## Validação local possível neste ambiente
- [x] Conferência de versão, package/applicationId e Manifest.
- [x] Conferência dos limites 10 / 100 / 250 / 500 / ilimitado.
- [x] Conferência da proteção 10/10 do FREE e reward apenas após callback de conclusão.
- [x] Conferência estática de referências/callsites dos arquivos alterados.
- [x] Conferência de balanceamento léxico básico nos arquivos Kotlin alterados.
- [x] Integridade dos ZIPs e raiz `StreamPulse/`.
- [ ] Compilação Android final: **GitHub Actions** (não há Gradle Wrapper/Android SDK completo neste ambiente).
