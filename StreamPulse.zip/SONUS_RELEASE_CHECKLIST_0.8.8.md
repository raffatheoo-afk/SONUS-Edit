# SONUS 0.8.8 • code53

## Destaques
- SONUS LAB com SONUS MASTER, SONUS MATCH e Teste de Som.
- SONUS AUTOMIX com organização automática, crossfade, normalização, beat-match básico, prévia e exportação WAV.
- Interfaces próprias para as novas experiências de Destaques.

## SONUS MASTER
- Diagnóstico local com loudness, pico, clipping e waveform.
- Modos Streaming, Mais Volume, Suave e Voz em Destaque.
- Intensidade, prévia Antes/Depois e exportação em nova cópia.

## SONUS MATCH
- Comparação local por BPM, tonalidade, energia, loudness e duração.
- Modos Geral, Mix/DJ e Clima; ranking das 10 faixas mais compatíveis.

## Teste de Som
- L/R, frequência manual, graves/médios/agudos, balanceamento, fase e Teste Rápido.
- Mostra a saída de áudio atual e usa volume de sinal moderado internamente.

## SONUS BOOST™ / SONUS SPATIAL™
- Substituem a identidade pública PulseLift/PulseOrbit.
- Ambos ficam livres, sem exigência de plano pago.
- SONUS BOOST™: assinatura dourada quando ativa; cinza opaco quando inativa.
- SONUS SPATIAL™: assinatura diamante quando ativa; cinza opaco quando inativa.
- BOOST refeito para preservar graves, médios e agudos, com presença, compressor, ganho e limiter.
- SPATIAL 8D desacelerado, com crossfeed e profundidade limitada para eliminar pingue-pongue abrupto.
- Processamento offline do Conversor atualizado com a mesma assinatura sonora.

## Player / Visualizer
- Mantido fallback por análise local de PCM.
- Decoder solicita PCM16 para evitar incompatibilidade em aparelhos que entregam PCM float.
- Timestamp do visualizer nativo é zerado ao trocar de sessão/faixa para o fallback assumir corretamente.

## Integridade
- applicationId preservado: com.sonusstudios.streampulse
- versionName 0.8.8
- versionCode 53
- Firebase, assinatura e compatibilidade de atualização preservados.
- Editor de vídeo antigo não reintroduzido.
- Identificador de música, Letras e transferência de playlists não adicionados.

## Validação
- Auditoria estática de enums/when, referências de ToolId, nomes públicos e balanceamento de delimitadores realizada.
- O projeto não contém Gradle Wrapper; a autoridade final de compilação continua sendo GitHub Actions.
