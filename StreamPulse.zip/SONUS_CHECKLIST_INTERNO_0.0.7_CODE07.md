# SONUS — checklist interno de release
## 0.0.7 • CODE07

**Projeto:** SONUS / StreamPulse  
**applicationId:** `com.sonusstudios.streampulse`  
**versionName:** `0.0.7`  •  **versionCode:** `7`  
**Base de atualização:** `0.0.6 / CODE06` corrigida.

## 1. Versão e integridade
- [x] Atualizar a versão Android para 0.0.7 / code 7.
- [x] Preservar `applicationId` e configuração de assinatura permanente.
- [x] Atualizar workflow e preflight do Codemagic para CODE07.
- [x] Preservar `AudioToolEngine.kt`, `PulsePlayerService.kt` e `SonusStreamPlatform.kt` byte a byte.
- [x] Manter os segredos de assinatura no ambiente seguro; não adicionar fallback de assinatura debug.
- [ ] Confirmar assemble e assinatura oficial na execução remota do Codemagic.

## 2. Stream — gêneros e design
- [x] Usar a lista central `SonusMediaStandards.genres` com 18 categorias.
- [x] Apresentar cartões em duas colunas com gradientes próprios, ícones e bordas arredondadas.
- [x] Exibir ação de favorito em cada cartão.
- [x] Ordenar favoritos primeiro e os demais gêneros alfabeticamente.
- [x] Mostrar “Toque para explorar” antes do catálogo estar disponível, sem contagens falsas de zero.
- [x] Ocultar os nomes técnicos das fontes pCloud como gêneros de usuário.
- [x] Manter as três fontes independentes para respeitar os controles de publicação do OWNER.
- [x] Projetar faixas para os gêneros oficiais usando tags/subpastas e fallback do catálogo de artistas.
- [x] Omitir faixas sem classificação confiável em vez de as atribuir a uma categoria incorreta.

## 3. Desempenho e atualização
- [x] Preservar Home leve, com primeira composição sem leitura síncrona do catálogo completo.
- [x] Não resolver links de áudio ou iniciar downloads de música ao abrir o Stream.
- [x] Manter conteúdo existente durante sincronização.
- [x] Criar índice local compacto das 80 faixas mais recentes.
- [x] Acrescentar opções: abertura, 30 min, 1 h, 2 h, 3 h, 6 h, 12 h, 24 h e Manual.
- [x] Usar “A cada abertura” como padrão para instalação sem preferência salva.
- [x] Preservar preferências já salvas pelo usuário.
- [x] Manter o botão Atualizar sempre disponível.

## 4. Rádio e LIVE
- [x] Exibir opções de Rádio pelos gêneros oficiais sem consultar faixas na abertura.
- [x] Consultar o catálogo e preparar a programação somente depois do toque em uma estação.
- [x] Estações automáticas por gênero só são criadas após a seleção e exigem mais de 15 faixas únicas; a lista de gêneros continua disponível sem pré-carregamento.
- [x] Manter a opção “Para Você”.
- [x] Atualizar a classificação de gêneros da LIVE por meio do mesmo catálogo oficial.
- [x] Não alterar as transições, controles ou fluxo de preparação do palco LIVE.

## 5. Sobre
- [x] Atualizar `SONUS_CURRENT_VERSION_SUMMARY` para refletir CODE07.
- [x] Registrar a nova versão no changelog e no status da entrega.

## 6. Validação estática desta entrega
- [ ] Validar APK e assinatura com Codemagic.
- [ ] Testar primeira abertura com cache vazio e com cache pré-existente.
- [ ] Testar todas as três fontes pCloud e os interruptores OWNER de publicação.
- [ ] Confirmar que nenhum rótulo MÚSICAS/MÚSICAS 2/MÚSICAS 3 aparece na interface pública.
- [ ] Testar gêneros com poucas faixas e gêneros sem metadados suficientes.
- [ ] Testar favoritos de gênero após fechar e reabrir o app.
- [ ] Testar índice recente em atualização da CODE06 para CODE07.
- [ ] Testar cada intervalo de atualização e o modo Manual.
- [ ] Confirmar que Rádio não carrega faixas antes de tocar em uma estação.
- [ ] Regressão completa do fluxo LIVE, Player, ferramentas de áudio, login e uploads.

## 7. Limitação conhecida
O endpoint pCloud utilizado retorna a árvore de metadados da fonte pública, não uma página de resultados por gênero. A CODE07 mantém a consulta da árvore para a primeira ação que precisa das faixas e separa os gêneros na camada de interface; nenhum link de áudio é resolvido nesse passo. Confirmar latência com as três fontes reais no aparelho.

**Nota de build:** este ambiente não dispõe de Gradle Wrapper/Gradle nem Android SDK. A compilação completa não foi executada localmente. O pacote e o workflow estão preparados para a validação remota no Codemagic.
