# Pulse Studio 0.7.2 — code34

Foco: seleção múltipla, timeline compacta com thumbnails/trim, botão +, rascunhos/autosave e Home do Editor.

- Seleção múltipla via OpenMultipleDocuments.
- Novas mídias são anexadas à timeline; não substituem as anteriores.
- Timeline sem RangeSlider roxo, com clipes compactos e thumbnails.
- Handles laterais no clipe selecionado para reduzir duração/trim.
- Botão + dedicado para adicionar mídia.
- Home do Editor com Novo Projeto, Projeto Musical e Rascunhos.
- Autosave silencioso; rascunho não apaga mídia original.
- Editor abre na Home, e não reabre automaticamente o último projeto.
- versionName 0.7.2 / versionCode 34.
