# Pulse Studio — Checklist de entrega 0.5 (27)

## Identidade
- [x] Marca pública Pulse Studio.
- [x] Logotipo oficial fornecido pelo usuário aplicado, com fonte mestre 4096×4096.
- [x] `applicationId=com.sonusstudios.streampulse` preservado.
- [x] Assinatura/keystore preservada.
- [x] `versionName=0.5` / `versionCode=27`.

## Arquitetura
- [x] Player como abertura.
- [x] Destaques: Karaokê + Conversor de Áudio.
- [x] Ferramentas sem duplicação de Player/Karaokê/Conversor.
- [x] Aba Vídeo preparada para o futuro Editor de Vídeo.
- [x] Ganhos consolida distribuição, histórico, analytics e financeiro.
- [x] Artistas/distribuidoras movidos para Ganhos.
- [x] Uso sem distribuidora não bloqueia Player/Ferramentas.
- [x] Conversor contextual: perfil de distribuidora só aparece quando há cadastro; caso contrário usa Modo livre.

## Planos e Passe Pulse
- [x] Free / Bronze / Prata / Ouro / Diamante aplicados ao catálogo.
- [x] Pulse Coins: 30 / 60 / 200 / 500 / ilimitadas.
- [x] Planos pagos sem anúncios comuns.
- [x] Remove Ads removido como plano comercial.
- [x] Passe Pulse 24h integrado para funções elegíveis por rewarded voluntário.
- [x] Serviço do Pulse Player respeita entitlement de PulseLift/PulseOrbit inclusive na notificação.

## Compatibilidade e segurança
- [x] Backup Pulse Studio aceita backups antigos StreamPulse.
- [x] Claims de planos antigos são mapeados para a nova hierarquia.
- [x] Configuração do Conversor pode persistir sem artista cadastrado.
- [x] Benefícios Premium/Owner não são restaurados de backup como autoridade.
- [x] Nenhuma Firebase Rule nova necessária.

## Validação antes da entrega
- [x] Verificar Kotlin estruturalmente e com parser PSI.
- [x] Parsear XML e JSON.
- [x] Confirmar hash do keystore contra code26.
- [x] Confirmar hashes das regras Firebase contra v1.9.4 publicada.
- [x] Confirmar `google-services.json` inalterado contra code26.
- [x] Varredura de credenciais/Owner/YouTube API.
- [x] Confirmar identidade visual e dimensões do logo.
- [x] Confirmar raiz técnica `StreamPulse/`.
- [x] Gerar `StreamPulse-GitHub.zip`.
- [x] Gerar backup `StreamPulse-GitHub-v0.5-code27.zip`.
- [x] Rodar `unzip -t` nos dois.
- [x] Comparar conteúdo dos dois ZIPs e calcular SHA-256.
- [x] Não afirmar compilação até GitHub Actions.
