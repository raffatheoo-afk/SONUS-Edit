# SONUS — 0.0.6 / code 06 (candidato de atualização)

- Stream: Home reorganizada em Linha do Tempo, SONUS Rádio, Acesso rápido e Gêneros; botões superiores redesenhados e Busca por músicas, artistas, playlists e gêneros.
- Stream: carregamento do catálogo/capas/locuções sob demanda; atualização Manual por padrão; removida a prateleira promocional PULSE (Pulse Player e ferramentas de áudio preservados).
- Stream: atalhos priorizam Adicionadas recentemente; tela mostra gênero/status e oferece acesso ao painel existente para editar letras e metadados.
- Stream: ajustes de dados móveis e limpeza de capas do cache de disco/memória, preservando biblioteca e histórico.
- LIVE: início não depende de cinco imagens; primeira cena com timeout, fallback SONUS e reposição da fila em segundo plano. Mantidos áudio real, controles, contagem regressiva, microfone e duração de vídeos.
- Atualizados `versionName = 0.0.6`, `versionCode = 6` e workflow Codemagic CODE06.
- Build APK e testes em dispositivo ainda pendentes; consulte `RELEASE_STATUS_0.0.6_CODE06.md` e `SONUS_CHECKLIST_INTERNO_0.0.6_CODE06.md`.

---

# SONUS — 0.0.2 / code 02 (candidato de atualização)

Esta versão continua o projeto estável que já passou por mais de 100 ajustes. A numeração 0.0.2 / code 02 pertence à nova linha de assinatura; não representa o início do projeto.

## Implementado nesta cópia de trabalho

- Atualizado `versionName` para `0.0.2` e `versionCode` para `2`.
- Stream: terceira origem pública de músicas integrada ao catálogo, preservando as duas origens existentes.
- Instalações novas: Stream passa a vir habilitado por padrão; preferências explicitamente salvas pelo usuário são preservadas.
- Social Edit e Live: integrados os três códigos públicos de galerias 9:16; IDs iguais de pastas diferentes permanecem distintos e os downloads mantêm a origem correta.
- Social Edit: substituído o ícone pelo arquivo de imagem fornecido.
- Marca/ícones: novo logotipo rosa como padrão; 26 variantes (8 grátis, 4 Prata, 5 Ouro e 9 Diamante) e recursos adaptativos/densidades correspondentes.
- Ícones (ajuste visual): as 28 camadas de primeiro plano foram redimensionadas para manter a arte em aproximadamente 46% da área quadrada, próxima à proporção da imagem de referência; fundos preservados. Previews e imagens de launcher em todas as densidades foram regenerados com a mesma escala.
- Compartilhamento do Stream: envia título, artista e deep link `sonusonline://pcloud`, com identificação de origem. O endereço pCloud não é incluído no texto compartilhado.
- Pulse: trechos de 20 segundos, rotação de catálogo em janelas de 6 horas e avanço automático ao concluir o trecho.
- Conversor de vídeo: seleção não exige pré-análise do lote; cada item é inspecionado quando sua conversão começa, em sequência.
- Editor de PDF: exportação fecha `PdfDocument` em `finally`, escreve o destino em modo de sobrescrita e atualiza o progresso na thread principal.
- Ferramentas: “Renomear áudios” e “Renomear vídeos” estão em áreas separadas, com filtros de seleção próprios.
- Codemagic: workflow, checagens de versão e hash do Player ajustados para 0.0.2 / code 02; mantidas verificações de assinatura e Firebase.
- Assinatura oficial: o `sonus-edit-dev.jks` enviado é byte a byte idêntico ao keystore já codificado no YAML (SHA-256 do arquivo: `b3884a61a389fcc2090846ff47926935337cfc522cf367418f68eab879fb0295`). O alias esperado continua `sonusedit`, com conferência da impressão digital do certificado no workflow.
- Segurança de atualização: removido o fallback de assinatura debug; Gradle e Codemagic agora interrompem o build se a chave oficial/senha segura estiver ausente e só disponibilizam o APK quando o certificado SHA-256 final confere com o oficial.

## Ainda não concluído — não considerar pronto para produção

- Downloads offline completos: botão alternável baixar/remover, armazenamento privado, biblioteca de baixadas e reprodução somente das baixadas sem internet ainda não foram implementados.
- Cache antecipado do áudio do Pulse: o código existente antecipa arte e descritores de reprodução; não foi integrado um cache Media3 persistente/compartilhado de bytes de áudio ao abrir o Stream.
- Link HTTPS universal: o compartilhamento usa o esquema `sonusonline://`; abre o SONUS quando instalado e associado ao esquema. Um link HTTPS universal/branded depende de domínio próprio e validação de Android App Links.
- Os códigos públicos das seis pastas foram conectados ao app, mas o conteúdo efetivo/listagem de cada pasta precisa ser conferido com acesso real ao pCloud durante o teste integrado.
- Correções do conversor e do PDF foram aplicadas ao código, mas precisam de validação funcional em aparelho com vídeos grandes/lotes e arquivos PDF reais.
- Não foi gerado APK nesta sessão. Não havia Gradle instalado nem Gradle Wrapper no pacote recebido; `assembleDebug`, instalação e testes em aparelho não foram executados.

## Validações executadas nesta cópia

- 51 arquivos XML parseados sem erros.
- 7 arquivos JSON parseados sem erros.
- `codemagic.yaml` parseado sem erros; 7 blocos shell passaram em `bash -n`.
- 11 arquivos Kotlin alterados passaram pela análise sintática PSI do compilador Kotlin, sem erros de sintaxe (não equivale a compilação com dependências Android).
- Catálogo contém exatamente 26 ícones (8/4/5/9), com todos os previews, camadas adaptativas e recursos de launcher nas cinco densidades; nenhum recurso referenciado ficou ausente.
- As cores de fundo das opções grátis, Prata e Ouro foram verificadas como iguais entre si.
- O arquivo ZIP de entrega ainda deve passar por teste de integridade após o empacotamento.

**Estado:** código-fonte candidato 0.0.2 / code 02; não é build Android compilada nem release aprovada.

## 0.0.8 — CODE08
Consulte `CHANGELOG_0.0.8_CODE08.md` para o resumo completo das correções da LIVE, popup de gêneros e simplificação da lista do Stream.

## 0.0.9 — CODE09
Consulte `CHANGELOG_0.0.9_CODE09.md`: ajuste de layout no cartão “Letras” do Painel Desenvolvedor OWNER para exibir integralmente o contador LRC.

## SONUS 1.0 — CODE10 (candidato de código-fonte)
Consulte `CHANGELOG_1.0_CODE10.md` e `RELEASE_STATUS_1.0_CODE10.md` para as alterações e validações pendentes. A compilação Android e a instalação de atualização sobre a CODE09 ainda precisam ser confirmadas no Codemagic e em aparelho real.
