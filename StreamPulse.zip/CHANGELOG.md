# SONUS 1.0.24 / code127 — Biblioteca LRC unificada e Developer compacto

- Corrige o contador/lista zerada de Letras sincronizadas no Painel Desenvolvedor.
- A biblioteca OWNER agora varre o catálogo completo e agrega LRC oficiais do pCloud com LRC já cadastradas nas músicas do SONUS.
- Mantém fonte única por faixa: pCloud oficial tem prioridade; LRC do catálogo entra como fallback, sem duplicação.
- Adiciona botão Atualizar para refazer catálogo, overrides e índice da pasta LRC em background.
- Download individual e “Baixar todas” passam a funcionar para LRC vindas de qualquer uma das fontes unificadas.
- Remove o card descritivo não clicável do SONUS Stream no Developer.
- Moderação de envios e Letras sincronizadas ficam em atalhos 50/50.
- Compacta Serviços SONUS Stream em grade de status com três itens por linha.
- Preserva as integrações code126 de duas fontes pCloud do Stream, assinatura visual e sincronização automática de letras.

## SONUS 1.0.23 / code126
- SONUS Stream passa a combinar duas pastas públicas pCloud em um único catálogo invisível ao usuário, com deduplicação por identidade da faixa e fallback se uma fonte falhar.
- Segunda fonte pública adicionada: kZjNE8JZ1u7bptnw2J7AJmDn04hFe8O3o09k.
- Nova biblioteca pública oficial de letras LRC: kZNiXQJZTobHXlzVPjzsj9LyASRI77DUtfJk.
- Letras sincronizadas passam a ser resolvidas automaticamente por faixa, priorizando o LRC oficial e usando a fonte antiga somente como fallback, sem renderização dupla.
- Editor LRC sugere o nome real da música no arquivo exportado.
- Painel Desenvolvedor recebe o card Letras sincronizadas com busca, download individual e pacote ZIP de todas as LRCs.
- Splash recebe a assinatura visual `by SONUS STUDIOS - RΛFΛ亗`.
- Motores protegidos de áudio, player e Stream backend permanecem byte-idênticos ao code125.


## SONUS 1.0.22 / code125
- Social Edit: duração das imagens agora divide exatamente o tempo total pela quantidade selecionada em 15/30/40/50/60/65s.
- 5s passa a ser apenas o tempo mínimo por imagem / limite máximo de seleção.
- Corrigido relógio local dos fades por clipe para impedir tela preta a partir da segunda imagem.
- Fade visual ajustado para 1,5s de entrada + 1,5s de saída por imagem; fade do áudio permanece inalterado.
# SONUS 1.0.21 / code124 — Player Stream inteligente, períodos e Social Edit

## Rodada aprovada — 01/10/2026

- Player principal usa uma sugestão cacheada do SONUS Stream quando a biblioteca local não está disponível, mantendo todos os controles visíveis e sem autoplay da próxima sugestão.
- Sugestões respeitam o gênero recente/última faixa local, evitam repetições recentes e permanecem no mesmo grupo de gênero durante a sessão.
- Aviso de biblioteca local foi reduzido a uma faixa compacta com chave para dispensar; pode ser reativado nos Ajustes do Player.
- Painel Desenvolvedor abre no SONUS Stream, remove o módulo Atualizações e reorganiza os módulos por prioridade, deixando Resumo por último.
- Estatísticas do Player e Uso do app passam a abrir em **Mês**, separado da janela móvel de **30 dias**, sem seletores horizontais escondidos.
- OWNER simulando FREE usa Rewarded oficial de teste do Google; o painel mostra código, domínio, mensagem e ResponseInfo da última falha.
- Social Edit passa a aceitar múltiplas imagens em slots de 5 s, com limites por duração e até 20 miniaturas carregadas; cada imagem recebe Fade In/Out de 2 s.
- Versão promovida para 1.0.21 / code124. Build verde depende da compilação real no Codemagic.

---

# SONUS 1.0.19 / code122 — Atualizações integradas, Tune, Gravador e ferramentas

## Rodada aprovada — 30/09/2026

- Novo **SONUS Update**: pCloud armazena APKs, o painel Owner publica/pausa pelo Firebase e os demais aparelhos consultam silenciosamente uma versão superior com cache de 12 h.
- Novo botão **Checar atualização** em Ajustes e novo popup com novidades, adiar, download, SHA-256, validação de pacote/assinatura e entrega ao instalador do Android.
- **Sobre o SONUS** agora mostra somente a versão instalada e um resumo curto das melhorias da versão atual.
- **Renomear imagens em lote** deixa de tratar todo URI SAF como renomeável: checa `FLAG_SUPPORTS_RENAME`, resolve o URI equivalente do MediaStore e usa `DISPLAY_NAME`, com diagnóstico amigável por falha.
- **Conversor de Vídeo** passa parâmetros ao FFmpegKit como argumentos estruturados e usa dimensões calculadas no Kotlin, removendo o filtro com aspas aninhadas que podia quebrar a conversão. Erros do FFmpeg agora priorizam a linha realmente útil.
- **Gravador de Voz** redesenhado com tela limpa, ajustes no topo e cards SONUS. A gravação é finalizada primeiro em arquivo privado válido e só depois publicada em `SONUS/Recordings`; pós-gravação inclui ouvir, renomear, excluir, exportar e redução de ruído.
- **SONUS Tune** vira automático/cromático com A4=440 Hz interno; controles manuais foram removidos. O ponteiro recebe mediana, EMA, histerese de nota, proteção contra saltos harmônicos, retenção curta de sinal e animação amortecida.
- Motores protegidos de Áudio, Stream e contador permanecem sem alteração funcional nesta rodada.

> code122 é o bootstrap do atualizador e precisa ser instalado manualmente uma última vez. Depois de instalado, versões superiores publicadas pelo Owner podem ser detectadas pelo próprio SONUS. Build verde ainda depende de `:app:assembleDebug` real no Codemagic.

---

# SONUS 1.0.18 / code121 — Conversor de Vídeo e contador 50%

## Rodada aprovada — 30/09/2026

- Compressor de Vídeo removido dos Destaques e substituído pelo **Conversor de Vídeo** gratuito.
- Nova tela compacta sem rolagem vertical, inspirada no layout aprovado: card laranja clicável para seleção/lote, resumo azul de entrada, estimativa lilás de saída e botão Converter verde.
- Lotes abrem a lista completa em modal próprio, com adicionar/remover/limpar sem expandir a tela principal.
- Grade de 9 formatos: MP4, MOV, MKV, WEBM, AVI, 3GP, MPEG, TS e FLV. Cada formato usa perfil real de contêiner + codec, com pré-check dos encoders antes do primeiro vídeo.
- FFmpegKit promovido de `ffmpeg-kit-audio:8.1.7` para `ffmpeg-kit-full:8.1.7`, preservando a mesma API usada pelas ferramentas de áudio; o Conversor de Áudio não foi reescrito.
- FPS de saída: 120, 60, 30 e 24. Resoluções: 4K, 2K, 1080p, 720p, 480p e 360p.
- Escala preserva a proporção original em horizontal, vertical, quadrado e proporções intermediárias; upscale e downscale são permitidos conforme escolha explícita.
- Progresso de lote usa o modal global SONUS e mostra vídeo atual/total.
- Contador do SONUS Stream agora qualifica em **50% exatos de tempo realmente ouvido**; seek não soma tempo.
- Ao passar pelo cooldown de 15 minutos e atingir 50%, o contador visível é atualizado localmente de imediato e a sincronização pública continua pendente/deduplicada por `sessionId`.

> Source code121 preparado para validação real em `:app:assembleDebug` pelo Codemagic. Não declarar build verde antes da compilação real e do teste no aparelho.

---

# SONUS 1.0.17 / code120 — Social Edit, Stream, Cortador Pro e Compressor

## Rodada aprovada — 29/09/2026

- SOCIAL EDIT recebeu novo ícone transparente/limpo, sem fundo preto, e os cards de duração passam a usar verde sólido suave; 15 s agora aparece como **TESTE** e 65 s como **TikTok 1min+**.
- Mantidos os 5 filtros atuais gratuitos e adicionados 10 filtros PRO de tratamento suave/natural: Natural+, Luz Suave, Quente Natural, Frio Natural, Contraste Suave, Cinema Clean, Dourado, Noite Limpa, Pastel Natural e Clareza+.
- Removido definitivamente o swipe horizontal entre abas principais; a navegação de área passa a acontecer somente pela barra inferior, evitando perda acidental de progresso.
- Cortador Pro recebeu waveform horizontal ampliada/deslizável (2x–8x), playhead central, régua temporal e referência posição/duração em HH:MM:SS quando necessário.
- SONUS Stream passa a aceitar reprodução da própria música como reprodução real. O anti-loop usa cooldown de 15 minutos por conta + faixa + dispositivo, com chave de aparelho protegida por hash.
- Analytics Você passa a checkpointar tempo ouvido durante a sessão para eliminar estados como “1 play / 0 s”; sessões em cooldown continuam registrando tempo, mas não adicionam nova visualização.
- Contador público e Analytics Artista deixam de excluir self-play automaticamente e continuam deduplicados por sessão.
- Compressor de Vídeo foi reconstruído sobre Media3/MediaCodec com bitrate-alvo calculado, H.264 por padrão e HEVC para 4K quando suportado, preservando resolução original quando solicitado e impedindo upscale.
- Metas do Compressor: Leve ~30% de redução, Equilibrado ~40%, Máxima ~50%; FPS adaptativo para fontes 24/30/60/120 fps e uma única recalibração automática quando a primeira saída fica acima da meta.
- O Compressor valida o tamanho final e não publica como sucesso uma saída maior que o original.
- Media3 atualizado do patch 1.11.0 para 1.11.1.
- A barra circular/percentual de progresso aprovada foi preservada.

> Source code120 preparado para validação real em `:app:assembleDebug` pelo Codemagic. Não declarar build verde antes da compilação real e do teste no aparelho.

---

# SONUS 1.0.16 / code119 — Build Fix 1

## Correção de compilação — 29/09/2026

- Mantidos `versionName = 1.0.16` e `versionCode = 119`; nenhuma promoção de versão.
- Corrigido o progresso do Conversor de Áudio em lote: `AudioConversionEngine` entrega progresso em `Float` de 0f a 1f, então a normalização agora usa `coerceIn(0f, 1f)` e preserva o cálculo agregado do lote.
- Corrigida referência indevida a `exporting` dentro da tela SONUS Match; essa variável pertence a outro fluxo do arquivo e não existe no escopo do Match. O indicador local volta a depender somente de `busy`.
- Nenhum motor de exportação, codec, bitrate, formato ou qualidade foi alterado.
- Build verde ainda depende de nova execução real de `:app:assembleDebug` no Codemagic.

---

# SONUS 1.0.16 / code119 — SOCIAL EDIT, Financeiro, Vídeo e Metadados

## Rodada aprovada — 29/09/2026

- Compartilhar renomeado para **SOCIAL EDIT**, com identidade própria, 15 s grátis e 30/40/50/60/65 s para planos pagos.
- SOCIAL EDIT recebeu ajuste fino de início em ±1 s, fade-in/fade-out automático de 2 s no áudio e fade visual de 2 s no vídeo.
- Distribuição & Pagamentos separa definitivamente modo **TOTAL** (snapshots acumulados) de **DIA** (registros diários), com `streamEntryMode` persistente e `financialCycleId` para isolar ciclos.
- Histórico financeiro agora permite editar/remover registros e recalcular os consumidores do motor de métricas.
- Novo **Comprimir Vídeo** gratuito nos Destaques.
- **Cortador Pro** foi transformado em cortador de vídeo multitreccho com mini player, waveform, marcações início/fim, ajuste −10/−1/+1/+10 e exportação de múltiplos trechos.
- Conversor de Áudio ganhou edição completa de metadados individual e em lote, título/nome de saída separados, limpeza automática conservadora e “Aplicar a todas”.
- Progresso circular do SOCIAL EDIT foi generalizado como padrão visual de exportações longas do SONUS, sem alterar motores já aprovados.
- Premium atualizado sem reajuste de preço: Prata R$ 8,90, Ouro R$ 14,90 (recomendado), Diamante R$ 24,90.
- AutoMix e Cortador Pro passam a PRO; Compressor de Vídeo permanece grátis; Player e Stream continuam completos no Free.

> O source code119 está preparado para `:app:assembleDebug`. O APK só deve ser considerado build verde após compilação real no Codemagic e teste no aparelho.

---

# SONUS 1.0.15 / code118 — Build Fix 1

## Correção de compilação — 29/09/2026

- Mantidos `versionName = 1.0.15` e `versionCode = 118`; nenhuma promoção para code119.
- Corrigida referência residual `externalRevenueRecords` em `AppRepository.deleteArtist()` após a remoção desse campo do `AppState`.
- Restaurada a dependência compartilhada correta do exportador com `com.sonusstudios.streampulse.audio.AudioAnalysis`; o analisador de áudio continua necessário fora do SONUS Edit.
- Os erros `frames`, `rms`, `bass`, `treble` e inferências de tipo em `PulseCompositionExporter` eram cascata da referência `AudioAnalysis` não resolvida.
- Nenhuma funcionalidade aprovada foi removida para contornar a compilação.
- Build verde ainda depende de nova execução real do `:app:assembleDebug` no Codemagic.

---

# SONUS 1.0.14 / code117 — Base de continuidade / migração

## Migração 28/09/2026

- Última versão informada como instalada pelo Rafa: SONUS 1.0.13 / code116.
- Nova base de desenvolvimento promovida para SONUS 1.0.14 / code117.
- Esta promoção NÃO adiciona novas funcionalidades por si só; preserva integralmente o estado funcional do code116 e prepara o próximo ciclo de ajustes.
- Workflow Codemagic promovido para `sonus-code117-debug`.
- Artifact esperado: `SONUS-v1.0.14-code117.apk`.
- Log completo de build: `BUILD-code117.log`.
- Build verde/APK instalado ainda dependem de execução real do `:app:assembleDebug` e teste do Rafa.

---

# SONUS 1.0.13 / code116 — Stream Performance / Pulse / Analytics / LRC

- SONUS Stream: first paint priorizado por cache/snapshot em memória, aliases cacheados e revalidações secundárias adiadas para background.
- SONUS Stream: contagens públicas passam a preferir snapshot único de `streamStats`, com cache curto e fallback por faixa, reduzindo centenas de leituras em catálogos médios.
- Player Stream: ExoPlayer online reaproveitável, descriptor de playback com TTL curto, retry único para URL expirada, prefetch somente da próxima faixa e logs internos `SONUS_STREAM_PERF` para medir URL/READY/primeiro áudio.
- Pulse: lista horizontal vinculada à assinatura da janela de 12h para sempre abrir no primeiro item; duração deixa de bloquear a prévia e o pipeline prioriza o primeiro áudio antes de análise/preload.
- Analytics: aba Artista recebe gráfico temporal sempre presente, com estado vazio explícito e refresh enquanto a tela permanece aberta; Analytics “Você” permanece intocado.
- Editor LRC: letra colada é separada automaticamente em linhas ainda na preparação; `INICIAR SINCRONIZAÇÃO` fica fixo abaixo de Restaurar rascunho / Adicionar música e só desaparece depois de entrar no modo de marcadores.
- Compartilhar permanece congelado nesta rodada por estar aprovado e funcionando.
- Versionamento promovido de 1.0.12/code115 instalado para 1.0.13/code116.

> O source code116 foi preparado para validação. O APK só deve ser considerado pronto após `:app:assembleDebug` concluir com sucesso no Codemagic.

# SONUS 1.0.11 / code114 — Build Fix 3

- Refatoração estrutural de `PulseVideoEditorScreen` para evitar o limite JVM/ASM de 64 KiB por método após três tentativas de compilação do code114.
- Preview/transport, timeline, inspector, exportação e modais foram isolados em corpos composables independentes sem remover recursos.
- `ToolInspector` também foi dividido por ferramenta para reduzir o bytecode gerado pelo Compose.
- `Modifier.weight` permanece somente em escopos `ColumnScope`/`RowScope` válidos.
- Codemagic agora valida marcadores do Build Fix 3 antes do Gradle e salva o log completo de `assembleDebug` como artifact mesmo quando o build falha.
- Versionamento permanece `1.0.11` / `114`; nenhum code115 foi criado.

# SONUS 1.0.11 — code114

## Build Fix 1 — 28/09/2026
- Corrigido `:app:compileDebugKotlin` que falhava com `MethodTooLargeException` em `PulseVideoEditorScreen`.
- O canvas de preview, o binding de efeitos em tempo real e diálogos simples foram extraídos do composable principal para métodos/composables menores.
- A correção é estrutural e não remove recursos aprovados do SONUS Edit.
- Mantidos `versionName = 1.0.11` e `versionCode = 114`, pois o primeiro build code114 não gerou APK instalável.

- Release pós-testes do code113, promovida para nova versão instalável porque SONUS 1.0.10 / code113 já está instalado no aparelho de teste.
- Compartilhar: saída física 1080x1920, crop 9:16 sem distorção, símbolo SONUS refinado, partículas e tela de filtros modernizada.
- Stream: reforço no contador público e Analytics, preservando tempo realmente ouvido, cooldown, idempotência, retry e proteção contra play do próprio OWNER.
- Financeiro: data real do pagamento e início do ciclo editáveis, separados da data esperada, com reprocessamento seguro da janela financeira.
- Conversor de imagens: preview de lote e nova função Renomear imagens em lote com nomes individuais, nome-base e enumeração automática.
- SONUS Edit: estado por clipe para filtros/efeitos/animações, favoritos persistentes, ✔✔ Aplicar a todos, animações/transições, timeline com edge auto-scroll e pausa no scrub.
- SONUS Edit: paridade Preview = Exportação reforçada e Gaussian Blur refeito para reduzir artefatos graves.
- Exportação: opções reorganizadas sem carrosséis escondidos e progresso circular com identidade SONUS.
- Preservados applicationId, SDK 36, Java/Kotlin 17, Media3 1.11.0 e dados do usuário.

> Este source precisa concluir `:app:assembleDebug` no Codemagic antes de o APK code114 ser considerado pronto.

# SONUS 1.0.10 — code113

- Pulse: abertura acelerada com cache/preload, fallback imediato, análise espectral em background, prebuffer da próxima faixa, navegação por toque nas metades do card, avanço automático após 30 s, barras segmentadas e pausa por toque prolongado.
- Compartilhar: disponível também para músicas locais da Biblioteca; faixas locais não alimentam métricas públicas do SONUS Stream.
- Share Video: padrão visual oficial com símbolo SONUS transparente e discreto no topo, letra central com cores neon alternadas por frase, título amarelo e artista branco no rodapé.
- Share Video: limpeza de marcações entre colchetes e timestamps, auto-fit seguro de texto e validação de área útil para evitar corte nas bordas.
- Share Video: seletor de início recebe Play/Pause de prévia exata e restaura o Player principal no mesmo ponto/estado após fechar ou concluir a audição.
- Reproduções públicas: validação do usuário e contador público foram desacoplados das métricas opcionais; retry passa a ser por sessão, deduplicado, sem contador público falso local e sem inflar reprodução do próprio OWNER.
- Analytics/Studio: tela cheia passa a respeitar status bar, notch/cutout e barra de navegação com WindowInsets.safeDrawing.
- Artistas para explorar: foto real do perfil do artista quando publicada, com cache e fallback para avatar genérico.
- Perfil de artista: modal substituído por página completa com foto, seguidores, Seguir/Seguindo, Favoritar, Ouvir músicas e catálogo exclusivo do artista.
- Firebase: regras específicas adicionadas para perfil público visual do artista e favoritos de artista.
- Sobre o SONUS: passa a mostrar as três versões mais recentes — 1.0.10/code113, 1.0.9/code112 e 1.0.8/code111.
- Preservados applicationId, SDK 36, Java/Kotlin 17, Media3 1.11.0, cooldown de reproduções, dados do usuário e correções estáveis das versões anteriores.

> O source code113 exige validação final por `:app:assembleDebug` no Codemagic antes de o APK ser chamado de pronto.

# SONUS 1.0.9 — code112

- Stream: a antiga área Story passa a se chamar **Pulse** e abre uma prévia isolada de 30 segundos em card, sem acionar mini player ou Player completo; **Ouvir** inicia a faixa completa no Player.
- Pulse: seleção automática do trecho de demonstração por análise interna de energia/espectro, com cache por música e fallback seguro.
- Mini player do Stream: controles Anterior / Play-Pause / Próxima, card inteiro clicável e navegação correta para a aba Música ao abrir o Player.
- Player: ações inferiores reorganizadas para Playlist YouTube / Compartilhar / YouTube; Compartilhar recebe botão central azul com acabamento neon/glass e o atalho duplicado do topo é removido.
- Compartilhar vídeo: duração real da mídia alimenta o slider de início e a saída 1080 passa a respeitar a proporção/orientação escolhida; a validação final considera metadado de rotação do arquivo.
- Analytics: a aba pessoal passa a registrar reproduções válidas primeiro no armazenamento interno do SONUS, sem ficar zerada por falha temporária de Firebase; contador público reage à confirmação remota mantendo proteção do OWNER.
- Stream: tocar em uma prateleira cria uma lista de reprodução com a ordem exibida e neutraliza shuffle antigo; buscas individuais passam a continuar por família de gênero compatível.
- Stream: novas prateleiras “Músicas católicas pra dormir”, “Músicas pra Orar”, “Novidades do seu estilo” e “Continue no seu gênero”, com seleção/rotação interna.
- Biblioteca/Pastas: busca filtrada vira o conjunto real de reprodução; Play e Aleatório não escapam para músicas ocultas pelo filtro.
- Biblioteca: nova ordenação por título, artista, data e duração; a preferência é persistida.
- Player: “Fila” passa a se chamar **Lista de reprodução**.
- Background/notificação: foco de áudio atrasado mantém a intenção de reprodução e falhas pontuais de uma faixa podem avançar com segurança sem pausar toda a sequência.
- Áudio: troca entre Player, Stream e demais abas deixa de reaplicar configurações da engine audível; preferências de transição são inicializadas pelo serviço, reduzindo estalos/pops de navegação.
- Preservados applicationId, SDK 36, Java/Kotlin 17, Media3 1.11.0, regras de stream válido/cooldown e demais dados da instalação.

> O source foi preparado e validado estaticamente. O APK só deve ser considerado pronto após `:app:assembleDebug` concluir com sucesso no Codemagic.

# SONUS 1.0.6 — code109

- SONUS Edit: velocidade real de vídeo entre 0,25x e 4x com persistência, preview e exportação.
- Exportação de múltiplas faixas de áudio com volume individual e fades.
- Transformações de clipe exportadas: escala, rotação, posição e espelhamento.
- Texto aprimorado: fonte personalizada TTF/OTF, tamanho, zoom, posição, rotação, opacidade, contorno, fundo, sombra e animações no render.
- PIP de imagem/vídeo conectado ao Transformer via VideoCompositorSettings.
- Novo pipeline GPU SONUS para efeitos/filtros problemáticos e ajustes avançados.
- Ajustes avançados de cor entram no render: highlights, shadows, whites/blacks, sharpen, fade, vignette, grain e opacity.
- Base mantida em Media3 1.11.0; sem introdução de FFmpegKitNext para o editor.
- Licença MIT do ClearCut registrada em THIRD_PARTY_NOTICES quando conceitos/trechos substanciais forem adaptados.

> Build real do APK code109 ainda precisa ser executado no Codemagic antes de marcar a versão como pronta para instalação.

# SONUS 1.0.5 — code108

## Build fix 1 — 23/09/2026
- Corrigidas as referências ausentes `recordTimelineValidPlay` e `timelineForYear` que impediam `:app:compileDebugKotlin`.
- Linha do Tempo anual agora registra e lê reproduções válidas localmente, por conta e por faixa, sem Cloud Function.
- Mantidos versionName 1.0.5 e versionCode 108 porque o build anterior não foi concluído.

- Publicação interna: músicas aprovadas recebem um prazo persistente de 1–60 minutos e passam a exibir Ao Vivo 🟢 automaticamente dentro do SONUS, sem depender de Cloud Functions ou botões manuais.
- Centro do artista: guias separadas “MÚSICAS APROVADAS” e “REJEITADAS”; rejeitadas podem ser ocultadas localmente por submissionId com “Remover registro”, sem 404.
- Painel OWNER: removidos os botões Ao Vivo individuais do catálogo; “Abrir ficha” permanece como ação principal e o vínculo faixa↔artista é reconhecido diretamente no Realtime Database quando o OWNER sincroniza o catálogo.
- Analytics do SONUS Stream — Você: novo painel mensal local com reproduções válidas, tempo ouvido, conclusões, replays, pulos, únicos, gráfico diário, rankings e limpeza apenas do mês pessoal.
- Analytics do SONUS Stream — Artista: dados permanentes com filtros 48h, 7, 15, 30, 90, 180, 365 dias e Total; gráficos, público e desempenho por faixa.
- Visualizações válidas: critério dinâmico por música — inicia em 50% da duração, reduz 10 s a cada 50 views e tem piso de 10 s; cooldown antirrepetição de 8 minutos permanece.
- Estatísticas do Player: reparo de históricos impossíveis de pulos e proteção para que erros técnicos, crossfade/gapless ou pause/retomar não sejam contabilizados como novos pulos/reproduções.
- SONUS Rádio: chips amarelos sólidos, sem gradiente/glow, com texto escuro de maior contraste.
- Linha do Tempo: degradê azul/roxo suave e novo ícone de cronômetro sem fundo.
- Sobre o SONUS atualizado com resumo detalhado da code108 e histórico recente.

# SONUS 1.0.4 — code107

- Player/Stream: transporte reforçado para impedir escapes curtos de áudio ao trocar de telas; estado pausado invalida crossfade/gapless e pausa explicitamente o analisador Media3.
- Biblioteca do Player: todas as ações de reprodução retornam ao Player e o botão Biblioteca preserva o escopo da pasta que originou a fila; “Músicas” no menu lateral redefine o escopo para o catálogo completo.
- SONUS Rádio: estações agora são derivadas do gênero real das faixas, sem transformar a pasta única MUSICA(S) em estação, com identidade visual amarelo/laranja.
- Linha do Tempo: novo degradê vermelho/lilás sólido e animação mais suave.
- Home do Stream: Mix para você, Artistas para explorar, Seu momento no SONUS com métricas reais quando disponíveis e Coleções SONUS por álbum; superfícies principais mais sólidas e menos repetitivas.
- Artistas: card “Seu limite” simplificado; usuários comuns passam a ter cota mensal de 30 envios e OWNER não é bloqueado por cota/pending.
- Rejeitadas: remoção exibe sucesso/falha e continua preservando o registro administrativo por userHiddenAt.
- Moderação OWNER: botão Ao Vivo direto por faixa no catálogo, com vínculo pelo fileId e matching seguro da submissão aprovada.
- Backend: nova sessão analítica startPlaySession e contabilização centralizada em claimPlay/finishPlay; regra de 20 s + cooldown de 8 min preservada e auto-reprodução do próprio artista excluída das métricas públicas.
- Diagnóstico: respostas HTTP do backend exibem o erro remoto para facilitar identificação de Functions não implantadas.
- Sobre o SONUS atualizado com histórico detalhado das três versões mais recentes.

# SONUS 1.0.2 — code105

- SONUS Stream: identificação automática de publicação reforçada com Music ID e leitura de metadados ID3 do próprio MP3.
- Publicações aprovadas continuam sendo verificadas automaticamente a cada 5 minutos; usuário e equipe também ganham atualização imediata.
- OWNER e SUPPORT podem marcar 🟢 Ao Vivo manualmente e reverter para aguardando publicação quando necessário.
- Usuário recebe notificação separada de aprovação e outra quando a música realmente fica Ao Vivo.
- Envios com LRC mantêm a letra incorporada no MP3 e também enviam o arquivo .LRC separado ao Telegram.
- Envios rejeitados podem ser removidos da lista do usuário sem apagar o registro administrativo.
- Tela Para artistas: botão Studio removido e bloco Análise manual transformado em card informativo escuro.
- Botão Suporte por música envia o contexto da faixa automaticamente.
- Sobre o SONUS passa a exibir apenas as três versões mais recentes e mudanças relevantes ao usuário.
- Preservada a regra de reprodução válida de 20 s / janela de 8 min e as correções estáveis da code104.

# SONUS 1.0.1 — code104

- SONUS Stream: Linha do Tempo anual secreta (5 reproduções válidas por música, liberação com 10 faixas).
- Stream: cache imediato + sincronização por revisão, consultas limitadas e melhorias de performance.
- Envios: ações por status, Analytics/Studio, avatar local/Google e status automático 🟢 Ao Vivo após confirmação real no catálogo.
- Letras: seletor global TXT/LRC e incorporação da letra ao MP3 enviado.
- Conversores/tags: gêneros canônicos e novos bitrates, incluindo 160 kbps.
- Player/Stream: limpeza visual de sufixos técnicos como MP3_128K.
- Preservada integralmente a regra de reprodução válida de 20 s / janela de 8 min da code103.

# SONUS 0.9.6 / code102

- Submissão de artistas migrou do pCloud File Request para o Cloudflare Worker seguro que entrega o MP3 processado ao grupo privado 🔴 SONUS ARTISTAS no Telegram.
- Token do Telegram e chat_id permanecem fora do APK, guardados como Secrets no Worker.
- Upload envia Firebase ID Token, MP3 160 kbps com capa/tags e LRC/TXT opcional, com progresso e confirmação somente após resposta real do backend.
- Topo do SONUS Stream compactado: título e quatro ações na mesma linha, sem TopAppBar duplicada e sem espaço vazio.
- Ícones do topo agora têm botões quadrados, cores vivas próprias e independentes do tema.
- Contador de reproduções recebe endurecimento de transação e diagnóstico; 20 s / 8 min continuam como regra.
- Mantidos Analytics do usuário/artista, ajustes funcionais, Modo Festa, monitor de dados, preload, fades/crossfade, playlists e gêneros canônicos da code101.

# SONUS 0.9.5 / code101

- Redesign do SONUS Stream com cabeçalho simplificado e ações separadas de upload, busca, Analytics e ajustes.
- SONUS Rádio priorizada; home reorganizada com cards compactos e remoção de blocos redundantes.
- Upload de artistas atualizado para File Request pCloud configurável remotamente, processamento MP3 160 kbps, capa 1:1 incorporada e progresso visível.
- Contador do Stream simplificado para view crítica aos 20 s com cooldown de 8 min por UID+música e métricas secundárias desacopladas.
- Analytics do usuário e do artista separados.
- Ajustes funcionais do Stream: atualização automática, preload, fade in/out, crossfade, monitor de dados e Modo Festa reativo ao áudio.
- Gêneros canônicos e seletor predefinido.
- Firebase Rules ampliadas para configuração remota e playlists Stream.
- Workflow CodeMagic atualizado para 0.9.5/code101 e validações estáticas reforçadas.

# SONUS 0.9.4 — code100

- SONUS Stream passa a abrir pelo catálogo em cache e atualizar a fonte pCloud em segundo plano quando possível, reduzindo a sensação de carregamento na troca de tela.
- Contador interno de reproduções válidas preserva a regra de 20 segundos e cooldown de 8 minutos por UID+música; novas métricas horárias alimentam o Studio sem bloquear o áudio.
- SONUS Artist Studio recebe períodos 24h, 7 dias, 15 dias, Mês atual e 90 dias, gráficos por hora/dia, músicas em análise e projeção do mês baseada apenas em dados internos do Stream.
- Acesso do topo é unificado em Studio/Analytics + ajustes, com conceito visual de engrenagem e gráfico; opções redundantes de qualidade/economia de dados foram removidas do painel do Stream.
- Envio de artista migra para a caixa pCloud 🔴 SONUS ARTISTAS via Upload Link. O catálogo oficial de leitura permanece separado.
- WAV/MP3 de entrada são processados localmente para MP3 160 kbps antes do upload; capa 1:1 obrigatória é incorporada ao MP3, sem resolução mínima.
- Letra passa a ser opcional por arquivo .LRC sincronizado ou .TXT comum.
- Firebase Rules code100 adicionam proteção para os novos buckets de Analytics.

---

# SONUS 0.9.2 — code98

- SONUS Rádio ganha interface própria AO VIVO com rewind virtual de até 10 minutos, sem reescrever o motor estável de áudio do Stream.
- Contador de reproduções ganha retry seguro e finalização de sessão para Analytics, sem bloquear a reprodução em falhas do backend.
- Criação de artista evolui para multiartista por `artistId`, preservando compatibilidade com perfis antigos e limites por plano.
- Novo SONUS Artist Studio com reproduções válidas, ouvintes únicos, horas ouvidas, retenção, conclusão/pulos, curtidas, seguidores, origens, horários, crescimento e metas por artista.
- Seguir/curtir passam pelo backend para impedir manipulação direta das métricas.
- Metas e recompensas básicas de progresso foram adicionadas sem monetização, saldo, saque ou promessa de pagamento.
- OWNER recebe diagnóstico dos serviços SONUS Stream; sino e selos FREE/PRO recebem refinamento visual.
- Regras e Cloud Functions code98 acompanham o pacote e precisam ser publicadas no Firebase real após a atualização.

---

# SONUS 0.9.1 — code97

- Mantido intacto o caminho estável de reprodução do SONUS Stream da code96.
- Corrigido fluxo de criação de artista com rota autenticada de backend e fallback compatível.
- Contador de reproduções só confirma play após resposta do backend, sem bloquear o áudio em falhas de estatística.
- Planos comerciais: Free, Prata, Ouro e Diamante; nova carteira de Moedas SONUS e limites por ferramenta.
- Free ganha 1 artista e teste de 7 dias para Distribuição & Pagamentos; Prata 3 artistas; Ouro 8; Diamante ilimitado.
- Barra principal suporta até 6 funções, com cores por função, sino SONUS com contador e indicador simplificado na engrenagem.
- SONUS Stream recebe Pra Você Hoje, Rádio Para Você, rádios por gênero, continuidade virtual, locuções locais e padronização visual de catálogo.
- Impulsionamento de música: 1 dia R$ 0,49; 7 dias R$ 2,99; 15 dias R$ 4,99; 30 dias R$ 7,99; prioridade por gênero e identificação como Patrocinada.
- 25 locuções MP3 integradas; Trap Gospel, Trap e Piseiro têm chamadas específicas e as demais entram no pool geral.
- Regras Firebase/Storage e Cloud Functions code97 acompanham o pacote, mas exigem publicação no projeto Firebase real.

---

# SONUS 0.8.39 — code84

- Sonus Music: streaming pCloud corrigido e diagnóstico real de leitura.
- Conversor de Áudio: metadados persistentes independentes do perfil e prévia de capa.
- SONUS VIDEO: Continuar assistindo corrigido, Link/Online e Legenda ao vivo.
- SONUS PLAYER: Letras/Transcrição ao vivo com TXT/LRC e displays adaptativos.

# SONUS v0.8.38 — code83

- Player principal renomeado para **SONUS PLAYER**, com organização mais limpa entre biblioteca local e streaming.
- **Sonus Music** migrado para catálogo público pCloud, com gêneros, filas contínuas, recentes, favoritos, playlists e cache de catálogo.
- YouTube e Sonus Music passam a ser os dois acessos de streaming destacados no player.
- Painel Desenvolvedor reorganizado em módulos profissionais, preservando Códigos Promocionais, Analytics, Planos, Administração Remota, Ferramentas, Diagnóstico de Mídia, Firebase/Sistema, Comunidade e Logs.
- Controle OWNER para publicar ou ocultar gêneros do Sonus Music.
- Melhorias de estabilidade e encerramento de conexões remotas.

---

## 0.8.37 — code82
- Sonus Music concluído com catálogo por gêneros a partir da pasta pública oficial, cache leve, fila correta e diagnóstico no Painel Desenvolvedor.
- Editor de Metadados de Áudio ampliado com campos avançados, capa incorporada, letras TXT/LRC/clipboard e memória de valores recorrentes.
- Correção do fluxo de salvamento de metadados com saída validada em Música/SONUS/Audio.
- Conversor de Áudio recebe metadados ampliados, capa incorporada e letras nos formatos compatíveis.
- Tags em Lote passa a ser ferramenta de áudio com preservar/aplicar/limpar, capas, letras, títulos individuais e numeração automática.
- Card Tags em Lote movido para o grupo musical dos Destaques e atualizado para a paleta avermelhada aprovada.
- Sobre o SONUS exibe somente as melhorias úteis da versão atual.

## 0.8.34 — code79
-  Splash refinada: nome Sonus reposicionado para cima, cerca de 5% menor e com margem segura contra recorte lateral.
-  DESTAQUES SONUS recebe contraste reforçado atrás dos textos, preservando glass, degradês, ícones e organização aprovados.
-  Nuvem do Player de Música: cards inteiros clicáveis, navegação direta por serviço, pasta principal persistente, várias pastas salvas, conteúdo exibido dentro de cada nuvem e múltiplos favoritos de serviços/músicas.
-  SONUS VIDEO: botão Início removido; barra passa a Vídeos, Nuvem, YouTube, Karaokê e Ajustes, com roxo, azul, vermelho e degradê verde/azul/lilás conforme a função.
-  Galeria de vídeo ganha miniaturas menores e tamanho configurável (Pequena/Média/Grande); Continuar assistindo mantém posição e mostra progresso.
-  Ajustes próprios do Player de Vídeo: pastas de leitura, temas, estatísticas, histórico/favoritos, velocidade, modos de reprodução, timer, bloqueio e perfil de desempenho.
-  Equalizador automático do vídeo classifica por título em Filme/Cinema, Clipe/Música, Jogos, Voz/Podcast/Entrevista, Entretenimento ou Neutro e aplica curvas moderadas; classificação pode ser corrigida e salva por vídeo.
-  Reprodução de vídeo consolida gestos de brilho/volume/seek, duplo toque ±10 s, fullscreen, PiP, 0,5x–3x, controles de proporção e bloqueio.
-  Legendas externas SRT/VTT ganham tamanho, cor, fundo de contraste e ajuste de sincronização; faixas embutidas continuam disponíveis pelo player Media3 quando presentes.
-  Informações técnicas do vídeo passam a mostrar resolução, codecs, FPS, bitrate, canais, duração e tamanho quando o arquivo fornece os metadados.
-  Pastas inteligentes permitem autorizar pastas específicas e ocultar WhatsApp/gravações de tela quando desejado.
-  SONUS passa a se registrar no Android para abrir áudio e vídeo compatíveis; vídeo externo usa Player Rápido dedicado, sem carregar a navegação completa do app, com retomada de posição e PiP.
-  Player de Música recebe identificação independente v0.7 e Player de Vídeo v0.3, separados da versão geral do aplicativo, além de listas individuais de formatos compatíveis.
-  Sobre o SONUS passa a carregar um histórico consolidado das melhorias registradas por versão, e a atualização do histórico entra no fechamento obrigatório de cada pacote futuro.

## 0.8.33 — code78
- Refinamento final da Splash cursiva.
- DESTAQUES SONUS volta à identidade glass/degradê em duas colunas, com catálogo enxuto e ícones próprios.
- Nova ordem principal: Música, Destaques, Vídeo, Ajustes.
- SONUS VIDEO passa a indexar automaticamente a galeria, exibir 3 itens em Continuar assistindo e usar fullscreen dedicado ao vídeo.

# SONUS 0.8.24 (code 69)
- Ajustes ganha a área **Recursos para Artistas**, com Distribuição & Pagamentos e Painéis das Distribuidoras independentes e desativados por padrão.
- Cada recurso pode ser ativado sem ocupar a navegação; a opção **Mostrar na barra principal** permite fixar nenhum, um ou os dois conforme o perfil do usuário.
- Distribuição & Pagamentos foi preservado integralmente: dados, saldo, financeiro, previsões e histórico continuam intactos e a área pode ser aberta pelos Ajustes mesmo sem ficar fixa.
- Novo **Painéis das Distribuidoras** reúne SoundOn, Ditto, DistroKid, TuneCore, FreshTunes, RouteNote, CD Baby, ONErpm, UnitedMasters, Amuse, LANDR, Symphonic e Too Lost em uma interface integrada ao padrão SONUS.
- Cada distribuidora mostra identidade visual, pode ser favoritada e a última utilizada recebe prioridade na organização.
- Painéis abrem o site oficial em uma moldura SONUS sem barra de endereço ou abas de navegador, com opção de abrir externamente quando necessário.
- Modo celular/computador é configurável e persistente por distribuidora; SoundOn inicia em modo computador para melhorar compatibilidade com o painel web.
- Perfis/artistas da mesma distribuidora podem ser alternados pelo cabeçalho; sessões são preservadas por perfil quando o serviço permitir, sem o SONUS armazenar senhas.
- Cookies de sessão mantidos pelo recurso são protegidos pelo Android Keystore e isolados por distribuidora/perfil; a limpeza é limitada ao domínio aberto para não afetar outros WebViews do app.
- Player, áudio, crossfade, MediaSession/Bluetooth, AdMob, Usos Premium, Vídeo → Áudio, Gravador, Login/Convidado, Premium e Dynamic Island permanecem preservados.

# SONUS 0.8.23 (code 68)
- Motor visual SONUS unificado sobre PCM Media3: FFT com janela menor, consumo completo dos buffers PCM, normalização adaptativa e atualização visual interpolada próxima ao refresh da tela para reduzir sensação de travamento.
- O espectro passa por um StateFlow separado do estado principal do Player, evitando recomposição de capa, textos e controles a cada quadro de áudio.
- Pure e Flow mantêm seus layouts e recebem barras mais fluidas; Orbit abandona a linha e usa barras SONUS; Neon Disc também passa às barras padrão.
- Vinyl Glow aumenta a arte central dentro do disco e reposiciona as barras para melhor equilíbrio do espaço.
- Arc Light recebe contraste reforçado e alternância Claro/Escuro por botão rápido dentro da própria interface, com preferência persistida.
- Cassette Retro é reformulado com seis skins SONUS desenhadas no próprio app, capa integrada à etiqueta, VU Meter estéreo reativo e carretéis que representam a transferência de fita conforme o progresso.
- Cassette Retro varia a velocidade angular dos carretéis conforme a quantidade de fita, para reproduzir o comportamento visual de uma fita real; Pause para os carretéis e Seek atualiza imediatamente a distribuição.
- Turntable Classic mantém prato/braço e recebe VU/LEDs com o novo motor fluido.
- Pause mantém as visualizações em tela enquanto elas descem suavemente a zero; Play volta a animar sem salto.
- Intensidade 50–200%, sensibilidade e suavidade Rápida/Equilibrada/Suave permanecem compartilhadas por todas as visualizações compatíveis.
- Temas, botão especial do YouTube, persistência de aleatório/repetição, fila, temporizador, áudio, crossfade, MediaSession/Bluetooth, AdMob, Usos Premium, Vídeo → Áudio, Gravador, Login/Convidado, Premium e Dynamic Island preservados.

# SONUS 0.8.22 (code 67)
- Hotfix code67: corrige parâmetro de duração da animação das interfaces do Player que impedia `compileDebugKotlin`.
- SONUS MUSIC ganha oito interfaces Premium além do SONUS Classic FREE: Pure (Bronze), Flow (Prata), Orbit (Ouro) e cinco interfaces Diamante: Vinyl Glow, Arc Light, Neon Disc, Cassette Retro e Turntable Classic.
- Temas e cores continuam funcionando em todas as interfaces; o botão especial do YouTube permanece acessível em todas.
- Spectro único deixa de ser a única apresentação: cada interface passa a usar barras, waveform, disco reativo ou VU Meter próprios sobre o motor PCM Media3.
- Cassette Retro anima carretéis e VU Meter; Turntable Classic anima prato e braço; vinis/discos param no Pause.
- Visualização reativa ganha interpolação por frame, intensidade 50–200%, sensibilidade e suavidade Rápida/Equilibrada/Suave; Pause zera os valores visuais.
- Ajustes do Player passa a centralizar interface, visualização, temas, crossfade, velocidade, ordem/repetição, temporizador, biblioteca e tela ligada.
- Aleatório e repetição passam a ser persistentes. Biblioteca ganha botões Reproduzir e Aleatório, com início imediato do modo escolhido.
- Última música e posição passam a ser restauradas sem iniciar reprodução sozinha quando o usuário havia pausado/parado.
- Fila ganha Tocar a seguir e Limpar, preservando reorganização e remoção existentes.
- Temporizador passa a oferecer 15/30/60 minutos e Parar ao fim da música.
- Controles Anterior/Próxima recebem contraste explícito por interface; MediaSession para fones/Bluetooth permanece preservada.
- Benefícios dos planos Premium passam a destacar as interfaces exclusivas do Player.
- Player, áudio, PCM Media3, crossfade, AdMob, Vídeo → Áudio, Gravador, Login/Convidado, Premium e Dynamic Island preservados.

# SONUS 0.8.21 (code 66)
- Corrige o fluxo de abertura para manter a splash até estado e autenticação estarem prontos, evitando o quadro preto entre splash e conteúdo.
- Corrige contraste de ícones/textos em temas escuros, com foco em Distribuição e Pagamentos; sino de Destaques passa a dourado.
- Central de Notificações acessada pelo sino mostra somente histórico/ações; configurações ficam em Ajustes > Notificações.
- Notificações externas usam ícone SONUS dedicado e logo oficial quando suportado.
- Card grande de Usos Premium removido de Destaques; Studio mantém marcador compacto e Premium/Ajustes conserva painel detalhado.
- Nova franquia global: FREE 20, Bronze 70, Prata 200, Ouro 500, Diamante ilimitado; migração de política renova corretamente instalações existentes.
- Ferramentas úteis de Destaques passam a usar o saldo Premium; Karaokê permanece livre. Falha/cancelamento não consome.
- Conversor de áudio e conversor de imagens em lote passam a descontar 1 uso por arquivo/imagem concluído, respeitando o saldo disponível.
- AdMob Rewarded é pré-carregado após consentimento/SDK, recarrega automaticamente após exibição/falha e mostra estado de carregamento quando necessário.
- Spectro passa a priorizar PCM Media3 com TeeAudioProcessor e FFT SONUS, watchdog contínuo e fallbacks Native/PCM Compat, sem depender de microfone.
- Diagnóstico do motor do Spectro fica restrito ao OWNER.
- Player, áudio, crossfade, Vídeo → Áudio, Gravador, Login/Convidado, Premium e Dynamic Island preservados.

# SONUS 0.8.20 (code 65)
- Hotfix code65: corrige chamada de `SettingsToggleRow` da Central de Notificações e referências do saldo global no `ToolHub` que impediam `compileDebugKotlin`.
- Franquia Premium passa a ser global: FREE 10, Bronze 100, Prata 250, Ouro 500 e Diamante ilimitado.
- FREE pode repor +1 Uso Premium por anúncio recompensado, sempre respeitando o teto de 10/10.
- O antigo Passe SONUS 24h deixa de ser oferecido; rewarded ads passam a alimentar somente o saldo FREE de Usos Premium.
- Novo painel de Usos Premium com saldo, progresso, renovação, histórico, ritmo de consumo e sugestão de upgrade quando o saldo tende a acabar antes do ciclo.
- Central de Notificações interna com sino em Destaques, badge, histórico por data, leitura/exclusão e atalhos para a tela relacionada.
- Notificações externas ficam reservadas a eventos importantes; categorias e horário da previsão diária podem ser configurados.
- Marcos financeiros são registrados de R$ 50 em R$ 50 por distribuidora sem repetir o mesmo marco; previsão externa fica limitada a um resumo diário.
- AdMob Rewarded e consentimento UMP preparados; anúncios reais exigem ativação explícita por `SONUS_REAL_ADS=true`, mantendo o bloco oficial de teste por padrão.
- Ferramentas Premium passam a descontar uso apenas após sucesso e bloqueiam nova execução ao zerar o saldo, evitando consumo duplicado ou operação grátis por falha de débito.
- Identidade pública SONUS e `applicationId=com.sonusstudios.streampulse` preservados.

# SONUS 0.8.19 (code 64)
- Spectro preserva o visual aprovado e ganha compatibilidade automática Native → PCM Compat → Fallback, com detecção de callbacks zerados/congelados e correção do waveform unsigned em firmwares Android.
- PCM Compat passa a analisar apenas blocos progressivos do áudio, fora da UI, com cancelamento, cache limitado e isolamento para que o Spectro nunca interrompa a reprodução.
- Streams, Saldo, Pulso ao Vivo, Histórico, Análises, Financeiro, insights e projeções passam a usar o motor unificado do ciclo e exibem valores desde o primeiro registro.
- Estimativas financeiras positivas usam piso visual de R$ 0,02; o Pulso troca “calibrando” por um indicador simples de Precisão.
- Atraso de dados atualiza a data de referência exibida no campo para Total do período e Valor do dia; se a data atrasada cair no ciclo anterior, o registro é atribuído ao ciclo correto. Registro retroativo fica separado e limitado ao ciclo.
- Artistas passam a aceitar foto individual da galeria e Avatar SONUS, preservando perfis antigos sem imagem.
- Avatar SONUS estreia com 60 desenhos 2D vetoriais e resolução independente: 10 instrumentos FREE, 10 flores Bronze, 10 animais Prata, 10 personagens originais Ouro e 20 opções Cosmos Diamante.
- Trocas de Avatar SONUS são ilimitadas dentro do plano e não consomem usos mensais.

# SONUS 0.8.18 (code 63)
- Modo convidado FREE: acesso ao player, Destaques, Studio e funções locais sem login obrigatório.
- Login passa a ser solicitado antes de dados de distribuição, Backup Online, código promocional e compras Premium, com retorno ao fluxo iniciado.
- Tela de login usa o símbolo oficial SONUS no lugar do antigo Pulse Audio.
- Vídeo → Áudio removido do Studio e destacado ao lado do conversor de imagens.
- Correções no Vídeo → Áudio: leitura da faixa, permissões URI, MIME correto, fallback MP3, salvamento e erros amigáveis.
- Cards principais dos Ajustes mantêm o layout aprovado e recuperam cores translúcidas por função.

# SONUS 0.8.17 (code 62)
- SONUS MUSIC redesenhado: capa maior, novo Spectro SONUS único e progresso percentual.
- 8 paletas do Spectro; Dynamic Color e Dynamic SONUS+ adaptativo à capa.
- Ajustes simplificados e limpeza de opções redundantes.
- PulseTune passa a SONUS TUNE.
- Premium reformulado com franquia por ferramenta, novos preços e limites de artistas.

# SONUS v0.8.15 • code60

Pacote de consolidação: entrada de streams por total/per-dia com atraso configurável; histórico focado em streams; Pulso refletido no saldo estimado; conversor de áudio livre; ferramenta PRO unificada para converter/redimensionar imagens em lote; limpeza de ferramentas duplicadas.

# SONUS v0.8.12 (code57)

- Dynamic Island: tamanho expandido reduzido, slider de largura centralizado, novo slider de altura, topo/status bar, layout de câmera reorganizado, translucidez automática e encerramento em até 4s após pausa/fim.
- Progresso: conversor compartilha o mesmo percentual com Dynamic Island/notificação.
- Studio: remove Conversor de Áudio duplicado e Capa Pro; ordenação FREE → Bronze → Prata → Ouro → Diamante.
- Conversor: fallback adicional de encoder para saída MP3.
- Redimensionador: presets retangulares, modo Esticar, destino SONUS/Images ou pasta personalizada persistente e correção do fluxo de salvamento.
- Visualizer: rascunho automático após alterações reais.
- Ícones: fundo preto universal, 28 estilos por plano e splash acompanhando o tema selecionado.

# SONUS v0.8.10 (code55)

- Hotfix completo pós-code54: conversor em lote, saída automática SONUS, Dynamic Island overlay, filtros de estatísticas, monetização Free/Premium/SONUS COINS, Lab/AutoMix e exportação real do Visualizer.
- SONUS BOOST™ e SONUS SPATIAL™ livres em todo o fluxo público.
- Crossfade aprovado na code54 preservado sem alteração de lógica.

# Sonus 0.8.3 (code 48) — 28/08/2026

- Corrige enquadramento do ícone principal para evitar recorte/zoom no launcher.
- Nova splash Sonus em Compose: símbolo entra suavemente, SONUS é escrito letra por letra e o conteúdo desaparece com fade antes da interface.
- Tela de restauração passa a usar o símbolo Sonus sem bloco quadrado.
- Selos Free/Bronze/Prata/Ouro/Diamante do Studio foram movidos para o canto superior direito dos cards, fora do desenho central.
- Todas as variações de ícone do seletor agora usam a identidade oficial Sonus, com enquadramento seguro e diferenciação por plano.
- Removedor Vocal permanece fora das áreas públicas.
- Pulse Transcribe permanece fora das áreas públicas.
- applicationId preservado.

# Pulse Studio 0.7.11 (code 43) — 26/08/2026

- Painéis inferiores alinhados à área segura do Android e mais compactos.
- Texto com subpainéis horizontais e transição suave, sem conteúdo escapando abaixo da tela.
- Sliders compactados.
- Snapping leve para áudio e faixas temporais.
- Exportação mostra dimensão real do canvas e ganhou progresso circular Pulse com percentual/fase/ETA.

# 0.7.10 (code 42)
- Estabilização de exportação por canvas/proporção, seleção de camadas, painéis horizontais e compatibilidade ampliada do Pulse Transcribe.

# Pulse Studio 0.7.8 — code 40

- Estatísticas locais por período e por módulo.
- Monitor de dados ampliado com RX/TX, velocidade real e histórico.
- Diagnóstico de build/dispositivo/codecs no painel OWNER.
- Editor com barra principal contextual no rodapé, confirmação, undo/redo inferior e handles maiores.
- Contrato inicial Pulse FX para overlays Screen/Add e pacotes baixáveis.

# Pulse Studio 0.7.7 — Editor Core Rebuild

- Canvas do projeto passa a ser aplicado de verdade no export via Media3 Presentation.
- Fit/Preencher persistido no rascunho e usado no preview/export.
- Exportação com progresso real, cancelamento, bitrate por resolução/FPS e validação pós-render de resolução/duração.
- HDR só aparece disponível quando há caminho HEVC compatível.
- Filtros/ajustes principais passam para Effects do Media3; Preto e Branco usa grayscale real.
- Efeitos temporais e texto também são renderizados no arquivo final.
- Legendas/captions entram como overlays temporais no export; modelos de visualizer agora mantêm comportamento por estilo no arquivo final.
- Visualizer usa análise PCM/FFT real de 2048 pontos e a mesma análise timestampada no preview/export.
- Áudio respeita offset de timeline no Composition por gap inicial.
- presets_pulsestudio.json incorporado ao app como contrato de parâmetros.
- Saturação visível usa escala 0–200% com neutro em 100%.


## 0.7.4 — code36
- Editor imersivo somente durante projeto aberto; Home mantém navegação principal.
- Photo Picker direto e seleção múltipla.
- Trim/duração de fotos mais sensível.
- Texto funcional com fontes/presets, cores e animações.
- Legendas manuais + automática beta local.
- Overlay de imagem, 50 efeitos, 50 filtros, ajustes independentes e proporções sociais.
- Audio Visualizer ampliado com novos modelos e partículas.
- Rascunhos passam a persistir o novo estado do editor.

# Pulse Studio 0.7.0 — code 32

- Início do Pulse Video Editor com preview, timeline P0, trim/split não destrutivos e export MP4 básico.
- Áudio Visualizer circular com análise PCM local, BPM estimado, partículas, cores neon, logo central e fundo por imagem.
- Compatibilidade do espectro do Player reforçada com fallback PCM independente do AudioFX Visualizer do fabricante.
- Barra do editor reorganizada pelas ferramentas de maior uso.
- Firebase Rules e applicationId preservados.

# 0.6.1 — code 31

- Correção reforçada do autoplay: intenção de reprodução controlada no serviço e pausa preventiva na entrada/navegação quando desativado.
- Nova opção Reprodução automática no Player, desativada por padrão.
- Player do YouTube recebe Histórico e Favoritos locais persistentes.
- Splash refinada para ~2 s, textos brancos, animação própria em Compose e sem emojis de sistema.
- Logo oficial e todas as variações de launcher passam a ter enquadramento mais próximo e legível.
- Cache persistente da biblioteca e atualização em segundo plano preservados.

# 0.6.0 — code 30

- Compatibilidade ampliada dos visualizadores com fallback FFT/waveform.
- Biblioteca persistente com carregamento imediato e atualização em segundo plano.
- Correção do autoplay involuntário ao retornar ao Player.
- Swipe nos visualizadores com tutorial automático não intrusivo.
- Redesign categorizado da aba Ferramentas.
- PulseTune™ Bronze+ com afinador local AudioRecord/YIN e painel próprio.
- Pulse Transcribe Prata+ e geração/cache de letras locais no Player.
- Novos Stem Splitter, Voice Cleaner, Metrônomo Pro e Detector BPM & Tom.
- Assinatura tátil Pulse configurável.

## 0.5.1 (28) — Qualidade, áudio e ferramentas Pro

- Pulse Player ganha visualizadores FFT reais com 34 estilos distribuídos entre Free, Bronze, Prata, Ouro e Diamante.
- PulseLift™ recebe perfis Natural / Boost / Max, com reforço de graves, loudness e preservação de presença vocal.
- Ícone do Pulse Studio passa a ter variações por plano, sem consumo de Pulse Coins.
- Gravador de Voz Pro e Removedor Vocal migram para Destaques e deixam de duplicar a aba Ferramentas.
- Gravador de Voz Pro recebe visual vermelho, waveform/VU destacados, ASMR e finalização PulseLift Boost.
- Removedor Vocal recebe player A/B no topo, separação Natural/Equilibrada/Forte, preservação de graves e prévia processada completa.
- Alterar Tom Pro recebe player integrado, cents, velocidade independente, loop A–B e memória de tom favorito.
- Originais continuam imutáveis; exportações criam novas cópias e Pulse Coins só são debitadas após sucesso.
- `versionName=0.5.1`, `versionCode=28`.

# Pulse Studio Changelog

## 0.5 (27) — Nova identidade e Creator Hub
- Rebrand público de StreamPulse para **Pulse Studio**, preservando applicationId, assinatura, Firebase e compatibilidade de backup.
- Novo logotipo oficial Pulse Studio aplicado à abertura, launcher e identidade visível.
- Navegação principal reorganizada em Player, Destaques, Ferramentas, Vídeo, Ganhos e Ajustes.
- Pulse Player passa a ser a abertura do app; Karaokê e Conversor de Áudio formam Destaques; Ferramentas deixa de duplicar os três.
- Editor de Vídeo ganha aba própria preparada para evolução posterior.
- Antigo núcleo de streams/analytics/financeiro vira módulo opcional **Ganhos & Distribuição**, com gestão de artistas no topo.
- O uso de Player/Ferramentas deixa de exigir cadastro de artista/distribuidora; restauração em nuvem e presets do Conversor foram adaptados para esse cenário.
- Conversor de Áudio passa a ser contextual: com artista/distribuidora cadastrados mostra o perfil e recomendações da distribuidora; sem cadastro opera em **Modo livre** com padrões genéricos do Pulse Studio.
- Passe Pulse 24h integrado às funções elegíveis por anúncio recompensado voluntário: PulseLift™, PulseOrbit™ 3D/8D, Removedor Vocal padrão, Alterar Tom Pro, Mesclar Pro e Vídeo → Áudio Pro, sem liberar o plano inteiro.
- Bloqueios Premium também são aplicados no serviço do Pulse Player para evitar que ações da notificação contornem o plano/passe ativo.
- Todos os planos pagos ficam sem anúncios comuns; o Free mantém rewarded voluntário. O antigo Remove Ads deixa de ser um plano comercial.
- Pulse Player recebe Home compacta, menu lateral redesenhado, atalhos EQ/PulseLift/PulseOrbit/Biblioteca, dupla confirmação ao sair, notificação própria, fila, estatísticas ampliadas, velocidade 0,5x–2x e loop A–B.
- Modo YouTube integrado ao Pulse Player com player oficial e fila Sempre Tocando enquanto a tela está visível, sem extração de áudio/background indevido.
- Planos públicos passam a Free, Bronze, Prata, Ouro e Diamante, com franquias de 30/60/200/500/ilimitadas Pulse Coins.
- Preços de referência: Bronze R$ 6,90; Prata R$ 14,90; Ouro R$ 21,90; Diamante R$ 39,90, com anuais R$ 69,90 / R$ 149,90 / R$ 219,90 / R$ 399,90.
- Temas do Pulse Player reorganizados por nova hierarquia de planos e coleção exclusiva Diamante.
- Backups novos identificam Pulse Studio, mantendo leitura de backups StreamPulse anteriores.
- Firebase Realtime Database Rules permanecem v1.9.4, sem republicação necessária neste pacote.
- `versionName=0.5`, `versionCode=27`.

## Histórico anterior

## 1.9.5-beta (26) — Pulse Player + Creator Suite
- Pulse Player estreia como primeiro e maior destaque de Ferramentas; Karaokê passa ao segundo lugar e Conversor de Áudio ao terceiro.
- Biblioteca musical local por pasta raiz persistente, varredura recursiva, busca, pastas/álbuns/artistas/gêneros, curtidas, fixadas, recentes e mais tocadas.
- Fila editável com reordenação/remoção, playlists locais, Smart Mix, shuffle/repeat, reprodução encadeada sem lacuna quando compatível, crossfade 0–12 s, sleep timer, reprodução em segundo plano, MediaSession e controles por notificação/headset.
- Estatísticas locais do Pulse Player: tempo ouvido, execuções, conclusões, pulos, horário favorito, top faixas/artistas/gêneros e atividade diária.
- Letras locais `.lrc`, compartilhamento, pastas ignoradas e Creator Mode com atalhos para ferramentas do StreamPulse.
- Equalizador do Pulse Player com presets, Graves/Médios/Agudos, 10 bandas, PulseLift™ e PulseOrbit™ 3D/8D.
- 38 temas do Pulse Player: 8 Free, 5 Plus, 10 Studio e 15 Max; `Pulse Signature` fecha a coleção Max.
- Novo miniapp Vídeo → Áudio com exportação multiformato conforme suporte do FFmpeg local.
- Novo Mesclar Áudio para 2+ arquivos com ordem, junção direta, crossfade ou intervalo.
- Novo Alterar Tom por semitons/cents com preservação de andamento e preview.
- Novo Removedor Vocal local com Instrumental/Voz, redução de ruído e PulseLift opcional; a versão 1.9.5 usa DSP estéreo/centro e não promete separação neural perfeita.
- PulseOrbit™ também passa a integrar o Conversor de Áudio para processamento 3D/8D próprio, sem nomenclatura Dolby/Atmos.
- Ferramentas secundárias recebem cards mais baixos e compactos.
- 14 novos temas gerais: Slate, Ocean, Forest; Violet Pulse, Sunset, Midnight Cyan; Neon Studio, Crimson Pro, Aurora Pro; Cyber Pulse, Royal Gold, Glass Horizon, Nebula e Infinity.
- Novas operações concluídas relevantes registram eventos no Histórico 360°; plays individuais permanecem nas estatísticas internas do Player.
- Firebase Realtime Database Rules permanecem exatamente as regras v1.9.4 já publicadas.
- applicationId e assinatura preservados; versionCode 26; versionName 1.9.5-beta.

## 1.9.4-beta (25) — correções pós-instalação
- Financeiro SoundOn recalibrado pela referência real confirmada de R$ 329,50 / 29.500 streams, com novos pagamentos reais refinando a estimativa.
- Calibração por pagamentos anteriores na aba Financeiro: mês retroativo sugerido automaticamente, usuário informa apenas o saldo; 5+ pagamentos elevam a confiança da média.
- Pagamentos retroativos são anexados ao Histórico 360° sem substituir registros existentes e não alteram a data de referência operacional da distribuidora.
- Pulso ao Vivo agora usa exatamente o mesmo Ritmo recente da projeção principal; removida a fórmula paralela que gerava valores diários fora da curva.
- Informação duplicada de Ritmo recente foi retirada de “O que mudou?” e o bloco passa a indicar que o Pulso usa a mesma projeção.
- Firebase Owner: leitura administrativa de couponSlots/couponReservations corrigida nas regras para eliminar Permission denied ao listar cupons/diagnóstico.
- Área Firebase/Infraestrutura deixa claro que métricas globais avançadas estão em preparação sem parecer falha do app.
- Schema local atualizado para 14 mantendo compatibilidade por campos com defaults.

## 1.9.3-beta (24)

- Conversor Pro mais compacto: saída e metadados lado a lado, EQ recolhível e PulseLift mais enxuto.
- Player rápido no Conversor para ouvir o arquivo antes dos ajustes e manter a pré-escuta A/B.
- Karaokê com visual de palco, monitor discreto de dados e gravação automática do microfone durante a apresentação.
- Karaokê encerra a apresentação quando o player oficial sinaliza fim do vídeo; gravação pode ser ouvida, salva em M4A/AAC ou descartada.
- Pulso ao Vivo passa a projetar somente diferenças diárias reais, com maior peso para dias recentes e fallback para ciclo anterior.
- Motor financeiro usa rendimento efetivo recente + histórico calibrado, sem apresentar taxa fixa oficial por stream.
- Histórico 360°: mantém streams no topo e adiciona atividades pessoais, filtros, resumo e mapa de atividade de 28 dias.
- Painel Owner ganha Central Firebase segura: diagnóstico do cliente e consumo da sessão; métricas globais ficam explicitamente dependentes de backend Cloud Monitoring protegido.
- Ajustes > Dados e rede: monitor de tráfego, alerta móvel e preferência por Wi‑Fi para operações grandes.

# 1.9.2-beta (23)

- Conversor Pro: seleção múltipla e por pasta/álbum; Free até 10 músicas por lote e Plus+ sem limite de quantidade por lote.
- Conversor Pro: perfis de distribuidora passam a ser recomendações; formatos adicionais WAV/FLAC/MP3/M4A/AAC/OGG/OPUS/AIFF ficam disponíveis.
- Equalizador: presets Flat/Rock/Pop/Classical/Hip-Hop/Jazz com 10 bandas 32 Hz–16 kHz, controles Graves/Médios/Agudos, modo avançado e curva em tempo real.
- PulseLift Signature v1: processamento adaptativo local próprio com limpeza moderada, controle tonal, compressor glue, widening estéreo conservador e limiter de proteção; Free desbloqueia por Rewarded Ad e Plus+ inclui o recurso.
- Conversor Pro: prévia A/B Original x Processado antes da exportação e memória local do último uso.
- Analisador: LUFS, true peak, crest factor, clipping, waveform e velocímetro de saúde técnica.
- Cortador Pro: nova apresentação, tempos manuais de início/fim, waveform, fades e sugestão automática local.
- Preview: um único player compartilhado impede sobreposição de áudio; cortes 15/30/60 s podem ter início ajustado antes de salvar.
- Metadados: capa incorporada, mais campos, substituição de artwork em formatos compatíveis e limpeza dos campos antes de salvar nova cópia.
- Capa: interface enriquecida com diagnóstico da imagem, alerta de baixa resolução e prévia de enquadramento.
- Ferramentas: miniapp Lançamento/Áudio+Capa removido da navegação; funções úteis permanecem distribuídas entre Conversor, Metadados e Capa.
- versionCode 23; versão 1.9.2-beta.

# 1.9.1-beta (22)

- Karaokê: troca do WebView manual por player Android dedicado baseado na IFrame Player API oficial; um único player é reutilizado ao trocar de resultado.
- Karaokê: Play/Pause, qualidade informativa e rotação ficam fora da área do vídeo; falhas aparecem dentro do quadro preto e não fecham o app.
- Karaokê: watchdog de player sem resposta e tratamento amigável de vídeo não incorporável/indisponível.
- Karaokê: pontuação não é gerada para silêncio/trecho curto; mínimo de voz real, velocímetro animado, Voz/Estabilidade/Ritmo/Energia e reações visuais por faixa.
- Owner: cupons deixam de esconder erros Firebase; editor permanece aberto em falha, exibe status ativo/pausado/expirado/esgotado e reforça cupons limitados por slots.
- Owner Analytics: registrados, online, ativos hoje/7d/30d, novos 7d/30d, rankings de ferramentas e páginas por período e diagnóstico de falhas.
- Premium: cards agora abrem fluxo de escolha Mensal (30 dias) ou Anual (1 ano) separadamente; cobrança Google Play permanece desativada até a etapa de monetização.
- Rewarded Ads: botões de ganhar +1 Pulse Coin ficam visíveis/preparados na suíte e no Conversor; beta continua usando anúncio oficial de teste.
- Ferramentas: Calculadoras YouTube/TikTok saem da Home e entram como miniapps; grade de 3 colunas fica mais baixa/compacta sem alterar os dois cards principais.
- Estabilidade: atualização leve de atividade ao retomar o app, aviso offline global, Sobre/Versão com diagnóstico copiável e mensagens de erro online mais explícitas.
- versionCode 22; versão 1.9.1-beta.

# 1.9.0-beta (21)

- Ferramentas: Conversor mais compacto e Karaokê em card de destaque com anel RGB animado em Compose.
- Ferramentas: grade compacta de 3 colunas para Analisador, Cortador, Preview, Gravador, Lançamento, Metadados e Capa.
- Karaokê: player oficial do YouTube reconstruído com IFrame API em WebView, base URL/Referer do applicationId, cookies e diagnóstico de erros/recarregamento.
- Cupons limitados: novo sistema de slots pré-criados, sem `numChildren()`, com 1 resgate por UID e limite global exato.
- Firebase: novas regras para `couponSlots` e `couponReservations`; analytics de cupons passa a contar slots consumidos.
- Estabilidade: falhas de analytics/Firebase na inicialização não derrubam a Home nem prendem o usuário no loading.
- Conta: exclusão de dados online deixa de depender de escrita multi-path na raiz.

# StreamPulse Changelog

## 1.8.1-beta (19)
- Karaokê: pesquisa pública do YouTube agora ocorre dentro do StreamPulse pela YouTube Data API v3.
- Karaokê: resultados exibem título, canal e thumbnail; apenas vídeos incorporáveis/sindicados são solicitados.
- Karaokê: player oficial incorporado do YouTube dentro da tela, sem scraping, download ou bloqueio de anúncios.
- Segurança: chave do YouTube é injetada pelo GitHub Actions via `YOUTUBE_API_KEY` e as chamadas enviam identificação Android (package + SHA-1).
- Pesquisa somente mediante toque em Pesquisar e com cache leve em memória para reduzir chamadas repetidas.

# StreamPulse v1.8.0 Beta

- Grande atualização da suíte StreamPulse: painel Owner remoto, gerador/gerenciador de cupons, analytics administrativo e métricas reais de usuários.
- Pulse Coins unificadas: Free 50, Plus 100, Studio 200, Max/Owner ilimitado; bônus separados da franquia mensal.
- Rewarded Ads + UMP preparados com anúncios de teste em beta e bônus temporário 2x por cupom/evento.
- Backup online por UID, restauração, APAGAR dados e exclusão de conta com confirmação e reautenticação.
- Ferramentas em grade de miniapps: Analisador, Cortador Pro, Previews 15/30/60, Metadados, Preparador de Lançamento, Conversor de Capa, Gravador Pro e Karaokê, além do Conversor de Áudio.
- Gravador Pro: waveform, MB/armazenamento/tempo restante, dispositivos de entrada, presets, sample rates altos, 16/24/32-bit com fallback, multicanal real quando o hardware expõe 5.1/7.1, ruído/voz e exportação multiformato.
- Pulso ao Vivo com estimativas animadas sem contaminar dados reais, além de inteligência de distribuidoras, recordes e conciliação financeira.
- Paleta global escurecida e progressão preto/vermelho/roxo/laranja/verde/azul; velocímetro mantém amarelo como faixa adicional.
- Cor/estilo do texto gratuita com modo dinâmico e personalização sem fechar diálogo nem perder posição de rolagem.
- Regras Firebase ampliadas para backups, analytics, cupons, resgates, claims e configuração pública.
- versionCode 18; versão 1.8.0-beta.

# StreamPulse v1.7.2 Beta

- Autorização remota OWNER via Realtime Database em `/roles/<uid>`, validando `role=OWNER` e `active=true` após o login.
- Painel do Desenvolvedor permanece totalmente invisível para contas comuns e só aparece em Ajustes quando o Firebase confirma OWNER.
- Conta Owner recebe selo próprio no perfil, acesso equivalente ao Max, artistas ilimitados e conversões de áudio ilimitadas sem consumo de moedas.
- Painel inclui simulador local de Free, Plus, Studio, Max e Owner para testar limites sem alterar o papel real no Firebase.
- Ferramentas de teste da carteira: zerar, adicionar moedas e restaurar a cota do plano simulado.
- Botão para verificar novamente a autorização remota sem precisar sair e entrar na conta.
- Regras locais do Realtime Database atualizadas para permitir que cada UID leia somente o próprio papel e impedir escrita em `/roles` pelo app.
- Base de bypass de anúncios para OWNER preparada; integração efetiva do SDK de Ads continua na próxima etapa.
- versionCode 17; versão 1.7.2-beta.

# StreamPulse v1.7.1 Beta

- Login oficial adicionado com Firebase Authentication: Google, e-mail/senha, criação de conta e recuperação de senha.
- Sessão persistente: após autenticar, o app volta direto para a Home nas próximas aberturas; sessão já salva continua permitindo acesso local sem internet.
- Migração da presença online: deixa de criar login anônimo e passa a usar somente o UID da conta autenticada, sem enviar dados musicais ou financeiros.
- Área de conta em Ajustes com nome, e-mail, foto do Google quando disponível, status Free e opção segura de sair sem apagar dados locais.
- Estrutura interna preparada para USER/OWNER; o Painel do Desenvolvedor ainda não aparece nesta versão e será autorizado remotamente após identificar o UID do desenvolvedor.
- Conversor redesenhado na aba Ferramentas como bloco compacto laranja e deixa de ser marcado como recurso Plus.
- Tags do conversor simplificadas: título automático pelo arquivo, artista automático, ano automático e apenas álbum, gênero e compositor editáveis/salváveis no preset.
- Progresso real da conversão conectado às estatísticas do FFmpeg, com percentual animado, etapas visuais e duração mínima de 5 segundos antes de concluir.
- Carteira de moedas do conversor preparada por conta: Free 5/mês, Plus 30/mês, Studio 40/mês e Max 100/mês; 1 moeda é consumida somente após conversão concluída com sucesso.
- Anúncios premiados ainda não são exibidos nesta versão; a recarga de moedas por Ads entra na próxima etapa junto do modo Owner.
- Schema local atualizado para 10; versionCode 16; versão 1.7.1-beta.

# StreamPulse v1.7.0 Beta

- Nova abertura visual do app com splash StreamPulse e carregamento em aproximadamente 4 segundos.
- Atualização de streams com feedback visual progressivo de 1,5 a 4 segundos conforme a base do ciclo.
- Saúde do Projeto reiniciada por ciclo, com pontuação positiva distribuída para fechar exatamente em 100 em um ciclo perfeito e faixas negativas -3/-2/-1.
- Velocímetro refinado, com rótulos acima dos valores para evitar sobreposição com os ponteiros.
- Home mais compacta e YouTube/TikTok posicionados logo abaixo do velocímetro.
- Calculadoras Max de YouTube e TikTok com cenários, nichos, formatos e histórico separado das distribuidoras.
- Nova aba Ferramentas com conversor local de áudio Plus, presets por artista, tags e validação por distribuidora.
- Perfis de áudio das 13 distribuidoras, incluindo WAV/MP3/FLAC para Ditto conforme evidência adicional fornecida.
- Guia do StreamPulse no fim de Análises, explicando funções sem expor fórmulas internas.
- Compras e Play Billing permanecem fora desta versão; recursos Premium continuam em modo beta/demonstração.

# StreamPulse Changelog

## v1.6.1-beta
- Home reorganizada: indicadores principais sobem; ações, alertas, Raio-X, YouTube/TikTok e precisão vão para o fim.
- Cards principais mais achatados e compactos; Saúde levemente reduzida.
- Velocímetro duplo de Atividade/Ritmo retorna à Home em formato compacto.
- Financeiro reorganizado por blocos relacionados; histórico financeiro, resultado antes de custos e ciclo atual removidos da tela.
- Projeções de 30/90 dias, 6/12 meses e 2/5/10 anos agrupadas.
- Metas anuais movidas para o fim e compactadas com detalhes expansíveis.
- Histórico passa a mostrar todos os registros do período, modo Ciclo e arquivo de ciclos anteriores.
- Novos temas grátis: Xadrez, Amarelo suave, Marrom suave, Laranja suave e Prata.
- Novos temas Max: Dourado, Céu e Space. Foto personalizada deixa a lista de temas e permanece em Foto no fundo.
- Ajustes: tocar no artista apenas seleciona; lápis separado abre edição.
- Novo painel local Uso do app StreamPulse com tempo, entradas, média diária, Premium restante, maior sessão e último acesso.
- Botão Voltar do Android respeita telas internas e nova navegação por deslize entre as 5 abas principais.
- Limites de artistas mantidos: Free 3, Plus 5, Studio 10, Max ilimitado.

# v1.6.0-beta

- Central Premium totalmente clicável em modo demonstrativo, com planos Remover anúncios, Plus, Studio e Max e botões “Em breve”.
- Limites planejados atualizados: Free 3 artistas, Plus 5, Studio 10 e Max ilimitado; Removedor prevê 4º artista via anúncio premiado.
- Selo FREE redesenhado para corrigir o badge bugado no perfil; Plus, Studio e Max mantêm selos gráficos próprios.
- Botão Premium movido para perto de Metas em Ajustes, com destaque dourado e animação leve isolada.
- Temas Premium novos: Arco-íris, Monocromático, Rosa, Lilás, Preto profundo, Aurora azul/lilás/rosa, Foto personalizada e Profissional.
- Tema Dinâmico volta a se mover suavemente através de uma camada de fundo isolada, evitando recomposição global da interface.
- Foto personalizada de fundo com escurecimento automático para preservar contraste; incluída no backup ZIP.
- 20 novos estilos de fonte Premium, divididos entre Plus, Studio e Max, todos identificados por selo e sem preço na lista de fontes.
- Raio-X do Projeto Plus adicionado à Home.
- Blocos Max demonstrativos de calculadora YouTube e TikTok adicionados à Home com modos por vídeo/mensal e futuro filtro por nicho.
- Análises Studio: Simulador de Meta, Auditoria do Ciclo, Detector de Anomalias e Comparador de Artistas.
- Financeiro Plus: Meta anual de ganhos individual com confirmado x estimado diário e PDF de 1 ano.
- Financeiro Studio: Meta geral da carteira e projeções de 6 meses/1 ano para artista e todos os artistas.
- Financeiro Max: projeções de 2, 5 e 10 anos, cenários conservador/provável/otimista e Planejamento Financeiro.
- Recursos Premium existentes permanecem liberados nesta beta para teste; compras e bloqueios reais ainda não estão ativos.
- Schema local atualizado para 7; versionCode 13; versão 1.6.0-beta.

# v1.5.3-beta

- Selos gráficos de plano no perfil: Free, Plus, Studio e Max.
- Infraestrutura visual pronta para marcar recursos premium por nível.
- Limites de artistas preparados por plano: 5 / 6 / 8 / ilimitado.
- Hero da Home com degradê estático mais profundo e suave.
- Removidas animações infinitas globais de tema, cards e resumo financeiro para reduzir jank.
- Variante beta debug otimizada com R8 e resource shrinking, preservando a assinatura de atualização.

# StreamPulse changelog

## 1.5.0 Beta
- Histórico totalmente redesenhado para mostrar apenas evolução de streams.
- Seletor de 7, 14 e 30 dias.
- Gráfico principal interativo com linha/área em degradê, média do período e seleção por toque.
- Indicadores compactos de dias registrados, dias sem dados e intervalo exibido.
- Registros recentes com mini barras, streams e variação percentual; toque abre detalhe do dia.
- Primeira arquitetura online adicionada sem tornar internet obrigatória.
- Badge discreto na Home preparado para mostrar total de usuários e usuários online.
- Firebase Authentication anônimo + Realtime Database preparados para presença em tempo real.
- Quando Firebase ainda não está configurado, o badge fica offline e todas as funções locais continuam normais.
- Nenhum dado musical/financeiro é enviado pela camada de presença.
- FIREBASE_SETUP.md e regras beta do Realtime Database incluídos.
- VersionCode 9; versão 1.5.0-beta.

## 1.4.1 Beta
- Análises redesenhada para remover indicadores repetidos da Home.
- Comparações exclusivas em janelas de 3, 7 e 14 registros, evolução diária, recordes, oscilações e sequências.
- Financeiro refinado: resumo financeiro, crescimento financeiro, precisão histórica, análise detalhada de meta e ciclo compacto.
- Ajustes redesenhado em cartões compactos com identidade visual do StreamPulse.
- Artistas continuam em avatares horizontais; metas, tema, fonte, análise e backup ficaram mais compactos.
- Ciclo e distribuidora movido para a área de informações e referência, próximo de Sobre as distribuidoras.
- Relatórios em PDF permanecem exclusivamente no Financeiro para evitar duplicação.

# StreamPulse 1.4.0 Beta

- Ciclos deixa a navegação principal; entra a nova área Financeiro.
- Dashboard financeiro com cards orgânicos, meta, recebido, crescimento, precisão, melhor ciclo, fechamento, distribuição por artista/distribuidora, histórico, projeções e resumo inteligente.
- PDF financeiro disponível para ciclo, 30 dias e 90 dias.
- Backup ZIP local com manifest, dados e fotos; restauração com prévia/validação.
- Artistas em bolhas compactas e ordem alfabética; limite gratuito de 5 artistas.
- Ações do artista centralizadas no avatar: editar nome/distribuidora, foto e exclusão.
- Temas Dinâmico, Claro, Escuro, Azul, Verde e Vermelho.
- Cinco opções de fonte, incluindo Digital.
- Registro retroativo sugere automaticamente o dia vazio mais recente dentro da janela de 15 dias.
- Porcentagens do painel automotivo movidas para a área superior, liberando o ponteiro.
- Premium ✨ preparado visualmente, sem fluxo de compra.
- Schema local atualizado para 6; versionCode 7.

# StreamPulse 1.3.2 Beta

- Percentuais do cluster automotivo reduzidos para melhorar leitura.
- Títulos Atividade e Ritmo da meta movidos para abaixo dos mostradores.
- Dados auxiliares dos relógios divididos em linhas compactas para evitar cortes.
- Novo botão de registro diário retroativo na tela Atualizar streams.
- Permite preencher de 1 a 15 dias anteriores; datas futuras ou fora da janela são bloqueadas.
- Registro retroativo usa streams daquele dia e não altera saldo/previsão financeira do ciclo.
- Registros retroativos entram no Histórico e alimentam Saúde, Tendência, Média diária, Ritmo recente e Atividade.
- Regravação da mesma data substitui somente aquele dia.
- Schema de dados atualizado para v5.
- VersionCode 6; mesma assinatura beta para atualização sobre a v1.3.1.

# StreamPulse 1.3.1 Beta

- Redesenha somente o card Atividade recente como cluster duplo inspirado em painel automotivo.
- Relógio esquerdo: variação diária automática com zonas vermelho → laranja → amarelo → verde.
- Relógio direito: ritmo da meta (ou ritmo do ciclo quando não há meta), atualizado automaticamente.
- Painel central: relógio, data e dias até o fechamento.
- Ponteiros e valores digitais animam suavemente quando os streams mudam.
- Remove a explicação longa do velocímetro antigo e mantém a Home mais limpa.
- VersionCode 5; mesma assinatura beta para atualização sobre a v1.3.

# Changelog

## 1.2 Beta
- Redesenho visual do Dashboard com cards circulares/assimétricos e cores por estado.
- Meta financeira por artista com barra de progresso colorida.
- Saúde do Projeto em indicador circular e uma única pontuação por dia.
- Correção de dias ausentes: dias anteriores ao primeiro registro não contam como falha.
- Proteção contra datas antigas/futuras em distribuidoras sem ciclo fixo.
- Foto local por artista com seletor em Ajustes.
- Atividade recente agora mostra variação percentual dia a dia.
- Atalhos Atualizar/Recebi movidos para o card principal.
- Período recomendado movido para aviso no final da Home.
- Números principais com estilo digital e sombra para contraste.

# StreamPulse — Changelog

## 1.1 Beta
- Onboarding redesenhado com logotipo menor e campo de artista com contraste corrigido.
- Navegação inferior reorganizada em 5 áreas: Início, Histórico, Análises, Ciclos e Ajustes.
- Transições animadas entre telas e carregamentos rápidos em operações de dados.
- Dashboard ampliado com tendência, dias restantes, última atualização, precisão, atividade recente e resumo inteligente.
- Fórmulas internas/RPM removidos das telas de uso comum e configurações.
- Histórico passa a preservar cada atualização, inclusive múltiplas leituras no mesmo dia.
- Saúde do Projeto revisada: primeira leitura já pontua; dias sem atualização são sinalizados sem receber pontuação inventada.
- Nova tela Análises com Pulso do Projeto, tendência, ritmo recente, melhores/piores registros e qualidade dos dados.
- Nova tela Ciclos com período recomendado, resumo do ciclo atual e ciclos registrados.
- Ajustes redesenhados com edição de artista, preferências de análise, aparência e dados locais.
- Nova área "Sobre as distribuidoras" com 13 distribuidoras, calendário operacional, orientação de período e links oficiais de ajuda.
- Motor de datas atualizado a partir do material de referência das distribuidoras.
- Pagamentos reais continuam calibrando o motor internamente, sem expor a fórmula ao usuário.

## 1.0 Local Beta
- Primeira versão funcional do StreamPulse.
- Cadastro de artistas e distribuidoras.
- Atualizações de streams, estimativas, previsões, saúde, histórico e pagamentos reais.

## 1.3 Beta
- Novo motor inicial de royalties por distribuidora + plano/modalidade.
- Mantido aprendizado progressivo com pagamentos reais por artista.
- Novo cadastro de plano/modalidade para cenários com retenções diferentes.
- Metas inteligentes: financeira + streams + ritmo necessário.
- Card de saldo com degradê dinâmico e contadores animados.
- Cards orgânicos ligeiramente menores, centralizados e com transições de cor.
- Saúde com pontuação e anel animados.
- Atividade recente redesenhada como velocímetro com ponteiro e leitura digital.
- Área Sobre as distribuidoras ampliada com cenários, percentuais, confiança e taxas/condições.
- Base preparada para futuro mix ponderado por plataforma (Spotify, Apple Music, Amazon, YouTube e TIDAL).
- Schema de dados atualizado para v4 e app versionCode 4.

## 1.5.2 Beta
- Home: card principal agora é duplo, sólido e orientado por progresso das metas.
- Saldo financeiro ganhou maior hierarquia visual e progresso independente.
- Meta de streams ganhou progresso, ritmo necessário e meta diária.
- Cores do painel principal: vermelho → laranja → amarelo → verde → azul.
- Textos auxiliares agora usam chips translúcidos de contraste.
- Nova faixa "Próxima ação" baseada no estado atual do artista.
- Alertas compactos aparecem apenas quando há algo que merece atenção.
- Troca rápida de artista pelo cabeçalho da Home.
- Firebase/presença online da v1.5.1 preservado.

## 0.5.2 (code 29)
- Hotfix do seletor de ícones fora do LaunchedEffect.
- Abertura visual rápida (~2 s) com status decorativo do Pulse Player, Ferramentas e Análises/Ajustes.
- Visualizadores ampliados e FFT reamostrado em 32 pontos, com ganho dinâmico e movimento mínimo perceptível.
- Modelos circulares/radiais maiores e com maior excursão.
- Capa ampliada no Player e área do espectro aumentada.
- Configuração do visualizador revisada, faixa de sensibilidade ampliada e restauração do padrão.
- Monitor contextual de dados na área YouTube (download, upload e consumo da sessão), ocultado automaticamente ao sair da função.
- Firebase Rules preservadas sem alterações.

## 0.7.3 (code35)
- Editor: correção de crashes ao abrir Rascunhos e ao importar múltiplas imagens.
- Editor: decodificação de imagens com downsampling para evitar OOM em fotos grandes.
- Editor: timeline visual separada de camadas de áudio.
- Editor: áudio por camada com Arquivos e Extrair de vídeo, volume e posicionamento na timeline.
- Editor: play/pause passa a avançar fotos e vídeos pela timeline e sincroniza camadas de áudio.
- Editor: handles de duração/trim ampliados e funcionais, inclusive para aumentar/reduzir duração de fotos.
- Editor: layout mais limpo e contextual, inspirado em fluxo de editores mobile modernos, mantendo identidade Pulse.
- Editor: falha de mídia passa a ser isolada com aviso em vez de derrubar o app.

## 0.7.5 (code37)
- Editor: fechamento funcional do checklist 0.7.x, galeria Fotos/Vídeos, timeline/trim mais responsivos, texto/cores/animações ampliados, ajustes completos e visualizer expandido.
- Export: compositor Media3 1.11.0 para sequência de fotos/vídeos com áudio de fundo, H.264/HEVC e HDR/SDR conforme capacidade.
- Estabilidade: mídia incompatível continua isolada, rascunhos seguros e processamento pesado fora da UI quando aplicável.

## 0.8.11 (code 56) — Dynamic Island SONUS 2.0
- Ajustes gerais compactados: a Dynamic Island ganhou painel próprio.
- Ilha somente em portrait; landscape oculta sem sobrescrever a posição salva.
- Tamanho mínimo reduzido, transparência ampliada, posição X/Y, alinhamentos e trava de posição.
- Presets de câmera esquerda/centro/direita; câmera central reserva um vão no layout expandido.
- Estados expandido/compacto/oculto, entrada/saída suave e recolhimento automático em ~4 s.
- Player compacto com capa, play/pause e progresso temporal; toque reexpande controles.
- Progresso de tarefas usa o mesmo valor publicado pela função e também atualiza a notificação do serviço.
- Conversor/Visualizer mantêm progresso; Master e AutoMix passam a anunciar início/conclusão na ilha.
- Presets Standard, Glow e Glass ampliados; modo Dinâmico usa cor da capa/função.
- Arraste refeito sem reiniciar Activity; quando a posição está fixada, arraste fica bloqueado.

## 0.8.17 (code 62) — hotfix de interface e transporte
- Ajustes reorganizados na ordem aprovada, com hub compacto em duas colunas para Conta, Desenvolvedor, Premium e Uso; Dynamic Island em card compacto próprio.
- Personalização, monitor de dados, assinatura tátil SONUS, código promocional, análises, backup, Sobre e segurança reordenados.
- Backup ZIP e Backup Online reunidos na mesma área; Backup Online permanece Bronze+.
- Resumo Inteligente sinalizado como Prata+ e Previsões Avançadas como Ouro+ nos Ajustes.
- SONUS MUSIC preserva o estado de transporte: Pause não vira Play ao trocar de área ou reabrir o app; reprodução que já estava ativa continua ativa.
- Player refinado com capa maior, Spectro deslocado para baixo e barra de progresso mais próxima dos controles.
- Limites de artistas agora são aplicados ao adicionar perfis: Free 1, Bronze 2, Prata 5, Ouro 10 e Diamante ilimitado, preservando perfis já existentes.
- Financeiro e projeções ficam bloqueados no Free e abrem a partir do Bronze; o simulador OWNER foi alinhado ao novo modelo sem carteira de Coins na interface.
- versionName 0.8.17 / versionCode 62 preservados para o hotfix.

## 0.8.26 (code71)
- Corrige Mesclar Áudio com persistência de acesso SAF, cache local seguro, validação de arquivos e progresso real baseado no tempo processado.
- Corrige Mesclar Vídeo removendo `-preset`, normalizando segmentos para MP4 compatível, suportando vídeos sem áudio e usando concatenação final segura.
- Adiciona cancelamento confirmado aos mescladores e remove saídas parciais em falhas.
- Distribuição & Pagamentos passa a ser PRO para Bronze, Prata, Ouro e Diamante; Painéis das Distribuidoras continua grátis.
- Itens PRO bloqueados abrem seletor de planos padronizado.
- Ajusta cards de Recursos para Artistas: selo PRO, botão Abrir visível, interruptor de fixação à esquerda e animação de entrada suave.

## SONUS v0.8.41 — code86
- Visualizer reconectado ao pipeline Media3/ExoPlayer do Sonus Music.
- Administração OWNER de tags, capa e letras por faixa do Sonus Music.
- Letras TXT/LRC; transcrição automática online removida por estabilidade.
- AdMob Rewarded + Interstitial com ambientes teste/produção e UMP.
- Planos comerciais simplificados: Grátis, Ouro e Diamante.
- Painel Desenvolvedor ganhou módulo Monetização.
- Preparação de Google Play Billing sem ativação de compras reais.
- Player de Música atualizado para v0.14.

## SONUS v0.8.42 — code87
- Corrige importação de letras TXT/LRC no Painel Desenvolvedor usando seleção ampla e validação por extensão/MIME.
- LRC passa a sincronizar diretamente na Home do SONUS PLAYER, com campo ampliado nos 9 layouts.
- Parser LRC ampliado para ponto/vírgula, múltiplos timestamps e offset.
- Codemagic passa a importar o grupo secreto `sonus_youtube`; build falha de forma explícita se `YOUTUBE_API_KEY` estiver ausente.
- Pesquisa interna do YouTube e Karaokê voltam a usar a YouTube Data API v3 com identificação Android package + SHA-1.
- Novo hub de Playlists do YouTube no PLAYER: colar/carregar link, reprodução incorporada, salvar, renomear, favoritar e remover atalhos locais.


- Hotfix de empacotamento code97: removida referência fora de escopo `premiumUseAvailable` em Tags em Lote, que impedia `compileDebugKotlin`. A cobrança continua ocorrendo na ampliação do lote via Moedas SONUS.

- FIX2 CodeMagic: pacote com nome único, marcador anti-cache e preflight que rejeita a referência obsoleta premiumUseAvailable no BatchTagEditor.

## Hotfix code98 FIX1 — compilação Kotlin
- Corrigido `Map.entries.takeLast(...)` no Analytics do Artista, convertendo `entries` explicitamente para `List` antes de `takeLast`.
- Corrige os erros em cascata de `it`, `key`, inferência de tipo e contexto `@Composable` observados no CodeMagic.
- Nenhuma alteração no motor de reprodução de áudio do SONUS Stream.


## 0.9.3 — code99
- Artista da conta SONUS passa a ser o artista do Stream; criação duplicada removida.
- Contador interno RTDB: 20 s, cooldown de 8 min por UID+música, tempo ouvido independente e replay manual.
- Repetição automática de uma faixa não gera tempo qualificado extra.
- Analytics interno e painel Integridade do Stream.
- App Check/Play Integrity preparado.
- Cloud Functions deixam de ser requisito para o fluxo básico de artista/contador/Analytics.

## SONUS 0.9.4 / code100 — FIX1 CodeMagic
- Corrigida interpolação Kotlin no identificador de alerta `LISTENING_CAP`: `$uid_` era interpretado como referência à variável inexistente `uid_`.
- Alterado para `${uid}_`, preservando exatamente a lógica do limite de tempo qualificado do Stream.
- Nenhuma alteração no motor de reprodução, contador 20s/8min, pCloud, Analytics ou interface.

## 1.0.7 / code110 — SONUS Edit foundation reform (2026-09-24)
- Immersive editor project mode: hides SONUS main tabs and disables global page swipe while editing.
- Double-back protection and autosave exit flow.
- New layered timeline with selectable/resizable/movable text, captions, PIP, effects and temporal filters.
- Larger white trim handles and gesture conflict protection.
- Horizontal-only main tool inspector with compact confirmation icon.
- Global original-media mute plus individual clip volume controls.
- Original-media aspect canvas detection and quick aspect presets.
- Direct pan/pinch/rotate transforms for visual clips and PIP.
- Text stays visible while actively being edited.
- Replaced the old fake Canvas effect path with real Media3/GPU processing inspired by ClearCut.
- Real blur, pixelation, distortion, glitch, VHS, film grain, light leak and chroma-key effect paths.
- Timed filter/effect export via Media3 TimestampWrapper.
- ClearCut MIT attribution included.

## SONUS 1.0.11 / code114 — BUILD FIX 2
- Corrige falha Kotlin em `PulseVideoEditorScreen.kt` causada por `Modifier.weight(1f)` ter sido movido para fora de `ColumnScope` durante o BUILD FIX 1.
- `SonusEditorPreviewCanvas` passa a receber `Modifier`; o `weight(1f)` é aplicado no call site dentro do `Column` do editor.
- Preserva a divisão do composable feita para eliminar `MethodTooLargeException`.
- Mantém versionName 1.0.11 / versionCode 114 e todas as melhorias pós-testes aprovadas.

## SONUS 1.0.11 / code114 — BUILD FIX 4 (28/09/2026)
- Rodada de fechamento aprovada: Share, LRC, Stream/Pulse, Analytics preventivo, Destaques, SONUS Edit e envio de música.
- Share ganhou identidade do usuário, busca manual de imagens, 1080p60 e partículas menos densas/mais fluidas.
- Stream reutiliza snapshot de catálogo/capas em processo; Pulse deixa de reutilizar URL resolvida expirada, aguarda Player READY, tenta recuperação uma vez e gira amostras a cada 12 horas.
- Analytics “Você” preservado; contador público mantém anti-self-play/pending-retry; Artista recebeu associação/refresh mais robustos.
- Destaques reorganizados e Renomear Imagens recebeu ícone próprio.
- SONUS Edit ganhou hitbox maior na timeline, duplo-check vetorial centralizado, preview focado no clipe editado e seletor Entrada/Saída para animações.
- Envio do Stream passa a processar internamente em 256 kbps, preserva todos os gêneros e recebe redesign SONUS sem expor bitrate ao artista.
- versionName/versionCode permanecem 1.0.11 / 114.
