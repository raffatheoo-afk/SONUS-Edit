# SONUS — Auditoria de release 0.8.21 • code66

Data da revisão: 2026-09-07

## Verificações concluídas

- `versionName = 0.8.21` e `versionCode = 66` confirmados.
- Estrutura Kotlin revisada nos 15 arquivos alterados: delimitadores, strings e comentários balanceados.
- 4 arquivos XML parseados sem erro.
- 7 arquivos JSON parseados sem erro.
- Nenhum arquivo vazio ou symlink inesperado no projeto.
- AdMob: App ID SONUS, Rewarded real e Rewarded de teste presentes; build de desenvolvimento permanece em modo de teste por padrão.
- Rewarded: pré-carregamento/retry/recarga automática presentes no fluxo.
- Usos Premium confirmados: FREE 20 / Bronze 70 / Prata 200 / Ouro 500 / Diamante ilimitado.
- Destaques: ferramentas de processamento usam o fluxo de Usos Premium; Karaokê permanece livre.
- Central de Notificações e Ajustes de Notificações mantidos como telas separadas.
- Notificações externas usam ícone SONUS dedicado e logo oficial quando suportado.
- Spectro: PCM Media3/TeeAudioProcessor como fonte principal, com Native e PCM Compat preservados como fallback.
- README, CHANGELOG e checklist code66 atualizados.

## Validação que depende do GitHub/aparelho

Esta sessão não possui Gradle/Android SDK local completo para executar uma compilação Android confiável. Portanto, **não foi afirmada compilação local**.

A validação final é:

1. GitHub Actions — `Build APK` deve concluir sem erro.
2. Instalação/teste no aparelho do Rafa.
3. Testar Rewarded de teste (pré-carregado + recompensa +1 no FREE).
4. Testar Spectro no S10e e no S10+ por reprodução prolongada, troca de faixa, pause/play e seek.
5. Confirmar abertura sem tela preta e contraste dos temas/telas de Distribuição.
