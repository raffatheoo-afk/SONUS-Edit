# SONUS v0.8.7 code52 hotfix1

Correções de compilação após o primeiro build da v0.8.7:

- `UtilityHeader` passou de `private` para `internal`, permitindo uso pelos arquivos `SonusFileUtilityTools.kt` e `SonusSocialTools.kt` dentro do mesmo módulo.
- Removida a referência residual `AB_COMPARE` do enum `ToolId`, alinhando o enum ao `when` atual e à remoção do Comparador A/B da interface.
- Sem alteração de `versionCode`/`versionName`: é um hotfix de compilação do mesmo release 0.8.7 code52.
