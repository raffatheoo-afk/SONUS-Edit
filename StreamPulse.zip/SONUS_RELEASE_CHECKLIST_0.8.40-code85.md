# SONUS v0.8.40 — code85

## Base
- Base: v0.8.39 / code84 HOTFIX1.
- Compilação: Codemagic.
- Player de Música: v0.13.
- Player de Vídeo: v0.5.

## Sonus Music
- Reprodução remota migra o caminho online audível para Media3/ExoPlayer.
- Estados BUFFERING / READY / PLAYING / ERROR são tratados sem `MediaPlayer.start()` prematuro.
- pCloud prefere o arquivo original via `getpublinkdownload`, com `getpubaudiolink` como fallback.
- Redirecionamentos HTTP e Range são aceitos pelo DataSource do Media3.
- Pausa de faixa online libera a conexão remota; retomada resolve uma URL nova na posição salva.
- A fila continua para a próxima música e mantém próxima/anterior/repetição/aleatório.

## Administração OWNER
- Painel Sonus Music abre gêneros e lista as faixas detectadas.
- Cada faixa possui ficha OWNER com link direto opcional, teste, salvar, remover e restaurar automático.
- Overrides ficam em `sonusMusicAdmin/streamOverrides` com regras OWNER-only.
- Busca e filtros: todas, sem link, com link, publicadas e ocultas.
- Teste de streaming verifica bytes reais e estado READY do ExoPlayer.

## Segurança
- URLs administrativas não aparecem na interface comum.
- Firebase RTDB recebeu caminho OWNER-only para overrides.
- Foi incluído proxy seguro opcional em `functions/sonus-stream-proxy`.
- Quando `SONUS_STREAM_PROXY_BASE` estiver configurado, o app envia Firebase ID token no cabeçalho e o proxy transmite os bytes sem devolver a URL real da origem.
- Sem proxy configurado, o catálogo público continua funcionando pela resolução temporária do pCloud.

## SONUS PLAYER
- Biblioteca local ganhou acesso fixo no TopAppBar da tela principal, independente dos 9 temas e da origem atual da faixa.
- Sonus Music e YouTube continuam visualmente separados como streaming.

## Sobre o SONUS
- Mostra somente as melhorias da versão atual.
