# Pulse Studio 0.5 — Firebase

O Pulse Studio preserva o projeto Firebase e o Android applicationId `com.sonusstudios.streampulse` para manter compatibilidade com a base instalada.

## Authentication
1. E-mail/senha ativado.
2. Google ativado.
3. SHA-1 e SHA-256 da assinatura cadastrados.
4. `app/google-services.json` permanece o arquivo do projeto Firebase atual.

## Realtime Database
A **0.5 não altera as regras publicadas**. Permanecem em vigor as regras v1.9.4, incluindo as correções de `couponSlots` e `couponReservations`.

Use `firebase-realtime-database.rules-v1.9.4.json`. Os arquivos raiz `firebase-realtime-database.rules.json` e `firebase-database-rules.json` devem continuar equivalentes a ele.

As regras protegem `/roles`, `/accounts`, `/presence`, `/backups`, `/analytics/events`, `/coupons`, `/couponSlots`, `/couponReservations`, `/couponRedemptions`, `/userClaims`, `/promoControl` e `/publicConfig` conforme a arquitetura já publicada.

## OWNER
A autoridade continua exclusivamente remota:
```json
roles/<UID> = {
  "role": "OWNER",
  "active": true
}
```
Nenhum e-mail, UID privilegiado, senha mestra, service account ou chave administrativa deve ser gravado no APK.

## Planos e compatibilidade de cupons
A interface pública usa Free/Bronze/Prata/Ouro/Diamante. Claims antigos são mapeados para compatibilidade (`PLUS→BRONZE`, `STUDIO→PRATA`, `MAX→OURO`). Isso não exige alteração das regras atuais porque as regras não fixam esses nomes como enum de segurança.

## Ads
Em versão 0.x/debug, o Rewarded usa o ID oficial de teste do Google. Não existem anúncios comuns nos planos pagos. Rewarded é sempre voluntário: o Free pode usá-lo para recompensas e qualquer plano abaixo do requisito de uma função elegível pode optar pelo **Passe Pulse 24h** para experimentar somente aquela função, sem receber o plano inteiro.

## YouTube
A busca usa `YOUTUBE_API_KEY` injetada pelo GitHub Actions. A reprodução usa o player oficial incorporado/IFrame. O Pulse Studio não extrai áudio, não raspa URLs de mídia e não implementa reprodução oculta do YouTube.
