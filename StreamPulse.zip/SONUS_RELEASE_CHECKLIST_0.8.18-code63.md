# SONUS 0.8.18 • code63

- [x] Login com símbolo oficial SONUS.
- [x] Modo convidado FREE persistente no aparelho.
- [x] Login obrigatório antes de dados de distribuição, backup online e compras Premium.
- [x] Retorno ao destino após autenticação (Conta, Premium, adicionar artista ou distribuidoras).
- [x] Vídeo → Áudio removido do Studio e mantido em Destaques.
- [x] Card de imagens dividido com Vídeo → Áudio em Destaques.
- [x] Vídeo → Áudio corrigido: leitura da faixa, URI persistente, MIME por formato, fallback MP3, salvamento via SONUS Storage e erros amigáveis.
- [x] Cards de Ajustes preservam layout aprovado com novas cores translúcidas.
- [x] Conta azul SONUS; Desenvolvedor diamante; Premium dourado; Uso vermelho; Dynamic Island preta.
- [x] Sobre o SONUS atualizado com mudanças da versão.
