# SONUS 0.0.8 — CODE08

## LIVE — letras sincronizadas
- A tela “No ar” passa a consultar a letra da faixa atual do SONUS Stream pelo identificador da música.
- Letras administrativas já cadastradas no catálogo têm prioridade; depois são consideradas letras da comunidade e, por último, a consulta LRCLIB existente.
- Quando a letra é LRC, a linha exibida acompanha a posição atual do áudio usando o mesmo parser do Player.
- A leitura é feita fora da thread principal, com limite de espera e tratamento de falha sem interromper a LIVE.
- Não foram redesenhados os demais elementos da tela LIVE.

## SONUS Stream — navegação de gêneros
- Tocar em um cartão de gênero abre um painel próprio sobre a tela, sem obrigar o usuário a procurar a lista no fim da página.
- O conteúdo ao fundo recebe desfoque enquanto o painel está aberto.
- O botão vermelho “Fechar” fica no rodapé, alinhado à direita; ao fechar, o desfoque desaparece.
- Os cartões, gradientes, ilustrações e a ordem de favoritos da versão anterior são preservados.

## SONUS Stream — lista de músicas
- Removidos dos itens da lista os comandos de adicionar à playlist, compartilhar e denunciar.
- Permanecem apenas favorito e play individual; o play recebe destaque visual e o favorito mantém indicação clara quando ativo.
- O painel oferece “Tocar tudo” e “Aleatório” no topo.
- O play individual inicia a reprodução a partir da faixa escolhida, mantendo as próximas músicas do contexto do gênero na sequência.
- A lista apresenta 20 faixas por lote. Quando ainda não existe snapshot completo em memória, um cursor continua a leitura sequencial do JSON local sem voltar ao início em cada rolagem; quando o snapshot já foi carregado por outra área do Stream, o painel reaproveita esse cache e mantém a apresentação em lotes de 20. Ao se aproximar das últimas 8 faixas carregadas, busca o próximo lote.
- O SharedPreferences ainda fornece cada JSON completo como `String`; a otimização reduz a desserialização/criação simultânea de objetos e não é streaming remoto direto do pCloud.
- A fila completa do gênero é materializada sob demanda para Tocar tudo, Aleatório e play individual com sequência. O áudio não é pré-carregado; a faixa só é resolvida quando será tocada.

## Preservações
- Rádio e Linha do Tempo continuam com o comportamento anterior; não foram convertidos em popups.
- Não foi alterada a classificação dos gêneros por metadados. Faixas sem tag ou com tag incorreta permanecem para eventual correção manual no catálogo.
- Os componentes protegidos `AudioToolEngine.kt`, `PulsePlayerService.kt` e `SonusStreamPlatform.kt` permanecem inalterados.

## Versão
- `versionName`: `0.0.8`
- `versionCode`: `8`

## Correção de compilação após o primeiro build CODE08
- `SonusLiveStudio.kt`: import explícito de `androidx.compose.material3.Surface`. Isso também resolve o erro em cascata de chamada `@Composable` dentro do conteúdo de `Surface`.
- `SonusOnlineMusic.kt`: imports explícitos de `androidx.compose.ui.text.style.TextAlign`, `androidx.compose.foundation.shape.CircleShape` e `androidx.compose.foundation.border`.
- Nenhuma lógica de reprodução, LIVE, navegação, catálogo, paginação ou assinatura foi modificada nesta correção.
