# SONUS v0.8.13 • code58

## Escopo aprovado
- Player: corrigida pausa ao reentrar na tela; sessão de reprodução permanece persistente.
- Áudio: pipeline mais conservador, normalização automática desligada por padrão, SONUS BOOST suavizado e curvas sem ganho positivo para reduzir clipping.
- Equalizador: removido controle manual de 10 bandas da UI; novos presets Flat, Pop, Rock, Hip-Hop, Vocal, Warm & Clear e Bass Safe; visual redesenhado.
- SONUS SPATIAL: removido da UI e DSP desativado por compatibilidade.
- SONUS Visualizer (editor de vídeo): descontinuado e removido da navegação/código dedicado. O visualizador do player permanece.
- Studio: categorias superiores redesenhadas como pílulas compactas, todas visíveis sem rolagem horizontal.
- Dynamic Island: PRO, limites menores, padrão mais discreto, pressão de 1s para expandir, recolhimento em 3s, desaparecimento em 4s sem mídia, transparência compacta estável, animações suavizadas e painel visual revisado.
- Gravador: validação real de RECORDSTATE_RECORDING, fallback para MIC e tratamento de erros de captura para evitar gravações 00:00/0 B falsas.
- Crossfade: lógica não alterada.
- applicationId preservado: com.sonusstudios.streampulse.

## Validação
Código preparado para GitHub Actions. Não há afirmação de compilação local; confirmar o workflow antes de instalar.
