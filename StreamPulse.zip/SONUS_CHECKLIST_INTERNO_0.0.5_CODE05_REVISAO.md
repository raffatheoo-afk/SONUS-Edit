# SONUS 0.0.5 / CODE 05 — Checklist interno consolidado

**Estado do pacote-fonte:** alterações desta etapa integradas. Identidade pública mantida em `versionName = 0.0.5` e `versionCode = 5`.

> “Fechado” aqui significa código-fonte, regras e workflow atualizados e revisados estaticamente. Compilação Android, assinatura final do APK e ensaios em aparelho precisam ser executados no Codemagic/dispositivo com o ambiente e as credenciais oficiais; não são simulados por esta revisão.

## A. LIVE — preparação, entrada no ar e cenas
- [x] Contagem regressiva padrão/mínima de 10 segundos; opções 10/15/20/30; valores antigos abaixo de 10 são normalizados.
- [x] As cinco primeiras imagens são selecionadas, baixadas e decodificadas durante a configuração; o início fica bloqueado até haver 5 prontas.
- [x] A mesma fila de `LiveSlide` preparada é consumida pelo palco depois da contagem, sem nova seleção da primeira cena.
- [x] O carregamento da galeria e a reposição acontecem em segundo plano; quando a fila esvazia, a cena atual permanece na tela até existir outra pronta.
- [x] Classificação/seleção pesada em `Dispatchers.Default`; rede/arquivo e decodificação em `Dispatchers.IO`; concorrência inicial limitada a três tarefas.
- [x] Transições leves de fade, deslocamento e escala; vídeos mudos avançam no fim/erro, sem corte artificial de duração.
- [x] O estado AO VIVO só é assumido após o player confirmar reprodução com faixa atual; em timeout, a tela retorna à configuração.
- [x] Painel central antigo e texto gigante de letra removidos; divulgação pequena no rodapé alterna SONUS / SONUS Edit e mostra Telegram `@sonusappupdate`.
- [x] Controles existentes de overlay, microfone, volume, CTA, curtidas/apoio e encerramento foram preservados.
- [ ] Medir ANR, tempo até o primeiro frame, FPS, memória, Bluetooth e comportamento real em aparelhos variados.

## B. SONUS Stream — desempenho
- [x] Filtros, normalização de busca, ranking, agrupamentos, playlists, álbuns e recomendações pesadas migrados para `Dispatchers.Default` via `produceState`/corrotinas.
- [x] Montagem de filas e programação da Rádio fora do caminho síncrono da interface; duplo acionamento da preparação da Rádio bloqueado.
- [x] Leituras de cache/catálogo e capas mantidas em `Dispatchers.IO`; atualização de perfis deixa de refazer carga completa a cada alteração do fluxo de envios.
- [x] Critério de estações automáticas permanece `list.size > 15`; normalização central de gêneros e aliases preservada.
- [ ] Medir tempo de abertura, scroll, memória e ANR com catálogos pequeno/médio/grande e conexões reais.

## C. Envio de músicas
- [x] Formulário individual mantido; janela de envio redesenhada em `Dialog` responsivo de largura ampla, em vez do AlertDialog antigo.
- [x] Modo real de seleção múltipla de arquivos de áudio via `OpenMultipleDocuments` (não é apenas o editor de metadados em lote).
- [x] Lote permite editar título por faixa, mostra estado e erro por arquivo, mantém as aprovadas e permite reenviar apenas as que faltaram/falharam.
- [x] Capa e gênero são compartilhados por todas as faixas do lote; OWNER pode definir o artista individualmente por faixa, usando o artista padrão apenas como valor inicial.
- [x] Letras TXT/LRC seguem disponíveis no fluxo individual; o modo lote informa explicitamente que não anexa letras separadas por faixa.
- [x] Envio mantém MP3 a 192 kbps e o caminho de cópia sem recodificação para fonte MP3 já compatível quando os critérios técnicos existentes permitem.
- [ ] Testar na nuvem limites de tamanho, codecs incomuns, perda de rede e retomada após falha; cancelamento durante upload não foi adicionado.

## D. OWNER e identidade artística
- [x] Lista de perfis públicos de artista carregada para OWNER e seletor ligado ao envio individual e ao modo lote.
- [x] `artistId` e `artistOwnerUid` do perfil escolhido são persistidos; `uid`/remetente continua sendo a conta que submeteu a faixa.
- [x] OWNER sem perfil selecionado não consegue enviar; a validação não depende apenas de esconder/exibir um controle na interface.
- [x] Regras RTDB validam que ambos os campos estejam ausentes (registros legados) ou ambos presentes, tipados e vinculados ao perfil público real; a troca para artista de outra conta exige papel OWNER ativo.
- [x] Conta artista comum continua associada ao próprio perfil.
- [ ] Exercitar no Firebase Emulator/ambiente de teste tentativas de adulterar `artistId` e `artistOwnerUid`.

## E. Perfil de artista
- [x] Cartão duplicado de perfil removido do corpo da tela “Para artistas”.
- [x] Avatar circular no cabeçalho com lápis; toque abre o painel de edição.
- [x] Avatar, nome artístico e próxima data permitida ficam no painel acessado pelo avatar.
- [x] Regra de alteração de nome a cada 30 dias e `artistId` estável preservados.

## F. Aprovadas e rejeitadas
- [x] Verde de aprovadas e vermelho de rejeitadas permanecem vívidos mesmo sem seleção.
- [x] Seleção recebe gradiente e contorno mais brilhantes que o estado não selecionado.
- [x] Recolhimento inicial e ações já existentes preservados.

## G. Catálogo, Rádio e compatibilidade
- [x] Catálogo central de 18 gêneros e aliases históricos mantidos.
- [x] Rádio automática só cria estação quando existem mais de 15 faixas válidas.
- [x] Três fontes pCloud e seus identificadores/fluxos preservados.
- [x] Envio MP3 192 kbps e cópia sem recodificação de arquivo compatível preservados.
- [x] Nome artístico com janela de 30 dias e sincronização pelo identificador estável preservados.

## H. Limpeza e segurança de manutenção
- [x] Código visual antigo de letra/painel central da LIVE removido onde não era mais utilizado.
- [x] Workflow conserva checksums dos arquivos críticos de áudio/player e atualiza o checksum do arquivo Stream revisado.
- [x] Não foi feita exclusão indiscriminada de assets, recursos Android ou arquivos apenas por ausência aparente de referência; uso dinâmico/XML/reflection exige prova antes de remover.
- [x] Assinatura permanente, identidade do pacote e ausência de fallback debug preservadas no Gradle/Codemagic.

## I. Verificações e entrega
- [x] `versionName = 0.0.5`, `versionCode = 5` e `applicationId` mantidos.
- [x] Parser sintático Kotlin executado nos quatro arquivos grandes alterados nesta etapa.
- [x] YAML Codemagic validado; scripts shell dos passos validados com `bash -n`.
- [x] JSON das regras Firebase válido e cópias espelhadas idênticas.
- [x] ZIP final testado com `unzip -t`; checksums e arquivos protegidos conferidos.
- [ ] Build Android real, APK assinado e verificação do certificado oficial no Codemagic.
- [ ] Testes instrumentados e ensaios em aparelhos físicos.

## Observações de implementação
- O modo em lote compartilha capa e gênero; permite título e, para OWNER, artista por faixa. A letra/LRC continua sendo selecionada no modo individual.
- A divulgação inferior exibe os nomes SONUS / SONUS Edit e o Telegram `@sonusappupdate`. Não foi inventado um URL de download de aplicativo; o endereço oficial de distribuição precisa continuar sendo o canal de download já adotado pelo projeto.
- Não declarar que o ANR está definitivamente eliminado sem executar a versão em aparelho real e medir o comportamento.
