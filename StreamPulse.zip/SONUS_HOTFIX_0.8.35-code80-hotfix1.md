# SONUS v0.8.35 code80 — HOTFIX 1

Correções de compilação:
- Moveu o estado/persistência da Caixa Preta para o escopo correto do `StreamPulseApp`.
- Restaurou os launchers de criar/restaurar backup usados pela tela de Ajustes.
- Restaurou o import `LazyRow` usado pela seleção de retenção da Caixa Preta.

Sem alteração de `versionName` ou `versionCode`.
