# SONUS 0.8.23 • code68 — checklist de release

## Motor visual SONUS
- [x] PCM Media3 permanece como fonte principal; Native/PCM Compat preservados como fallback.
- [x] FFT reduzida para janela de 512 amostras para resposta mais rápida.
- [x] Buffer PCM é consumido integralmente, com sobreposição de 50% entre janelas.
- [x] Normalização adaptativa para músicas com masters baixos/altos.
- [x] StateFlow do espectro separado do estado principal do Player para reduzir recomposição da tela.
- [x] Interpolação no clock de frame, attack rápido e release suave.
- [x] Intensidade 50–200%, sensibilidade e suavidade Rápida/Equilibrada/Suave preservadas.
- [x] Pause faz barras/VU decaírem suavemente a zero; Play retoma sem salto.
- [x] Processamento FFT permanece fora da UI thread e buffers continuam limitados.

## Interfaces
- [x] SONUS Classic FREE preservado.
- [x] Pure mantém layout e recebe barras fluidas.
- [x] Flow mantém layout e recebe barras fluidas.
- [x] Orbit remove a visualização em linha e usa barras padrão SONUS.
- [x] Vinyl Glow recebe capa ampliada e barras reposicionadas.
- [x] Arc Light corrige contraste e adiciona botão Claro/Escuro rápido com preferência persistente.
- [x] Neon Disc usa barras padrão SONUS.
- [x] Cassette Retro reformulado com 6 skins SONUS originais desenhados no app.
- [x] Cassette Retro integra capa maior na etiqueta da fita.
- [x] Cassette Retro usa VU Meter estéreo reativo no lugar do Spectro inferior simples.
- [x] Cassette Retro anima os dois carretéis; Pause para e Seek acompanha o progresso.
- [x] Quantidade de fita muda progressivamente entre os carretéis.
- [x] Carretel com menos fita gira mais rápido e o mais cheio gira mais devagar.
- [x] Botão rápido no Cassette Retro alterna os seis modelos e salva a escolha.
- [x] Turntable Classic preservado com VU/LEDs alimentados pelo novo motor fluido.

## Comportamento comum
- [x] YouTube especial permanece acessível em todas as interfaces.
- [x] Temas continuam funcionando nas interfaces.
- [x] Aleatório/repetição/interface continuam persistentes.
- [x] Biblioteca, fila e temporizador da code67 preservados.
- [x] Controles Anterior/Próxima permanecem com contraste adequado.
- [x] Animações mecânicas param no Pause sem iniciar reprodução indevida.

## Preservação
- [x] Qualidade de áudio preservada.
- [x] Crossfade preservado.
- [x] Media3 PCM universal preservado.
- [x] Bluetooth/fones/MediaSession preservados.
- [x] AdMob Rewarded e Usos Premium preservados.
- [x] Vídeo → Áudio, Gravador, Login/Convidado, Premium e Dynamic Island preservados.
- [x] SONUS BOOST/SPATIAL continuam removidos.

## Versão / documentação / pacote
- [x] versionName 0.8.23.
- [x] versionCode 68.
- [x] CHANGELOG atualizado.
- [x] README atualizado.
- [x] Sobre o SONUS → O que mudou nesta versão atualizado.
- [x] Raiz dos ZIPs deve permanecer `StreamPulse/`.
- [ ] GitHub Actions: validação final de compilação Android após upload.
