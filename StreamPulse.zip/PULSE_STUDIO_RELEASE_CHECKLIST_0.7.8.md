# Pulse Studio 0.7.8 — code 40

## Uso do app
- Períodos Hoje, Ontem, 7/15/30 dias, 3 meses e Total.
- Histórico diário local e por módulo: Editor, Player, Ferramentas, Destaques e Ajustes.
- Resumo do período, sessões, média, maior sessão, último acesso e Premium.
- Histórico de dados RX/TX e taxa atual de transferência do processo.

## Dados e rede
- Persistência de download/upload por dia e total.
- Economia de dados, Pulse FX somente em Wi-Fi e limite de consumo acumulado.
- Monitor mede tráfego real do processo sem executar speed test artificial.

## Desenvolvedor
- Build/versionCode, aparelho, Android, ABI e diagnóstico real de encoders H.264/HEVC/AV1.
- Bloco de diagnóstico para Editor, áudio/FFT, export, Spectro e Pulse FX.

## Editor
- Barra principal no rodapé quando nenhum contexto está aberto.
- Selecionar foto/vídeo/áudio substitui a barra principal pelo inspector contextual.
- Ferramentas Dividir/Excluir/Duplicar/Girar/Espelhar não ficam permanentes.
- Confirmar fecha o contexto e retorna à barra principal.
- Undo/Redo movidos para os controles inferiores.
- Handles de trim maiores e com área de toque ampla; timeline não recebe o drag capturado pelo handle.
- Preview ganha espaço ao reduzir o inspector.

## Pulse FX
- Contrato local para catálogo e pacotes .pulsefx.
- Tipos Overlay Video, Particle Sprite, Shader e LUT.
- Blend modes Normal, Screen, Add, Multiply e Overlay.
- Modelo pronto para vídeos VFX de fundo preto usando Screen/Add, loop, opacidade, velocidade, thumbnail, preview, URL e SHA-256.
- Nenhum endpoint fixo: pCloud/CDN pode ser definido pelo catálogo sem mudar a engine.
