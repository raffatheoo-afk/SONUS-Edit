# SONUS v0.8.41 — code86

## Release
- [x] versionName 0.8.41
- [x] versionCode 86
- [x] Player de Música 0.14
- [x] Player de Vídeo 0.5
- [x] Changelog da versão atual somente
- [x] Sonus Music OWNER tags/capa/letras
- [x] Visualizer Media3 code path
- [x] AdMob test/prod IDs separados
- [x] UMP integrado
- [x] Política de privacidade linkada
- [x] app-ads.txt publicado pelo OWNER
- [x] Planos Grátis/Ouro/Diamante
- [x] Billing preparado sem compra real
- [ ] Compilar no Codemagic
- [ ] Smoke test no APK
- [ ] Validar app-ads.txt no AdMob quando o rastreador concluir
- [ ] Antes de release público, configurar SONUS_REAL_ADS=true e produtos Play Billing quando aplicável
