# SONUS 0.9.4 / code100 — Release Checklist

Status do pacote: implementação concluída no código-fonte. FIX1 preparado após o primeiro build real no CodeMagic apontar uma única falha de compilação Kotlin em SonusStreamPlatform.kt:1219 (`uid_` inexistente em interpolação de String). A linha foi corrigida para `${uid}`. Nova compilação real no CodeMagic ainda deve confirmar o hotfix.

## Implementado
- versionName 0.9.4 / versionCode 100.
- Contador interno preservando 20 s mínimos e cooldown de 8 min por UID+música.
- Buckets horários internos para Analytics do SONUS Stream.
- Períodos: 24h, 7 dias, 15 dias, Mês atual e 90 dias.
- Gráficos por hora para 24h e por dia para períodos maiores.
- Músicas em análise visíveis no Studio.
- Projeção do mês baseada somente na atividade interna do Stream; sem dados suficientes, não inventa previsão.
- Acesso único Studio/Analytics + ajustes com ícone engrenagem + gráfico.
- Remoção das opções redundantes de qualidade/economia de dados do painel do Stream.
- Abertura via cache com atualização remota em segundo plano quando já há catálogo local.
- Submissão de artista para pCloud File Request / caixa 🔴 SONUS ARTISTAS.
- Nenhum token privado pCloud é embarcado; somente o código do Upload Link fornecido para a caixa de entrada.
- WAV e MP3 aceitos como origem; processamento local para MP3 160 kbps antes do upload.
- Capa obrigatória e quadrada 1:1, sem resolução mínima, incorporada ao MP3.
- LRC/TXT opcional; LRC exige timestamps reconhecíveis, TXT é letra comum.
- Interface mostra “Processando…” e “Processamento concluído.”.
- Pasta de submissão não altera a pasta oficial usada para leitura do catálogo.
- Regras Firebase atualizadas para métricas novas.
- Diagnóstico OWNER inclui pCloud/Analytics.

## Validações feitas neste ambiente
- JSON das Firebase Rules validado por parser.
- Nenhuma regra `.read` contém `newData`.
- `codemagic.yaml` validado por parser YAML.
- Marcadores code100/versionCode/versionName verificados.
- Primeiro build real no CodeMagic alcançou `:app:compileDebugKotlin` e apontou uma única falha: `Unresolved reference 'uid_'` em `SonusStreamPlatform.kt:1219`.
- FIX1 corrige a interpolação de String de `$uid_` para `${uid}_`.
- Foi feita varredura adicional nas alterações code100 para o mesmo padrão de interpolação e nenhuma outra ocorrência equivalente foi encontrada.
- Este ambiente ainda não substitui a nova compilação Android real no CodeMagic.
- Integridade dos ZIPs deve ser conferida por `unzip -t` após empacotamento.

## Antes de testar o APK
1. Publicar `FIREBASE_REALTIME_RULES_SONUS_CODE100.json` no Realtime Database real.
2. Compilar o pacote no CodeMagic.
3. Instalar o APK e testar contador com dois UIDs.
4. Testar um envio pequeno MP3 + capa 1:1 e confirmar chegada em 🔴 SONUS ARTISTAS.
5. Testar WAV + capa e LRC/TXT.
6. Confirmar que o catálogo oficial não exibe a submissão antes de você movê-la/publicá-la.

## Nota de segurança do pCloud
O File Request é upload-only e não expõe o conteúdo da pasta, mas o código do link é uma credencial de capacidade pública e pode ser extraído de um APK ou compartilhado. Se houver abuso no futuro, revogue/regenere o File Request ou migre o upload para um proxy server-side protegido por App Check. Nesta fase, ele não é um token privado da sua conta pCloud.
