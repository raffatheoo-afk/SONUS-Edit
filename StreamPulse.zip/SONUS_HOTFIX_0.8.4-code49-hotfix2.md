# SONUS v0.8.4 code49 hotfix2

Correção do build do tema Camaleon:
- removido uso direto de ProcessCameraProvider/ListenableFuture;
- Camaleon agora usa LifecycleCameraController do CameraX View;
- removida dependência explícita com.google.guava:listenablefuture:1.0, evitando conflito de classpath;
- mantidos versionName 0.8.4 e versionCode 49 porque a versão ainda não compilou no GitHub Actions.
