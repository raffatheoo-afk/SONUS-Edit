# SONUS 0.0.3 / code 03 — alterações desta preparação

## Aplicado nesta cópia
- Mantidas as três fontes de música já configuradas no `app/build.gradle.kts`; nenhum código público pCloud existente foi substituído.
- Mantidas as três galerias 9:16 no `SonusLiveMedia.kt` e no repositório de mídia do Social Edit.
- Painel OWNER/Desenvolvedor do Stream: adicionado diagnóstico explícito das três pastas de música, com leitura individual e contagem de arquivos de áudio.
- Compartilhamento do player: adicionada linha em branco entre a descrição e o deep link `sonusonline://`.
- Botão EDIT do player: ícone passa a usar `ContentScale.Fit`, sem máscara arredondada que cortava a arte; tamanho ampliado.
- Fundo preto da arte `social_edit_icon.png` convertido em transparência com margem de respiro.
- `versionName` atualizado para `0.0.3` e `versionCode` para `3`.
- Codemagic atualizado para validar a versão 0.0.3 e continuar exigindo a assinatura oficial SONUS.

## Não marcar como concluído sem implementação/teste adicional
- WhatsApp não torna esquema customizado `sonusonline://` um hiperlink clicável de forma consistente. Linha em branco melhora a separação visual, mas um link clicável confiável exige URL HTTPS de domínio controlado e App Links verificados.
- Retorno/monitoramento de microfone ainda não foi implementado. Latência zero não é garantível; Bluetooth A2DP/HFP adiciona latência e capturar a saída de áudio de uma caixa não é permitido de forma geral pelo Android. Requer desenho por rota, API de áudio de baixa latência e teste real em dispositivos/fones.
- Reorganização completa da tela Aplicativos por abas/categorias ainda não foi implementada.
- Classificação sem mistura de imagens religiosas e não religiosas na LIVE ainda precisa de taxonomia confiável e testes com catálogo real.
- Download offline do player ainda precisa ser implementado/validado (download, cancelamento, remoção, biblioteca e limpeza de dados).
- Logo dedicado para Renomear Áudios ainda precisa ser integrado ao tile da ferramenta.

## Validação
- Não houve compilação Gradle/Android neste ambiente. A cópia não contém Gradle Wrapper e o ambiente não possui Gradle instalado.
- O ZIP deve ser tratado como candidato de código-fonte, não como APK pronto para distribuição.
