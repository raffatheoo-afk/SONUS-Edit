# PulseOrbit™ — notas DSP v1.9.5

PulseOrbit™ é a identidade de áudio espacial do Pulse Studio.

## PulseOrbit 3D
Na v1.9.5, a reprodução local usa espacialização/virtualização disponível no Android e intensidade controlada pelo usuário. Na exportação do Conversor, a cadeia usa widening/ambience conservador e proteção final de pico.

## PulseOrbit 8D
Na reprodução, usa virtualização e órbita estéreo de potência aproximadamente constante, com velocidade lenta (~0,115 Hz) e intensidade regulável. Na exportação, usa modulação/panning espacial e ambiente conservador conforme os filtros disponíveis no FFmpeg embarcado.

## Limite técnico desta versão
O PDF de referência do projeto recomenda HRTF para um modelo 3D físico mais avançado. A v1.9.5 **não afirma implementar um HRTF universal/personalizado**. A assinatura atual é um DSP próprio, compatível com Android, pensado para sensação espacial agradável sem copiar marcas/nomes de terceiros.

## PulseLift™ + PulseOrbit™
PulseLift permanece uma função separada. Quando ambos são usados, a cadeia procura preservar definição/dinâmica antes da espacialização e aplicar proteção final contra clipping na exportação.


## Presets próprios

### PulseOrbit 3D
- Natural — espacialização suave para uso prolongado.
- Studio — largura moderada e foco central.
- Stage — sensação de palco mais amplo.
- Cinema — maior profundidade e envolvimento.
- Deep Space — intensidade máxima da família 3D.

### PulseOrbit 8D
- Orbit Natural — giro lento e discreto.
- Orbit Flow — movimento contínuo e musical.
- Orbit Wide — trajetória mais ampla.
- Orbit Deep — órbita lenta com sensação de profundidade maior.
- Orbit Live — movimento discreto para sensação de palco.
- Orbit Dream — órbita lenta e aérea.
- Orbit Energy — movimento mais rápido para faixas energéticas.
- Orbit Infinite — assinatura principal 8D, com equilíbrio entre amplitude, velocidade e profundidade.

A interface permite escolher 3D/8D, preset e intensidade. Ajustar a intensidade manualmente passa o estado para `Manual`, sem apagar a possibilidade de selecionar novamente um preset.
