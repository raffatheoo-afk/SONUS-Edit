# PulseLift Signature v1 — Pulse Studio

Processamento local próprio do Pulse Studio. Não é Dolby, Dolby Atmos nem uma cópia do Dolby On.

Ordem do MVP:
1. headroom do EQ quando houver boost positivo;
2. EQ gráfico/preset do usuário;
3. high-pass musical em 26 Hz;
4. redução espectral moderada adaptada pela intensidade;
5. de-esser suave;
6. controle tonal dinâmico aproximado em 240 Hz / 3,1 kHz / 11,5 kHz;
7. compressor glue com ratio baixo e knee suave;
8. widening Mid/Side moderado apenas em estéreo;
9. limiter de proteção em ~-1,2 dBFS.

A intensidade não é um controle de volume. Ela escala limpeza, correção tonal, densidade e largura dentro de limites conservadores. Preview e exportação usam a mesma cadeia de filtros.
