# SONUS v0.8.14 — code59

- Player não inicia reprodução apenas ao abrir/reentrar no app.
- Revisão do caminho de áudio: EQ nativo desligado em Flat, headroom automático para boosts e SONUS BOOST menos agressivo.
- Presets recalibrados + 3 controles simples: Graves, Médios e Agudos.
- Gravador: correção da leitura AudioRecord/ByteBuffer que podia deixar gravação em 00:00/0 B.
- Gravador redesenhado com controle principal no topo da tela.
- Dynamic Island: controle independente do tamanho recolhido e long-press de 1s reforçado.
- Mantidos: crossfade existente, applicationId, assinatura/Firebase, SONUS BOOST e decisões anteriores.
