# SONUS 0.0.9 — CODE09 (atualização consolidada)

## Identidade preservada
- `versionName`: `0.0.9`
- `versionCode`: `9`
- `applicationId`: `com.sonusstudios.streampulse`
- Esta consolidação mantém a mesma versão e o mesmo código; não cria CODE10.

## Painel Desenvolvedor OWNER — cartão Letras
- Corrigido o encaixe vertical do cartão preto “Letras”.
- Ícone, título, subtítulo e contador LRC são distribuídos pelo espaço interno com `Arrangement.SpaceEvenly`.
- Mantidos altura externa, cores, borda, callback e comportamento de abertura da biblioteca.

## LIVE — transições de mídia
- As cinco transições já existentes foram preservadas: fade, deslocamento horizontal, zoom/escala com fade, deslocamento vertical e deslocamento horizontal inverso.
- A seleção agora é aleatória a cada troca, sem repetir imediatamente o efeito anterior.
- A fila de cenas e o carregamento em segundo plano foram preservados.

## LIVE — letras e apresentação
- A legenda foi removida do rodapé junto ao nome da música.
- No modo vertical, aparece centralizada sobre a imagem.
- No modo horizontal, aparece na metade direita da composição.
- A legenda não recebe caixa/fundo próprio; mantém sombra para legibilidade.
- Adicionados cinco estilos selecionáveis e persistidos: Karaokê (preenchimento progressivo), Palavra por palavra (uma palavra ativa), Clássica (serifada), Neon (monoespaçada) e Minimalista. O estilo Palavra por palavra usa família cursiva do sistema como opção de aparência manuscrita.
- O texto entre colchetes (por exemplo `[verso2]`, `[refrão]` e tags de metadados) é removido antes de exibir a letra.
- Tamanho adaptativo, ajuste progressivo quando o layout excede o limite e máximo de duas linhas.
- A resolução de letra sincronizada segue: LRC original do Stream → LRC comunitário → LRCLIB → texto simples original como fallback.

## Player — atalho principal e simplificação
- Removido o botão “Compartilhar música” do conjunto de ações do player.
- O atalho de edição foi renomeado para “SONUS EDIT LITE”.
- O conjunto de ações do player passa a mostrar Sonus Edit Lite e LIVE.
- Removida a classe `SonusEditBridge` do pacote porque a opção de abrir o editor externo foi retirada do fluxo.
- Sonus Edit Lite abre diretamente na tela de criação, sem menu intermediário.

## Sonus Edit Lite — galeria e seleção
- A galeria consulta as três pastas públicas pCloud já configuradas no projeto.
- A consulta aceita fotos e vídeos, sem iniciar reprodução de vídeo na tela de seleção.
- Cada item recebe selo `FOTO` ou `VÍDEO`.
- Até 50 mídias são exibidas como opções por vez; a lista completa é mantida para busca.
- A classificação automática considera título, gênero, artista, álbum e contexto da letra.
- Imagens identificadas como religiosas são filtradas nas sugestões automáticas de faixas não religiosas; a pesquisa manual explícita continua podendo retornar imagens religiosas.

## Sonus Edit Lite — exportação e legendas
- O exportador agora baixa fotos e vídeos selecionados, respeitando limites de 120 MB por vídeo e 500 MB para o conjunto.
- Vídeos são incorporados à linha do tempo sem reprodução na galeria; o áudio original do arquivo visual é silenciado para preservar a música selecionada.
- Clipe curto pode ser repetido para preencher a duração atribuída àquele item; vídeos longos são cortados para caber no trecho.
- O download temporário é removido inclusive em caso de falha durante a preparação.
- Para faixas do Stream, a busca sincronizada usa o mesmo resolvedor Stream/comunitário/LRCLIB.
- O tamanho-base das legendas do vídeo foi reduzido em aproximadamente 10%, com paleta um pouco mais luminosa e quebra de texto limitada a duas linhas.
- Adicionada camada de seleção com quatro opções: Padrão, Alione, Impact Stone e Bainsley Bold Italic.

## STREAM — permissões OWNER
- Usuários comuns continuam sujeitos ao intervalo de 30 dias para alterar o nome artístico.
- Contas com `AccountRole.OWNER` podem alterar o nome a qualquer momento.
- A exceção é aplicada na validação da operação, não apenas na interface.
- A paginação progressiva, o cache e o carregamento sob demanda existentes foram preservados.

## Limitações conhecidas desta entrega
- As três pastas encontradas no código são links públicos **pCloud**, não iCloud. Seus códigos estão presentes, mas não foi possível validar a resposta externa dos links neste ambiente por indisponibilidade de rede/DNS.
- As opções Alione, Impact Stone e Bainsley Bold Italic aparecem no seletor, mas os arquivos originais das fontes não foram incorporados. O projeto usa famílias tipográficas do sistema como aproximação até que os arquivos corretos e as licenças necessárias estejam disponíveis. “Alione” não foi identificado de forma confiável como nome exato de uma família tipográfica; Impact Stone exige licença App/Game para incorporação em aplicativo; Bainsley Bold Italic é listado como SIL Open Font License 1.1.
- A fonte de mensagem de erro na abertura da LIVE não foi localizada no código Kotlin atual: a preparação visual já falha silenciosamente e a LIVE mantém o cenário SONUS enquanto tenta novamente. O fluxo de carregamento não foi alterado.
- O comportamento visual final, a disponibilidade externa das pastas e a exportação de vídeos precisam de teste no aparelho real.
- Nenhum novo gargalo isolado do STREAM foi confirmado durante a inspeção; por segurança, foram preservados o cache/paginação existentes e os módulos de áudio/player protegidos, sem uma alteração especulativa que pudesse prejudicar a reprodução.

## Preservação técnica
- `AudioToolEngine.kt` e `PulsePlayerService.kt` permanecem idênticos à base CODE08.
- `SonusStreamPlatform.kt` recebeu apenas a exceção de permissão OWNER para a troca do nome artístico e a respectiva mensagem/estado de interface.
- Nenhum fallback para assinatura debug foi adicionado.
