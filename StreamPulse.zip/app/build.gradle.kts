plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("org.jetbrains.kotlin.plugin.serialization")
    id("com.google.gms.google-services")
}

android {
    namespace = "com.sonusstudios.streampulse"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.sonusstudios.streampulse"
        minSdk = 26
        targetSdk = 36
        versionCode = 127
        versionName = "1.0.24"

        // Injetada pelo GitHub Actions via secret YOUTUBE_API_KEY. Em builds locais sem
        // a variável, os recursos da YouTube Data API ficam indisponíveis sem quebrar o app.
        val youtubeApiKey = (System.getenv("YOUTUBE_API_KEY") ?: "")
            .replace("\\", "\\\\")
            .replace("\"", "\\\"")
        buildConfigField("String", "YOUTUBE_API_KEY", "\"$youtubeApiKey\"")

        // Segurança de monetização: anúncios reais só entram quando o build do GitHub
        // receber SONUS_REAL_ADS=true. Sem isso, o app usa o bloco oficial de teste.
        val realAdsEnabled = (System.getenv("SONUS_REAL_ADS") ?: "false").equals("true", ignoreCase = true)
        buildConfigField("boolean", "REAL_ADS_ENABLED", realAdsEnabled.toString())

        // SONUS Stream: catálogo público somente leitura no pCloud.
        // O código do link público não é credencial e não concede permissão de escrita.
        buildConfigField("String", "SONUS_PCLOUD_PUBLIC_CODE", "\"kZoiqzJZYKnSUcvcE3yhv2kogYMgtzmoSLyX\"")

        // Segunda fonte pública do catálogo SONUS Stream. A origem é interna e nunca é exibida na UI.
        buildConfigField("String", "SONUS_PCLOUD_SECONDARY_PUBLIC_CODE", "\"kZjNE8JZ1u7bptnw2J7AJmDn04hFe8O3o09k\"")

        // Biblioteca pública oficial de letras sincronizadas do SONUS.
        // O link é somente leitura; nenhuma credencial de escrita é embarcada no APK.
        buildConfigField("String", "SONUS_LRC_PCLOUD_PUBLIC_CODE", "\"kZNiXQJZTobHXlzVPjzsj9LyASRI77DUtfJk\"")

        // code122: pasta pública dedicada apenas aos APKs de atualização do SONUS.
        // Código público não é credencial e não concede escrita no pCloud.
        buildConfigField("String", "SONUS_UPDATE_PCLOUD_PUBLIC_CODE", "\"kZPPs8JZNBif4G3VzdfDsowilxjXSVFBUHAy\"")

        // code108 preserva o endpoint seguro do Cloudflare Worker que encaminha os envios
        // processados do SONUS para o grupo privado de análise no Telegram.
        // O token do bot e o chat_id NÃO ficam no APK; permanecem como Secrets no Worker.
        val sonusTelegramUploadBase = (System.getenv("SONUS_TELEGRAM_UPLOAD_BASE") ?: "https://sonus-telegram-upload.raffatheoo.workers.dev")
            .replace("\\", "\\\\")
            .replace("\"", "\\\"")
        buildConfigField("String", "SONUS_TELEGRAM_UPLOAD_BASE", "\"$sonusTelegramUploadBase\"")

        // Backend seguro do SONUS Stream. Pode ser sobrescrito por variável de ambiente; por padrão usa
        // o projeto Firebase oficial da aplicação e nunca expõe credenciais privadas.
        val sonusStreamProxyBase = (System.getenv("SONUS_STREAM_PROXY_BASE") ?: "https://southamerica-east1-streenpulse.cloudfunctions.net")
            .replace("\\", "\\\\")
            .replace("\"", "\\\"")
        buildConfigField("String", "SONUS_STREAM_PROXY_BASE", "\"$sonusStreamProxyBase\"")

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    signingConfigs {
        create("betaDebug") {
            storeFile = file("beta-debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        getByName("debug") {
            // O GitHub Actions gera a variante debug para o beta interno.
            // Mantemos o mesmo keystore, mas desativamos debuggability e ativamos R8
            // para aproximar a fluidez de uma build de produção.
            signingConfig = signingConfigs.getByName("betaDebug")
            isDebuggable = false
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2026.06.00")
    implementation(composeBom)

    implementation("androidx.activity:activity-compose:1.13.0")
    implementation("androidx.core:core-ktx:1.17.0")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.navigation:navigation-compose:2.9.8")
    implementation("androidx.datastore:datastore-preferences:1.2.1")
    implementation("androidx.work:work-runtime-ktx:2.10.1")
    implementation("androidx.media3:media3-exoplayer:1.11.1")
    implementation("androidx.media3:media3-ui:1.11.1")
    implementation("androidx.media3:media3-common:1.11.1")
    implementation("androidx.media3:media3-effect:1.11.1")
    implementation("androidx.media3:media3-transformer:1.11.1")
    implementation("androidx.documentfile:documentfile:1.1.0")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.9.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")

    // code121: o Conversor de Vídeo precisa dos muxers/codecs de vídeo, mas o pacote Full
    // preserva a mesma API com.arthenica.ffmpegkit já usada pelo Conversor de Áudio.
    // Mantemos a linha 8.1.7 para reduzir risco de regressão nas ferramentas de áudio.
    implementation("dev.ffmpegkit-maintained:ffmpeg-kit-full:8.1.7")
    // O artefato ffmpeg-kit-audio 8.1.7 referencia o Smart Exception, mas
    // sua publicação atual não declara essa dependência de forma transitiva.
    // Mantemos a versão oficial usada pelo FFmpegKit para evitar falha do R8.
    implementation("com.arthenica:smart-exception-java:0.2.1")

    // Firebase Authentication + Realtime Database.
    implementation(platform("com.google.firebase:firebase-bom:34.16.0"))
    implementation("com.google.firebase:firebase-auth")
    implementation("com.google.firebase:firebase-database")
    implementation("com.google.firebase:firebase-storage")
    implementation("com.google.firebase:firebase-appcheck-playintegrity")

    // Login com Google via Credential Manager (fluxo recomendado pelo Firebase).
    implementation("androidx.credentials:credentials:1.3.0")
    implementation("androidx.credentials:credentials-play-services-auth:1.3.0")
    implementation("com.google.android.libraries.identity.googleid:googleid:1.1.1")

    // Monetização: anúncios premiados + consentimento de privacidade (UMP).
    implementation("com.google.android.gms:play-services-ads:25.4.0")
    implementation("com.google.android.ump:user-messaging-platform:4.0.0")

    // Serviços em primeiro plano e lifecycle para gravação robusta.
    implementation("androidx.lifecycle:lifecycle-process:2.9.2")
    implementation("androidx.camera:camera-core:1.4.2")
    implementation("androidx.camera:camera-camera2:1.4.2")
    implementation("androidx.camera:camera-lifecycle:1.4.2")
    implementation("androidx.camera:camera-view:1.4.2")
    // Required by ProcessCameraProvider.getInstance(): CameraX exposes Guava ListenableFuture.
    // Keep this explicit to avoid Kotlin compile errors in GitHub Actions.
    // androidx.heifwriter exige API 28. O app continua minSdk 26; o manifest
    // autoriza a biblioteca e o código HEIC fica isolado/guardado para API 28+.
    implementation("androidx.heifwriter:heifwriter:1.0.0")

    // Player oficial incorporado do YouTube, baseado na IFrame Player API.
    // v13 usa o package do app como origin e trata o HTTP Referer exigido pelo YouTube.
    implementation("com.pierfrancescosoffritti.androidyoutubeplayer:core:13.0.0")

    debugImplementation("androidx.compose.ui:ui-tooling")
}
