plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("org.jetbrains.kotlin.plugin.serialization")
    id("com.google.gms.google-services")
}

android {
    namespace = "com.sonusstudios.streampulse"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.sonusstudios.streampulse"
        minSdk = 26
        targetSdk = 36
        versionCode = 7
        versionName = "0.0.7"

        // Segurança de monetização: anúncios reais só entram quando o build do GitHub
        // receber SONUS_REAL_ADS=true. Sem isso, o app usa o bloco oficial de teste.
        val realAdsEnabled = (System.getenv("SONUS_REAL_ADS") ?: "false").equals("true", ignoreCase = true)
        buildConfigField("boolean", "REAL_ADS_ENABLED", realAdsEnabled.toString())

        // Login com Google: fica ESCONDIDO na tela de login até o APK sair assinado com a chave permanente
        // (a SHA-1 cadastrada no Firebase). Para ligar, defina SONUS_GOOGLE_LOGIN=true no Codemagic.
        val googleLoginEnabled = (System.getenv("SONUS_GOOGLE_LOGIN") ?: "false").equals("true", ignoreCase = true)
        buildConfigField("boolean", "GOOGLE_LOGIN_ENABLED", googleLoginEnabled.toString())

        // SONUS Stream: catálogo público somente leitura no pCloud.
        // O código do link público não é credencial e não concede permissão de escrita.
        buildConfigField("String", "SONUS_PCLOUD_PUBLIC_CODE", "\"kZoiqzJZYKnSUcvcE3yhv2kogYMgtzmoSLyX\"")

        // Segunda fonte pública do catálogo SONUS Stream. A origem é interna e nunca é exibida na UI.
        buildConfigField("String", "SONUS_PCLOUD_SECONDARY_PUBLIC_CODE", "\"kZjNE8JZ1u7bptnw2J7AJmDn04hFe8O3o09k\"")
        // Terceira pasta pública do SONUS Stream (somente leitura).
        buildConfigField("String", "SONUS_PCLOUD_TERTIARY_PUBLIC_CODE", "\"kZ1MPSJZOx4zaPJ6YjLe5qaUy8Qw94bFfmpV\"")

        // code122: pasta pública dedicada apenas aos APKs de atualização do SONUS.
        // Código público não é credencial e não concede escrita no pCloud.
        buildConfigField("String", "SONUS_UPDATE_PCLOUD_PUBLIC_CODE", "\"kZPPs8JZNBif4G3VzdfDsowilxjXSVFBUHAy\"")

        // code108 preserva o endpoint seguro do Cloudflare Worker que encaminha os envios
        // processados do SONUS para o grupo privado de análise no Telegram.
        // O token do bot e o chat_id NÃO ficam no APK; permanecem como Secrets no Worker.
        val sonusTelegramUploadBase = (System.getenv("SONUS_TELEGRAM_UPLOAD_BASE") ?: "https://sonus-telegram-upload.raffatheoo.workers.dev")
            .replace("\\", "\\\\")
            .replace("\"", "\\\"")
        buildConfigField("String", "SONUS_TELEGRAM_UPLOAD_BASE", "\"$sonusTelegramUploadBase\"")

        // Backend seguro do SONUS Stream. Pode ser sobrescrito por variável de ambiente; por padrão usa
        // o projeto Firebase oficial da aplicação e nunca expõe credenciais privadas.
        val sonusStreamProxyBase = (System.getenv("SONUS_STREAM_PROXY_BASE") ?: "https://southamerica-east1-streenpulse.cloudfunctions.net")
            .replace("\\", "\\\\")
            .replace("\"", "\\\"")
        buildConfigField("String", "SONUS_STREAM_PROXY_BASE", "\"$sonusStreamProxyBase\"")
        // Página HTTPS pública hospedada no Firebase Hosting; /share encaminha para a função de compartilhamento.
        val sonusShareBase = (System.getenv("SONUS_SHARE_BASE") ?: "https://streenpulse.web.app/share")
            .replace("\\", "\\\\")
            .replace("\"", "\\\"")
        buildConfigField("String", "SONUS_SHARE_BASE", "\"$sonusShareBase\"")

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    // 0.0.2: o SONUS usa a MESMA chave permanente do SONUS Edit (sonus-edit-dev.jks, alias sonusedit).
    // O arquivo é restaurado pelo codemagic.yaml; as SENHAS nunca ficam no código: vêm das variáveis de ambiente
    // SONUS_KEYSTORE_PASSWORD (e opcionalmente SONUS_KEY_PASSWORD / SONUS_KEY_ALIAS) vêm do Codemagic (grupo sonus_signing).
    // A assinatura permanente é obrigatória. Nunca gerar APK instalável com chave debug/de teste,
    // pois isso causa conflito ao atualizar uma instalação assinada com a chave oficial.
    val sonusKeystorePath = System.getenv("SONUS_KEYSTORE_PATH").orEmpty()
    val sonusKeystorePassword = System.getenv("SONUS_KEYSTORE_PASSWORD").orEmpty()
    val hasPermanentKey = sonusKeystorePath.isNotBlank() && sonusKeystorePassword.isNotBlank() && file(sonusKeystorePath).exists()
    if (!hasPermanentKey) {
        throw GradleException(
            "Assinatura oficial SONUS ausente. Configure SONUS_KEYSTORE_PATH e SONUS_KEYSTORE_PASSWORD no ambiente de build."
        )
    }
    signingConfigs {
        create("sonus") {
            if (hasPermanentKey) {
                storeFile = file(sonusKeystorePath)
                storePassword = sonusKeystorePassword
                keyAlias = System.getenv("SONUS_KEY_ALIAS")?.takeIf { it.isNotBlank() } ?: "sonusedit"
                keyPassword = System.getenv("SONUS_KEY_PASSWORD")?.takeIf { it.isNotBlank() } ?: sonusKeystorePassword
            }
        }
    }

    buildTypes {
        getByName("debug") {
            // O Codemagic gera a variante interna, sempre assinada com a chave oficial do SONUS.
            // Desativamos debuggability e ativamos R8
            // para aproximar a fluidez de uma build de produção.
            signingConfig = signingConfigs.getByName("sonus")
            isDebuggable = false
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2026.06.00")
    implementation(composeBom)

    implementation("androidx.activity:activity-compose:1.13.0")
    implementation("androidx.core:core-ktx:1.17.0")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.navigation:navigation-compose:2.9.8")
    implementation("androidx.datastore:datastore-preferences:1.2.1")
    implementation("androidx.work:work-runtime-ktx:2.10.1")
    implementation("androidx.media3:media3-exoplayer:1.11.1")
    implementation("androidx.media3:media3-ui:1.11.1")
    implementation("androidx.media3:media3-common:1.11.1")
    implementation("androidx.media3:media3-effect:1.11.1")
    implementation("androidx.media3:media3-transformer:1.11.1")
    implementation("androidx.documentfile:documentfile:1.1.0")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.9.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")

    // code121: o Conversor de Vídeo precisa dos muxers/codecs de vídeo, mas o pacote Full
    // preserva a mesma API com.arthenica.ffmpegkit já usada pelo Conversor de Áudio.
    // Mantemos a linha 8.1.7 para reduzir risco de regressão nas ferramentas de áudio.
    implementation("dev.ffmpegkit-maintained:ffmpeg-kit-full:8.1.7")
    // O artefato ffmpeg-kit-audio 8.1.7 referencia o Smart Exception, mas
    // sua publicação atual não declara essa dependência de forma transitiva.
    // Mantemos a versão oficial usada pelo FFmpegKit para evitar falha do R8.
    implementation("com.arthenica:smart-exception-java:0.2.1")

    // Firebase Authentication + Realtime Database.
    implementation(platform("com.google.firebase:firebase-bom:34.16.0"))
    implementation("com.google.firebase:firebase-auth")
    implementation("com.google.firebase:firebase-database")
    implementation("com.google.firebase:firebase-storage")
    implementation("com.google.firebase:firebase-appcheck-playintegrity")

    // Login com Google via Credential Manager (fluxo recomendado pelo Firebase).
    implementation("androidx.credentials:credentials:1.3.0")
    implementation("androidx.credentials:credentials-play-services-auth:1.3.0")
    implementation("com.google.android.libraries.identity.googleid:googleid:1.1.1")

    // Monetização: anúncios premiados + consentimento de privacidade (UMP).
    implementation("com.google.android.gms:play-services-ads:25.4.0")
    implementation("com.google.android.ump:user-messaging-platform:4.0.0")

    // Serviços em primeiro plano e lifecycle para gravação robusta.
    implementation("androidx.lifecycle:lifecycle-process:2.9.2")
    implementation("androidx.camera:camera-core:1.4.2")
    implementation("androidx.camera:camera-camera2:1.4.2")
    implementation("androidx.camera:camera-lifecycle:1.4.2")
    implementation("androidx.camera:camera-view:1.4.2")
    // Required by ProcessCameraProvider.getInstance(): CameraX exposes Guava ListenableFuture.
    // Keep this explicit to avoid Kotlin compile errors in GitHub Actions.
    // androidx.heifwriter exige API 28. O app continua minSdk 26; o manifest
    // autoriza a biblioteca e o código HEIC fica isolado/guardado para API 28+.
    implementation("androidx.heifwriter:heifwriter:1.0.0")

    
    debugImplementation("androidx.compose.ui:ui-tooling")
}
