# FFmpegKit usa JNI/reflexão em partes da API e depende do Smart Exception.
# Mantemos essas classes no beta minificado para evitar remoção pelo R8.
-keep class com.arthenica.ffmpegkit.** { *; }
-keep class com.arthenica.smartexception.** { *; }
-dontwarn com.arthenica.smartexception.**
# Namespace real usado pela publicação 0.2.1 do Smart Exception.
-keep class com.arthenica.smart_exception.** { *; }
-dontwarn com.arthenica.smart_exception.**

# Ponte JavaScript usada pelo player oficial do YouTube no WebView do Karaokê.
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
