package com.sonusstudios.streampulse.tools

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.sonusstudios.streampulse.core.SonusMediaStandards
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.Normalizer
import java.util.Locale

@Composable
internal fun SonusBulkMetadataEditor(
    repo: SonusOnlineMusicRepository,
    genres: List<SonusOnlineGenre>,
    onClose: () -> Unit,
    onSaved: (String) -> Unit
) {
    val scope = rememberCoroutineScope()
    var folder by remember(genres) { mutableStateOf(genres.firstOrNull()) }
    val folderTracks = remember(folder, genres) { folder?.let { repo.cachedTracks(it.path) }.orEmpty() }
    val allTracks = remember(genres) { genres.flatMap { repo.cachedTracks(it.path) }.distinctBy { it.fileId } }
    val artists = remember(allTracks) {
        allTracks.map { it.artist.trim().replace(Regex("\\s+"), " ") }
            .filter { it.isNotBlank() }
            .distinctBy(::artistKey)
            .sortedBy { it.lowercase(Locale.ROOT) }
    }
    var folderMenu by remember { mutableStateOf(false) }
    var genreMenu by remember { mutableStateOf(false) }
    var genre by remember { mutableStateOf("") }
    var artist by remember { mutableStateOf("") }
    var artistSearch by remember { mutableStateOf("") }
    var album by remember { mutableStateOf("") }
    var year by remember { mutableStateOf("") }
    var trackSearch by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<Set<Long>>(emptySet()) }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    val visibleTracks = remember(folderTracks, trackSearch) {
        folderTracks.filter { item -> trackSearch.isBlank() || item.displayTitle.contains(trackSearch, true) || item.artist.contains(trackSearch, true) }
    }
    val artistMatches = remember(artists, artistSearch) {
        if (artistSearch.isBlank()) artists.take(8) else artists.filter { it.contains(artistSearch, true) || artistKey(it).contains(artistKey(artistSearch)) }.take(12)
    }

    AlertDialog(
        onDismissRequest = { if (!busy) onClose() },
        title = { Text("Edição de música em lote", fontWeight = FontWeight.Black) },
        text = {
            Column(
                Modifier.fillMaxWidth().heightIn(max = 650.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Escolha uma das três pastas, marque as faixas e preencha somente os campos que deseja atualizar. Campos vazios serão preservados.", style = MaterialTheme.typography.bodySmall)
                Box {
                    OutlinedButton(onClick = { folderMenu = true }, modifier = Modifier.fillMaxWidth(), enabled = !busy) {
                        Icon(Icons.Default.Folder, null); Spacer(Modifier.width(7.dp))
                        Text(folder?.name ?: "Selecionar pasta de músicas", modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    DropdownMenu(expanded = folderMenu, onDismissRequest = { folderMenu = false }) {
                        genres.forEach { g -> DropdownMenuItem(text = { Text(g.name) }, onClick = { folder = g; selected = emptySet(); folderMenu = false }) }
                    }
                }
                Text("METADADOS PARA APLICAR", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                Box {
                    OutlinedButton(onClick = { genreMenu = true }, modifier = Modifier.fillMaxWidth(), enabled = !busy) {
                        Text(if (genre.isBlank()) "Gênero (não alterar)" else genre, modifier = Modifier.weight(1f), maxLines = 1)
                    }
                    DropdownMenu(expanded = genreMenu, onDismissRequest = { genreMenu = false }) {
                        SonusMediaStandards.genres.forEach { g -> DropdownMenuItem(text = { Text(g) }, onClick = { genre = g; genreMenu = false }) }
                        DropdownMenuItem(text = { Text("Não alterar gênero") }, onClick = { genre = ""; genreMenu = false })
                    }
                }
                OutlinedTextField(value = artistSearch, onValueChange = { artistSearch = it; artist = "" }, label = { Text("Artista • pesquisar ou digitar novo") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true, modifier = Modifier.fillMaxWidth(), enabled = !busy)
                if (artistMatches.isNotEmpty()) {
                    Text("ARTISTAS JÁ CADASTRADOS", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        artistMatches.forEach { name ->
                            FilterChip(selected = artist.equals(name, true), onClick = { artist = name; artistSearch = name }, label = { Text(name, maxLines = 1) }, enabled = !busy)
                        }
                    }
                }
                if (artistSearch.isNotBlank() && artistMatches.none { artistKey(it) == artistKey(artistSearch) }) {
                    TextButton(onClick = { artist = artistSearch.trim().replace(Regex("\\s+"), " ") }, enabled = !busy) { Text("Usar novo artista: ${artistSearch.trim()}") }
                }
                OutlinedTextField(value = album, onValueChange = { album = it.take(120) }, label = { Text("Álbum (vazio = não alterar)") }, singleLine = true, modifier = Modifier.fillMaxWidth(), enabled = !busy)
                OutlinedTextField(value = year, onValueChange = { year = it.filter(Char::isDigit).take(4) }, label = { Text("Ano (vazio = não alterar)") }, singleLine = true, modifier = Modifier.fillMaxWidth(), enabled = !busy)

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("MÚSICAS (${selected.size} selecionadas)", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    TextButton(onClick = { selected = if (selected.size == visibleTracks.size) emptySet() else visibleTracks.map { it.fileId }.toSet() }, enabled = !busy && visibleTracks.isNotEmpty()) {
                        Text(if (selected.size == visibleTracks.size && visibleTracks.isNotEmpty()) "Desmarcar" else "Selecionar todas")
                    }
                }
                OutlinedTextField(value = trackSearch, onValueChange = { trackSearch = it }, label = { Text("Pesquisar música") }, singleLine = true, modifier = Modifier.fillMaxWidth(), enabled = !busy)
                Column(Modifier.fillMaxWidth().heightIn(max = 230.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    visibleTracks.forEach { track ->
                        Row(Modifier.fillMaxWidth().clickable(enabled = !busy) { selected = if (track.fileId in selected) selected - track.fileId else selected + track.fileId }.padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = track.fileId in selected, onCheckedChange = { checked -> selected = if (checked) selected + track.fileId else selected - track.fileId }, enabled = !busy)
                            Column(Modifier.weight(1f)) {
                                Text(track.displayTitle, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(track.artist.ifBlank { "Artista não informado" }, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                            }
                        }
                    }
                }
                Text("As letras TXT/LRC, capas e demais dados não serão modificados por esta edição em lote.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                if (busy) {
                    Row(verticalAlignment = Alignment.CenterVertically) { CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp); Spacer(Modifier.width(8.dp)); Text(progress, style = MaterialTheme.typography.labelSmall) }
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            Button(onClick = {
                val updates = buildMap {
                    if (genre.isNotBlank()) put("genre", genre)
                    val typedArtist = artist.ifBlank { artistSearch.trim() }
                    if (typedArtist.isNotBlank()) {
                        val canonical = artists.firstOrNull { artistKey(it) == artistKey(typedArtist) } ?: typedArtist.replace(Regex("\\s+"), " ")
                        put("artist", canonical)
                    }
                    if (album.isNotBlank()) put("album", album.trim())
                    if (year.isNotBlank()) put("year", year)
                }
                if (selected.isEmpty()) { error = "Selecione pelo menos uma música."; return@Button }
                if (updates.isEmpty()) { error = "Preencha ao menos um metadado para atualizar."; return@Button }
                busy = true; error = null
                scope.launch {
                    val result = withContext(Dispatchers.IO) {
                        runCatching {
                            repo.refreshTrackOverrides(force = true)
                            val chosen = folderTracks.filter { it.fileId in selected }
                            val batch = chosen.associate { track ->
                                // O nó do Firebase é substituído ao salvar. Mesclamos tanto o override
                                // existente quanto os metadados originais da faixa; assim letras que
                                // ainda estão no catálogo-base também são copiadas e preservadas.
                                val existing = repo.trackOverride(track.fileId)
                                val merged = linkedMapOf(
                                    "title" to existing["title"].orEmpty().ifBlank { track.title },
                                    "artist" to existing["artist"].orEmpty().ifBlank { track.artist },
                                    "album" to existing["album"].orEmpty().ifBlank { track.album },
                                    "genre" to existing["genre"].orEmpty().ifBlank { track.genre },
                                    "year" to existing["year"].orEmpty().ifBlank { track.year },
                                    "trackNumber" to existing["trackNumber"].orEmpty().ifBlank { track.trackNumber },
                                    "lyrics" to existing["lyrics"].orEmpty().ifBlank { track.lyrics },
                                    "lyricsFormat" to existing["lyricsFormat"].orEmpty().ifBlank { track.lyricsFormat },
                                    "coverBase64" to existing["coverBase64"].orEmpty().ifBlank { track.adminCoverBase64.orEmpty() }
                                )
                                merged.putAll(updates)
                                track.fileId to merged
                            }
                            repo.saveTrackAdminOverridesBatch(batch).getOrThrow()
                            batch.size
                        }
                    }
                    busy = false
                    result.onSuccess { count -> onSaved("✓ ${count} música(s) atualizada(s). Letras e capas preservadas."); onClose() }
                        .onFailure { error = "Não foi possível concluir: ${it.message ?: "erro ao salvar"}" }
                }
            }, enabled = !busy) { Icon(Icons.Default.Save, null); Spacer(Modifier.width(5.dp)); Text("Aplicar às selecionadas") }
        },
        dismissButton = { TextButton(onClick = onClose, enabled = !busy) { Text("Fechar") } }
    )
}

private fun artistKey(value: String): String = Normalizer.normalize(value.trim().lowercase(Locale.ROOT), Normalizer.Form.NFD)
    .replace(Regex("\\p{M}+"), "")
    .replace("&", " e ")
    .replace(Regex("[^a-z0-9]+"), " ")
    .replace(Regex("\\s+"), " ").trim()
