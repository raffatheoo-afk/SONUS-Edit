package com.sonusstudios.streampulse.cloud

import com.google.android.gms.tasks.Task
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ServerValue
import com.sonusstudios.streampulse.BuildConfig
import com.sonusstudios.streampulse.core.AppState
import com.sonusstudios.streampulse.core.MembershipTier
import com.sonusstudios.streampulse.core.UserPreferences
import com.sonusstudios.streampulse.support.sonusPublicId
import java.time.Instant
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.util.Locale
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

@Serializable
enum class CouponType { COINS, PREMIUM, REMOVE_ADS, DISCOUNT, AD_REWARD_2X }

@Serializable
data class PromoCoupon(
    val code: String,
    val type: CouponType,
    val amount: Int = 0,
    val tierName: String? = null,
    val durationHours: Int = 0,
    val discountPercent: Int = 0,
    val active: Boolean = true,
    val unlimitedUses: Boolean = false,
    val maxUses: Int = 100,
    val expiresAtEpochMillis: Long? = null,
    val description: String = "",
    val createdAtEpochMillis: Long = System.currentTimeMillis(),
    val usedCount: Int = 0
)

data class CouponRedemptionResult(
    val coupon: PromoCoupon,
    val redeemedAtEpochMillis: Long,
    val message: String
)


data class RemotePromotionState(
    val tierName: String? = null,
    val premiumUntil: Long? = null,
    val adFreeUntil: Long? = null,
    val adMultiplier: Int = 1,
    val adMultiplierUntil: Long? = null,
    val discountPercent: Int? = null,
    val discountTierName: String? = null,
    val discountUntil: Long? = null
)

data class DistributionTrialState(
    val startedAt: Long = 0L,
    val expiresAt: Long = 0L,
    val active: Boolean = false
)

data class CloudBackupStatus(
    val lastBackupAtEpochMillis: Long? = null,
    val message: String? = null
)

data class AnalyticsEvent(
    val name: String,
    val category: String,
    val tier: String,
    val success: Boolean? = null,
    val durationMs: Long? = null,
    val createdAtEpochMillis: Long = System.currentTimeMillis()
)

data class AdminAnalyticsSnapshot(
    val registeredUsers: Int = 0,
    val onlineUsers: Int = 0,
    val activeToday: Int = 0,
    val active7d: Int = 0,
    val active30d: Int = 0,
    val newUsers7d: Int = 0,
    val newUsers30d: Int = 0,
    val eventCounts: Map<String, Int> = emptyMap(),
    val toolCountsToday: Map<String, Int> = emptyMap(),
    val toolCounts7d: Map<String, Int> = emptyMap(),
    val toolCounts30d: Map<String, Int> = emptyMap(),
    val pageCountsToday: Map<String, Int> = emptyMap(),
    val pageCounts7d: Map<String, Int> = emptyMap(),
    val pageCounts30d: Map<String, Int> = emptyMap(),
    val errorCounts7d: Map<String, Int> = emptyMap(),
    val successCounts: Map<String, Pair<Int, Int>> = emptyMap(),
    val averageDurationMs: Map<String, Long> = emptyMap(),
    val tierCounts: Map<String, Int> = emptyMap(),
    val couponUses: Map<String, Int> = emptyMap(),
    val warnings: List<String> = emptyList()
)

data class SupportTeamMember(
    val uid: String,
    val publicId: String,
    val displayName: String?,
    val email: String?,
    val active: Boolean,
    val permissions: Map<String, Boolean> = emptyMap()
)

/**
 * Infraestrutura remota do StreamPulse baseada somente no Realtime Database.
 * Dados musicais sensíveis não são enviados para analytics; o backup é privado por UID.
 */
class CloudAccountManager {
    private val database = FirebaseDatabase.getInstance()
    private val auth = FirebaseAuth.getInstance()
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    suspend fun ensureAccount(uid: String, displayName: String?, email: String?) {
        val ref = database.getReference("accounts").child(uid)
        val existing = ref.get().awaitValue()
        val now = System.currentTimeMillis()
        val values = mutableMapOf<String, Any?>(
            "lastSeenAt" to now,
            "lastSeenDay" to LocalDate.now().toString(),
            "publicId" to sonusPublicId(uid)
        )
        if (!existing.exists()) {
            values["createdAt"] = now
            values["createdDay"] = LocalDate.now().toString()
        }
        if (!displayName.isNullOrBlank()) values["displayName"] = displayName.take(120)
        // E-mail não é necessário para métricas; guardamos apenas se a própria conta já expõe isso ao Firebase Auth.
        if (!email.isNullOrBlank()) values["email"] = email.take(180)
        ref.updateChildren(values).awaitCompletion()
    }

    /**
     * Atualiza somente a atividade agregada da conta quando o app volta ao primeiro plano.
     * É uma escrita leve, sem heartbeat contínuo.
     */
    suspend fun touchActivity(uid: String): Result<Unit> = runCatching {
        if (uid.isBlank()) return@runCatching
        database.getReference("accounts").child(uid).updateChildren(
            mapOf(
                "lastSeenAt" to System.currentTimeMillis(),
                "lastSeenDay" to LocalDate.now().toString()
            )
        ).awaitCompletion()
    }

    /** Inicia o trial somente na primeira abertura e consulta o mesmo registro nas próximas vezes. */
    suspend fun activateDistributionTrial(): Result<DistributionTrialState> = runCatching {
        val current = auth.currentUser ?: error("Entre na sua conta para iniciar o teste.")
        val base = BuildConfig.SONUS_STREAM_PROXY_BASE.trim().trimEnd('/')
        require(base.isNotBlank()) { "Serviço SONUS temporariamente indisponível." }
        val token = current.getIdToken(false).awaitValue().token ?: error("Não foi possível validar sua sessão.")
        val response = withContext(Dispatchers.IO) {
            val c = (URL("$base/distributionTrial").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"; connectTimeout = 10_000; readTimeout = 15_000; doOutput = true
                setRequestProperty("Authorization", "Bearer $token")
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
            }
            try {
                c.outputStream.use { it.write("{}".toByteArray()) }
                val body = (if (c.responseCode in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
                if (c.responseCode !in 200..299) error("Não foi possível ativar o teste agora.")
                JSONObject(body)
            } finally { c.disconnect() }
        }
        DistributionTrialState(
            startedAt = response.optLong("startedAt", 0L),
            expiresAt = response.optLong("expiresAt", 0L),
            active = response.optBoolean("active", false)
        )
    }

    private fun sanitizeForCloudBackup(state: AppState): AppState {
        val p = state.preferences
        return state.copy(
            artists = state.artists.map { it.copy(photoPath = null) },
            preferences = p.copy(
                backgroundPhotoPath = null,
                // Autoridade vem do servidor/plano atual, nunca do backup restaurável.
                promotionalTierName = null,
                premiumExpiresAtEpochMillis = null,
                adFreeUntilEpochMillis = null,
                adRewardMultiplier = 1,
                adRewardMultiplierUntilEpochMillis = null,
                discountPercent = null,
                discountTierName = null,
                discountUntilEpochMillis = null,
                converterCoins = 0,
                converterCoinsPeriod = null,
                converterCoinsOwnerUid = null,
                pulseMonthlyCoins = 0,
                pulseBonusCoins = 0,
                pulseCoinsPeriod = null,
                pulseCoinsOwnerUid = null,
                pulseUsageTierName = null
            )
        )
    }

    suspend fun uploadBackup(uid: String, state: AppState): Result<Long> = runCatching {
        val now = System.currentTimeMillis()
        val payload = json.encodeToString(sanitizeForCloudBackup(state))
        database.getReference("backups").child(uid).setValue(
            mapOf(
                "stateJson" to payload,
                "updatedAt" to now,
                "appSchema" to state.schemaVersion
            )
        ).awaitCompletion()
        now
    }

    suspend fun downloadBackup(uid: String): Result<Pair<AppState, Long>?> = runCatching {
        val snap = database.getReference("backups").child(uid).get().awaitValue()
        val raw = snap.child("stateJson").getValue(String::class.java) ?: return@runCatching null
        val updatedAt = snap.child("updatedAt").getValue(Long::class.java) ?: 0L
        json.decodeFromString<AppState>(raw) to updatedAt
    }

    suspend fun deleteBackup(uid: String) {
        database.getReference("backups").child(uid).removeValue().awaitCompletion()
    }

    suspend fun track(uid: String, event: AnalyticsEvent) {
        if (uid.isBlank()) return
        // Analytics é sempre não crítico: falha de rede/permissão jamais pode
        // interromper navegação, ferramentas, gravação ou a Home.
        runCatching {
            val ref = database.getReference("analytics").child("events").child(uid).push()
            ref.setValue(
                mapOf(
                    "name" to event.name.take(80),
                    "category" to event.category.take(40),
                    "tier" to event.tier.take(20),
                    "success" to event.success,
                    "durationMs" to event.durationMs,
                    "createdAt" to event.createdAtEpochMillis,
                    "day" to LocalDate.now().toString()
                )
            ).awaitCompletion()
        }
    }


    suspend fun loadRemotePromotions(uid: String): Result<RemotePromotionState> = runCatching {
        val snap = database.getReference("userClaims").child(uid).get().awaitValue()
        val claims = snap.children.mapNotNull { c ->
            val type = c.child("type").getValue(String::class.java)?.let { runCatching { CouponType.valueOf(it) }.getOrNull() } ?: return@mapNotNull null
            val redeemedAt = c.child("redeemedAt").getValue(Long::class.java) ?: return@mapNotNull null
            Triple(c, type, redeemedAt)
        }.sortedBy { it.third }
        var tier: String? = null
        var premiumUntil = 0L
        var adFreeUntil = 0L
        var multiplierUntil = 0L
        var discountPercent: Int? = null
        var discountTier: String? = null
        var discountUntil = 0L
        claims.forEach { (c, type, redeemedAt) ->
            val duration = (c.child("durationHours").getValue(Long::class.java) ?: 0L).coerceAtLeast(0L)
            when (type) {
                CouponType.PREMIUM -> {
                    premiumUntil = maxOf(redeemedAt, premiumUntil) + duration * 3_600_000L
                    tier = c.child("tierName").getValue(String::class.java)
                }
                CouponType.REMOVE_ADS -> adFreeUntil = maxOf(redeemedAt, adFreeUntil) + duration * 3_600_000L
                CouponType.AD_REWARD_2X -> multiplierUntil = maxOf(redeemedAt, multiplierUntil) + duration * 3_600_000L
                CouponType.DISCOUNT -> {
                    discountPercent = c.child("discountPercent").getValue(Long::class.java)?.toInt()
                    discountTier = c.child("tierName").getValue(String::class.java)
                    discountUntil = redeemedAt + maxOf(24L, duration) * 3_600_000L
                }
                CouponType.COINS -> Unit
            }
        }
        val now = System.currentTimeMillis()
        // Benefício pago/manual tem prioridade sobre cupom promocional enquanto estiver ativo.
        val entitlement = database.getReference("premiumEntitlements").child(uid).get().awaitValue()
        val entitlementUntil = entitlement.child("expiresAt").getValue(Long::class.java) ?: 0L
        val entitlementTier = entitlement.child("tier").getValue(String::class.java)?.uppercase(Locale.ROOT)
            ?.takeIf { it == "PRATA" || it == "OURO" || it == "DIAMANTE" }
        val paidActive = entitlement.child("active").getValue(Boolean::class.java) != false && entitlementUntil > now && entitlementTier != null
        if (paidActive) { tier = entitlementTier; premiumUntil = entitlementUntil }
        RemotePromotionState(
            tierName = tier.takeIf { premiumUntil > now },
            premiumUntil = premiumUntil.takeIf { it > now },
            adFreeUntil = adFreeUntil.takeIf { it > now },
            adMultiplier = if (multiplierUntil > now) 2 else 1,
            adMultiplierUntil = multiplierUntil.takeIf { it > now },
            discountPercent = discountPercent.takeIf { discountUntil > now },
            discountTierName = discountTier.takeIf { discountUntil > now },
            discountUntil = discountUntil.takeIf { it > now }
        )
    }

    suspend fun listCoupons(): Result<List<PromoCoupon>> = runCatching {
        val snap = database.getReference("coupons").get().awaitValue()
        val slots = database.getReference("couponSlots").get().awaitValue()
        val redemptions = database.getReference("couponRedemptions").get().awaitValue()
        snap.children.mapNotNull(::couponFromSnapshot)
            .map { coupon ->
                val used = if (coupon.unlimitedUses) {
                    redemptions.child(coupon.code).childrenCount.toInt()
                } else {
                    slots.child(coupon.code).children.count { child ->
                        val value = child.value
                        value == true || (value is String && value.isNotBlank())
                    }
                }
                coupon.copy(usedCount = used)
            }
            .sortedByDescending { it.createdAtEpochMillis }
    }

    suspend fun saveCoupon(coupon: PromoCoupon): Result<Unit> = runCatching {
        require(coupon.code.matches(Regex("[A-Z0-9_-]{4,32}"))) { "Use 4 a 32 caracteres: letras, números, _ ou -." }
        require(coupon.unlimitedUses || coupon.maxUses in 1..5000) { "Para cupons limitados, use entre 1 e 5.000 resgates." }

        val slotsRef = database.getReference("couponSlots").child(coupon.code)
        if (coupon.unlimitedUses) {
            // Slots são necessários apenas para cupons limitados. Claims antigos continuam
            // válidos no userClaims mesmo se o Owner transformar o cupom em ilimitado.
            runCatching { slotsRef.removeValue().awaitCompletion() }
        } else {
            val existing = slotsRef.get().awaitValue()
            val legacyUsed = if (!existing.exists()) {
                database.getReference("couponRedemptions").child(coupon.code).get().awaitValue().childrenCount.toInt()
            } else 0
            val existingClaimed = existing.children.count { child ->
                val value = child.value
                value == true || (value is String && value.isNotBlank())
            }
            val claimed = existingClaimed + legacyUsed
            require(coupon.maxUses >= claimed) {
                "O limite não pode ser menor que os $claimed resgates já consumidos."
            }
            val desired = linkedMapOf<String, Any>()
            for (index in 1..coupon.maxUses) {
                val key = slotKey(index)
                val old = existing.child(key).value
                desired[key] = when {
                    old == true -> true
                    old is String && old.isNotBlank() -> old
                    !existing.exists() && index <= legacyUsed -> true
                    else -> false
                }
            }
            slotsRef.setValue(desired).awaitCompletion()
        }
        database.getReference("coupons").child(coupon.code).setValue(couponToMap(coupon)).awaitCompletion()
    }

    suspend fun deleteCoupon(code: String): Result<Unit> = runCatching {
        database.getReference("coupons").child(code).removeValue().awaitCompletion()
        runCatching { database.getReference("couponSlots").child(code).removeValue().awaitCompletion() }
        runCatching { database.getReference("couponReservations").child(code).removeValue().awaitCompletion() }
    }

    suspend fun pauseAllCoupons(paused: Boolean): Result<Unit> = runCatching {
        database.getReference("promoControl").child("allPaused").setValue(paused).awaitCompletion()
    }

    suspend fun couponsPaused(): Boolean = database.getReference("promoControl").child("allPaused").get().awaitValue().getValue(Boolean::class.java) == true

    suspend fun redeemCoupon(uid: String, rawCode: String): Result<CouponRedemptionResult> = runCatching {
        val code = rawCode.trim().uppercase()
        require(code.isNotBlank()) { "Digite um código promocional." }
        require(!couponsPaused()) { "Os códigos promocionais estão temporariamente pausados." }
        val couponSnap = database.getReference("coupons").child(code).get().awaitValue()
        val coupon = couponFromSnapshot(couponSnap) ?: error("Código inválido, expirado ou indisponível.")
        val now = System.currentTimeMillis()
        require(coupon.active) { "Código inválido, expirado ou indisponível." }
        require(coupon.expiresAtEpochMillis == null || coupon.expiresAtEpochMillis > now) { "Código inválido, expirado ou indisponível." }
        val claimRef = database.getReference("userClaims").child(uid).child(code)
        require(!claimRef.get().awaitValue().exists()) { "Este código já foi resgatado nesta conta." }

        val reservedSlot = if (coupon.unlimitedUses) null else reserveLimitedCouponSlot(uid, coupon, now)
        val claim = mapOf(
            "redeemedAt" to now,
            "type" to coupon.type.name,
            "amount" to coupon.amount,
            "tierName" to coupon.tierName,
            "durationHours" to coupon.durationHours,
            "discountPercent" to coupon.discountPercent
        )
        try {
            claimRef.setValue(claim).awaitCompletion()
            if (coupon.unlimitedUses) {
                // Em cupons ilimitados, este marcador serve apenas para histórico/analytics.
                runCatching {
                    database.getReference("couponRedemptions").child(code).child(uid)
                        .setValue(mapOf("redeemedAt" to now)).awaitCompletion()
                }
            }
            if (reservedSlot != null) {
                // Depois que o benefício foi criado, o slot deixa de guardar o UID e
                // vira apenas um marcador booleano de uso consumido.
                finalizeLimitedCouponSlot(uid, code, reservedSlot)
            }
        } catch (claimError: Throwable) {
            if (reservedSlot != null) {
                runCatching { rollbackLimitedCouponSlot(uid, code, reservedSlot) }
            }
            throw claimError
        } finally {
            if (reservedSlot != null) {
                runCatching { database.getReference("couponReservations").child(code).child(uid).removeValue().awaitCompletion() }
            }
        }
        CouponRedemptionResult(coupon, now, redemptionMessage(coupon))
    }

    /**
     * Cupons limitados usam slots pré-criados pelo Owner. Cada slot começa como false,
     * é reservado temporariamente com o UID e depois finalizado como true. Assim o
     * limite global é exato sem numChildren(), Cloud Functions ou scraping de contagem.
     */
    private suspend fun reserveLimitedCouponSlot(uid: String, coupon: PromoCoupon, now: Long): String {
        require(coupon.maxUses in 1..5000) { "Código inválido, expirado ou indisponível." }
        val reservationRef = database.getReference("couponReservations").child(coupon.code).child(uid)

        // Se uma tentativa anterior caiu entre a reserva e o claim, tenta retomá-la.
        val existingReservation = runCatching { reservationRef.get().awaitValue() }.getOrNull()
        val existingSlot = existingReservation?.child("slot")?.getValue(String::class.java)
        if (!existingSlot.isNullOrBlank()) {
            val slotRef = database.getReference("couponSlots").child(coupon.code).child(existingSlot)
            val owned = runCatching { slotRef.get().awaitValue().getValue(String::class.java) == uid }.getOrDefault(false)
            if (owned) return existingSlot
            val retry = runCatching { slotRef.setValue(uid).awaitCompletion() }
            if (retry.isSuccess) return existingSlot
            runCatching { reservationRef.removeValue().awaitCompletion() }
        }

        val start = ((uid.hashCode() xor coupon.code.hashCode()) and Int.MAX_VALUE) % coupon.maxUses
        for (offset in 0 until coupon.maxUses) {
            val index = ((start + offset) % coupon.maxUses) + 1
            val slot = slotKey(index)
            val createReservation = runCatching {
                reservationRef.setValue(mapOf("slot" to slot, "createdAt" to now)).awaitCompletion()
            }
            if (createReservation.isFailure) continue

            val slotRef = database.getReference("couponSlots").child(coupon.code).child(slot)
            val reserve = runCatching { slotRef.setValue(uid).awaitCompletion() }
            if (reserve.isSuccess) return slot

            runCatching { reservationRef.removeValue().awaitCompletion() }
        }
        error("Código inválido, expirado ou indisponível.")
    }

    private suspend fun finalizeLimitedCouponSlot(uid: String, code: String, slot: String) {
        database.getReference("couponSlots").child(code).child(slot).setValue(true).awaitCompletion()
    }

    private suspend fun rollbackLimitedCouponSlot(uid: String, code: String, slot: String) {
        database.getReference("couponSlots").child(code).child(slot).setValue(false).awaitCompletion()
        database.getReference("couponReservations").child(code).child(uid).removeValue().awaitCompletion()
    }

    private fun slotKey(index: Int): String = index.toString().padStart(6, '0')

    suspend fun loadAdminAnalytics(): Result<AdminAnalyticsSnapshot> = runCatching {
        val warnings = mutableListOf<String>()

        suspend fun safe(path: String): DataSnapshot? {
            val result = runCatching { database.getReference(path).get().awaitValue() }
            if (result.isFailure) {
                val detail = result.exceptionOrNull()?.message?.take(120).orEmpty()
                warnings += if (detail.isBlank()) "$path indisponível" else "$path: $detail"
            }
            return result.getOrNull()
        }

        val accounts = safe("accounts")
        val presence = safe("presence")
        val events = safe("analytics/events")
        val coupons = safe("coupons")
        val couponSlots = safe("couponSlots")
        val redemptions = safe("couponRedemptions")

        val today = LocalDate.now()
        val sevenDaysAgo = today.minusDays(6)
        val thirtyDaysAgo = today.minusDays(29)
        var activeToday = 0
        var active7d = 0
        var active30d = 0
        var new7d = 0
        var new30d = 0

        accounts?.children?.forEach { account ->
            val lastDay = account.child("lastSeenDay").getValue(String::class.java)
                ?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
            val createdDay = account.child("createdDay").getValue(String::class.java)
                ?.let { runCatching { LocalDate.parse(it) }.getOrNull() }

            if (lastDay == today) activeToday++
            if (lastDay != null && !lastDay.isBefore(sevenDaysAgo)) active7d++
            if (lastDay != null && !lastDay.isBefore(thirtyDaysAgo)) active30d++
            if (createdDay != null && !createdDay.isBefore(sevenDaysAgo)) new7d++
            if (createdDay != null && !createdDay.isBefore(thirtyDaysAgo)) new30d++
        }

        val counts = mutableMapOf<String, Int>()
        val toolToday = mutableMapOf<String, Int>()
        val tool7d = mutableMapOf<String, Int>()
        val tool30d = mutableMapOf<String, Int>()
        val pageToday = mutableMapOf<String, Int>()
        val page7d = mutableMapOf<String, Int>()
        val page30d = mutableMapOf<String, Int>()
        val errors7d = mutableMapOf<String, Int>()
        val successes = mutableMapOf<String, Pair<Int, Int>>()
        val durations = mutableMapOf<String, MutableList<Long>>()
        val tiers = mutableMapOf<String, Int>()

        fun increment(target: MutableMap<String, Int>, key: String) {
            target[key] = (target[key] ?: 0) + 1
        }

        events?.children?.forEach { userEvents ->
            userEvents.children.forEach eventLoop@ { e ->
                val name = e.child("name").getValue(String::class.java) ?: return@eventLoop
                val category = e.child("category").getValue(String::class.java).orEmpty().lowercase()
                val day = e.child("day").getValue(String::class.java)
                    ?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
                    ?: e.child("createdAt").getValue(Long::class.java)?.let {
                        runCatching {
                            Instant.ofEpochMilli(it).atZone(java.time.ZoneId.systemDefault()).toLocalDate()
                        }.getOrNull()
                    }

                increment(counts, name)
                e.child("tier").getValue(String::class.java)?.let { tier -> increment(tiers, tier) }

                val success = e.child("success").getValue(Boolean::class.java)
                success?.let { ok ->
                    val old = successes[name] ?: (0 to 0)
                    successes[name] = (old.first + if (ok) 1 else 0) to (old.second + 1)
                    if (!ok && day != null && !day.isBefore(sevenDaysAgo)) increment(errors7d, name)
                }
                e.child("durationMs").getValue(Long::class.java)?.let {
                    durations.getOrPut(name) { mutableListOf() }.add(it)
                }

                if (day != null && !day.isAfter(today)) {
                    val todayTarget = if (category == "tool") toolToday else if (category == "page") pageToday else null
                    val sevenTarget = if (category == "tool") tool7d else if (category == "page") page7d else null
                    val thirtyTarget = if (category == "tool") tool30d else if (category == "page") page30d else null
                    if (day == today) todayTarget?.let { increment(it, name) }
                    if (!day.isBefore(sevenDaysAgo)) sevenTarget?.let { increment(it, name) }
                    if (!day.isBefore(thirtyDaysAgo)) thirtyTarget?.let { increment(it, name) }
                }
            }
        }

        fun sorted(source: Map<String, Int>): Map<String, Int> =
            source.toList().sortedByDescending { it.second }.toMap()

        val couponUses = buildMap {
            coupons?.children?.forEach { couponSnap ->
                val code = couponSnap.key.orEmpty()
                if (code.isBlank()) return@forEach
                val unlimited = couponSnap.child("unlimitedUses").getValue(Boolean::class.java) == true
                val count = if (unlimited) {
                    redemptions?.child(code)?.childrenCount?.toInt() ?: 0
                } else {
                    couponSlots?.child(code)?.children?.count { child ->
                        val value = child.value
                        value == true || (value is String && value.isNotBlank())
                    } ?: 0
                }
                put(code, count)
            }
        }

        AdminAnalyticsSnapshot(
            registeredUsers = accounts?.childrenCount?.toInt() ?: 0,
            onlineUsers = presence?.childrenCount?.toInt() ?: 0,
            activeToday = activeToday,
            active7d = active7d,
            active30d = active30d,
            newUsers7d = new7d,
            newUsers30d = new30d,
            eventCounts = sorted(counts),
            toolCountsToday = sorted(toolToday),
            toolCounts7d = sorted(tool7d),
            toolCounts30d = sorted(tool30d),
            pageCountsToday = sorted(pageToday),
            pageCounts7d = sorted(page7d),
            pageCounts30d = sorted(page30d),
            errorCounts7d = sorted(errors7d),
            successCounts = successes,
            averageDurationMs = durations.mapValues { (_, list) -> if (list.isEmpty()) 0L else list.average().toLong() },
            tierCounts = sorted(tiers),
            couponUses = sorted(couponUses),
            warnings = warnings.distinct()
        )
    }

    suspend fun setPublicCommunityConfig(enabled: Boolean, minimum: Int): Result<Unit> = runCatching {
        database.getReference("publicConfig").child("community").setValue(
            mapOf("enabled" to enabled, "minimum" to minimum.coerceAtLeast(1), "updatedAt" to System.currentTimeMillis())
        ).awaitCompletion()
    }

    suspend fun loadSonusMusicPublishedGenres(): Result<Set<String>> = runCatching {
        val snap = database.getReference("publicConfig").child("sonusMusic").child("publishedGenres").get().awaitValue()
        snap.children.mapNotNull { it.getValue(String::class.java)?.trim()?.takeIf { value -> value.isNotBlank() } }.toSet()
    }

    suspend fun setSonusMusicPublishedGenres(genres: Set<String>): Result<Unit> = runCatching {
        val clean = genres.map(String::trim).filter(String::isNotBlank).distinct().sortedBy { it.lowercase(Locale.getDefault()) }
        val base = database.getReference("publicConfig").child("sonusMusic")
        // Atualiza somente os filhos necessários para não apagar capas/letras/overrides do catálogo.
        base.child("publishedGenres").setValue(clean).awaitCompletion()
        base.child("updatedAt").setValue(System.currentTimeMillis()).awaitCompletion()
    }


    /**
     * Override administrativo por faixa. O caminho é OWNER-only nas regras do RTDB e
     * nunca faz parte do catálogo público. Usuários comuns continuam usando a resolução
     * automática do pCloud, enquanto um proxy seguro pode consumir estes overrides.
     */
    suspend fun loadSonusMusicStreamOverride(fileId: Long): Result<String?> = runCatching {
        if (fileId <= 0L) return@runCatching null
        database.getReference("sonusMusicAdmin").child("streamOverrides").child(fileId.toString())
            .child("url").get().awaitValue().getValue(String::class.java)?.trim()?.takeIf { it.isNotBlank() }
    }


    suspend fun loadSonusMusicStreamOverrides(): Result<Map<Long, String>> = runCatching {
        val snap = database.getReference("sonusMusicAdmin").child("streamOverrides").get().awaitValue()
        snap.children.mapNotNull { child ->
            val id = child.key?.toLongOrNull() ?: return@mapNotNull null
            val url = child.child("url").getValue(String::class.java)?.trim()?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
            id to url
        }.toMap()
    }

    suspend fun saveSonusMusicStreamOverride(fileId: Long, url: String): Result<Unit> = runCatching {
        require(fileId > 0L) { "Faixa inválida" }
        val clean = url.trim()
        require(clean.startsWith("https://", true)) { "Use um link HTTPS" }
        val uid = auth.currentUser?.uid.orEmpty()
        database.getReference("sonusMusicAdmin").child("streamOverrides").child(fileId.toString()).setValue(
            mapOf(
                "url" to clean,
                "updatedAt" to System.currentTimeMillis(),
                "updatedBy" to uid
            )
        ).awaitCompletion()
    }

    suspend fun removeSonusMusicStreamOverride(fileId: Long): Result<Unit> = runCatching {
        if (fileId > 0L) database.getReference("sonusMusicAdmin").child("streamOverrides")
            .child(fileId.toString()).removeValue().awaitCompletion()
    }

    /**
     * Metadados administrados pelo OWNER para faixas do SONUS Stream.
     * A cópia em sonusMusicAdmin mantém auditoria privada; a cópia sanitizada em publicConfig
     * permite que o player comum enxergue somente os dados finais (nunca URL/diagnóstico).
     */
    suspend fun loadSonusMusicTrackOverrides(): Result<Map<Long, Map<String, String>>> = runCatching {
        val snap = database.getReference("publicConfig").child("sonusMusic").child("trackOverrides").get().awaitValue()
        snap.children.mapNotNull { child ->
            val id = child.key?.toLongOrNull() ?: return@mapNotNull null
            val fields = linkedMapOf<String, String>()
            listOf("title","artist","album","genre","year","trackNumber","lyrics","lyricsFormat","coverBase64").forEach { key ->
                child.child(key).getValue(String::class.java)?.let { value -> fields[key] = value }
            }
            id to fields
        }.toMap()
    }

    suspend fun saveSonusMusicTrackOverride(fileId: Long, fields: Map<String, String>): Result<Unit> = runCatching {
        require(fileId > 0L) { "Faixa inválida" }
        val allowed = setOf("title","artist","album","genre","year","trackNumber","lyrics","lyricsFormat","coverBase64")
        val clean = fields.filterKeys { it in allowed }.mapValues { (_, value) -> value.trim() }.toMutableMap()
        clean["lyricsFormat"] = clean["lyricsFormat"]?.uppercase(Locale.getDefault())?.takeIf { it == "LRC" } ?: "TEXT"
        // RTDB não é repositório de mídia: limite preventivo para capa comprimida.
        require((clean["coverBase64"]?.length ?: 0) <= 950_000) { "Capa muito grande; use uma imagem menor." }
        val uid = auth.currentUser?.uid.orEmpty()
        val adminValue = clean.toMutableMap<String, Any?>().apply {
            put("updatedAt", System.currentTimeMillis())
            put("updatedBy", uid)
        }
        database.getReference("sonusMusicAdmin").child("trackOverrides").child(fileId.toString()).setValue(adminValue).awaitCompletion()
        database.getReference("publicConfig").child("sonusMusic").child("trackOverrides").child(fileId.toString()).setValue(clean).awaitCompletion()
    }

    suspend fun removeSonusMusicTrackOverride(fileId: Long): Result<Unit> = runCatching {
        if (fileId <= 0L) return@runCatching
        database.getReference("sonusMusicAdmin").child("trackOverrides").child(fileId.toString()).removeValue().awaitCompletion()
        database.getReference("publicConfig").child("sonusMusic").child("trackOverrides").child(fileId.toString()).removeValue().awaitCompletion()
    }

    suspend fun findAccountByPublicId(publicId: String): Result<SupportTeamMember?> = runCatching {
        val clean = publicId.trim().uppercase(Locale.getDefault())
        val snap = database.getReference("accounts").orderByChild("publicId").equalTo(clean).limitToFirst(1).get().awaitValue()
        val account = snap.children.firstOrNull() ?: return@runCatching null
        val uid = account.key ?: return@runCatching null
        val roleSnap = database.getReference("roles").child(uid).get().awaitValue()
        val permSnap = database.getReference("supportTeam").child(uid).child("permissions").get().awaitValue()
        SupportTeamMember(
            uid = uid,
            publicId = account.child("publicId").getValue(String::class.java) ?: clean,
            displayName = account.child("displayName").getValue(String::class.java),
            email = account.child("email").getValue(String::class.java),
            active = roleSnap.child("active").getValue(Boolean::class.java) == true && roleSnap.child("role").getValue(String::class.java) == "SUPPORT",
            permissions = permSnap.children.associate { it.key.orEmpty() to (it.getValue(Boolean::class.java) == true) }
        )
    }

    suspend fun setSupportMember(memberUid: String, active: Boolean, permissions: Map<String, Boolean>): Result<Unit> = runCatching {
        require(memberUid.isNotBlank()) { "Usuário inválido" }
        val actor = auth.currentUser?.uid ?: error("Sessão expirada")
        if (active) {
            database.getReference("roles").child(memberUid).setValue(mapOf("role" to "SUPPORT", "active" to true, "updatedAt" to System.currentTimeMillis(), "updatedBy" to actor)).awaitCompletion()
            database.getReference("supportTeam").child(memberUid).setValue(mapOf("active" to true, "permissions" to permissions, "updatedAt" to System.currentTimeMillis(), "updatedBy" to actor)).awaitCompletion()
        } else {
            database.getReference("roles").child(memberUid).setValue(mapOf("role" to "USER", "active" to true, "updatedAt" to System.currentTimeMillis(), "updatedBy" to actor)).awaitCompletion()
            database.getReference("supportTeam").child(memberUid).updateChildren(mapOf("active" to false, "updatedAt" to System.currentTimeMillis(), "updatedBy" to actor)).awaitCompletion()
        }
        database.getReference("adminAudit").push().setValue(mapOf("actorUid" to actor, "targetUid" to memberUid, "action" to if (active) "SUPPORT_GRANTED" else "SUPPORT_REVOKED", "createdAt" to System.currentTimeMillis())).awaitCompletion()
    }

    suspend fun updateSupportPermissions(memberUid: String, permissions: Map<String, Boolean>): Result<Unit> = runCatching {
        val actor = auth.currentUser?.uid ?: error("Sessão expirada")
        database.getReference("supportTeam").child(memberUid).child("permissions").setValue(permissions).awaitCompletion()
        database.getReference("adminAudit").push().setValue(mapOf("actorUid" to actor, "targetUid" to memberUid, "action" to "SUPPORT_PERMISSIONS_UPDATED", "createdAt" to System.currentTimeMillis())).awaitCompletion()
    }

    suspend fun deleteAllUserCloudData(uid: String): Result<Unit> = runCatching {
        // Evita updateChildren na raiz (que exigiria permissão global). Cada remoção
        // usa o caminho específico autorizado pelas regras do próprio usuário.
        val claims = database.getReference("userClaims").child(uid).get().awaitValue()
        val codes = claims.children.mapNotNull { it.key }

        // Reservas temporárias devem sair antes dos claims; com claim existente as
        // regras permitem limpar uma eventual reserva deixada por interrupção.
        for (code in codes) {
            runCatching { database.getReference("couponReservations").child(code).child(uid).removeValue().awaitCompletion() }
            runCatching { database.getReference("couponRedemptions").child(code).child(uid).removeValue().awaitCompletion() }
        }

        database.getReference("backups").child(uid).removeValue().awaitCompletion()
        database.getReference("accounts").child(uid).removeValue().awaitCompletion()
        database.getReference("analytics").child("events").child(uid).removeValue().awaitCompletion()
        database.getReference("userClaims").child(uid).removeValue().awaitCompletion()
        database.getReference("users").child(uid).removeValue().awaitCompletion()
        database.getReference("presence").child(uid).removeValue().awaitCompletion()
    }

    private fun couponFromSnapshot(s: DataSnapshot): PromoCoupon? {
        if (!s.exists()) return null
        val code = s.child("code").getValue(String::class.java) ?: s.key ?: return null
        val type = s.child("type").getValue(String::class.java)?.let { runCatching { CouponType.valueOf(it) }.getOrNull() } ?: return null
        return PromoCoupon(
            code = code,
            type = type,
            amount = s.child("amount").getValue(Long::class.java)?.toInt() ?: 0,
            tierName = s.child("tierName").getValue(String::class.java),
            durationHours = s.child("durationHours").getValue(Long::class.java)?.toInt() ?: 0,
            discountPercent = s.child("discountPercent").getValue(Long::class.java)?.toInt() ?: 0,
            active = s.child("active").getValue(Boolean::class.java) != false,
            unlimitedUses = s.child("unlimitedUses").getValue(Boolean::class.java) == true,
            maxUses = s.child("maxUses").getValue(Long::class.java)?.toInt() ?: 100,
            expiresAtEpochMillis = s.child("expiresAtEpochMillis").getValue(Long::class.java),
            description = s.child("description").getValue(String::class.java).orEmpty(),
            createdAtEpochMillis = s.child("createdAtEpochMillis").getValue(Long::class.java) ?: 0L
        )
    }

    private fun couponToMap(c: PromoCoupon): Map<String, Any?> = mapOf(
        "code" to c.code,
        "type" to c.type.name,
        "amount" to c.amount,
        "tierName" to c.tierName,
        "durationHours" to c.durationHours,
        "discountPercent" to c.discountPercent,
        "active" to c.active,
        "unlimitedUses" to c.unlimitedUses,
        "maxUses" to c.maxUses,
        "expiresAtEpochMillis" to c.expiresAtEpochMillis,
        "description" to c.description,
        "createdAtEpochMillis" to c.createdAtEpochMillis
    )

    private fun redemptionMessage(c: PromoCoupon): String = when (c.type) {
        CouponType.COINS -> "+${c.amount} Moedas SONUS adicionadas."
        CouponType.PREMIUM -> "${c.tierName ?: "Premium"} liberado por ${humanDuration(c.durationHours)}."
        CouponType.REMOVE_ADS -> "Anúncios removidos por ${humanDuration(c.durationHours)}."
        CouponType.DISCOUNT -> "${c.discountPercent}% de desconto reservado para ${c.tierName ?: "o plano selecionado"}."
        CouponType.AD_REWARD_2X -> "Bônus 2x legado resgatado; o novo modelo de anúncios mantém +1 Moeda SONUS por anúncio."
    }

    private fun humanDuration(hours: Int): String = when {
        hours % 24 == 0 -> "${hours / 24} dia(s)"
        else -> "$hours hora(s)"
    }
}

private suspend fun <T> Task<T>.awaitValue(): T = suspendCancellableCoroutine { c ->
    addOnCompleteListener { task ->
        if (!c.isActive) return@addOnCompleteListener
        if (task.isSuccessful) c.resume(task.result)
        else c.resumeWithException(task.exception ?: IllegalStateException("Falha no Firebase"))
    }
}

private suspend fun Task<Void>.awaitCompletion() = suspendCancellableCoroutine<Unit> { c ->
    addOnCompleteListener { task ->
        if (!c.isActive) return@addOnCompleteListener
        if (task.isSuccessful) c.resume(Unit)
        else c.resumeWithException(task.exception ?: IllegalStateException("Falha no Firebase"))
    }
}
