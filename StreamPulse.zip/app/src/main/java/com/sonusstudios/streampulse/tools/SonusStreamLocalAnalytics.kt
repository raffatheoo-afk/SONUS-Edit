package com.sonusstudios.streampulse.tools

import android.content.Context
import com.google.firebase.auth.FirebaseAuth
import org.json.JSONObject
import java.time.LocalDate
import java.time.YearMonth
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Analytics pessoal do SONUS Stream.
 *
 * Fica somente no aparelho e é usado pela aba "Você". Os dados são salvos por dia
 * para permitir que a interface mostre apenas o mês corrente sem apagar o histórico
 * imediatamente na virada do mês.
 */
class SonusStreamLocalAnalyticsStore(context: Context) {
    private val prefs = context.getSharedPreferences("sonus_stream_local_analytics_v108", Context.MODE_PRIVATE)
    private val lock = ReentrantLock()

    /** Shared process-local revision bus: PlayerService and Analytics use separate store instances,
     * but a valid play/finish must refresh an already-open Analytics screen immediately. */
    val revisionFlow: StateFlow<Long> get() = revisions.asStateFlow()

    data class TrackStat(
        val fileId: Long,
        val title: String,
        val artist: String,
        val genre: String,
        val validPlays: Long,
        val listeningMs: Long,
        val completions: Long,
        val replays: Long,
        val skips: Long,
        val lastPlayedAt: Long,
        val lastThresholdMs: Long
    )

    data class Snapshot(
        val month: YearMonth,
        val validPlays: Long,
        val listeningMs: Long,
        val completions: Long,
        val replays: Long,
        val skips: Long,
        val uniqueSongs: Int,
        val uniqueArtists: Int,
        val uniqueGenres: Int,
        val topTracks: List<TrackStat>,
        val topArtists: List<Pair<String, Long>>,
        val topGenres: List<Pair<String, Long>>,
        val dailyPlays: List<Pair<String, Long>>,
        val dailyListeningMs: List<Pair<String, Long>>
    )

    fun recordValidPlay(item: PulsePlayerQueueItem, fileId: Long, thresholdMs: Long) {
        recordValidPlayIfEligible(item, fileId, thresholdMs, 0L)
    }

    /**
     * Registra a reprodução válida no aparelho antes de qualquer sincronização remota.
     * O cooldown mantém o Analytics pessoal consistente com a regra pública do SONUS.
     */
    fun recordValidPlayIfEligible(
        item: PulsePlayerQueueItem,
        fileId: Long,
        thresholdMs: Long,
        cooldownMs: Long
    ): Boolean = lock.withLock {
        if (fileId <= 0L) return@withLock false
        val now = System.currentTimeMillis()
        val uid = FirebaseAuth.getInstance().currentUser?.uid.orEmpty().ifBlank { "anonymous" }
        val cooldownKey = "valid_last_${uid}_$fileId"
        val last = prefs.getLong(cooldownKey, 0L)
        if (cooldownMs > 0L && last > 0L && now - last < cooldownMs) return@withLock false
        val day = LocalDate.now()
        val root = loadDay(day)
        val key = fileId.toString()
        val o = root.optJSONObject(key) ?: seed(item, fileId)
        val oldPlays = o.optLong("plays").coerceAtLeast(0L)
        o.put("title", item.title)
        o.put("artist", item.artist)
        o.put("genre", item.genre)
        o.put("plays", oldPlays + 1L)
        if (oldPlays > 0L) o.put("replays", o.optLong("replays").coerceAtLeast(0L) + 1L)
        o.put("last", now)
        o.put("thresholdMs", thresholdMs.coerceAtLeast(0L))
        root.put(key, o)
        prefs.edit().putLong(cooldownKey, now).apply()
        saveDay(day, root)
        true
    }

    /** Persiste tempo ouvido em pequenos deltas durante a sessão. Assim uma queda, troca de faixa
     * ou encerramento do processo não transforma uma reprodução já válida em “1 play / 0s”. */
    fun recordListeningDelta(item: PulsePlayerQueueItem, fileId: Long, deltaMs: Long) = lock.withLock {
        if (fileId <= 0L || deltaMs <= 0L) return@withLock
        val day = LocalDate.now()
        val root = loadDay(day)
        val key = fileId.toString()
        val o = root.optJSONObject(key) ?: seed(item, fileId)
        o.put("title", item.title)
        o.put("artist", item.artist)
        o.put("genre", item.genre)
        o.put("ms", o.optLong("ms").coerceAtLeast(0L) + deltaMs.coerceIn(0L, 12L * 60L * 60_000L))
        o.put("last", System.currentTimeMillis())
        root.put(key, o)
        saveDay(day, root)
    }

    /** listenedMs aqui representa somente o delta ainda não checkpointado da sessão. */
    fun recordFinish(item: PulsePlayerQueueItem, fileId: Long, listenedMs: Long, completed: Boolean, skipped: Boolean) = lock.withLock {
        if (fileId <= 0L) return@withLock
        val day = LocalDate.now()
        val root = loadDay(day)
        val key = fileId.toString()
        val o = root.optJSONObject(key) ?: seed(item, fileId)
        o.put("title", item.title)
        o.put("artist", item.artist)
        o.put("genre", item.genre)
        o.put("ms", o.optLong("ms").coerceAtLeast(0L) + listenedMs.coerceAtLeast(0L))
        if (completed) o.put("completed", o.optLong("completed").coerceAtLeast(0L) + 1L)
        if (skipped && !completed) o.put("skips", o.optLong("skips").coerceAtLeast(0L) + 1L)
        o.put("last", System.currentTimeMillis())
        root.put(key, o)
        saveDay(day, root)
    }

    fun snapshotCurrentMonth(limit: Int = 12): Snapshot = snapshot(YearMonth.now(), limit)

    /**
     * Total local persistente usado como fallback quando o Firebase pessoal estiver
     * indisponível. Mantém a mesma fonte local-first da aba "Você" e nunca alimenta
     * contador público de artista.
     */
    fun snapshotAllTime(limit: Int = 12): Snapshot = lock.withLock {
        val dates = prefs.all.keys.asSequence()
            .filter { it.startsWith("day_") }
            .mapNotNull { runCatching { LocalDate.parse(it.removePrefix("day_")) }.getOrNull() }
            .distinct()
            .sorted()
            .toList()
        val merged = linkedMapOf<Long, TrackStat>()
        val dailyPlays = mutableListOf<Pair<String, Long>>()
        val dailyListening = mutableListOf<Pair<String, Long>>()
        dates.forEach { date ->
            val root = loadDay(date)
            var dp = 0L
            var dm = 0L
            root.keys().forEach { key ->
                val o = root.optJSONObject(key) ?: return@forEach
                val stat = toStat(o) ?: return@forEach
                dp += stat.validPlays
                dm += stat.listeningMs
                val old = merged[stat.fileId]
                merged[stat.fileId] = if (old == null) stat else old.copy(
                    title = stat.title.ifBlank { old.title },
                    artist = stat.artist.ifBlank { old.artist },
                    genre = stat.genre.ifBlank { old.genre },
                    validPlays = old.validPlays + stat.validPlays,
                    listeningMs = old.listeningMs + stat.listeningMs,
                    completions = old.completions + stat.completions,
                    replays = old.replays + stat.replays,
                    skips = old.skips + stat.skips,
                    lastPlayedAt = maxOf(old.lastPlayedAt, stat.lastPlayedAt),
                    lastThresholdMs = if (stat.lastPlayedAt >= old.lastPlayedAt) stat.lastThresholdMs else old.lastThresholdMs
                )
            }
            dailyPlays += date.toString() to dp
            dailyListening += date.toString() to dm
        }
        val tracks = merged.values.toList()
        fun grouped(selector: (TrackStat) -> String): List<Pair<String, Long>> = tracks
            .groupBy { selector(it).trim().ifBlank { "Outros" } }
            .mapValues { (_, list) -> list.sumOf { it.listeningMs } }
            .toList().sortedByDescending { it.second }.take(limit)

        Snapshot(
            month = YearMonth.now(),
            validPlays = tracks.sumOf { it.validPlays },
            listeningMs = tracks.sumOf { it.listeningMs },
            completions = tracks.sumOf { it.completions },
            replays = tracks.sumOf { it.replays },
            skips = tracks.sumOf { it.skips },
            uniqueSongs = tracks.count { it.validPlays > 0L },
            uniqueArtists = tracks.filter { it.validPlays > 0L }.map { it.artist.trim().lowercase() }.filter { it.isNotBlank() }.distinct().size,
            uniqueGenres = tracks.filter { it.validPlays > 0L }.map { it.genre.trim().lowercase() }.filter { it.isNotBlank() }.distinct().size,
            topTracks = tracks.sortedWith(compareByDescending<TrackStat> { it.validPlays }.thenByDescending { it.listeningMs }).take(limit),
            topArtists = grouped { it.artist },
            topGenres = grouped { it.genre },
            dailyPlays = dailyPlays,
            dailyListeningMs = dailyListening
        )
    }

    fun snapshot(month: YearMonth, limit: Int = 12): Snapshot = lock.withLock {
        val merged = linkedMapOf<Long, TrackStat>()
        val dailyPlays = mutableListOf<Pair<String, Long>>()
        val dailyListening = mutableListOf<Pair<String, Long>>()
        val today = LocalDate.now()
        val last = if (month == YearMonth.from(today)) today.dayOfMonth else month.lengthOfMonth()
        for (d in 1..last) {
            val date = month.atDay(d)
            val root = loadDay(date)
            var dp = 0L
            var dm = 0L
            root.keys().forEach { key ->
                val o = root.optJSONObject(key) ?: return@forEach
                val stat = toStat(o) ?: return@forEach
                dp += stat.validPlays
                dm += stat.listeningMs
                val old = merged[stat.fileId]
                merged[stat.fileId] = if (old == null) stat else old.copy(
                    title = stat.title.ifBlank { old.title },
                    artist = stat.artist.ifBlank { old.artist },
                    genre = stat.genre.ifBlank { old.genre },
                    validPlays = old.validPlays + stat.validPlays,
                    listeningMs = old.listeningMs + stat.listeningMs,
                    completions = old.completions + stat.completions,
                    replays = old.replays + stat.replays,
                    skips = old.skips + stat.skips,
                    lastPlayedAt = maxOf(old.lastPlayedAt, stat.lastPlayedAt),
                    lastThresholdMs = if (stat.lastPlayedAt >= old.lastPlayedAt) stat.lastThresholdMs else old.lastThresholdMs
                )
            }
            dailyPlays += date.toString() to dp
            dailyListening += date.toString() to dm
        }
        val tracks = merged.values.toList()
        fun grouped(selector: (TrackStat) -> String): List<Pair<String, Long>> = tracks
            .groupBy { selector(it).trim().ifBlank { "Outros" } }
            .mapValues { (_, list) -> list.sumOf { it.listeningMs } }
            .toList().sortedByDescending { it.second }.take(limit)

        Snapshot(
            month = month,
            validPlays = tracks.sumOf { it.validPlays },
            listeningMs = tracks.sumOf { it.listeningMs },
            completions = tracks.sumOf { it.completions },
            replays = tracks.sumOf { it.replays },
            skips = tracks.sumOf { it.skips },
            uniqueSongs = tracks.count { it.validPlays > 0L },
            uniqueArtists = tracks.filter { it.validPlays > 0L }.map { it.artist.trim().lowercase() }.filter { it.isNotBlank() }.distinct().size,
            uniqueGenres = tracks.filter { it.validPlays > 0L }.map { it.genre.trim().lowercase() }.filter { it.isNotBlank() }.distinct().size,
            topTracks = tracks.sortedWith(compareByDescending<TrackStat> { it.validPlays }.thenByDescending { it.listeningMs }).take(limit),
            topArtists = grouped { it.artist },
            topGenres = grouped { it.genre },
            dailyPlays = dailyPlays,
            dailyListeningMs = dailyListening
        )
    }

    fun clearCurrentMonth() = lock.withLock {
        val prefix = "day_${YearMonth.now()}-"
        val edit = prefs.edit()
        prefs.all.keys.filter { it.startsWith(prefix) }.forEach(edit::remove)
        edit.apply()
        revisions.value = revisions.value + 1L
    }

    private fun seed(item: PulsePlayerQueueItem, fileId: Long) = JSONObject().apply {
        put("fileId", fileId)
        put("title", item.title)
        put("artist", item.artist)
        put("genre", item.genre)
        put("plays", 0L)
        put("ms", 0L)
        put("completed", 0L)
        put("replays", 0L)
        put("skips", 0L)
        put("last", 0L)
        put("thresholdMs", 0L)
    }

    private fun toStat(o: JSONObject): TrackStat? = runCatching {
        TrackStat(
            fileId = o.getLong("fileId"),
            title = o.optString("title"),
            artist = o.optString("artist"),
            genre = o.optString("genre"),
            validPlays = o.optLong("plays").coerceAtLeast(0L),
            listeningMs = o.optLong("ms").coerceAtLeast(0L),
            completions = o.optLong("completed").coerceAtLeast(0L),
            replays = o.optLong("replays").coerceAtLeast(0L),
            skips = o.optLong("skips").coerceAtLeast(0L),
            lastPlayedAt = o.optLong("last").coerceAtLeast(0L),
            lastThresholdMs = o.optLong("thresholdMs").coerceAtLeast(0L)
        )
    }.getOrNull()

    private fun dayKey(day: LocalDate) = "day_$day"
    private fun loadDay(day: LocalDate): JSONObject = runCatching { JSONObject(prefs.getString(dayKey(day), "{}") ?: "{}") }.getOrElse { JSONObject() }
    private fun saveDay(day: LocalDate, root: JSONObject) {
        prefs.edit().putString(dayKey(day), root.toString()).apply()
        revisions.value = revisions.value + 1L
    }

    companion object {
        private val revisions = MutableStateFlow(0L)
    }
}
