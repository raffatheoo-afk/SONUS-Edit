package com.sonusstudios.streampulse.navigation

import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Navegação personalizada do SONUS code97.
 * PLAYER e SETTINGS são fixos. Os demais atalhos são opcionais e reordenáveis.
 */
enum class SonusMainTab(val label: String, val icon: ImageVector) {
    HIGHLIGHTS("Destaques", Icons.Default.AutoAwesome),
    VIDEO("Vídeo", Icons.Default.VideoLibrary),
    STREAM("SONUS Stream", Icons.Default.GraphicEq),
    DISTRIBUTION("Distribuição", Icons.Default.Payments)
}

data class SonusMainTabConfig(
    val enabled: Set<SonusMainTab>,
    val order: List<SonusMainTab>,
    val barStyle: String = "BLACK"
) {
    companion object {
        val DEFAULT = SonusMainTabConfig(
            enabled = setOf(SonusMainTab.HIGHLIGHTS, SonusMainTab.VIDEO),
            order = listOf(
                SonusMainTab.HIGHLIGHTS,
                SonusMainTab.VIDEO,
                SonusMainTab.STREAM,
                SonusMainTab.DISTRIBUTION
            ),
            barStyle = "BLACK"
        )
    }
}

class SonusMainTabPreferences(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("sonus_main_tabs_v1", Context.MODE_PRIVATE)

    fun load(): SonusMainTabConfig {
        val orderNames = prefs.getString("order", null)?.split(',')?.filter { it.isNotBlank() }
        val enabledNames = prefs.getStringSet("enabled", null)
        val default = SonusMainTabConfig.DEFAULT
        val parsedOrder = orderNames?.mapNotNull { runCatching { SonusMainTab.valueOf(it) }.getOrNull() }.orEmpty()
        val order = (parsedOrder + SonusMainTab.entries).distinct()
        val enabled = enabledNames?.mapNotNull { runCatching { SonusMainTab.valueOf(it) }.getOrNull() }?.toSet() ?: default.enabled
        val barStyle = prefs.getString("bar_style", "BLACK") ?: "BLACK"
        return SonusMainTabConfig(enabled, order, barStyle)
    }

    fun save(config: SonusMainTabConfig) {
        prefs.edit()
            .putString("order", config.order.joinToString(",") { it.name })
            .putStringSet("enabled", config.enabled.map { it.name }.toSet())
            .putString("bar_style", config.barStyle)
            .apply()
    }

    fun reset() {
        prefs.edit().clear().apply()
    }
}

@Composable
fun SonusMainTabsOrganizerScreen(
    initial: SonusMainTabConfig,
    onSave: (SonusMainTabConfig) -> Unit,
    onBack: () -> Unit
) {
    var config by remember(initial) { mutableStateOf(initial) }
    var message by remember { mutableStateOf<String?>(null) }
    val maxOptional = SonusMainTab.entries.size

    fun toggle(tab: SonusMainTab, enabled: Boolean) {
        val next = config.enabled.toMutableSet()
        if (enabled) {
            if (next.size >= maxOptional) {
                message = "A barra principal já está completa. Remova uma aba para adicionar outra."
                return
            }
            next += tab
        } else next -= tab
        config = config.copy(enabled = next)
        onSave(config)
    }

    fun move(tab: SonusMainTab, direction: Int) {
        val list = config.order.toMutableList()
        val from = list.indexOf(tab)
        val to = (from + direction).coerceIn(0, list.lastIndex)
        if (from < 0 || from == to) return
        list.removeAt(from)
        list.add(to, tab)
        config = config.copy(order = list)
        onSave(config)
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(top = 14.dp, bottom = 28.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Voltar") }
                Column(Modifier.weight(1f)) {
                    Text("Organizar abas principais", fontSize = 23.sp, fontWeight = FontWeight.Black)
                    Text("SONUS Player fica sempre em primeiro e Ajustes sempre acessível.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item {
            Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = .35f)) {
                Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Headphones, null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("SONUS Player", fontWeight = FontWeight.ExtraBold)
                        Text("Fixo • principal", style = MaterialTheme.typography.labelSmall)
                    }
                    Text("1º", fontWeight = FontWeight.Black)
                }
            }
        }
        items(config.order, key = { it.name }) { tab ->
            var drag by remember(tab) { mutableFloatStateOf(0f) }
            Surface(
                modifier = Modifier.fillMaxWidth().pointerInput(tab, config.order) {
                    detectVerticalDragGestures(
                        onDragStart = { drag = 0f },
                        onVerticalDrag = { change, amount ->
                            change.consume(); drag += amount
                            if (drag > 46f) { move(tab, +1); drag = 0f }
                            else if (drag < -46f) { move(tab, -1); drag = 0f }
                        },
                        onDragEnd = { drag = 0f },
                        onDragCancel = { drag = 0f }
                    )
                },
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .38f),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .12f))
            ) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.DragHandle, "Arraste", tint = MaterialTheme.colorScheme.onSurface.copy(alpha = .45f))
                    Spacer(Modifier.width(8.dp))
                    Icon(tab.icon, null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(10.dp))
                    Text(tab.label, Modifier.weight(1f), fontWeight = FontWeight.Bold)
                    Switch(checked = tab in config.enabled, onCheckedChange = { toggle(tab, it) })
                }
            }
        }
        item {
            Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .22f)) {
                Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Settings, null)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Ajustes", fontWeight = FontWeight.ExtraBold)
                        Text("Fixo • último atalho", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
        item {
            Text("Cor da barra inferior", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
            Text("Escolha uma paleta SONUS. Preto é o padrão.", style = MaterialTheme.typography.labelSmall)
            Spacer(Modifier.height(8.dp))
            val styles = listOf("BLACK" to Color.Black, "SONUS" to Color(0xFF071A35), "NIGHT" to Color(0xFF061224), "GRAPHITE" to Color(0xFF202126), "PURPLE" to Color(0xFF17102E), "DYNAMIC" to MaterialTheme.colorScheme.surface)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(styles.size) { index ->
                    val (key, color) = styles[index]
                    FilterChip(selected = config.barStyle == key, onClick = { config = config.copy(barStyle = key); onSave(config) }, label = { Text(if(key=="DYNAMIC") "Dinâmica" else key.lowercase().replaceFirstChar{it.uppercase()}, fontSize=9.sp) }, leadingIcon = { Surface(Modifier.size(14.dp), shape=RoundedCornerShape(50), color=color){} })
                }
            }
            Spacer(Modifier.height(10.dp))
            Surface(shape=RoundedCornerShape(16.dp), color = when(config.barStyle){"BLACK"->Color.Black;"SONUS"->Color(0xFF071A35);"NIGHT"->Color(0xFF061224);"GRAPHITE"->Color(0xFF202126);"PURPLE"->Color(0xFF17102E);else->MaterialTheme.colorScheme.surface}) {
                Row(Modifier.fillMaxWidth().padding(horizontal=14.dp,vertical=9.dp), horizontalArrangement=Arrangement.SpaceAround, verticalAlignment=Alignment.CenterVertically) {
                    Icon(Icons.Default.Headphones,null,tint=Color(0xFF7DE7FF)); config.order.filter{it in config.enabled}.take(4).forEachIndexed{index,tab->val accents=listOf(Color(0xFFFFD76A),Color(0xFFFF7B8A),Color(0xFFB48CFF),Color(0xFF67C8FF));Icon(tab.icon,null,tint=accents[index%accents.size].copy(alpha=.82f))}; Icon(Icons.Default.Settings,null,tint=Color.White.copy(alpha=.82f))
                }
            }
        }
        message?.let { msg -> item { Text(msg, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) } }
        item {
            OutlinedButton(
                onClick = {
                    config = SonusMainTabConfig.DEFAULT
                    onSave(config)
                    message = "Organização padrão restaurada."
                },
                modifier = Modifier.fillMaxWidth()
            ) { Icon(Icons.Default.Restore, null); Spacer(Modifier.width(7.dp)); Text("Restaurar organização padrão") }
        }
    }
}
