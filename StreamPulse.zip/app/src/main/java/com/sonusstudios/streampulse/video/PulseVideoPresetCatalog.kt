package com.sonusstudios.streampulse.video

import android.content.Context
import org.json.JSONObject

/** Runtime contract generated from presets_pulsestudio.json supplied for the editor audit. */
object PulseVideoPresetCatalog {
    data class FilterPreset(
        val name: String,
        val exposureEv: Float = 0f,
        val contrast: Float = 0f,
        val saturationPercent: Float = 100f,
        val temperature: Float = 0f,
        val tint: Float = 0f,
        val sharpen: Float = 0f,
        val amount: Float = 100f
    )

    data class AspectPreset(val id: String, val name: String, val width: Int, val height: Int)

    @Volatile private var root: JSONObject? = null

    private fun json(context: Context): JSONObject {
        root?.let { return it }
        val parsed = context.assets.open("presets_pulsestudio.json").bufferedReader().use { JSONObject(it.readText()) }
        root = parsed
        return parsed
    }

    fun filter(context: Context, visibleName: String): FilterPreset? {
        val arr = json(context).optJSONArray("filters") ?: return null
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            if (o.optString("name").equals(visibleName, ignoreCase = true)) {
                val p = o.optJSONObject("params") ?: JSONObject()
                return FilterPreset(
                    name = o.optString("name"),
                    exposureEv = p.optDouble("exposureEv", 0.0).toFloat(),
                    contrast = p.optDouble("contrast", 0.0).toFloat(),
                    saturationPercent = p.optDouble("saturation", 100.0).toFloat(),
                    temperature = p.optDouble("temperature", 0.0).toFloat(),
                    tint = p.optDouble("tint", 0.0).toFloat(),
                    sharpen = p.optDouble("sharpen", 0.0).toFloat(),
                    amount = o.optDouble("filterAmount", 100.0).toFloat()
                )
            }
        }
        return null
    }

    fun aspectByName(context: Context, visibleName: String): AspectPreset? {
        val arr = json(context).optJSONArray("aspectRatios") ?: return null
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            if (o.optString("name").equals(visibleName, ignoreCase = true)) {
                return AspectPreset(o.optString("id"), o.optString("name"), o.optInt("width"), o.optInt("height"))
            }
        }
        return null
    }
}
