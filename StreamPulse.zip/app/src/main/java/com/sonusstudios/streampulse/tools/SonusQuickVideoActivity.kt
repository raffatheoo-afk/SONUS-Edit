package com.sonusstudios.streampulse.tools

import android.app.PictureInPictureParams
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Rational
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PictureInPictureAlt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.documentfile.provider.DocumentFile
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay
import com.sonusstudios.streampulse.MainActivity

@OptIn(androidx.media3.common.util.UnstableApi::class)
class SonusQuickVideoActivity : ComponentActivity() {
    private var player: ExoPlayer? = null
    private var openedUri: String? = null
    private lateinit var settings: SonusVideoSettingsStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = SonusVideoSettingsStore(applicationContext)
        val uri = intent?.data
        if (uri == null) {
            finish()
            return
        }
        openedUri = uri.toString()

        window.decorView.systemUiVisibility =
            android.view.View.SYSTEM_UI_FLAG_FULLSCREEN or
            android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY

        if (!settings.useQuickExternalVideo) {
            startActivity(Intent(this, MainActivity::class.java).apply {
                action = Intent.ACTION_VIEW
                data = uri
                type = intent?.type ?: "video/*"
                putExtra("sonus_external_video_uri", uri.toString())
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            })
            finish()
            return
        }

        val title = DocumentFile.fromSingleUri(this, uri)?.name?.substringBeforeLast('.')?.ifBlank { "Vídeo" } ?: "Vídeo"
        val start = if (settings.rememberExternalPosition) settings.externalPosition(uri.toString()) else 0L
        val exo = ExoPlayer.Builder(this).build().apply {
            setMediaItem(MediaItem.fromUri(uri), start.coerceAtLeast(0L))
            prepare()
            playWhenReady = true
        }
        player = exo

        setContent {
            val eq = remember { SonusVideoEqualizerController() }
            DisposableEffect(Unit) { onDispose { eq.release() } }
            LaunchedEffect(exo, title) {
                repeat(10) {
                    delay(250)
                    if (exo.audioSessionId > 0) {
                        val category = settings.categoryOverride(uri.toString())
                            ?: if (settings.autoEq) classifySonusVideoTitle(title) else settings.manualCategory
                        eq.apply(exo.audioSessionId, settings.eqEnabled, videoEqCurve(category))
                        return@LaunchedEffect
                    }
                }
            }
            Box(Modifier.fillMaxSize().background(Color.Black)) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx -> PlayerView(ctx).apply { this.player = exo; useController = true } },
                    update = { it.player = exo }
                )
                Surface(
                    modifier = Modifier.align(Alignment.TopCenter).padding(10.dp),
                    color = Color.Black.copy(alpha = .62f),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(Modifier.padding(horizontal = 7.dp, vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("SONUS VIDEO • Player Rápido", color = Color.White, style = MaterialTheme.typography.labelMedium, modifier = Modifier.weight(1f).padding(start=8.dp))
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            IconButton(onClick = {
                                enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build())
                            }) { Icon(Icons.Default.PictureInPictureAlt, "Picture in Picture", tint = Color.White) }
                        }
                        IconButton(onClick = { finish() }) { Icon(Icons.Default.Close, "Fechar", tint = Color.White) }
                    }
                }
            }
        }
    }

    override fun onStop() {
        val uri = openedUri
        val exo = player
        if (uri != null && exo != null && settings.rememberExternalPosition) {
            settings.saveExternalPosition(uri, exo.currentPosition)
        }
        super.onStop()
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}
