package com.sonusstudios.streampulse.core

import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToLong

/**
 * Fonte única dos números de streams do SONUS.
 *
 * code119 separa definitivamente os dois modelos de entrada:
 * - TOTAL: StreamSnapshot é um total acumulado do ciclo e é a única fonte contábil.
 * - DIA: DailyStreamRecord é um incremento diário e é a única fonte contábil.
 *
 * AUTO permanece apenas como fallback legado para chamadas antigas que ainda não conhecem o modo.
 * Registros de cycleId diferente nunca entram num ciclo novo.
 */
object StreamMetricsEngine {
    data class CycleMetrics(
        val currentStreams: Long,
        val dailyEntries: List<DailyStreamEntry>,
        val cycleDailyAverage: Double,
        val recentDailyAverage: Double,
        val projectedDailyRate: Double,
        val projectedStreams: Long,
        val conservativeStreams: Long,
        val optimisticStreams: Long,
        val confidence: String,
        val sampleCount: Int,
        val coveredDays: Int,
        val variability: Double,
        val latestDataDate: LocalDate?
    )

    fun cycleMetrics(
        snapshots: List<StreamSnapshot>,
        dailyRecords: List<DailyStreamRecord>,
        cycleStart: LocalDate,
        cycleEnd: LocalDate,
        referenceDate: LocalDate = LocalDate.now(),
        entryMode: String = "AUTO",
        cycleId: String? = null
    ): CycleMetrics {
        fun cycleMatches(recordCycleId: String?): Boolean = cycleId == null || recordCycleId == cycleId

        val scopedSnapshots = snapshots
            .filter { cycleMatches(it.cycleId) && inRange(it.dateIso, cycleStart, cycleEnd) }
            .groupBy { it.dateIso }
            .mapNotNull { (_, sameDay) ->
                sameDay.maxWithOrNull(compareBy<StreamSnapshot> { it.recordedAtEpochMillis }.thenBy { it.id })
            }
            .sortedBy { it.dateIso }

        val scopedDaily = dailyRecords
            .filter { cycleMatches(it.cycleId) && inRange(it.dateIso, cycleStart, cycleEnd) }
            .groupBy { it.dateIso }
            .mapNotNull { (_, sameDay) ->
                sameDay.maxWithOrNull(compareBy<DailyStreamRecord> { it.recordedAtEpochMillis }.thenBy { it.id })
            }
            .sortedBy { it.dateIso }

        val normalizedMode = entryMode.trim().uppercase()
        val accounting = linkedMapOf<LocalDate, Long>()
        var currentStreams = 0L
        var latestDataDate: LocalDate? = null
        val observedDates = mutableListOf<LocalDate>()

        fun allocateEvenly(start: LocalDate, end: LocalDate, rawBudget: Long) {
            if (end.isBefore(start)) return
            val dates = generateSequence(start) { current ->
                current.plusDays(1).takeIf { !it.isAfter(end) }
            }.toList()
            if (dates.isEmpty()) return
            val budget = rawBudget.coerceAtLeast(0L)
            val q = budget / dates.size
            var r = budget % dates.size
            dates.forEach { date ->
                val amount = q + if (r > 0L) 1L else 0L
                if (r > 0L) r--
                accounting[date] = (accounting[date] ?: 0L) + amount
            }
        }

        when (normalizedMode) {
            "TOTAL" -> {
                // Snapshot acumulado é autoridade absoluta. DailyStreamRecord fica fora da contabilidade.
                var previousTotal = 0L
                var intervalStart = cycleStart
                scopedSnapshots.forEach { snapshot ->
                    val date = LocalDate.parse(snapshot.dateIso)
                    val total = snapshot.cumulativeStreams.coerceAtLeast(0L)
                    // Regressão de painel não cria stream negativo: mantemos o último total conhecido.
                    val normalizedTotal = max(previousTotal, total)
                    allocateEvenly(intervalStart, date, normalizedTotal - previousTotal)
                    previousTotal = normalizedTotal
                    intervalStart = date.plusDays(1)
                    observedDates += date
                }
                // A leitura mais recente é a autoridade oficial do painel acumulado.
                // Novas regressões são bloqueadas/avisadas na edição; não ressuscitamos um valor antigo maior.
                currentStreams = scopedSnapshots.lastOrNull()?.cumulativeStreams?.coerceAtLeast(0L) ?: 0L
                if (scopedSnapshots.isNotEmpty()) {
                    latestDataDate = LocalDate.parse(scopedSnapshots.last().dateIso)
                }
            }

            "DIA" -> {
                // Cada registro é incremento real daquele dia. Snapshots ficam fora da contabilidade.
                scopedDaily.forEach { record ->
                    val date = LocalDate.parse(record.dateIso)
                    accounting[date] = record.streams.coerceAtLeast(0L)
                    observedDates += date
                }
                currentStreams = scopedDaily.sumOf { it.streams.coerceAtLeast(0L) }
                latestDataDate = scopedDaily.lastOrNull()?.let { LocalDate.parse(it.dateIso) }
            }

            else -> {
                // Compatibilidade de chamadas legadas: snapshot é autoridade até sua última data;
                // somente dias explicitamente posteriores continuam o total.
                val latestSnapshot = scopedSnapshots.lastOrNull()
                val latestSnapshotDate = latestSnapshot?.let { LocalDate.parse(it.dateIso) }
                val dailyAfter = scopedDaily.filter {
                    val d = LocalDate.parse(it.dateIso)
                    latestSnapshotDate == null || d.isAfter(latestSnapshotDate)
                }
                currentStreams = if (latestSnapshot != null) {
                    latestSnapshot.cumulativeStreams.coerceAtLeast(0L) + dailyAfter.sumOf { it.streams.coerceAtLeast(0L) }
                } else scopedDaily.sumOf { it.streams.coerceAtLeast(0L) }

                var previousTotal = 0L
                var intervalStart = cycleStart
                scopedSnapshots.forEach { snapshot ->
                    val date = LocalDate.parse(snapshot.dateIso)
                    val total = max(previousTotal, snapshot.cumulativeStreams.coerceAtLeast(0L))
                    allocateEvenly(intervalStart, date, total - previousTotal)
                    previousTotal = total
                    intervalStart = date.plusDays(1)
                    observedDates += date
                }
                dailyAfter.forEach { record ->
                    val date = LocalDate.parse(record.dateIso)
                    accounting[date] = record.streams.coerceAtLeast(0L)
                    observedDates += date
                }
                if (scopedSnapshots.isEmpty()) scopedDaily.forEach { record ->
                    val date = LocalDate.parse(record.dateIso)
                    accounting[date] = record.streams.coerceAtLeast(0L)
                    observedDates += date
                }
                latestDataDate = listOfNotNull(
                    latestSnapshotDate,
                    scopedDaily.lastOrNull()?.let { LocalDate.parse(it.dateIso) }
                ).maxOrNull()
            }
        }

        val dailyEntries = accounting.entries.sortedBy { it.key }.map { (date, streams) ->
            DailyStreamEntry(date.toString(), streams, HealthEngine.pointsForStreams(streams, 3))
        }
        val allRates = accounting.entries.sortedBy { it.key }.map { it.value.toDouble().coerceAtLeast(0.0) }
        val cycleAverage = allRates.takeIf { it.isNotEmpty() }?.average() ?: 0.0
        val recent = allRates.takeLast(7)
        val recentAverage = if (recent.isEmpty()) 0.0 else {
            val weights = recent.indices.map { (it + 1).toDouble() }
            recent.indices.sumOf { idx -> recent[idx] * weights[idx] } / weights.sum()
        }
        val projectedRate = when {
            recentAverage > 0.0 -> recentAverage
            cycleAverage > 0.0 -> cycleAverage
            currentStreams > 0L -> {
                val reference = latestDataDate ?: referenceDate
                val elapsed = (ChronoUnit.DAYS.between(cycleStart, reference) + 1L).coerceAtLeast(1L)
                currentStreams.toDouble() / elapsed.toDouble()
            }
            else -> 0.0
        }.coerceAtLeast(0.0)

        val projectionStart = latestDataDate ?: referenceDate
        val remainingDays = max(0L, ChronoUnit.DAYS.between(projectionStart, cycleEnd))
        val projectedStreams = max(currentStreams, (currentStreams + projectedRate * remainingDays).roundToLong())

        val variability = if (recent.size >= 2) {
            val mean = recent.average()
            val dev = recent.sumOf { abs(it - mean) } / recent.size.toDouble()
            (dev / max(1.0, mean)).coerceIn(0.05, 0.60)
        } else 0.25

        val conservativeStreams = max(
            currentStreams,
            (currentStreams + projectedRate * (1.0 - variability.coerceAtMost(.45)) * remainingDays).roundToLong()
        )
        val optimisticStreams = max(
            projectedStreams,
            (currentStreams + projectedRate * (1.0 + variability.coerceAtMost(.45)) * remainingDays).roundToLong()
        )

        val distinctObserved = observedDates.distinct().sorted()
        val coveredDays = when {
            distinctObserved.isEmpty() -> 0
            distinctObserved.size == 1 && normalizedMode == "TOTAL" ->
                (ChronoUnit.DAYS.between(cycleStart, distinctObserved.first()) + 1L).toInt().coerceAtLeast(1)
            else -> distinctObserved.size
        }
        val confidence = when {
            currentStreams <= 0L || allRates.isEmpty() -> "Baixa"
            allRates.size >= 7 && coveredDays >= 7 && variability <= .38 -> "Alta"
            allRates.size >= 3 && coveredDays >= 3 -> "Média"
            else -> "Baixa"
        }

        return CycleMetrics(
            currentStreams = currentStreams,
            dailyEntries = dailyEntries,
            cycleDailyAverage = cycleAverage,
            recentDailyAverage = recentAverage,
            projectedDailyRate = projectedRate,
            projectedStreams = projectedStreams,
            conservativeStreams = conservativeStreams,
            optimisticStreams = optimisticStreams,
            confidence = confidence,
            sampleCount = allRates.size,
            coveredDays = coveredDays,
            variability = variability,
            latestDataDate = latestDataDate
        )
    }

    private fun inRange(dateIso: String, start: LocalDate, end: LocalDate): Boolean = runCatching {
        val date = LocalDate.parse(dateIso)
        !date.isBefore(start) && !date.isAfter(end)
    }.getOrDefault(false)
}
