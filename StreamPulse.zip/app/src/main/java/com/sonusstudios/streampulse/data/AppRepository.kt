package com.sonusstudios.streampulse.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.sonusstudios.streampulse.core.AppState
import com.sonusstudios.streampulse.core.Artist
import com.sonusstudios.streampulse.core.DistributorRules
import com.sonusstudios.streampulse.core.DailyStreamRecord
import com.sonusstudios.streampulse.core.RoyaltyPayment
import com.sonusstudios.streampulse.core.StreamSnapshot
import com.sonusstudios.streampulse.core.UserPreferences
import com.sonusstudios.streampulse.core.UserActivityRecord
import com.sonusstudios.streampulse.core.PulseFeaturePass
import com.sonusstudios.streampulse.notifications.SonusNotificationCenter
import com.sonusstudios.streampulse.widgets.SonusWidgetCenter
import java.time.YearMonth
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

private val Context.dataStore by preferencesDataStore(name = "streampulse_state")

class AppRepository(private val context: Context) {
    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }
    private val stateKey = stringPreferencesKey("app_state_json")
    private val financialLearning = FinancialLearningCloud(context)

    val state: Flow<AppState> = context.dataStore.data.map { prefs ->
        prefs[stateKey]?.let { raw ->
            runCatching { json.decodeFromString<AppState>(raw) }
                .map(::migrate)
                .getOrDefault(AppState())
        } ?: AppState()
    }

    private fun migrate(state: AppState): AppState {
        return state.copy(
            schemaVersion = 20,
            artists = state.artists.map { artist ->
                val persistedMode = artist.streamEntryMode?.uppercase()?.takeIf { it == "TOTAL" || it == "DIA" }
                artist.copy(streamEntryMode = persistedMode ?: DistributorRules.financialProfile(artist).entryMode.uppercase())
            },
            preferences = state.preferences.copy(
                themeMode = if (state.preferences.themeMode == com.sonusstudios.streampulse.core.ThemeMode.SYSTEM) com.sonusstudios.streampulse.core.ThemeMode.DYNAMIC else state.preferences.themeMode,
                trendWindowDays = state.preferences.trendWindowDays.coerceIn(2, 14),
                pulseMonthlyCoins = state.preferences.pulseMonthlyCoins.coerceAtLeast(0),
                pulseBonusCoins = state.preferences.pulseBonusCoins.coerceAtLeast(0),
                adRewardMultiplier = state.preferences.adRewardMultiplier.coerceIn(1, 2),
                publicCommunityMinimum = state.preferences.publicCommunityMinimum.coerceAtLeast(1),
                mobileDataWarningMb = state.preferences.mobileDataWarningMb.coerceIn(10, 5_000)
            )
        )
    }

    private suspend fun mutate(block: (AppState) -> AppState) {
        context.dataStore.edit { prefs ->
            val current = prefs[stateKey]?.let { raw ->
                runCatching { json.decodeFromString<AppState>(raw) }
                    .map(::migrate)
                    .getOrDefault(AppState())
            } ?: AppState()
            prefs[stateKey] = json.encodeToString(block(current))
        }
        // Mantém widgets financeiros, metas e painéis sincronizados com a mesma fonte local.
        runCatching { SonusWidgetCenter.refreshAll(context) }
    }

    suspend fun addArtist(artist: Artist) = mutate { current ->
        // O limite comercial pertence à camada de plano/UI. O repositório não fixa um teto,
        // Limites públicos atuais: Free (1), Prata (3), Ouro (8) e Diamante (ilimitado).
        current.copy(
            artists = current.artists + artist,
            selectedArtistId = artist.id,
            onboardingComplete = true
        )
    }

    suspend fun updateArtist(artist: Artist) = mutate { current ->
        current.copy(artists = current.artists.map { if (it.id == artist.id) artist else it })
    }

    suspend fun deleteArtist(id: String) = mutate { current ->
        val artists = current.artists.filterNot { it.id == id }
        current.copy(
            artists = artists,
            selectedArtistId = if (current.selectedArtistId == id) artists.firstOrNull()?.id else current.selectedArtistId,
            snapshots = current.snapshots.filterNot { it.artistId == id },
            dailyStreamRecords = current.dailyStreamRecords.filterNot { it.artistId == id },
            payments = current.payments.filterNot { it.artistId == id },
            activityRecords = current.activityRecords.filterNot { it.artistId == id },
            // No SONUS, remover a última distribuidora não "desconfigura" o app.
            // Player e Ferramentas continuam sendo um uso completo sem artista cadastrado.
            onboardingComplete = true
        )
    }

    suspend fun selectArtist(id: String) = mutate { it.copy(selectedArtistId = id) }

    suspend fun addSnapshot(snapshot: StreamSnapshot) {
        mutate { current ->
            // Cada salvamento vira um evento histórico. Várias leituras no mesmo dia são preservadas.
            current.copy(snapshots = current.snapshots + snapshot)
        }
        runCatching {
            val latest = state.first()
            SonusNotificationCenter.evaluateFinancialMilestones(context, latest)
            SonusNotificationCenter.evaluateForecastMovement(context, latest)
        }
    }

    /** Replaces every snapshot for the same artist/date/cycle with one authoritative reading. */
    suspend fun replaceSnapshotsForDate(snapshot: StreamSnapshot) {
        mutate { current ->
            val kept = current.snapshots.filterNot { existing ->
                existing.artistId == snapshot.artistId &&
                    existing.dateIso == snapshot.dateIso &&
                    existing.cycleId == snapshot.cycleId
            }
            current.copy(snapshots = kept + snapshot)
        }
    }

    suspend fun deleteSnapshotsForDate(artistId: String, dateIso: String, cycleId: String?) {
        mutate { current ->
            current.copy(snapshots = current.snapshots.filterNot {
                it.artistId == artistId && it.dateIso == dateIso && it.cycleId == cycleId
            })
        }
    }

    suspend fun deleteDailyStreamRecord(artistId: String, dateIso: String, cycleId: String?) {
        mutate { current ->
            current.copy(dailyStreamRecords = current.dailyStreamRecords.filterNot {
                it.artistId == artistId && it.dateIso == dateIso && it.cycleId == cycleId
            })
        }
    }

    suspend fun refreshGlobalFinancialLearning() {
        val current = state.first()
        val distributors = current.artists.map { it.distributor }.distinct()
        distributors.forEach { distributor ->
            val global = runCatching { withTimeoutOrNull(4_000L) { financialLearning.read(distributor) } }.getOrNull() ?: return@forEach
            applyGlobalFinancialReference(distributor, global)
        }
    }

    private suspend fun applyGlobalFinancialReference(
        distributor: com.sonusstudios.streampulse.core.DistributorId,
        global: FinancialLearningCloud.Snapshot
    ) = mutate { current ->
        current.copy(artists = current.artists.map { artist ->
            if (artist.distributor != distributor) artist else artist.copy(
                globalReferenceRpmBrl = global.averageRpm,
                globalReferenceMedianRpmBrl = global.medianRpm,
                globalReferenceSpreadRpmBrl = global.spreadRpm,
                globalReferenceAccuracyPercent = global.accuracyPercent,
                globalReferenceSampleCount = global.sampleCount
            )
        })
    }

    suspend fun upsertDailyStreamRecord(record: DailyStreamRecord) {
        mutate { current ->
            // Um dia possui um fechamento manual. Salvar novamente substitui o valor daquele dia.
            val withoutSameDay = current.dailyStreamRecords.filterNot {
                it.artistId == record.artistId &&
                    it.dateIso == record.dateIso &&
                    it.cycleId == record.cycleId
            }
            current.copy(dailyStreamRecords = withoutSameDay + record)
        }
        runCatching {
            val latest = state.first()
            SonusNotificationCenter.evaluateFinancialMilestones(context, latest)
            SonusNotificationCenter.evaluateForecastMovement(context, latest)
        }
    }

    suspend fun addPayment(payment: RoyaltyPayment) {
        mutate { current ->
        val updatedArtists = current.artists.map { artist ->
            if (!payment.isRetroactive && artist.id == payment.artistId) {
                val paidDate = runCatching { java.time.LocalDate.parse(payment.paidDateIso) }.getOrNull()
                val requestedCycleStart = payment.newCycleStartIso?.let { runCatching { java.time.LocalDate.parse(it) }.getOrNull() } ?: paidDate
                // The selected start is authoritative for the new window. Data on/after this day
                // remains in the new cycle, so the previous cycle is considered consumed only
                // through the day before it. This also makes historical entries immediately
                // reappear in charts when the user corrects an early/late payout date.
                val lastCounted = payment.lastCountedDataDateIso?.let { runCatching { java.time.LocalDate.parse(it) }.getOrNull() }
                    ?: requestedCycleStart?.minusDays(1)
                val nextData = requestedCycleStart ?: lastCounted?.plusDays(1) ?: paidDate
                val payoutDayOverride = if (payment.adoptActualPayoutDayAsPattern) paidDate?.dayOfMonth?.coerceIn(1, 31) else artist.financialExpectedPayoutDayOverride
                val projectedArtist = artist.copy(financialExpectedPayoutDayOverride = payoutDayOverride)
                val nextExpected = paidDate?.let { DistributorRules.nextExpectedPayoutDate(projectedArtist, it).toString() }
                artist.copy(
                    lastPayoutDateIso = if (DistributorRules.needsManualPayoutDate(artist.distributor)) payment.paidDateIso else artist.lastPayoutDateIso,
                    financialCycleStartIso = requestedCycleStart?.toString() ?: payment.paidDateIso,
                    financialCycleId = java.util.UUID.randomUUID().toString(),
                    lastCountedDataDateIso = lastCounted?.toString(),
                    nextUnconsumedDataDateIso = nextData?.toString() ?: payment.paidDateIso,
                    nextExpectedPayoutDateIso = nextExpected,
                    financialExpectedPayoutDayOverride = payoutDayOverride,
                    lastActualPayoutDateIso = payment.paidDateIso
                )
            } else artist
        }
        val amountLabel = "R$ " + String.format(java.util.Locale.US, "%.2f", payment.amountBrl).replace('.', ',')
        val periodLabel = payment.referenceMonthIso?.let { " • referência $it" }.orEmpty()
        val activity = UserActivityRecord(
            id = java.util.UUID.randomUUID().toString(),
            artistId = payment.artistId,
            title = if (payment.isRetroactive) "Pagamento anterior registrado" else "Pagamento registrado",
            category = "Financeiro",
            detail = amountLabel + periodLabel,
            success = true,
            createdAtEpochMillis = System.currentTimeMillis()
        )
        current.copy(
            payments = current.payments + payment,
            artists = updatedArtists,
            activityRecords = (current.activityRecords + activity).takeLast(2_500)
        )
        }
        runCatching {
            val latest = state.first()
            val artist = latest.artists.firstOrNull { it.id == payment.artistId }
            if (artist != null && payment.amountBrl > 0.0 && payment.cycleStreams > 0L) {
                val global = withTimeoutOrNull(6_000L) {
                    financialLearning.submitAndRead(artist.distributor, payment)
                }
                if (global != null) applyGlobalFinancialReference(artist.distributor, global)
            }
            val refreshed = state.first()
            SonusNotificationCenter.evaluateFinancialMilestones(context, refreshed)
            SonusNotificationCenter.evaluateForecastMovement(context, refreshed)
        }
    }



    suspend fun addActivity(record: UserActivityRecord) {
        // v0.8.15: o histórico geral foi descontinuado. Streams permanecem no histórico dedicado.
        // Não persistimos navegação, abertura de telas ou ferramentas para evitar ruído e peso.
        return
    }

    suspend fun deleteActivity(id: String) = mutate { current ->
        current.copy(activityRecords = current.activityRecords.filterNot { it.id == id })
    }

    suspend fun clearActivityHistory(artistId: String? = null) = mutate { current ->
        current.copy(activityRecords = if (artistId == null) emptyList() else current.activityRecords.filterNot { it.artistId == artistId || it.artistId == null })
    }


    suspend fun ensureConverterWallet(uid: String, monthlyAllowance: Int = 5) = mutate { current ->
        val prefs = current.preferences
        val period = YearMonth.now().toString()
        val ownerChanged = prefs.converterCoinsOwnerUid != uid
        val periodChanged = prefs.converterCoinsPeriod != period
        if (!ownerChanged && !periodChanged) current
        else current.copy(
            preferences = prefs.copy(
                converterCoins = monthlyAllowance.coerceAtLeast(0),
                converterCoinsPeriod = period,
                converterCoinsOwnerUid = uid
            )
        )
    }

    suspend fun consumeConverterCoin(uid: String): Boolean {
        var consumed = false
        mutate { current ->
            val prefs = current.preferences
            if (prefs.converterCoinsOwnerUid == uid && prefs.converterCoins > 0) {
                consumed = true
                current.copy(preferences = prefs.copy(converterCoins = prefs.converterCoins - 1))
            } else current
        }
        return consumed
    }

    suspend fun addConverterCoins(uid: String, amount: Int) = mutate { current ->
        val prefs = current.preferences
        if (prefs.converterCoinsOwnerUid != uid || amount <= 0) current
        else current.copy(preferences = prefs.copy(converterCoins = (prefs.converterCoins + amount).coerceAtMost(9999)))
    }

    suspend fun setConverterCoins(uid: String, amount: Int) = mutate { current ->
        val prefs = current.preferences
        if (prefs.converterCoinsOwnerUid != uid) current
        else current.copy(preferences = prefs.copy(converterCoins = amount.coerceIn(0, 9999)))
    }

    suspend fun ensurePulseWallet(uid: String, monthlyAllowance: Int, tierName: String? = null) {
        val currentPolicyVersion = 3 // code97: Free 5 / Prata 200 / Ouro 500 / Diamante ilimitado
        var renewedCycle = false
        var previousPeriod: String? = null
        mutate { current ->
            val prefs = current.preferences
            val period = YearMonth.now().toString()
            val ownerChanged = prefs.pulseCoinsOwnerUid != uid
            val periodChanged = prefs.pulseCoinsPeriod != period
            val tierChanged = tierName != null && prefs.pulseUsageTierName != tierName
            val policyChanged = prefs.pulseWalletPolicyVersion != currentPolicyVersion
            renewedCycle = !ownerChanged && prefs.pulseCoinsPeriod != null && periodChanged
            if (renewedCycle) previousPeriod = prefs.pulseCoinsPeriod
            if (!ownerChanged && !periodChanged && !tierChanged && !policyChanged) current
            else current.copy(
                preferences = prefs.copy(
                    pulseMonthlyCoins = monthlyAllowance.coerceAtLeast(0),
                    pulseBonusCoins = 0,
                    pulseCoinsPeriod = period,
                    pulseCoinsOwnerUid = uid,
                    pulseUsageTierName = tierName ?: prefs.pulseUsageTierName,
                    pulseWalletPolicyVersion = currentPolicyVersion
                )
            )
        }
        if (renewedCycle) {
            runCatching {
                val previousUses = previousPeriod?.let { SonusNotificationCenter.premiumUsageCount(context, it) } ?: 0
                if (previousUses > 0) {
                    SonusNotificationCenter.add(
                        context,
                        "Resumo do ciclo",
                        "Você concluiu $previousUses operação(ões) com ferramentas Premium no último ciclo.",
                        "PREMIUM",
                        "PREMIUM",
                        false
                    )
                }
                SonusNotificationCenter.add(
                    context,
                    "Moedas SONUS renovadas",
                    if (monthlyAllowance == Int.MAX_VALUE) "Seu novo ciclo começou com ferramentas Premium ilimitadas." else "Seu novo ciclo começou com $monthlyAllowance Moedas SONUS disponíveis.",
                    "PREMIUM",
                    "PREMIUM",
                    false
                )
                SonusNotificationCenter.clearPremiumUsageHistory(context)
            }
        }
    }

    suspend fun consumePulseCoins(uid: String, amount: Int = 1): Boolean {
        if (amount <= 0) return true
        var consumed = false
        var before = 0
        var after = 0
        var allowance = 0
        var planName = "FREE"
        mutate { current ->
            val prefs = current.preferences
            if (prefs.pulseCoinsOwnerUid != uid) return@mutate current
            val total = prefs.pulseMonthlyCoins + prefs.pulseBonusCoins
            if (total < amount) return@mutate current
            before = total
            planName = prefs.pulseUsageTierName ?: "FREE"
            allowance = when (planName) {
                "BRONZE", "PRATA" -> 200
                "OURO" -> 500
                "DIAMANTE" -> Int.MAX_VALUE
                else -> 5
            }
            var remaining = amount
            val fromMonthly = minOf(prefs.pulseMonthlyCoins, remaining)
            remaining -= fromMonthly
            val newMonthly = prefs.pulseMonthlyCoins - fromMonthly
            val newBonus = prefs.pulseBonusCoins - remaining
            after = newMonthly + newBonus
            consumed = true
            current.copy(preferences = prefs.copy(pulseMonthlyCoins = newMonthly, pulseBonusCoins = newBonus))
        }
        if (consumed) runCatching { SonusNotificationCenter.notifyUsageThreshold(context, before, after, allowance, planName.lowercase().replaceFirstChar { it.uppercase() }) }
        return consumed
    }

    suspend fun addPulseBonusCoins(uid: String, amount: Int) = mutate { current ->
        val prefs = current.preferences
        if (prefs.pulseCoinsOwnerUid != uid || amount <= 0) current
        else {
            // Code97: anúncios recompensados podem conceder no máximo +10 Moedas SONUS
            // por ciclo. Prata/Ouro só devem chamar este método após esgotar a cota mensal.
            val room = (10 - prefs.pulseBonusCoins).coerceAtLeast(0)
            if (room == 0) current
            else current.copy(preferences = prefs.copy(pulseBonusCoins = prefs.pulseBonusCoins + minOf(amount, room)))
        }
    }

    suspend fun setPulseWalletForTesting(uid: String, monthly: Int, bonus: Int = 0) = mutate { current ->
        val prefs = current.preferences
        if (prefs.pulseCoinsOwnerUid != uid) current
        else current.copy(preferences = prefs.copy(
            pulseMonthlyCoins = monthly.coerceIn(0, 999_999),
            pulseBonusCoins = bonus.coerceIn(0, 999_999)
        ))
    }

    suspend fun applyPromotion(
        tierName: String? = null,
        premiumUntil: Long? = null,
        adFreeUntil: Long? = null,
        adMultiplier: Int? = null,
        adMultiplierUntil: Long? = null,
        discountPercent: Int? = null,
        discountTierName: String? = null,
        discountUntil: Long? = null
    ) = mutate { current ->
        val p = current.preferences
        current.copy(preferences = p.copy(
            promotionalTierName = tierName ?: p.promotionalTierName,
            premiumExpiresAtEpochMillis = premiumUntil ?: p.premiumExpiresAtEpochMillis,
            adFreeUntilEpochMillis = maxOf(p.adFreeUntilEpochMillis ?: 0L, adFreeUntil ?: 0L).takeIf { it > 0L },
            adRewardMultiplier = adMultiplier?.coerceIn(1, 2) ?: p.adRewardMultiplier,
            adRewardMultiplierUntilEpochMillis = adMultiplierUntil ?: p.adRewardMultiplierUntilEpochMillis,
            discountPercent = discountPercent ?: p.discountPercent,
            discountTierName = discountTierName ?: p.discountTierName,
            discountUntilEpochMillis = discountUntil ?: p.discountUntilEpochMillis
        ))
    }


    suspend fun syncRemotePromotions(
        tierName: String?,
        premiumUntil: Long?,
        adFreeUntil: Long?,
        adMultiplier: Int,
        adMultiplierUntil: Long?,
        discountPercent: Int?,
        discountTierName: String?,
        discountUntil: Long?
    ) = mutate { current ->
        val p = current.preferences
        current.copy(preferences = p.copy(
            promotionalTierName = tierName,
            premiumExpiresAtEpochMillis = premiumUntil,
            adFreeUntilEpochMillis = adFreeUntil,
            adRewardMultiplier = adMultiplier.coerceIn(1, 2),
            adRewardMultiplierUntilEpochMillis = adMultiplierUntil,
            discountPercent = discountPercent,
            discountTierName = discountTierName,
            discountUntilEpochMillis = discountUntil
        ))
    }

    suspend fun clearAuthorityPromotions() = mutate { current ->
        val p = current.preferences
        current.copy(preferences = p.copy(
            promotionalTierName = null,
            premiumExpiresAtEpochMillis = null,
            adFreeUntilEpochMillis = null,
            adRewardMultiplier = 1,
            adRewardMultiplierUntilEpochMillis = null,
            discountPercent = null,
            discountTierName = null,
            discountUntilEpochMillis = null
        ))
    }

    suspend fun grantFeaturePass(feature: PulseFeaturePass, durationMillis: Long = 24L * 60L * 60L * 1000L) = mutate { current ->
        val now = System.currentTimeMillis()
        val until = now + durationMillis.coerceIn(60_000L, 7L * 24L * 60L * 60L * 1000L)
        val p = current.preferences
        val updated = when (feature) {
            PulseFeaturePass.PULSE_LIFT -> p.copy(passPulseLiftUntilEpochMillis = maxOf(p.passPulseLiftUntilEpochMillis ?: 0L, until))
            PulseFeaturePass.PULSE_ORBIT_3D -> p.copy(passPulseOrbit3dUntilEpochMillis = maxOf(p.passPulseOrbit3dUntilEpochMillis ?: 0L, until))
            PulseFeaturePass.PULSE_ORBIT_8D -> p.copy(passPulseOrbit8dUntilEpochMillis = maxOf(p.passPulseOrbit8dUntilEpochMillis ?: 0L, until))
            PulseFeaturePass.VOCAL_REMOVER -> p.copy(passVocalRemoverUntilEpochMillis = maxOf(p.passVocalRemoverUntilEpochMillis ?: 0L, until))
            PulseFeaturePass.PITCH_PRO -> p.copy(passPitchProUntilEpochMillis = maxOf(p.passPitchProUntilEpochMillis ?: 0L, until))
            PulseFeaturePass.MERGE_PRO -> p.copy(passMergeProUntilEpochMillis = maxOf(p.passMergeProUntilEpochMillis ?: 0L, until))
            PulseFeaturePass.VIDEO_AUDIO_PRO -> p.copy(passVideoAudioProUntilEpochMillis = maxOf(p.passVideoAudioProUntilEpochMillis ?: 0L, until))
        }
        current.copy(preferences = updated)
    }

    suspend fun updatePreferences(preferences: UserPreferences) = mutate { current ->
        current.copy(preferences = preferences.copy(trendWindowDays = preferences.trendWindowDays.coerceIn(2, 14)))
    }

    suspend fun replaceState(restored: AppState) = mutate { current ->
        // O backup restaura dados do criador, nunca autoridade da conta. Plano, promoções,
        // descontos e Moedas SONUS continuam vindo do estado atual/servidor. Isso também
        // impede que um backup antigo seja usado para recuperar benefícios expirados.
        val migrated = migrate(restored)
        val authority = current.preferences
        val restoredPrefs = migrated.preferences.copy(
            premiumExpiresAtEpochMillis = authority.premiumExpiresAtEpochMillis,
            promotionalTierName = authority.promotionalTierName,
            adFreeUntilEpochMillis = authority.adFreeUntilEpochMillis,
            adRewardMultiplier = authority.adRewardMultiplier,
            adRewardMultiplierUntilEpochMillis = authority.adRewardMultiplierUntilEpochMillis,
            discountPercent = authority.discountPercent,
            discountTierName = authority.discountTierName,
            discountUntilEpochMillis = authority.discountUntilEpochMillis,
            converterCoins = authority.converterCoins,
            converterCoinsPeriod = authority.converterCoinsPeriod,
            converterCoinsOwnerUid = authority.converterCoinsOwnerUid,
            pulseMonthlyCoins = authority.pulseMonthlyCoins,
            pulseBonusCoins = authority.pulseBonusCoins,
            pulseCoinsPeriod = authority.pulseCoinsPeriod,
            pulseCoinsOwnerUid = authority.pulseCoinsOwnerUid,
            pulseUsageTierName = authority.pulseUsageTierName,
            passPulseLiftUntilEpochMillis = authority.passPulseLiftUntilEpochMillis,
            passPulseOrbit3dUntilEpochMillis = authority.passPulseOrbit3dUntilEpochMillis,
            passPulseOrbit8dUntilEpochMillis = authority.passPulseOrbit8dUntilEpochMillis,
            passVocalRemoverUntilEpochMillis = authority.passVocalRemoverUntilEpochMillis,
            passPitchProUntilEpochMillis = authority.passPitchProUntilEpochMillis,
            passMergeProUntilEpochMillis = authority.passMergeProUntilEpochMillis,
            passVideoAudioProUntilEpochMillis = authority.passVideoAudioProUntilEpochMillis
        )
        migrated.copy(preferences = restoredPrefs, onboardingComplete = true)
    }

    suspend fun markAppSetupComplete() = mutate { current ->
        if (current.onboardingComplete) current else current.copy(onboardingComplete = true)
    }


    suspend fun clearAppUsageStats() = mutate { current ->
        val p = current.preferences
        current.copy(preferences = p.copy(
            appUsageTotalMillis = 0L, appUsageSessionCount = 0L, appUsageDaysIso = emptyList(),
            appUsageLongestSessionMillis = 0L, appUsageLastAccessIso = null, appUsageDailyMillis = emptyMap(),
            appUsageFeatureMillis = emptyMap(), appUsageFeatureDailyMillis = emptyMap(),
            dataUsageTotalRxBytes = 0L, dataUsageTotalTxBytes = 0L, dataUsageDailyRxBytes = emptyMap(), dataUsageDailyTxBytes = emptyMap()
        ))
    }
    suspend fun recordAppOpen(dayIso: String, accessIso: String) = mutate { current ->
        val prefs = current.preferences
        val days = (prefs.appUsageDaysIso + dayIso).distinct().takeLast(4000)
        current.copy(
            preferences = prefs.copy(
                appUsageSessionCount = prefs.appUsageSessionCount + 1L,
                appUsageDaysIso = days,
                appUsageLastAccessIso = accessIso
            )
        )
    }

    suspend fun recordAppUsage(durationMillis: Long, dayIso: String, accessIso: String) = mutate { current ->
        val prefs = current.preferences
        val safeDuration = durationMillis.coerceAtLeast(0L)
        val days = (prefs.appUsageDaysIso + dayIso).distinct().takeLast(4000)
        current.copy(
            preferences = prefs.copy(
                appUsageTotalMillis = prefs.appUsageTotalMillis + safeDuration,
                appUsageLongestSessionMillis = maxOf(prefs.appUsageLongestSessionMillis, safeDuration),
                appUsageDailyMillis = (prefs.appUsageDailyMillis + (dayIso to ((prefs.appUsageDailyMillis[dayIso] ?: 0L) + safeDuration))).entries.sortedBy { it.key }.takeLast(400).associate { it.toPair() },
                appUsageDaysIso = days,
                appUsageLastAccessIso = accessIso
            )
        )
    }


    suspend fun recordFeatureUsage(feature: String, durationMillis: Long, dayIso: String) = mutate { current ->
        val prefs = current.preferences
        val safe = durationMillis.coerceAtLeast(0L)
        val dailyKey = "$dayIso|$feature"
        current.copy(preferences = prefs.copy(
            appUsageFeatureMillis = prefs.appUsageFeatureMillis + (feature to ((prefs.appUsageFeatureMillis[feature] ?: 0L) + safe)),
            appUsageFeatureDailyMillis = (prefs.appUsageFeatureDailyMillis + (dailyKey to ((prefs.appUsageFeatureDailyMillis[dailyKey] ?: 0L) + safe))).entries.sortedBy { it.key }.takeLast(3000).associate { it.toPair() }
        ))
    }

    suspend fun recordDataUsage(rxBytes: Long, txBytes: Long, dayIso: String) = mutate { current ->
        val prefs = current.preferences
        val rx = rxBytes.coerceAtLeast(0L); val tx = txBytes.coerceAtLeast(0L)
        current.copy(preferences = prefs.copy(
            dataUsageTotalRxBytes = prefs.dataUsageTotalRxBytes + rx,
            dataUsageTotalTxBytes = prefs.dataUsageTotalTxBytes + tx,
            dataUsageDailyRxBytes = (prefs.dataUsageDailyRxBytes + (dayIso to ((prefs.dataUsageDailyRxBytes[dayIso] ?: 0L) + rx))).entries.sortedBy { it.key }.takeLast(400).associate { it.toPair() },
            dataUsageDailyTxBytes = (prefs.dataUsageDailyTxBytes + (dayIso to ((prefs.dataUsageDailyTxBytes[dayIso] ?: 0L) + tx))).entries.sortedBy { it.key }.takeLast(400).associate { it.toPair() }
        ))
    }

    suspend fun resetAllPreservingAuthority() = mutate { current ->
        val p = current.preferences
        AppState(
            preferences = UserPreferences(
                // Configurações pessoais voltam ao padrão; somente autoridade/benefícios
                // válidos da conta permanecem.
                premiumExpiresAtEpochMillis = p.premiumExpiresAtEpochMillis,
                promotionalTierName = p.promotionalTierName,
                adFreeUntilEpochMillis = p.adFreeUntilEpochMillis,
                adRewardMultiplier = p.adRewardMultiplier,
                adRewardMultiplierUntilEpochMillis = p.adRewardMultiplierUntilEpochMillis,
                discountPercent = p.discountPercent,
                discountTierName = p.discountTierName,
                discountUntilEpochMillis = p.discountUntilEpochMillis,
                pulseMonthlyCoins = p.pulseMonthlyCoins,
                pulseBonusCoins = p.pulseBonusCoins,
                pulseCoinsPeriod = p.pulseCoinsPeriod,
                pulseCoinsOwnerUid = p.pulseCoinsOwnerUid,
                pulseUsageTierName = p.pulseUsageTierName,
                passPulseLiftUntilEpochMillis = p.passPulseLiftUntilEpochMillis,
                passPulseOrbit3dUntilEpochMillis = p.passPulseOrbit3dUntilEpochMillis,
                passPulseOrbit8dUntilEpochMillis = p.passPulseOrbit8dUntilEpochMillis,
                passVocalRemoverUntilEpochMillis = p.passVocalRemoverUntilEpochMillis,
                passPitchProUntilEpochMillis = p.passPitchProUntilEpochMillis,
                passMergeProUntilEpochMillis = p.passMergeProUntilEpochMillis,
                passVideoAudioProUntilEpochMillis = p.passVideoAudioProUntilEpochMillis
            )
        )
    }

    suspend fun resetAll() {
        context.dataStore.edit { it.remove(stateKey) }
    }
}
