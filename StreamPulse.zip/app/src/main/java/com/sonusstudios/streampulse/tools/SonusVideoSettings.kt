package com.sonusstudios.streampulse.tools

import android.content.Context
import android.content.Intent
import android.media.audiofx.Equalizer
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.documentfile.provider.DocumentFile
import kotlin.math.roundToInt

internal const val SONUS_VIDEO_PLAYER_VERSION = "0.5"
internal const val SONUS_AUDIO_PLAYER_VERSION = "0.14"

internal enum class SonusVideoThumbnailSize(val label: String) {
    SMALL("Pequena"), MEDIUM("Média"), LARGE("Grande")
}

internal enum class SonusVideoTheme(val label: String, val colors: List<Color>, val accent: Color) {
    SONUS("SONUS", listOf(Color(0xFF05080E), Color(0xFF081522), Color(0xFF03050A)), Color(0xFF6EDCFF)),
    AMOLED("AMOLED", listOf(Color.Black, Color(0xFF050505), Color.Black), Color(0xFFB7B7FF)),
    CINEMA("Cinema", listOf(Color(0xFF09050A), Color(0xFF1C0A12), Color(0xFF05070C)), Color(0xFFFF6A7E)),
    AURORA("Aurora", listOf(Color(0xFF031014), Color(0xFF07343E), Color(0xFF22123D)), Color(0xFF6FFFD8))
}

internal enum class SonusVideoCategory(val label: String) {
    FILM("Filme / Cinema"),
    MUSIC("Clipe / Música"),
    GAMES("Jogos"),
    VOICE("Voz / Podcast / Entrevista"),
    ENTERTAINMENT("Entretenimento"),
    NEUTRAL("Neutro")
}

internal fun classifySonusVideoTitle(title: String): SonusVideoCategory {
    val value = title.lowercase()
    val film = listOf("filme", "movie", "cinema", "longa", "curta metragem", "curta-metragem", "trailer", "filme completo", "full movie")
    val games = listOf("jogando", "gameplay", "free fire", "minecraft", "fortnite", "valorant", "roblox", "gta", "call of duty", "partida", "ranked", "mestre", "zerando", "speedrun", "game ")
    val music = listOf("clipe", "videoclipe", "music video", "official video", "vídeo oficial", "video oficial", "lyric video", "letra oficial", "música", "musica", "ao vivo", "acústico", "acustico", "cover ", "karaokê", "karaoke")
    val voice = listOf("podcast", "entrevista", "debate", "palestra", "aula", "documentário", "documentario", "notícia", "noticia", "jornal", "talk show")
    val entertainment = listOf("vlog", "react", "reação", "reacao", "desafio", "pegadinha", "unboxing", "rotina", "tour", "review", "reagindo", "tente não", "tente nao", "curiosidades", "compilado", "melhores momentos")
    return when {
        film.any(value::contains) -> SonusVideoCategory.FILM
        games.any(value::contains) -> SonusVideoCategory.GAMES
        music.any(value::contains) -> SonusVideoCategory.MUSIC
        voice.any(value::contains) -> SonusVideoCategory.VOICE
        entertainment.any(value::contains) -> SonusVideoCategory.ENTERTAINMENT
        else -> SonusVideoCategory.NEUTRAL
    }
}

internal fun videoEqCurve(category: SonusVideoCategory): List<Float> = when (category) {
    SonusVideoCategory.FILM -> listOf(.22f, .12f, .02f, .12f, .20f)
    SonusVideoCategory.MUSIC -> listOf(.20f, .12f, .00f, .14f, .18f)
    SonusVideoCategory.GAMES -> listOf(.10f, .02f, .10f, .24f, .18f)
    SonusVideoCategory.VOICE -> listOf(-.10f, -.04f, .14f, .28f, .18f)
    SonusVideoCategory.ENTERTAINMENT -> listOf(.08f, .04f, .10f, .16f, .12f)
    SonusVideoCategory.NEUTRAL -> listOf(0f, 0f, 0f, 0f, 0f)
}

internal class SonusVideoEqualizerController {
    private var equalizer: Equalizer? = null
    private var sessionId: Int = 0

    fun apply(audioSessionId: Int, enabled: Boolean, curve: List<Float>) {
        if (audioSessionId <= 0) return
        if (sessionId != audioSessionId || equalizer == null) {
            release()
            equalizer = runCatching { Equalizer(0, audioSessionId) }.getOrNull()
            sessionId = audioSessionId
        }
        val eq = equalizer ?: return
        runCatching {
            eq.enabled = enabled
            if (!enabled) return@runCatching
            val range = eq.bandLevelRange
            val min = range.getOrNull(0)?.toInt() ?: -1500
            val max = range.getOrNull(1)?.toInt() ?: 1500
            val bands = eq.numberOfBands.toInt().coerceAtLeast(1)
            repeat(bands) { index ->
                val normalized = if (bands == 1) 0f else index.toFloat() / (bands - 1).toFloat()
                val sourceIndex = (normalized * (curve.size - 1)).roundToInt().coerceIn(0, curve.lastIndex)
                val fraction = curve[sourceIndex].coerceIn(-1f, 1f)
                val level = if (fraction >= 0f) (fraction * max).roundToInt() else ((-fraction) * min).roundToInt()
                eq.setBandLevel(index.toShort(), level.coerceIn(min, max).toShort())
            }
        }
    }

    fun release() {
        runCatching { equalizer?.release() }
        equalizer = null
        sessionId = 0
    }
}

internal class SonusVideoSettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("sonus_video_settings_v1", Context.MODE_PRIVATE)

    var thumbnailSize: SonusVideoThumbnailSize
        get() = runCatching { SonusVideoThumbnailSize.valueOf(prefs.getString("thumb_size", SonusVideoThumbnailSize.MEDIUM.name)!!) }.getOrDefault(SonusVideoThumbnailSize.MEDIUM)
        set(value) { prefs.edit().putString("thumb_size", value.name).apply() }

    var theme: SonusVideoTheme
        get() = runCatching { SonusVideoTheme.valueOf(prefs.getString("theme", SonusVideoTheme.SONUS.name)!!) }.getOrDefault(SonusVideoTheme.SONUS)
        set(value) { prefs.edit().putString("theme", value.name).apply() }

    var eqEnabled: Boolean
        get() = prefs.getBoolean("eq_enabled", true)
        set(value) { prefs.edit().putBoolean("eq_enabled", value).apply() }

    var autoEq: Boolean
        get() = prefs.getBoolean("eq_auto", true)
        set(value) { prefs.edit().putBoolean("eq_auto", value).apply() }

    var manualCategory: SonusVideoCategory
        get() = runCatching { SonusVideoCategory.valueOf(prefs.getString("eq_manual", SonusVideoCategory.NEUTRAL.name)!!) }.getOrDefault(SonusVideoCategory.NEUTRAL)
        set(value) { prefs.edit().putString("eq_manual", value.name).apply() }

    var performanceProfile: String
        get() = prefs.getString("performance", "Equilibrado") ?: "Equilibrado"
        set(value) { prefs.edit().putString("performance", value).apply() }

    var playbackSpeed: Float
        get() = prefs.getFloat("playback_speed", 1f).coerceIn(.5f, 3f)
        set(value) { prefs.edit().putFloat("playback_speed", value.coerceIn(.5f, 3f)).apply() }

    var playbackMode: String
        get() = prefs.getString("playback_mode", "Sequencial") ?: "Sequencial"
        set(value) { prefs.edit().putString("playback_mode", value).apply() }

    var subtitleSizeSp: Float
        get() = prefs.getFloat("subtitle_size_sp", 18f).coerceIn(12f, 30f)
        set(value) { prefs.edit().putFloat("subtitle_size_sp", value.coerceIn(12f, 30f)).apply() }

    var subtitleColor: String
        get() = prefs.getString("subtitle_color", "Branco") ?: "Branco"
        set(value) { prefs.edit().putString("subtitle_color", value).apply() }

    var subtitleBackground: Boolean
        get() = prefs.getBoolean("subtitle_background", true)
        set(value) { prefs.edit().putBoolean("subtitle_background", value).apply() }

    var subtitleOffsetMs: Int
        get() = prefs.getInt("subtitle_offset_ms", 0).coerceIn(-5000, 5000)
        set(value) { prefs.edit().putInt("subtitle_offset_ms", value.coerceIn(-5000, 5000)).apply() }

    var subtitlePosition: String
        get() = prefs.getString("subtitle_position", "Inferior") ?: "Inferior"
        set(value) { prefs.edit().putString("subtitle_position", value).apply() }

    var liveCaptionLanguage: String
        get() = prefs.getString("live_caption_language", "pt-BR") ?: "pt-BR"
        set(value) { prefs.edit().putString("live_caption_language", value).apply() }

    var selectedFoldersOnly: Boolean
        get() = prefs.getBoolean("selected_folders_only", false)
        set(value) { prefs.edit().putBoolean("selected_folders_only", value).apply() }

    var ignoreWhatsApp: Boolean
        get() = prefs.getBoolean("ignore_whatsapp", false)
        set(value) { prefs.edit().putBoolean("ignore_whatsapp", value).apply() }

    var ignoreScreenRecordings: Boolean
        get() = prefs.getBoolean("ignore_screen_recordings", false)
        set(value) { prefs.edit().putBoolean("ignore_screen_recordings", value).apply() }

    var rememberExternalPosition: Boolean
        get() = prefs.getBoolean("remember_external_position", true)
        set(value) { prefs.edit().putBoolean("remember_external_position", value).apply() }

    var useQuickExternalVideo: Boolean
        get() = prefs.getBoolean("quick_external_video", true)
        set(value) { prefs.edit().putBoolean("quick_external_video", value).apply() }

    var timerMinutes: Int
        get() = prefs.getInt("timer_minutes", 0)
        set(value) { prefs.edit().putInt("timer_minutes", value.coerceAtLeast(0)).apply() }

    var stopAtEnd: Boolean
        get() = prefs.getBoolean("stop_at_end", false)
        set(value) { prefs.edit().putBoolean("stop_at_end", value).apply() }

    fun videoFolders(): Set<String> = (prefs.getStringSet("video_folders", emptySet()) ?: emptySet()).toSet()
    fun addVideoFolder(uri: String) {
        val set = videoFolders().toMutableSet(); set.add(uri)
        prefs.edit().putStringSet("video_folders", set).apply()
    }
    fun removeVideoFolder(uri: String) {
        val set = videoFolders().toMutableSet(); set.remove(uri)
        prefs.edit().putStringSet("video_folders", set).apply()
    }

    fun categoryOverride(uri: String): SonusVideoCategory? {
        val value = prefs.getString("category_${uri.hashCode()}", null) ?: return null
        return runCatching { SonusVideoCategory.valueOf(value) }.getOrNull()
    }
    fun setCategoryOverride(uri: String, category: SonusVideoCategory?) {
        prefs.edit().apply {
            if (category == null) remove("category_${uri.hashCode()}") else putString("category_${uri.hashCode()}", category.name)
        }.apply()
    }

    fun addUsage(section: String, millis: Long) {
        val key = "usage_${section.lowercase()}"
        prefs.edit().putLong(key, prefs.getLong(key, 0L) + millis.coerceAtLeast(0L)).apply()
    }
    fun usage(section: String): Long = prefs.getLong("usage_${section.lowercase()}", 0L)
    fun addPlayback(millis: Long) {
        prefs.edit().putLong("playback_total", prefs.getLong("playback_total", 0L) + millis.coerceAtLeast(0L)).apply()
    }
    fun playbackTotal(): Long = prefs.getLong("playback_total", 0L)
    fun clearStats() {
        val edit = prefs.edit()
        listOf("local", "youtube", "karaoke", "settings").forEach { edit.remove("usage_$it") }
        edit.remove("playback_total").apply()
    }

    fun saveExternalPosition(uri: String, positionMs: Long) {
        prefs.edit().putLong("external_pos_${uri.hashCode()}", positionMs.coerceAtLeast(0L)).apply()
    }
    fun externalPosition(uri: String): Long = prefs.getLong("external_pos_${uri.hashCode()}", 0L)
}

internal val SONUS_AUDIO_FORMATS = listOf("MP3", "WAV", "FLAC", "M4A/AAC", "OGG", "Opus")
internal val SONUS_VIDEO_FORMATS = listOf("MP4/M4V", "MKV", "WebM", "MOV", "AVI*", "MPEG-TS*")

private fun formatUsage(ms: Long): String {
    val totalSeconds = (ms / 1000L).coerceAtLeast(0L)
    val h = totalSeconds / 3600L
    val m = (totalSeconds % 3600L) / 60L
    return if (h > 0) "${h}h ${m}min" else "${m}min"
}

@Composable
internal fun SonusVideoSettingsScreen(
    store: SonusVideoSettingsStore,
    onChanged: () -> Unit
) {
    val context = LocalContext.current
    val cloudStore = remember { SonusCloudMediaStore(context) }
    var refresh by remember { mutableIntStateOf(0) }
    var thumb by remember(refresh) { mutableStateOf(store.thumbnailSize) }
    var theme by remember(refresh) { mutableStateOf(store.theme) }
    var eqEnabled by remember(refresh) { mutableStateOf(store.eqEnabled) }
    var autoEq by remember(refresh) { mutableStateOf(store.autoEq) }
    var manualCategory by remember(refresh) { mutableStateOf(store.manualCategory) }
    var selectedOnly by remember(refresh) { mutableStateOf(store.selectedFoldersOnly) }
    var ignoreWhatsApp by remember(refresh) { mutableStateOf(store.ignoreWhatsApp) }
    var ignoreRecordings by remember(refresh) { mutableStateOf(store.ignoreScreenRecordings) }
    var rememberPosition by remember(refresh) { mutableStateOf(store.rememberExternalPosition) }
    var quickVideo by remember(refresh) { mutableStateOf(store.useQuickExternalVideo) }
    var performance by remember(refresh) { mutableStateOf(store.performanceProfile) }
    var playbackSpeed by remember(refresh) { mutableFloatStateOf(store.playbackSpeed) }
    var playbackMode by remember(refresh) { mutableStateOf(store.playbackMode) }
    var subtitleSize by remember(refresh) { mutableFloatStateOf(store.subtitleSizeSp) }
    var subtitleColor by remember(refresh) { mutableStateOf(store.subtitleColor) }
    var subtitleBackground by remember(refresh) { mutableStateOf(store.subtitleBackground) }
    var subtitleOffset by remember(refresh) { mutableIntStateOf(store.subtitleOffsetMs) }
    var subtitlePosition by remember(refresh) { mutableStateOf(store.subtitlePosition) }
    var liveCaptionLanguage by remember(refresh) { mutableStateOf(store.liveCaptionLanguage) }
    var timer by remember(refresh) { mutableIntStateOf(store.timerMinutes) }
    var stopAtEnd by remember(refresh) { mutableStateOf(store.stopAtEnd) }
    var folders by remember(refresh) { mutableStateOf(store.videoFolders().toList()) }

    fun changed() { refresh++; onChanged() }

    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        runCatching {
            context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        }.recoverCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        store.addVideoFolder(uri.toString())
        folders = store.videoFolders().toList()
        changed()
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 34.dp)
    ) {
        item {
            Text("Ajustes do Player de Vídeo", color = Color.White, fontWeight = FontWeight.Black, fontSize = 21.sp)
            Text("SONUS VIDEO • versão $SONUS_VIDEO_PLAYER_VERSION", color = Color.White.copy(alpha = .55f), fontSize = 10.sp)
        }

        item {
            VideoSettingCard("Miniaturas", Icons.Default.ViewModule) {
                Text("Tamanho da miniatura", color = Color.White, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    SonusVideoThumbnailSize.entries.forEach { value ->
                        FilterChip(selected = thumb == value, onClick = { thumb = value; store.thumbnailSize = value; changed() }, label = { Text(value.label) })
                    }
                }
            }
        }

        item {
            VideoSettingCard("Temas do Player", Icons.Default.Palette) {
                SonusVideoTheme.entries.forEach { value ->
                    Surface(
                        modifier = Modifier.fillMaxWidth().clickable { theme = value; store.theme = value; changed() },
                        shape = RoundedCornerShape(13.dp),
                        color = if (theme == value) value.accent.copy(alpha = .16f) else Color.White.copy(alpha = .04f),
                        border = BorderStroke(1.dp, if (theme == value) value.accent.copy(alpha = .62f) else Color.White.copy(alpha = .07f))
                    ) {
                        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(38.dp).background(Brush.linearGradient(value.colors), RoundedCornerShape(10.dp)))
                            Spacer(Modifier.width(9.dp)); Text(value.label, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            if (theme == value) Icon(Icons.Default.CheckCircle, null, tint = value.accent)
                        }
                    }
                }
            }
        }

        item {
            VideoSettingCard("Equalizador automático", Icons.Default.GraphicEq) {
                VideoSettingsSwitch("Equalizador de vídeo", "Aplica curvas moderadas ao áudio do vídeo", eqEnabled) { eqEnabled = it; store.eqEnabled = it; changed() }
                VideoSettingsSwitch("Identificar pelo título", "Filmes, clipes, jogos, voz e entretenimento", autoEq) { autoEq = it; store.autoEq = it; changed() }
                if (!autoEq) {
                    Text("Preset manual", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    SonusVideoCategory.entries.forEach { cat ->
                        FilterChip(selected = manualCategory == cat, onClick = { manualCategory = cat; store.manualCategory = cat; changed() }, label = { Text(cat.label) })
                    }
                }
                VideoEqCurvePreview(videoEqCurve(if(autoEq) SonusVideoCategory.FILM else manualCategory), Color(0xFF69D7FF))
                Text("Ex.: “Filme completo Homem-Aranha 2” → Cinema • “Jogando Free Fire até pegar mestre” → Jogos.", color = Color.White.copy(alpha = .56f), fontSize = 9.sp)
            }
        }

        item {
            VideoSettingCard("Pastas de leitura", Icons.Default.FolderOpen) {
                VideoSettingsSwitch("Usar somente pastas escolhidas", "Quando ligado, a galeria do SONUS VIDEO fica focada nas pastas abaixo", selectedOnly) { selectedOnly = it; store.selectedFoldersOnly = it; changed() }
                VideoSettingsSwitch("Ignorar WhatsApp", "Oculta caminhos identificados como WhatsApp", ignoreWhatsApp) { ignoreWhatsApp = it; store.ignoreWhatsApp = it; changed() }
                VideoSettingsSwitch("Ignorar gravações de tela", "Oculta ScreenRecord/Screen_Recording quando possível", ignoreRecordings) { ignoreRecordings = it; store.ignoreScreenRecordings = it; changed() }
                folders.forEach { raw ->
                    val uri = runCatching { Uri.parse(raw) }.getOrNull()
                    val name = uri?.let { DocumentFile.fromTreeUri(context, it)?.name }.orEmpty().ifBlank { "Pasta autorizada" }
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Folder, null, tint = Color(0xFF69D7FF)); Spacer(Modifier.width(8.dp))
                        Text(name, color = Color.White, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        IconButton(onClick = { store.removeVideoFolder(raw); folders = store.videoFolders().toList(); changed() }) { Icon(Icons.Default.DeleteOutline, "Remover", tint = Color.White.copy(alpha=.7f)) }
                    }
                }
                OutlinedButton(onClick = { folderPicker.launch(null) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.CreateNewFolder, null); Spacer(Modifier.width(6.dp)); Text("Adicionar pasta") }
            }
        }

        item {
            VideoSettingCard("Reprodução", Icons.Default.PlayCircle) {
                Text("Perfil de desempenho", color = Color.White, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Econômico", "Equilibrado", "Máxima qualidade").forEach { value ->
                        FilterChip(selected = performance == value, onClick = { performance = value; store.performanceProfile = value; changed() }, label = { Text(value) })
                    }
                }
                Text("Velocidade padrão: ${String.format(java.util.Locale.US, "%.2fx", playbackSpeed)}", color = Color.White, fontWeight = FontWeight.Bold)
                Slider(playbackSpeed, { playbackSpeed = it; store.playbackSpeed = it; changed() }, valueRange = .5f..3f, steps = 9)
                Text("Modo de reprodução", color = Color.White, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    listOf("Sequencial", "Repetir vídeo", "Repetir todos", "Aleatório").forEach { value ->
                        FilterChip(selected = playbackMode == value, onClick = { playbackMode = value; store.playbackMode = value; changed() }, label = { Text(value) })
                    }
                }
                Text("Temporizador", color = Color.White, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(0 to "Off", 15 to "15 min", 30 to "30 min", 60 to "60 min").forEach { (value, label) ->
                        FilterChip(selected = timer == value, onClick = { timer = value; store.timerMinutes = value; changed() }, label = { Text(label) })
                    }
                }
                VideoSettingsSwitch("Parar ao fim", "Não inicia outro vídeo automaticamente ao terminar", stopAtEnd) { stopAtEnd = it; store.stopAtEnd = it; changed() }
            }
        }

        item {
            VideoSettingCard("Legendas", Icons.Default.Subtitles) {
                Text("Tamanho: ${subtitleSize.roundToInt()} sp", color=Color.White, fontWeight=FontWeight.Bold)
                Slider(subtitleSize, { subtitleSize = it; store.subtitleSizeSp = it; changed() }, valueRange = 12f..30f, steps = 8)
                Text("Cor", color=Color.White, fontWeight=FontWeight.Bold)
                Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                    listOf("Branco","Amarelo","Ciano").forEach { value -> FilterChip(selected=subtitleColor==value,onClick={subtitleColor=value;store.subtitleColor=value;changed()},label={Text(value)}) }
                }
                VideoSettingsSwitch("Fundo de contraste", "Aplica fundo escuro atrás da legenda", subtitleBackground) { subtitleBackground=it;store.subtitleBackground=it;changed() }
                Text("Posição", color=Color.White, fontWeight=FontWeight.Bold)
                Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                    listOf("Superior","Centro","Inferior").forEach { value -> FilterChip(selected=subtitlePosition==value,onClick={subtitlePosition=value;store.subtitlePosition=value;changed()},label={Text(value)}) }
                }
                Text("Idioma da Legenda ao vivo", color=Color.White, fontWeight=FontWeight.Bold)
                Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                    listOf("pt-BR" to "Português","en-US" to "English","es-ES" to "Español").forEach { (code,label) -> FilterChip(selected=liveCaptionLanguage==code,onClick={liveCaptionLanguage=code;store.liveCaptionLanguage=code;changed()},label={Text(label)}) }
                }
                Text("Sincronização: ${if(subtitleOffset>=0) "+" else ""}${subtitleOffset} ms", color=Color.White, fontWeight=FontWeight.Bold)
                Slider(subtitleOffset.toFloat(), { subtitleOffset = it.roundToInt(); store.subtitleOffsetMs = subtitleOffset; changed() }, valueRange = -5000f..5000f, steps = 19)
            }
        }

        item {
            VideoSettingCard("Favoritos e histórico", Icons.Default.History) {
                Text("${cloudStore.favoriteUris("video").size} favoritos • ${cloudStore.recents("video").size} itens no histórico", color=Color.White.copy(alpha=.72f), fontSize=10.sp)
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick={cloudStore.clearFavorites("video");changed()}, modifier=Modifier.weight(1f)){Text("Limpar favoritos")}
                    OutlinedButton(onClick={cloudStore.clearRecents("video");changed()}, modifier=Modifier.weight(1f)){Text("Limpar histórico")}
                }
            }
        }

        item {
            VideoSettingCard("Reprodução externa", Icons.Default.OpenInNew) {
                VideoSettingsSwitch("Player Rápido para vídeos", "Ao abrir um arquivo externo, entra direto no vídeo sem carregar o app completo", quickVideo) { quickVideo = it; store.useQuickExternalVideo = it; changed() }
                VideoSettingsSwitch("Lembrar última posição", "Retoma vídeos externos de onde pararam", rememberPosition) { rememberPosition = it; store.rememberExternalPosition = it; changed() }
                Text("O SONUS também é registrado no Android como opção para abrir arquivos de áudio e vídeo compatíveis.", color = Color.White.copy(alpha=.58f), fontSize = 9.sp)
            }
        }

        item {
            VideoSettingCard("Estatísticas", Icons.Default.Insights) {
                Text("Tempo reproduzindo vídeo: ${formatUsage(store.playbackTotal())}", color = Color.White, fontWeight = FontWeight.Bold)
                listOf(
                    "Vídeos" to "local", "YouTube" to "youtube", "Karaokê" to "karaoke", "Ajustes" to "settings"
                ).forEach { (label, key) ->
                    Row(Modifier.fillMaxWidth()) { Text(label, color=Color.White.copy(alpha=.72f), fontSize=10.sp, modifier=Modifier.weight(1f)); Text(formatUsage(store.usage(key)), color=Color.White, fontSize=10.sp) }
                }
                OutlinedButton(onClick = { store.clearStats(); changed() }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.DeleteSweep, null); Spacer(Modifier.width(6.dp)); Text("Limpar estatísticas") }
            }
        }

        item {
            VideoSettingCard("Formatos compatíveis", Icons.Default.Info) {
                Text("Player de Música • v$SONUS_AUDIO_PLAYER_VERSION", color = Color.White, fontWeight = FontWeight.ExtraBold)
                Text(SONUS_AUDIO_FORMATS.joinToString(" • "), color=Color.White.copy(alpha=.65f), fontSize=9.sp)
                Spacer(Modifier.height(5.dp))
                Text("Player de Vídeo • v$SONUS_VIDEO_PLAYER_VERSION", color = Color.White, fontWeight = FontWeight.ExtraBold)
                Text(SONUS_VIDEO_FORMATS.joinToString(" • "), color=Color.White.copy(alpha=.65f), fontSize=9.sp)
                Text("* Compatibilidade final depende do codec/decoder disponível no aparelho e no Media3.", color=Color.White.copy(alpha=.45f), fontSize=8.sp)
            }
        }
    }
}


@Composable
private fun VideoEqCurvePreview(curve: List<Float>, accent: Color) {
    androidx.compose.foundation.Canvas(Modifier.fillMaxWidth().height(72.dp)) {
        if (curve.isEmpty()) return@Canvas
        val zero = size.height / 2f
        val points = curve.mapIndexed { index, value ->
            androidx.compose.ui.geometry.Offset(
                x = if (curve.size == 1) size.width / 2f else size.width * index / (curve.size - 1).toFloat(),
                y = zero - value.coerceIn(-1f,1f) * size.height * .38f
            )
        }
        drawLine(Color.White.copy(alpha=.10f), androidx.compose.ui.geometry.Offset(0f,zero), androidx.compose.ui.geometry.Offset(size.width,zero), 1.dp.toPx())
        val path = androidx.compose.ui.graphics.Path().apply {
            moveTo(points.first().x, points.first().y)
            points.drop(1).forEach { lineTo(it.x,it.y) }
        }
        drawPath(path, accent, style=androidx.compose.ui.graphics.drawscope.Stroke(3.dp.toPx(), cap=androidx.compose.ui.graphics.StrokeCap.Round))
        points.forEach { drawCircle(accent, 4.dp.toPx(), it) }
    }
}

@Composable
private fun VideoSettingCard(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, content: @Composable ColumnScope.() -> Unit) {
    Surface(shape=RoundedCornerShape(18.dp), color=Color.White.copy(alpha=.05f), border=BorderStroke(1.dp,Color.White.copy(alpha=.08f)), modifier=Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment=Alignment.CenterVertically) { Icon(icon,null,tint=Color(0xFF69D7FF));Spacer(Modifier.width(8.dp));Text(title,color=Color.White,fontWeight=FontWeight.ExtraBold) }
            content()
        }
    }
}

@Composable
private fun VideoSettingsSwitch(title: String, subtitle: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(title,color=Color.White,fontWeight=FontWeight.SemiBold,fontSize=11.sp);Text(subtitle,color=Color.White.copy(alpha=.52f),fontSize=8.5.sp) }
        Switch(checked=checked,onCheckedChange=onChecked)
    }
}
