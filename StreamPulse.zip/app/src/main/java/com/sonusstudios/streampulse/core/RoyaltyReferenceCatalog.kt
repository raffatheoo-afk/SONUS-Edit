package com.sonusstudios.streampulse.core

/**
 * Referências de planejamento para royalties de master/áudio DSP.
 * Os valores são médias observadas da pesquisa comparativa enviada ao projeto,
 * não tarifas contratuais por reprodução. Taxas fixas, impostos, câmbio, splits,
 * publishing, UGC e custos de saque ficam fora deste RPM de referência.
 */
data class RoyaltyScenario(
    val id: String,
    val distributor: DistributorId,
    val label: String,
    val artistShare: Double,
    val referenceRpmBrl: Double,
    val confidence: String,
    val notes: String,
    val fixedFeeNote: String? = null
)

object RoyaltyReferenceCatalog {
    const val MIX_GLOBAL_RPM_BRL = 17.812471908000003
    const val SPOTIFY_RPM_BRL = 15.6707964
    const val APPLE_MUSIC_RPM_BRL = 32.39
    const val AMAZON_MUSIC_RPM_BRL = 45.97
    const val YOUTUBE_RPM_BRL = 25.07
    const val TIDAL_RPM_BRL = 35.52

    val platformReferences: Map<String, Double> = linkedMapOf(
        "Spotify" to SPOTIFY_RPM_BRL,
        "Apple Music" to APPLE_MUSIC_RPM_BRL,
        "Amazon Music" to AMAZON_MUSIC_RPM_BRL,
        "YouTube" to YOUTUBE_RPM_BRL,
        "TIDAL" to TIDAL_RPM_BRL,
        "Mix global de DSPs" to MIX_GLOBAL_RPM_BRL
    )

    val scenarios: List<RoyaltyScenario> = listOf(
        RoyaltyScenario(
            "soundon_lite", DistributorId.SOUNDON, "Lite", .90, 16.0312247172,
            "Alta", "Artista mantém 90% dos royalties de streaming.",
            "Custo variável conforme ganhos; condições podem variar por produto."
        ),
        RoyaltyScenario(
            "soundon_core", DistributorId.SOUNDON, "Core", 1.0, MIX_GLOBAL_RPM_BRL,
            "Alta", "Referência de 100% dos royalties de streaming.",
            "Preço do plano não consolidado na pesquisa."
        ),
        RoyaltyScenario(
            "ditto_standard", DistributorId.DITTO, "Distribuição padrão", 1.0, MIX_GLOBAL_RPM_BRL,
            "Alta", "Referência de 100% dos royalties de distribuição.",
            "Taxa anual separada; preço não consolidado na pesquisa."
        ),
        RoyaltyScenario(
            "distrokid_standard", DistributorId.DISTROKID, "Distribuição padrão", 1.0, MIX_GLOBAL_RPM_BRL,
            "Alta", "Referência de 100% dos ganhos de distribuição.",
            "Assinatura anual publicada separadamente."
        ),
        RoyaltyScenario(
            "tunecore_audio", DistributorId.TUNECORE, "Áudio DSP", 1.0, MIX_GLOBAL_RPM_BRL,
            "Alta", "Referência para áudio DSP padrão; receitas sociais/UGC seguem regras diferentes.",
            "Planos podem cobrar assinatura anual."
        ),
        RoyaltyScenario(
            "freshtunes_audio", DistributorId.FRESHTUNES, "Áudio DSP", 1.0, MIX_GLOBAL_RPM_BRL,
            "Média", "100% usado como estimativa para áudio DSP; a pesquisa não encontrou comissão explícita de áudio na mesma clareza dos serviços UGC.",
            "FreshTunes Pro possui taxa anual; outros serviços podem ter comissão."
        ),
        RoyaltyScenario(
            "routenote_free", DistributorId.ROUTENOTE, "Free", .85, 15.1406011218,
            "Alta", "Artista mantém 85%.", "Sem taxa de distribuição no plano Free."
        ),
        RoyaltyScenario(
            "routenote_premium", DistributorId.ROUTENOTE, "Premium", 1.0, MIX_GLOBAL_RPM_BRL,
            "Alta", "Artista mantém 100%.", "Taxa Premium varia conforme lançamento/configuração."
        ),
        RoyaltyScenario(
            "cdbaby_standard", DistributorId.CDBABY, "Distribuição digital", .91, 16.20934943628,
            "Alta", "CD Baby retém 9% da receita de distribuição digital.",
            "Taxa única por lançamento separada."
        ),
        RoyaltyScenario(
            "onerpm_public", DistributorId.ONERPM, "Página pública", .85, 15.1406011218,
            "Contrato necessário", "Página pública consultada indica 85% ao artista.",
            "Há fonte oficial conflitante; confirme o contrato do artista."
        ),
        RoyaltyScenario(
            "onerpm_masters", DistributorId.ONERPM, "Acordo de masters", .80, 14.2499775264,
            "Contrato necessário", "Acordo legal consultado indica 80% de Net Receipts da distribuição digital de masters.",
            "Condições podem variar por contrato/produto."
        ),
        RoyaltyScenario(
            "unitedmasters_debut", DistributorId.UNITEDMASTERS, "DEBUT+", 1.0, MIX_GLOBAL_RPM_BRL,
            "Alta", "Referência de 100% dos royalties de streaming.", "US$19,99/ano na pesquisa de referência."
        ),
        RoyaltyScenario(
            "unitedmasters_select", DistributorId.UNITEDMASTERS, "SELECT", 1.0, MIX_GLOBAL_RPM_BRL,
            "Alta", "Referência de 100% dos royalties de streaming.", "US$59,99/ano na pesquisa de referência."
        ),
        RoyaltyScenario(
            "amuse_active", DistributorId.AMUSE, "Assinatura ativa", 1.0, MIX_GLOBAL_RPM_BRL,
            "Alta", "Referência de 100% dos royalties de áudio enquanto a assinatura aplicável está ativa.",
            "Planos anuais separados; serviços como Content ID podem seguir outra regra."
        ),
        RoyaltyScenario(
            "amuse_post_cancel", DistributorId.AMUSE, "Pós-cancelamento", .75, 13.359353931,
            "Alta", "Catálogo mantido após cancelamento: referência de 75% ao artista.",
            "Comissão de 25% sobre royalties futuros neste cenário."
        ),
        RoyaltyScenario(
            "landr_active", DistributorId.LANDR, "Assinatura ativa", 1.0, MIX_GLOBAL_RPM_BRL,
            "Alta", "Referência de 100% durante assinatura ativa.", "Preço de assinatura não consolidado na pesquisa."
        ),
        RoyaltyScenario(
            "landr_post_cancel", DistributorId.LANDR, "Pós-cancelamento", .85, 15.1406011218,
            "Alta", "Catálogo mantido após cancelamento: referência de 85% ao artista.",
            "Comissão de 15% sobre royalties futuros neste cenário."
        ),
        RoyaltyScenario(
            "symphonic_starter", DistributorId.SYMPHONIC, "Starter — áudio DSP", 1.0, MIX_GLOBAL_RPM_BRL,
            "Alta", "Referência de 100% em DSPs de streaming no Starter.",
            "UGC e serviços adicionais podem ter percentuais próprios."
        ),
        RoyaltyScenario(
            "toolost_standard", DistributorId.TOOLOST, "Distribuição padrão", 1.0, MIX_GLOBAL_RPM_BRL,
            "Alta", "Referência de 100% dos royalties de vendas e streams.",
            "Termos comerciais e serviços auxiliares ficam separados."
        )
    )

    fun scenariosFor(distributor: DistributorId): List<RoyaltyScenario> =
        scenarios.filter { it.distributor == distributor }

    fun defaultScenario(distributor: DistributorId): RoyaltyScenario? = when (distributor) {
        DistributorId.SOUNDON -> scenarios.firstOrNull { it.id == "soundon_core" }
        DistributorId.ROUTENOTE -> scenarios.firstOrNull { it.id == "routenote_free" }
        DistributorId.ONERPM -> scenarios.firstOrNull { it.id == "onerpm_public" }
        DistributorId.UNITEDMASTERS -> scenarios.firstOrNull { it.id == "unitedmasters_debut" }
        DistributorId.AMUSE -> scenarios.firstOrNull { it.id == "amuse_active" }
        DistributorId.LANDR -> scenarios.firstOrNull { it.id == "landr_active" }
        else -> scenariosFor(distributor).firstOrNull()
    }

    fun resolve(distributor: DistributorId, scenarioId: String?): RoyaltyScenario? =
        scenarios.firstOrNull { it.distributor == distributor && it.id == scenarioId }
            ?: defaultScenario(distributor)

    fun displayScenario(distributor: DistributorId, scenarioId: String?): String? =
        resolve(distributor, scenarioId)?.label

    fun referenceRpm(artist: Artist): Double =
        resolve(artist.distributor, artist.royaltyScenarioId)?.referenceRpmBrl
            ?: MIX_GLOBAL_RPM_BRL

    fun referenceConfidence(artist: Artist): String = when (artist.distributor) {
        DistributorId.OTHER -> "Genérica"
        else -> resolve(artist.distributor, artist.royaltyScenarioId)?.confidence ?: "Genérica"
    }
}
