package com.sonusstudios.streampulse.tools

import android.content.Context
import com.sonusstudios.streampulse.core.MembershipTier
import java.time.LocalDate
import java.time.YearMonth

/** Limites de tempo de live por plano (0.0.1). Valores em segundos. */
internal data class SonusLiveLimits(val dailySeconds: Long, val monthlySeconds: Long, val unlimited: Boolean = false)

internal data class SonusLiveUsageSnapshot(
    val usedTodaySeconds: Long,
    val usedMonthSeconds: Long,
    val totalSeconds: Long,
    val totalBytes: Long,
    val sessions: Int,
    val lastSessionSeconds: Long,
    val lastSessionBytes: Long
)

/**
 * Contabilidade privada das lives. O consumo só começa em "Iniciar live" e termina em "Encerrar live".
 * Os contadores diário e mensal reiniciam sozinhos na virada do dia/mês (horário do aparelho).
 */
internal object SonusLiveUsage {
    private const val PREFS = "sonus_live_usage_v1"
    private const val H = 3600L

    fun limitsFor(tier: MembershipTier, ownerUnlimited: Boolean): SonusLiveLimits = when {
        ownerUnlimited -> SonusLiveLimits(Long.MAX_VALUE / 4, Long.MAX_VALUE / 4, unlimited = true)
        tier == MembershipTier.PRATA -> SonusLiveLimits(4 * H, 100 * H)
        tier == MembershipTier.OURO -> SonusLiveLimits(6 * H, 180 * H)
        tier == MembershipTier.DIAMANTE -> SonusLiveLimits(12 * H, 360 * H)
        // FREE e BRONZE: 1 h por dia e 20 h por mês (o Bronze não foi definido na tabela da live).
        else -> SonusLiveLimits(1 * H, 20 * H)
    }

    private fun prefs(context: Context) = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun rollover(context: Context) {
        val p = prefs(context)
        val day = LocalDate.now().toString()
        val month = YearMonth.now().toString()
        val e = p.edit()
        if (p.getString("day", "") != day) { e.putString("day", day).putLong("today_s", 0L) }
        if (p.getString("month", "") != month) { e.putString("month", month).putLong("month_s", 0L) }
        e.apply()
    }

    fun snapshot(context: Context): SonusLiveUsageSnapshot {
        rollover(context)
        val p = prefs(context)
        return SonusLiveUsageSnapshot(
            usedTodaySeconds = p.getLong("today_s", 0L),
            usedMonthSeconds = p.getLong("month_s", 0L),
            totalSeconds = p.getLong("total_s", 0L),
            totalBytes = p.getLong("total_b", 0L),
            sessions = p.getInt("sessions", 0),
            lastSessionSeconds = p.getLong("last_s", 0L),
            lastSessionBytes = p.getLong("last_b", 0L)
        )
    }

    fun remainingSeconds(context: Context, limits: SonusLiveLimits): Long {
        if (limits.unlimited) return Long.MAX_VALUE / 4
        val s = snapshot(context)
        return minOf(limits.dailySeconds - s.usedTodaySeconds, limits.monthlySeconds - s.usedMonthSeconds).coerceAtLeast(0L)
    }

    fun addSeconds(context: Context, seconds: Long) {
        if (seconds <= 0L) return
        rollover(context)
        val p = prefs(context)
        p.edit()
            .putLong("today_s", p.getLong("today_s", 0L) + seconds)
            .putLong("month_s", p.getLong("month_s", 0L) + seconds)
            .putLong("total_s", p.getLong("total_s", 0L) + seconds)
            .apply()
    }

    fun finishSession(context: Context, seconds: Long, bytes: Long) {
        val p = prefs(context)
        p.edit()
            .putInt("sessions", p.getInt("sessions", 0) + 1)
            .putLong("total_b", p.getLong("total_b", 0L) + bytes.coerceAtLeast(0L))
            .putLong("last_s", seconds)
            .putLong("last_b", bytes.coerceAtLeast(0L))
            .apply()
    }

    fun tutorialSeen(context: Context): Boolean = prefs(context).getBoolean("tutorial_seen", false)
    fun setTutorialSeen(context: Context) { prefs(context).edit().putBoolean("tutorial_seen", true).apply() }

    fun formatDuration(seconds: Long): String {
        val s = seconds.coerceAtLeast(0L)
        val h = s / 3600; val m = (s % 3600) / 60
        return if (h > 0) "${h}h ${"%02d".format(m)}min" else "${m}min"
    }

    fun formatBytes(bytes: Long): String {
        val b = bytes.coerceAtLeast(0L).toDouble()
        return when {
            b >= 1024.0 * 1024 * 1024 -> "%.2f GB".format(b / (1024.0 * 1024 * 1024))
            b >= 1024.0 * 1024 -> "%.1f MB".format(b / (1024.0 * 1024))
            else -> "%.0f KB".format(b / 1024.0)
        }
    }
}
