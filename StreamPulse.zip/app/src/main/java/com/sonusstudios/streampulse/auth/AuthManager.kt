package com.sonusstudios.streampulse.auth

import android.content.Context
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialException
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.gms.tasks.Task
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.sonusstudios.streampulse.R
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

enum class AccountRole {
    USER,
    SUPPORT,
    OWNER
}

data class AuthUser(
    val uid: String,
    val displayName: String?,
    val email: String?,
    val photoUrl: String?,
    val role: AccountRole = AccountRole.USER
)

data class AuthState(
    val ready: Boolean = false,
    val user: AuthUser? = null
)

/**
 * Camada central de autenticação e autorização do StreamPulse.
 *
 * O papel OWNER nunca é decidido por e-mail, senha mestra ou segredo gravado no APK.
 * Depois do login, o app observa apenas /roles/<uid> no Realtime Database. As regras
 * do Firebase permitem que cada conta leia somente o próprio papel e impedem escrita
 * por clientes, mantendo a concessão/revogação sob controle administrativo.
 */
class AuthManager(context: Context) {
    private val auth = FirebaseAuth.getInstance()
    private val database = FirebaseDatabase.getInstance()
    private val _state = MutableStateFlow(AuthState())
    val state: StateFlow<AuthState> = _state.asStateFlow()

    private var roleReference: DatabaseReference? = null
    private var roleListener: ValueEventListener? = null
    private var watchedUid: String? = null

    private val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
        val current = firebaseAuth.currentUser
        if (current?.isAnonymous == true) {
            // Versões anteriores usavam autenticação anônima somente para presença.
            // Ao migrar para contas reais, descartamos essa sessão técnica sem tocar
            // nos dados locais do usuário.
            detachRoleListener()
            firebaseAuth.signOut()
            publish(null)
        } else if (current == null) {
            detachRoleListener()
            publish(null)
        } else {
            // Preserva um papel já confirmado para o mesmo UID caso o listener de
            // autenticação seja disparado novamente durante a sessão.
            val knownRole = _state.value.user?.takeIf { it.uid == current.uid }?.role ?: AccountRole.USER
            publish(current, knownRole)
            watchRemoteRole(current)
        }
    }

    init {
        val current = auth.currentUser
        if (current?.isAnonymous == true) {
            auth.signOut()
            publish(null)
        } else if (current != null) {
            val knownRole = _state.value.user?.takeIf { it.uid == current.uid }?.role ?: AccountRole.USER
            publish(current, knownRole)
            watchRemoteRole(current)
        } else {
            publish(null)
        }
        auth.addAuthStateListener(listener)
    }

    suspend fun signInWithEmail(email: String, password: String): Result<Unit> = runCatching {
        val cleanEmail = email.trim()
        require(cleanEmail.isNotBlank()) { "Informe seu e-mail." }
        require(password.isNotBlank()) { "Informe sua senha." }
        auth.signInWithEmailAndPassword(cleanEmail, password).awaitCompletion()
    }.mapFailureToFriendlyAuthError()

    suspend fun createAccount(email: String, password: String): Result<Unit> = runCatching {
        val cleanEmail = email.trim()
        require(cleanEmail.isNotBlank()) { "Informe seu e-mail." }
        require(password.length >= 6) { "A senha precisa ter pelo menos 6 caracteres." }
        auth.createUserWithEmailAndPassword(cleanEmail, password).awaitCompletion()
    }.mapFailureToFriendlyAuthError()

    suspend fun sendPasswordReset(email: String): Result<Unit> = runCatching {
        val cleanEmail = email.trim()
        require(cleanEmail.isNotBlank()) { "Informe o e-mail da sua conta." }
        auth.sendPasswordResetEmail(cleanEmail).awaitCompletion()
    }.mapFailureToFriendlyAuthError()

    suspend fun signInWithGoogle(context: Context): Result<Unit> {
        return try {
            val credentialManager = CredentialManager.create(context)
            val googleIdOption = GetGoogleIdOption.Builder()
                .setFilterByAuthorizedAccounts(false)
                .setServerClientId(context.getString(R.string.default_web_client_id))
                .setAutoSelectEnabled(false)
                .build()
            val request = GetCredentialRequest.Builder()
                .addCredentialOption(googleIdOption)
                .build()

            val response = credentialManager.getCredential(context = context, request = request)
            val credential = response.credential
            if (credential !is CustomCredential || credential.type != GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                return Result.failure<Unit>(IllegalStateException("O Google não retornou uma credencial compatível."))
                    .mapFailureToFriendlyAuthError()
            }

            val googleCredential = GoogleIdTokenCredential.createFrom(credential.data)
            val firebaseCredential = GoogleAuthProvider.getCredential(googleCredential.idToken, null)
            auth.signInWithCredential(firebaseCredential).awaitCompletion()
            Result.success(Unit)
        } catch (e: GetCredentialException) {
            val cancelled = e::class.java.simpleName.contains("Cancel", ignoreCase = true)
            Result.failure<Unit>(
                IllegalStateException(
                    if (cancelled) "Login com Google cancelado."
                    else "Não foi possível concluir o login com Google. Tente novamente.",
                    e
                )
            )
        } catch (t: Throwable) {
            Result.failure<Unit>(t).mapFailureToFriendlyAuthError()
        }
    }

    fun currentAccountUsesPassword(): Boolean = auth.currentUser?.providerData?.any { it.providerId == EmailAuthProvider.PROVIDER_ID } == true

    suspend fun reauthenticate(context: Context, password: String? = null): Result<Unit> = runCatching {
        val user = auth.currentUser ?: error("Sua sessão expirou. Entre novamente.")
        if (currentAccountUsesPassword()) {
            val email = user.email ?: error("Não foi possível identificar o e-mail da conta.")
            require(!password.isNullOrBlank()) { "Digite sua senha para confirmar a exclusão." }
            user.reauthenticate(EmailAuthProvider.getCredential(email, password)).awaitCompletion()
        } else {
            val credentialManager = CredentialManager.create(context)
            val googleIdOption = GetGoogleIdOption.Builder()
                .setFilterByAuthorizedAccounts(false)
                .setServerClientId(context.getString(R.string.default_web_client_id))
                .setAutoSelectEnabled(false)
                .build()
            val request = GetCredentialRequest.Builder().addCredentialOption(googleIdOption).build()
            val response = credentialManager.getCredential(context = context, request = request)
            val credential = response.credential
            require(credential is CustomCredential && credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                "Confirmação com Google não concluída."
            }
            val googleCredential = GoogleIdTokenCredential.createFrom(credential.data)
            user.reauthenticate(GoogleAuthProvider.getCredential(googleCredential.idToken, null)).awaitCompletion()
        }
    }.mapFailureToFriendlyAuthError()

    suspend fun deleteAccountAfterReauth(context: Context): Result<Unit> = runCatching {
        val user = auth.currentUser ?: error("Sua sessão expirou. Entre novamente.")
        detachRoleListener()
        user.delete().awaitCompletion()
        // A falha ao limpar o estado local de credenciais não deve transformar
        // uma exclusão Firebase já concluída em falha. Mantém o bloco externo
        // com retorno Unit para que o Result seja Result<Unit>.
        runCatching { CredentialManager.create(context).clearCredentialState(ClearCredentialStateRequest()) }
        Unit
    }.mapFailureToFriendlyAuthError()

    suspend fun deleteAccount(context: Context, password: String? = null): Result<Unit> {
        val reauth = reauthenticate(context, password)
        if (reauth.isFailure) return reauth
        return deleteAccountAfterReauth(context)
    }

    suspend fun signOut(context: Context) {
        detachRoleListener()
        auth.signOut()
        runCatching {
            CredentialManager.create(context).clearCredentialState(ClearCredentialStateRequest())
        }
    }

    /** Força uma nova leitura do papel sem exigir novo login. */
    fun refreshRole() {
        val current = auth.currentUser?.takeUnless { it.isAnonymous } ?: return
        val knownRole = _state.value.user?.takeIf { it.uid == current.uid }?.role ?: AccountRole.USER
        detachRoleListener()
        publish(current, knownRole)
        watchRemoteRole(current)
    }

    private fun watchRemoteRole(user: FirebaseUser) {
        if (watchedUid == user.uid && roleListener != null) return
        detachRoleListener()

        val reference = database.getReference("roles").child(user.uid)
        val remoteListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (auth.currentUser?.uid != user.uid) return
                val active = snapshot.child("active").getValue(Boolean::class.java) == true
                val roleName = snapshot.child("role").getValue(String::class.java)?.trim()?.uppercase()
                val role = if (!active) AccountRole.USER else when (roleName) {
                    AccountRole.OWNER.name -> AccountRole.OWNER
                    AccountRole.SUPPORT.name -> AccountRole.SUPPORT
                    else -> AccountRole.USER
                }
                publish(auth.currentUser, role)
            }

            override fun onCancelled(error: DatabaseError) {
                // Falha fechada: sem confirmação remota, a conta permanece USER.
                if (auth.currentUser?.uid == user.uid) publish(auth.currentUser, AccountRole.USER)
            }
        }

        watchedUid = user.uid
        roleReference = reference
        roleListener = remoteListener
        reference.addValueEventListener(remoteListener)
    }

    private fun detachRoleListener() {
        val reference = roleReference
        val listener = roleListener
        if (reference != null && listener != null) reference.removeEventListener(listener)
        roleReference = null
        roleListener = null
        watchedUid = null
    }

    private fun publish(user: FirebaseUser?, role: AccountRole = AccountRole.USER) {
        _state.value = AuthState(
            ready = true,
            user = user?.let {
                AuthUser(
                    uid = it.uid,
                    displayName = it.displayName,
                    email = it.email,
                    photoUrl = it.photoUrl?.toString(),
                    role = role
                )
            }
        )
    }

    private suspend fun Task<*>.awaitCompletion() {
        suspendCancellableCoroutine<Unit> { continuation ->
            addOnCompleteListener { task ->
                if (!continuation.isActive) return@addOnCompleteListener
                if (task.isSuccessful) continuation.resume(Unit)
                else continuation.resumeWithException(task.exception ?: IllegalStateException("Falha de autenticação."))
            }
        }
    }

    private fun Result<Unit>.mapFailureToFriendlyAuthError(): Result<Unit> {
        val error = exceptionOrNull() ?: return this
        if (error is IllegalArgumentException && !error.message.isNullOrBlank()) return this

        val message = when (error) {
            is FirebaseAuthException -> when (error.errorCode) {
                "ERROR_INVALID_EMAIL" -> "Digite um e-mail válido."
                "ERROR_EMAIL_ALREADY_IN_USE" -> "Este e-mail já possui uma conta no SONUS."
                "ERROR_WEAK_PASSWORD" -> "Escolha uma senha mais forte, com pelo menos 6 caracteres."
                "ERROR_USER_DISABLED" -> "Esta conta está temporariamente desativada."
                "ERROR_TOO_MANY_REQUESTS" -> "Muitas tentativas em pouco tempo. Aguarde um pouco e tente novamente."
                "ERROR_NETWORK_REQUEST_FAILED" -> "Sem conexão com a internet. Verifique sua rede e tente novamente."
                "ERROR_INVALID_CREDENTIAL", "ERROR_WRONG_PASSWORD", "ERROR_USER_NOT_FOUND" -> "E-mail ou senha incorretos."
                else -> "Não foi possível autenticar sua conta agora. Tente novamente."
            }
            else -> when {
                error.message?.contains("network", ignoreCase = true) == true -> "Sem conexão com a internet. Verifique sua rede e tente novamente."
                !error.message.isNullOrBlank() -> error.message!!
                else -> "Não foi possível autenticar sua conta agora. Tente novamente."
            }
        }
        return Result.failure<Unit>(IllegalStateException(message, error))
    }
}
