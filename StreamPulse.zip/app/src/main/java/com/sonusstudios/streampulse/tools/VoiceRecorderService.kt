package com.sonusstudios.streampulse.tools

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioManager
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.sonusstudios.streampulse.MainActivity
import com.sonusstudios.streampulse.R
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.abs
import kotlin.math.max


data class RecorderSnapshot(
    val recording: Boolean = false,
    val paused: Boolean = false,
    val durationMs: Long = 0L,
    val bytesWritten: Long = 0L,
    val amplitude: Float = 0f,
    val averageAmplitude: Float = 0f,
    val voicedRatio: Float = 0f,
    val pitchHz: Float = 0f,
    val pitchStability: Float = 0f,
    val sampleRate: Int = 48000,
    val channels: Int = 1,
    val bitDepth: Int = 16,
    val inputName: String? = null,
    val outputPath: String? = null,
    val warning: String? = null,
    val error: String? = null
)

object RecorderBus {
    private val _state = MutableStateFlow(RecorderSnapshot())
    val state: StateFlow<RecorderSnapshot> = _state.asStateFlow()
    internal fun publish(value: RecorderSnapshot) { _state.value = value }
}

class VoiceRecorderService : Service() {
    private var audioRecord: AudioRecord? = null
    private var worker: Thread? = null
    private val running = AtomicBoolean(false)
    private val paused = AtomicBoolean(false)
    private var file: File? = null
    private var sampleRate = 48000
    private var channels = 1
    private var bitDepth = 16
    private var encoding = AudioFormat.ENCODING_PCM_16BIT
    private var bytesPerSample = 2
    private var dataBytes = 0L
    private var lastNotificationSecond = -1L
    private var skipSilence = false
    private var preferredDeviceId = -1
    private var totalChunks = 0L
    private var voicedChunks = 0L
    private var amplitudeSum = 0.0
    private var pitchCount = 0L
    private var pitchSum = 0.0
    private var pitchSqSum = 0.0
    private var noiseSuppressor: NoiseSuppressor? = null
    private var echoCanceler: AcousticEchoCanceler? = null
    private var autoGain: AutomaticGainControl? = null
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startRecording(
                requestedSampleRate = intent.getIntExtra(EXTRA_SAMPLE_RATE, 48000),
                requestedChannels = intent.getIntExtra(EXTRA_CHANNELS, 1),
                requestedBitDepth = intent.getIntExtra(EXTRA_BIT_DEPTH, 16),
                mode = intent.getStringExtra(EXTRA_MODE).orEmpty(),
                preferredDevice = intent.getIntExtra(EXTRA_DEVICE_ID, -1),
                skipSilentChunks = intent.getBooleanExtra(EXTRA_SKIP_SILENCE, false)
            )
            ACTION_PAUSE -> pauseRecording()
            ACTION_RESUME -> resumeRecording()
            ACTION_STOP -> stopRecording()
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        if (running.get()) stopRecording()
        super.onDestroy()
    }

    @SuppressLint("MissingPermission")
    private fun startRecording(
        requestedSampleRate: Int,
        requestedChannels: Int,
        requestedBitDepth: Int,
        mode: String,
        preferredDevice: Int,
        skipSilentChunks: Boolean
    ) {
        if (running.get()) return
        preferredDeviceId = preferredDevice
        skipSilence = skipSilentChunks
        totalChunks = 0L
        voicedChunks = 0L
        amplitudeSum = 0.0
        pitchCount = 0L
        pitchSum = 0.0
        pitchSqSum = 0.0
        dataBytes = 0L
        lastNotificationSecond = -1L

        val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val preferredInput = audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS).firstOrNull { it.id == preferredDeviceId }
        val requestedRate = requestedSampleRate.takeIf { it in SUPPORTED_RATES } ?: 48000
        val safeRequestedChannels = when (requestedChannels) {
            1, 2, 6, 8 -> requestedChannels
            else -> 1
        }
        val safeRequestedDepth = when {
            requestedBitDepth == 24 && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> 24
            requestedBitDepth == 32 -> 32
            else -> 16
        }

        val channelCandidates = buildList {
            add(safeRequestedChannels)
            if (safeRequestedChannels > 2) add(2)
            if (safeRequestedChannels != 1) add(1)
        }.distinct()
        val rateCandidates = listOf(requestedRate, 48000, 44100).distinct()
        val depthCandidates = buildList {
            add(safeRequestedDepth)
            if (safeRequestedDepth != 16) add(16)
        }.distinct()
        val preferredSource = when (mode.uppercase()) {
            "VOICE", "PODCAST", "INTERVIEW", "MEETING" -> MediaRecorder.AudioSource.VOICE_RECOGNITION
            else -> MediaRecorder.AudioSource.MIC
        }
        val sourceCandidates = listOf(preferredSource, MediaRecorder.AudioSource.MIC).distinct()

        var warning: String? = null
        var recorder: AudioRecord? = null
        var selectedSource = preferredSource
        outer@ for (source in sourceCandidates) {
          for (depth in depthCandidates) {
            val enc = encodingForBitDepth(depth) ?: continue
            for (rate in rateCandidates) {
                for (channelCount in channelCandidates) {
                    if (channelCount > 2 && preferredInput == null) continue
                    if (channelCount > 2 && preferredInput?.channelCounts?.none { it >= channelCount } != false) continue
                    val built = runCatching { createRecorder(source, rate, channelCount, depth, enc) }.getOrNull() ?: continue
                    if (built.state == AudioRecord.STATE_INITIALIZED) {
                        recorder = built
                        sampleRate = rate
                        channels = channelCount
                        bitDepth = depth
                        encoding = enc
                        bytesPerSample = bytesPerSampleForDepth(depth)
                        selectedSource = source
                        break@outer
                    } else {
                        built.release()
                    }
                }
            }
          }
        }
        val activeRecorder = recorder ?: run {
            RecorderBus.publish(RecorderSnapshot(error = "Este aparelho não forneceu uma configuração de gravação compatível."))
            stopSelf(); return
        }
        if (sampleRate != requestedRate || channels != safeRequestedChannels || bitDepth != safeRequestedDepth) {
            warning = "O hardware ajustou a captura para ${sampleRate / 1000.0} kHz • ${channelLabel(channels)} • ${bitDepth}-bit."
        }
        if (preferredInput != null) runCatching { activeRecorder.setPreferredDevice(preferredInput) }

        if (mode.uppercase() in setOf("VOICE", "PODCAST", "INTERVIEW", "MEETING")) {
            runCatching { if (NoiseSuppressor.isAvailable()) noiseSuppressor = NoiseSuppressor.create(activeRecorder.audioSessionId)?.apply { enabled = true } }
            runCatching { if (AcousticEchoCanceler.isAvailable()) echoCanceler = AcousticEchoCanceler.create(activeRecorder.audioSessionId)?.apply { enabled = true } }
            runCatching { if (AutomaticGainControl.isAvailable()) autoGain = AutomaticGainControl.create(activeRecorder.audioSessionId)?.apply { enabled = true } }
        }

        val inputName = preferredInput?.productName?.toString()?.takeIf { it.isNotBlank() }
        val dir = File(filesDir, "recordings").apply { mkdirs() }
        val stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"))
        val output = File(dir, "SONUS_$stamp.wav")
        RandomAccessFile(output, "rw").use { raf ->
            raf.setLength(0); raf.write(ByteArray(44))
        }
        file = output
        audioRecord = activeRecorder
        running.set(true); paused.set(false)
        val power = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SONUS:VoiceRecorder").apply {
            setReferenceCounted(false)
            acquire(12 * 60 * 60 * 1000L)
        }
        startForeground(NOTIFICATION_ID, notification("Preparando microfone…"))
        val startError = runCatching { activeRecorder.startRecording() }.exceptionOrNull()
        val actuallyRecording = startError == null && activeRecorder.recordingState == AudioRecord.RECORDSTATE_RECORDING
        if (!actuallyRecording) {
            running.set(false)
            runCatching { activeRecorder.stop() }; activeRecorder.release()
            runCatching { output.delete() }
            runCatching { wakeLock?.takeIf { it.isHeld }?.release() }; wakeLock = null
            RecorderBus.publish(RecorderSnapshot(error = startError?.message ?: "O microfone não iniciou a captura. Verifique a permissão ou se outro app está usando o microfone."))
            stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return
        }
        if (selectedSource != preferredSource) warning = listOfNotNull(warning, "O SONUS usou o microfone padrão para garantir compatibilidade.").joinToString(" ")
        RecorderBus.publish(
            RecorderSnapshot(
                recording = true,
                sampleRate = sampleRate,
                channels = channels,
                bitDepth = bitDepth,
                inputName = inputName,
                outputPath = output.absolutePath,
                warning = warning
            )
        )

        val frameBytes = (channels * bytesPerSample).coerceAtLeast(1)
        val targetBufferBytes = max(frameBytes * 1024, sampleRate * frameBytes / 10).coerceAtLeast(4096)
        worker = Thread {
            val directBuffer = ByteBuffer.allocateDirect(targetBufferBytes).order(ByteOrder.LITTLE_ENDIAN)
            val transfer = ByteArray(targetBufferBytes)
            try {
                RandomAccessFile(output, "rw").use { raf ->
                    raf.seek(44)
                    while (running.get()) {
                        if (paused.get()) {
                            Thread.sleep(45); continue
                        }
                        directBuffer.clear()
                        val read = activeRecorder.read(directBuffer, targetBufferBytes, AudioRecord.READ_BLOCKING)
                        if (read <= 0) {
                            if (read == AudioRecord.ERROR_DEAD_OBJECT || read == AudioRecord.ERROR_INVALID_OPERATION || read == AudioRecord.ERROR_BAD_VALUE) {
                                RecorderBus.publish(RecorderBus.state.value.copy(error = "A captura do microfone foi interrompida pelo sistema."))
                                running.set(false); break
                            }
                            Thread.sleep(12); continue
                        }
                        // AudioRecord.read(ByteBuffer) pode escrever sem avançar position em alguns
                        // drivers. flip() então produz limit=0 e mata silenciosamente o worker.
                        // Posicionamos explicitamente o intervalo realmente lido.
                        directBuffer.position(0)
                        directBuffer.limit(read.coerceAtMost(directBuffer.capacity()))
                        directBuffer.get(transfer, 0, read.coerceAtMost(transfer.size))

                        var maxAmp = 0f
                        var zeroCrossings = 0
                        var previousSample = 0f
                        var frameCount = 0
                        var offset = 0
                        while (offset + bytesPerSample <= read) {
                            val normalized = decodeNormalizedSample(transfer, offset, bitDepth)
                            maxAmp = max(maxAmp, abs(normalized))
                            if (frameCount > 0 && ((previousSample < 0f && normalized >= 0f) || (previousSample >= 0f && normalized < 0f))) zeroCrossings++
                            previousSample = normalized
                            frameCount++
                            offset += frameBytes
                        }
                        val amp = maxAmp.coerceIn(0f, 1f)
                        val voiced = amp >= 0.012f
                        if (!skipSilence || voiced) {
                            raf.write(transfer, 0, read)
                            dataBytes += read
                        }
                        totalChunks++
                        if (voiced) voicedChunks++
                        amplitudeSum += amp
                        val pitch = if (frameCount > 0) (zeroCrossings * sampleRate.toDouble() / (2.0 * frameCount)) else 0.0
                        val validPitch = pitch.takeIf { voiced && it in 55.0..1200.0 }
                        if (validPitch != null) {
                            pitchCount++
                            pitchSum += validPitch
                            pitchSqSum += validPitch * validPitch
                        }
                        val avgAmp = (amplitudeSum / totalChunks.coerceAtLeast(1)).toFloat()
                        val voicedRatio = (voicedChunks.toDouble() / totalChunks.coerceAtLeast(1)).toFloat()
                        val meanPitch = if (pitchCount > 0) (pitchSum / pitchCount).toFloat() else 0f
                        val pitchVariance = if (pitchCount > 1) (pitchSqSum / pitchCount - (pitchSum / pitchCount) * (pitchSum / pitchCount)).coerceAtLeast(0.0) else 0.0
                        val pitchStability = if (meanPitch > 0f) (1f - (kotlin.math.sqrt(pitchVariance).toFloat() / meanPitch).coerceIn(0f, 1f)) else 0f
                        val byteRate = sampleRate.toLong() * channels * bytesPerSample
                        val duration = if (byteRate > 0L) dataBytes * 1000L / byteRate else 0L
                        RecorderBus.publish(
                            RecorderSnapshot(
                                recording = true,
                                paused = false,
                                durationMs = duration,
                                bytesWritten = dataBytes + 44,
                                amplitude = amp,
                                averageAmplitude = avgAmp,
                                voicedRatio = voicedRatio,
                                pitchHz = meanPitch,
                                pitchStability = pitchStability,
                                sampleRate = sampleRate,
                                channels = channels,
                                bitDepth = bitDepth,
                                inputName = inputName,
                                outputPath = output.absolutePath,
                                warning = warning
                            )
                        )
                        val sec = duration / 1000L
                        if (sec != lastNotificationSecond) {
                            lastNotificationSecond = sec
                            val mm = sec / 60; val ss = sec % 60
                            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIFICATION_ID, notification("Gravando • %02d:%02d".format(mm, ss)))
                        }
                    }
                }
            } catch (t: Throwable) {
                RecorderBus.publish(RecorderBus.state.value.copy(error = t.message ?: "A gravação foi interrompida."))
            }
        }.apply { name = "SONUSRecorder"; start() }
    }

    @SuppressLint("MissingPermission")
    private fun createRecorder(source: Int, rate: Int, channelCount: Int, depth: Int, enc: Int): AudioRecord {
        val formatBuilder = AudioFormat.Builder()
            .setEncoding(enc)
            .setSampleRate(rate)
        if (channelCount <= 2) {
            formatBuilder.setChannelMask(if (channelCount == 2) AudioFormat.CHANNEL_IN_STEREO else AudioFormat.CHANNEL_IN_MONO)
        } else {
            formatBuilder.setChannelIndexMask((1 shl channelCount) - 1)
        }
        val format = formatBuilder.build()
        val bytes = bytesPerSampleForDepth(depth)
        val bufferBytes = max(rate * channelCount * bytes / 5, channelCount * bytes * 2048).coerceAtLeast(8192)
        return AudioRecord.Builder()
            .setAudioSource(source)
            .setAudioFormat(format)
            .setBufferSizeInBytes(bufferBytes)
            .build()
    }

    private fun encodingForBitDepth(depth: Int): Int? = when (depth) {
        16 -> AudioFormat.ENCODING_PCM_16BIT
        24 -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) AudioFormat.ENCODING_PCM_24BIT_PACKED else null
        32 -> AudioFormat.ENCODING_PCM_FLOAT
        else -> null
    }

    private fun bytesPerSampleForDepth(depth: Int): Int = when (depth) { 24 -> 3; 32 -> 4; else -> 2 }

    private fun decodeNormalizedSample(data: ByteArray, offset: Int, depth: Int): Float = when (depth) {
        24 -> {
            val raw = (data[offset].toInt() and 0xff) or
                ((data[offset + 1].toInt() and 0xff) shl 8) or
                ((data[offset + 2].toInt() and 0xff) shl 16)
            val signed = if ((raw and 0x800000) != 0) raw or -0x1000000 else raw
            signed / 8388608f
        }
        32 -> ByteBuffer.wrap(data, offset, 4).order(ByteOrder.LITTLE_ENDIAN).float.takeIf { it.isFinite() } ?: 0f
        else -> {
            val raw = (data[offset].toInt() and 0xff) or (data[offset + 1].toInt() shl 8)
            raw.toShort().toInt() / 32768f
        }
    }

    private fun pauseRecording() {
        if (!running.get()) return
        paused.set(true)
        RecorderBus.publish(RecorderBus.state.value.copy(paused = true, amplitude = 0f))
    }

    private fun resumeRecording() {
        if (!running.get()) return
        paused.set(false)
        RecorderBus.publish(RecorderBus.state.value.copy(paused = false))
    }

    private fun stopRecording() {
        if (!running.getAndSet(false)) { stopSelf(); return }
        paused.set(false)
        runCatching { audioRecord?.stop() }
        runCatching { worker?.join(1500) }
        runCatching { audioRecord?.release() }
        runCatching { noiseSuppressor?.release() }; noiseSuppressor = null
        runCatching { echoCanceler?.release() }; echoCanceler = null
        runCatching { autoGain?.release() }; autoGain = null
        runCatching { wakeLock?.takeIf { it.isHeld }?.release() }; wakeLock = null
        audioRecord = null
        file?.let { finalizeWav(it, dataBytes, sampleRate, channels, bitDepth) }
        val previous = RecorderBus.state.value
        RecorderBus.publish(previous.copy(recording = false, paused = false, amplitude = 0f, bytesWritten = dataBytes + 44))
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun finalizeWav(file: File, dataLength: Long, sampleRate: Int, channels: Int, bitDepth: Int) {
        val bytesPerSample = bytesPerSampleForDepth(bitDepth)
        RandomAccessFile(file, "rw").use { raf ->
            val byteRate = sampleRate * channels * bytesPerSample
            val totalDataLen = dataLength + 36
            val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            header.put("RIFF".toByteArray())
            header.putInt(totalDataLen.coerceAtMost(Int.MAX_VALUE.toLong()).toInt())
            header.put("WAVE".toByteArray())
            header.put("fmt ".toByteArray())
            header.putInt(16)
            header.putShort((if (bitDepth == 32) 3 else 1).toShort())
            header.putShort(channels.toShort())
            header.putInt(sampleRate)
            header.putInt(byteRate)
            header.putShort((channels * bytesPerSample).toShort())
            header.putShort(bitDepth.toShort())
            header.put("data".toByteArray())
            header.putInt(dataLength.coerceAtMost(Int.MAX_VALUE.toLong()).toInt())
            raf.seek(0); raf.write(header.array())
        }
    }

    private fun channelLabel(count: Int): String = when (count) { 1 -> "mono"; 2 -> "estéreo"; 6 -> "5.1"; 8 -> "7.1"; else -> "$count canais" }

    private fun createChannel() {
        val channel = NotificationChannel(CHANNEL_ID, "Gravação de voz", NotificationManager.IMPORTANCE_LOW).apply {
            description = "Mantém a gravação ativa com a tela apagada."
            setSound(null, null)
        }
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
    }

    private fun notification(text: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this, 2, Intent(this, VoiceRecorderService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("SONUS • Gravador")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(openIntent)
            .addAction(0, "Parar", stopIntent)
            .build()
    }

    companion object {
        const val ACTION_START = "streampulse.recorder.START"
        const val ACTION_PAUSE = "streampulse.recorder.PAUSE"
        const val ACTION_RESUME = "streampulse.recorder.RESUME"
        const val ACTION_STOP = "streampulse.recorder.STOP"
        const val EXTRA_SAMPLE_RATE = "sampleRate"
        const val EXTRA_CHANNELS = "channels"
        const val EXTRA_BIT_DEPTH = "bitDepth"
        const val EXTRA_MODE = "mode"
        const val EXTRA_DEVICE_ID = "deviceId"
        const val EXTRA_SKIP_SILENCE = "skipSilence"
        private const val CHANNEL_ID = "streampulse_voice_recorder"
        private const val NOTIFICATION_ID = 7802
        private val SUPPORTED_RATES = setOf(44100, 48000, 88200, 96000, 192000)

        fun start(
            context: Context,
            sampleRate: Int,
            channels: Int,
            mode: String,
            deviceId: Int = -1,
            skipSilence: Boolean = false,
            bitDepth: Int = 16
        ) {
            val i = Intent(context, VoiceRecorderService::class.java).setAction(ACTION_START)
                .putExtra(EXTRA_SAMPLE_RATE, sampleRate)
                .putExtra(EXTRA_CHANNELS, channels)
                .putExtra(EXTRA_BIT_DEPTH, bitDepth)
                .putExtra(EXTRA_MODE, mode)
                .putExtra(EXTRA_DEVICE_ID, deviceId)
                .putExtra(EXTRA_SKIP_SILENCE, skipSilence)
            context.startForegroundService(i)
        }
        fun pause(context: Context) = context.startService(Intent(context, VoiceRecorderService::class.java).setAction(ACTION_PAUSE))
        fun resume(context: Context) = context.startService(Intent(context, VoiceRecorderService::class.java).setAction(ACTION_RESUME))
        fun stop(context: Context) = context.startService(Intent(context, VoiceRecorderService::class.java).setAction(ACTION_STOP))
    }
}
