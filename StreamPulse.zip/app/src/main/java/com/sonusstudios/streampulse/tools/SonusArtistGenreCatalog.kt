package com.sonusstudios.streampulse.tools

import android.content.Context
import java.text.Normalizer
import java.util.Locale

internal data class SonusArtistGenreProfile(
    val category: String,
    val imageKeyword: String,
    val secondaryKeywords: Set<String>,
    val confidence: String
) {
    val allKeywords: Set<String> get() = buildSet {
        if (category.isNotBlank()) add(category)
        if (imageKeyword.isNotBlank()) add(imageKeyword)
        addAll(secondaryKeywords)
    }
}

/**
 * code131: catálogo local e leve de artista -> gênero usado apenas como contexto do
 * Social Edit. O CSV é carregado uma única vez por processo e depois consultado por Map.
 */
internal object SonusArtistGenreCatalog {
    @Volatile private var cached: Map<String, SonusArtistGenreProfile>? = null

    fun find(context: Context, rawArtist: String): SonusArtistGenreProfile? {
        if (rawArtist.isBlank()) return null
        val map = cached ?: synchronized(this) {
            cached ?: load(context.applicationContext).also { cached = it }
        }
        val normalized = normalizeArtist(rawArtist)
        map[normalized]?.let { return it }

        // Colaborações costumam vir como "Artista feat. Outro" / "Artista & Outro".
        // Tenta o artista principal sem inventar um gênero quando não há correspondência.
        val primaryCandidates = listOf(
            normalized.substringBefore(" feat "),
            normalized.substringBefore(" ft "),
            normalized.substringBefore(" featuring "),
            normalized.substringBefore(" x "),
            normalized.substringBefore(" com ")
        ).map(String::trim).filter { it.isNotBlank() }.distinct()
        return primaryCandidates.firstNotNullOfOrNull(map::get)
    }

    private fun load(context: Context): Map<String, SonusArtistGenreProfile> = runCatching {
        context.assets.open("artists_genres_master.csv").bufferedReader(Charsets.UTF_8).useLines { lines ->
            val rows = lines.iterator()
            if (!rows.hasNext()) return@useLines emptyMap()
            val header = parseCsvLine(rows.next()).map { it.trim().removePrefix("\uFEFF") }
            val index = header.withIndex().associate { it.value to it.index }
            fun field(row: List<String>, name: String): String = index[name]?.let(row::getOrNull).orEmpty().trim()
            buildMap {
                while (rows.hasNext()) {
                    val row = parseCsvLine(rows.next())
                    val normalizedName = normalizeArtist(field(row, "normalized_name").ifBlank { field(row, "artist") })
                    if (normalizedName.isBlank()) continue
                    val category = normalizeKeyword(field(row, "category"))
                    val imageKeyword = normalizeKeyword(field(row, "image_keyword"))
                    val secondary = field(row, "secondary_keywords")
                        .split(',')
                        .map(::normalizeKeyword)
                        .filter { it.isNotBlank() }
                        .toSet()
                    put(
                        normalizedName,
                        SonusArtistGenreProfile(
                            category = category,
                            imageKeyword = imageKeyword,
                            secondaryKeywords = secondary,
                            confidence = field(row, "confidence").lowercase(Locale.ROOT)
                        )
                    )
                }
            }
        }
    }.getOrDefault(emptyMap())

    private fun parseCsvLine(line: String): List<String> {
        val out = mutableListOf<String>()
        val current = StringBuilder()
        var quoted = false
        var i = 0
        while (i < line.length) {
            val c = line[i]
            when {
                c == '"' && quoted && i + 1 < line.length && line[i + 1] == '"' -> {
                    current.append('"'); i++
                }
                c == '"' -> quoted = !quoted
                c == ',' && !quoted -> {
                    out += current.toString(); current.setLength(0)
                }
                else -> current.append(c)
            }
            i++
        }
        out += current.toString()
        return out
    }

    private fun normalizeArtist(raw: String): String = Normalizer.normalize(raw.lowercase(Locale.ROOT), Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "")
        .replace("&", " e ")
        .replace(Regex("[_./\\\\]+"), " ")
        .replace(Regex("[^a-z0-9]+"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun normalizeKeyword(raw: String): String = Normalizer.normalize(raw.lowercase(Locale.ROOT), Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "")
        .replace(Regex("[^a-z0-9]+"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()
}
