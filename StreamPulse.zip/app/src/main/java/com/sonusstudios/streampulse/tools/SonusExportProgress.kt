package com.sonusstudios.streampulse.tools

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

@Composable
internal fun SonusExportProgressRing(percent: Int, modifier: Modifier = Modifier.size(156.dp)) {
    val progress = percent.coerceIn(0, 100) / 100f
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 13.dp.toPx()
            drawArc(
                color = Color(0xFF1A2942),
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                style = Stroke(width = stroke, cap = StrokeCap.Round)
            )
            if (progress > 0f) {
                drawArc(
                    brush = Brush.sweepGradient(
                        listOf(
                            Color(0xFF49DFFF),
                            Color(0xFF49DFFF),
                            Color(0xFF967BFF),
                            Color(0xFFFF4FA1),
                            Color(0xFF49DFFF)
                        )
                    ),
                    startAngle = -90f,
                    sweepAngle = 360f * progress,
                    useCenter = false,
                    style = Stroke(width = stroke, cap = StrokeCap.Round)
                )
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("$percent%", fontSize = 31.sp, fontWeight = FontWeight.Black)
            Text("SONUS", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF49DFFF).copy(alpha = .78f))
        }
    }
}

@Composable
internal fun SonusExportProgressDialog(
    percent: Int,
    phase: String,
    title: String = "Processando no SONUS",
    onCancel: (() -> Unit)? = null
) {
    Dialog(
        onDismissRequest = {},
        properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false)
    ) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            tonalElevation = 10.dp,
            shadowElevation = 16.dp,
            color = MaterialTheme.colorScheme.surface.copy(alpha = .98f)
        ) {
            Column(
                Modifier.padding(horizontal = 28.dp, vertical = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(title, fontSize = 20.sp, fontWeight = FontWeight.Black)
                SonusExportProgressRing(percent)
                Text(
                    phase.ifBlank { "Preparando…" },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = .72f)
                )
                if (onCancel != null) {
                    OutlinedButton(onClick = onCancel, enabled = percent < 100) {
                        Text("Cancelar")
                    }
                } else {
                    Text("Aguarde…", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .58f))
                }
            }
        }
    }
}


@Composable
internal fun SonusShareExportProgressDialog(
    percent: Int,
    phase: String,
    onCancel: () -> Unit
) = SonusExportProgressDialog(
    percent = percent,
    phase = phase,
    title = "Criando vídeo SONUS",
    onCancel = onCancel
)
