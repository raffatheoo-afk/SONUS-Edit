package com.sonusstudios.streampulse.tools

import android.content.Context
import org.json.JSONObject
import java.time.LocalDate
import java.time.LocalTime
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

/** Estatísticas privadas do SONUS PLAYER, armazenadas apenas no aparelho. */
class PulsePlayerStatsStore(context: Context) {
    private val prefs = context.getSharedPreferences("pulse_player_stats_v1", Context.MODE_PRIVATE)
    private val lock = ReentrantLock()

    init {
        repairImpossibleHistoricalCountersOnce()
    }

    data class TrackStat(
        val uri: String,
        val title: String,
        val artist: String,
        val album: String,
        val genre: String,
        val source: String,
        val plays: Int,
        val listenedMs: Long,
        val skips: Int,
        val completed: Int,
        val lastPlayedAt: Long
    )

    data class SourceStat(
        val name: String,
        val listenedMs: Long,
        val plays: Int,
        val skips: Int,
        val completed: Int
    )

    data class Snapshot(
        val totalListeningMs: Long,
        val totalPlays: Int,
        val totalSkips: Int,
        val totalCompleted: Int,
        val topTracks: List<TrackStat>,
        val topArtists: List<Pair<String, Long>>,
        val topAlbums: List<Pair<String, Long>>,
        val topGenres: List<Pair<String, Long>>,
        val topOrigins: List<Pair<String, Long>>,
        val sourceStats: List<SourceStat>,
        val dailyMinutes: List<Pair<String, Long>>,
        val favoriteHour: Int?,
        val favoriteDay: String?,
        val activeDays: Int,
        val currentStreak: Int
    )

    fun recordPlay(item: PulsePlayerQueueItem) = mutate(item) { o ->
        o.put("plays", o.optInt("plays") + 1)
        o.put("last", System.currentTimeMillis())
        incrementGlobal("plays", 1)
        recordHour()
        mutateDailyTrack(item) {
            it.put("plays", it.optInt("plays") + 1)
            it.put("last", System.currentTimeMillis())
        }
    }

    fun addListening(item: PulsePlayerQueueItem, millis: Long) {
        if (millis <= 0) return
        mutate(item) { o -> o.put("ms", o.optLong("ms") + millis) }
        lock.withLock {
            prefs.edit().putLong("totalMs", prefs.getLong("totalMs", 0L) + millis).apply()
            val day = LocalDate.now().toString()
            val daily = loadObject("daily")
            daily.put(day, daily.optLong(day) + millis)
            saveObject("daily", daily)
        }
        mutateDailyTrack(item) { it.put("ms", it.optLong("ms") + millis) }
    }

    fun recordSkip(item: PulsePlayerQueueItem) = mutate(item) { o ->
        o.put("skips", o.optInt("skips") + 1)
        incrementGlobal("skips", 1)
        mutateDailyTrack(item) { it.put("skips", it.optInt("skips") + 1) }
    }

    fun recordCompleted(item: PulsePlayerQueueItem) = mutate(item) { o ->
        o.put("completed", o.optInt("completed") + 1)
        incrementGlobal("completed", 1)
        mutateDailyTrack(item) { it.put("completed", it.optInt("completed") + 1) }
    }

    /** Última faixa local realmente registrada; usada apenas para personalizar a sugestão do Stream. */
    fun latestLocalTrack(): TrackStat? = lock.withLock {
        loadTracks().mapNotNull { (_, o) -> toStat(o) }
            .filter { it.source.equals("Local", ignoreCase = true) || it.source.isBlank() }
            .maxByOrNull { it.lastPlayedAt }
    }

    /** Histórico total, incluindo dados antigos anteriores ao filtro por período. */
    fun snapshot(limit: Int = 8): Snapshot = lock.withLock {
        buildSnapshot(loadTracks().mapNotNull { (_, o) -> toStat(o) }, null, null, limit, totalFallback = true)
    }

    /** Período inclusivo. */
    fun snapshot(start: LocalDate, end: LocalDate, limit: Int = 8): Snapshot = lock.withLock {
        val safeStart = minOf(start, end)
        val safeEnd = maxOf(start, end)
        val merged = linkedMapOf<String, TrackStat>()
        var day = safeStart
        while (!day.isAfter(safeEnd)) {
            val dayObj = loadObject("day_tracks_$day")
            dayObj.keys().forEach { key ->
                dayObj.optJSONObject(key)?.let { o ->
                    val stat = toStat(o) ?: return@let
                    val old = merged[key]
                    merged[key] = if (old == null) stat else old.copy(
                        title = stat.title.ifBlank { old.title },
                        artist = stat.artist.ifBlank { old.artist },
                        album = stat.album.ifBlank { old.album },
                        genre = stat.genre.ifBlank { old.genre },
                        source = stat.source.ifBlank { old.source },
                        plays = old.plays + stat.plays,
                        listenedMs = old.listenedMs + stat.listenedMs,
                        skips = old.skips + stat.skips,
                        completed = old.completed + stat.completed,
                        lastPlayedAt = maxOf(old.lastPlayedAt, stat.lastPlayedAt)
                    )
                }
            }
            day = day.plusDays(1)
        }
        buildSnapshot(merged.values.toList(), safeStart, safeEnd, limit, totalFallback = false)
    }

    private fun buildSnapshot(
        tracks: List<TrackStat>, start: LocalDate?, end: LocalDate?, limit: Int, totalFallback: Boolean
    ): Snapshot {
        fun grouped(selector: (TrackStat) -> String, fallback: String): List<Pair<String, Long>> = tracks
            .groupBy { selector(it).ifBlank { fallback } }
            .mapValues { (_, l) -> l.sumOf { it.listenedMs } }
            .toList().sortedByDescending { it.second }.take(limit)

        val artists = grouped({ it.artist }, "Artista desconhecido")
        val albums = grouped({ it.album }, "Álbum desconhecido")
        val genres = grouped({ it.genre }, "Sem gênero")
        val origins = grouped({ it.source }, "Local")
        val sourceStats = tracks
            .groupBy { it.source.ifBlank { "Local" } }
            .map { (name, list) ->
                SourceStat(
                    name = name,
                    listenedMs = list.sumOf { it.listenedMs },
                    plays = list.sumOf { it.plays },
                    skips = list.sumOf { it.skips },
                    completed = list.sumOf { it.completed }
                )
            }
            .sortedWith(compareByDescending<SourceStat> { it.listenedMs }.thenByDescending { it.plays })
            .take(limit)

        val daily = loadObject("daily")
        val days = daily.keys().asSequence().mapNotNull { key ->
            val d = runCatching { LocalDate.parse(key) }.getOrNull() ?: return@mapNotNull null
            if ((start != null && d.isBefore(start)) || (end != null && d.isAfter(end))) null
            else key to daily.optLong(key) / 60_000L
        }.sortedBy { it.first }.toList()

        val hours = if (start == null || end == null) loadObject("hours") else JSONObject().also { sum ->
            var day = start!!
            val lastDay = end!!
            while (!day.isAfter(lastDay)) {
                val h = loadObject("day_hours_$day")
                h.keys().forEach { key -> sum.put(key, sum.optLong(key) + h.optLong(key)) }
                day = day.plusDays(1)
            }
        }
        val favorite = hours.keys().asSequence()
            .mapNotNull { h -> h.toIntOrNull()?.let { it to hours.optLong(h) } }
            .maxByOrNull { it.second }?.first

        // Os totais exibidos são derivados das próprias faixas, que são a fonte mais
        // consistente. As chaves globais antigas podem ter sido infladas por builds
        // anteriores e não devem voltar a contaminar a tela de Estatísticas.
        val summedMs = tracks.sumOf { it.listenedMs }
        val summedPlays = tracks.sumOf { it.plays }
        val summedCompleted = tracks.sumOf { it.completed }
        val summedSkips = tracks.sumOf { it.skips }
        val totalMs = if (totalFallback && tracks.isEmpty()) prefs.getLong("totalMs", 0L) else summedMs
        val totalPlays = if (totalFallback && tracks.isEmpty()) prefs.getInt("plays", 0) else summedPlays
        val totalCompleted = if (totalFallback && tracks.isEmpty()) prefs.getInt("completed", 0) else summedCompleted
        val totalSkips = if (totalFallback && tracks.isEmpty()) prefs.getInt("skips", 0) else summedSkips

        val favoriteDay = days.maxByOrNull { it.second }?.first
        val activeDates = days.filter { it.second > 0 }.mapNotNull { runCatching { LocalDate.parse(it.first) }.getOrNull() }.toSet()
        var streak = 0
        var cursor = LocalDate.now()
        while (cursor in activeDates) { streak++; cursor = cursor.minusDays(1) }

        return Snapshot(
            totalMs,
            totalPlays,
            totalSkips,
            totalCompleted,
            tracks.sortedWith(compareByDescending<TrackStat> { it.listenedMs }.thenByDescending { it.plays }).take(limit),
            artists,
            albums,
            genres,
            origins,
            sourceStats,
            days,
            favorite,
            favoriteDay,
            activeDates.size,
            streak
        )
    }

    /**
     * Repara uma única vez contadores históricos matematicamente impossíveis.
     * Cada reprodução registrada pode terminar, no máximo, em uma conclusão OU em um pulo.
     * Portanto: completed <= plays e skips <= plays - completed.
     *
     * Quando o histórico de pulos viola essa regra, o valor verdadeiro não pode ser
     * reconstruído. Nesse caso zeramos apenas o contador de pulos corrompido daquela
     * faixa, preservando tempo ouvido, plays e conclusões reais.
     */
    private fun repairImpossibleHistoricalCountersOnce() = lock.withLock {
        if (prefs.getBoolean("integrity_v2_repaired", false)) return@withLock

        fun sanitizeRoot(root: JSONObject): Pair<JSONObject, Boolean> {
            var changed = false
            val out = JSONObject()
            root.keys().forEach { key ->
                val original = root.optJSONObject(key)
                if (original == null) {
                    out.put(key, root.opt(key))
                    return@forEach
                }
                val o = JSONObject(original.toString())
                val plays = o.optInt("plays").coerceAtLeast(0)
                val completed = o.optInt("completed").coerceIn(0, plays)
                val maxSkips = (plays - completed).coerceAtLeast(0)
                val rawSkips = o.optInt("skips").coerceAtLeast(0)
                val skips = if (rawSkips > maxSkips) 0 else rawSkips
                if (plays != o.optInt("plays") || completed != o.optInt("completed") || skips != o.optInt("skips")) {
                    changed = true
                    o.put("plays", plays)
                    o.put("completed", completed)
                    o.put("skips", skips)
                }
                out.put(key, o)
            }
            return out to changed
        }

        val tracksRoot = loadObject("tracks")
        val (cleanTracks, tracksChanged) = sanitizeRoot(tracksRoot)
        if (tracksChanged) saveObject("tracks", cleanTracks)

        // Corrige também os recortes diários para que filtros de período não ressuscitem
        // valores impossíveis depois da migração.
        prefs.all.keys.filter { it.startsWith("day_tracks_") }.forEach { key ->
            val (cleanDay, changed) = sanitizeRoot(loadObject(key))
            if (changed) saveObject(key, cleanDay)
        }

        var plays = 0
        var completed = 0
        var skips = 0
        var totalMs = 0L
        cleanTracks.keys().forEach { key ->
            cleanTracks.optJSONObject(key)?.let { o ->
                plays += o.optInt("plays").coerceAtLeast(0)
                completed += o.optInt("completed").coerceAtLeast(0)
                skips += o.optInt("skips").coerceAtLeast(0)
                totalMs += o.optLong("ms").coerceAtLeast(0L)
            }
        }
        prefs.edit()
            .putInt("plays", plays)
            .putInt("completed", completed)
            .putInt("skips", skips)
            .putLong("totalMs", totalMs)
            .putBoolean("integrity_v2_repaired", true)
            .apply()
    }

    fun clear() = lock.withLock { prefs.edit().clear().apply() }

    private fun seed(item: PulsePlayerQueueItem) = JSONObject().apply {
        put("uri", item.uri)
        put("title", item.title)
        put("artist", item.artist)
        put("album", item.album)
        put("genre", item.genre)
        put("source", item.source)
        put("plays", 0)
        put("ms", 0L)
        put("skips", 0)
        put("completed", 0)
        put("last", 0L)
    }

    private fun refreshMetadata(o: JSONObject, item: PulsePlayerQueueItem) {
        o.put("title", item.title)
        o.put("artist", item.artist)
        o.put("album", item.album)
        o.put("genre", item.genre)
        o.put("source", item.source)
    }

    private fun mutateDailyTrack(item: PulsePlayerQueueItem, block: (JSONObject) -> Unit) = lock.withLock {
        val key = "day_tracks_${LocalDate.now()}"
        val root = loadObject(key)
        val o = root.optJSONObject(item.uri) ?: seed(item)
        refreshMetadata(o, item)
        block(o)
        root.put(item.uri, o)
        saveObject(key, root)
    }

    private fun mutate(item: PulsePlayerQueueItem, block: (JSONObject) -> Unit) = lock.withLock {
        val tracks = loadTracks()
        val key = item.uri
        val o = tracks[key] ?: seed(item)
        refreshMetadata(o, item)
        block(o)
        tracks[key] = o
        val root = JSONObject()
        tracks.forEach { (k, v) -> root.put(k, v) }
        prefs.edit().putString("tracks", root.toString()).apply()
    }

    private fun loadTracks(): MutableMap<String, JSONObject> {
        val root = runCatching { JSONObject(prefs.getString("tracks", "{}") ?: "{}") }.getOrElse { JSONObject() }
        val map = linkedMapOf<String, JSONObject>()
        root.keys().forEach { k -> root.optJSONObject(k)?.let { map[k] = it } }
        return map
    }

    private fun toStat(o: JSONObject): TrackStat? = runCatching {
        TrackStat(
            o.getString("uri"),
            o.optString("title"),
            o.optString("artist"),
            o.optString("album"),
            o.optString("genre"),
            o.optString("source", "Local"),
            o.optInt("plays"),
            o.optLong("ms"),
            o.optInt("skips"),
            o.optInt("completed"),
            o.optLong("last")
        )
    }.getOrNull()

    private fun incrementGlobal(key: String, amount: Int) {
        prefs.edit().putInt(key, prefs.getInt(key, 0) + amount).apply()
    }

    private fun recordHour() {
        val h = LocalTime.now().hour.toString()
        val hours = loadObject("hours")
        hours.put(h, hours.optLong(h) + 1L)
        saveObject("hours", hours)
        val d = loadObject("day_hours_${LocalDate.now()}")
        d.put(h, d.optLong(h) + 1L)
        saveObject("day_hours_${LocalDate.now()}", d)
    }

    private fun loadObject(key: String): JSONObject =
        runCatching { JSONObject(prefs.getString(key, "{}") ?: "{}") }.getOrElse { JSONObject() }

    private fun saveObject(key: String, value: JSONObject) {
        prefs.edit().putString(key, value.toString()).apply()
    }
}
