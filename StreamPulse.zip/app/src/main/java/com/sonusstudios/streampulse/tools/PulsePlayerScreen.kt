package com.sonusstudios.streampulse.tools
import com.sonusstudios.streampulse.stream.SonusRealtimePlayCount

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.net.TrafficStats
import android.os.Process
import android.os.Build
import android.os.IBinder
import android.app.Activity
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import com.sonusstudios.streampulse.R
import com.sonusstudios.streampulse.core.SonusMediaStandards
import com.sonusstudios.streampulse.core.*
import com.sonusstudios.streampulse.ads.StreamPulseAdManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.text.Normalizer
import java.util.Locale
import kotlin.math.roundToInt

internal enum class PulseCreatorAction { ANALYZER, CUTTER, CONVERTER, PITCH, VOCAL, METADATA, MERGE, VIDEO_AUDIO }

private enum class PlayerSection(val title: String, val icon: ImageVector) {
    HOME("Início", Icons.Default.Home), SONGS("Músicas", Icons.Default.LibraryMusic), FOLDERS("Pastas", Icons.Default.Folder),
    ALBUMS("Álbuns", Icons.Default.Album), ARTISTS("Artistas", Icons.Default.Person), GENRES("Gêneros", Icons.Default.Category),
    PLAYLISTS("Playlists", Icons.Default.QueueMusic), QUEUE("Lista de reprodução", Icons.Default.FormatListNumbered), LIKED("Curtidas", Icons.Default.Favorite), PINNED("Fixadas", Icons.Default.PushPin),
    RECENT("Recentes", Icons.Default.History), TOP("Mais tocadas", Icons.Default.LocalFireDepartment),
    STATS("Estatísticas", Icons.Default.Insights), ONLINE("SONUS Stream", Icons.Default.Public), LYRICS("Letras", Icons.Default.Lyrics), YOUTUBE_PLAYLISTS("Playlists YouTube", Icons.Default.PlaylistPlay), YOUTUBE("YouTube", Icons.Default.SmartDisplay), EQ("Equalizador", Icons.Default.GraphicEq),
    THEMES("Temas", Icons.Default.Palette), CREATOR("Creator Mode", Icons.Default.Build), SETTINGS("Configurações", Icons.Default.Settings)
}

private data class PulseLibraryTrack(
    val queue: PulsePlayerQueueItem,
    val folder: String,
    val lrcUri: String? = null,
    val lastModified: Long = 0L
)

private sealed class PlayerLibraryScope {
    data object AllTracks : PlayerLibraryScope()
    data class Folder(val name: String) : PlayerLibraryScope()
}

private enum class LibrarySortMode(val label: String) {
    TITLE_ASC("Título A–Z"), TITLE_DESC("Título Z–A"),
    ARTIST_ASC("Artista A–Z"), ARTIST_DESC("Artista Z–A"),
    NEWEST("Mais recentes"), OLDEST("Mais antigas"),
    DURATION_DESC("Duração maior"), DURATION_ASC("Duração menor")
}

private data class PlayerThemeSpec(val id: String, val name: String, val tier: MembershipTier, val colors: List<Color>, val glow: Color, val dynamic: Boolean = false)

internal data class PlayerVisualizerSpec(
    val id: String,
    val name: String,
    val tier: MembershipTier,
    val family: Int = 19,
    val colors: List<Color>,
    val dynamicColor: Boolean = false,
    val coverAdaptive: Boolean = false
)

/** Paletas do motor visual SONUS. Cada interface decide se apresenta barras ou VU Meter. */
internal val PulsePlayerVisualizers = listOf(
    PlayerVisualizerSpec("sonus_blue","Azul SONUS",MembershipTier.FREE,colors=listOf(Color(0xFF00D8FF),Color(0xFF246BFD),Color(0xFF7047EB))),
    PlayerVisualizerSpec("violet","Violeta",MembershipTier.FREE,colors=listOf(Color(0xFF7657FF),Color(0xFFB14DFF),Color(0xFFFF5CB8))),
    PlayerVisualizerSpec("red_pulse","Red Pulse",MembershipTier.FREE,colors=listOf(Color(0xFFFF3D55),Color(0xFFFF6A3D),Color(0xFFFFB13D))),
    PlayerVisualizerSpec("sonus_multi","Multicolor SONUS",MembershipTier.FREE,colors=listOf(Color(0xFF20E3FF),Color(0xFF397BFF),Color(0xFF8A4DFF),Color(0xFFFF4FB8),Color(0xFFFFB13D))),
    PlayerVisualizerSpec("sunset_pro","Sunset PRO",MembershipTier.FREE,colors=listOf(Color(0xFFFFC43D),Color(0xFFFF7043),Color(0xFFE93D9A))),
    PlayerVisualizerSpec("pink_purple_pro","Pink Purple PRO",MembershipTier.FREE,colors=listOf(Color(0xFFFF5BBE),Color(0xFFCB4DFF),Color(0xFF654DFF))),
    PlayerVisualizerSpec("dynamic_color","Dynamic Color",MembershipTier.FREE,colors=listOf(Color.Red,Color.Yellow,Color.Green,Color.Cyan,Color.Blue,Color.Magenta),dynamicColor=true),
    PlayerVisualizerSpec("dynamic_sonus_plus","Dynamic SONUS+",MembershipTier.FREE,colors=listOf(Color(0xFF20E3FF),Color(0xFF8A4DFF),Color(0xFFFF4FB8)),coverAdaptive=true)
)

private data class PulseOrbitUiPreset(
    val name: String,
    val mode: PulseOrbitMode,
    val intensity: Int,
    val frequencyHz: Double = 0.115
)

private val PulseOrbit3DPresets = listOf(
    PulseOrbitUiPreset("Natural", PulseOrbitMode.THREE_D, 42),
    PulseOrbitUiPreset("Studio", PulseOrbitMode.THREE_D, 55),
    PulseOrbitUiPreset("Stage", PulseOrbitMode.THREE_D, 66),
    PulseOrbitUiPreset("Cinema", PulseOrbitMode.THREE_D, 76),
    PulseOrbitUiPreset("Deep Space", PulseOrbitMode.THREE_D, 88)
)

private val PulseOrbit8DPresets = listOf(
    PulseOrbitUiPreset("Natural", PulseOrbitMode.EIGHT_D, 44, 0.055),
    PulseOrbitUiPreset("Flow", PulseOrbitMode.EIGHT_D, 52, 0.065),
    PulseOrbitUiPreset("Wide", PulseOrbitMode.EIGHT_D, 60, 0.060),
    PulseOrbitUiPreset("Deep", PulseOrbitMode.EIGHT_D, 64, 0.050),
    PulseOrbitUiPreset("Live", PulseOrbitMode.EIGHT_D, 48, 0.045),
    PulseOrbitUiPreset("Dream", PulseOrbitMode.EIGHT_D, 56, 0.040),
    PulseOrbitUiPreset("Energy", PulseOrbitMode.EIGHT_D, 62, 0.075),
    PulseOrbitUiPreset("Infinite", PulseOrbitMode.EIGHT_D, 66, 0.058)
)

private val PulsePlayerThemes = listOf(
    // 8 FREE
    PlayerThemeSpec("midnight_blue", "Midnight Blue", MembershipTier.FREE, listOf(Color(0xFF030A19), Color(0xFF081B3D), Color(0xFF0B2C52)), Color(0xFF00C8FF), true),
    PlayerThemeSpec("ocean", "Ocean", MembershipTier.FREE, listOf(Color(0xFF031820), Color(0xFF063A48), Color(0xFF0B5966)), Color(0xFF36D6E7)),
    PlayerThemeSpec("graphite", "Graphite", MembershipTier.FREE, listOf(Color(0xFF080A0D), Color(0xFF171A1F), Color(0xFF2B3038)), Color(0xFF8FA6BC)),
    PlayerThemeSpec("forest", "Forest", MembershipTier.FREE, listOf(Color(0xFF05140F), Color(0xFF0B3024), Color(0xFF15543F)), Color(0xFF55E6A5)),
    PlayerThemeSpec("violet", "Violet", MembershipTier.FREE, listOf(Color(0xFF10071C), Color(0xFF2D1251), Color(0xFF4A2077)), Color(0xFFB58CFF)),
    PlayerThemeSpec("crimson", "Crimson", MembershipTier.FREE, listOf(Color(0xFF17070A), Color(0xFF40121A), Color(0xFF6D2230)), Color(0xFFFF7086)),
    PlayerThemeSpec("ice", "Ice", MembershipTier.FREE, listOf(Color(0xFF07151E), Color(0xFF12374A), Color(0xFF1C5368)), Color(0xFFA4F0FF)),
    PlayerThemeSpec("sunset", "Sunset", MembershipTier.FREE, listOf(Color(0xFF160B22), Color(0xFF522148), Color(0xFF7D3B29)), Color(0xFFFF9A5C), true),
    // 5 BRONZE
    PlayerThemeSpec("neon_violet", "Neon Violet", MembershipTier.FREE, listOf(Color(0xFF080411), Color(0xFF27104B), Color(0xFF530E75)), Color(0xFFE447FF), true),
    PlayerThemeSpec("cyan_pulse", "Cyan Pulse", MembershipTier.FREE, listOf(Color(0xFF02090D), Color(0xFF00343B), Color(0xFF005D6B)), Color(0xFF00F2FF), true),
    PlayerThemeSpec("rose_night", "Rose Night", MembershipTier.FREE, listOf(Color(0xFF12070F), Color(0xFF3A1630), Color(0xFF68234E)), Color(0xFFFF68B6)),
    PlayerThemeSpec("emerald_glow", "Emerald Glow", MembershipTier.FREE, listOf(Color(0xFF03100C), Color(0xFF0B382B), Color(0xFF096047)), Color(0xFF2FFFC0), true),
    PlayerThemeSpec("electric_sunset", "Electric Sunset", MembershipTier.FREE, listOf(Color(0xFF10061B), Color(0xFF451252), Color(0xFF8A3E23)), Color(0xFFFF8D3B), true),
    // 10 PRATA
    PlayerThemeSpec("neon_studio", "Neon Studio", MembershipTier.PRATA, listOf(Color(0xFF030409), Color(0xFF071D3A), Color(0xFF24105A)), Color(0xFF00D9FF), true),
    PlayerThemeSpec("aurora", "Aurora", MembershipTier.PRATA, listOf(Color(0xFF061325), Color(0xFF143A50), Color(0xFF41295F)), Color(0xFF7EF9D6), true),
    PlayerThemeSpec("cyber_blue", "Cyber Blue", MembershipTier.PRATA, listOf(Color(0xFF020716), Color(0xFF061E55), Color(0xFF0A3D83)), Color(0xFF2C8CFF), true),
    PlayerThemeSpec("crimson_pro", "Crimson Pro", MembershipTier.PRATA, listOf(Color(0xFF090608), Color(0xFF281016), Color(0xFF5B1B2A)), Color(0xFFFF3F67)),
    PlayerThemeSpec("deep_ocean", "Deep Ocean", MembershipTier.PRATA, listOf(Color(0xFF01070C), Color(0xFF052834), Color(0xFF0B4D5A)), Color(0xFF22D7E4)),
    PlayerThemeSpec("synthwave", "Synthwave", MembershipTier.PRATA, listOf(Color(0xFF090419), Color(0xFF31104D), Color(0xFF6B164D)), Color(0xFFFF42D0), true),
    PlayerThemeSpec("stellar", "Stellar", MembershipTier.PRATA, listOf(Color(0xFF02030A), Color(0xFF111739), Color(0xFF29235D)), Color(0xFFB6A2FF), true),
    PlayerThemeSpec("arctic_glass", "Arctic Glass", MembershipTier.PRATA, listOf(Color(0xFF07121B), Color(0xFF153245), Color(0xFF315A6F)), Color(0xFFB7F1FF)),
    PlayerThemeSpec("purple_stage", "Purple Stage", MembershipTier.PRATA, listOf(Color(0xFF08040F), Color(0xFF27103A), Color(0xFF531D6D)), Color(0xFFD465FF), true),
    PlayerThemeSpec("emerald_studio", "Emerald Studio", MembershipTier.PRATA, listOf(Color(0xFF020B08), Color(0xFF0A2E22), Color(0xFF14543D)), Color(0xFF48F2B0)),
    // 15 OURO
    PlayerThemeSpec("infinity", "Infinity", MembershipTier.OURO, listOf(Color(0xFF010207), Color(0xFF07152E), Color(0xFF241049)), Color(0xFF22D8FF), true),
    PlayerThemeSpec("supernova", "Supernova", MembershipTier.OURO, listOf(Color(0xFF080306), Color(0xFF3C1027), Color(0xFF7D3512)), Color(0xFFFFB24D), true),
    PlayerThemeSpec("nebula", "Nebula", MembershipTier.OURO, listOf(Color(0xFF04030B), Color(0xFF221044), Color(0xFF5A174E)), Color(0xFFE477FF), true),
    PlayerThemeSpec("royal_gold", "Royal Gold", MembershipTier.OURO, listOf(Color(0xFF080602), Color(0xFF2E2208), Color(0xFF5A4310)), Color(0xFFFFD76A)),
    PlayerThemeSpec("prism_glass", "Prism Glass", MembershipTier.OURO, listOf(Color(0xFF07111D), Color(0xFF233347), Color(0xFF33254E)), Color(0xFFB7E6FF), true),
    PlayerThemeSpec("cosmic_violet", "Cosmic Violet", MembershipTier.OURO, listOf(Color(0xFF02030B), Color(0xFF17103B), Color(0xFF481E78)), Color(0xFFC05CFF), true),
    PlayerThemeSpec("black_diamond", "Black Diamond", MembershipTier.OURO, listOf(Color.Black, Color(0xFF090A0E), Color(0xFF191C24)), Color(0xFFE8EEFF)),
    PlayerThemeSpec("aurora_x", "Aurora X", MembershipTier.OURO, listOf(Color(0xFF031018), Color(0xFF0B3F44), Color(0xFF421E63)), Color(0xFF42FFD2), true),
    PlayerThemeSpec("liquid_neon", "Liquid Neon", MembershipTier.OURO, listOf(Color(0xFF03040A), Color(0xFF062A42), Color(0xFF4A0F58)), Color(0xFF00EEFF), true),
    PlayerThemeSpec("solar_flare", "Solar Flare", MembershipTier.OURO, listOf(Color(0xFF100502), Color(0xFF55160B), Color(0xFF8C4A0F)), Color(0xFFFFB636), true),
    PlayerThemeSpec("cyber_matrix", "Cyber Matrix", MembershipTier.OURO, listOf(Color(0xFF010702), Color(0xFF06250D), Color(0xFF0B4218)), Color(0xFF39FF6A), true),
    PlayerThemeSpec("galaxy_glass", "Galaxy Glass", MembershipTier.OURO, listOf(Color(0xFF03050E), Color(0xFF151E42), Color(0xFF3F245A)), Color(0xFF81A8FF), true),
    PlayerThemeSpec("quantum", "Quantum", MembershipTier.OURO, listOf(Color(0xFF020611), Color(0xFF0B2852), Color(0xFF32165D)), Color(0xFF3EEAFF), true),
    PlayerThemeSpec("celestial", "Celestial", MembershipTier.OURO, listOf(Color(0xFF06101A), Color(0xFF1B3245), Color(0xFF4C3B5A)), Color(0xFFFFE3B0), true),
    PlayerThemeSpec("pulse_signature", "Pulse Signature", MembershipTier.OURO, listOf(Color(0xFF02050D), Color(0xFF071E4A), Color(0xFF35115C)), Color(0xFF00D8FF), true),

    PlayerThemeSpec("diamond_aura", "Diamond Aura", MembershipTier.DIAMANTE, listOf(Color(0xFF01050A), Color(0xFF0C3557), Color(0xFF4A1C70)), Color(0xFFB7F8FF), true),
    PlayerThemeSpec("crystal_pulse", "Crystal Pulse", MembershipTier.DIAMANTE, listOf(Color(0xFF02070B), Color(0xFF164559), Color(0xFF513D77)), Color(0xFFE1FDFF), true),
    PlayerThemeSpec("hologram", "Hologram", MembershipTier.DIAMANTE, listOf(Color(0xFF02050B), Color(0xFF17335B), Color(0xFF6B246B)), Color(0xFF82FFF2), true),
    PlayerThemeSpec("midnight_diamond", "Midnight Diamond", MembershipTier.DIAMANTE, listOf(Color(0xFF000103), Color(0xFF07101E), Color(0xFF19152D)), Color(0xFFDDF9FF), true),
    PlayerThemeSpec("pulse_crown", "Pulse Crown", MembershipTier.DIAMANTE, listOf(Color(0xFF03030A), Color(0xFF1E1745), Color(0xFF5B1D69)), Color(0xFFF0D7FF), true)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun PulsePlayerScreen(
    membershipTier: MembershipTier,
    preferences: UserPreferences,
    ownerUnlimited: Boolean,
    onBack: () -> Unit,
    externalAudioUri: String? = null,
    onExternalAudioConsumed: () -> Unit = {},
    onUnlockFeature24h: (feature: PulseFeaturePass, onUnlocked: () -> Unit, onUnavailable: (String) -> Unit) -> Unit,
    onTrack: (String, Boolean?, Long?) -> Unit,
    onCreatorAction: (PulseCreatorAction) -> Unit,
    onRequestPlan: (MembershipTier) -> Unit,
    onStreamCreator: () -> Unit = {},
    onOpenFullPlayerFromStream: (() -> Unit)? = null,
    initialSection: String? = null,
    adManager: StreamPulseAdManager? = null
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val store = remember { PulsePlayerLibraryStore(context) }
    val streamExperience = remember { SonusStreamExperiencePreferences(context) }
    var shuffleMode by remember { mutableStateOf(store.shuffleMode) }
    val statsStore = remember { PulsePlayerStatsStore(context) }
    var service by remember { mutableStateOf<PulsePlayerService?>(null) }
    val connection = remember {
        object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
                val connected = (binder as? PulsePlayerService.LocalBinder)?.service()
                connected?.reconcileTransportState()
                service = connected
            }
            override fun onServiceDisconnected(name: ComponentName?) { service = null }
        }
    }
    DisposableEffect(Unit) {
        val intent = Intent(context, PulsePlayerService::class.java)
        // Apenas conecta ao serviço. Voltar ao Player nunca é interpretado como pedido de Play.
        context.bindService(intent, connection, Context.BIND_AUTO_CREATE)
        onDispose { runCatching { context.unbindService(connection) } }
    }
    val fallback = remember { kotlinx.coroutines.flow.MutableStateFlow(PulsePlayerPlaybackState()) }
    val fallbackSpectrum = remember { kotlinx.coroutines.flow.MutableStateFlow(List(24) { 0f }) }
    val playback by (service?.state ?: fallback).collectAsState()
    val liveSpectrum by (service?.spectrum ?: fallbackSpectrum).collectAsState()
    val streamShareRepo = remember { SonusOnlineMusicRepository(context) }
    val streamSharePlatform = remember { com.sonusstudios.streampulse.stream.SonusStreamPlatformRepository(context) }
    var shareSource by remember { mutableStateOf<SonusShareSource?>(null) }
    var section by remember(initialSection) { mutableStateOf(if (initialSection == "ONLINE") PlayerSection.ONLINE else PlayerSection.HOME) }

    LaunchedEffect(service, externalAudioUri) {
        val connected = service ?: return@LaunchedEffect
        val raw = externalAudioUri ?: return@LaunchedEffect
        val uri = runCatching { Uri.parse(raw) }.getOrNull() ?: return@LaunchedEffect
        persistCloudUri(context, uri)
        val item = withContext(Dispatchers.IO) { cloudAudioQueueItem(context, uri, "Arquivo externo") }
        connected.setQueue(listOf(item), 0, true)
        onExternalAudioConsumed()
    }

    val pulseLiftAccess = true
    val pulseOrbit3dAccess = true
    val pulseOrbit8dAccess = true

    fun unlockOrRun(feature: PulseFeaturePass, action: () -> Unit) {
        if (hasFeatureAccess(membershipTier, preferences, feature, ownerUnlimited)) {
            action()
        } else {
            onUnlockFeature24h(
                feature,
                {
                    service?.setPremiumFeatureAccess(
                        pulseLiftAccess || feature == PulseFeaturePass.PULSE_LIFT,
                        pulseOrbit3dAccess || feature == PulseFeaturePass.PULSE_ORBIT_3D,
                        pulseOrbit8dAccess || feature == PulseFeaturePass.PULSE_ORBIT_8D
                    )
                    action()
                },
                { message -> Toast.makeText(context, message, Toast.LENGTH_SHORT).show() }
            )
        }
    }

    var tracks by remember { mutableStateOf(store.cachedTracks()) }
    var loading by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var librarySortMode by remember { mutableStateOf(store.librarySortMode) }
    var libraryMessage by remember { mutableStateOf<String?>(null) }
    var selectedGroup by remember { mutableStateOf<String?>(null) }
    var libraryScope by remember { mutableStateOf<PlayerLibraryScope>(PlayerLibraryScope.AllTracks) }
    val libraryScopeTracks = remember(tracks, libraryScope) {
        when (val scopeValue = libraryScope) {
            PlayerLibraryScope.AllTracks -> tracks
            is PlayerLibraryScope.Folder -> tracks.filter { it.folder == scopeValue.name }
        }
    }
    val libraryScopeTitle = when (val scopeValue = libraryScope) {
        PlayerLibraryScope.AllTracks -> "Todas as músicas"
        is PlayerLibraryScope.Folder -> "Biblioteca • ${scopeValue.name}"
    }
    var selectedThemeId by remember { mutableStateOf(store.themeId) }
    val selectedTheme = PulsePlayerThemes.firstOrNull { it.id == selectedThemeId && hasTier(membershipTier, it.tier) } ?: PulsePlayerThemes.first()
    var playerInterfaceId by remember { mutableStateOf(store.playerInterfaceId) }
    val selectedPlayerInterface = PulsePlayerInterfaces.firstOrNull { it.id == playerInterfaceId && hasTier(membershipTier, it.tier) }
        ?: PulsePlayerInterfaces.first()
    var visualizerId by remember { mutableStateOf(store.visualizerId) }
    val selectedVisualizer = PulsePlayerVisualizers.firstOrNull { it.id == visualizerId && hasTier(membershipTier, it.tier) } ?: PulsePlayerVisualizers.first()
    var visualizerIntensity by remember { mutableIntStateOf(store.visualizerIntensity) }
    var visualizerSensitivity by remember { mutableFloatStateOf(store.visualizerSensitivity) }
    var visualizerSmoothness by remember { mutableIntStateOf(store.visualizerSmoothness) }
    var visualizerEnabled by remember { mutableStateOf(store.visualizerEnabled) }
    var keepScreenOn by remember { mutableStateOf(store.keepScreenOn) }

    LaunchedEffect(membershipTier, playerInterfaceId) {
        val selected = PulsePlayerInterfaces.firstOrNull { it.id == playerInterfaceId }
        if (selected == null || !hasTier(membershipTier, selected.tier)) {
            playerInterfaceId = "classic"
            store.playerInterfaceId = "classic"
        }
    }
    var reduceAnimations by remember { mutableStateOf(store.reduceAnimations) }
    var liked by remember { mutableStateOf(store.liked) }
    var pinned by remember { mutableStateOf(store.pinned) }
    var playlists by remember { mutableStateOf(store.playlists()) }
    var statsRevision by remember { mutableIntStateOf(0) }
    var initialAutoPlayDone by remember { mutableStateOf(false) }
    var streamSuggestionLoading by remember { mutableStateOf(false) }
    var streamSuggestionFamily by remember { mutableStateOf<String?>(null) }
    var folderPromptEnabled by remember { mutableStateOf(store.folderPromptEnabled) }
    var localRootAvailable by remember { mutableStateOf(store.rootUri != null) }
    var wasSuggestedTrackPlaying by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val rootText = store.rootUri
        if (!rootText.isNullOrBlank()) {
            val rootUri = runCatching { Uri.parse(rootText) }.getOrNull()
            val available = rootUri != null && withContext(Dispatchers.IO) {
                runCatching { DocumentFile.fromTreeUri(context, rootUri)?.exists() == true }.getOrDefault(false)
            }
            localRootAvailable = available
            if (!available) {
                store.rootUri = null
                tracks = emptyList()
                store.saveCachedTracks(emptyList())
            }
        } else {
            localRootAvailable = false
        }
    }

    val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    fun requestNotificationIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    var libraryScanInProgress by remember { mutableStateOf(false) }
    fun scan(uri: Uri, autoplayAfter: Boolean = false, showLoading: Boolean = true) {
        if (libraryScanInProgress) return
        scope.launch {
            libraryScanInProgress = true
            if (showLoading) loading = true
            if (showLoading) libraryMessage = "Procurando novas músicas…"
            val previous = tracks.ifEmpty { store.cachedTracks() }
            val previousUris = previous.map { it.queue.uri }.toSet()
            val result = withContext(Dispatchers.IO) { scanPulseLibrary(context, uri, store.excludedFolders, previous) }
            val updated = result.getOrElse { previous }
            tracks = updated
            val rootStillAvailable = withContext(Dispatchers.IO) { runCatching { DocumentFile.fromTreeUri(context, uri)?.exists() == true }.getOrDefault(false) }
            localRootAvailable = rootStillAvailable
            if (result.isSuccess) {
                store.saveCachedTracks(updated)
                store.lastLibraryScanAt = System.currentTimeMillis()
            }
            if (!rootStillAvailable && store.rootUri == uri.toString()) store.rootUri = null
            val updatedUris = updated.map { it.queue.uri }.toSet()
            val added = (updatedUris - previousUris).size
            val removed = (previousUris - updatedUris).size
            loading = false
            libraryScanInProgress = false
            libraryMessage = result.exceptionOrNull()?.message ?: when {
                updated.isEmpty() -> "Nenhuma música encontrada nessa pasta."
                added > 0 && removed > 0 -> "$added nova(s) • $removed removida(s)"
                added > 0 -> "$added nova(s) música(s) encontrada(s)."
                removed > 0 -> "$removed música(s) removida(s) da biblioteca."
                else -> "Biblioteca atualizada • nenhuma novidade."
            }
            if (updated.isNotEmpty()) {
                val queue = updated.map { it.queue }
                // code103: o refresh nunca reinicia a música, a fila ativa ou o contador.
                if (playback.queue.isEmpty()) service?.setQueue(queue, 0, false)
            }
        }
    }

    fun refreshLibrary(showLoading: Boolean = true) {
        val root = store.rootUri?.let { runCatching { Uri.parse(it) }.getOrNull() }
        if (root == null) {
            libraryMessage = "Escolha uma pasta de músicas primeiro."
            return
        }
        scan(root, autoplayAfter = false, showLoading = showLoading)
    }

    val treePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        uri?.let { selectedUri ->
            // Alguns provedores SAF concedem somente leitura. Tenta preservar leitura+escrita
            // e recua para somente leitura para não perder a biblioteca após reiniciar o app.
            runCatching {
                context.contentResolver.takePersistableUriPermission(selectedUri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            }.recoverCatching {
                context.contentResolver.takePersistableUriPermission(selectedUri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            store.rootUri = selectedUri.toString()
            localRootAvailable = true
            scan(selectedUri, autoplayAfter = false, showLoading = true)
            onTrack("SONUS PLAYER: biblioteca definida", true, null)
        }
    }

    fun installStreamSuggestion(forceNext: Boolean = false) {
        val connected = service ?: return
        if (tracks.isNotEmpty() || streamSuggestionLoading) return
        if (!forceNext && connected.state.value.current?.source?.contains("SONUS Stream", ignoreCase = true) == true) return
        streamSuggestionLoading = true
        scope.launch {
            var catalog = streamSuggestionCatalog(streamShareRepo)
            if (catalog.isEmpty()) {
                withContext(Dispatchers.IO) { runCatching { streamShareRepo.refreshCatalogIfChanged(force = false) } }
                catalog = streamSuggestionCatalog(streamShareRepo)
            }
            val preferredFamily = streamSuggestionFamily
                ?: playerGenreFamily(statsStore.latestLocalTrack()?.genre.orEmpty()).takeIf { it.isNotBlank() }
                ?: statsStore.snapshot(80).topGenres.firstOrNull()?.first?.let(::playerGenreFamily)?.takeIf { it.isNotBlank() }
            if (streamSuggestionFamily == null) streamSuggestionFamily = preferredFamily
            val sameFamily = preferredFamily?.let { family -> catalog.filter { playerGenreFamily(it.genre) == family } }.orEmpty()
            val pool = (if (sameFamily.isNotEmpty()) sameFamily else catalog).filterNot { it.fileId in store.recentStreamSuggestionIds() }
                .ifEmpty { if (sameFamily.isNotEmpty()) sameFamily else catalog }
            val candidate = pool.shuffled().firstOrNull()
            if (candidate != null) {
                val queueItem = streamShareRepo.queueItem(candidate).copy(source = "SONUS Stream • Sugestão")
                connected.setRepeatMode(0)
                connected.setShuffle(false)
                connected.setQueue(listOf(queueItem), 0, false, 0L)
                store.rememberStreamSuggestion(candidate.fileId)
                withContext(Dispatchers.IO) {
                    runCatching { streamShareRepo.prefetchPlaybackDescriptor(candidate.fileId) }
                    runCatching { streamShareRepo.artwork(candidate) }
                }
            }
            streamSuggestionLoading = false
        }
    }

    LaunchedEffect(section) {
        if (section == PlayerSection.HOME) folderPromptEnabled = store.folderPromptEnabled
    }

    LaunchedEffect(service, pulseLiftAccess, pulseOrbit3dAccess, pulseOrbit8dAccess) {
        service?.setPremiumFeatureAccess(pulseLiftAccess, pulseOrbit3dAccess, pulseOrbit8dAccess)
    }

    LaunchedEffect(playback.current?.uri) {
        playback.current?.uri?.takeIf { it.isNotBlank() }?.let { store.lastTrackUri = it }
    }

    LaunchedEffect(service) {
        val connected = service
        // code112: reabrir/trocar aba é apenas observação da sessão ativa.
        // Não reaplica speed/shuffle/repeat em um player já tocando: isso evita estalo
        // e também impede um shuffle antigo de destruir a ordem escolhida no Stream.
        if (connected != null && connected.state.value.queue.isEmpty()) {
            connected.setCrossfade(store.crossfade)
            connected.setPlaybackSpeed(store.playbackSpeed)
            connected.setShuffle(store.shuffle)
            connected.setRepeatMode(store.repeatMode)
        }
        if (connected != null && !initialAutoPlayDone) {
            initialAutoPlayDone = true
            // Reentrar na tela apenas reconecta à sessão persistente. Nunca pausa mídia já em reprodução.
            if (playback.queue.isEmpty() && tracks.isNotEmpty()) {
                val remembered = store.lastTrackUri
                val rememberedIndex = tracks.indexOfFirst { it.queue.uri == remembered }.takeIf { it >= 0 } ?: 0
                // code103: restaura somente o estado visual/posição. O MediaPlayer só é criado após Play explícito.
                service?.setQueue(tracks.map { it.queue }, rememberedIndex, false, startPositionMs = store.lastPositionMs)
            } else if (playback.queue.isEmpty() && tracks.isEmpty()) {
                installStreamSuggestion(forceNext = false)
            }
            val cacheAgeMs = System.currentTimeMillis() - store.lastLibraryScanAt
            val needsRefresh = tracks.isEmpty() || cacheAgeMs >= 30 * 60_000L
            if (needsRefresh) {
                store.rootUri?.let { runCatching { Uri.parse(it) }.getOrNull() }?.let { uri ->
                    // code106: com cache pronto a atualização é silenciosa e ocorre no máximo uma vez por sessão/TTL.
                    scan(uri, autoplayAfter = false, showLoading = tracks.isEmpty())
                }
            }
        }
    }

    // code106: removidos full rescan ao retornar à tela e loop automático de 60 s.
    // Atualizações continuam disponíveis pelo botão e pull-to-refresh.

    LaunchedEffect(service, tracks.size, playback.queue.isEmpty()) {
        if (service != null && tracks.isEmpty() && playback.queue.isEmpty()) installStreamSuggestion(forceNext = false)
    }

    // Sugestão do Stream nunca vira rádio automática: ao terminar, prepara outra do mesmo gênero e para.
    LaunchedEffect(playback.current?.uri, playback.playing, playback.positionMs, playback.durationMs) {
        val current = playback.current
        val suggested = current?.source?.contains("Sugestão", ignoreCase = true) == true
        if (suggested && playback.playing) wasSuggestedTrackPlaying = true
        if (suggested && wasSuggestedTrackPlaying && !playback.playing && playback.positionMs <= 600L && playback.durationMs > 0L) {
            wasSuggestedTrackPlaying = false
            delay(120L)
            installStreamSuggestion(forceNext = true)
        }
        if (!suggested) wasSuggestedTrackPlaying = false
    }

    val latestPlaybackForPersistence by rememberUpdatedState(playback)
    LaunchedEffect(playback.current?.uri, playback.playing) {
        val uri = playback.current?.uri ?: return@LaunchedEffect
        store.lastTrackUri = uri
        store.lastPositionMs = playback.positionMs.coerceAtLeast(0L)
        if (playback.playing) {
            while (true) {
                delay(5_000L)
                val latest = latestPlaybackForPersistence
                if (latest.current?.uri != uri || !latest.playing) break
                store.lastPositionMs = latest.positionMs.coerceAtLeast(0L)
            }
        }
    }
    DisposableEffect(Unit) {
        onDispose {
            latestPlaybackForPersistence.current?.uri?.let { uri ->
                store.lastTrackUri = uri
                store.lastPositionMs = latestPlaybackForPersistence.positionMs.coerceAtLeast(0L)
            }
        }
    }

    DisposableEffect(keepScreenOn) {
        val activity = context.findActivity()
        if (keepScreenOn) activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose { activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
    }

    val drawerState = rememberDrawerState(DrawerValue.Closed)
    var lastBackAt by remember { mutableLongStateOf(0L) }
    BackHandler {
        when {
            drawerState.isOpen -> scope.launch { drawerState.close() }
            section != PlayerSection.HOME -> section = PlayerSection.HOME
            else -> {
                val now = System.currentTimeMillis()
                if (now - lastBackAt <= 2_000L) onBack()
                else {
                    lastBackAt = now
                    Toast.makeText(context, "Pressione voltar novamente para sair", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    shareSource?.let { target ->
        SonusShareDialog(
            source = target,
            repo = streamShareRepo,
            platform = streamSharePlatform,
            service = service,
            membershipTier = membershipTier,
            onRequestPlan = onRequestPlan,
            onClose = { shareSource = null }
        )
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                modifier = Modifier.width(310.dp),
                drawerContainerColor = Color(0xFF07101F)
            ) {
                Box(
                    Modifier.fillMaxWidth().background(
                        Brush.verticalGradient(listOf(selectedTheme.glow.copy(alpha = .22f), Color.Transparent))
                    ).padding(horizontal = 18.dp, vertical = 18.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(shape = CircleShape, color = selectedTheme.glow.copy(alpha = .18f), border = BorderStroke(1.dp, selectedTheme.glow.copy(alpha=.45f))) {
                            Icon(Icons.Default.Headphones, null, tint = selectedTheme.glow, modifier = Modifier.padding(12.dp))
                        }
                        Spacer(Modifier.width(11.dp))
                        Column {
                            Text("SONUS PLAYER", fontWeight = FontWeight.Black, fontSize = 23.sp, color = Color.White)
                            Text("SONUS • Music Hub", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha=.62f))
                        }
                    }
                }
                val drawerGroups = listOf(
                    "BIBLIOTECA" to listOf(PlayerSection.HOME, PlayerSection.SONGS, PlayerSection.FOLDERS, PlayerSection.ALBUMS, PlayerSection.ARTISTS, PlayerSection.GENRES),
                    "MINHA MÚSICA" to listOf(PlayerSection.PLAYLISTS, PlayerSection.QUEUE, PlayerSection.LIKED, PlayerSection.PINNED, PlayerSection.RECENT, PlayerSection.TOP),
                    // SONUS Stream já possui aba principal própria; não duplicar a navegação dentro do Player.
                    "INTELIGÊNCIA" to listOf(PlayerSection.STATS),
                    "SOM" to listOf(PlayerSection.EQ),
                    "PERSONALIZAÇÃO" to listOf(PlayerSection.THEMES),
                    "SISTEMA" to listOf(PlayerSection.SETTINGS)
                )
                LazyColumn(contentPadding = PaddingValues(start=12.dp, end=12.dp, bottom=22.dp)) {
                    drawerGroups.forEach { (group, entries) ->
                        item {
                            Text(group, color=selectedTheme.glow.copy(alpha=.88f), fontWeight=FontWeight.Black, fontSize=11.sp, letterSpacing=1.2.sp, modifier=Modifier.padding(start=4.dp, top=14.dp, bottom=7.dp))
                        }
                        items(entries.chunked(2)) { rowEntries ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                                rowEntries.forEach { item ->
                                    val selected = section == item
                                    Surface(
                                        modifier=Modifier.weight(1f).height(72.dp).clickable {
                                            if (item == PlayerSection.SONGS) libraryScope = PlayerLibraryScope.AllTracks
                                            section = item
                                            selectedGroup = null
                                            scope.launch { drawerState.close() }
                                        },
                                        shape=RoundedCornerShape(16.dp),
                                        color=if(selected) selectedTheme.glow.copy(alpha=.18f) else Color.White.copy(alpha=.045f),
                                        border=BorderStroke(1.dp, if(selected) selectedTheme.glow.copy(alpha=.58f) else Color.White.copy(alpha=.10f))
                                    ) {
                                        Column(Modifier.fillMaxSize().padding(9.dp), verticalArrangement=Arrangement.Center, horizontalAlignment=Alignment.CenterHorizontally) {
                                            Icon(item.icon, null, tint=if(selected) selectedTheme.glow else Color.White.copy(alpha=.72f), modifier=Modifier.size(23.dp))
                                            Spacer(Modifier.height(5.dp))
                                            Text(item.title, fontWeight=if(selected) FontWeight.Black else FontWeight.SemiBold, fontSize=11.sp, maxLines=1, overflow=TextOverflow.Ellipsis, color=Color.White.copy(alpha=.92f))
                                        }
                                    }
                                }
                                if (rowEntries.size == 1) Spacer(Modifier.weight(1f))
                            }
                            Spacer(Modifier.height(8.dp))
                        }
                    }
                }
            }
        }
    ) {
        Box(Modifier.fillMaxSize()) {
            PulsePlayerBackdrop(selectedTheme, reduceAnimations)
            Scaffold(
                containerColor = Color.Transparent,
                topBar = {
                    if(section!=PlayerSection.ONLINE) CenterAlignedTopAppBar(
                        title = {
                            Column(horizontalAlignment=Alignment.CenterHorizontally) {
                                Text("SONUS PLAYER", fontWeight = FontWeight.Black, letterSpacing = 1.8.sp, fontSize=21.sp)
                                if (section != PlayerSection.HOME) Text(section.title, style = MaterialTheme.typography.labelSmall, color = selectedTheme.glow.copy(alpha=.82f))
                            }
                        },
                        navigationIcon = { IconButton(onClick = { scope.launch { drawerState.open() } }) { Icon(Icons.Default.Menu, "Menu") } },
                        actions = {
                            if (section == PlayerSection.SONGS || section == PlayerSection.FOLDERS) {
                                IconButton(onClick = { refreshLibrary(showLoading = true) }, enabled = !libraryScanInProgress) {
                                    Icon(Icons.Default.Refresh, "Atualizar biblioteca")
                                }
                            }
                            if (section == PlayerSection.HOME) {
                                IconButton(onClick = { query = ""; section = PlayerSection.SONGS }) { Icon(Icons.Default.LibraryMusic, "Biblioteca") }
                                IconButton(onClick = { section = PlayerSection.STATS }) { Icon(Icons.Default.Insights, "Estatísticas") }
                                IconButton(onClick = { query = ""; section = PlayerSection.SONGS }) { Icon(Icons.Default.Search, "Pesquisar") }
                            } else {
                                IconButton(onClick = { section = PlayerSection.HOME }) { Icon(Icons.Default.Home, "Voltar ao Player") }
                            }
                        },
                        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = Color.Transparent)
                    )
                }
            ) { pad ->
                Box(Modifier.fillMaxSize().padding(pad)) {
                    when (section) {
                        PlayerSection.HOME -> PulseHome(
                            tracks = tracks, playback = playback, spectrumFlow = service?.spectrum ?: fallbackSpectrum, theme = selectedTheme, playerInterface = selectedPlayerInterface, visualizer = selectedVisualizer,
                            visualizerEnabled = visualizerEnabled, visualizerIntensity = visualizerIntensity, visualizerSensitivity = visualizerSensitivity,
                            visualizerSmoothness = visualizerSmoothness,
                            loading = loading, message = libraryMessage,
                            showFolderPrompt = tracks.isEmpty() && !localRootAvailable && folderPromptEnabled,
                            onDismissFolderPrompt = { folderPromptEnabled = false; store.folderPromptEnabled = false },
                            onChooseFolder = { treePicker.launch(null) },
                            onToggle = { requestNotificationIfNeeded(); PulseHaptics.perform(context, preferences, PulseHapticEvent.TAP, forPlayer = true); service?.toggle() },
                            onPrevious = { PulseHaptics.perform(context, preferences, PulseHapticEvent.TAP, forPlayer = true); service?.previous() },
                            onNext = { PulseHaptics.perform(context, preferences, PulseHapticEvent.TAP, forPlayer = true); service?.next(true) },
                            onSeek = { service?.seekTo(it) }, onShuffle = {
                                shuffleMode = when(shuffleMode){"off"->"normal";"normal"->"az";"az"->"smart";else->"off"}
                                store.shuffleMode=shuffleMode
                                val scoped = libraryScopeTracks
                                val arranged=when(shuffleMode){"normal"->scoped.shuffled();"az"->alternateExtremes(scoped.sortedBy{it.queue.title.lowercase()});"smart"->smartArtistShuffle(scoped);else->scoped}
                                service?.setShuffle(false);store.shuffle=shuffleMode!="off"
                                if(arranged.isNotEmpty()){val current=playback.current?.uri;val idx=arranged.indexOfFirst{it.queue.uri==current}.coerceAtLeast(0);service?.setQueue(arranged.map{it.queue},idx,playback.playing)}
                                Toast.makeText(context,when(shuffleMode){"normal"->"Aleatório";"az"->"Aleatório A–Z";"smart"->"Aleatório inteligente";else->"Aleatório desativado"},Toast.LENGTH_SHORT).show()
                            },
                            onRepeat = {
                                val next = (playback.repeatMode + 1) % 3
                                service?.setRepeatMode(next); store.repeatMode = next
                            },
                            onRadioDelay = { delayMs ->
                                SonusRadioEngine.targetForDelay(context, playback.queue, delayMs)?.let { (targetIndex, targetPosition) ->
                                    service?.playIndex(targetIndex, shouldPlay = true, startPositionMs = targetPosition)
                                }
                            },
                            liked = liked, onLike = { uri -> liked = toggleSet(liked, uri); store.liked = liked },
                            pinned = pinned, onPin = { uri -> pinned = toggleSet(pinned, uri); store.pinned = pinned },
                            onEqualizer = { section = PlayerSection.EQ },
                            onLibrary = { query = ""; section = PlayerSection.SONGS },
                            onYouTube = { section = PlayerSection.YOUTUBE },
                            onYouTubePlaylists = { section = PlayerSection.YOUTUBE_PLAYLISTS },
                            onShare = {
                                val current = playback.current
                                if (current != null) {
                                    val onlineRef = SonusOnlineRef.parse(current.uri)
                                    if (onlineRef != null) {
                                        val cached = streamShareRepo.allCachedTracks().firstOrNull { it.fileId == onlineRef.fileId }
                                        val onlineTrack = cached ?: SonusOnlineTrack(
                                            path = "", fileName = current.title, size = onlineRef.size, fileId = onlineRef.fileId,
                                            title = current.title, artist = current.artist, album = current.album,
                                            genre = current.genre, durationMs = playback.durationMs
                                        )
                                        shareSource = onlineTrack.toShareSource()
                                    } else {
                                        scope.launch {
                                            val localTrack = tracks.firstOrNull { it.queue.uri == current.uri }
                                            val lrcText = withContext(Dispatchers.IO) {
                                                val sidecar = localTrack?.lrcUri?.let { lrcUri ->
                                                    runCatching {
                                                        context.contentResolver.openInputStream(Uri.parse(lrcUri))
                                                            ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                                                    }.getOrNull()
                                                }.orEmpty()
                                                if (sidecar.isNotBlank()) sidecar
                                                else runCatching { AudioToolEngine.readMetadata(context, Uri.parse(current.uri)).lyrics }.getOrDefault("")
                                            }
                                            shareSource = SonusShareSource(
                                                key = "local:${current.uri}",
                                                title = current.title.ifBlank { "Música" },
                                                artist = current.artist,
                                                album = current.album,
                                                genre = current.genre,
                                                durationMs = playback.durationMs.takeIf { it > 0L } ?: current.durationMs,
                                                audioUri = current.uri,
                                                lrcText = lrcText
                                            )
                                        }
                                    }
                                }
                            },
                            shareEnabled = playback.current != null,
                            onStats = { section = PlayerSection.STATS },
                            onLyrics = { section = PlayerSection.LYRICS },
                            onPulseLift = {
                                if (playback.pulseLift) service?.setPulseLift(false)
                                else service?.setPulseLift(true)
                            }
                        )
                        PlayerSection.SONGS -> PullToRefreshBox(
                            isRefreshing = libraryScanInProgress,
                            onRefresh = { refreshLibrary(showLoading = true) }
                        ) {
                            val scopedTracks = libraryScopeTracks
                            val visibleTracks = sortLibraryTracks(filterTracks(scopedTracks, query), librarySortMode)
                            TrackBrowser(
                                libraryScopeTitle, visibleTracks, query, { query = it }, playback.current?.uri,
                                { track ->
                                    requestNotificationIfNeeded()
                                    store.shuffle = false
                                    service?.setShuffle(false)
                                    playTrack(service, visibleTracks, track, onTrack)
                                    section = PlayerSection.HOME
                                }, liked, { u -> liked = toggleSet(liked,u);store.liked=liked },
                                sortMode = librarySortMode,
                                onSortMode = { mode -> librarySortMode = mode; store.librarySortMode = mode },
                                onPlayAll = {
                                    if (visibleTracks.isNotEmpty()) {
                                        requestNotificationIfNeeded()
                                        store.shuffle = false; service?.setShuffle(false)
                                        service?.setQueue(visibleTracks.map { it.queue }, 0, true)
                                        section = PlayerSection.HOME
                                    }
                                },
                                onShuffleAll = { if(visibleTracks.isNotEmpty()){requestNotificationIfNeeded();shuffleMode="normal";store.shuffleMode=shuffleMode;store.shuffle=true;service?.setShuffle(false);service?.setQueue(visibleTracks.shuffled().map{it.queue},0,true);section=PlayerSection.HOME} },
                                onAzAll = { if(visibleTracks.isNotEmpty()){requestNotificationIfNeeded();shuffleMode="az";store.shuffleMode=shuffleMode;store.shuffle=true;service?.setShuffle(false);service?.setQueue(alternateExtremes(visibleTracks.sortedBy{it.queue.title.lowercase()}).map{it.queue},0,true);section=PlayerSection.HOME} },
                                onSmartAll = { if(visibleTracks.isNotEmpty()){requestNotificationIfNeeded();shuffleMode="smart";store.shuffleMode=shuffleMode;store.shuffle=true;service?.setShuffle(false);service?.setQueue(smartArtistShuffle(visibleTracks).map{it.queue},0,true);section=PlayerSection.HOME} }
                            )
                        }
                        PlayerSection.FOLDERS -> PullToRefreshBox(
                            isRefreshing = libraryScanInProgress,
                            onRefresh = { refreshLibrary(showLoading = true) }
                        ) {
                            GroupBrowser(
                                "Pastas", tracks, { it.folder }, selectedGroup, { selectedGroup = it }, playback.current?.uri,
                                onPlay = { playTrack(service, tracks, it, onTrack) },
                                onPlayInGroup = { folderTracks, track ->
                                    requestNotificationIfNeeded()
                                    folderTracks.firstOrNull()?.folder?.let { libraryScope = PlayerLibraryScope.Folder(it) }
                                    store.shuffle = false
                                    service?.setShuffle(false)
                                    playTrack(service, folderTracks, track, onTrack)
                                    section = PlayerSection.HOME
                                },
                                sortMode = librarySortMode,
                                onSortMode = { mode -> librarySortMode = mode; store.librarySortMode = mode },
                                onPlayGroup = { list, mode ->
                                    val arranged = when (mode) {
                                        "shuffle" -> list.shuffled()
                                        "extremes" -> alternateExtremes(list)
                                        "smart" -> smartArtistShuffle(list)
                                        else -> list
                                    }
                                    if (arranged.isNotEmpty()) {
                                        requestNotificationIfNeeded()
                                        list.firstOrNull()?.folder?.let { libraryScope = PlayerLibraryScope.Folder(it) }
                                        // A fila já foi ordenada localmente; manter o shuffle interno desligado
                                        // impede reconstrução da fila e garante que nenhuma faixa externa entre.
                                        store.shuffle = mode == "shuffle"
                                        service?.setShuffle(false)
                                        service?.setQueue(arranged.map { it.queue }, 0, true)
                                        onTrack("SONUS PLAYER: pasta • $mode", true, null)
                                        section = PlayerSection.HOME
                                    }
                                }
                            )
                        }
                        PlayerSection.ALBUMS -> GroupBrowser("Álbuns", tracks, { it.queue.album.ifBlank { "Sem álbum" } }, selectedGroup, { selectedGroup = it }, playback.current?.uri, onPlay = { playTrack(service, tracks, it, onTrack) })
                        PlayerSection.ARTISTS -> GroupBrowser("Artistas", tracks, { it.queue.artist.ifBlank { "Artista desconhecido" } }, selectedGroup, { selectedGroup = it }, playback.current?.uri, onPlay = { playTrack(service, tracks, it, onTrack) })
                        PlayerSection.GENRES -> GroupBrowser("Gêneros", tracks, { it.queue.genre.ifBlank { "Sem gênero" } }, selectedGroup, { selectedGroup = it }, playback.current?.uri, onPlay = { playTrack(service, tracks, it, onTrack) })
                        PlayerSection.LIKED -> TrackBrowser("Músicas curtidas", tracks.filter { it.queue.uri in liked }, query, { query = it }, playback.current?.uri, { playTrack(service, tracks, it, onTrack) }, liked, { u -> liked = toggleSet(liked,u);store.liked=liked })
                        PlayerSection.PINNED -> TrackBrowser("Músicas fixadas", tracks.filter { it.queue.uri in pinned }, query, { query = it }, playback.current?.uri, { playTrack(service, tracks, it, onTrack) }, liked, { u -> liked = toggleSet(liked,u);store.liked=liked })
                        PlayerSection.RECENT -> TrackBrowser("Adicionadas recentemente", tracks.sortedByDescending { it.lastModified }, query, { query=it }, playback.current?.uri, { playTrack(service, tracks, it, onTrack) }, liked, {u->liked=toggleSet(liked,u);store.liked=liked})
                        PlayerSection.TOP -> StatsTopTracks(statsStore, tracks, playback.current?.uri) { playTrack(service, tracks, it, onTrack) }
                        PlayerSection.PLAYLISTS -> PlaylistScreen(playlists, tracks, playback.current, onCreate = { name -> playlists = store.createPlaylist(name); }, onAddCurrent = { name -> playback.current?.let { playlists = store.addToPlaylist(name, it.uri) } }, onPlay = { name -> val uris=playlists[name].orEmpty(); val list=tracks.filter{it.queue.uri in uris}; if(list.isNotEmpty()) service?.setQueue(list.map{it.queue},0,true) })
                        PlayerSection.QUEUE -> QueueScreen(playback, service)
                        PlayerSection.STATS -> StatisticsScreen(
                            store = statsStore,
                            playback = playback,
                            revision = statsRevision,
                            tracks = tracks,
                            liked = liked,
                            onPlayList = { list -> if (list.isNotEmpty()) { requestNotificationIfNeeded(); service?.setQueue(list.map { it.queue }, 0, true) } },
                            onRefresh = { statsRevision++ },
                            onClear = { statsStore.clear(); statsRevision++ }
                        )
                        PlayerSection.ONLINE -> SonusOnlineMusicScreen(
                            accent = selectedTheme.glow,
                            service = service,
                            membershipTier = membershipTier,
                            onRequestPlan = onRequestPlan,
                            onTrack = onTrack,
                            onCreatorCenter = onStreamCreator
                        ) {
                            onOpenFullPlayerFromStream?.invoke() ?: run { section = PlayerSection.HOME }
                        }
                        // Letras continua suportada internamente para arquivos .lrc, mas não ocupa o menu principal.
                        PlayerSection.LYRICS -> LyricsScreen(context, tracks.firstOrNull { it.queue.uri == playback.current?.uri }, playback.current, playback.positionMs, playback.durationMs, membershipTier, preferences)
                        // Recursos YouTube são acessados diretamente pela Home do Player, não pelo menu lateral.
                        PlayerSection.YOUTUBE_PLAYLISTS -> YouTubePlaylistHubScreen(selectedTheme.glow)
                        PlayerSection.YOUTUBE -> PulsePlayerYouTubeScreen(selectedTheme.glow)
                        PlayerSection.EQ -> EqualizerScreen(
                            service = service,
                            playback = playback,
                            currentTrack = tracks.firstOrNull { it.queue.uri == playback.current?.uri },
                            pulseLiftAccess = pulseLiftAccess,
                            pulseOrbit3dAccess = pulseOrbit3dAccess,
                            pulseOrbit8dAccess = pulseOrbit8dAccess,
                            onUnlockFeature24h = onUnlockFeature24h,
                            onTrack = onTrack,
                            membershipTier = membershipTier,
                            ownerUnlimited = ownerUnlimited,
                            spectrumFlow = service?.spectrum ?: fallbackSpectrum,
                            playerTheme = selectedTheme,
                            onRequestPlan = onRequestPlan
                        )
                        PlayerSection.THEMES -> ThemesScreen(PulsePlayerThemes, membershipTier, selectedThemeId) { spec -> selectedThemeId = spec.id; store.themeId = spec.id; onTrack("SONUS PLAYER: tema ${spec.name}", true, null) }
                        PlayerSection.CREATOR -> CreatorModeScreen(playback.current, onCreatorAction)
                        PlayerSection.SETTINGS -> PlayerSettingsScreen(
                            store, playback, membershipTier, ownerUnlimited,
                            reduceAnimations, { reduceAnimations=it;store.reduceAnimations=it },
                            service,
                            playerInterfaceId, { id -> playerInterfaceId=id;store.playerInterfaceId=id },
                            visualizerId, { id -> visualizerId=id;store.visualizerId=id },
                            visualizerIntensity, { value -> visualizerIntensity=value;store.visualizerIntensity=value },
                            visualizerSensitivity, { value -> visualizerSensitivity=value;store.visualizerSensitivity=value },
                            visualizerSmoothness, { value -> visualizerSmoothness=value;store.visualizerSmoothness=value },
                            visualizerEnabled, { value -> visualizerEnabled=value;store.visualizerEnabled=value },
                            keepScreenOn, { value -> keepScreenOn=value;store.keepScreenOn=value },
                            onOpenThemes = { section = PlayerSection.THEMES },
                            treePicker = {treePicker.launch(null)}, rescan={store.rootUri?.let{scan(Uri.parse(it),false)}}, clearStats={statsStore.clear();statsRevision++}
                        )
                    }
                }
            }
            SonusDataUsageMiniMonitor(streamExperience.dataMonitor,Modifier.align(Alignment.TopEnd).padding(top=8.dp,end=8.dp))
        }
    }
}

private fun playTrack(service: PulsePlayerService?, library: List<PulseLibraryTrack>, track: PulseLibraryTrack, onTrack:(String,Boolean?,Long?)->Unit) {
    val idx = library.indexOfFirst { it.queue.uri == track.queue.uri }.coerceAtLeast(0)
    service?.setQueue(library.map { it.queue }, idx, false)
    service?.playIndex(idx)
}

@Composable private fun PulsePlayerBackdrop(theme: PlayerThemeSpec, reduce: Boolean) {
    val transition = rememberInfiniteTransition(label="pulse-player-bg")
    val phase by transition.animateFloat(0f,1f,infiniteRepeatable(tween(if(reduce) 40000 else 9000, easing=LinearEasing),RepeatMode.Restart),label="phase")
    Canvas(Modifier.fillMaxSize()) {
        drawRect(Brush.linearGradient(theme.colors, Offset.Zero, Offset(size.width,size.height)))
        val p = if (reduce) .35f else phase
        val x = size.width * (.1f + .8f * p)
        val y = size.height * (.18f + .1f * kotlin.math.sin(p * Math.PI * 2).toFloat())
        drawCircle(Brush.radialGradient(listOf(theme.glow.copy(alpha=.30f), Color.Transparent), center=Offset(x,y), radius=size.width*.55f), radius=size.width*.55f, center=Offset(x,y))

    }
}

@Composable private fun PulseHome(
    tracks: List<PulseLibraryTrack>, playback: PulsePlayerPlaybackState, spectrumFlow: kotlinx.coroutines.flow.StateFlow<List<Float>>, theme: PlayerThemeSpec,
    playerInterface: PlayerInterfaceSpec, visualizer: PlayerVisualizerSpec,
    visualizerEnabled: Boolean, visualizerIntensity: Int, visualizerSensitivity: Float, visualizerSmoothness: Int,
    loading:Boolean, message:String?,
    showFolderPrompt:Boolean, onDismissFolderPrompt:()->Unit,
    onChooseFolder:()->Unit, onToggle:()->Unit,onPrevious:()->Unit,onNext:()->Unit,
    onSeek:(Long)->Unit,onShuffle:()->Unit,onRepeat:()->Unit,onRadioDelay:(Long)->Unit,
    liked:Set<String>,onLike:(String)->Unit,pinned:Set<String>,onPin:(String)->Unit,
    onEqualizer:()->Unit,onLibrary:()->Unit,onYouTube:()->Unit,onYouTubePlaylists:()->Unit,onShare:()->Unit,shareEnabled:Boolean,onStats:()->Unit,onLyrics:()->Unit,onPulseLift:()->Unit
) {
    BoxWithConstraints(Modifier.fillMaxSize().padding(horizontal=14.dp, vertical=6.dp)) {
        val compact = maxHeight < 650.dp
        Column(Modifier.fillMaxSize(), verticalArrangement=Arrangement.spacedBy(if(compact) 5.dp else 7.dp)) {
            if (showFolderPrompt) {
                Surface(
                    shape=RoundedCornerShape(14.dp),
                    color=Color.Black.copy(alpha=.26f),
                    border=BorderStroke(1.dp,theme.glow.copy(alpha=.32f)),
                    modifier=Modifier.fillMaxWidth()
                ) {
                    Row(Modifier.padding(horizontal=10.dp,vertical=6.dp),verticalAlignment=Alignment.CenterVertically) {
                        Icon(Icons.Default.FolderOpen,null,tint=theme.glow,modifier=Modifier.size(17.dp))
                        Spacer(Modifier.width(7.dp))
                        Text("Biblioteca local",fontSize=10.sp,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f))
                        TextButton(onClick=onChooseFolder,contentPadding=PaddingValues(horizontal=7.dp,vertical=0.dp)) { Text("Selecionar",fontSize=9.sp) }
                        Switch(checked=true,onCheckedChange={ enabled -> if(!enabled) onDismissFolderPrompt() },modifier=Modifier.height(28.dp))
                    }
                }
            }
            if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
            if (tracks.isEmpty() && (showFolderPrompt || loading)) message?.let { Text(it, style=MaterialTheme.typography.bodySmall, color=Color.White.copy(alpha=.60f), maxLines=1, overflow=TextOverflow.Ellipsis) }
            playback.current?.let { item ->
                Box(Modifier.weight(1f, fill=true)) {
                    NowPlayingCard(
                        item=item,track=tracks.firstOrNull { it.queue.uri == item.uri },state=playback,spectrumFlow=spectrumFlow,theme=theme,playerInterface=playerInterface,visualizer=visualizer,
                        visualizerEnabled=visualizerEnabled,visualizerIntensity=visualizerIntensity,
                        visualizerSensitivity=visualizerSensitivity,visualizerSmoothness=visualizerSmoothness,
                        onToggle=onToggle,
                        onPrevious=onPrevious,onNext=onNext,onSeek=onSeek,onShuffle=onShuffle,onRepeat=onRepeat,onRadioDelay=onRadioDelay,
                        liked=liked,onLike=onLike,pinned=pinned,onPin=onPin,onLyrics=onLyrics,onStats=onStats,
                        onLibrary=onLibrary,onEqualizer=onEqualizer,compact=compact
                    )
                }
            } ?: run {
                if (tracks.isNotEmpty()) {
                    Card(
                        colors=CardDefaults.cardColors(containerColor=Color.Black.copy(alpha=.28f)),
                        border=BorderStroke(1.dp,theme.glow.copy(alpha=.32f)),
                        modifier=Modifier.weight(1f).fillMaxWidth()
                    ) { Box(Modifier.fillMaxSize(), contentAlignment=Alignment.Center) { Text("Selecione uma música na Biblioteca", color=Color.White.copy(alpha=.68f)) } }
                }
            }
            playback.errorMessage?.takeIf { it.isNotBlank() }?.let { error ->
                Surface(shape=RoundedCornerShape(12.dp),color=Color(0xFF5A1720).copy(alpha=.72f),border=BorderStroke(1.dp,Color(0xFFFF6B78).copy(alpha=.50f)),modifier=Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(horizontal=10.dp,vertical=7.dp),verticalAlignment=Alignment.CenterVertically){
                        Icon(Icons.Default.ErrorOutline,null,tint=Color(0xFFFF8E98),modifier=Modifier.size(17.dp));Spacer(Modifier.width(7.dp));Text(error,color=Color.White,fontSize=10.sp,fontWeight=FontWeight.SemiBold)
                    }
                }
            }
            // Ações rápidas do Player: sem duplicar a aba Stream da navegação principal.
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(9.dp), verticalAlignment=Alignment.CenterVertically) {
                PlayerQuickAction(Icons.Default.PlaylistPlay, "Playlist YouTube", Color(0xFF54E3A8), onYouTubePlaylists, Modifier.weight(1f), emphasized = true)
                PlayerShareAction(onClick = onShare, enabled = shareEnabled)
                PlayerQuickAction(Icons.Default.SmartDisplay, "YouTube", Color(0xFFFF5C62), onYouTube, Modifier.weight(1f), emphasized = true)
            }
        }
    }
}


@Composable
private fun PlayerShareAction(onClick:()->Unit, enabled:Boolean) {
    val transition = rememberInfiniteTransition(label = "share-neon")
    val angle by transition.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(4200, easing = LinearEasing), RepeatMode.Restart),
        label = "share-angle"
    )
    Box(
        modifier = Modifier.size(60.dp).clip(CircleShape).clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier.matchParentSize().graphicsLayer(rotationZ = angle)
                .background(
                    Brush.sweepGradient(
                        listOf(Color(0xFF00E5FF), Color(0xFF1A73FF), Color(0xFF8C4DFF), Color(0xFF00E5FF))
                    ), CircleShape
                )
        )
        Surface(
            modifier = Modifier.size(54.dp), shape = CircleShape,
            color = Color(0xFF071D45).copy(alpha = if (enabled) .82f else .38f),
            border = BorderStroke(1.dp, Color.White.copy(alpha = if (enabled) .48f else .18f)),
            shadowElevation = if (enabled) 9.dp else 0.dp
        ) {
            Box(
                Modifier.fillMaxSize().background(Brush.radialGradient(listOf(Color.White.copy(alpha=.16f), Color.Transparent))),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(R.drawable.social_edit_icon),
                    contentDescription = "SOCIAL EDIT",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.size(38.dp).clip(RoundedCornerShape(11.dp)).graphicsLayer(alpha = if (enabled) 1f else .38f)
                )
            }
        }
    }
}

@Composable private fun PlayerQuickAction(icon:ImageVector,label:String,tint:Color,onClick:()->Unit,modifier:Modifier=Modifier,compact:Boolean=false,emphasized:Boolean=false) {
    Surface(
        modifier=modifier.height(if(emphasized) 56.dp else if(compact) 42.dp else 48.dp).clickable(onClick=onClick),
        shape=RoundedCornerShape(if(emphasized) 18.dp else 14.dp),
        color=if(emphasized) tint.copy(alpha=.14f) else Color.Black.copy(alpha=.30f),
        border=BorderStroke(if(emphasized) 1.4.dp else 1.dp,tint.copy(alpha=if(emphasized) .62f else .28f))
    ) {
        Row(Modifier.fillMaxSize().padding(horizontal=10.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.Center) {
            Icon(icon,null,tint=tint,modifier=Modifier.size(if(emphasized) 22.dp else if(compact) 17.dp else 19.dp))
            Spacer(Modifier.width(if(emphasized) 8.dp else 5.dp))
            Text(label,fontSize=if(emphasized) 12.sp else if(compact) 9.sp else 10.sp,fontWeight=FontWeight.Black,maxLines=1,overflow=TextOverflow.Ellipsis,color=Color.White.copy(alpha=.96f))
        }
    }
}

@Composable
private fun NowPlayingCard(
    item: PulsePlayerQueueItem,
    track: PulseLibraryTrack?,
    state: PulsePlayerPlaybackState,
    spectrumFlow: kotlinx.coroutines.flow.StateFlow<List<Float>>,
    theme: PlayerThemeSpec,
    playerInterface: PlayerInterfaceSpec,
    visualizer: PlayerVisualizerSpec,
    visualizerEnabled: Boolean,
    visualizerIntensity: Int,
    visualizerSensitivity: Float,
    visualizerSmoothness: Int,
    onToggle: () -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    onSeek: (Long) -> Unit,
    onShuffle: () -> Unit,
    onRepeat: () -> Unit,
    onRadioDelay: (Long) -> Unit,
    liked: Set<String>,
    onLike: (String) -> Unit,
    pinned: Set<String>,
    onPin: (String) -> Unit,
    onLyrics: () -> Unit,
    onStats: () -> Unit,
    onLibrary: () -> Unit,
    onEqualizer: () -> Unit,
    compact: Boolean = false
) {
    val context = LocalContext.current
    val artwork by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, item.uri) {
        value = withContext(Dispatchers.IO) {
            if (SonusOnlineRef.parse(item.uri) != null) loadSonusOnlineArtwork(context, item.uri)
            else loadArtwork(context, Uri.parse(item.uri))
        }
    }
    val coverColors by produceState<List<Color>>(emptyList(), item.uri) {
        value = withContext(Dispatchers.IO) {
            if (SonusOnlineRef.parse(item.uri) != null) emptyList()
            else loadArtworkPalette(context, Uri.parse(item.uri))
        }
    }
    val busLyricsLine by SonusLiveLyricsBus.line.collectAsState()
    var playerLyricsText by remember(item.uri, track?.lrcUri) { mutableStateOf<String?>(null) }
    var playerLyricsFormat by remember(item.uri, track?.lrcUri) { mutableStateOf("TEXT") }
    LaunchedEffect(item.uri, track?.lrcUri) {
        SonusLiveLyricsBus.clear()
        playerLyricsText = null
        playerLyricsFormat = "TEXT"
        val onlineRef = SonusOnlineRef.parse(item.uri)
        if (onlineRef != null) {
            val repo = SonusOnlineMusicRepository(context)
            withContext(Dispatchers.IO) { runCatching { repo.refreshTrackOverrides() } }
            val lyrics = repo.lyricsForFileIdAuto(onlineRef.fileId)
            playerLyricsText = lyrics?.first
            playerLyricsFormat = lyrics?.second?.uppercase() ?: "TEXT"
        } else {
            val sidecar = track?.lrcUri
            if (!sidecar.isNullOrBlank()) {
                playerLyricsText = withContext(Dispatchers.IO) {
                    runCatching {
                        context.contentResolver.openInputStream(Uri.parse(sidecar))?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                    }.getOrNull()
                }
                playerLyricsFormat = "LRC"
            }
        }
    }
    val liveLyricsLine = remember(playerLyricsText, playerLyricsFormat, state.positionMs, busLyricsLine) {
        val text = playerLyricsText.orEmpty()
        when {
            playerLyricsFormat == "LRC" && text.isNotBlank() -> sonusLrcLineAt(text, state.positionMs).orEmpty()
            text.isNotBlank() -> text.lineSequence().map { it.trim() }.firstOrNull { it.isNotBlank() }.orEmpty()
            else -> busLyricsLine
        }
    }
    val onlineRefForCount = remember(item.uri) { SonusOnlineRef.parse(item.uri) }
    val radioMode = item.source.startsWith("SONUS Rádio")
    val radioDelayMs = if (radioMode) SonusRadioEngine.delayFromLive(context, state.queue, state.index, state.positionMs) else 0L
    val radioWindowMs = if (radioMode) SonusRadioEngine.rewindWindowMs(state.queue) else SonusRadioEngine.MAX_REWIND_MS
    val streamPlatform = remember { com.sonusstudios.streampulse.stream.SonusStreamPlatformRepository(context) }
    val streamPlayCount by remember(onlineRefForCount?.fileId) { onlineRefForCount?.let { streamPlatform.playCountFlow(it.fileId) } ?: kotlinx.coroutines.flow.flowOf(-1L) }.collectAsState(initial=-1L)
    Box(Modifier.fillMaxSize()) {
        SonusPlayerInterface(
            spec = playerInterface,
            item = item,
            state = state,
            spectrumFlow = spectrumFlow,
            artwork = artwork,
            coverColors = coverColors,
            themeColors = theme.colors,
            accent = theme.glow,
            visualizer = visualizer,
            visualizerEnabled = visualizerEnabled,
            intensityPercent = visualizerIntensity,
            sensitivity = visualizerSensitivity,
            smoothness = visualizerSmoothness,
            liked = liked,
            pinned = pinned,
            onToggle = onToggle,
            onPrevious = onPrevious,
            onNext = onNext,
            onSeek = onSeek,
            onShuffle = onShuffle,
            onRepeat = onRepeat,
            onLike = onLike,
            onPin = onPin,
            onLyrics = onLyrics,
            onStats = onStats,
            onLibrary = onLibrary,
            onEqualizer = onEqualizer,
            lyricsLine = liveLyricsLine,
            streamPlayCount = streamPlayCount.takeIf { onlineRefForCount != null && it >= 0L },
            radioMode = radioMode,
            radioDelayMs = radioDelayMs,
            radioWindowMs = radioWindowMs,
            onRadioDelay = onRadioDelay,
            compact = compact,
            modifier = Modifier.fillMaxSize()
        )
    }
}

@Composable
private fun TrackBrowser(
    title:String,
    tracks:List<PulseLibraryTrack>,
    query:String,
    onQuery:(String)->Unit,
    current:String?,
    onPlay:(PulseLibraryTrack)->Unit,
    liked:Set<String>,
    onLike:(String)->Unit,
    sortMode:LibrarySortMode?=null,
    onSortMode:((LibrarySortMode)->Unit)?=null,
    onPlayAll:(()->Unit)?=null,
    onShuffleAll:(()->Unit)?=null,
    onAzAll:(()->Unit)?=null,
    onSmartAll:(()->Unit)?=null
){
    LazyColumn(Modifier.fillMaxSize().padding(horizontal=16.dp),verticalArrangement=Arrangement.spacedBy(7.dp),contentPadding=PaddingValues(bottom=24.dp)){
        item{
            Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
                Text(title,fontWeight=FontWeight.Black,fontSize=22.sp,modifier=Modifier.weight(1f))
                if(sortMode!=null && onSortMode!=null) LibrarySortControl(sortMode,onSortMode)
            }
        }
        if(onPlayAll!=null || onShuffleAll!=null){
            item{
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly,verticalAlignment=Alignment.CenterVertically){
                    FilledIconButton(onClick={onPlayAll?.invoke()},enabled=tracks.isNotEmpty(),colors=IconButtonDefaults.filledIconButtonColors(containerColor=Color(0xFF2FAE70)),modifier=Modifier.size(46.dp)){Icon(Icons.Default.PlayArrow,"Reproduzir")}
                    FilledTonalButton(onClick={onShuffleAll?.invoke()},enabled=tracks.isNotEmpty(),contentPadding=PaddingValues(horizontal=10.dp)){Icon(Icons.Default.Shuffle,null,modifier=Modifier.size(18.dp));Spacer(Modifier.width(3.dp));Text("Aleatório",fontSize=10.sp)}
                    FilledTonalButton(onClick={onAzAll?.invoke()},enabled=tracks.isNotEmpty(),contentPadding=PaddingValues(horizontal=9.dp)){Icon(Icons.Default.Shuffle,null,modifier=Modifier.size(16.dp));Text("A-Z",fontSize=9.sp,fontWeight=FontWeight.Black)}
                    FilledTonalButton(onClick={onSmartAll?.invoke()},enabled=tracks.isNotEmpty(),colors=ButtonDefaults.filledTonalButtonColors(containerColor=Color(0xFF7753B5).copy(alpha=.65f)),contentPadding=PaddingValues(horizontal=10.dp)){Icon(Icons.Default.AutoAwesome,null,modifier=Modifier.size(17.dp));Spacer(Modifier.width(2.dp));Text("Inteligente",fontSize=9.sp)}
                }
            }
        }
        item{OutlinedTextField(query,onQuery,leadingIcon={Icon(Icons.Default.Search,null)},singleLine=true,modifier=Modifier.fillMaxWidth(),placeholder={Text("Buscar")})}
        val displayTracks = if(sortMode!=null) tracks else filterTracks(tracks,query)
        items(displayTracks,key={it.queue.uri}){TrackRow(it,it.queue.uri==current,{onPlay(it)},it.queue.uri in liked,{onLike(it.queue.uri)})}
    }
}

@Composable
private fun LibrarySortControl(selected:LibrarySortMode,onSelected:(LibrarySortMode)->Unit){
    var expanded by remember { mutableStateOf(false) }
    Box {
        FilledTonalIconButton(onClick={expanded=true}){Icon(Icons.Default.Sort,"Organizar")}
        DropdownMenu(expanded=expanded,onDismissRequest={expanded=false}){
            LibrarySortMode.entries.forEach { mode ->
                DropdownMenuItem(
                    text={Text(mode.label,fontWeight=if(mode==selected)FontWeight.Black else FontWeight.Normal)},
                    leadingIcon={if(mode==selected)Icon(Icons.Default.Check,null)},
                    onClick={expanded=false;onSelected(mode)}
                )
            }
        }
    }
}

@Composable private fun TrackRow(track:PulseLibraryTrack,active:Boolean,onPlay:()->Unit,liked:Boolean,onLike:()->Unit){Surface(shape=RoundedCornerShape(15.dp),color=if(active)MaterialTheme.colorScheme.primaryContainer.copy(alpha=.72f) else Color.Black.copy(alpha=.22f),modifier=Modifier.fillMaxWidth().clickable(onClick=onPlay)){Row(Modifier.padding(10.dp),verticalAlignment=Alignment.CenterVertically){Surface(Modifier.size(44.dp),shape=RoundedCornerShape(12.dp),color=MaterialTheme.colorScheme.primary.copy(alpha=.16f)){Box(contentAlignment=Alignment.Center){Icon(if(active)Icons.Default.GraphicEq else Icons.Default.MusicNote,null,tint=MaterialTheme.colorScheme.primary)}};Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(track.queue.title,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis);Text(listOf(track.queue.artist,track.queue.album).filter{it.isNotBlank()}.joinToString(" • ").ifBlank{track.folder},style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.58f),maxLines=1,overflow=TextOverflow.Ellipsis)};IconButton(onClick=onLike){Icon(if(liked)Icons.Default.Favorite else Icons.Default.FavoriteBorder,null,tint=if(liked)Color(0xFFFF5D7A) else MaterialTheme.colorScheme.onSurface.copy(alpha=.55f))}}}}

@Composable private fun GroupBrowser(
    title:String, tracks:List<PulseLibraryTrack>, key:(PulseLibraryTrack)->String,
    selected:String?, onSelected:(String?)->Unit, current:String?,
    onPlay:(PulseLibraryTrack)->Unit,
    onPlayInGroup:((List<PulseLibraryTrack>,PulseLibraryTrack)->Unit)?=null,
    sortMode:LibrarySortMode?=null,
    onSortMode:((LibrarySortMode)->Unit)?=null,
    onPlayGroup:((List<PulseLibraryTrack>,String)->Unit)?=null
){
    val groups = remember(tracks) {
        runCatching {
            tracks.groupBy { track -> key(track).trim().ifBlank { "Sem pasta" } }
                .toList().sortedBy { it.first.lowercase(java.util.Locale.getDefault()) }.toMap()
        }.getOrElse { emptyMap() }
    }
    val selectedTracks = selected?.let { groups[it] }.orEmpty()
    var groupQuery by remember(selected) { mutableStateOf("") }
    val visibleSelectedTracks = remember(selectedTracks, groupQuery, sortMode) {
        val filtered = filterTracks(selectedTracks, groupQuery)
        if (sortMode != null) sortLibraryTracks(filtered, sortMode) else filtered
    }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal=16.dp),verticalArrangement=Arrangement.spacedBy(8.dp),contentPadding=PaddingValues(bottom=24.dp)){
        item{Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.fillMaxWidth()){if(selected!=null)IconButton(onClick={onSelected(null)}){Icon(Icons.Default.ArrowBack,null)};Text(selected?:title,fontWeight=FontWeight.Black,fontSize=22.sp,modifier=Modifier.weight(1f));if(selected!=null&&sortMode!=null&&onSortMode!=null)LibrarySortControl(sortMode,onSortMode)}}
        if(selected==null) items(groups.entries.toList()){(name,list)->Surface(shape=RoundedCornerShape(16.dp),color=Color.Black.copy(alpha=.24f),modifier=Modifier.fillMaxWidth().clickable{onSelected(name)}){Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.FolderCopy,null);Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(name,fontWeight=FontWeight.Bold);Text("${list.size} música(s)",style=MaterialTheme.typography.bodySmall)};Icon(Icons.Default.ChevronRight,null)}}}
        else {
            item { OutlinedTextField(groupQuery,{groupQuery=it},leadingIcon={Icon(Icons.Default.Search,null)},singleLine=true,modifier=Modifier.fillMaxWidth(),placeholder={Text("Buscar nesta pasta")}) }
            if(onPlayGroup!=null) item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(5.dp)) {
                    FilledTonalButton(onClick={onPlayGroup(visibleSelectedTracks,"all")},modifier=Modifier.weight(1f),contentPadding=PaddingValues(horizontal=5.dp,vertical=7.dp)) {
                        Icon(Icons.Default.PlayArrow,null,Modifier.size(15.dp)); Spacer(Modifier.width(2.dp)); Text("Tocar tudo",fontSize=8.sp,maxLines=1)
                    }
                    OutlinedButton(onClick={onPlayGroup(visibleSelectedTracks,"shuffle")},modifier=Modifier.weight(1f),contentPadding=PaddingValues(horizontal=4.dp,vertical=7.dp)) {
                        Icon(Icons.Default.Shuffle,null,Modifier.size(14.dp)); Spacer(Modifier.width(2.dp)); Text("Aleatório",fontSize=8.sp,maxLines=1)
                    }
                    OutlinedButton(onClick={onPlayGroup(visibleSelectedTracks,"extremes")},modifier=Modifier.weight(1f),contentPadding=PaddingValues(horizontal=4.dp,vertical=7.dp)) {
                        Icon(Icons.Default.SwapVert,null,Modifier.size(14.dp)); Spacer(Modifier.width(2.dp)); Text("Extremos",fontSize=8.sp,maxLines=1)
                    }
                    OutlinedButton(onClick={onPlayGroup(visibleSelectedTracks,"smart")},modifier=Modifier.weight(1f),contentPadding=PaddingValues(horizontal=4.dp,vertical=7.dp)) {
                        Icon(Icons.Default.AutoAwesome,null,Modifier.size(14.dp)); Spacer(Modifier.width(2.dp)); Text("Inteligente",fontSize=7.sp,maxLines=1)
                    }
                }
            }
            items(visibleSelectedTracks,key={it.queue.uri}){t->TrackRow(t,t.queue.uri==current,{onPlayInGroup?.invoke(visibleSelectedTracks,t) ?: onPlay(t)},false,{})}
        }
    }
}

private fun alternateExtremes(list:List<PulseLibraryTrack>):List<PulseLibraryTrack>{
    if(list.size<3)return list
    val out=ArrayList<PulseLibraryTrack>(list.size);var a=0;var b=list.lastIndex
    while(a<=b){out+=list[a++];if(a<=b)out+=list[b--]}
    return out
}

private fun smartArtistShuffle(list:List<PulseLibraryTrack>):List<PulseLibraryTrack>{
    if(list.size<3)return list.shuffled()
    val remaining=list.shuffled().toMutableList();val out=mutableListOf<PulseLibraryTrack>();var last=""
    while(remaining.isNotEmpty()){
        val idx=remaining.indexOfFirst{it.queue.artist.ifBlank{"__unknown_${it.queue.uri}"}!=last}.let{if(it<0)0 else it}
        val item=remaining.removeAt(idx);out+=item;last=item.queue.artist.ifBlank{"__unknown_${item.queue.uri}"}
    }
    return out
}

@Composable private fun StatsTopTracks(store:PulsePlayerStatsStore,tracks:List<PulseLibraryTrack>,current:String?,onPlay:(PulseLibraryTrack)->Unit){val snap=remember{store.snapshot(30)};val ordered=snap.topTracks.mapNotNull{s->tracks.firstOrNull{it.queue.uri==s.uri}};TrackBrowser("Mais tocadas",ordered,"",{},current,onPlay,emptySet(),{})}

@Composable private fun PlaylistScreen(playlists:Map<String,List<String>>,tracks:List<PulseLibraryTrack>,current:PulsePlayerQueueItem?,onCreate:(String)->Unit,onAddCurrent:(String)->Unit,onPlay:(String)->Unit){var newName by remember{mutableStateOf("")};LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){item{Text("Playlists",fontWeight=FontWeight.Black,fontSize=22.sp)};item{Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(newName,{newName=it.take(40)},label={Text("Nova playlist")},singleLine=true,modifier=Modifier.weight(1f));IconButton(onClick={if(newName.isNotBlank()){onCreate(newName.trim());newName=""}}){Icon(Icons.Default.AddCircle,null)}}};items(playlists.entries.toList()){(name,uris)->Card{Column(Modifier.padding(13.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(name,fontWeight=FontWeight.Bold);Text("${uris.size} música(s)",style=MaterialTheme.typography.bodySmall)};IconButton(onClick={onPlay(name)}){Icon(Icons.Default.PlayArrow,null)}};if(current!=null&&current.uri !in uris)TextButton(onClick={onAddCurrent(name)}){Icon(Icons.Default.PlaylistAdd,null);Spacer(Modifier.width(5.dp));Text("Adicionar música atual")}}}}}}

@Composable
private fun StatisticsScreen(
    store: PulsePlayerStatsStore,
    playback: PulsePlayerPlaybackState,
    revision: Int,
    tracks: List<PulseLibraryTrack>,
    liked: Set<String>,
    onPlayList: (List<PulseLibraryTrack>) -> Unit,
    onRefresh: () -> Unit,
    onClear: () -> Unit
) {
    val context = LocalContext.current
    var period by remember { mutableStateOf("Mês") }
    var customStart by remember { mutableStateOf<java.time.LocalDate?>(null) }
    var customEnd by remember { mutableStateOf<java.time.LocalDate?>(null) }
    var expandedRankings by remember { mutableStateOf<Set<String>>(emptySet()) }
    val today = java.time.LocalDate.now()
    val range = remember(period, customStart, customEnd, revision) {
        when (period) {
            "Hoje" -> today to today
            "7 dias" -> today.minusDays(6) to today
            "Mês" -> today.withDayOfMonth(1) to today
            "30 dias" -> today.minusDays(29) to today
            "90 dias" -> today.minusDays(89) to today
            "6 meses" -> today.minusMonths(6).plusDays(1) to today
            "1 ano" -> today.minusYears(1).plusDays(1) to today
            "Personalizado" -> (customStart ?: today) to (customEnd ?: customStart ?: today)
            else -> null
        }
    }
    val snapshot = remember(range, revision, period) { range?.let { store.snapshot(it.first, it.second, 500) } ?: store.snapshot(500) }
    val previousSnapshot = remember(range, revision) {
        range?.let { r ->
            val days = java.time.temporal.ChronoUnit.DAYS.between(r.first, r.second).coerceAtLeast(0) + 1
            val prevEnd = r.first.minusDays(1)
            val prevStart = prevEnd.minusDays(days - 1)
            store.snapshot(prevStart, prevEnd, 500)
        }
    }
    val completionRate = if (snapshot.totalPlays > 0) (snapshot.totalCompleted * 100.0 / snapshot.totalPlays).coerceIn(0.0,100.0) else 0.0
    val skipRate = if (snapshot.totalPlays > 0) (snapshot.totalSkips * 100.0 / snapshot.totalPlays).coerceIn(0.0,100.0) else 0.0
    val comparison = previousSnapshot?.takeIf { it.totalListeningMs > 0 }?.let {
        ((snapshot.totalListeningMs - it.totalListeningMs) * 100.0 / it.totalListeningMs).coerceIn(-999.0,999.0)
    }
    val uniqueArtists = snapshot.topTracks.map { it.artist }.filter { it.isNotBlank() }.distinct().size
    val uniqueTracks = snapshot.topTracks.size
    val avgPerPlay = if (snapshot.totalPlays > 0) snapshot.totalListeningMs / snapshot.totalPlays else 0L
    val mostRepeated = snapshot.topTracks.maxByOrNull { it.plays }
    val daily = snapshot.dailyMinutes
    val topGenre = snapshot.topGenres.firstOrNull()?.first
    val topArtist = snapshot.topArtists.firstOrNull()?.first

    fun chooseCustomDate() {
        val now = java.util.Calendar.getInstance()
        android.app.DatePickerDialog(context,{_,y,m,d->
            val first=java.time.LocalDate.of(y,m+1,d)
            val cal=java.util.Calendar.getInstance()
            android.app.DatePickerDialog(context,{_,y2,m2,d2-> customStart=first;customEnd=java.time.LocalDate.of(y2,m2+1,d2);period="Personalizado" },cal.get(java.util.Calendar.YEAR),cal.get(java.util.Calendar.MONTH),cal.get(java.util.Calendar.DAY_OF_MONTH)).show()
        },now.get(java.util.Calendar.YEAR),now.get(java.util.Calendar.MONTH),now.get(java.util.Calendar.DAY_OF_MONTH)).show()
    }

    val smartCollections = listOf(
        Triple("Favoritas", Icons.Default.Favorite, tracks.filter { it.queue.uri in liked }.take(80)),
        Triple("Mais ouvidas", Icons.Default.LocalFireDepartment, snapshot.topTracks.mapNotNull { st -> tracks.firstOrNull { it.queue.uri == st.uri } }.take(80)),
        Triple("Recentes", Icons.Default.History, tracks.sortedByDescending { it.lastModified }.take(80)),
        Triple("Descobrir de novo", Icons.Default.AutoAwesome, snapshot.topTracks.asReversed().mapNotNull { st -> tracks.firstOrNull { it.queue.uri == st.uri } }.take(50))
    )

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(11.dp),
        contentPadding = PaddingValues(top=14.dp,bottom=28.dp)
    ) {
        item {
            Row(verticalAlignment=Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Estatísticas", fontWeight=FontWeight.Black, fontSize=24.sp)
                    Text("Seu jeito de ouvir, organizado pelo SONUS.", style=MaterialTheme.typography.bodySmall, color=MaterialTheme.colorScheme.onSurface.copy(alpha=.58f))
                }
                IconButton(onClick=onRefresh) { Icon(Icons.Default.Refresh,"Atualizar") }
            }
        }
        item {
            val periods = listOf("Hoje","7 dias","Mês","30 dias","90 dias","6 meses","1 ano","Total","Personalizado")
            Column(verticalArrangement=Arrangement.spacedBy(5.dp)) {
                listOf(periods.take(5), periods.drop(5)).forEach { rowPeriods ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(4.dp)) {
                        rowPeriods.forEach { p ->
                            FilterChip(
                                selected = period == p,
                                onClick = { if (p == "Personalizado") chooseCustomDate() else period = p },
                                label = { Text(p, fontSize=8.sp, maxLines=1) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }
        item {
            Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    StatMetricCard("Tempo ouvido", formatLongDuration(snapshot.totalListeningMs), Icons.Default.Schedule, listOf(Color(0xFF155A7B),Color(0xFF26BEE8)), Modifier.weight(1f))
                    StatMetricCard("Reproduções", snapshot.totalPlays.toString(), Icons.Default.PlayCircle, listOf(Color(0xFF5940A0),Color(0xFF9B72F2)), Modifier.weight(1f))
                }
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    StatMetricCard("Concluídas", snapshot.totalCompleted.toString(), Icons.Default.CheckCircle, listOf(Color(0xFF157652),Color(0xFF35D394)), Modifier.weight(1f))
                    StatMetricCard("Puladas", snapshot.totalSkips.toString(), Icons.Default.SkipNext, listOf(Color(0xFF9B452C),Color(0xFFF37A4D)), Modifier.weight(1f))
                }
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    StatMetricCard("Músicas únicas", uniqueTracks.toString(), Icons.Default.MusicNote, listOf(Color(0xFF8E5C17),Color(0xFFEAB53E)), Modifier.weight(1f))
                    StatMetricCard("Artistas únicos", uniqueArtists.toString(), Icons.Default.Person, listOf(Color(0xFF8A315F),Color(0xFFE35A9A)), Modifier.weight(1f))
                }
            }
        }
        if (daily.isNotEmpty()) {
            item { DailyListeningChart(daily) }
        }
        item {
            Surface(
                shape=RoundedCornerShape(22.dp),
                color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.50f),
                border=BorderStroke(1.dp,Color(0xFF8A6BFF).copy(alpha=.32f))
            ) {
                Column(Modifier.padding(15.dp),verticalArrangement=Arrangement.spacedBy(9.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Surface(shape=RoundedCornerShape(12.dp),color=Color(0xFF8A6BFF).copy(alpha=.15f)) { Icon(Icons.Default.AutoAwesome,null,tint=Color(0xFFB7A4FF),modifier=Modifier.padding(8.dp)) }
                        Spacer(Modifier.width(9.dp));Text("SONUS Insight",fontWeight=FontWeight.Black,fontSize=18.sp)
                    }
                    comparison?.let { delta ->
                        Text(if(delta>=0) "Você ouviu ${String.format(java.util.Locale.US,"%.0f",delta)}% mais música que no período anterior." else "Você ouviu ${String.format(java.util.Locale.US,"%.0f",-delta)}% menos música que no período anterior.",fontWeight=FontWeight.Bold,color=if(delta>=0)Color(0xFF52DFA1) else Color(0xFFFF987A))
                    }
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                        snapshot.favoriteHour?.let { InsightChip(Icons.Default.Schedule,"Horário","${it.toString().padStart(2,'0')}:00",Modifier.weight(1f)) }
                        snapshot.favoriteDay?.let { InsightChip(Icons.Default.CalendarToday,"Dia forte",it.takeLast(5),Modifier.weight(1f)) }
                        InsightChip(Icons.Default.LocalFireDepartment,"Sequência","${snapshot.currentStreak} dia(s)",Modifier.weight(1f))
                    }
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                        InsightChip(Icons.Default.DoneAll,"Conclusão","${completionRate.roundToInt()}%",Modifier.weight(1f))
                        InsightChip(Icons.Default.SkipNext,"Pulos","${skipRate.roundToInt()}%",Modifier.weight(1f))
                        InsightChip(Icons.Default.Timer,"Média",formatLongDuration(avgPerPlay),Modifier.weight(1f))
                    }
                    topArtist?.takeUnless { it == "Artista desconhecido" }?.let { Text("• $it lidera seu tempo de reprodução.",fontSize=10.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.68f)) }
                    topGenre?.takeUnless { it == "Sem gênero" }?.let { Text("• $it é o gênero mais presente no período.",fontSize=10.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.68f)) }
                    mostRepeated?.let { Text("• ${it.title} foi a música mais repetida (${it.plays}x).",fontSize=10.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.68f)) }
                }
            }
        }
        item { Text("Coleções inteligentes",fontWeight=FontWeight.Black,fontSize=17.sp) }
        item {
            LazyRow(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                items(smartCollections) { (name,icon,list) -> SmartCollectionCard(name,icon,list.size,enabled=list.isNotEmpty()){onPlayList(list)} }
            }
        }
        if (snapshot.topTracks.isNotEmpty()) {
            item {
                StatsRankingCard(
                    "Top músicas", Icons.Default.MusicNote,
                    snapshot.topTracks.take(20).map { Triple(it.title,it.artist.ifBlank{"Artista desconhecido"},"${it.plays}x • ${formatLongDuration(it.listenedMs)}") },
                    expanded = "tracks" in expandedRankings,
                    onToggle = { expandedRankings = if ("tracks" in expandedRankings) expandedRankings - "tracks" else expandedRankings + "tracks" }
                )
            }
        }
        if (snapshot.topArtists.isNotEmpty()) {
            item {
                StatsRankingCard(
                    "Artistas mais ouvidos", Icons.Default.Person, snapshot.topArtists.take(20).map { Triple(it.first,"",formatLongDuration(it.second)) },
                    expanded = "artists" in expandedRankings,
                    onToggle = { expandedRankings = if ("artists" in expandedRankings) expandedRankings - "artists" else expandedRankings + "artists" }
                )
            }
        }
        if (snapshot.topAlbums.isNotEmpty()) {
            item {
                StatsRankingCard(
                    "Álbuns mais ouvidos", Icons.Default.Album, snapshot.topAlbums.filterNot { it.first == "Álbum desconhecido" }.take(20).map { Triple(it.first,"",formatLongDuration(it.second)) },
                    expanded = "albums" in expandedRankings,
                    onToggle = { expandedRankings = if ("albums" in expandedRankings) expandedRankings - "albums" else expandedRankings + "albums" }
                )
            }
        }
        if (snapshot.sourceStats.isNotEmpty()) {
            item {
                Surface(shape=RoundedCornerShape(18.dp),color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.42f),border=BorderStroke(1.dp,Color(0xFF5ED7FF).copy(alpha=.18f))) {
                    Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(9.dp)) {
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Icon(Icons.Default.CloudQueue,null,tint=Color(0xFF5ED7FF),modifier=Modifier.size(17.dp));Spacer(Modifier.width(6.dp));Text("Origem das músicas",fontWeight=FontWeight.Black)
                        }
                        snapshot.sourceStats.take(8).forEach { origin ->
                            Column(verticalArrangement=Arrangement.spacedBy(2.dp)) {
                                Row {
                                    Text(origin.name.ifBlank{"Local"},Modifier.weight(1f),fontSize=10.sp,fontWeight=FontWeight.SemiBold)
                                    Text(formatLongDuration(origin.listenedMs),fontWeight=FontWeight.Bold,fontSize=10.sp)
                                }
                                Text("${origin.plays} reproduções • ${origin.completed} concluídas • ${origin.skips} puladas",fontSize=8.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.54f))
                            }
                        }
                    }
                }
            }
        }
        item {
            var confirmClear by remember { mutableStateOf(false) }
            Button(
                onClick={confirmClear=true},
                modifier=Modifier.fillMaxWidth(),
                colors=ButtonDefaults.buttonColors(containerColor=Color(0xFFB3263E),contentColor=Color.White)
            ) { Icon(Icons.Default.DeleteSweep,null);Spacer(Modifier.width(7.dp));Text("Limpar todos os dados") }
            if(confirmClear) AlertDialog(
                onDismissRequest={confirmClear=false},
                title={Text("Limpar estatísticas?")},
                text={Text("Isso apaga somente as estatísticas locais do SONUS PLAYER. Músicas, playlists e configurações não serão alteradas.")},
                confirmButton={TextButton(onClick={onClear();confirmClear=false}){Text("Limpar",color=Color(0xFFFF5D73))}},
                dismissButton={TextButton(onClick={confirmClear=false}){Text("Cancelar")}}
            )
        }
    }
}

@Composable
private fun StatMetricCard(label:String,value:String,icon:ImageVector,colors:List<Color>,modifier:Modifier=Modifier) {
    Surface(modifier=modifier.height(82.dp),shape=RoundedCornerShape(18.dp),color=Color.Transparent,border=BorderStroke(1.dp,Color.White.copy(alpha=.10f))) {
        Box(Modifier.fillMaxSize().background(Brush.linearGradient(colors.map{it.copy(alpha=.72f)}))) {
            Box(Modifier.fillMaxWidth().height(28.dp).background(Brush.verticalGradient(listOf(Color.White.copy(alpha=.17f),Color.Transparent))))
            Column(Modifier.padding(11.dp)) {
                Row(verticalAlignment=Alignment.CenterVertically){Icon(icon,null,tint=Color.White.copy(alpha=.92f),modifier=Modifier.size(15.dp));Spacer(Modifier.width(5.dp));Text(label,fontSize=8.5.sp,color=Color.White.copy(alpha=.78f))}
                Spacer(Modifier.height(5.dp));Text(value,fontWeight=FontWeight.Black,fontSize=16.sp,color=Color.White,maxLines=1,overflow=TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun DailyListeningChart(days:List<Pair<String,Long>>) {
    val maxValue = days.maxOfOrNull { it.second }?.coerceAtLeast(1L) ?: 1L
    var selectedIndex by remember(days) { mutableIntStateOf(-1) }
    Surface(shape=RoundedCornerShape(20.dp),color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.44f),border=BorderStroke(1.dp,Color(0xFF38BDF8).copy(alpha=.24f))) {
        Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
            Row { Text("Tempo ouvido por dia", modifier = Modifier.weight(1f), fontWeight = FontWeight.Black); Text("últimos ${days.size} dias", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .55f)) }
            Canvas(Modifier.fillMaxWidth().height(128.dp).pointerInput(days) {
                detectTapGestures { pos ->
                    if (days.isNotEmpty()) selectedIndex = ((pos.x / size.width) * days.size).toInt().coerceIn(0,days.lastIndex)
                }
            }) {
                val gap=8.dp.toPx();val bw=(size.width-gap*(days.size-1))/days.size.coerceAtLeast(1)
                days.forEachIndexed { i,(_,minutes) ->
                    val h=(size.height-22.dp.toPx())*(minutes.toFloat()/maxValue.toFloat()).coerceIn(.04f,1f)
                    val x=i*(bw+gap);val y=size.height-22.dp.toPx()-h
                    val alpha=if(selectedIndex<0||selectedIndex==i)1f else .48f
                    drawRoundRect(Brush.verticalGradient(listOf(Color(0xFF7B61FF).copy(alpha=alpha),Color(0xFF25C8F5).copy(alpha=alpha)),startY=y,endY=y+h),Offset(x,y),Size(bw,h),CornerRadius(8.dp.toPx(),8.dp.toPx()))
                }
            }
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) { days.forEach { (day,minutes) -> Column(horizontalAlignment=Alignment.CenterHorizontally){Text(day.takeLast(5),fontSize=7.5.sp);Text("${minutes}m",fontSize=7.5.sp,fontWeight=FontWeight.Bold)} } }
            days.getOrNull(selectedIndex)?.let { (day,minutes) ->
                Text("$day • ${formatLongDuration(minutes * 60_000L)}",fontSize=9.sp,fontWeight=FontWeight.Bold,color=Color(0xFF65D7FF),modifier=Modifier.align(Alignment.CenterHorizontally))
            }
        }
    }
}

@Composable
private fun InsightChip(icon:ImageVector,label:String,value:String,modifier:Modifier=Modifier) {
    Surface(modifier=modifier,shape=RoundedCornerShape(13.dp),color=Color.Black.copy(alpha=.18f)) {
        Column(Modifier.padding(horizontal=8.dp,vertical=7.dp),horizontalAlignment=Alignment.CenterHorizontally) { Icon(icon,null,modifier=Modifier.size(14.dp),tint=Color(0xFFB8A7FF));Text(label,fontSize=7.5.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.55f));Text(value,fontSize=9.sp,fontWeight=FontWeight.Black,maxLines=1) }
    }
}

@Composable
private fun SmartCollectionCard(name:String,icon:ImageVector,count:Int,enabled:Boolean,onClick:()->Unit) {
    Surface(modifier=Modifier.width(142.dp).height(72.dp).clickable(enabled=enabled,onClick=onClick),shape=RoundedCornerShape(17.dp),color=Color(0xFF5C46B7).copy(alpha=if(enabled).18f else .07f),border=BorderStroke(1.dp,Color(0xFF9D89FF).copy(alpha=.25f))) {
        Row(Modifier.padding(10.dp),verticalAlignment=Alignment.CenterVertically){Icon(icon,null,tint=Color(0xFFB8A7FF));Spacer(Modifier.width(7.dp));Column{Text(name,fontSize=9.5.sp,fontWeight=FontWeight.Bold);Text("$count faixas",fontSize=8.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.55f))}}
    }
}

@Composable
private fun StatsRankingCard(
    title:String, icon:ImageVector, rows:List<Triple<String,String,String>>,
    expanded:Boolean=false, onToggle:(()->Unit)?=null
) {
    if(rows.isEmpty()) return
    val shown = if (expanded) rows else rows.take(5)
    Surface(shape=RoundedCornerShape(19.dp),color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.40f)) {
        Column(Modifier.padding(13.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment=Alignment.CenterVertically){Icon(icon,null,tint=Color(0xFF65D7FF),modifier=Modifier.size(18.dp));Spacer(Modifier.width(7.dp));Text(title,fontWeight=FontWeight.Black)}
            shown.forEachIndexed { index,(name,sub,value) ->
                Row(verticalAlignment=Alignment.CenterVertically){
                    Text("${index+1}",fontSize=8.sp,fontWeight=FontWeight.Black,color=Color(0xFF65D7FF),modifier=Modifier.width(18.dp))
                    Column(Modifier.weight(1f)){Text(name,fontSize=9.5.sp,fontWeight=FontWeight.SemiBold,maxLines=1,overflow=TextOverflow.Ellipsis);if(sub.isNotBlank())Text(sub,fontSize=8.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.52f),maxLines=1,overflow=TextOverflow.Ellipsis)}
                    Text(value,fontSize=8.5.sp,fontWeight=FontWeight.Bold)
                }
            }
            if (rows.size > 5 && onToggle != null) {
                TextButton(onClick=onToggle,modifier=Modifier.align(Alignment.End),contentPadding=PaddingValues(horizontal=8.dp,vertical=0.dp)) {
                    Text(if(expanded) "Ver menos" else "Ver mais",fontSize=9.sp)
                }
            }
        }
    }
}

@Composable private fun StatCard(label:String,value:String,modifier:Modifier){Card(modifier){Column(Modifier.padding(13.dp)){Text(label,style=MaterialTheme.typography.labelSmall);Text(value,fontWeight=FontWeight.Black,fontSize=18.sp)}}}

@Composable private fun LyricsScreen(
    context:Context,
    track:PulseLibraryTrack?,
    currentItem:PulsePlayerQueueItem?,
    currentPositionMs:Long,
    currentDurationMs:Long,
    membershipTier:MembershipTier,
    preferences:UserPreferences
){
    val scope=rememberCoroutineScope()
    val sonusRef=remember(currentItem?.uri){SonusOnlineRef.parse(currentItem?.uri)}
    var catalogLyricsFormat by remember(currentItem?.uri){mutableStateOf("TEXT")}
    var text by remember(track?.lrcUri,currentItem?.uri){mutableStateOf<String?>(null)}
    var liveEnabled by remember(currentItem?.uri){mutableStateOf(false)}
    var busy by remember{mutableStateOf(false)}
    var status by remember{mutableStateOf("Pronto")}
    var language by remember{mutableStateOf("pt-BR")}
    var focusVoice by remember{mutableStateOf(false)}
    var transcriber by remember{mutableStateOf<PulseSpeechTranscriber?>(null)}
    var transcriptLines by remember(currentItem?.uri){mutableStateOf<List<SonusTranscriptLine>>(emptyList())}
    val lrcText=remember(transcriptLines){transcriptToLrc(transcriptLines)}
    val effectiveLrcText=remember(text,lrcText,catalogLyricsFormat){if(catalogLyricsFormat=="LRC"&&!text.isNullOrBlank())text.orEmpty() else lrcText}
    var pendingMetadataText by remember{mutableStateOf<String?>(null)}
    val saveTxt=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")){out->
        if(out!=null){scope.launch(Dispatchers.IO){runCatching{context.contentResolver.openOutputStream(out,"w")?.bufferedWriter()?.use{it.write(text.orEmpty())}}}}
    }
    val saveLrc=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")){out->
        if(out!=null){scope.launch(Dispatchers.IO){runCatching{context.contentResolver.openOutputStream(out,"w")?.bufferedWriter()?.use{it.write(effectiveLrcText)}}}}
    }
    val saveTaggedCopy=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/mpeg")){out->
        val src=currentItem?.uri?.takeIf{SonusOnlineRef.parse(it)==null}?.let{runCatching{Uri.parse(it)}.getOrNull()}
        val lyrics=pendingMetadataText.orEmpty()
        if(out!=null && src!=null && lyrics.isNotBlank()) scope.launch{
            status="Gravando letra nos metadados…";busy=true
            val result=withContext(Dispatchers.IO){runCatching{val meta=AudioToolEngine.readMetadata(context,src);AudioToolEngine.writeMetadata(context,src,out,meta.copy(lyrics=lyrics)).getOrThrow()}}
            busy=false;status=if(result.isSuccess)"Cópia com letra incorporada criada" else "Não foi possível incorporar a letra"
        }
    }
    LaunchedEffect(track?.lrcUri, currentItem?.uri){
        SonusLiveLyricsBus.clear()
        if(sonusRef!=null){
            status="Carregando letra do SONUS Stream…"
            val repo=SonusOnlineMusicRepository(context)
            withContext(Dispatchers.IO){runCatching{repo.refreshTrackOverrides()}}
            val lyrics=repo.lyricsForFileIdAuto(sonusRef.fileId)
            text=lyrics?.first
            catalogLyricsFormat=lyrics?.second?.uppercase() ?: "TEXT"
            status=if(text.isNullOrBlank())"Letra ainda não cadastrada pelo SONUS" else if(catalogLyricsFormat=="LRC")"Letra sincronizada do catálogo" else "Letra do catálogo"
        }else{
            catalogLyricsFormat="TEXT"
            text = withContext(Dispatchers.IO){
                track?.lrcUri?.let{runCatching{context.contentResolver.openInputStream(Uri.parse(it))?.bufferedReader()?.use{r->r.readText()}}.getOrNull()}
            }
        }
    }
    LaunchedEffect(currentPositionMs,text,catalogLyricsFormat,currentItem?.uri){
        if(sonusRef!=null && catalogLyricsFormat=="LRC" && !text.isNullOrBlank()){
            sonusLrcLineAt(text.orEmpty(),currentPositionMs)?.let(SonusLiveLyricsBus::publish)
        }else if(sonusRef!=null && catalogLyricsFormat=="TEXT"){
            text?.lineSequence()?.firstOrNull{it.isNotBlank()}?.let(SonusLiveLyricsBus::publish)
        }
    }
    DisposableEffect(Unit){onDispose{transcriber?.destroy();SonusLiveLyricsBus.clear()}}

    fun transcribeSegment(){
        if(sonusRef!=null){status="No SONUS Stream, a letra é administrada pelo catálogo.";return}
        val item=currentItem?:return
        if(busy)return
        busy=true;status="Preparando trecho…"
        scope.launch{
            val start=maxOf(currentPositionMs.coerceAtLeast(0L), transcriptLines.lastOrNull()?.startMs?.plus(18_000L) ?: 0L)
            val pcm=withContext(Dispatchers.IO){prepareSpeechPcmSegment(context,item.uri,start,18,focusVoice)}
            if(pcm==null){busy=false;status="Não foi possível preparar o áudio";return@launch}
            status="Transcrevendo no aparelho…"
            val tr=PulseSpeechTranscriber(context,{partial->
                val line=partial.lineSequence().lastOrNull{it.isNotBlank()}.orEmpty();if(line.isNotBlank()){SonusLiveLyricsBus.publish(line);text=(transcriptLines.map{it.text}+line).joinToString("\n")}
            },{final->
                val line=final.lineSequence().lastOrNull{it.isNotBlank()}.orEmpty()
                if(line.isNotBlank()){transcriptLines=transcriptLines+SonusTranscriptLine(start,line);SonusLiveLyricsBus.publish(line);text=transcriptLines.joinToString("\n"){it.text}}
                busy=false;status=if(line.isBlank())"Nenhuma voz reconhecida neste trecho" else "Trecho reconhecido"
                pcm.delete()
                if(liveEnabled) scope.launch { delay(900); transcribeSegment() }
            },{msg->busy=false;status=msg;pcm.delete()})
            transcriber?.destroy();transcriber=tr;tr.transcribePcmFile(pcm,language)
        }
    }

    LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp),contentPadding=PaddingValues(bottom=28.dp)){
        item{Text("Letras / Transcrição",fontWeight=FontWeight.Black,fontSize=22.sp);Text(currentItem?.title?:"Nenhuma música em reprodução",fontWeight=FontWeight.Bold);Text(status,fontSize=10.sp,color=MaterialTheme.colorScheme.primary)}
        item{
            if(sonusRef!=null){
                Surface(shape=RoundedCornerShape(14.dp),color=Color(0xFF12382F).copy(alpha=.62f)){
                    Row(Modifier.fillMaxWidth().padding(11.dp),verticalAlignment=Alignment.CenterVertically){
                        Icon(Icons.Default.Verified,null,tint=Color(0xFF63E2C2));Spacer(Modifier.width(7.dp));Text("Catálogo oficial SONUS Studios • Todos os direitos reservados. Letras sincronizadas e revisadas para acompanhar a reprodução.",fontSize=10.sp)
                    }
                }
            }else{
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
                    Button(onClick={liveEnabled=true;transcribeSegment()},enabled=currentItem!=null&&!busy,modifier=Modifier.weight(1f)){Icon(Icons.Default.RecordVoiceOver,null);Spacer(Modifier.width(4.dp));Text(if(busy)"Processando…" else "Trecho ao vivo")}
                    OutlinedButton(onClick={liveEnabled=false;transcriber?.destroy();busy=false;SonusLiveLyricsBus.clear()},enabled=liveEnabled||busy,modifier=Modifier.weight(1f)){Icon(Icons.Default.Stop,null);Spacer(Modifier.width(4.dp));Text("Parar")}
                }
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){
                    listOf("pt-BR" to "PT","en-US" to "EN","es-ES" to "ES").forEach{(code,label)->FilterChip(selected=language==code,onClick={language=code},label={Text(label)})}
                    FilterChip(selected=focusVoice,onClick={focusVoice=!focusVoice},label={Text("Foco na voz")},leadingIcon={Icon(Icons.Default.RecordVoiceOver,null,modifier=Modifier.size(16.dp))})
                }
                Text("Usa o áudio interno da mídia, sem microfone. Foco na voz aplica um filtro local antes do reconhecimento para reduzir parte do instrumental.",fontSize=9.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.56f))
            }
        }
        item{
            Surface(shape=RoundedCornerShape(16.dp),color=Color.Black.copy(alpha=.25f),modifier=Modifier.fillMaxWidth().heightIn(min=220.dp)){
                Text(text?.let(::stripLrcTimestamps)?.ifBlank{"A letra aparecerá aqui."}?:if(sonusRef!=null)"Esta música ainda não possui letra cadastrada." else "Nenhum arquivo .lrc vinculado. Toque em Trecho ao vivo para transcrever.",lineHeight=24.sp,modifier=Modifier.padding(14.dp))
            }
        }
        item{
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){
                OutlinedButton(onClick={saveTxt.launch("SONUS_Letra_${System.currentTimeMillis()}.txt")},enabled=!text.isNullOrBlank(),modifier=Modifier.weight(1f)){Text("Salvar TXT")}
                OutlinedButton(onClick={saveLrc.launch("SONUS_Letra_${System.currentTimeMillis()}.lrc")},enabled=effectiveLrcText.isNotBlank(),modifier=Modifier.weight(1f)){Text("Salvar LRC")}
            }
            OutlinedButton(onClick={pendingMetadataText=if(effectiveLrcText.isNotBlank())effectiveLrcText else text;saveTaggedCopy.launch("SONUS_Com_Letra_${System.currentTimeMillis()}.mp3")},enabled=currentItem!=null&&SonusOnlineRef.parse(currentItem.uri)==null&&!text.isNullOrBlank(),modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Sell,null);Spacer(Modifier.width(5.dp));Text("Criar cópia com letra nos metadados")}
        }
    }
}

@Composable
private fun QueueScreen(playback: PulsePlayerPlaybackState, service: PulsePlayerService?) {
    LazyColumn(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
                Column(Modifier.weight(1f)){
                    Text("Lista de reprodução", fontWeight = FontWeight.Black, fontSize = 22.sp)
                    Text("${playback.queue.size} música(s) • reorganize sem interromper a faixa atual", style = MaterialTheme.typography.bodySmall)
                }
                OutlinedButton(onClick={service?.clearQueue()},enabled=playback.queue.isNotEmpty()){Icon(Icons.Default.DeleteSweep,null);Spacer(Modifier.width(4.dp));Text("Limpar")}
            }
        }
        if (playback.queue.isEmpty()) {
            item { Text("A lista de reprodução está vazia. Escolha uma música ou playlist para começar.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        } else {
            itemsIndexed(playback.queue, key = { index, item -> "${item.uri}-$index" }) { index, item ->
                val current = index == playback.index
                Card(colors = CardDefaults.cardColors(containerColor = if (current) MaterialTheme.colorScheme.primaryContainer.copy(alpha=.45f) else Color.Black.copy(alpha=.22f))) {
                    Row(Modifier.fillMaxWidth().padding(horizontal=10.dp, vertical=8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(if(current) Icons.Default.GraphicEq else Icons.Default.MusicNote, null, tint = if(current) MaterialTheme.colorScheme.primary else LocalContentColor.current)
                        Spacer(Modifier.width(9.dp))
                        Column(Modifier.weight(1f)) {
                            Text(item.title, fontWeight = if(current) FontWeight.Black else FontWeight.SemiBold, maxLines=1, overflow=TextOverflow.Ellipsis)
                            Text(item.artist.ifBlank { "Artista desconhecido" }, style=MaterialTheme.typography.bodySmall, maxLines=1, overflow=TextOverflow.Ellipsis)
                        }
                        IconButton(onClick={service?.playNextFromQueue(index)},enabled=!current && playback.index>=0) { Icon(Icons.Default.PlaylistPlay,"Tocar a seguir") }
                        IconButton(onClick={ if(index>0) service?.moveQueue(index,index-1) }, enabled=index>0) { Icon(Icons.Default.KeyboardArrowUp,"Subir") }
                        IconButton(onClick={ if(index<playback.queue.lastIndex) service?.moveQueue(index,index+1) }, enabled=index<playback.queue.lastIndex) { Icon(Icons.Default.KeyboardArrowDown,"Descer") }
                        IconButton(onClick={ service?.removeQueueAt(index) }) { Icon(Icons.Default.Close,"Remover") }
                    }
                }
            }
        }
    }
}

private fun formatNetBytes(bytes: Long): String = when {
    bytes >= 1_048_576 -> String.format(java.util.Locale.US, "%.1f MB", bytes / 1_048_576.0)
    bytes >= 1024 -> String.format(java.util.Locale.US, "%.0f KB", bytes / 1024.0)
    else -> "$bytes B"
}
private fun formatNetRate(bytesPerSecond: Long): String = "${formatNetBytes(bytesPerSecond)}/s"

private class PulseYouTubeLocalStore(context: Context) {
    private val prefs = context.getSharedPreferences("pulse_youtube_player_v1", Context.MODE_PRIVATE)
    private fun read(key: String): List<YouTubeVideoResult> = runCatching {
        val array = JSONArray(prefs.getString(key, "[]") ?: "[]")
        (0 until array.length()).mapNotNull { i ->
            val o = array.optJSONObject(i) ?: return@mapNotNull null
            val id = o.optString("id")
            if (id.isBlank()) return@mapNotNull null
            YouTubeVideoResult(id, o.optString("title"), o.optString("channel"), o.optString("thumb").takeIf { it.isNotBlank() })
        }
    }.getOrDefault(emptyList())
    private fun write(key: String, items: List<YouTubeVideoResult>) {
        val array = JSONArray()
        items.forEach { v -> array.put(JSONObject().apply {
            put("id", v.videoId); put("title", v.title); put("channel", v.channelTitle); put("thumb", v.thumbnailUrl ?: "")
        }) }
        prefs.edit().putString(key, array.toString()).apply()
    }
    fun history(): List<YouTubeVideoResult> = read("history")
    fun favorites(): List<YouTubeVideoResult> = read("favorites")
    fun addHistory(video: YouTubeVideoResult): List<YouTubeVideoResult> {
        val updated = (listOf(video) + history().filterNot { it.videoId == video.videoId }).take(200)
        write("history", updated); return updated
    }
    fun toggleFavorite(video: YouTubeVideoResult): List<YouTubeVideoResult> {
        val current = favorites()
        val updated = if (current.any { it.videoId == video.videoId }) current.filterNot { it.videoId == video.videoId }
        else listOf(video) + current
        write("favorites", updated); return updated
    }
    fun clearHistory() { prefs.edit().remove("history").apply() }
}

@Composable
private fun PulsePlayerYouTubeScreen(accent: Color) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val controller = rememberStreamPulseYouTubeController()
    val localStore = remember { PulseYouTubeLocalStore(context) }
    var history by remember { mutableStateOf(localStore.history()) }
    var favorites by remember { mutableStateOf(localStore.favorites()) }
    var savedMode by remember { mutableStateOf("search") }
    var query by remember { mutableStateOf("") }
    var searching by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var results by remember { mutableStateOf<List<YouTubeVideoResult>>(emptyList()) }
    var selectedIndex by remember { mutableIntStateOf(-1) }
    val selected = results.getOrNull(selectedIndex)
    var netDownBps by remember { mutableLongStateOf(0L) }
    var netUpBps by remember { mutableLongStateOf(0L) }
    var sessionBytes by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        val uid = Process.myUid()
        val startRx = TrafficStats.getUidRxBytes(uid).coerceAtLeast(0L)
        val startTx = TrafficStats.getUidTxBytes(uid).coerceAtLeast(0L)
        var lastRx = startRx; var lastTx = startTx
        while (true) {
            delay(1000)
            val rx = TrafficStats.getUidRxBytes(uid).coerceAtLeast(lastRx)
            val tx = TrafficStats.getUidTxBytes(uid).coerceAtLeast(lastTx)
            netDownBps = (rx-lastRx).coerceAtLeast(0L); netUpBps=(tx-lastTx).coerceAtLeast(0L)
            sessionBytes = (rx-startRx).coerceAtLeast(0L) + (tx-startTx).coerceAtLeast(0L)
            lastRx=rx; lastTx=tx
        }
    }

    fun playSaved(video: YouTubeVideoResult) {
        results = listOf(video)
        selectedIndex = 0
        savedMode = "search"
        history = localStore.addHistory(video)
        controller.load(video.videoId, force = true)
    }

    fun runSearch(raw: String) {
        val q = raw.trim()
        if (q.isBlank()) return
        scope.launch {
            searching = true
            error = null
            if (SonusProcessNotifier.isOffline(context)) { searching=false; error="Sem internet para pesquisar no YouTube."; return@launch }
            val result = YouTubeSearchClient.search(context, q, "music")
            result.onSuccess { list ->
                results = list.distinctBy { it.videoId }
                selectedIndex = if (results.isEmpty()) -1 else 0
                if (selectedIndex >= 0) {
                    history = localStore.addHistory(results[selectedIndex])
                    controller.load(results[selectedIndex].videoId, force = true)
                }
            }.onFailure { error = it.message ?: "Não foi possível pesquisar no YouTube." }
            searching = false
        }
    }

    LaunchedEffect(controller.endedGeneration) {
        if (controller.endedGeneration <= 0 || results.isEmpty()) return@LaunchedEffect
        val next = selectedIndex + 1
        if (next < results.size) {
            selectedIndex = next
            history = localStore.addHistory(results[next])
            controller.load(results[next].videoId, force = true)
        } else {
            val seed = selected?.let { "${it.channelTitle} ${it.title}" }.orEmpty().ifBlank { query }
            val extra = YouTubeSearchClient.search(context, seed, "music").getOrDefault(emptyList())
            val merged = (results + extra).distinctBy { it.videoId }
            if (merged.size > results.size) {
                results = merged
                selectedIndex = next.coerceAtMost(merged.lastIndex)
                history = localStore.addHistory(merged[selectedIndex])
                controller.load(merged[selectedIndex].videoId, force = true)
            } else {
                selectedIndex = 0
                history = localStore.addHistory(results.first())
                controller.load(results.first().videoId, force = true)
            }
        }
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal=14.dp),
        verticalArrangement=Arrangement.spacedBy(10.dp),
        contentPadding=PaddingValues(bottom=24.dp)
    ) {
        item {
            Card(
                colors=CardDefaults.cardColors(containerColor=Color.Black.copy(alpha=.28f)),
                border=BorderStroke(1.dp,accent.copy(alpha=.34f))
            ) {
                Column(Modifier.padding(13.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Icon(Icons.Default.SmartDisplay,null,tint=Color(0xFFFF4B55))
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Text("YouTube no SONUS PLAYER",fontWeight=FontWeight.Black)
                            Text("Player oficial incorporado • vídeo sempre visível",style=MaterialTheme.typography.bodySmall,color=Color.White.copy(alpha=.62f))
                        }
                        AssistChip(onClick={},label={Text("∞ Sempre tocando")},enabled=false)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected=savedMode=="history",
                            onClick={ savedMode = if(savedMode=="history") "search" else "history" },
                            label={Text("Histórico (${history.size})")},
                            leadingIcon={Icon(Icons.Default.History,null,modifier=Modifier.size(18.dp))}
                        )
                        FilterChip(
                            selected=savedMode=="favorites",
                            onClick={ savedMode = if(savedMode=="favorites") "search" else "favorites" },
                            label={Text("Favoritos (${favorites.size})")},
                            leadingIcon={Icon(Icons.Default.Favorite,null,modifier=Modifier.size(18.dp))}
                        )
                    }
                    Surface(shape=RoundedCornerShape(12.dp), color=accent.copy(alpha=.12f), border=BorderStroke(1.dp,accent.copy(alpha=.24f))) {
                        Row(Modifier.fillMaxWidth().padding(horizontal=10.dp,vertical=7.dp), horizontalArrangement=Arrangement.SpaceBetween) {
                            Text("Dados • ↓ ${formatNetRate(netDownBps)}  ↑ ${formatNetRate(netUpBps)}", style=MaterialTheme.typography.labelSmall, color=Color.White.copy(alpha=.82f))
                            Text("Sessão ${formatNetBytes(sessionBytes)}", style=MaterialTheme.typography.labelSmall, color=accent)
                        }
                    }
                    OutlinedTextField(
                        value=query,
                        onValueChange={ query=it.take(100) },
                        modifier=Modifier.fillMaxWidth(),
                        singleLine=true,
                        leadingIcon={Icon(Icons.Default.Search,null)},
                        placeholder={Text("Música, artista ou vídeo")}
                    )
                    Button(onClick={runSearch(query)},enabled=query.isNotBlank()&&!searching,modifier=Modifier.fillMaxWidth()) {
                        if(searching) CircularProgressIndicator(Modifier.size(18.dp),strokeWidth=2.dp) else Icon(Icons.Default.Search,null)
                        Spacer(Modifier.width(7.dp)); Text(if(searching) "Pesquisando..." else "Pesquisar no YouTube")
                    }
                    Text("A reprodução contínua funciona enquanto esta tela estiver aberta. Ao bloquear a tela ou sair do modo YouTube, o player oficial é encerrado/pausado.",style=MaterialTheme.typography.labelSmall,color=Color.White.copy(alpha=.52f))
                    error?.let{Text(it,color=MaterialTheme.colorScheme.error,style=MaterialTheme.typography.bodySmall)}
                }
            }
        }
        if (savedMode == "history") {
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically) {
                    Text("Histórico", Modifier.weight(1f), fontWeight=FontWeight.Black, color=Color.White)
                    TextButton(onClick={ localStore.clearHistory(); history=emptyList() }, enabled=history.isNotEmpty()) { Text("Limpar") }
                }
            }
            if (history.isEmpty()) item { Text("Nenhuma reprodução salva ainda.", color=Color.White.copy(alpha=.58f)) }
            items(history, key={ "h_"+it.videoId }) { video ->
                Surface(
                    modifier=Modifier.fillMaxWidth().clickable { playSaved(video) },
                    shape=RoundedCornerShape(14.dp), color=Color.Black.copy(alpha=.22f)
                ) {
                    Row(Modifier.padding(9.dp), verticalAlignment=Alignment.CenterVertically) {
                        YouTubeThumbnail(video.thumbnailUrl,Modifier.size(width=92.dp,height=52.dp).clip(RoundedCornerShape(9.dp)))
                        Spacer(Modifier.width(9.dp))
                        Column(Modifier.weight(1f)) {
                            Text(video.title,fontWeight=FontWeight.SemiBold,maxLines=2,overflow=TextOverflow.Ellipsis)
                            Text(video.channelTitle,style=MaterialTheme.typography.labelSmall,color=Color.White.copy(alpha=.55f),maxLines=1)
                        }
                        Icon(Icons.Default.PlayArrow,null,tint=accent)
                    }
                }
            }
        }
        if (savedMode == "favorites") {
            item { Text("Favoritos", fontWeight=FontWeight.Black, color=Color.White) }
            if (favorites.isEmpty()) item { Text("Toque no coração de uma música para salvá-la aqui.", color=Color.White.copy(alpha=.58f)) }
            items(favorites, key={ "f_"+it.videoId }) { video ->
                Surface(
                    modifier=Modifier.fillMaxWidth().clickable { playSaved(video) },
                    shape=RoundedCornerShape(14.dp), color=Color.Black.copy(alpha=.22f)
                ) {
                    Row(Modifier.padding(9.dp), verticalAlignment=Alignment.CenterVertically) {
                        YouTubeThumbnail(video.thumbnailUrl,Modifier.size(width=92.dp,height=52.dp).clip(RoundedCornerShape(9.dp)))
                        Spacer(Modifier.width(9.dp))
                        Column(Modifier.weight(1f)) {
                            Text(video.title,fontWeight=FontWeight.SemiBold,maxLines=2,overflow=TextOverflow.Ellipsis)
                            Text(video.channelTitle,style=MaterialTheme.typography.labelSmall,color=Color.White.copy(alpha=.55f),maxLines=1)
                        }
                        IconButton(onClick={ favorites=localStore.toggleFavorite(video) }) { Icon(Icons.Default.Favorite,"Remover favorito",tint=Color(0xFFFF5A70)) }
                    }
                }
            }
        }
        if (savedMode == "search") selected?.let { video ->
            item {
                Card(colors=CardDefaults.cardColors(containerColor=Color.Black.copy(alpha=.32f)),border=BorderStroke(1.dp,accent.copy(alpha=.30f))) {
                    Column(Modifier.padding(10.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                        YouTubeEmbedPlayer(video.videoId,controller,Modifier.fillMaxWidth().aspectRatio(16f/9f).clip(RoundedCornerShape(16.dp)))
                        Text(video.title,fontWeight=FontWeight.Black,maxLines=2,overflow=TextOverflow.Ellipsis)
                        Text(video.channelTitle,style=MaterialTheme.typography.bodySmall,color=Color.White.copy(alpha=.62f))
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly) {
                            IconButton(onClick={ if(selectedIndex>0){selectedIndex--; history=localStore.addHistory(results[selectedIndex]);controller.load(results[selectedIndex].videoId,true)} },enabled=selectedIndex>0){Icon(Icons.Default.SkipPrevious,"Anterior")}
                            FilledIconButton(onClick={ if(controller.isPlaying) controller.pause() else controller.play() }){Icon(if(controller.isPlaying)Icons.Default.Pause else Icons.Default.PlayArrow,"Play/Pause")}
                            IconButton(onClick={ if(selectedIndex<results.lastIndex){selectedIndex++; history=localStore.addHistory(results[selectedIndex]);controller.load(results[selectedIndex].videoId,true)} },enabled=selectedIndex<results.lastIndex){Icon(Icons.Default.SkipNext,"Próxima")}
                            IconButton(onClick={ favorites=localStore.toggleFavorite(video) }) {
                                Icon(if(favorites.any{it.videoId==video.videoId}) Icons.Default.Favorite else Icons.Default.FavoriteBorder,"Favorito",tint=if(favorites.any{it.videoId==video.videoId}) Color(0xFFFF5A70) else Color.White)
                            }
                        }
                        controller.errorMessage?.let { Text(it,color=MaterialTheme.colorScheme.error,style=MaterialTheme.typography.bodySmall) }
                    }
                }
            }
        }
        if(savedMode == "search" && results.isNotEmpty()) {
            item { Text("Fila automática • ${results.size} vídeos",fontWeight=FontWeight.Black,color=Color.White) }
            itemsIndexed(results,key={_,v->v.videoId}) { index, video ->
                Surface(
                    modifier=Modifier.fillMaxWidth().clickable { selectedIndex=index; history=localStore.addHistory(video); controller.load(video.videoId,true) },
                    shape=RoundedCornerShape(14.dp),
                    color=if(index==selectedIndex) accent.copy(alpha=.18f) else Color.Black.copy(alpha=.22f),
                    border=if(index==selectedIndex) BorderStroke(1.dp,accent.copy(alpha=.44f)) else null
                ) {
                    Row(Modifier.padding(9.dp),verticalAlignment=Alignment.CenterVertically) {
                        YouTubeThumbnail(video.thumbnailUrl,Modifier.size(width=92.dp,height=52.dp).clip(RoundedCornerShape(9.dp)))
                        Spacer(Modifier.width(9.dp))
                        Column(Modifier.weight(1f)) {
                            Text(video.title,fontWeight=if(index==selectedIndex)FontWeight.Black else FontWeight.SemiBold,maxLines=2,overflow=TextOverflow.Ellipsis)
                            Text(video.channelTitle,style=MaterialTheme.typography.labelSmall,color=Color.White.copy(alpha=.55f),maxLines=1)
                        }
                        if(index==selectedIndex) Icon(Icons.Default.GraphicEq,null,tint=accent)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EqualizerScreen(
    playback: PulsePlayerPlaybackState,
    service: PulsePlayerService?,
    currentTrack: PulseLibraryTrack?,
    pulseLiftAccess: Boolean,
    pulseOrbit3dAccess: Boolean,
    pulseOrbit8dAccess: Boolean,
    onUnlockFeature24h: (PulseFeaturePass, () -> Unit, (String) -> Unit) -> Unit,
    onTrack: (String, Boolean?, Long?) -> Unit,
    membershipTier: MembershipTier,
    ownerUnlimited: Boolean,
    spectrumFlow: kotlinx.coroutines.flow.StateFlow<List<Float>>,
    playerTheme: PlayerThemeSpec,
    onRequestPlan: (MembershipTier) -> Unit
) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("pulse_player_eq_v3", Context.MODE_PRIVATE) }
    val presets = linkedMapOf(
        "Neutro" to listOf(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f),
        "Rock" to listOf(1.1f,1.2f,.7f,-.3f,-.6f,-.2f,.6f,1.1f,.9f,.4f),
        "Pop" to listOf(.4f,.6f,.3f,-.2f,-.4f,-.1f,.5f,.9f,.6f,.2f),
        "Clássico" to listOf(.2f,.3f,.2f,0f,-.1f,.1f,.4f,.6f,.5f,.3f),
        "Hip-Hop" to listOf(1.4f,1.5f,1f,.2f,-.4f,-.3f,.2f,.5f,.3f,0f),
        "Eletrônica" to listOf(1.2f,1.3f,.8f,0f,-.4f,-.2f,.4f,.9f,1f,.7f),
        "Vocal" to listOf(-.5f,-.4f,-.2f,0f,.3f,.7f,1f,.8f,.1f,-.2f)
    )
    val autoCurves = remember { mapOf(
        "sertanejo" to listOf(.7f,.8f,.5f,0f,-.2f,.2f,.7f,.8f,.4f,.1f),
        "country" to listOf(.5f,.6f,.4f,0f,-.1f,.2f,.7f,.8f,.4f,.1f),
        "rock" to presets.getValue("Rock"), "metal" to listOf(.8f,1f,.7f,-.2f,-.5f,-.1f,.6f,1f,.9f,.4f),
        "pop" to presets.getValue("Pop"), "hip hop" to presets.getValue("Hip-Hop"), "hip-hop" to presets.getValue("Hip-Hop"), "rap" to presets.getValue("Hip-Hop"),
        "electronic" to presets.getValue("Eletrônica"), "eletronica" to presets.getValue("Eletrônica"), "eletrônica" to presets.getValue("Eletrônica"), "edm" to presets.getValue("Eletrônica"), "house" to presets.getValue("Eletrônica"), "techno" to presets.getValue("Eletrônica"),
        "classical" to presets.getValue("Clássico"), "classico" to presets.getValue("Clássico"), "clássico" to presets.getValue("Clássico"),
        "mpb" to listOf(.3f,.4f,.2f,0f,.1f,.4f,.7f,.6f,.2f,0f), "samba" to listOf(.4f,.5f,.2f,-.1f,.1f,.4f,.7f,.7f,.3f,.1f), "pagode" to listOf(.5f,.6f,.3f,0f,.1f,.4f,.7f,.6f,.2f,0f),
        "forro" to listOf(.6f,.7f,.4f,0f,-.1f,.3f,.7f,.7f,.3f,0f), "forró" to listOf(.6f,.7f,.4f,0f,-.1f,.3f,.7f,.7f,.3f,0f), "piseiro" to listOf(.8f,.9f,.5f,0f,-.2f,.2f,.6f,.7f,.3f,0f),
        "funk" to listOf(1.2f,1.3f,.8f,.1f,-.3f,-.2f,.2f,.5f,.3f,0f), "r&b" to listOf(.8f,1f,.6f,.1f,-.2f,.1f,.5f,.6f,.2f,0f), "soul" to listOf(.6f,.7f,.4f,.1f,.1f,.4f,.7f,.6f,.2f,0f),
        "jazz" to listOf(.3f,.4f,.2f,0f,.1f,.3f,.6f,.7f,.4f,.2f), "blues" to listOf(.5f,.6f,.3f,.1f,.1f,.4f,.6f,.6f,.3f,.1f),
        "reggae" to listOf(.9f,1f,.6f,.1f,-.2f,.1f,.4f,.5f,.2f,0f), "gospel" to listOf(.4f,.5f,.2f,0f,.2f,.6f,.8f,.6f,.2f,0f), "religious" to listOf(.3f,.4f,.2f,0f,.2f,.5f,.7f,.6f,.2f,0f),
        "acoustic" to listOf(.2f,.3f,.2f,0f,.2f,.5f,.7f,.6f,.2f,0f), "folk" to listOf(.3f,.4f,.2f,0f,.1f,.4f,.7f,.6f,.2f,0f),
        "latin" to listOf(.6f,.7f,.4f,0f,-.1f,.3f,.7f,.8f,.4f,.1f), "reggaeton" to listOf(1f,1.2f,.7f,.1f,-.3f,-.1f,.3f,.6f,.3f,0f),
        "dance" to listOf(1f,1.1f,.7f,0f,-.3f,-.1f,.4f,.8f,.8f,.5f), "trap" to listOf(1.3f,1.5f,1f,.1f,-.4f,-.3f,.2f,.5f,.3f,0f),
        "indie" to listOf(.5f,.6f,.3f,-.1f,-.2f,.1f,.6f,.8f,.5f,.2f), "alternative" to listOf(.6f,.7f,.4f,-.1f,-.3f,.1f,.6f,.8f,.5f,.2f),
        "ambient" to listOf(.4f,.5f,.3f,.1f,0f,.2f,.4f,.6f,.6f,.4f), "soundtrack" to listOf(.4f,.5f,.3f,.1f,0f,.3f,.6f,.7f,.5f,.3f)
    ) }
    var enabled by remember { mutableStateOf(prefs.getBoolean("enabled", true)) }
    var preset by remember { mutableStateOf(prefs.getString("preset", "Neutro") ?: "Neutro") }
    var bass by remember { mutableFloatStateOf(prefs.getFloat("bass", 0f)) }
    var mids by remember { mutableFloatStateOf(prefs.getFloat("mids", 0f)) }
    var treble by remember { mutableFloatStateOf(prefs.getFloat("treble", 0f)) }
    var autoEq by remember { mutableStateOf(prefs.getBoolean("auto", false)) }
    var bassBoost by remember { mutableStateOf(prefs.getBoolean("bass_boost", false)) }
    var expanded by remember { mutableStateOf(false) }
    var themeMenu by remember { mutableStateOf(false) }
    var eqTheme by remember { mutableStateOf(prefs.getString("theme", "Seguir Player") ?: "Seguir Player") }
    val pro = ownerUnlimited || membershipTier != MembershipTier.FREE
    val themeMap = mapOf("Gold" to Color(0xFFFFC857), "Crimson" to Color(0xFFFF334F), "Ocean" to Color(0xFF20C7F4), "Emerald" to Color(0xFF32E889), "Purple" to Color(0xFF9B6CFF), "Ice" to Color(0xFF9CEBFF), "Monochrome" to Color(0xFFE7E7E7), "Neon" to Color(0xFFC63CFF), "Lime" to Color(0xFFB7FF35), "Sunset" to Color(0xFFFF5A36), "Aurora" to Color(0xFF4DE6D0))
    val accent = if (eqTheme == "Seguir Player") playerTheme.glow else themeMap[eqTheme] ?: playerTheme.glow
    val spectrum by spectrumFlow.collectAsState()

    fun manualCurve(): List<Float> = (presets[preset] ?: presets.getValue("Neutro")).mapIndexed { i,v -> (v + when(i){0,1,2->bass;3,4,5,6->mids;else->treble}).coerceIn(-10f,10f) }
    fun autoCurve(): List<Float> {
        val q=currentTrack?.queue; val g=q?.genre.orEmpty().lowercase().trim()
        autoCurves.entries.firstOrNull { (k,_) -> g.contains(k) }?.value?.let{return it}
        val safe=listOf("pop","acoustic","dance","indie","latin","r&b","rock").mapNotNull{autoCurves[it]}
        return if(safe.isEmpty()) presets.getValue("Neutro") else safe[kotlin.math.abs((q?.title.orEmpty()+q?.artist.orEmpty()).hashCode())%safe.size]
    }
    fun apply() { service?.setEqualizerTenBands(if(!enabled) presets.getValue("Neutro") else if(autoEq) autoCurve() else manualCurve()) }
    fun setPreset(name:String){ preset=name; bass=0f;mids=0f;treble=0f; prefs.edit().putString("preset",name).apply(); apply(); onTrack("SONUS PLAYER: EQ $name",true,null) }
    fun setTone(which:Int,v:Float){ when(which){0->bass=v;1->mids=v;else->treble=v}; preset="Personalizado"; prefs.edit().putFloat("bass",bass).putFloat("mids",mids).putFloat("treble",treble).putString("preset",preset).apply(); service?.setEqualizerTenBands(if(enabled) manualCurve() else presets.getValue("Neutro")) }
    LaunchedEffect(service, currentTrack?.queue?.uri, enabled, autoEq) { apply(); service?.setSonusBassBoost(enabled && bassBoost && pro) }
    val displayedCurve = (if (!enabled) presets.getValue("Neutro") else if (autoEq) autoCurve() else manualCurve()).mapIndexed { i,v ->
        if(enabled && bassBoost && pro && i <= 2) (v + listOf(.9f,.7f,.35f)[i]).coerceIn(-10f,10f) else v
    }
    val animatedCurve = displayedCurve.mapIndexed { i, target ->
        val value by animateFloatAsState(targetValue = target, animationSpec = tween(320, easing = FastOutSlowInEasing), label = "eq-curve-$i")
        value
    }
    val curveColors = when(eqTheme) {
        "Crimson" -> listOf(Color(0xFFFF284F), Color(0xFFFF8A35))
        "Emerald" -> listOf(Color(0xFF20E58B), Color(0xFF36E7E0))
        "Neon" -> listOf(Color(0xFF9D35FF), Color(0xFFFF42C8), Color(0xFF4B7BFF))
        "Gold" -> listOf(Color(0xFFFFB52E), Color(0xFFFFE47A))
        "Sunset" -> listOf(Color(0xFFFF315F), Color(0xFFFFA12F))
        "Aurora" -> listOf(Color(0xFF35E8B0), Color(0xFF4C8DFF), Color(0xFFB44CFF))
        else -> listOf(accent.copy(alpha=.9f), accent)
    }

    LazyColumn(Modifier.fillMaxSize().padding(horizontal=16.dp), verticalArrangement=Arrangement.spacedBy(12.dp), contentPadding=PaddingValues(top=16.dp,bottom=34.dp)) {
        item {
            Surface(shape=RoundedCornerShape(24.dp), color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.58f), border=BorderStroke(1.dp,accent.copy(alpha=.38f))) {
                Column(Modifier.padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)){ Text("Equalizador SONUS",fontSize=22.sp,fontWeight=FontWeight.Black); Text(if(autoEq) "Automático • ${currentTrack?.queue?.genre?.ifBlank{"Neutro"} ?: "Neutro"}" else "Som preciso, visual limpo",style=MaterialTheme.typography.bodySmall,color=accent) }
                        Switch(checked=enabled,onCheckedChange={enabled=it;prefs.edit().putBoolean("enabled",it).apply();apply()})
                    }
                    Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                        Canvas(Modifier.weight(1f).height(62.dp)) {
                            val values=if(spectrum.isEmpty()) List(24){0f}else spectrum
                            val gap=3.dp.toPx(); val w=(size.width-gap*(values.size-1))/values.size
                            values.forEachIndexed { i,v -> val h=(size.height*(.10f+v.coerceIn(0f,1f)*.90f)); drawRoundRect(accent.copy(alpha=.85f), Offset(i*(w+gap),size.height-h), Size(w,h), CornerRadius(w/2,w/2)) }
                        }
                        Surface(shape=RoundedCornerShape(16.dp), color=if(bassBoost) Color(0xFFFFB02E).copy(alpha=.20f) else Color.Black.copy(alpha=.16f), border=BorderStroke(1.dp,if(bassBoost)Color(0xFFFFC857) else Color.White.copy(alpha=.12f)), modifier=Modifier.clickable { if(!pro) onRequestPlan(MembershipTier.PRATA) else { bassBoost=!bassBoost;prefs.edit().putBoolean("bass_boost",bassBoost).apply();service?.setSonusBassBoost(enabled&&bassBoost) } }) {
                            Column(Modifier.padding(horizontal=12.dp,vertical=9.dp),horizontalAlignment=Alignment.CenterHorizontally){ Text("BASS",fontSize=10.sp,fontWeight=FontWeight.Black,color=if(bassBoost)Color(0xFFFFC857) else LocalContentColor.current); Text(if(pro) "BOOST" else "PRO",fontSize=9.sp,fontWeight=FontWeight.Bold) }
                        }
                    }
                }
            }
        }
        item {
            Surface(shape=RoundedCornerShape(20.dp), color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.40f), border=BorderStroke(1.dp,accent.copy(alpha=.22f))) {
                Column(Modifier.padding(horizontal=12.dp,vertical=10.dp),verticalArrangement=Arrangement.spacedBy(5.dp)) {
                    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
                        Text("CURVA EQ",fontSize=10.sp,letterSpacing=1.1.sp,fontWeight=FontWeight.Black,color=accent)
                        Spacer(Modifier.weight(1f))
                        Text(if(!enabled) "Neutro" else if(autoEq) "Auto" else preset,fontSize=10.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.55f))
                    }
                    Canvas(Modifier.fillMaxWidth().height(112.dp)) {
                        val left=4.dp.toPx(); val right=size.width-4.dp.toPx(); val top=6.dp.toPx(); val bottom=size.height-20.dp.toPx(); val zero=(top+bottom)/2f
                        val labels=listOf("31","62","125","250","500","1k","2k","4k","8k","16k")
                        // Escala visual adaptativa: os dB reais não mudam, apenas usamos melhor
                        // a altura disponível para tornar cada preset/Auto EQ claramente distinto.
                        val actualPeak = animatedCurve.maxOfOrNull { kotlin.math.abs(it) } ?: 0f
                        val visualPeak = (actualPeak * 1.15f).coerceAtLeast(1.20f).coerceAtMost(10f)
                        val pts=animatedCurve.mapIndexed { i,v -> Offset(left+(right-left)*i/9f, zero-(v.coerceIn(-visualPeak,visualPeak)/visualPeak)*(bottom-top)*.46f) }
                        for(i in 0..9){ val x=left+(right-left)*i/9f; drawLine(Color.White.copy(alpha=.07f),Offset(x,top),Offset(x,bottom),1.dp.toPx()) }
                        drawLine(Color.White.copy(alpha=.16f),Offset(left,zero),Offset(right,zero),1.dp.toPx())
                        val path=Path().apply { moveTo(pts.first().x,pts.first().y); for(i in 1 until pts.size){ val a=pts[i-1]; val b=pts[i]; val mid=(a.x+b.x)/2f; cubicTo(mid,a.y,mid,b.y,b.x,b.y) } }
                        val fill=Path().apply { addPath(path); lineTo(pts.last().x,bottom); lineTo(pts.first().x,bottom); close() }
                        val brush=Brush.horizontalGradient(curveColors,startX=left,endX=right)
                        drawPath(fill,brush,alpha=.27f)
                        drawPath(path,brush,style=androidx.compose.ui.graphics.drawscope.Stroke(4.1.dp.toPx(),cap=StrokeCap.Round))
                        labels.forEachIndexed { i,t -> drawContext.canvas.nativeCanvas.apply { val paint=android.graphics.Paint().apply { color=android.graphics.Color.argb(150,255,255,255);textSize=9.sp.toPx();textAlign=android.graphics.Paint.Align.CENTER;isAntiAlias=true }; drawText(t,left+(right-left)*i/9f,size.height-3.dp.toPx(),paint) } }
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                Surface(shape=RoundedCornerShape(16.dp),color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.5f),modifier=Modifier.weight(1f).clickable{expanded=!expanded}) { Row(Modifier.padding(13.dp),verticalAlignment=Alignment.CenterVertically){ Text(if(preset=="Personalizado")"Personalizado" else preset,Modifier.weight(1f),fontWeight=FontWeight.Bold);Icon(if(expanded)Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,null) } }
                Surface(shape=RoundedCornerShape(16.dp),color=if(autoEq)accent.copy(alpha=.18f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.5f),border=BorderStroke(1.dp,if(autoEq)accent else Color.Transparent),modifier=Modifier.clickable{ if(!pro) onRequestPlan(MembershipTier.PRATA) else {autoEq=!autoEq;prefs.edit().putBoolean("auto",autoEq).apply();apply()} }) { Row(Modifier.padding(horizontal=12.dp,vertical=13.dp),verticalAlignment=Alignment.CenterVertically){ Icon(Icons.Default.AutoAwesome,null,tint=accent,modifier=Modifier.size(17.dp));Spacer(Modifier.width(5.dp));Text(if(pro)"EQ Auto" else "EQ Auto • PRO",fontWeight=FontWeight.Bold,fontSize=12.sp) } }
            }
        }
        if(expanded) item { Surface(shape=RoundedCornerShape(18.dp),color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.42f)){ Column(Modifier.padding(10.dp)){ presets.keys.forEach { name -> Row(Modifier.fillMaxWidth().clickable{autoEq=false;setPreset(name);expanded=false}.padding(10.dp),verticalAlignment=Alignment.CenterVertically){ Text(name,Modifier.weight(1f));if(preset==name&&!autoEq)Icon(Icons.Default.Check,null,tint=accent) } } } } }
        item {
            Surface(shape=RoundedCornerShape(22.dp),color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.48f)) {
                Column(Modifier.padding(15.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
                    Text("AJUSTE FINO",fontSize=11.sp,letterSpacing=1.2.sp,fontWeight=FontWeight.Black,color=accent)
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly){ SonusEqKnob("GRAVE",bass,accent){autoEq=false;setTone(0,it)}; SonusEqKnob("MÉDIO",mids,accent){autoEq=false;setTone(1,it)}; SonusEqKnob("AGUDO",treble,accent){autoEq=false;setTone(2,it)} }
                }
            }
        }
        item {
            Box { Surface(shape=RoundedCornerShape(16.dp),color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.42f),modifier=Modifier.fillMaxWidth().clickable{themeMenu=true}) { Row(Modifier.padding(13.dp),verticalAlignment=Alignment.CenterVertically){ Icon(Icons.Default.Palette,null,tint=accent);Spacer(Modifier.width(8.dp));Text("Tema: $eqTheme",Modifier.weight(1f),fontWeight=FontWeight.Bold);Icon(Icons.Default.KeyboardArrowDown,null) } }; DropdownMenu(expanded=themeMenu,onDismissRequest={themeMenu=false}) { (listOf("Seguir Player")+themeMap.keys.toList()).forEach { n -> DropdownMenuItem(text={Text(n)},onClick={eqTheme=n;themeMenu=false;prefs.edit().putString("theme",n).apply()}) } } }
        }
        item { Text("EQ Automático usa o gênero gravado na própria música. Tags ausentes ou desconhecidas recebem curva neutra. As curvas usam ganhos moderados para preservar dinâmica e reduzir distorção.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.58f)) }
    }
}

@Composable
private fun SonusEqKnob(label:String,value:Float,accent:Color,onChange:(Float)->Unit){
    val angle=135f + ((value+10f)/20f)*270f
    Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.width(86.dp)){
        Canvas(Modifier.size(76.dp).pointerInput(Unit){
            fun update(pos:Offset){
                val cx=size.width/2f; val cy=size.height/2f
                var deg=Math.toDegrees(kotlin.math.atan2((pos.y-cy).toDouble(),(pos.x-cx).toDouble())).toFloat()
                if(deg<135f) deg+=360f
                val clamped=deg.coerceIn(135f,405f)
                val next=(((clamped-135f)/270f)*20f-10f).coerceIn(-10f,10f)
                onChange((next*10f).roundToInt()/10f)
            }
            detectDragGestures(
                onDragStart={ update(it) },
                onDrag={ change,_ -> change.consume(); update(change.position) }
            )
        }){
            val stroke=5.dp.toPx()
            drawArc(Color.White.copy(alpha=.10f),135f,270f,false,style=androidx.compose.ui.graphics.drawscope.Stroke(stroke,cap=StrokeCap.Round))
            val sweep=((value+10f)/20f*270f).coerceIn(0f,270f)
            if(sweep>0.5f) drawArc(Brush.sweepGradient(listOf(accent.copy(alpha=.55f),accent,accent.copy(alpha=.8f))),135f,sweep,false,style=androidx.compose.ui.graphics.drawscope.Stroke(stroke,cap=StrokeCap.Round))
            val rad=Math.toRadians(angle.toDouble()); val r=size.minDimension*.28f; val c=center
            drawCircle(Color.Black.copy(alpha=.30f),size.minDimension*.32f,c)
            drawCircle(Color.White.copy(alpha=.06f),size.minDimension*.25f,c)
            drawLine(accent,c,Offset(c.x+(kotlin.math.cos(rad)*r).toFloat(),c.y+(kotlin.math.sin(rad)*r).toFloat()),2.5.dp.toPx(),StrokeCap.Round)
        }
        Text(label,fontSize=10.sp,fontWeight=FontWeight.Black)
        Text(String.format("%+.1f",value),fontSize=11.sp,color=accent,fontWeight=FontWeight.Bold)
    }
}

@Composable
private fun SettingsSwitch(title: String, subtitle: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Surface(shape = RoundedCornerShape(16.dp), color = Color.Black.copy(alpha = .18f)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .62f))
            }
            Switch(checked = checked, onCheckedChange = onChecked)
        }
    }
}

@Composable private fun QuickEq(label:String,value:Float,onChange:(Float)->Unit){Row(verticalAlignment=Alignment.CenterVertically){Text(label,Modifier.width(68.dp),fontWeight=FontWeight.SemiBold);Slider(value,onChange,valueRange=-6f..6f,modifier=Modifier.weight(1f));Text(String.format("%+.1f",value),Modifier.width(46.dp),textAlign=TextAlign.End)}}

@Composable
private fun ThemesScreen(
    themes: List<PlayerThemeSpec>,
    tier: MembershipTier,
    selected: String,
    onSelect: (PlayerThemeSpec) -> Unit
) {
    LazyColumn(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement=Arrangement.spacedBy(9.dp),
        contentPadding=PaddingValues(bottom=24.dp)
    ) {
        item {
            Text("Temas do SONUS PLAYER",fontWeight=FontWeight.Black,fontSize=22.sp)
            Text("Cada tema mostra claramente o plano necessário.",style=MaterialTheme.typography.bodySmall)
        }
        items(themes,key={it.id}) { t ->
            val unlocked=hasTier(tier,t.tier)
            val tierLabel=when(t.tier){
                MembershipTier.FREE->"FREE"
                MembershipTier.BRONZE->"PRATA"
                MembershipTier.PRATA->"PRATA"
                MembershipTier.OURO->"OURO"
                MembershipTier.DIAMANTE->"DIAMANTE"
            }
            Surface(
                shape=RoundedCornerShape(18.dp),
                border=BorderStroke(if(selected==t.id)2.dp else 1.dp,if(selected==t.id)t.glow else Color.White.copy(alpha=.12f)),
                color=Color.Transparent,
                modifier=Modifier.fillMaxWidth().clickable(enabled=unlocked){onSelect(t)}
            ) {
                Row(Modifier.background(Brush.linearGradient(t.colors)).padding(14.dp),verticalAlignment=Alignment.CenterVertically) {
                    Box(Modifier.size(46.dp).background(Brush.radialGradient(listOf(t.glow,Color.Transparent)),CircleShape))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(t.name,color=Color.White,fontWeight=FontWeight.Black)
                        Spacer(Modifier.height(4.dp))
                        Surface(
                            shape=RoundedCornerShape(50),
                            color=if(t.tier==MembershipTier.FREE) Color.White.copy(alpha=.14f) else t.glow.copy(alpha=.18f),
                            border=BorderStroke(1.dp,if(t.tier==MembershipTier.FREE) Color.White.copy(alpha=.18f) else t.glow.copy(alpha=.45f))
                        ) {
                            Row(Modifier.padding(horizontal=8.dp,vertical=3.dp),verticalAlignment=Alignment.CenterVertically) {
                                if(t.tier!=MembershipTier.FREE) {
                                    Icon(Icons.Default.Star,null,tint=t.glow,modifier=Modifier.size(13.dp))
                                    Spacer(Modifier.width(4.dp))
                                }
                                Text(tierLabel,color=Color.White.copy(alpha=.92f),fontSize=9.sp,fontWeight=FontWeight.Black,letterSpacing=.6.sp)
                            }
                        }
                    }
                    Icon(if(unlocked){if(selected==t.id)Icons.Default.CheckCircle else Icons.Default.ChevronRight}else Icons.Default.Lock,null,tint=Color.White)
                }
            }
        }
    }
}

@Composable private fun CreatorModeScreen(current:PulsePlayerQueueItem?,onAction:(PulseCreatorAction)->Unit){val actions=listOf(PulseCreatorAction.ANALYZER to ("Analisar áudio" to Icons.Default.Analytics),PulseCreatorAction.CUTTER to ("Cortar" to Icons.Default.ContentCut),PulseCreatorAction.CONVERTER to ("Converter" to Icons.Default.Transform),PulseCreatorAction.PITCH to ("Alterar tom" to Icons.Default.Tune),PulseCreatorAction.METADATA to ("Metadados" to Icons.Default.Sell),PulseCreatorAction.MERGE to ("Mesclar" to Icons.Default.MergeType));LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){item{Text("Creator Mode",fontWeight=FontWeight.Black,fontSize=22.sp);Text(current?.let{"Faixa atual: ${it.title}"}?:"Reproduza uma música e abra qualquer ferramenta do SONUS.",style=MaterialTheme.typography.bodySmall)};items(actions){(a,p)->Card(onClick={onAction(a)}){Row(Modifier.fillMaxWidth().padding(14.dp),verticalAlignment=Alignment.CenterVertically){Icon(p.second,null);Spacer(Modifier.width(10.dp));Text(p.first,Modifier.weight(1f),fontWeight=FontWeight.Bold);Icon(Icons.Default.ChevronRight,null)}}}}}

@Composable
private fun PlayerSettingsScreen(
    store: PulsePlayerLibraryStore,
    playback: PulsePlayerPlaybackState,
    membershipTier: MembershipTier,
    ownerDiagnostic: Boolean,
    reduce: Boolean,
    onReduce: (Boolean) -> Unit,
    service: PulsePlayerService?,
    playerInterfaceId: String,
    onPlayerInterfaceId: (String) -> Unit,
    visualizerId: String,
    onVisualizerId: (String) -> Unit,
    visualizerIntensity: Int,
    onVisualizerIntensity: (Int) -> Unit,
    visualizerSensitivity: Float,
    onVisualizerSensitivity: (Float) -> Unit,
    visualizerSmoothness: Int,
    onVisualizerSmoothness: (Int) -> Unit,
    visualizerEnabled: Boolean,
    onVisualizerEnabled: (Boolean) -> Unit,
    keepScreenOn: Boolean,
    onKeepScreenOn: (Boolean) -> Unit,
    onOpenThemes: () -> Unit,
    treePicker: () -> Unit,
    rescan: () -> Unit,
    clearStats: () -> Unit
) {
    var crossfade by remember { mutableFloatStateOf(playback.crossfadeSeconds.toFloat()) }
    var speed by remember { mutableFloatStateOf(playback.playbackSpeed) }
    var excludes by remember { mutableStateOf(store.excludedFolders.joinToString("; ")) }
    var folderPromptEnabledSetting by remember { mutableStateOf(store.folderPromptEnabled) }
    val sleepRemaining = playback.sleepEndEpochMs?.let { ((it - System.currentTimeMillis()).coerceAtLeast(0L) / 60_000L).coerceAtLeast(1L) }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement=Arrangement.spacedBy(10.dp), contentPadding=PaddingValues(bottom=28.dp)) {
        item { Text("Ajustes do Player", fontWeight=FontWeight.Black, fontSize=22.sp) }
        item {
            Card {
                Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment=Alignment.CenterVertically) {
                    Icon(Icons.Default.PauseCircle, null, tint=MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(9.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Estado de reprodução", fontWeight=FontWeight.Bold)
                        Text("Pause continua pause. Se o SONUS estava tocando, a reprodução continua ao navegar pelo app.", style=MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
        item {
            Card {
                Column(Modifier.padding(14.dp), verticalArrangement=Arrangement.spacedBy(9.dp)) {
                    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
                        Icon(Icons.Default.DashboardCustomize,null,tint=MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp));Text("Interface do Player",fontWeight=FontWeight.ExtraBold,modifier=Modifier.weight(1f))
                    }
                    Text("O tema continua funcionando em qualquer interface. O player FREE permanece completo; os layouts extras valorizam cada plano.",style=MaterialTheme.typography.bodySmall)
                    PulsePlayerInterfaces.forEach { spec ->
                        val unlocked=hasTier(membershipTier,spec.tier)
                        Surface(
                            shape=RoundedCornerShape(14.dp),
                            color=if(playerInterfaceId==spec.id)MaterialTheme.colorScheme.primaryContainer.copy(alpha=.55f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.28f),
                            modifier=Modifier.fillMaxWidth().clickable(enabled=unlocked){onPlayerInterfaceId(spec.id)}
                        ){
                            Row(Modifier.padding(11.dp),verticalAlignment=Alignment.CenterVertically){
                                Surface(Modifier.size(38.dp),shape=RoundedCornerShape(10.dp),color=MaterialTheme.colorScheme.primary.copy(alpha=.14f)){
                                    Box(contentAlignment=Alignment.Center){Icon(when(spec.id){"cassette_retro"->Icons.Default.QueueMusic;"turntable_classic","vinyl_glow","orbit","neon_disc"->Icons.Default.Album;"arc_light"->Icons.Default.GraphicEq;else->Icons.Default.MusicNote},null,tint=MaterialTheme.colorScheme.primary)}
                                }
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)){Text(spec.name,fontWeight=FontWeight.Bold);Text(spec.description,style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}
                                if(!unlocked) Surface(shape=RoundedCornerShape(50),color=Color(0xFFFFC84B).copy(alpha=.16f)){Text(spec.badge,modifier=Modifier.padding(horizontal=7.dp,vertical=3.dp),fontSize=8.sp,fontWeight=FontWeight.Black,color=Color(0xFFFFC84B))}
                                else if(playerInterfaceId==spec.id) Icon(Icons.Default.CheckCircle,null,tint=MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
        }
        item {
            Card {
                Column(Modifier.padding(14.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("Visualização de áudio", fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                        if (ownerDiagnostic) Text("Motor: ${playback.spectrumEngine}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    SettingsSwitch("Visualização reativa", "Barras e VU Meter acompanham a interface escolhida com o mesmo motor fluido", visualizerEnabled, onVisualizerEnabled)
                    if(visualizerEnabled){
                        Text("Intensidade: $visualizerIntensity%",fontWeight=FontWeight.Bold)
                        Slider(visualizerIntensity.toFloat(),{onVisualizerIntensity(it.roundToInt())},valueRange=50f..200f,steps=14)
                        Text("Sensibilidade: ${String.format(java.util.Locale.US,"%.1fx",visualizerSensitivity)}",fontWeight=FontWeight.Bold)
                        Slider(visualizerSensitivity,{onVisualizerSensitivity(it)},valueRange=.7f..2.2f,steps=14)
                        Text("Suavidade",fontWeight=FontWeight.Bold)
                        Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){
                            listOf(0 to "Rápida",1 to "Equilibrada",2 to "Suave").forEach{(value,label)->FilterChip(selected=visualizerSmoothness==value,onClick={onVisualizerSmoothness(value)},label={Text(label)})}
                        }
                        Text("Cores da visualização",fontWeight=FontWeight.Bold)
                        PulsePlayerVisualizers.forEach { spec ->
                            val unlocked=hasTier(membershipTier,spec.tier)
                            Surface(shape=RoundedCornerShape(14.dp),color=if(visualizerId==spec.id)MaterialTheme.colorScheme.primaryContainer.copy(alpha=.48f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.28f),modifier=Modifier.fillMaxWidth().clickable(enabled=unlocked){onVisualizerId(spec.id)}) {
                                Row(Modifier.padding(10.dp),verticalAlignment=Alignment.CenterVertically){
                                    Row(Modifier.width(104.dp),horizontalArrangement=Arrangement.spacedBy(2.dp)){spec.colors.take(6).forEach{c->Box(Modifier.weight(1f).height(20.dp).background(c,RoundedCornerShape(5.dp)))}}
                                    Spacer(Modifier.width(9.dp));Text(spec.name,Modifier.weight(1f),fontWeight=FontWeight.SemiBold)
                                    if(!unlocked) Icon(Icons.Default.Lock,null,tint=Color(0xFFFFC84B),modifier=Modifier.size(17.dp)) else if(visualizerId==spec.id) Icon(Icons.Default.CheckCircle,null,tint=MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    }
                }
            }
        }
        item { SettingsSwitch("Reduzir animações", "Economiza bateria e reduz os movimentos do fundo do Player", reduce, onReduce) }
        item { SettingsSwitch("Manter tela ligada", "Mantém a tela acesa enquanto o Player do SONUS estiver aberto", keepScreenOn, onKeepScreenOn) }
        item { SettingsSwitch("Nivelamento de reprodução", "Ajuste leve para reduzir saltos bruscos de volume", playback.normalization) { service?.setNormalization(it) } }
        item {
            Card { Column(Modifier.padding(13.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                Text("Ordem e repetição",fontWeight=FontWeight.Bold)
                SettingsSwitch("Modo aleatório", "A escolha fica salva mesmo ao sair e voltar ao Player", playback.shuffle){enabled->service?.setShuffle(enabled);store.shuffle=enabled}
                Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){
                    listOf(0 to "Sem repetir",1 to "Lista",2 to "Faixa").forEach{(mode,label)->FilterChip(selected=playback.repeatMode==mode,onClick={service?.setRepeatMode(mode);store.repeatMode=mode},label={Text(label)})}
                }
            } }
        }
        item {
            Card { Column(Modifier.padding(13.dp)) {
                Text("Crossfade: ${crossfade.roundToInt()} s", fontWeight=FontWeight.Bold)
                Slider(crossfade, { crossfade=it; service?.setCrossfade(it.roundToInt()); store.crossfade=it.roundToInt() }, valueRange=0f..12f, steps=11)
            } }
        }
        item {
            Card { Column(Modifier.padding(13.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
                Text("Velocidade sem alterar o tom", fontWeight=FontWeight.Bold)
                Text("${String.format(java.util.Locale.US, "%.2fx", speed)} • útil para estudo e ensaio", style=MaterialTheme.typography.bodySmall)
                Slider(speed, { value -> speed=value; store.playbackSpeed=value; service?.setPlaybackSpeed(value) }, valueRange=.5f..2f, steps=14)
                Row(horizontalArrangement=Arrangement.spacedBy(7.dp)) { listOf(.75f, 1f, 1.25f, 1.5f).forEach { value -> AssistChip(onClick={speed=value;store.playbackSpeed=value;service?.setPlaybackSpeed(value)}, label={Text("${value}x")}) } }
            } }
        }
        item {
            Card { Column(Modifier.padding(13.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
                Text("Loop A–B", fontWeight=FontWeight.Bold)
                Text(when { playback.loopStartMs == null -> "Defina A no ponto inicial do trecho"; playback.loopEndMs == null -> "A = ${formatClock(playback.loopStartMs)} • agora defina B"; else -> "${formatClock(playback.loopStartMs)} ↔ ${formatClock(playback.loopEndMs)} • repetição ativa" }, style=MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                    OutlinedButton(onClick={service?.setLoopStartAtCurrent()}, enabled=playback.current!=null, modifier=Modifier.weight(1f)){Text("Marcar A")}
                    OutlinedButton(onClick={service?.setLoopEndAtCurrent()}, enabled=playback.loopStartMs!=null && playback.current!=null, modifier=Modifier.weight(1f)){Text("Marcar B")}
                    IconButton(onClick={service?.clearLoop()}, enabled=playback.loopStartMs!=null){Icon(Icons.Default.Clear,null)}
                }
            } }
        }
        item {
            Card { Column(Modifier.padding(13.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
                Text("Temporizador", fontWeight=FontWeight.Bold)
                Text(when { playback.stopAfterCurrent -> "Parar ao fim da música atual"; sleepRemaining != null -> "Desliga em aproximadamente $sleepRemaining min"; else -> "Pare a reprodução automaticamente" }, style=MaterialTheme.typography.bodySmall)
                LazyRow(horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                    items(listOf(15,30,60)) { min -> AssistChip(onClick={service?.setStopAfterCurrent(false);service?.setSleepTimerMinutes(min)}, label={Text("$min min")}) }
                    item { AssistChip(onClick={service?.clearSleepTimer();service?.setStopAfterCurrent(true)}, label={Text("Fim da música")}) }
                    item { AssistChip(onClick={service?.clearSleepTimer();service?.setStopAfterCurrent(false)}, label={Text("Desligar")}, enabled=playback.sleepEndEpochMs!=null || playback.stopAfterCurrent) }
                }
            } }
        }
        item {
            Card { Column(Modifier.padding(13.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                Text("Temas",fontWeight=FontWeight.Bold)
                Text("Cores e Dynamic SONUS+ continuam compatíveis com todas as interfaces.",style=MaterialTheme.typography.bodySmall)
                OutlinedButton(onClick=onOpenThemes,modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Palette,null);Spacer(Modifier.width(6.dp));Text("Abrir temas do Player")}
            } }
        }
        item {
            Card { Column(Modifier.padding(13.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
                Text("Biblioteca", fontWeight=FontWeight.Bold)
                SettingsSwitch("Lembrar de selecionar pasta local", "Mostra um aviso discreto no Player quando nenhuma biblioteca local estiver vinculada", folderPromptEnabledSetting) { enabled -> folderPromptEnabledSetting = enabled; store.folderPromptEnabled = enabled }
                Text(store.rootUri ?: "Nenhuma pasta raiz definida", style=MaterialTheme.typography.bodySmall, maxLines=2, overflow=TextOverflow.Ellipsis)
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick=treePicker, modifier=Modifier.weight(1f)) { Text("Trocar pasta") }
                    OutlinedButton(onClick=rescan, modifier=Modifier.weight(1f)) { Text("Atualizar") }
                }
                OutlinedTextField(excludes, { value -> excludes=value;store.excludedFolders=value.split(';').map(String::trim).filter(String::isNotBlank).toSet() }, label={Text("Pastas ignoradas • separadas por ;")}, placeholder={Text("WhatsApp; Recordings; Notifications")}, modifier=Modifier.fillMaxWidth())
            } }
        }
        item {
            Card { Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Player de Música • v$SONUS_AUDIO_PLAYER_VERSION", fontWeight = FontWeight.ExtraBold)
                Text("Formatos compatíveis", fontWeight = FontWeight.Bold)
                Text(SONUS_AUDIO_FORMATS.joinToString(" • "), style = MaterialTheme.typography.bodySmall)
                Text("A compatibilidade final depende do codec/decoder disponível no aparelho.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha=.55f))
            } }
        }
        item { OutlinedButton(onClick=clearStats, modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.DeleteSweep,null); Spacer(Modifier.width(7.dp)); Text("Limpar estatísticas do SONUS PLAYER") } }
    }
}

private class PulsePlayerLibraryStore(context:Context){
    private val p=context.getSharedPreferences("pulse_player_library_v1",Context.MODE_PRIVATE)
    var rootUri:String? get()=p.getString("root",null);set(v){p.edit().putString("root",v).apply()}
    var folderPromptEnabled:Boolean get()=p.getBoolean("folderPromptEnabled",true);set(v){p.edit().putBoolean("folderPromptEnabled",v).apply()}
    fun recentStreamSuggestionIds(): Set<Long> = p.getStringSet("recentStreamSuggestions", emptySet()).orEmpty().mapNotNull { it.toLongOrNull() }.toSet()
    fun rememberStreamSuggestion(fileId:Long) {
        val recent = (listOf(fileId) + recentStreamSuggestionIds().toList()).distinct().take(8).map(Long::toString).toSet()
        p.edit().putStringSet("recentStreamSuggestions", recent).apply()
    }
    var themeId:String get()=p.getString("theme","midnight_blue")?:"midnight_blue";set(v){p.edit().putString("theme",v).apply()}
    var playerInterfaceId:String get()=p.getString("playerInterface","classic")?:"classic";set(v){p.edit().putString("playerInterface",v).apply()}
    var visualizerId:String get()=p.getString("visualizer","sonus_multi")?:"sonus_multi";set(v){p.edit().putString("visualizer",v).apply()}
    var visualizerIntensity:Int
        get() {
            val raw=p.getInt("visualizerIntensity",100)
            return if(raw<=2) when(raw){0->70;1->100;else->140} else raw.coerceIn(50,200)
        }
        set(v){p.edit().putInt("visualizerIntensity",v.coerceIn(50,200)).apply()}
    var visualizerSensitivity:Float get()=p.getFloat("visualizerSensitivity",1f).coerceIn(.70f,2.2f);set(v){p.edit().putFloat("visualizerSensitivity",v.coerceIn(.70f,2.2f)).apply()}
    var visualizerSmoothness:Int get()=p.getInt("visualizerSmoothness",1).coerceIn(0,2);set(v){p.edit().putInt("visualizerSmoothness",v.coerceIn(0,2)).apply()}
    var visualizerEnabled:Boolean get()=p.getBoolean("visualizerEnabled",true);set(v){p.edit().putBoolean("visualizerEnabled",v).apply()}
    var keepScreenOn:Boolean get()=p.getBoolean("keepScreenOn",false);set(v){p.edit().putBoolean("keepScreenOn",v).apply()}
    var reduceAnimations:Boolean get()=p.getBoolean("reduce",false);set(v){p.edit().putBoolean("reduce",v).apply()}
    var autoPlay:Boolean get()=p.getBoolean("autoplay",false);set(v){p.edit().putBoolean("autoplay",v).apply()}
    var lastTrackUri:String? get()=p.getString("lastTrackUri",null);set(v){p.edit().putString("lastTrackUri",v).apply()}
    var lastPositionMs:Long get()=p.getLong("lastPositionMs",0L).coerceAtLeast(0L);set(v){p.edit().putLong("lastPositionMs",v.coerceAtLeast(0L)).apply()}
    var shuffle:Boolean get()=p.getBoolean("shuffle",false);set(v){p.edit().putBoolean("shuffle",v).apply()}
    var shuffleMode:String get()=p.getString("shuffle_mode","off")?:"off";set(v){p.edit().putString("shuffle_mode",v).apply()}
    var librarySortMode:LibrarySortMode
        get()=runCatching{LibrarySortMode.valueOf(p.getString("library_sort",LibrarySortMode.TITLE_ASC.name)?:LibrarySortMode.TITLE_ASC.name)}.getOrDefault(LibrarySortMode.TITLE_ASC)
        set(v){p.edit().putString("library_sort",v.name).apply()}
    var repeatMode:Int get()=p.getInt("repeatMode",0).coerceIn(0,2);set(v){p.edit().putInt("repeatMode",v.coerceIn(0,2)).apply()}
    var crossfade:Int get()=p.getInt("crossfade",0);set(v){p.edit().putInt("crossfade",v).apply()}
    var playbackSpeed:Float get()=p.getFloat("speed",1f).coerceIn(.5f,2f);set(v){p.edit().putFloat("speed",v.coerceIn(.5f,2f)).apply()}
    var liked:Set<String> get()=p.getStringSet("liked",emptySet())?.toSet()?:emptySet();set(v){p.edit().putStringSet("liked",v).apply()}
    var pinned:Set<String> get()=p.getStringSet("pinned",emptySet())?.toSet()?:emptySet();set(v){p.edit().putStringSet("pinned",v).apply()}
    var excludedFolders:Set<String> get()=p.getStringSet("excluded",setOf("WhatsApp","Notifications","Ringtones"))?.toSet()?:emptySet();set(v){p.edit().putStringSet("excluded",v).apply()}
    var swipeTutorialSeen:Boolean get()=p.getBoolean("visualizerSwipeTutorialSeen",false);set(v){p.edit().putBoolean("visualizerSwipeTutorialSeen",v).apply()}
    var lastLibraryScanAt:Long get()=p.getLong("lastLibraryScanAt",0L);set(v){p.edit().putLong("lastLibraryScanAt",v).apply()}
    fun playlists():Map<String,List<String>>{val o=runCatching{JSONObject(p.getString("playlists","{}")?:"{}")}.getOrElse{JSONObject()};return o.keys().asSequence().associateWith{k->val a=o.optJSONArray(k)?:JSONArray();(0 until a.length()).mapNotNull{a.optString(it).takeIf(String::isNotBlank)}}}
    private fun save(m:Map<String,List<String>>):Map<String,List<String>>{val o=JSONObject();m.forEach{(k,v)->o.put(k,JSONArray(v))};p.edit().putString("playlists",o.toString()).apply();return m}
    fun createPlaylist(name:String)=save(playlists()+ (name to playlists()[name].orEmpty()))
    fun addToPlaylist(name:String,uri:String)=save(playlists()+ (name to (playlists()[name].orEmpty()+uri).distinct()))
    fun cachedTracks(): List<PulseLibraryTrack> = runCatching {
        val a=JSONArray(p.getString("libraryCache","[]")?:"[]")
        (0 until a.length()).mapNotNull { i ->
            val o=a.optJSONObject(i)?:return@mapNotNull null
            val uri=o.optString("uri"); if(uri.isBlank()) return@mapNotNull null
            PulseLibraryTrack(
                PulsePlayerQueueItem(uri,o.optString("title"),o.optString("artist"),o.optString("album"),o.optString("genre"),o.optLong("duration")),
                o.optString("folder"),o.optString("lrc").takeIf{it.isNotBlank()},o.optLong("modified")
            )
        }
    }.getOrDefault(emptyList())
    fun saveCachedTracks(items: List<PulseLibraryTrack>) {
        val a=JSONArray()
        items.forEach { t -> a.put(JSONObject().apply {
            put("uri",t.queue.uri);put("title",t.queue.title);put("artist",t.queue.artist);put("album",t.queue.album);put("genre",t.queue.genre);put("duration",t.queue.durationMs);put("folder",t.folder);put("lrc",t.lrcUri?:"");put("modified",t.lastModified)
        }) }
        p.edit().putString("libraryCache",a.toString()).apply()
    }
}

private fun playerGenreFamily(raw:String):String {
    if(raw.isBlank()) return ""
    val normalized = Normalizer.normalize(raw.lowercase(Locale.getDefault()), Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "")
    return when {
        listOf("catolic","gospel","crista","louvor","worship","religios").any(normalized::contains) -> "faith"
        listOf("piseiro","pisadinha","forro","vaquejada").any(normalized::contains) -> "piseiro"
        listOf("sertanej","arrocha","sofrencia").any(normalized::contains) -> "sertanejo"
        listOf("trap","funk","rap","hip hop","hip-hop").any(normalized::contains) -> "urban"
        listOf("rock","metal").any(normalized::contains) -> "rock"
        listOf("pop","dance","eletron").any(normalized::contains) -> "pop"
        else -> normalized.trim().substringBefore('/').substringBefore(',').trim()
    }
}

private fun streamSuggestionCatalog(repo:SonusOnlineMusicRepository):List<SonusOnlineTrack> {
    val published = repo.cachedPublishedGenres()
    return repo.cachedGenres().filter { published.isEmpty() || it.name in published }.flatMap { genre ->
        repo.cachedTracks(genre.path).map { track -> if(track.genre.isBlank()) track.copy(genre=genre.name) else track }
    }.distinctBy { it.fileId }
}

private suspend fun scanPulseLibrary(context:Context,tree:Uri,excluded:Set<String>,cached:List<PulseLibraryTrack> = emptyList()):Result<List<PulseLibraryTrack>> = runCatching {
    val root=DocumentFile.fromTreeUri(context,tree)?:error("Não foi possível abrir a pasta escolhida.")
    data class E(val f:DocumentFile,val path:String)
    val entries=mutableListOf<E>()
    fun walk(dir:DocumentFile,path:String){if(excluded.any{it.equals(dir.name,true)})return;dir.listFiles().forEach{f->val pth=if(path.isBlank())(f.name?:"") else "$path/${f.name?:""}";if(f.isDirectory)walk(f,pth)else entries+=E(f,path)}}
    walk(root,root.name.orEmpty())
    val lrc=entries.filter{it.f.name?.endsWith(".lrc",true)==true}.associateBy{it.f.name!!.substringBeforeLast('.').lowercase()}
    val old=cached.associateBy{it.queue.uri}
    val audioExt=setOf("mp3","wav","flac","m4a","aac","ogg","opus","aiff","aif","wma","amr","3gp","webm")
    entries.filter{e->e.f.type?.startsWith("audio/")==true||e.f.name?.substringAfterLast('.',"")?.lowercase() in audioExt}.mapNotNull{e->
        val uri=e.f.uri.toString(); val modified=e.f.lastModified(); val cachedTrack=old[uri]
        if(cachedTrack!=null && cachedTrack.lastModified==modified) {
            val file=e.f.name.orEmpty(); cachedTrack.copy(folder=e.path,lrcUri=lrc[file.substringBeforeLast('.').lowercase()]?.f?.uri?.toString())
        } else runCatching{
            val r=MediaMetadataRetriever();try{r.setDataSource(context,e.f.uri);val file=e.f.name.orEmpty();val rawTitle=r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE).orEmpty();val artist=r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST).orEmpty();val title=SonusMediaStandards.cleanDisplayTitle(rawTitle,file,artist);val album=r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM).orEmpty();val genre=r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_GENRE).orEmpty();val dur=r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()?:0L;val lyric=lrc[file.substringBeforeLast('.').lowercase()]?.f?.uri?.toString();PulseLibraryTrack(PulsePlayerQueueItem(uri,title,artist,album,genre,dur),e.path,lyric,modified)}finally{r.release()}
        }.getOrNull()
    }.sortedWith(compareBy<PulseLibraryTrack>{it.queue.artist.lowercase()}.thenBy{it.queue.album.lowercase()}.thenBy{it.queue.title.lowercase()})
}

private fun sortLibraryTracks(tracks:List<PulseLibraryTrack>,mode:LibrarySortMode):List<PulseLibraryTrack> = when(mode){
    LibrarySortMode.TITLE_ASC -> tracks.sortedBy{it.queue.title.lowercase()}
    LibrarySortMode.TITLE_DESC -> tracks.sortedByDescending{it.queue.title.lowercase()}
    LibrarySortMode.ARTIST_ASC -> tracks.sortedWith(compareBy<PulseLibraryTrack>{it.queue.artist.lowercase()}.thenBy{it.queue.title.lowercase()})
    LibrarySortMode.ARTIST_DESC -> tracks.sortedWith(compareByDescending<PulseLibraryTrack>{it.queue.artist.lowercase()}.thenBy{it.queue.title.lowercase()})
    LibrarySortMode.NEWEST -> tracks.sortedByDescending{it.lastModified}
    LibrarySortMode.OLDEST -> tracks.sortedBy{it.lastModified}
    LibrarySortMode.DURATION_DESC -> tracks.sortedByDescending{it.queue.durationMs}
    LibrarySortMode.DURATION_ASC -> tracks.sortedBy{it.queue.durationMs}
}

private fun filterTracks(tracks:List<PulseLibraryTrack>,q:String):List<PulseLibraryTrack>{val x=q.trim().lowercase();if(x.isBlank())return tracks;return tracks.filter{listOf(it.queue.title,it.queue.artist,it.queue.album,it.queue.genre,it.folder).any{s->s.lowercase().contains(x)}}}
private fun toggleSet(s:Set<String>,v:String)=if(v in s)s-v else s+v
private fun hasTier(current:MembershipTier,required:MembershipTier)=commercialTier(current).ordinal>=commercialTier(required).ordinal
private fun loadArtworkPalette(context:Context,uri:Uri):List<Color> = runCatching {
    val r=MediaMetadataRetriever(); try { r.setDataSource(context,uri); val bytes=r.embeddedPicture ?: return@runCatching emptyList(); val b=BitmapFactory.decodeByteArray(bytes,0,bytes.size) ?: return@runCatching emptyList();
        val pts=listOf(.18f to .22f,.50f to .35f,.78f to .28f,.28f to .72f,.72f to .70f); val out=pts.map{(xf,yf)-> val px=b.getPixel((b.width*xf).toInt().coerceIn(0,b.width-1),(b.height*yf).toInt().coerceIn(0,b.height-1)); val hsv=FloatArray(3);android.graphics.Color.colorToHSV(px,hsv);hsv[1]=hsv[1].coerceAtLeast(.58f);hsv[2]=hsv[2].coerceIn(.72f,1f);Color(android.graphics.Color.HSVToColor(hsv))}; b.recycle(); out.distinct().take(4)
    } finally { r.release() }
}.getOrDefault(emptyList())

private fun loadArtwork(context:Context,uri:Uri):ImageBitmap?=runCatching{val r=MediaMetadataRetriever();try{r.setDataSource(context,uri);r.embeddedPicture?.let{BitmapFactory.decodeByteArray(it,0,it.size)?.asImageBitmap()}}finally{r.release()}}.getOrNull()
private fun formatClock(ms:Long):String{val total=(ms/1000).coerceAtLeast(0);return "%02d:%02d".format(total/60,total%60)}
private fun formatLongDuration(ms:Long):String{val min=ms/60000;val h=min/60;return if(h>0)"${h}h ${min%60}min" else "${min} min"}
private fun sonusLrcLineAt(lrc:String,positionMs:Long):String? {
    // Compatibilidade LRC: fração com ponto ou vírgula, múltiplos timestamps por linha e tag [offset:].
    val timeRegex=Regex("\\[(\\d{1,3}):(\\d{2})(?:[.,](\\d{1,3}))?]")
    val offsetMs=Regex("\\[offset:([+-]?\\d+)]",RegexOption.IGNORE_CASE).find(lrc)?.groupValues?.getOrNull(1)?.toLongOrNull() ?: 0L
    var selected:String?=null
    var best=-1L
    lrc.lineSequence().forEach { raw ->
        val matches=timeRegex.findAll(raw).toList()
        if(matches.isEmpty()) return@forEach
        val lyric=raw.replace(timeRegex,"").trim().takeIf{it.isNotBlank()} ?: return@forEach
        matches.forEach { m ->
            val min=m.groupValues[1].toLongOrNull() ?: 0L
            val sec=m.groupValues[2].toLongOrNull() ?: 0L
            val frac=m.groupValues[3].padEnd(3,'0').take(3).toLongOrNull() ?: 0L
            val at=((min*60L+sec)*1000L+frac+offsetMs).coerceAtLeast(0L)
            if(at<=positionMs && at>=best){best=at;selected=lyric}
        }
    }
    return selected
}

private fun stripLrcTimestamps(s:String)=s.lines().joinToString("\n"){it.replace(Regex("\\[[0-9]{1,3}:[0-9]{2}(?:[.,][0-9]{1,3})?]"),"")}.trim()

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}
