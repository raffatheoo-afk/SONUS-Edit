package com.sonusstudios.streampulse.data

import android.content.Context
import android.net.Uri
import com.sonusstudios.streampulse.core.AppState
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.time.Instant
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

@Serializable
data class BackupManifest(
    val app: String = "SONUS",
    val backupFormatVersion: Int = 1,
    val appVersion: String,
    val createdAtIso: String,
    val schemaVersion: Int,
    val artists: Int,
    val snapshots: Int,
    val dailyRecords: Int,
    val payments: Int,
    val photos: Int,
    val backgroundPhotos: Int = 0
)

data class BackupPreview(
    val manifest: BackupManifest,
    val state: AppState,
    val photoBytesByArtistId: Map<String, ByteArray>,
    val backgroundPhotoBytes: ByteArray? = null
)

object BackupManager {
    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
        prettyPrint = true
    }

    fun writeBackup(context: Context, uri: Uri, state: AppState, appVersion: String): Result<BackupManifest> = runCatching {
        val existingPhotos = state.artists.mapNotNull { artist ->
            artist.photoPath?.let(::File)?.takeIf { it.exists() }?.let { artist.id to it }
        }
        val backgroundPhoto = state.preferences.backgroundPhotoPath?.let(::File)?.takeIf { it.exists() }
        val manifest = BackupManifest(
            appVersion = appVersion,
            createdAtIso = Instant.now().toString(),
            schemaVersion = state.schemaVersion,
            artists = state.artists.size,
            snapshots = state.snapshots.size,
            dailyRecords = state.dailyStreamRecords.size,
            payments = state.payments.size,
            photos = existingPhotos.size,
            backgroundPhotos = if (backgroundPhoto != null) 1 else 0
        )

        context.contentResolver.openOutputStream(uri)?.use { output ->
            ZipOutputStream(output.buffered()).use { zip ->
                fun putText(name: String, value: String) {
                    zip.putNextEntry(ZipEntry(name))
                    zip.write(value.toByteArray(Charsets.UTF_8))
                    zip.closeEntry()
                }
                putText("manifest.json", json.encodeToString(manifest))
                putText("data.json", json.encodeToString(state))
                existingPhotos.forEach { (artistId, file) ->
                    val ext = file.extension.takeIf { it.isNotBlank() } ?: "jpg"
                    zip.putNextEntry(ZipEntry("photos/$artistId.$ext"))
                    file.inputStream().buffered().use { it.copyTo(zip) }
                    zip.closeEntry()
                }
                backgroundPhoto?.let { file ->
                    zip.putNextEntry(ZipEntry("background/background.img"))
                    file.inputStream().buffered().use { it.copyTo(zip) }
                    zip.closeEntry()
                }
            }
        } ?: error("Não foi possível criar o arquivo de backup.")
        manifest
    }

    fun readBackup(context: Context, uri: Uri): Result<BackupPreview> = runCatching {
        var manifest: BackupManifest? = null
        var state: AppState? = null
        val photos = mutableMapOf<String, ByteArray>()
        var backgroundPhotoBytes: ByteArray? = null
        context.contentResolver.openInputStream(uri)?.use { input ->
            ZipInputStream(input.buffered()).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    when {
                        entry.name == "manifest.json" -> {
                            manifest = json.decodeFromString(zip.readBytes().toString(Charsets.UTF_8))
                        }
                        entry.name == "data.json" -> {
                            state = json.decodeFromString(zip.readBytes().toString(Charsets.UTF_8))
                        }
                        entry.name.startsWith("photos/") && !entry.isDirectory -> {
                            val id = entry.name.substringAfter("photos/").substringBeforeLast('.')
                            photos[id] = zip.readBytes()
                        }
                        entry.name == "background/background.img" -> {
                            backgroundPhotoBytes = zip.readBytes()
                        }
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
        } ?: error("Não foi possível abrir o backup.")

        val foundManifest = manifest ?: error("Backup inválido: manifest.json ausente.")
        require(foundManifest.app in setOf("SONUS", "StreamPulse")) { "Este arquivo não é um backup compatível com o SONUS." }
        require(foundManifest.backupFormatVersion <= 1) { "Backup criado por uma versão mais nova do SONUS." }
        val foundState = state ?: error("Backup inválido: data.json ausente.")
        BackupPreview(foundManifest, foundState, photos, backgroundPhotoBytes)
    }

    fun prepareRestoredState(context: Context, preview: BackupPreview): Result<AppState> = runCatching {
        val dir = File(context.filesDir, "artist_photos").apply { mkdirs() }
        val restoredArtists = preview.state.artists.map { artist ->
            val bytes = preview.photoBytesByArtistId[artist.id]
            if (bytes == null) artist.copy(photoPath = null)
            else {
                val file = File(dir, "${artist.id}_backup.jpg")
                file.writeBytes(bytes)
                artist.copy(photoPath = file.absolutePath)
            }
        }
        val restoredBackgroundPath = preview.backgroundPhotoBytes?.let { bytes ->
            val backgroundDir = File(context.filesDir, "backgrounds").apply { mkdirs() }
            File(backgroundDir, "restored_background.img").apply { writeBytes(bytes) }.absolutePath
        }
        preview.state.copy(
            schemaVersion = 10,
            artists = restoredArtists,
            preferences = preview.state.preferences.copy(backgroundPhotoPath = restoredBackgroundPath),
            selectedArtistId = preview.state.selectedArtistId?.takeIf { id -> restoredArtists.any { it.id == id } }
                ?: restoredArtists.firstOrNull()?.id,
            onboardingComplete = restoredArtists.isNotEmpty()
        )
    }
}
