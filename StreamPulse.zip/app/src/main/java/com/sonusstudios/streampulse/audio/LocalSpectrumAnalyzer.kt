package com.sonusstudios.streampulse.audio

import android.content.Context
import android.media.MediaCodec
import android.media.AudioFormat
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

data class SpectrumFrame(
    val timeMs: Long,
    val values: FloatArray,
    val rms: Float = 0f,
    val spectralFlux: Float = 0f,
    val bass: Float = 0f,
    val mid: Float = 0f,
    val treble: Float = 0f
)

data class AudioAnalysis(
    val frames: List<SpectrumFrame>,
    val estimatedBpm: Int?,
    val peakEnergy: Float,
    val sampleRate: Int = 44_100,
    val fftSize: Int = 2048
)

/**
 * Analisador offline independente de android.media.audiofx.Visualizer.
 * A 0.7.7 usa PCM real + FFT de 2048 pontos, bandas logarítmicas, RMS,
 * spectral flux e smoothing. Preview e export podem consumir o mesmo buffer
 * timestampado para não criarem batidas artificiais.
 */
object LocalSpectrumAnalyzer {
    private const val FFT_SIZE = 2048
    private const val HOP_SIZE = 1024
    private const val OUTPUT_BANDS = 64
    private const val SILENCE_FLOOR = 0.02f
    private const val SMOOTHING = 0.65f

    suspend fun analyze(
        context: Context,
        uri: Uri,
        maxFrames: Int = 12_000,
        startMs: Long = 0L,
        headers: Map<String, String> = emptyMap()
    ): Result<AudioAnalysis> = withContext(Dispatchers.IO) {
        runCatching {
            val extractor = MediaExtractor()
            var codec: MediaCodec? = null
            try {
                // Streams HTTP(S) do SONUS podem precisar de headers. Arquivos locais/SAF
                // continuam usando o ContentResolver para preservar permissões persistentes.
                if (uri.scheme.equals("http", true) || uri.scheme.equals("https", true)) {
                    extractor.setDataSource(uri.toString(), headers)
                } else {
                    extractor.setDataSource(context, uri, if (headers.isEmpty()) null else headers)
                }
                var audioTrack = -1
                var format: MediaFormat? = null
                for (i in 0 until extractor.trackCount) {
                    val f = extractor.getTrackFormat(i)
                    if (f.getString(MediaFormat.KEY_MIME).orEmpty().startsWith("audio/")) {
                        audioTrack = i
                        format = f
                        break
                    }
                }
                require(audioTrack >= 0 && format != null) { "Faixa de áudio não encontrada" }
                extractor.selectTrack(audioTrack)
                val fmt = format!!
                val mime = fmt.getString(MediaFormat.KEY_MIME) ?: error("Codec de áudio desconhecido")
                var sampleRate = if (fmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44_100
                var channels = if (fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceAtLeast(1) else 1
                if (startMs > 0L) {
                    extractor.seekTo(startMs * 1000L, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
                }

                codec = MediaCodec.createDecoderByType(mime)
                // Preferimos PCM16 quando o decoder aceita, mas o leitor também trata PCM float.
                runCatching { fmt.setInteger(MediaFormat.KEY_PCM_ENCODING, AudioFormat.ENCODING_PCM_16BIT) }
                codec.configure(fmt, null, null, 0)
                codec.start()

                val info = MediaCodec.BufferInfo()
                val pcm = FloatArrayBuffer(FFT_SIZE * 4)
                val frames = ArrayList<SpectrumFrame>()
                var inputDone = false
                var outputDone = false
                var outputPcmEncoding = AudioFormat.ENCODING_PCM_16BIT
                var sampleCursor = startMs.coerceAtLeast(0L) * sampleRate / 1000L
                var timeBaseInitialized = false
                var previousMagnitudes = FloatArray(FFT_SIZE / 2)
                var smoothed = FloatArray(OUTPUT_BANDS)
                var peak = 0f
                val onset = ArrayList<Pair<Long, Float>>()

                while (!outputDone && frames.size < maxFrames) {
                    currentCoroutineContext().ensureActive()
                    if (!inputDone) {
                        val inIndex = codec.dequeueInputBuffer(10_000)
                        if (inIndex >= 0) {
                            val input = codec.getInputBuffer(inIndex)!!
                            input.clear()
                            val size = extractor.readSampleData(input, 0)
                            if (size < 0) {
                                codec.queueInputBuffer(inIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            } else {
                                codec.queueInputBuffer(inIndex, 0, size, extractor.sampleTime.coerceAtLeast(0L), 0)
                                extractor.advance()
                            }
                        }
                    }

                    when (val outIndex = codec.dequeueOutputBuffer(info, 10_000)) {
                        MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            val outFmt = codec.outputFormat
                            sampleRate = if (outFmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) outFmt.getInteger(MediaFormat.KEY_SAMPLE_RATE) else sampleRate
                            channels = if (outFmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) outFmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceAtLeast(1) else channels
                            outputPcmEncoding = if (outFmt.containsKey(MediaFormat.KEY_PCM_ENCODING)) {
                                outFmt.getInteger(MediaFormat.KEY_PCM_ENCODING)
                            } else AudioFormat.ENCODING_PCM_16BIT
                            sampleCursor = startMs.coerceAtLeast(0L) * sampleRate / 1000L
                        }
                        else -> if (outIndex >= 0) {
                            if (!timeBaseInitialized && info.presentationTimeUs >= 0L) {
                                sampleCursor = info.presentationTimeUs * sampleRate / 1_000_000L
                                timeBaseInitialized = true
                            }
                            val out = codec.getOutputBuffer(outIndex)
                            if (out != null && info.size > 0) {
                                out.position(info.offset)
                                out.limit(info.offset + info.size)
                                out.order(ByteOrder.LITTLE_ENDIAN)
                                when (outputPcmEncoding) {
                                    AudioFormat.ENCODING_PCM_FLOAT -> {
                                        val frameBytes = 4 * channels
                                        while (out.remaining() >= frameBytes) {
                                            var sum = 0f
                                            repeat(channels) { sum += out.getFloat().coerceIn(-1f, 1f) }
                                            pcm.add(sum / channels)
                                        }
                                    }
                                    else -> {
                                        val frameBytes = 2 * channels
                                        while (out.remaining() >= frameBytes) {
                                            var sum = 0f
                                            repeat(channels) { sum += out.getShort() / 32768f }
                                            pcm.add(sum / channels)
                                        }
                                    }
                                }
                            }
                            outputDone = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                            codec.releaseOutputBuffer(outIndex, false)
                        }
                    }

                    while (pcm.size >= FFT_SIZE && frames.size < maxFrames) {
                        val window = pcm.copyFirst(FFT_SIZE)
                        val rms = sqrt(window.fold(0.0) { acc, v -> acc + v * v } / FFT_SIZE).toFloat().coerceIn(0f, 1f)
                        for (i in window.indices) {
                            val hann = (0.5 - 0.5 * cos(2.0 * PI * i / (FFT_SIZE - 1))).toFloat()
                            window[i] *= hann
                        }
                        val real = window.copyOf()
                        val imag = FloatArray(FFT_SIZE)
                        fftInPlace(real, imag)
                        val magnitudes = FloatArray(FFT_SIZE / 2)
                        for (i in magnitudes.indices) {
                            magnitudes[i] = sqrt(real[i] * real[i] + imag[i] * imag[i]) / (FFT_SIZE / 2f)
                        }

                        var flux = 0f
                        for (i in magnitudes.indices) {
                            val d = magnitudes[i] - previousMagnitudes[i]
                            if (d > 0f) flux += d
                        }
                        flux = (flux / magnitudes.size * 6f).coerceIn(0f, 1f)
                        previousMagnitudes = magnitudes

                        val bands = logBands(magnitudes, sampleRate, OUTPUT_BANDS)
                        for (i in bands.indices) smoothed[i] = smoothed[i] * SMOOTHING + bands[i] * (1f - SMOOTHING)
                        val normalized = smoothed.mapToFloatArray { v ->
                            if (rms < SILENCE_FLOOR) 0f else (ln(1f + v * 18f) / ln(19f)).coerceIn(0f, 1f)
                        }
                        val bass = averageRange(normalized, 0, 12)
                        val mid = averageRange(normalized, 12, 42)
                        val treble = averageRange(normalized, 42, OUTPUT_BANDS)
                        val energy = (rms * .55f + bass * .27f + flux * .18f).coerceIn(0f, 1f)
                        peak = max(peak, energy)
                        val timeMs = sampleCursor * 1000L / sampleRate
                        frames += SpectrumFrame(timeMs, normalized, rms, flux, bass, mid, treble)
                        onset += timeMs to (flux * .62f + rms * .38f)
                        pcm.removeFirst(HOP_SIZE)
                        sampleCursor += HOP_SIZE
                    }
                }

                AudioAnalysis(frames, estimateBpm(onset), peak, sampleRate, FFT_SIZE)
            } finally {
                runCatching { codec?.stop() }
                runCatching { codec?.release() }
                runCatching { extractor.release() }
            }
        }
    }

    private fun logBands(magnitudes: FloatArray, sampleRate: Int, bands: Int): FloatArray {
        val out = FloatArray(bands)
        val nyquist = sampleRate / 2f
        val minHz = 30f
        val maxHz = minOf(18_000f, nyquist)
        val minLog = ln(minHz)
        val maxLog = ln(maxHz)
        for (b in 0 until bands) {
            val f0 = kotlin.math.exp(minLog + (maxLog - minLog) * b / bands)
            val f1 = kotlin.math.exp(minLog + (maxLog - minLog) * (b + 1) / bands)
            val i0 = ((f0 / sampleRate) * FFT_SIZE).toInt().coerceIn(1, magnitudes.lastIndex)
            val i1 = ((f1 / sampleRate) * FFT_SIZE).toInt().coerceIn(i0 + 1, magnitudes.size)
            var maxV = 0f
            var sum = 0f
            var n = 0
            for (i in i0 until i1) { val v = magnitudes[i]; maxV = max(maxV, v); sum += v; n++ }
            out[b] = if (n == 0) 0f else (sum / n * .72f + maxV * .28f)
        }
        return out
    }

    private fun fftInPlace(real: FloatArray, imag: FloatArray) {
        val n = real.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while (j and bit != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) {
                val tr = real[i]; real[i] = real[j]; real[j] = tr
                val ti = imag[i]; imag[i] = imag[j]; imag[j] = ti
            }
        }
        var len = 2
        while (len <= n) {
            val angle = -2.0 * PI / len
            val wLenR = cos(angle).toFloat(); val wLenI = sin(angle).toFloat()
            var i = 0
            while (i < n) {
                var wr = 1f; var wi = 0f
                for (k in 0 until len / 2) {
                    val uR = real[i + k]; val uI = imag[i + k]
                    val idx = i + k + len / 2
                    val vR = real[idx] * wr - imag[idx] * wi
                    val vI = real[idx] * wi + imag[idx] * wr
                    real[i + k] = uR + vR; imag[i + k] = uI + vI
                    real[idx] = uR - vR; imag[idx] = uI - vI
                    val nwr = wr * wLenR - wi * wLenI
                    wi = wr * wLenI + wi * wLenR; wr = nwr
                }
                i += len
            }
            len = len shl 1
        }
    }

    private fun averageRange(a: FloatArray, from: Int, to: Int): Float {
        val f = from.coerceIn(0, a.size); val t = to.coerceIn(f, a.size)
        if (f == t) return 0f
        var s = 0f; for (i in f until t) s += a[i]
        return s / (t - f)
    }

    private fun estimateBpm(samples: List<Pair<Long, Float>>): Int? {
        if (samples.size < 24) return null
        val avg = samples.map { it.second }.average().toFloat()
        val threshold = avg * 1.35f
        val peaks = ArrayList<Long>()
        for (i in 2 until samples.size - 2) {
            val e = samples[i].second
            if (e > threshold && e >= samples[i - 1].second && e > samples[i + 1].second) {
                val t = samples[i].first
                if (peaks.isEmpty() || t - peaks.last() > 220L) peaks += t
            }
        }
        val gaps = peaks.zipWithNext { a, b -> b - a }.filter { it in 250L..1500L }
        if (gaps.size < 3) return null
        val median = gaps.sorted()[gaps.size / 2].coerceAtLeast(1L)
        var bpm = (60_000.0 / median).toInt()
        while (bpm < 70) bpm *= 2
        while (bpm > 190) bpm /= 2
        return bpm.coerceIn(50, 220)
    }

    private inline fun FloatArray.mapToFloatArray(block: (Float) -> Float): FloatArray = FloatArray(size) { block(this[it]) }

    private class FloatArrayBuffer(initial: Int) {
        private var data = FloatArray(initial)
        var size: Int = 0; private set
        fun add(v: Float) { if (size == data.size) data = data.copyOf(data.size * 2); data[size++] = v }
        fun copyFirst(n: Int): FloatArray = data.copyOfRange(0, n)
        fun removeFirst(n: Int) { if (n >= size) { size = 0; return }; data.copyInto(data, 0, n, size); size -= n }
    }
}
