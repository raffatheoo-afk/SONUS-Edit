package com.sonusstudios.streampulse.export

import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import com.sonusstudios.streampulse.core.*
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.text.NumberFormat
import java.util.Locale


enum class ReportPeriod(val label: String, val fileToken: String) {
    CYCLE("Ciclo atual", "ciclo"),
    DAYS_30("Últimos 30 dias", "30_dias"),
    DAYS_90("Últimos 90 dias", "90_dias"),
    YEAR_1("Último ano", "1_ano")
}

object ReportPdfManager {
    private val brl = NumberFormat.getCurrencyInstance(Locale("pt", "BR"))
    private val intFormat = NumberFormat.getIntegerInstance(Locale("pt", "BR"))
    private val displayDate = DateTimeFormatter.ofPattern("dd/MM/yyyy")

    fun suggestedName(artist: Artist, period: ReportPeriod): String {
        val clean = artist.name.replace(Regex("[^A-Za-zÀ-ÿ0-9_-]+"), "_").trim('_')
        return "SONUS_${clean}_${period.fileToken}_${LocalDate.now()}.pdf"
    }

    fun writeReport(context: Context, uri: Uri, state: AppState, artist: Artist, period: ReportPeriod): Result<Unit> = runCatching {
        val today = LocalDate.now()
        val cycle = DistributorRules.cycleFor(artist, today)
        val start = when (period) {
            ReportPeriod.CYCLE -> LocalDate.parse(cycle.startIso)
            ReportPeriod.DAYS_30 -> today.minusDays(29)
            ReportPeriod.DAYS_90 -> today.minusDays(89)
            ReportPeriod.YEAR_1 -> today.minusDays(364)
        }
        val end = today
        val snapshots = state.snapshots.filter { it.artistId == artist.id && inRange(it.dateIso, start, end) }
        val daily = state.dailyStreamRecords.filter { it.artistId == artist.id && inRange(it.dateIso, start, end) }
        val payments = state.payments.filter { it.artistId == artist.id && inRange(it.paidDateIso, start, end) }
        val allArtistPayments = state.payments.filter { it.artistId == artist.id }
        val rpm = RoyaltyEngine.personalizedRpm(artist, allArtistPayments)
        val cycleSnapshots = state.snapshots.filter { it.artistId == artist.id && it.cycleStartIso == cycle.startIso }
        val cycleDaily = state.dailyStreamRecords.filter { it.artistId == artist.id && inRange(it.dateIso, LocalDate.parse(cycle.startIso), LocalDate.parse(cycle.endIso)) }
        val forecast = RoyaltyEngine.forecast(
            cycleSnapshots,
            cycleDaily,
            LocalDate.parse(cycle.startIso),
            LocalDate.parse(cycle.endIso),
            today,
            rpm
        )
        val health = HealthEngine.calculateFromSnapshots(
            snapshots = state.snapshots.filter { it.artistId == artist.id },
            manualRecords = state.dailyStreamRecords.filter { it.artistId == artist.id },
            cycle = cycle,
            referenceDate = today
        )
        val trend = AnalyticsEngine.trendFromDailyEntries(
            unifiedEntries(state, artist, today).filter { inRange(it.dateIso, start, end) },
            state.preferences.trendWindowDays
        )
        val accuracy = RoyaltyEngine.accuracy(allArtistPayments)
        val latest = snapshots.maxByOrNull { it.recordedAtEpochMillis }
        val received = payments.sumOf { it.amountBrl }
        val totalDaily = daily.sumOf { it.streams }

        val doc = PdfDocument()
        val pageWidth = 595
        val pageHeight = 842
        var pageNumber = 0
        var page = doc.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, ++pageNumber).create())
        var canvas = page.canvas
        var y = 56f

        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(16, 74, 160)
            textSize = 26f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val hPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(32, 45, 66)
            textSize = 16f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(52, 58, 70)
            textSize = 12f
        }
        val smallPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(95, 101, 112)
            textSize = 10f
        }

        fun newPage() {
            doc.finishPage(page)
            page = doc.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, ++pageNumber).create())
            canvas = page.canvas
            y = 52f
        }

        fun ensure(space: Float) {
            if (y + space > pageHeight - 45f) newPage()
        }

        fun line(text: String, paint: Paint = bodyPaint, gap: Float = 19f) {
            ensure(gap + 8f)
            canvas.drawText(text, 46f, y, paint)
            y += gap
        }

        fun wrapped(text: String, paint: Paint = bodyPaint, widthChars: Int = 78) {
            val words = text.split(' ')
            var current = ""
            words.forEach { word ->
                val candidate = if (current.isBlank()) word else "$current $word"
                if (candidate.length > widthChars) {
                    line(current, paint)
                    current = word
                } else current = candidate
            }
            if (current.isNotBlank()) line(current, paint)
        }

        fun section(title: String) {
            ensure(34f)
            y += 7f
            line(title, hPaint, 24f)
        }

        canvas.drawText("SONUS", 46f, y, titlePaint)
        y += 32f
        line("Extrato de desempenho musical", hPaint, 24f)
        line("Artista: ${artist.name}")
        line("Distribuidora: ${DistributorRules.displayName(artist.distributor, artist.customDistributorName)}${RoyaltyReferenceCatalog.displayScenario(artist.distributor, artist.royaltyScenarioId)?.let { " • $it" } ?: ""}")
        line("Período: ${start.format(displayDate)} a ${end.format(displayDate)} • ${period.label}")
        line("Gerado em: ${today.format(displayDate)}", smallPaint)

        section("Resumo")
        line("Streams acumulados mais recentes: ${latest?.cumulativeStreams?.let(intFormat::format) ?: "—"}")
        if (daily.isNotEmpty()) line("Streams em registros diários no período: ${intFormat.format(totalDaily)}")
        line("Estimativa atual do ciclo: ${brl.format(forecast.estimatedCurrentBrl)}")
        line("Previsão principal do ciclo: ${brl.format(forecast.projectedBrl)}")
        line("Pagamentos reais no período: ${brl.format(received)}")
        artist.goalBrl?.let { line("Meta financeira: ${brl.format(it)}") }
        artist.goalStreams?.let { line("Meta de streams: ${intFormat.format(it)}") }

        section("Indicadores")
        line("Saúde do Projeto: ${health.score} pontos • ${health.label}")
        line("Desempenho do ciclo até hoje: ${String.format(Locale.US, "%.1f%%", health.performancePercent)} • ${health.score}/${health.possiblePoints.coerceAtLeast(0)} pontos possíveis")
        line("Dias registrados: ${health.scoredDays} • positivos: ${health.positiveDays} • fracos: ${health.weakDays}")
        line("Tendência: ${trend.label}${trend.percentChange?.let { " • ${String.format(Locale.US, "%+.1f%%", it)}" } ?: ""}")
        line("Média recente: ${intFormat.format(trend.recentAverage.toLong())} streams/dia")
        line("Precisão: ${accuracy.accuracyPercent?.let { String.format(Locale.US, "%.1f%%", it) } ?: forecast.confidence}")

        section("Ciclo e previsão")
        line("Ciclo atual: ${LocalDate.parse(cycle.startIso).format(displayDate)} → ${LocalDate.parse(cycle.endIso).format(displayDate)}")
        line("Streams atuais do ciclo: ${intFormat.format(forecast.currentStreams)}")
        line("Conservadora: ${brl.format(forecast.conservativeBrl)} • ${intFormat.format(forecast.conservativeStreams)} streams")
        line("Principal: ${brl.format(forecast.projectedBrl)} • ${intFormat.format(forecast.projectedStreams)} streams")
        line("Otimista: ${brl.format(forecast.optimisticBrl)} • ${intFormat.format(forecast.optimisticStreams)} streams")

        if (payments.isNotEmpty()) {
            section("Pagamentos reais")
            payments.sortedByDescending { it.paidDateIso }.take(30).forEach { payment ->
                line("${LocalDate.parse(payment.paidDateIso).format(displayDate)} • ${brl.format(payment.amountBrl)} • ${intFormat.format(payment.cycleStreams)} streams", smallPaint, 16f)
            }
        }

        if (daily.isNotEmpty()) {
            section("Registros diários")
            daily.sortedByDescending { it.dateIso }.take(45).forEach { record ->
                line("${LocalDate.parse(record.dateIso).format(displayDate)} • ${intFormat.format(record.streams)} streams", smallPaint, 16f)
            }
        }

        section("Observação")
        wrapped("Valores financeiros exibidos pelo SONUS são estimativas de planejamento. Pagamentos reais podem variar conforme plataforma, país dos ouvintes, elegibilidade dos streams, retenções, impostos, taxas, câmbio e contrato da distribuidora.", smallPaint, 94)
        doc.finishPage(page)
        context.contentResolver.openOutputStream(uri)?.use { doc.writeTo(it) }
            ?: error("Não foi possível salvar o PDF.")
        doc.close()
    }

    private fun unifiedEntries(state: AppState, artist: Artist, referenceDate: LocalDate): List<DailyStreamEntry> {
        val snapshots = state.snapshots.filter { it.artistId == artist.id }
        val dailyRecords = state.dailyStreamRecords.filter { it.artistId == artist.id }
        val windows = linkedMapOf<String, CycleWindow>()
        snapshots.forEach { snapshot ->
            windows["${snapshot.cycleStartIso}|${snapshot.cycleEndIso}"] = CycleWindow(snapshot.cycleStartIso, snapshot.cycleEndIso, "Histórico")
        }
        val current = DistributorRules.cycleFor(artist, referenceDate)
        windows["${current.startIso}|${current.endIso}"] = current
        dailyRecords.forEach { record ->
            val date = runCatching { LocalDate.parse(record.dateIso) }.getOrNull() ?: return@forEach
            if (windows.values.none { inRange(record.dateIso, LocalDate.parse(it.startIso), LocalDate.parse(it.endIso)) }) {
                val derived = DistributorRules.cycleFor(artist, date)
                windows["${derived.startIso}|${derived.endIso}"] = derived
            }
        }
        return windows.values.sortedBy { it.startIso }.flatMap { window ->
            val cycleStart = LocalDate.parse(window.startIso)
            val cycleEnd = LocalDate.parse(window.endIso)
            StreamMetricsEngine.cycleMetrics(
                snapshots.filter { inRange(it.dateIso, cycleStart, cycleEnd) },
                dailyRecords.filter { inRange(it.dateIso, cycleStart, cycleEnd) },
                cycleStart,
                cycleEnd,
                minOf(referenceDate, cycleEnd)
            ).dailyEntries
        }.groupBy { it.dateIso }.map { (_, rows) -> rows.last() }.sortedBy { it.dateIso }
    }

    private fun inRange(iso: String, start: LocalDate, end: LocalDate): Boolean {
        val date = runCatching { LocalDate.parse(iso) }.getOrNull() ?: return false
        return !date.isBefore(start) && !date.isAfter(end)
    }
}
