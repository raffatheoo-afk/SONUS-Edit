package com.sonusstudios.streampulse.tools

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.text.Normalizer
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext

internal data class SonusLyricsQuery(
    val title: String,
    val artist: String = "",
    val album: String = "",
    val durationMs: Long = 0L
)

internal data class SonusResolvedLyrics(
    val text: String,
    val format: String,
    val source: String,
    val score: Int = 0
)

/**
 * code131: normalização/matching compartilhados por Player local, Stream e LRCLIB.
 * O lookup remove ruído comum de título/artista antes de consultar o LRCLIB, mas
 * preserva marcadores reais de versão (ao vivo / acústico / remix / remaster etc.).
 */
internal object SonusLyricsResolver {
    private const val POSITIVE_TTL_MS = 60L * 24L * 60L * 60L * 1000L // 60 dias
    private const val NEGATIVE_TTL_MS = 24L * 60L * 60L * 1000L // 24 horas
    @Volatile private var cooldownUntilMs: Long = 0L
    // O corpo de lrclib() é bloqueante (sem suspensão), então a flag por thread é segura.
    private val transientFailure = ThreadLocal.withInitial { false }

    private val versionRules = linkedMapOf(
        "live" to listOf("ao vivo", "live", "concert", "show"),
        "acoustic" to listOf("acustico", "acoustic", "acustica", "acustica"),
        "remix" to listOf("remix", "mix"),
        "remaster" to listOf("remaster", "remastered"),
        "edit" to listOf("edit", "radio edit"),
        "demo" to listOf("demo"),
        "instrumental" to listOf("instrumental"),
        "karaoke" to listOf("karaoke", "playback")
    )

    fun normalize(raw: String): String = Normalizer.normalize(raw.lowercase(Locale.ROOT), Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "")
        .replace('&', ' ')
        .replace(Regex("[_./\\\\]+"), " ")
        .replace(Regex("[^a-z0-9]+"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

    fun versionTags(raw: String): Set<String> {
        val n = normalize(raw)
        return versionRules.mapNotNull { (canonical, aliases) ->
            canonical.takeIf { aliases.any { alias -> n.contains(normalize(alias)) } }
        }.toSet()
    }

    private fun tokens(raw: String): Set<String> = normalize(raw).split(' ')
        .asSequence().filter { it.length >= 2 && it !in setOf("de","da","do","das","dos","the","a","an","and","e") }.toSet()

    private fun overlap(a: Set<String>, b: Set<String>): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        return a.intersect(b).size.toDouble() / a.size.toDouble()
    }

    private val lookupNoise = Regex(
        "(?i)\\b(?:official\\s+(?:music\\s+)?video|official\\s+audio|lyric\\s+video|lyrics?|visualizer|clipe\\s+oficial|video\\s+oficial|áudio\\s+oficial|audio\\s+oficial|4k|hd|hq)\\b"
    )

    private fun cleanLookupArtist(raw: String): String = raw
        .replace(Regex("(?i)\\s*[-–—|:]?\\s*(?:official|oficial|vevo|topic)\\s*$"), "")
        .replace(Regex("(?i)\\s+(?:feat\\.?|ft\\.?|featuring)\\s+.*$"), "")
        .replace(Regex("\\s+"), " ")
        .trim(' ', '-', '–', '—', '|', ':')

    private fun cleanLookupTitle(raw: String, artist: String): String {
        // Não usa substringBeforeLast('.') porque títulos legítimos podem conter ponto.
        // Remove apenas extensão de áudio conhecida e prefixo inequívoco tipo "01 - ".
        var value = raw.trim()
            .replace(Regex("(?i)\\.(?:mp3|flac|wav|m4a|aac|ogg|opus|wma|aiff?|webm)$"), "")
            .replace(Regex("(?i)^\\s*(?:track\\s*)?\\d{2}\\s*[-–—_]\\s*"), "")
            .trim()
        val cleanArtist = cleanLookupArtist(artist)
        if (cleanArtist.isNotBlank()) {
            value = value
                .replace(Regex("(?i)^\\s*${Regex.escape(cleanArtist)}\\s*[-–—|:]\\s*"), "")
                .replace(Regex("(?i)\\s*[-–—|:]\\s*${Regex.escape(cleanArtist)}\\s*$"), "")
        }
        value = value.replace(lookupNoise, " ")
            .replace(Regex("[()\\[\\]{}]+"), " ")
            .replace(Regex("\\s*[-–—|:]\\s*$"), "")
            .replace(Regex("\\s+"), " ")
            .trim()
        return value.ifBlank { raw.trim() }
    }

    private fun cleanLookupAlbum(raw: String): String = raw
        .replace(lookupNoise, " ")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun lookupQuery(query: SonusLyricsQuery): SonusLyricsQuery = SonusLyricsQuery(
        title = cleanLookupTitle(query.title, query.artist),
        artist = cleanLookupArtist(query.artist),
        album = cleanLookupAlbum(query.album),
        durationMs = query.durationMs
    )

    /** Score de filename pCloud. Título+artista vencem; versão incompatível sofre penalidade forte. */
    fun scoreFilename(query: SonusLyricsQuery, fileStem: String): Int {
        val stem = normalize(fileStem)
        val title = normalize(query.title)
        val artist = normalize(query.artist)
        if (title.isBlank() || stem.isBlank()) return Int.MIN_VALUE / 4
        val titleTokens = tokens(query.title)
        val artistTokens = tokens(query.artist)
        val stemTokens = tokens(fileStem)
        var score = 0
        if (stem == title) score += 105
        if (artist.isNotBlank() && (stem == "$title $artist" || stem == "$artist $title")) score += 185
        score += (overlap(titleTokens, stemTokens) * 100).toInt()
        if (artistTokens.isNotEmpty()) score += (overlap(artistTokens, stemTokens) * 55).toInt()
        if (stem.contains(title)) score += 35
        if (artist.isNotBlank() && stem.contains(artist)) score += 30

        val wantedTags = versionTags(query.title + " " + query.album)
        val candidateTags = versionTags(fileStem)
        when {
            wantedTags == candidateTags && wantedTags.isNotEmpty() -> score += 70
            wantedTags.isEmpty() && candidateTags.isEmpty() -> score += 32
            wantedTags.isEmpty() && candidateTags.isNotEmpty() -> score -= 85
            wantedTags.isNotEmpty() && candidateTags.isEmpty() -> score -= 45
            wantedTags.intersect(candidateTags).isNotEmpty() -> score += 35
            else -> score -= 120
        }
        return score
    }

    fun lrcTimelineEndMs(text: String): Long {
        var max = 0L
        Regex("\\[(\\d{1,3}):(\\d{2})(?:[.,](\\d{1,3}))?]").findAll(text).forEach { m ->
            val min = m.groupValues[1].toLongOrNull() ?: 0L
            val sec = m.groupValues[2].toLongOrNull() ?: 0L
            val frac = m.groupValues[3].padEnd(3, '0').take(3).toLongOrNull() ?: 0L
            max = maxOf(max, (min * 60L + sec) * 1000L + frac)
        }
        return max
    }

    fun durationCompatibility(trackDurationMs: Long, lrcText: String): Int {
        if (trackDurationMs <= 0L) return 0
        val end = lrcTimelineEndMs(lrcText)
        if (end <= 0L) return 0
        // A última linha geralmente termina antes do áudio; diferença moderada é normal.
        val diff = kotlin.math.abs(trackDurationMs - end)
        return when {
            diff <= 8_000L -> 40
            diff <= 18_000L -> 26
            diff <= 30_000L -> 10
            diff <= 45_000L -> -25
            else -> -90
        }
    }

    suspend fun lrclib(context: Context, query: SonusLyricsQuery): SonusResolvedLyrics? = withContext(Dispatchers.IO) {
        if (query.title.isBlank()) return@withContext null
        val lookup = lookupQuery(query)
        val cacheDir = File(context.cacheDir, "sonus_lrclib_v1").apply { mkdirs() }
        val key = sha256(listOf(normalize(lookup.title), normalize(lookup.artist), normalize(lookup.album), (lookup.durationMs / 1000L).toString(), versionTags(query.title + " " + query.album).sorted().joinToString(",")).joinToString("|"))
        val cache = File(cacheDir, "$key.json")
        val miss = File(cacheDir, "$key.miss")
        val now = System.currentTimeMillis()
        // code132: cache positivo com validade e cache negativo curto, para não repetir a mesma
        // consulta a cada abertura da faixa. Falhas de rede/limite NUNCA viram "sem letra".
        if (cache.exists() && cache.length() > 0L) {
            if (now - cache.lastModified() <= POSITIVE_TTL_MS) {
                runCatching { parseCached(JSONObject(cache.readText())) }.getOrNull()?.let { return@withContext it }
            } else runCatching { cache.delete() }
        }
        if (miss.exists() && now - miss.lastModified() <= NEGATIVE_TTL_MS) return@withContext null
        if (now < cooldownUntilMs) return@withContext null
        transientFailure.set(false)
        currentCoroutineContext().ensureActive()

        val candidates = mutableListOf<JSONObject>()
        // Lookup limpo primeiro. Só recua para os metadados crus se a limpeza não encontrar nada.
        exactGet(lookup, includeAlbum = lookup.album.isNotBlank())?.let(candidates::add)
        if (candidates.isEmpty() && lookup.album.isNotBlank()) exactGet(lookup, includeAlbum = false)?.let(candidates::add)
        if (candidates.isEmpty()) candidates += search(lookup)
        currentCoroutineContext().ensureActive()
        if (candidates.isEmpty() && lookup != query) candidates += search(query)
        if (candidates.isEmpty()) {
            if (!transientFailure.get()) runCatching { miss.writeText(now.toString()) }
            return@withContext null
        }

        val ranked = candidates.distinctBy { obj ->
            obj.optLong("id", 0L).takeIf { it > 0L }?.toString()
                ?: listOf(obj.optString("trackName"), obj.optString("artistName"), obj.optDouble("duration", 0.0).toString()).joinToString("|")
        }.mapNotNull { obj ->
            val plain = obj.optString("plainLyrics").takeUnless { it == "null" }.orEmpty().trim()
            val synced = obj.optString("syncedLyrics").takeUnless { it == "null" }.orEmpty().trim()
            if (plain.isBlank() && synced.isBlank()) return@mapNotNull null
            val itemTitle = obj.optString("trackName", obj.optString("name"))
            val itemArtist = obj.optString("artistName")
            val itemAlbum = obj.optString("albumName")
            val itemDuration = obj.optDouble("duration", 0.0)
            var score = 0
            val qt = normalize(lookup.title); val qa = normalize(lookup.artist); val qal = normalize(lookup.album)
            val it = normalize(itemTitle); val ia = normalize(itemArtist); val ial = normalize(itemAlbum)
            if (qt == it) score += 160 else score += (overlap(tokens(lookup.title), tokens(itemTitle)) * 100).toInt()
            if (qa.isNotBlank()) score += if (qa == ia) 90 else (overlap(tokens(lookup.artist), tokens(itemArtist)) * 55).toInt()
            if (qal.isNotBlank() && qal == ial) score += 25
            val wantedTags = versionTags(query.title + " " + query.album)
            val gotTags = versionTags(itemTitle + " " + itemAlbum)
            if (wantedTags == gotTags) score += 45 else if (wantedTags.intersect(gotTags).isEmpty() && (wantedTags.isNotEmpty() || gotTags.isNotEmpty())) score -= 90
            if (lookup.durationMs > 0L && itemDuration > 0.0) {
                val diff = kotlin.math.abs(lookup.durationMs / 1000.0 - itemDuration)
                score += when {
                    diff <= 3.0 -> 80
                    diff <= 8.0 -> 42
                    diff <= 15.0 -> 10
                    else -> -100
                }
            }
            Triple(obj, score, synced.ifBlank { plain })
        }.sortedByDescending { it.second }

        currentCoroutineContext().ensureActive()
        val best = ranked.firstOrNull()
        if (best == null || best.second < 85) {
            if (!transientFailure.get()) runCatching { miss.writeText(now.toString()) }
            return@withContext null
        }
        val synced = best.first.optString("syncedLyrics").takeUnless { it == "null" }.orEmpty().trim()
        val plain = best.first.optString("plainLyrics").takeUnless { it == "null" }.orEmpty().trim()
        val resolved = SonusResolvedLyrics(
            text = synced.ifBlank { plain },
            format = if (synced.isNotBlank()) "LRC" else "TEXT",
            source = "LRCLIB",
            score = best.second
        )
        runCatching { miss.delete() }
        runCatching {
            cache.writeText(JSONObject().put("text", resolved.text).put("format", resolved.format).put("source", resolved.source).put("score", resolved.score).toString())
        }
        resolved
    }

    private fun parseCached(o: JSONObject): SonusResolvedLyrics? {
        val text = o.optString("text").trim()
        if (text.isBlank()) return null
        return SonusResolvedLyrics(text, o.optString("format", "TEXT"), o.optString("source", "LRCLIB"), o.optInt("score", 0))
    }

    private fun exactGet(query: SonusLyricsQuery, includeAlbum: Boolean): JSONObject? {
        val params = linkedMapOf("track_name" to query.title)
        if (query.artist.isNotBlank()) params["artist_name"] = query.artist
        if (includeAlbum && query.album.isNotBlank()) params["album_name"] = query.album
        if (query.durationMs > 0L) params["duration"] = (query.durationMs / 1000.0).toString()
        val response = request("https://lrclib.net/api/get?${encode(params)}") ?: return null
        return runCatching { JSONObject(response) }.getOrNull()
    }

    private fun search(query: SonusLyricsQuery): List<JSONObject> {
        val params = linkedMapOf("track_name" to query.title)
        if (query.artist.isNotBlank()) params["artist_name"] = query.artist
        if (query.album.isNotBlank()) params["album_name"] = query.album
        val response = request("https://lrclib.net/api/search?${encode(params)}") ?: return emptyList()
        return runCatching {
            val arr = JSONArray(response)
            (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }.take(20)
        }.getOrDefault(emptyList())
    }

    private fun request(url: String): String? = runCatching {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 5_000
            readTimeout = 7_000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "SONUS/1.0.33 (Android; lyrics resolver)")
        }
        try {
            val code = connection.responseCode
            when {
                code in 200..299 -> connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                code == 404 -> null // resposta limpa: o LRCLIB não conhece esta faixa
                code == 429 -> {
                    val wait = connection.getHeaderField("Retry-After")?.trim()?.toLongOrNull()?.coerceIn(5L, 600L) ?: 60L
                    cooldownUntilMs = System.currentTimeMillis() + wait * 1000L
                    transientFailure.set(true)
                    null
                }
                else -> { transientFailure.set(true); null } // 5xx/erros: não cacheia como "sem letra"
            }
        } finally { connection.disconnect() }
    }.getOrElse { transientFailure.set(true); null }

    private fun encode(params: Map<String, String>): String = params.entries.joinToString("&") { (k, v) ->
        "${URLEncoder.encode(k, StandardCharsets.UTF_8.name())}=${URLEncoder.encode(v, StandardCharsets.UTF_8.name())}"
    }

    private fun sha256(raw: String): String = MessageDigest.getInstance("SHA-256")
        .digest(raw.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
}
