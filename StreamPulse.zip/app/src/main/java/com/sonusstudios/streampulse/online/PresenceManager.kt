package com.sonusstudios.streampulse.online

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Presença online mínima do StreamPulse.
 *
 * A partir da v1.7.1 usa somente o UID da conta autenticada. Nenhum stream,
 * saldo, artista, pagamento ou outro dado musical é enviado.
 */
data class CommunityPresenceState(
    val configured: Boolean = false,
    val connecting: Boolean = false,
    val connected: Boolean = false,
    val totalUsers: Long? = null,
    val onlineUsers: Long? = null,
    val publicCounterEnabled: Boolean = true,
    val publicCounterMinimum: Long = 100L,
    val message: String? = null
)

class PresenceManager(context: Context) {
    private val appContext = context.applicationContext
    private val _state = MutableStateFlow(CommunityPresenceState())
    val state: StateFlow<CommunityPresenceState> = _state.asStateFlow()

    private var auth: FirebaseAuth? = null
    private var authListener: FirebaseAuth.AuthStateListener? = null
    private var database: FirebaseDatabase? = null
    private var active = false
    private var userId: String? = null
    private var networkConnected = false
    private var connectedListener: ValueEventListener? = null
    private var usersListener: ValueEventListener? = null
    private var presenceListener: ValueEventListener? = null
    private var publicConfigListener: ValueEventListener? = null
    private var totalUsers: Long? = null
    private var onlineUsers: Long? = null
    private var publicCounterEnabled: Boolean = true
    private var publicCounterMinimum: Long = 100L

    init {
        initializeFirebase()
    }

    fun setAppActive(isActive: Boolean) {
        active = isActive
        if (isActive) {
            syncAuthenticatedUser()
            if (networkConnected && userId != null) setOwnPresence()
        } else {
            clearOwnPresence()
        }
    }

    private fun initializeFirebase() {
        runCatching {
            val app = FirebaseApp.initializeApp(appContext) ?: FirebaseApp.getInstance()
            auth = FirebaseAuth.getInstance(app)
            database = FirebaseDatabase.getInstance(app)
            _state.value = CommunityPresenceState(configured = true, connecting = false)

            val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
                val current = firebaseAuth.currentUser
                if (current != null && !current.isAnonymous) {
                    onAuthenticated(current.uid)
                } else {
                    onSignedOut()
                }
            }
            authListener = listener
            auth?.addAuthStateListener(listener)
            syncAuthenticatedUser()
        }.onFailure {
            _state.value = CommunityPresenceState(
                configured = false,
                message = "Firebase indisponível"
            )
        }
    }

    private fun syncAuthenticatedUser() {
        val current = auth?.currentUser
        if (current != null && !current.isAnonymous) onAuthenticated(current.uid)
        else onSignedOut()
    }

    private fun onAuthenticated(uid: String) {
        if (userId == uid) {
            attachCounters()
            attachConnectionListener()
            if (active && networkConnected) setOwnPresence()
            return
        }

        clearOwnPresence()
        detachRemoteListeners()
        userId = uid
        val db = database ?: return
        // /users registra somente que este UID autenticado já utilizou o app.
        db.getReference("users").child(uid).setValue(true)
        attachCounters()
        attachConnectionListener()
        if (active && networkConnected) setOwnPresence()
    }

    private fun onSignedOut() {
        clearOwnPresence()
        userId = null
        detachRemoteListeners()
        networkConnected = false
        _state.value = CommunityPresenceState(configured = database != null, connecting = false, connected = false)
    }

    private fun attachCounters() {
        val db = database ?: return
        if (usersListener == null) {
            val listener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    totalUsers = snapshot.childrenCount
                    publishConnectedState()
                }

                override fun onCancelled(error: DatabaseError) {
                    _state.value = _state.value.copy(message = "Contagem indisponível")
                }
            }
            usersListener = listener
            db.getReference("users").addValueEventListener(listener)
        }

        if (presenceListener == null) {
            val listener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    onlineUsers = snapshot.childrenCount
                    publishConnectedState()
                }

                override fun onCancelled(error: DatabaseError) {
                    _state.value = _state.value.copy(message = "Presença indisponível")
                }
            }
            presenceListener = listener
            db.getReference("presence").addValueEventListener(listener)
        }

        if (publicConfigListener == null) {
            val listener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    publicCounterEnabled = snapshot.child("enabled").getValue(Boolean::class.java) ?: true
                    publicCounterMinimum = snapshot.child("minimum").getValue(Long::class.java)?.coerceAtLeast(1L) ?: 100L
                    publishConnectedState()
                }
                override fun onCancelled(error: DatabaseError) = Unit
            }
            publicConfigListener = listener
            db.getReference("publicConfig").child("community").addValueEventListener(listener)
        }
    }

    private fun attachConnectionListener() {
        val db = database ?: return
        if (connectedListener != null) return

        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                networkConnected = snapshot.getValue(Boolean::class.java) == true
                if (networkConnected && active && userId != null) {
                    setOwnPresence()
                } else if (!networkConnected) {
                    _state.value = _state.value.copy(connecting = false, connected = false)
                }
            }

            override fun onCancelled(error: DatabaseError) {
                _state.value = _state.value.copy(connecting = false, connected = false)
            }
        }
        connectedListener = listener
        db.getReference(".info/connected").addValueEventListener(listener)
    }

    private fun detachRemoteListeners() {
        val db = database ?: return
        usersListener?.let { db.getReference("users").removeEventListener(it) }
        presenceListener?.let { db.getReference("presence").removeEventListener(it) }
        connectedListener?.let { db.getReference(".info/connected").removeEventListener(it) }
        publicConfigListener?.let { db.getReference("publicConfig").child("community").removeEventListener(it) }
        usersListener = null
        presenceListener = null
        connectedListener = null
        publicConfigListener = null
        totalUsers = null
        onlineUsers = null
    }

    private fun setOwnPresence() {
        val uid = userId ?: return
        val ref = database?.getReference("presence")?.child(uid) ?: return
        ref.onDisconnect().removeValue()
        ref.setValue(true).addOnCompleteListener { task ->
            if (task.isSuccessful) publishConnectedState(forceConnected = true)
        }
    }

    private fun clearOwnPresence() {
        val uid = userId ?: return
        val ref = database?.getReference("presence")?.child(uid) ?: return
        ref.onDisconnect().cancel()
        ref.removeValue()
        _state.value = _state.value.copy(connecting = false, connected = false)
    }

    private fun publishConnectedState(forceConnected: Boolean? = null) {
        val connected = forceConnected ?: (networkConnected && active && userId != null)
        _state.value = _state.value.copy(
            configured = true,
            connecting = !connected && active && userId != null,
            connected = connected,
            totalUsers = totalUsers,
            onlineUsers = onlineUsers,
            publicCounterEnabled = publicCounterEnabled,
            publicCounterMinimum = publicCounterMinimum,
            message = null
        )
    }
}
