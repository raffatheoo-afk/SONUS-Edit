package com.sonusstudios.streampulse.tools

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

internal data class SonusCloudProvider(
    val id: String,
    val name: String,
    val icon: ImageVector,
    val accent: Color
)

internal val SonusCloudProviders = listOf(
    SonusCloudProvider("drive", "Google Drive", Icons.Default.AddToDrive, Color(0xFF42C86A)),
    SonusCloudProvider("onedrive", "OneDrive", Icons.Default.Cloud, Color(0xFF3B9CFF)),
    SonusCloudProvider("dropbox", "Dropbox", Icons.Default.Inventory2, Color(0xFF4E7CFF)),
    SonusCloudProvider("pcloud", "pCloud", Icons.Default.CloudQueue, Color(0xFF55D5E8)),
    SonusCloudProvider("mega", "MEGA", Icons.Default.CloudCircle, Color(0xFFE94B52))
)

internal data class SonusCloudRecent(
    val uri: String,
    val providerId: String,
    val title: String,
    val mediaType: String,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val lastOpenedAt: Long = System.currentTimeMillis()
)

internal class SonusCloudMediaStore(context: Context) {
    private val prefs = context.getSharedPreferences("sonus_cloud_media_v1", Context.MODE_PRIVATE)
    var favoriteProvider: String
        get() = prefs.getString("favorite_provider", "drive") ?: "drive"
        set(value) { prefs.edit().putString("favorite_provider", value).apply() }

    fun favoriteProviders(): Set<String> {
        val saved = (prefs.getStringSet("favorite_providers", emptySet()) ?: emptySet()).toSet()
        return if (saved.isNotEmpty()) saved else setOf(favoriteProvider)
    }
    fun toggleFavoriteProvider(providerId: String): Set<String> {
        val set = favoriteProviders().toMutableSet()
        if (!set.add(providerId)) set.remove(providerId)
        prefs.edit().putStringSet("favorite_providers", set).apply()
        if (set.isNotEmpty()) favoriteProvider = set.first()
        return set
    }

    fun favoriteUris(type: String): Set<String> = prefs.getStringSet("favorites_$type", emptySet()) ?: emptySet()
    fun toggleFavorite(type: String, uri: String): Set<String> {
        val set = favoriteUris(type).toMutableSet()
        if (!set.add(uri)) set.remove(uri)
        prefs.edit().putStringSet("favorites_$type", set).apply()
        return set
    }
    fun clearFavorites(type: String) { prefs.edit().remove("favorites_$type").apply() }
    fun clearRecents(type: String) { prefs.edit().remove("recent_$type").apply() }
    fun folderUri(providerId: String, type: String): String? = prefs.getString("folder_${providerId}_$type", null)
    fun setFolderUri(providerId: String, type: String, uri: String?) {
        prefs.edit().apply { if (uri == null) remove("folder_${providerId}_$type") else putString("folder_${providerId}_$type", uri) }.apply()
        if (uri != null) {
            val set = savedFolderUris(providerId, type).toMutableSet(); set.add(uri)
            prefs.edit().putStringSet("folders_${providerId}_$type", set).apply()
        }
    }
    fun savedFolderUris(providerId: String, type: String): Set<String> = (prefs.getStringSet("folders_${providerId}_$type", emptySet()) ?: emptySet()).toSet()
    fun removeSavedFolder(providerId: String, type: String, uri: String) {
        val set = savedFolderUris(providerId, type).toMutableSet(); set.remove(uri)
        prefs.edit().putStringSet("folders_${providerId}_$type", set).apply()
        if (folderUri(providerId, type) == uri) setFolderUri(providerId, type, set.firstOrNull())
    }

    fun recents(type: String): List<SonusCloudRecent> = runCatching {
        val arr = JSONArray(prefs.getString("recent_$type", "[]") ?: "[]")
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            SonusCloudRecent(
                uri = o.optString("uri"),
                providerId = o.optString("provider"),
                title = o.optString("title"),
                mediaType = type,
                positionMs = o.optLong("position"),
                durationMs = o.optLong("duration"),
                lastOpenedAt = o.optLong("last")
            ).takeIf { it.uri.isNotBlank() }
        }
    }.getOrDefault(emptyList())

    fun addRecent(item: SonusCloudRecent) {
        val current = recents(item.mediaType)
        val updated = (listOf(item.copy(lastOpenedAt = System.currentTimeMillis())) + current.filterNot { it.uri == item.uri }).take(100)
        val arr = JSONArray()
        updated.forEach { e -> arr.put(JSONObject().apply {
            put("uri", e.uri); put("provider", e.providerId); put("title", e.title)
            put("position", e.positionMs); put("duration", e.durationMs); put("last", e.lastOpenedAt)
        }) }
        prefs.edit().putString("recent_${item.mediaType}", arr.toString()).apply()
    }

    fun updateProgress(uri: String, type: String, positionMs: Long, durationMs: Long) {
        recents(type).firstOrNull { it.uri == uri }?.let {
            addRecent(it.copy(positionMs = positionMs, durationMs = durationMs))
        }
    }

    fun removeRecent(type: String, uri: String) {
        val updated = recents(type).filterNot { it.uri == uri }
        val arr = JSONArray()
        updated.forEach { e -> arr.put(JSONObject().apply {
            put("uri", e.uri); put("provider", e.providerId); put("title", e.title)
            put("position", e.positionMs); put("duration", e.durationMs); put("last", e.lastOpenedAt)
        }) }
        prefs.edit().putString("recent_$type", arr.toString()).apply()
    }

    fun pruneMissingLocalVideoRecents(context: Context) {
        recents("video").filter { it.providerId == "local" || it.providerId == "external" }.forEach { item ->
            val uri = runCatching { Uri.parse(item.uri) }.getOrNull() ?: return@forEach
            val exists = runCatching {
                when (uri.scheme?.lowercase()) {
                    "file" -> java.io.File(uri.path.orEmpty()).exists()
                    "content" -> context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { true } ?: false
                    else -> true
                }
            }.getOrDefault(false)
            if (!exists) removeRecent("video", item.uri)
        }
    }
}

internal fun persistCloudUri(context: Context, uri: Uri) {
    runCatching {
        context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
}

internal fun cloudAudioQueueItem(context: Context, uri: Uri, source: String): PulsePlayerQueueItem {
    // Arquivos remotos podem bloquear por vários segundos quando MediaMetadataRetriever
    // tenta abrir o stream. Para a nuvem usamos apenas o nome do documento no clique;
    // a reprodução começa imediatamente e metadados pesados não seguram a interface.
    val doc = DocumentFile.fromSingleUri(context, uri)
    val title = doc?.name?.substringBeforeLast('.')?.takeIf { it.isNotBlank() } ?: "Música na nuvem"
    return PulsePlayerQueueItem(uri.toString(), title, "", "", "", 0L, source)
}

internal data class SonusCloudFile(val uri: String, val title: String, val mime: String?)

internal fun scanCloudTree(context: Context, tree: Uri, prefix: String, maxItems: Int = 400): List<SonusCloudFile> {
    val root = DocumentFile.fromTreeUri(context, tree) ?: return emptyList()
    val out = mutableListOf<SonusCloudFile>()
    fun walk(dir: DocumentFile, depth: Int) {
        if (depth > 5 || out.size >= maxItems) return
        runCatching { dir.listFiles().toList() }.getOrDefault(emptyList()).forEach { file ->
            if (out.size >= maxItems) return@forEach
            if (file.isDirectory) walk(file, depth + 1)
            else {
                val mime = file.type
                val name = file.name.orEmpty()
                val match = mime?.startsWith(prefix) == true || when (prefix) {
                    "audio/" -> name.substringAfterLast('.', "").lowercase() in setOf("mp3","wav","flac","m4a","aac","ogg","opus")
                    "video/" -> name.substringAfterLast('.', "").lowercase() in setOf("mp4","mkv","webm","mov","m4v","avi","ts")
                    else -> false
                }
                if (match) out += SonusCloudFile(file.uri.toString(), name.substringBeforeLast('.').ifBlank { name }, mime)
            }
        }
    }
    walk(root, 0)
    return out
}

@Composable
internal fun SonusCloudAudioScreen(
    accent: Color,
    service: PulsePlayerService?,
    onTrack: (String, Boolean?, Long?) -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    val store = remember { SonusCloudMediaStore(context) }
    var favoriteProviders by remember { mutableStateOf(store.favoriteProviders()) }
    var favorites by remember { mutableStateOf(store.favoriteUris("audio")) }
    var recents by remember { mutableStateOf(store.recents("audio")) }
    var pendingProvider by remember { mutableStateOf(SonusCloudProviders.first()) }
    var expandedProviderId by remember { mutableStateOf<String?>(favoriteProviders.firstOrNull()) }
    var providerFiles by remember { mutableStateOf<Map<String, List<SonusCloudFile>>>(emptyMap()) }
    var loadingProviderId by remember { mutableStateOf<String?>(null) }

    fun playUri(uri: Uri, provider: SonusCloudProvider) {
        val item = cloudAudioQueueItem(context, uri, provider.name)
        store.addRecent(SonusCloudRecent(uri.toString(), provider.id, item.title, "audio", durationMs = item.durationMs))
        recents = store.recents("audio")
        service?.setQueue(listOf(item), 0, true)
        onTrack("SONUS STREAM: ${provider.name}", true, null)
    }

    fun playProviderFile(file: SonusCloudFile, provider: SonusCloudProvider) {
        val files = providerFiles[provider.id].orEmpty()
        val queue = if (files.isEmpty()) {
            listOf(PulsePlayerQueueItem(file.uri, file.title, "", "", "", 0L, provider.name))
        } else {
            files.map { cloud -> PulsePlayerQueueItem(cloud.uri, cloud.title, "", "", "", 0L, provider.name) }
        }
        val index = queue.indexOfFirst { it.uri == file.uri }.coerceAtLeast(0)
        val current = queue[index]
        store.addRecent(SonusCloudRecent(current.uri, provider.id, current.title, "audio"))
        recents = store.recents("audio")
        service?.setQueue(queue, index, true)
        onTrack("SONUS STREAM: ${provider.name}", true, null)
    }

    fun loadProvider(provider: SonusCloudProvider) {
        expandedProviderId = provider.id
        val saved = store.folderUri(provider.id, "audio") ?: return
        val uri = runCatching { Uri.parse(saved) }.getOrNull() ?: return
        scope.launch {
            loadingProviderId = provider.id
            val files = withContext(Dispatchers.IO) { scanCloudTree(context, uri, "audio/") }
            providerFiles = providerFiles + (provider.id to files)
            loadingProviderId = null
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        persistCloudUri(context, uri)
        playUri(uri, pendingProvider)
        expandedProviderId = pendingProvider.id
    }
    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }
            .recoverCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        store.setFolderUri(pendingProvider.id, "audio", uri.toString())
        loadProvider(pendingProvider)
    }

    LaunchedEffect(Unit) {
        favoriteProviders.forEach { id ->
            SonusCloudProviders.firstOrNull { it.id == id }?.let { provider ->
                if (store.folderUri(provider.id, "audio") != null) loadProvider(provider)
            }
        }
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(bottom = 28.dp)
    ) {
        item {
            Text("Nuvem", fontWeight = FontWeight.Black, fontSize = 24.sp)
            Text("Toque em uma nuvem para entrar nela. A pasta autorizada fica salva e volta automaticamente nos próximos acessos.", style = MaterialTheme.typography.bodySmall)
        }
        item {
            Text("SERVIÇOS", fontWeight = FontWeight.Black, fontSize = 11.sp, color = accent)
            Spacer(Modifier.height(6.dp))
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                SonusCloudProviders.sortedByDescending { it.id in favoriteProviders }.forEach { provider ->
                    val expanded = expandedProviderId == provider.id
                    val files = providerFiles[provider.id].orEmpty()
                    val providerRecents = recents.filter { it.providerId == provider.id }.take(12)
                    val savedFolders = store.savedFolderUris(provider.id, "audio").toList()
                    val activeFolder = store.folderUri(provider.id, "audio")
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = if (expanded) provider.accent.copy(alpha = .12f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .48f),
                        border = BorderStroke(1.dp, provider.accent.copy(alpha = if (expanded) .62f else .35f)),
                        modifier = Modifier.fillMaxWidth().clickable {
                            pendingProvider = provider
                            val saved = store.folderUri(provider.id, "audio")
                            if (saved == null) folderPicker.launch(null) else if (expanded) expandedProviderId = null else loadProvider(provider)
                        }
                    ) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(shape = CircleShape, color = provider.accent.copy(alpha = .16f)) {
                                    Icon(provider.icon, null, tint = provider.accent, modifier = Modifier.padding(9.dp).size(21.dp))
                                }
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(provider.name, fontWeight = FontWeight.Bold)
                                    Text(
                                        if (store.folderUri(provider.id,"audio") != null) "Pasta salva • toque para ${if(expanded) "recolher" else "abrir"}" else "Toque para escolher a pasta de músicas",
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                }
                                IconButton(onClick = { pendingProvider = provider; picker.launch(arrayOf("audio/*")) }) { Icon(Icons.Default.AudioFile,"Escolher música",tint=provider.accent) }
                                IconButton(onClick = { pendingProvider = provider; folderPicker.launch(null) }) { Icon(Icons.Default.FolderOpen,"Escolher pasta",tint=provider.accent) }
                                IconButton(onClick = { favoriteProviders = store.toggleFavoriteProvider(provider.id) }) {
                                    Icon(if (provider.id in favoriteProviders) Icons.Default.Star else Icons.Default.StarBorder, "Favoritar serviço", tint = if (provider.id in favoriteProviders) Color(0xFFFFD05A) else LocalContentColor.current)
                                }
                            }

                            if (expanded) {
                                HorizontalDivider(color = Color.White.copy(alpha=.08f))
                                if (savedFolders.isNotEmpty()) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("Pastas salvas", fontWeight = FontWeight.ExtraBold, fontSize = 10.sp, modifier = Modifier.weight(1f))
                                        Text("${savedFolders.size}", fontSize = 8.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha=.52f))
                                    }
                                    savedFolders.forEach { raw ->
                                        val folderUri = runCatching { Uri.parse(raw) }.getOrNull()
                                        val folderName = folderUri?.let { DocumentFile.fromTreeUri(context, it)?.name }.orEmpty().ifBlank { "Pasta autorizada" }
                                        Surface(
                                            modifier = Modifier.fillMaxWidth().clickable {
                                                store.setFolderUri(provider.id, "audio", raw)
                                                loadProvider(provider)
                                            },
                                            shape = RoundedCornerShape(11.dp),
                                            color = if (activeFolder == raw) provider.accent.copy(alpha=.13f) else Color.Black.copy(alpha=.11f),
                                            border = BorderStroke(1.dp, if (activeFolder == raw) provider.accent.copy(alpha=.42f) else Color.White.copy(alpha=.05f))
                                        ) {
                                            Row(Modifier.padding(start=8.dp, top=3.dp, bottom=3.dp, end=2.dp), verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Default.Folder, null, tint = provider.accent, modifier = Modifier.size(16.dp))
                                                Spacer(Modifier.width(6.dp))
                                                Text(folderName, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 9.sp)
                                                if (activeFolder == raw) Icon(Icons.Default.Star, "Pasta principal", tint = Color(0xFFFFD05A), modifier = Modifier.size(15.dp))
                                                IconButton(onClick = {
                                                    store.removeSavedFolder(provider.id, "audio", raw)
                                                    providerFiles = providerFiles - provider.id
                                                    if (store.folderUri(provider.id, "audio") != null) loadProvider(provider) else expandedProviderId = null
                                                }, modifier = Modifier.size(28.dp)) {
                                                    Icon(Icons.Default.Close, "Remover pasta salva", tint = LocalContentColor.current.copy(alpha=.58f), modifier = Modifier.size(15.dp))
                                                }
                                            }
                                        }
                                    }
                                }
                                if (loadingProviderId == provider.id) LinearProgressIndicator(Modifier.fillMaxWidth())
                                if (files.isEmpty() && loadingProviderId != provider.id) {
                                    Text("Nenhuma faixa compatível encontrada nesta pasta.", style=MaterialTheme.typography.bodySmall, color=MaterialTheme.colorScheme.onSurface.copy(alpha=.58f))
                                } else {
                                    Row(verticalAlignment=Alignment.CenterVertically) {
                                        Text("Músicas nesta nuvem", fontWeight=FontWeight.ExtraBold, fontSize=11.sp, modifier=Modifier.weight(1f))
                                        Text("${files.size} faixas", fontSize=8.sp, color=MaterialTheme.colorScheme.onSurface.copy(alpha=.55f))
                                    }
                                    files.take(50).forEach { file ->
                                        Surface(shape=RoundedCornerShape(12.dp), color=Color.Black.copy(alpha=.16f), modifier=Modifier.fillMaxWidth().clickable { playProviderFile(file,provider) }) {
                                            Row(Modifier.padding(horizontal=9.dp,vertical=6.dp), verticalAlignment=Alignment.CenterVertically) {
                                                Icon(Icons.Default.MusicNote,null,tint=provider.accent,modifier=Modifier.size(18.dp))
                                                Spacer(Modifier.width(7.dp))
                                                Text(file.title,Modifier.weight(1f),fontSize=9.5.sp,maxLines=1,overflow=TextOverflow.Ellipsis)
                                                IconButton(onClick={favorites=store.toggleFavorite("audio",file.uri)},modifier=Modifier.size(30.dp)) {
                                                    Icon(if(file.uri in favorites)Icons.Default.Favorite else Icons.Default.FavoriteBorder,"Favorito",tint=if(file.uri in favorites)Color(0xFFFF5D7A) else LocalContentColor.current,modifier=Modifier.size(17.dp))
                                                }
                                            }
                                        }
                                    }
                                }
                                val favoriteRecents = providerRecents.filter { it.uri in favorites }
                                if (favoriteRecents.isNotEmpty()) {
                                    Text("Favoritos", fontWeight=FontWeight.ExtraBold, fontSize=10.sp)
                                    favoriteRecents.forEach { recent ->
                                        CloudAudioRecentRow(recent,provider,accent,true,{playUri(Uri.parse(recent.uri),provider)},{favorites=store.toggleFavorite("audio",recent.uri)})
                                    }
                                }
                                if (providerRecents.isNotEmpty()) {
                                    Text("Recentes", fontWeight=FontWeight.ExtraBold, fontSize=10.sp)
                                    providerRecents.forEach { recent ->
                                        CloudAudioRecentRow(recent,provider,accent,recent.uri in favorites,{playUri(Uri.parse(recent.uri),provider)},{favorites=store.toggleFavorite("audio",recent.uri)})
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CloudAudioRecentRow(
    recent: SonusCloudRecent,
    provider: SonusCloudProvider,
    accent: Color,
    favorite: Boolean,
    onPlay:()->Unit,
    onFavorite:()->Unit
) {
    Surface(shape = RoundedCornerShape(14.dp), color = Color.Black.copy(alpha = .20f), modifier = Modifier.fillMaxWidth().clickable(onClick=onPlay)) {
        Row(Modifier.padding(horizontal=10.dp,vertical=7.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(provider.icon, null, tint = provider.accent)
            Spacer(Modifier.width(9.dp))
            Column(Modifier.weight(1f)) {
                Text(recent.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold,fontSize=10.sp)
                Text(provider.name, style = MaterialTheme.typography.labelSmall)
            }
            IconButton(onClick=onFavorite){Icon(if(favorite)Icons.Default.Favorite else Icons.Default.FavoriteBorder,"Favorito",tint=if(favorite)Color(0xFFFF5D7A) else accent.copy(alpha=.65f))}
            Icon(Icons.Default.PlayArrow, null)
        }
    }
}

