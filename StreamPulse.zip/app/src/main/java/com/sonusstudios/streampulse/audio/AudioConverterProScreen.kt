package com.sonusstudios.streampulse.audio

import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.provider.DocumentsContract
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonusstudios.streampulse.core.*
import com.sonusstudios.streampulse.core.SonusStorage
import com.sonusstudios.streampulse.notifications.SonusNotificationCenter
import com.sonusstudios.streampulse.tools.AudioToolEngine
import com.sonusstudios.streampulse.tools.SonusProcessNotifier
import com.sonusstudios.streampulse.tools.SonusExportProgressDialog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import java.io.File
import java.time.LocalDate
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

private data class BatchAudioItem(val uri: Uri, val info: AudioSourceInfo)

private data class BatchAudioEdit(
    val title: String,
    val outputName: String,
    val useTitleAsFilename: Boolean = true,
    val artist: String = "",
    val albumArtist: String = "",
    val album: String = "",
    val genre: String = "",
    val composer: String = "",
    val author: String = "",
    val year: String = "",
    val track: String = "",
    val bpm: String = "",
    val isrc: String = "",
    val copyright: String = "",
    val comment: String = "",
    val lyrics: String = "",
    val artworkUri: Uri? = null,
    val selected: Boolean = true,
    val expanded: Boolean = false,
    val dirty: Boolean = false
)

private fun cleanAudioLabel(raw: String): String {
    var value = raw.substringBeforeLast('.', raw).trim()
    value = value.replace(Regex("[_]+"), " ")
        .replace(Regex("\\s*-{2,}\\s*"), " ")
        .replace(Regex("\\s+-\\s+"), " ")
        .replace(Regex("\\s+"), " ")
        .trim(' ', '-', '_')
    return value.split(' ').joinToString(" ") { word ->
        if (word.length <= 2 && word.all { it.isUpperCase() || it.isDigit() }) word
        else word.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString() }
    }.ifBlank { raw.substringBeforeLast('.', raw).ifBlank { "Faixa" } }
}

private val EqPresets = linkedMapOf(
    "Flat" to listOf(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
    "Rock" to listOf(0.0, -0.530, -2.259, -4.281, -5.493, -6.564, -4.752, -2.716, -0.901, -0.337),
    "Pop" to listOf(-7.213, -6.232, -4.382, -2.258, 0.0, -0.040, -2.265, -4.077, -5.822, -7.363),
    "Classical" to listOf(0.0, -0.872, -2.197, -4.184, -6.156, -5.733, -4.510, -2.850, -1.410, -0.964),
    "Hip-Hop" to listOf(0.0, -0.235, -1.203, -3.799, -6.432, -6.994, -5.662, -4.968, -4.003, -1.329),
    "Jazz" to listOf(-3.826, -3.670, -3.263, -2.812, -3.525, -4.614, -4.027, -2.569, -1.162, 0.0)
)

@Composable
fun AudioConverterProScreen(
    artist: Artist,
    hasDistributionProfile: Boolean,
    pulseCoins: Int,
    membershipTier: MembershipTier,
    coinUnlimited: Boolean,
    pulseLiftUnlocked: Boolean,
    pulseOrbit3dUnlocked: Boolean,
    pulseOrbit8dUnlocked: Boolean,
    onBack: () -> Unit,
    onSavePreset: (AudioConversionPreset) -> Unit,
    onWatchRewardedAdForCoin: () -> Unit,
    onUnlockFeature24h: (feature: PulseFeaturePass, onUnlocked: () -> Unit, onUnavailable: (String) -> Unit) -> Unit,
    onSpendCoins: suspend (Int) -> Boolean,
    onTrack: (name: String, success: Boolean?, durationMs: Long?) -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val commercial = commercialTier(membershipTier)
    val batchBase = when (commercial) {
        MembershipTier.FREE -> 5
        MembershipTier.PRATA -> 10
        MembershipTier.OURO -> 20
        MembershipTier.DIAMANTE -> Int.MAX_VALUE
        else -> 10
    }
    val batchStep = when (commercial) {
        MembershipTier.FREE, MembershipTier.PRATA -> 5
        MembershipTier.OURO -> 10
        MembershipTier.DIAMANTE -> Int.MAX_VALUE
        else -> 5
    }
    val batchLimit = if (coinUnlimited || commercial == MembershipTier.DIAMANTE) Int.MAX_VALUE
        else batchBase + pulseCoins.coerceAtLeast(0) * batchStep

    var preset by remember(artist.id, hasDistributionProfile) {
        mutableStateOf(loadLocalConverterPreset(context, artist, hasDistributionProfile))
    }
    var files by remember { mutableStateOf<List<BatchAudioItem>>(emptyList()) }
    var batchEdits by remember { mutableStateOf<Map<String, BatchAudioEdit>>(emptyMap()) }
    var artworkTargetKey by remember { mutableStateOf<String?>(null) }
    var lyricsTargetKey by remember { mutableStateOf<String?>(null) }
    var showCleanPreview by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var globalProgress by remember { mutableFloatStateOf(0f) }
    var status by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var quickEqExpanded by remember { mutableStateOf(false) }
    var advancedEq by remember { mutableStateOf(false) }
    var eqSectionEnabled by rememberSaveable { mutableStateOf(false) }
    var metadataSectionEnabled by rememberSaveable { mutableStateOf(false) }
    var pulseLiftSessionUnlocked by remember { mutableStateOf(true) }
    var previewFile by remember { mutableStateOf<File?>(null) }
    var previewBusy by remember { mutableStateOf(false) }
    var previewMode by remember { mutableStateOf<String?>(null) }
    var previewPlayer by remember { mutableStateOf<MediaPlayer?>(null) }
    var previewPlaying by remember { mutableStateOf(false) }
    var namedPresets by remember { mutableStateOf(loadNamedConverterPresets(context, artist.id)) }
    var showPresetDialog by remember { mutableStateOf(false) }
    var presetName by remember { mutableStateOf("") }
    val metadataPrefs = remember { context.getSharedPreferences("sonus_metadata_defaults_v3", Context.MODE_PRIVATE) }
    // Metadados do conversor são independentes do perfil de artista selecionado no SONUS.
    var artistTag by rememberSaveable {
        mutableStateOf(metadataPrefs.getString("artist", "").orEmpty())
    }
    var albumArtistTag by rememberSaveable { mutableStateOf(metadataPrefs.getString("albumArtist", "").orEmpty()) }
    var authorTag by rememberSaveable { mutableStateOf(metadataPrefs.getString("author", "").orEmpty()) }
    var copyrightTag by rememberSaveable { mutableStateOf(metadataPrefs.getString("copyright", "").orEmpty()) }
    var commentTag by rememberSaveable { mutableStateOf(metadataPrefs.getString("comment", "").orEmpty()) }
    var bpmTag by rememberSaveable { mutableStateOf(metadataPrefs.getString("bpm", "").orEmpty()) }
    var isrcTag by rememberSaveable { mutableStateOf("") }
    var lyricsTag by rememberSaveable { mutableStateOf("") }
    var lyricsSource by remember { mutableStateOf("") }
    var artworkUri by remember { mutableStateOf<Uri?>(null) }
    val artworkPreview by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, artworkUri) {
        value = withContext(Dispatchers.IO) {
            artworkUri?.let { uri ->
                runCatching {
                    context.contentResolver.openInputStream(uri)?.use { input ->
                        android.graphics.BitmapFactory.decodeStream(input)?.asImageBitmap()
                    }
                }.getOrNull()
            }
        }
    }
    var preserveSourceTags by rememberSaveable { mutableStateOf(true) }

    suspend fun buildBatchEdits(items: List<BatchAudioItem>): Map<String, BatchAudioEdit> = withContext(Dispatchers.IO) {
        items.associate { item ->
            val original = runCatching { AudioToolEngine.readMetadata(context, item.uri) }.getOrDefault(com.sonusstudios.streampulse.tools.AudioMetadata())
            val base = item.info.displayName.substringBeforeLast('.').ifBlank { "Faixa" }
            val title = original.title.ifBlank { base }
            item.uri.toString() to BatchAudioEdit(
                title = title,
                outputName = "${base}_SONUS",
                artist = artistTag.ifBlank { original.artist },
                albumArtist = albumArtistTag.ifBlank { original.albumArtist },
                album = preset.album.ifBlank { original.album },
                genre = preset.genre.ifBlank { original.genre },
                composer = preset.composer.ifBlank { original.composer },
                author = authorTag.ifBlank { original.author },
                year = original.year.ifBlank { LocalDate.now().year.toString() },
                track = original.track,
                bpm = bpmTag.ifBlank { original.bpm },
                isrc = isrcTag.ifBlank { original.isrc },
                copyright = copyrightTag.ifBlank { original.copyright },
                comment = commentTag.ifBlank { original.comment },
                lyrics = lyricsTag.ifBlank { original.lyrics },
                artworkUri = artworkUri
            )
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            runCatching { previewPlayer?.release() }
            runCatching { previewFile?.delete() }
        }
    }

    LaunchedEffect(preset) { saveLocalConverterPreset(context, artist.id, preset) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            scope.launch {
                val allowed = if (batchLimit == Int.MAX_VALUE) uris else uris.take(batchLimit)
                val extraCount = (allowed.size - batchBase).coerceAtLeast(0)
                val requiredCoins = if (extraCount <= 0 || coinUnlimited || commercial == MembershipTier.DIAMANTE) 0 else (extraCount + batchStep - 1) / batchStep
                val paid = requiredCoins == 0 || onSpendCoins(requiredCoins)
                val finalUris = if (paid) allowed else uris.take(batchBase)
                if (!paid && commercial == MembershipTier.FREE) onWatchRewardedAdForCoin()
                finalUris.forEach { uri -> runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } }
                val inspected = withContext(Dispatchers.IO) { finalUris.mapNotNull { u -> runCatching { BatchAudioItem(u, AudioConversionEngine.inspect(context, u)) }.getOrNull() } }
                files = inspected
                batchEdits = buildBatchEdits(inspected)
                message = when {
                    !paid && commercial == MembershipTier.FREE -> "Lote básico: 5 arquivos. Assista ao anúncio para ganhar 1 moeda e liberar +5."
                    !paid -> "Moedas SONUS insuficientes para ampliar o lote."
                    uris.size > finalUris.size -> "${finalUris.size} arquivo(s) carregado(s). Mais capacidade pode ser liberada com Moedas SONUS."
                    requiredCoins > 0 -> "+$extraCount arquivo(s) liberados por $requiredCoins Moeda(s) SONUS."
                    else -> null
                }
                status = emptyMap(); globalProgress = 0f
            }
        }
    }
    val inputFolderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { tree ->
        if (tree != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            scope.launch {
                val uris = withContext(Dispatchers.IO) { listAudioDocuments(context, tree) }
                val allowed = if (batchLimit == Int.MAX_VALUE) uris else uris.take(batchLimit)
                val extraCount = (allowed.size - batchBase).coerceAtLeast(0)
                val requiredCoins = if (extraCount <= 0 || coinUnlimited || commercial == MembershipTier.DIAMANTE) 0 else (extraCount + batchStep - 1) / batchStep
                val paid = requiredCoins == 0 || onSpendCoins(requiredCoins)
                val finalUris = if (paid) allowed else uris.take(batchBase)
                if (!paid && commercial == MembershipTier.FREE) onWatchRewardedAdForCoin()
                val inspected = withContext(Dispatchers.IO) { finalUris.mapNotNull { u -> runCatching { BatchAudioItem(u, AudioConversionEngine.inspect(context, u)) }.getOrNull() } }
                files = inspected
                batchEdits = buildBatchEdits(inspected)
                message = when {
                    uris.isEmpty() -> "Nenhum arquivo de áudio foi encontrado nessa pasta."
                    !paid && commercial == MembershipTier.FREE -> "Carregamos 5 arquivos. Assista ao anúncio para ganhar 1 moeda e liberar +5."
                    !paid -> "Moedas SONUS insuficientes para ampliar o lote."
                    uris.size > finalUris.size -> "Carregamos ${finalUris.size} arquivo(s). Amplie o lote com Moedas SONUS."
                    requiredCoins > 0 -> "${inspected.size} música(s) carregada(s) • $requiredCoins Moeda(s) SONUS usadas no lote."
                    else -> "${inspected.size} música(s) carregada(s) da pasta."
                }
                status = emptyMap(); globalProgress = 0f
            }
        }
    }

    val artworkPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val target = artworkTargetKey
            if (target != null) {
                batchEdits = batchEdits + (target to (batchEdits[target] ?: return@rememberLauncherForActivityResult).copy(artworkUri = uri, dirty = true))
                artworkTargetKey = null
            } else artworkUri = uri
        }
    }
    val lyricsPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val result = withContext(Dispatchers.IO) { SonusLyricsImporter.read(context, uri) }
            result.onSuccess { doc ->
                val target = lyricsTargetKey
                if (target != null) {
                    batchEdits = batchEdits + (target to (batchEdits[target] ?: return@onSuccess).copy(lyrics = doc.text, dirty = true))
                    lyricsTargetKey = null
                } else {
                    lyricsTag = doc.text
                    lyricsSource = if (doc.format == "LRC") "LRC sincronizado importado" else "TXT importado"
                }
            }.onFailure { message = it.message ?: "Não foi possível importar a letra." }
        }
    }

    LaunchedEffect(artistTag, albumArtistTag, preset.album, preset.genre, preset.composer, authorTag, copyrightTag, commentTag, bpmTag) {
        metadataPrefs.edit()
            .putString("artist", artistTag)
            .putString("albumArtist", albumArtistTag)
            .putString("album", preset.album)
            .putString("genre", preset.genre)
            .putString("composer", preset.composer)
            .putString("author", authorTag)
            .putString("copyright", copyrightTag)
            .putString("comment", commentTag)
            .putString("bpm", bpmTag)
            .apply()
    }

    val advanced = preset.eqAdvancedOffsetsDb.takeIf { it.size == 10 } ?: List(10) { 0.0 }
    val baseEq = EqPresets[preset.eqPresetName] ?: EqPresets.getValue("Flat")
    val finalEq = baseEq.mapIndexed { index, value ->
        val region = when (index) { in 0..3 -> preset.eqBassDb; in 4..6 -> preset.eqMidDb; else -> preset.eqTrebleDb }
        (value + region + advanced[index]).coerceIn(-12.0, 6.0)
    }
    val eqActive = preset.eqPresetName != "Flat" || preset.eqBassDb != 0.0 || preset.eqMidDb != 0.0 || preset.eqTrebleDb != 0.0 || advanced.any { kotlin.math.abs(it) > .01 }
    val processing = AudioProcessingConfig(
        eqEnabled = eqSectionEnabled && eqActive,
        eqBandsDb = finalEq,
        pulseLiftEnabled = false,
        pulseLiftIntensity = 0,
        pulseOrbitMode = "OFF",
        pulseOrbitPreset = "Off",
        pulseOrbitIntensity = 0
    )
    val recommended = true
    val lossy = preset.format in setOf("MP3", "M4A", "AAC", "OGG", "OPUS")
    val year = LocalDate.now().year.toString()
    val plannedOutputNames = files.mapNotNull { item ->
        val edit = batchEdits[item.uri.toString()] ?: return@mapNotNull null
        val base = if (edit.useTitleAsFilename) edit.title else edit.outputName
        sanitizeName("${base.ifBlank { item.info.displayName.substringBeforeLast('.') }}.${AudioConversionEngine.outputExtension(preset.format)}").lowercase(Locale.getDefault())
    }
    val duplicateOutputNames = plannedOutputNames.groupingBy { it }.eachCount().filterValues { it > 1 }.keys
    val canConvert = files.isNotEmpty() && !busy && duplicateOutputNames.isEmpty()

    fun updateBatchEdit(key: String, transform: (BatchAudioEdit) -> BatchAudioEdit) {
        val current = batchEdits[key] ?: return
        batchEdits = batchEdits + (key to transform(current))
    }

    fun applyBatchDefaults(onlySelected: Boolean) {
        batchEdits = batchEdits.mapValues { (_, edit) ->
            if (onlySelected && !edit.selected) edit else edit.copy(
                artist = artistTag.ifBlank { edit.artist },
                albumArtist = albumArtistTag.ifBlank { edit.albumArtist },
                album = preset.album.ifBlank { edit.album },
                genre = preset.genre.ifBlank { edit.genre },
                composer = preset.composer.ifBlank { edit.composer },
                author = authorTag.ifBlank { edit.author },
                year = edit.year.ifBlank { year },
                bpm = bpmTag.ifBlank { edit.bpm },
                isrc = isrcTag.ifBlank { edit.isrc },
                copyright = copyrightTag.ifBlank { edit.copyright },
                comment = commentTag.ifBlank { edit.comment },
                lyrics = lyricsTag.ifBlank { edit.lyrics },
                artworkUri = artworkUri ?: edit.artworkUri,
                dirty = true
            )
        }
    }

    fun stopPreview() {
        runCatching { previewPlayer?.stop() }; runCatching { previewPlayer?.release() }
        previewPlayer = null; previewPlaying = false; previewMode = null
    }

    fun playPreview(mode: String) {
        val item = files.firstOrNull() ?: return
        if (previewMode == mode && previewPlaying) {
            previewPlayer?.pause(); previewPlaying = false; return
        }
        stopPreview()
        val duration = item.info.durationMs ?: 0L
        val startMs = max(0L, (duration * .35).toLong() - 10_000L).toInt()
        val p = MediaPlayer()
        runCatching {
            if (mode == "Original") {
                p.setDataSource(context, item.uri); p.prepare(); p.seekTo(startMs)
            } else {
                val f = previewFile ?: return
                p.setDataSource(f.absolutePath); p.prepare()
            }
            p.setOnCompletionListener { previewPlaying = false; previewMode = null }
            p.start(); previewPlayer = p; previewPlaying = true; previewMode = mode
        }.onFailure { runCatching { p.release() }; message = "Não foi possível reproduzir a prévia: ${it.message}" }
    }

    if(showPresetDialog){
        AlertDialog(
            onDismissRequest={showPresetDialog=false},
            title={Text("Salvar preset personalizado")},
            text={OutlinedTextField(presetName,{presetName=it.take(32)},label={Text("Nome do preset")},singleLine=true)},
            confirmButton={TextButton(onClick={
                val clean=presetName.trim().ifBlank{"Meu preset"}
                saveNamedConverterPreset(context,artist.id,clean,preset)
                namedPresets=loadNamedConverterPresets(context,artist.id)
                presetName="";showPresetDialog=false;message="Preset '$clean' salvo neste aparelho."
            }){Text("Salvar")}},
            dismissButton={TextButton(onClick={showPresetDialog=false}){Text("Cancelar")}}
        )
    }

    if (showCleanPreview) {
        val targets = batchEdits.filterValues { it.selected }
        val preview = targets.entries.map { (key, edit) -> key to (edit.title to cleanAudioLabel(edit.title)) }
        AlertDialog(
            onDismissRequest = { showCleanPreview = false },
            title = { Text("Limpar títulos selecionados") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("O SONUS remove separadores como _ e hífens repetidos. Revise antes de aplicar.", style = MaterialTheme.typography.bodySmall)
                    preview.take(8).forEach { (_, pair) ->
                        Column {
                            Text(pair.first, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelSmall)
                            Text("→ ${pair.second}", maxLines = 1, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                        }
                    }
                    if (preview.size > 8) Text("+ ${preview.size - 8} faixa(s)", style = MaterialTheme.typography.labelSmall)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    batchEdits = batchEdits.mapValues { (key, edit) ->
                        if (!edit.selected) edit else {
                            val clean = cleanAudioLabel(edit.title)
                            edit.copy(title = clean, outputName = if (edit.useTitleAsFilename) clean else edit.outputName, dirty = true)
                        }
                    }
                    showCleanPreview = false
                }) { Text("Aplicar") }
            },
            dismissButton = { TextButton(onClick = { showCleanPreview = false }) { Text("Cancelar") } }
        )
    }

    if (busy) {
        SonusExportProgressDialog(
            percent = (globalProgress.coerceIn(0f, 1f) * 100).roundToInt(),
            phase = status.values.lastOrNull() ?: "Convertendo lote…",
            title = "Conversor SONUS",
            onCancel = null
        )
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 14.dp, bottom = 32.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Voltar") }
                Column(Modifier.weight(1f)) {
                    Text("Conversor de áudio Pro", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Lote • EQ • exportação local", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .62f))
                }
                Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.primaryContainer) {
                    val usageLabel = when {
                        coinUnlimited || membershipTier == MembershipTier.DIAMANTE -> "DIAMANTE • ilimitado"
                        membershipTier == MembershipTier.FREE -> "FREE • 5 moedas/mês"
                        else -> "${monthlyToolUsageAllowance(membershipTier)} moedas/mês"
                    }
                    Text(usageLabel, modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp), fontWeight = FontWeight.ExtraBold, fontSize = 10.sp)
                }
            }
            if (!coinUnlimited && pulseCoins <= 0) {
                Spacer(Modifier.height(8.dp))
                if (membershipTier == MembershipTier.FREE) {
                    OutlinedButton(onClick = onWatchRewardedAdForCoin, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.SmartDisplay, null)
                        Spacer(Modifier.width(7.dp))
                        Text("Assistir anúncio • ganhar +1 Moeda SONUS")
                    }
                } else {
                    Text(
                        "Suas Moedas SONUS acabaram. Aguarde a renovação ou use a opção de anúncio quando disponível.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        item {
            ProSection("1. Músicas do lote", Icons.Default.LibraryMusic) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { picker.launch(arrayOf("audio/*", "application/octet-stream")) }, enabled = !busy, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.LibraryMusic, null); Spacer(Modifier.width(6.dp)); Text("Músicas")
                    }
                    OutlinedButton(onClick = { inputFolderPicker.launch(null) }, enabled = !busy, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(6.dp)); Text("Pasta / álbum")
                    }
                }
                if (files.isNotEmpty()) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = .42f)
                    ) {
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = { playPreview("Original") }, enabled = !busy) {
                                Icon(
                                    if (previewMode == "Original" && previewPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    if (previewMode == "Original" && previewPlaying) "Pausar" else "Ouvir"
                                )
                            }
                            Column(Modifier.weight(1f)) {
                                Text(files.first().info.displayName, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold)
                                Text("Player rápido • ouça antes de ajustar", style = MaterialTheme.typography.labelSmall)
                            }
                            Text(if (previewMode == "Original" && previewPlaying) "TOCANDO" else "ORIGINAL", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
                AssistChip(onClick={}, label={Text(if(batchLimit==Int.MAX_VALUE)"∞" else "$batchBase + extras")})
                Text(when (commercial) {
                    MembershipTier.FREE -> "5 arquivos • +5 por 1 moeda ou anúncio"
                    MembershipTier.PRATA -> "10 arquivos • +5 por 1 moeda"
                    MembershipTier.OURO -> "20 arquivos • +10 por 1 moeda"
                    MembershipTier.DIAMANTE -> "Lote ilimitado pelo plano"
                    else -> "10 arquivos • +5 por 1 moeda"
                }, style=MaterialTheme.typography.labelSmall)
                files.forEachIndexed { index, item ->
                    Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.55f)) {
                        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary.copy(alpha=.15f)) { Text("${index+1}", modifier=Modifier.padding(8.dp), fontWeight=FontWeight.Bold) }
                            Spacer(Modifier.width(9.dp))
                            Column(Modifier.weight(1f)) {
                                Text(item.info.displayName, maxLines=1, overflow=TextOverflow.Ellipsis, fontWeight=FontWeight.SemiBold)
                                Text(buildList { item.info.durationMs?.let { add(formatDuration(it)) }; item.info.sizeBytes?.let { add(formatBytes(it)) }; item.info.sampleRateHz?.let { add("${it/1000.0} kHz") } }.joinToString(" • "), style=MaterialTheme.typography.labelSmall)
                                status[item.uri.toString()]?.let { Text(it, style=MaterialTheme.typography.labelSmall, color=MaterialTheme.colorScheme.primary) }
                            }
                            IconButton(onClick = { if(!busy) files = files.filterNot { it.uri == item.uri } }) { Icon(Icons.Default.Close, "Remover") }
                        }
                    }
                }
            }
        }

        item {
            ProSection("2. Perfil de saída", Icons.Default.Tune) {
                if (false) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Switch(checked = preset.useDistributorRecommended, onCheckedChange = { checked ->
                            preset = if (checked) AudioDistributorCatalog.defaultPreset(artist.distributor).copy(
                                album=preset.album, genre=preset.genre, composer=preset.composer,
                                eqPresetName=preset.eqPresetName, eqBassDb=preset.eqBassDb, eqMidDb=preset.eqMidDb, eqTrebleDb=preset.eqTrebleDb,
                                eqAdvancedOffsetsDb=preset.eqAdvancedOffsetsDb, pulseLiftEnabled=preset.pulseLiftEnabled, pulseLiftIntensity=preset.pulseLiftIntensity,
                                pulseOrbitMode=preset.pulseOrbitMode, pulseOrbitPreset=preset.pulseOrbitPreset, pulseOrbitIntensity=preset.pulseOrbitIntensity,
                                useDistributorRecommended=true
                            ) else preset.copy(useDistributorRecommended=false)
                        })
                        Spacer(Modifier.width(8.dp)); Text("Usar recomendação da distribuidora", fontWeight=FontWeight.SemiBold)
                    }
                } else {
                    
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CompactChoice("Formato", preset.format, AudioConversionEngine.supportedFormats, Modifier.weight(1f)) { format ->
                        val normalized = AudioConversionEngine.normalizedSampleRate(format, preset.sampleRateHz)
                        preset = preset.copy(format=format, sampleRateHz=normalized, useDistributorRecommended=false)
                    }
                    val allowedRates = AudioConversionEngine.sampleRatesFor(preset.format)
                    CompactChoice("Sample", sampleLabel(AudioConversionEngine.normalizedSampleRate(preset.format, preset.sampleRateHz)), allowedRates.map(::sampleLabel), Modifier.weight(1f)) { label ->
                        allowedRates.firstOrNull { sampleLabel(it)==label }?.let { preset=preset.copy(sampleRateHz=it, useDistributorRecommended=false) }
                    }
                }
                if (preset.format.equals("MP3", true)) {
                    Text("MP3 usa 44,1 ou 48 kHz. Arquivos Hi-Res são reamostrados automaticamente antes da codificação.", style=MaterialTheme.typography.labelSmall, color=MaterialTheme.colorScheme.onSurface.copy(alpha=.62f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val bitrateOptions = SonusMediaStandards.bitratePresets(preset.format)
                    if (!lossy) {
                        CompactChoice("Bits", "${preset.bitDepth}-bit", listOf("16-bit","24-bit"), Modifier.weight(1f)) { preset=preset.copy(bitDepth=it.substringBefore('-').toInt(), useDistributorRecommended=false) }
                    } else if (bitrateOptions.isNotEmpty()) {
                        val normalizedBitrate = SonusMediaStandards.nearestBitrate(preset.format, preset.bitrateKbps)
                        CompactChoice("Bitrate", "$normalizedBitrate kbps", bitrateOptions.map { "$it kbps" }, Modifier.weight(1f)) { preset=preset.copy(bitrateKbps=it.substringBefore(' ').toInt()) }
                    } else {
                        Text("VBR", modifier=Modifier.weight(1f), style=MaterialTheme.typography.labelLarge)
                    }
                    CompactChoice("Canais", if(preset.channels==1)"Mono" else "Estéreo", listOf("Estéreo","Mono"), Modifier.weight(1f)) { preset=preset.copy(channels=if(it=="Mono")1 else 2) }
                }
                if (hasDistributionProfile && !recommended) Text("⚠ Fora do perfil recomendado da distribuidora. A conversão continua liberada.", style=MaterialTheme.typography.bodySmall, color=Color(0xFFE9A34B))
                OutlinedButton(onClick={
                    preset = AudioConversionPreset(useDistributorRecommended=false)
                    message = "Configurações restauradas para o padrão livre do SONUS."
                },modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.RestartAlt,null);Spacer(Modifier.width(6.dp));Text("Restaurar padrão")}
            }
        }

        item {
            ProSection("3. Equalizador", Icons.Default.GraphicEq) {
                Row(verticalAlignment=Alignment.CenterVertically){Text("Ativar equalizador",Modifier.weight(1f),fontWeight=FontWeight.SemiBold);Switch(eqSectionEnabled,{eqSectionEnabled=it})}
                AnimatedVisibility(eqSectionEnabled) { Column(verticalArrangement=Arrangement.spacedBy(7.dp)) {
                Text("Presets de 10 bandas • 32 Hz → 16 kHz", style=MaterialTheme.typography.bodySmall, color=MaterialTheme.colorScheme.onSurface.copy(alpha=.65f))
                if(namedPresets.isNotEmpty()){
                    Text("Meus presets",fontWeight=FontWeight.Bold,style=MaterialTheme.typography.labelLarge)
                    LazyRow(horizontalArrangement=Arrangement.spacedBy(7.dp)){
                        items(namedPresets){ entry -> AssistChip(onClick={preset=entry.second},label={Text(entry.first)},leadingIcon={Icon(Icons.Default.Bookmark,null)}) }
                    }
                }
                LazyRow(horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                    items(EqPresets.keys.toList()) { name ->
                        val accent = eqPresetColor(name)
                        FilterChip(
                            selected=preset.eqPresetName==name,
                            onClick={preset=preset.copy(eqPresetName=name, eqAdvancedOffsetsDb=List(10){0.0})},
                            label={Text(name)},
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = accent.copy(alpha = .22f),
                                selectedLabelColor = accent
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = preset.eqPresetName == name,
                                borderColor = accent.copy(alpha = .42f),
                                selectedBorderColor = accent
                            )
                        )
                    }
                }
                EqCurve(finalEq, eqPresetColor(preset.eqPresetName))
                TextButton(onClick={quickEqExpanded=!quickEqExpanded}, modifier = Modifier.fillMaxWidth()) {
                    Icon(if(quickEqExpanded)Icons.Default.ExpandLess else Icons.Default.ExpandMore,null)
                    Spacer(Modifier.width(5.dp))
                    Text(if(quickEqExpanded)"Ocultar ajuste rápido" else "Ajuste rápido • Graves / Médios / Agudos")
                }
                AnimatedVisibility(quickEqExpanded) {
                    Column {
                        EqSlider("Graves", preset.eqBassDb) { preset=preset.copy(eqBassDb=it) }
                        EqSlider("Médios", preset.eqMidDb) { preset=preset.copy(eqMidDb=it) }
                        EqSlider("Agudos", preset.eqTrebleDb) { preset=preset.copy(eqTrebleDb=it) }
                    }
                }
                TextButton(onClick={advancedEq=!advancedEq}, modifier = Modifier.fillMaxWidth()) { Icon(if(advancedEq)Icons.Default.ExpandLess else Icons.Default.ExpandMore,null); Spacer(Modifier.width(5.dp)); Text(if(advancedEq)"Ocultar 10 bandas" else "Equalizador avançado • 10 bandas") }
                AnimatedVisibility(advancedEq) {
                    Column(verticalArrangement=Arrangement.spacedBy(3.dp)) {
                        AudioConversionEngine.eqBandsHz.forEachIndexed { index, hz ->
                            val v=advanced[index]
                            Row(verticalAlignment=Alignment.CenterVertically) {
                                Text(if(hz>=1000)"${hz/1000}k" else "$hz", modifier=Modifier.width(44.dp), style=MaterialTheme.typography.labelSmall)
                                Slider(value=v.toFloat(), onValueChange={nv-> val l=advanced.toMutableList();l[index]=nv.toDouble();preset=preset.copy(eqAdvancedOffsetsDb=l)}, valueRange=-6f..6f, modifier=Modifier.weight(1f))
                                Text(String.format(Locale.US,"%+.1f",v), modifier=Modifier.width(46.dp), style=MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick={preset=preset.copy(eqPresetName="Flat",eqBassDb=0.0,eqMidDb=0.0,eqTrebleDb=0.0,eqAdvancedOffsetsDb=List(10){0.0})},modifier=Modifier.weight(1f)){Text("Resetar EQ")}
                    OutlinedButton(onClick={showPresetDialog=true},modifier=Modifier.weight(1f)){Icon(Icons.Default.BookmarkAdd,null);Spacer(Modifier.width(5.dp));Text("Meu preset")}
                }
                TextButton(onClick={onSavePreset(preset)},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Save,null);Spacer(Modifier.width(5.dp));Text(if (artist.id == "pulse-studio-local") "Salvar configuração do Conversor" else "Salvar configuração no artista")}
                } }
            }
        }


        if (files.isNotEmpty()) item {
            ProSection("4. Pré-escuta A/B", Icons.Default.Headphones) {
                Text("Compare o arquivo original com a equalização antes de exportar. Apenas um player toca por vez.", style=MaterialTheme.typography.bodySmall)
                Button(onClick={
                    scope.launch {
                        stopPreview(); previewBusy=true; runCatching{previewFile?.delete()}; previewFile=null
                        val first=files.first(); val d=first.info.durationMs?:0L; val start=max(0.0,d/1000.0*.35-10.0)
                        val result=withContext(Dispatchers.IO){AudioConversionEngine.buildProcessedPreview(context, first.uri, processing, start,20.0)}
                        previewFile=result.getOrNull(); message=result.exceptionOrNull()?.message; previewBusy=false
                    }
                }, enabled=!previewBusy && !busy, modifier=Modifier.fillMaxWidth()) { if(previewBusy)CircularProgressIndicator(Modifier.size(20.dp),strokeWidth=2.dp) else Icon(Icons.Default.AutoFixHigh,null);Spacer(Modifier.width(7.dp));Text(if(previewBusy)"Gerando prévia..." else "Gerar prévia processada • 20s") }
                if(previewFile!=null) Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    Button(onClick={playPreview("Original")},modifier=Modifier.weight(1f)){Icon(if(previewMode=="Original"&&previewPlaying)Icons.Default.Pause else Icons.Default.PlayArrow,null);Spacer(Modifier.width(4.dp));Text("Original")}
                    Button(onClick={playPreview("Processado")},modifier=Modifier.weight(1f)){Icon(if(previewMode=="Processado"&&previewPlaying)Icons.Default.Pause else Icons.Default.PlayArrow,null);Spacer(Modifier.width(4.dp));Text("Equalizado")}
                }
            }
        }

        item {
            ProSection("5. Metadados, capa e letras", Icons.Default.Sell) {
                Row(verticalAlignment=Alignment.CenterVertically){
                    Text("Editar metadados",Modifier.weight(1f),fontWeight=FontWeight.SemiBold)
                    Switch(metadataSectionEnabled,{metadataSectionEnabled=it})
                }
                Row(verticalAlignment=Alignment.CenterVertically){
                    Text("Preservar dados existentes quando o campo novo estiver vazio",Modifier.weight(1f),style=MaterialTheme.typography.bodySmall)
                    Switch(preserveSourceTags,{preserveSourceTags=it})
                }
                AnimatedVisibility(metadataSectionEnabled){
                    Column(verticalArrangement=Arrangement.spacedBy(9.dp)){
                        Text("Padrões do lote", fontWeight=FontWeight.Black, color=MaterialTheme.colorScheme.primary)
                        Text("Defina valores comuns e aplique só quando quiser. Campos individuais continuam editáveis.", style=MaterialTheme.typography.bodySmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(preset.album,{preset=preset.copy(album=it.take(160))},label={Text("Álbum")},singleLine=true,modifier=Modifier.weight(1f))
                            CompactChoice("Gênero", SonusMediaPreferences.initialGenre(context, preset.genre), SonusMediaStandards.genres, Modifier.weight(1f)) { selected ->
                                SonusMediaPreferences.saveLastGenre(context, selected); preset=preset.copy(genre=selected)
                            }
                        }
                        OutlinedTextField(artistTag,{artistTag=it.take(160)},label={Text("Artista")},singleLine=true,modifier=Modifier.fillMaxWidth())
                        OutlinedTextField(albumArtistTag,{albumArtistTag=it.take(160)},label={Text("Artista do álbum")},singleLine=true,modifier=Modifier.fillMaxWidth())
                        OutlinedTextField(preset.composer,{preset=preset.copy(composer=it.take(160))},label={Text("Compositor")},singleLine=true,modifier=Modifier.fillMaxWidth())
                        OutlinedTextField(authorTag,{authorTag=it.take(160)},label={Text("Autor")},singleLine=true,modifier=Modifier.fillMaxWidth())
                        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                            OutlinedTextField(bpmTag,{bpmTag=it.filter{c->c.isDigit()||c=='.'}.take(8)},label={Text("BPM")},singleLine=true,modifier=Modifier.weight(1f))
                            OutlinedTextField(isrcTag,{isrcTag=it.take(24)},label={Text("ISRC")},singleLine=true,modifier=Modifier.weight(1f))
                        }
                        OutlinedTextField(copyrightTag,{copyrightTag=it.take(220)},label={Text("Copyright")},singleLine=true,modifier=Modifier.fillMaxWidth())
                        OutlinedTextField(commentTag,{commentTag=it.take(500)},label={Text("Comentário")},modifier=Modifier.fillMaxWidth())
                        Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){
                            OutlinedButton(onClick={artworkTargetKey=null;artworkPicker.launch(arrayOf("image/*"))},modifier=Modifier.weight(1f)){
                                Icon(Icons.Default.AddPhotoAlternate,null);Spacer(Modifier.width(5.dp));Text(if(artworkUri==null)"Capa padrão" else "Trocar capa")
                            }
                            OutlinedButton(onClick={lyricsTargetKey=null;lyricsPicker.launch(SonusLyricsImporter.pickerMimeTypes())},modifier=Modifier.weight(1f)){
                                Icon(Icons.Default.Description,null);Spacer(Modifier.width(5.dp));Text("Letra padrão")
                            }
                        }
                        Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){
                            Button(onClick={applyBatchDefaults(true)},enabled=batchEdits.values.any{it.selected},modifier=Modifier.weight(1f)){Text("Aplicar selecionadas",fontSize=10.sp)}
                            Button(onClick={applyBatchDefaults(false)},enabled=batchEdits.isNotEmpty(),modifier=Modifier.weight(1f)){Text("Aplicar a todas",fontSize=10.sp)}
                        }
                        Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){
                            OutlinedButton(onClick={showCleanPreview=true},enabled=batchEdits.values.any{it.selected},modifier=Modifier.weight(1f)){
                                Icon(Icons.Default.AutoFixHigh,null);Spacer(Modifier.width(4.dp));Text("Limpar títulos",fontSize=10.sp)
                            }
                            TextButton(onClick={
                                val allSelected=batchEdits.values.all{it.selected}
                                batchEdits=batchEdits.mapValues{(_,e)->e.copy(selected=!allSelected)}
                            },modifier=Modifier.weight(1f)){Text(if(batchEdits.values.all{it.selected})"Desmarcar todas" else "Selecionar todas",fontSize=10.sp)}
                        }
                        HorizontalDivider()
                        Text("Músicas do lote",fontWeight=FontWeight.Black)
                        files.forEachIndexed { index,item ->
                            val key=item.uri.toString()
                            val edit=batchEdits[key] ?: BatchAudioEdit(item.info.displayName.substringBeforeLast('.'), item.info.displayName.substringBeforeLast('.')+"_SONUS")
                            Surface(shape=RoundedCornerShape(15.dp),color=MaterialTheme.colorScheme.surface.copy(alpha=.72f),border=BorderStroke(1.dp,MaterialTheme.colorScheme.outline.copy(alpha=.18f))){
                                Column(Modifier.padding(10.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){
                                    Row(verticalAlignment=Alignment.CenterVertically){
                                        Checkbox(checked=edit.selected,onCheckedChange={v->updateBatchEdit(key){it.copy(selected=v)}})
                                        Surface(shape=CircleShape,color=MaterialTheme.colorScheme.primary.copy(alpha=.14f)){Text("${index+1}",Modifier.padding(horizontal=7.dp,vertical=5.dp),fontWeight=FontWeight.Bold)}
                                        Spacer(Modifier.width(7.dp))
                                        Column(Modifier.weight(1f)){
                                            Text(edit.title.ifBlank{item.info.displayName},maxLines=1,overflow=TextOverflow.Ellipsis,fontWeight=FontWeight.Bold)
                                            Text(when{edit.dirty->"Alterado";edit.artist.isBlank()||edit.album.isBlank()->"Metadados incompletos";else->"Original / pronto"},style=MaterialTheme.typography.labelSmall,color=if(edit.dirty)MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha=.58f))
                                        }
                                        IconButton(onClick={updateBatchEdit(key){it.copy(expanded=!it.expanded)}}){Icon(if(edit.expanded)Icons.Default.ExpandLess else Icons.Default.ExpandMore,"Expandir")}
                                    }
                                    AnimatedVisibility(edit.expanded){
                                        Column(verticalArrangement=Arrangement.spacedBy(7.dp)){
                                            OutlinedTextField(edit.title,{v->updateBatchEdit(key){it.copy(title=v.take(180),dirty=true)}},label={Text("Título")},singleLine=true,modifier=Modifier.fillMaxWidth())
                                            Row(verticalAlignment=Alignment.CenterVertically){
                                                Text("Usar título como nome do arquivo",Modifier.weight(1f),style=MaterialTheme.typography.bodySmall)
                                                Switch(edit.useTitleAsFilename,{v->updateBatchEdit(key){it.copy(useTitleAsFilename=v,dirty=true)}})
                                            }
                                            OutlinedTextField(edit.outputName,{v->updateBatchEdit(key){it.copy(outputName=v.take(180),dirty=true)}},label={Text("Nome do arquivo de saída")},singleLine=true,enabled=!edit.useTitleAsFilename,modifier=Modifier.fillMaxWidth())
                                            Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){
                                                OutlinedTextField(edit.artist,{v->updateBatchEdit(key){it.copy(artist=v.take(160),dirty=true)}},label={Text("Artista")},singleLine=true,modifier=Modifier.weight(1f))
                                                OutlinedTextField(edit.album,{v->updateBatchEdit(key){it.copy(album=v.take(160),dirty=true)}},label={Text("Álbum")},singleLine=true,modifier=Modifier.weight(1f))
                                            }
                                            Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){
                                                OutlinedTextField(edit.genre,{v->updateBatchEdit(key){it.copy(genre=v.take(80),dirty=true)}},label={Text("Gênero")},singleLine=true,modifier=Modifier.weight(1f))
                                                OutlinedTextField(edit.year,{v->updateBatchEdit(key){it.copy(year=v.filter(Char::isDigit).take(4),dirty=true)}},label={Text("Ano")},singleLine=true,modifier=Modifier.weight(1f))
                                                OutlinedTextField(edit.track,{v->updateBatchEdit(key){it.copy(track=v.take(12),dirty=true)}},label={Text("Faixa")},singleLine=true,modifier=Modifier.weight(1f))
                                            }
                                            OutlinedTextField(edit.composer,{v->updateBatchEdit(key){it.copy(composer=v.take(160),dirty=true)}},label={Text("Compositor")},singleLine=true,modifier=Modifier.fillMaxWidth())
                                            OutlinedTextField(edit.author,{v->updateBatchEdit(key){it.copy(author=v.take(160),dirty=true)}},label={Text("Autor")},singleLine=true,modifier=Modifier.fillMaxWidth())
                                            Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){
                                                OutlinedTextField(edit.bpm,{v->updateBatchEdit(key){it.copy(bpm=v.filter{c->c.isDigit()||c=='.'}.take(8),dirty=true)}},label={Text("BPM")},singleLine=true,modifier=Modifier.weight(1f))
                                                OutlinedTextField(edit.isrc,{v->updateBatchEdit(key){it.copy(isrc=v.take(24),dirty=true)}},label={Text("ISRC")},singleLine=true,modifier=Modifier.weight(1f))
                                            }
                                            OutlinedTextField(edit.copyright,{v->updateBatchEdit(key){it.copy(copyright=v.take(220),dirty=true)}},label={Text("Copyright")},singleLine=true,modifier=Modifier.fillMaxWidth())
                                            OutlinedTextField(edit.comment,{v->updateBatchEdit(key){it.copy(comment=v.take(500),dirty=true)}},label={Text("Comentário")},modifier=Modifier.fillMaxWidth())
                                            OutlinedTextField(edit.lyrics,{v->updateBatchEdit(key){it.copy(lyrics=v,dirty=true)}},label={Text("Letra / LRC")},minLines=3,maxLines=7,modifier=Modifier.fillMaxWidth())
                                            Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){
                                                OutlinedButton(onClick={artworkTargetKey=key;artworkPicker.launch(arrayOf("image/*"))},modifier=Modifier.weight(1f)){Icon(Icons.Default.AddPhotoAlternate,null);Spacer(Modifier.width(4.dp));Text(if(edit.artworkUri==null)"Capa" else "Trocar capa")}
                                                OutlinedButton(onClick={lyricsTargetKey=key;lyricsPicker.launch(SonusLyricsImporter.pickerMimeTypes())},modifier=Modifier.weight(1f)){Icon(Icons.Default.Description,null);Spacer(Modifier.width(4.dp));Text("TXT/LRC")}
                                            }
                                            edit.artworkUri?.let { uri -> BatchArtworkPreview(uri) }
                                            if(edit.artworkUri!=null)TextButton(onClick={updateBatchEdit(key){it.copy(artworkUri=null,dirty=true)}},modifier=Modifier.fillMaxWidth()){Text("Remover capa desta faixa")}
                                            Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){
                                                OutlinedButton(onClick={
                                                    val clean=cleanAudioLabel(edit.title)
                                                    updateBatchEdit(key){it.copy(title=clean,outputName=if(it.useTitleAsFilename)clean else it.outputName,dirty=true)}
                                                },modifier=Modifier.weight(1f)){Text("Limpar título")}
                                                OutlinedButton(onClick={
                                                    updateBatchEdit(key){it.copy(outputName=cleanAudioLabel(it.outputName),dirty=true)}
                                                },modifier=Modifier.weight(1f)){Text("Limpar nome")}
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        Text("MP3, M4A e FLAC recebem capa incorporada quando suportado. Outros formatos continuam sendo convertidos normalmente.",style=MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }

        item {
            ProSection("6. Destino e conversão", Icons.Default.FolderCopy) {
                Text("Música/SONUS/Audio", style=MaterialTheme.typography.labelSmall, color=MaterialTheme.colorScheme.primary)
                if (duplicateOutputNames.isNotEmpty()) {
                    Text(
                        "Existem nomes de saída duplicados. Edite os títulos/nomes antes de converter para evitar sobrescrita.",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold
                    )
                }
                Button(onClick={
                    scope.launch {
                        busy=true;message=null;status=emptyMap();globalProgress=0f;stopPreview()
                        SonusProcessNotifier.publish(context,"Conversor SONUS",0)
                        var success=0;var fail=0
                        for ((index,item) in files.withIndex()) {
                            status=status+(item.uri.toString() to "Processando…")
                            val edit = batchEdits[item.uri.toString()]
                            val title = edit?.title?.trim().orEmpty().ifBlank { item.info.displayName.substringBeforeLast('.').take(160) }
                            val outputBase = if (edit?.useTitleAsFilename != false) title else edit.outputName.trim().ifBlank { title }
                            val outName=sanitizeName("${outputBase}.${AudioConversionEngine.outputExtension(preset.format)}")
                            val outUri=withContext(Dispatchers.IO){SonusStorage.createAudio(context,outName,AudioConversionEngine.outputMime(preset.format),SonusStorage.Bucket.AUDIO)}
                            if(outUri==null){fail++;status=status+(item.uri.toString() to "Falha ao criar saída SONUS");continue}
                            val result=withContext(Dispatchers.IO){
                                val original = if(preserveSourceTags) runCatching { AudioToolEngine.readMetadata(context,item.uri) }.getOrDefault(com.sonusstudios.streampulse.tools.AudioMetadata()) else com.sonusstudios.streampulse.tools.AudioMetadata()
                                fun choose(newValue:String, oldValue:String)=if(newValue.isNotBlank())newValue else if(preserveSourceTags)oldValue else ""
                                val tags=AudioTrackTags(
                                    title=title,
                                    artist=choose(edit?.artist.orEmpty(),original.artist),
                                    album=choose(edit?.album.orEmpty(),original.album),
                                    genre=choose(edit?.genre.orEmpty(),original.genre),
                                    composer=choose(edit?.composer.orEmpty(),original.composer),
                                    year=choose(edit?.year.orEmpty(),original.year),
                                    albumArtist=choose(edit?.albumArtist.orEmpty(),original.albumArtist),
                                    author=choose(edit?.author.orEmpty(),original.author),
                                    copyright=choose(edit?.copyright.orEmpty(),original.copyright),
                                    comment=choose(edit?.comment.orEmpty(),original.comment),
                                    lyrics=choose(edit?.lyrics.orEmpty(),original.lyrics),
                                    bpm=choose(edit?.bpm.orEmpty(),original.bpm),
                                    isrc=choose(edit?.isrc.orEmpty(),original.isrc),
                                    track=choose(edit?.track.orEmpty(),original.track),
                                    disc=original.disc
                                )
                                AudioConversionEngine.convert(context,item.uri,outUri,preset,tags,{p->scope.launch{globalProgress=(index + p.coerceIn(0f,1f))/files.size.toFloat();SonusProcessNotifier.publish(context,"Conversor SONUS",(globalProgress*100).roundToInt(),"Faixa ${index+1} de ${files.size}")}},processing,edit?.artworkUri ?: artworkUri)
                            }
                            if(result.success){
                                withContext(Dispatchers.IO){ SonusStorage.finish(context,outUri) }
                                SonusNotificationCenter.recordPremiumUse(context, "Conversor de Áudio Pro")
                                success++;status=status+(item.uri.toString() to "✓ Concluído • SONUS/Audio")
                            } else {
                                withContext(Dispatchers.IO){ SonusStorage.abort(context,outUri) }
                                fail++;status=status+(item.uri.toString() to "Falha: ${result.message.take(180)}")
                            }
                            globalProgress=(index+1f)/files.size.toFloat()
                            SonusProcessNotifier.publish(context,"Conversor SONUS",(globalProgress*100).roundToInt())
                        }
                        busy=false;SonusProcessNotifier.clear(context,"Conversor SONUS")
                        message = when {
                            success == 0 -> "Lote finalizado: nenhuma conversão concluída • $fail falha(s). Originais preservados."
                            fail > 0 -> "Lote finalizado: $success concluído(s) • $fail falha(s). Originais preservados."
                            else -> "Lote finalizado: $success concluído(s) com sucesso. As moedas só ampliam a capacidade do lote."
                        }
                        SonusNotificationCenter.add(
                            context,
                            if (success > 0) "Conversão concluída" else "Conversão não concluída",
                            if (success > 0) "$success arquivo(s) convertido(s) • $fail falha(s)." else "O lote terminou sem arquivos convertidos.",
                            "FERRAMENTAS",
                            importantExternal = false
                        )
                        onTrack("Conversor: lote $success/${files.size} concluído", fail == 0, null)
                        
                    }
                },enabled=canConvert,modifier=Modifier.fillMaxWidth().height(50.dp),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF1E9E55),contentColor=Color.White)) { Icon(Icons.Default.Transform,null);Spacer(Modifier.width(7.dp));Text(if(busy)"Convertendo…" else "Converter ${files.size} música(s)") }
            }
        }

        message?.let { text -> item { ConverterResultCard(text) } }
        item { Text("🔒 Processamento local. O SONUS cria novas cópias e nunca sobrescreve seus arquivos originais.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.55f),modifier=Modifier.fillMaxWidth()) }
    }
}

@Composable
private fun ProSection(title:String,icon:androidx.compose.ui.graphics.vector.ImageVector,content:@Composable ColumnScope.()->Unit){
    Card(colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.48f)),border=BorderStroke(1.dp,MaterialTheme.colorScheme.outline.copy(alpha=.15f))){Column(Modifier.padding(15.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){Row(verticalAlignment=Alignment.CenterVertically){Surface(shape=RoundedCornerShape(12.dp),color=MaterialTheme.colorScheme.primary.copy(alpha=.14f)){Icon(icon,null,modifier=Modifier.padding(8.dp),tint=MaterialTheme.colorScheme.primary)};Spacer(Modifier.width(9.dp));Text(title,fontWeight=FontWeight.ExtraBold,fontSize=17.sp)};content()}}
}

@Composable private fun ProGradientCard(colors:List<Color>,content:@Composable ColumnScope.()->Unit){Card(colors=CardDefaults.cardColors(containerColor=Color.Transparent)){Column(Modifier.fillMaxWidth().background(Brush.linearGradient(colors)).padding(16.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){content()}}}

@Composable
private fun CompactChoice(label:String,value:String,options:List<String>,modifier:Modifier=Modifier,onSelect:(String)->Unit){
    var expanded by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(onClick={expanded=true},modifier=Modifier.fillMaxWidth(),contentPadding=PaddingValues(horizontal=10.dp,vertical=7.dp)) {
            Column(Modifier.weight(1f),horizontalAlignment=Alignment.Start) {
                Text(label,style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.58f))
                Text(value,fontWeight=FontWeight.ExtraBold,maxLines=1,overflow=TextOverflow.Ellipsis)
            }
            Icon(Icons.Default.ArrowDropDown,null,modifier=Modifier.size(18.dp))
        }
        DropdownMenu(expanded,onDismissRequest={expanded=false}) {
            options.distinct().forEach { o ->
                DropdownMenuItem(text={Text(o)},onClick={expanded=false;onSelect(o)},leadingIcon={if(o==value) Icon(Icons.Default.Check,null)})
            }
        }
    }
}

@Composable
private fun ChoiceRow(label:String,value:String,options:List<String>,onSelect:(String)->Unit) =
    CompactChoice(label,value,options,Modifier.fillMaxWidth(),onSelect)

@Composable private fun EqSlider(label:String,value:Double,onChange:(Double)->Unit){Column{Row{Text(label,fontWeight=FontWeight.SemiBold,modifier=Modifier.weight(1f));Text(String.format(Locale.US,"%+.1f dB",value),fontWeight=FontWeight.Bold)};Slider(value.toFloat(),{onChange(it.toDouble())},valueRange=-6f..6f)}}

@Composable
private fun EqCurve(values:List<Double>, c:Color=MaterialTheme.colorScheme.primary){Canvas(Modifier.fillMaxWidth().height(64.dp)){if(values.size<2)return@Canvas;val min=-12f;val max=6f;val step=size.width/(values.size-1).toFloat();fun y(v:Double):Float{val n=((v.toFloat()-min)/(max-min)).coerceIn(0f,1f);return size.height*(1f-n)};drawLine(Color.Gray.copy(alpha=.3f),Offset(0f,y(0.0)),Offset(size.width,y(0.0)),1.dp.toPx());for(i in 0 until values.lastIndex){drawLine(c,Offset(i*step,y(values[i])),Offset((i+1)*step,y(values[i+1])),3.dp.toPx(),StrokeCap.Round)}}}



private fun eqPresetColor(name: String): Color = when (name) {
    "Rock" -> Color(0xFFEF5350)
    "Pop" -> Color(0xFFAB47BC)
    "Hip-Hop" -> Color(0xFFFFA726)
    "Jazz" -> Color(0xFF42A5F5)
    "Classical" -> Color(0xFF66BB6A)
    else -> Color(0xFF5C6BC0)
}

private fun listAudioDocuments(context: Context, tree: Uri): List<Uri> = runCatching {
    val resolver = context.contentResolver
    val parentId = DocumentsContract.getTreeDocumentId(tree)
    val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId)
    val out = mutableListOf<Uri>()
    resolver.query(children, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_MIME_TYPE), null, null, null)?.use { c ->
        val idCol = c.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
        val mimeCol = c.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)
        while (c.moveToNext()) {
            val id = if (idCol >= 0) c.getString(idCol) else null
            val mime = if (mimeCol >= 0) c.getString(mimeCol) else null
            if (id != null && mime != DocumentsContract.Document.MIME_TYPE_DIR && (mime?.startsWith("audio/") == true || mime == "application/octet-stream")) {
                out += DocumentsContract.buildDocumentUriUsingTree(tree, id)
            }
        }
    }
    out
}.getOrDefault(emptyList())

private fun sanitizeName(name:String)=name.replace(Regex("[\\\\/:*?\"<>|]+"),"_").take(180)

@Composable
private fun ConverterResultCard(message: String) {
    val normalized = message.lowercase(Locale.getDefault())
    val hasNonZeroFailureCount = Regex("""\b([1-9]\d*)\s+falha""").containsMatchIn(normalized)
    val failed = hasNonZeroFailureCount || normalized.contains("falha:") || normalized.contains("não conclu") || normalized.contains("erro")
    val success = !failed && (normalized.contains("conclu") || normalized.contains("salvo") || normalized.contains("finalizado") || normalized.contains("sucesso"))
    val bg = when { failed -> Color(0xFF4A1218); success -> Color(0xFF123D27); else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.72f) }
    val accent = when { failed -> Color(0xFFFF6675); success -> Color(0xFF59D98E); else -> MaterialTheme.colorScheme.primary }
    Surface(shape=RoundedCornerShape(16.dp), color=bg, border=BorderStroke(1.dp, accent.copy(alpha=.45f))) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment=Alignment.Top) {
            Icon(if(failed) Icons.Default.ErrorOutline else if(success) Icons.Default.CheckCircle else Icons.Default.Info, null, tint=accent)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f), verticalArrangement=Arrangement.spacedBy(4.dp)) {
                Text(if(failed) "Falha no processamento" else if(success) "Processo concluído" else "Informação", fontWeight=FontWeight.Black, color=Color.White)
                message.split(" • ").filter { it.isNotBlank() }.forEach { line -> Text(line.trim(), style=MaterialTheme.typography.bodySmall, color=Color.White.copy(alpha=.86f)) }
            }
        }
    }
}
private fun sampleLabel(hz:Int)=if(hz%1000==0)"${hz/1000} kHz" else String.format(Locale.US,"%.1f kHz",hz/1000.0)
private fun formatDuration(ms:Long):String{val s=(ms/1000).coerceAtLeast(0);return "%02d:%02d".format(s/60,s%60)}
private fun formatBytes(bytes:Long):String=when{bytes>=1024L*1024*1024->String.format(Locale.US,"%.2f GB",bytes/(1024.0*1024*1024));bytes>=1024L*1024->String.format(Locale.US,"%.1f MB",bytes/(1024.0*1024));bytes>=1024->String.format(Locale.US,"%.0f KB",bytes/1024.0);else->"$bytes B"}


private fun loadLocalConverterPreset(context:Context,artist:Artist,hasDistributionProfile:Boolean):AudioConversionPreset{
    val base=artist.audioPreset ?: AudioConversionPreset(useDistributorRecommended=false)
    val p=context.getSharedPreferences("converter_pro_v192",Context.MODE_PRIVATE);val k=artist.id
    return base.copy(
        format=p.getString("$k.format",base.format)?:base.format,
        sampleRateHz=p.getInt("$k.sr",base.sampleRateHz),bitDepth=p.getInt("$k.depth",base.bitDepth),bitrateKbps=p.getInt("$k.br",base.bitrateKbps),channels=p.getInt("$k.ch",base.channels),
        eqPresetName=p.getString("$k.eq",base.eqPresetName)?:base.eqPresetName,
        eqBassDb=java.lang.Double.longBitsToDouble(p.getLong("$k.bass",java.lang.Double.doubleToLongBits(base.eqBassDb))),
        eqMidDb=java.lang.Double.longBitsToDouble(p.getLong("$k.mid",java.lang.Double.doubleToLongBits(base.eqMidDb))),
        eqTrebleDb=java.lang.Double.longBitsToDouble(p.getLong("$k.treble",java.lang.Double.doubleToLongBits(base.eqTrebleDb))),
        eqAdvancedOffsetsDb=(p.getString("$k.adv",null)?.split(',')?.mapNotNull{it.toDoubleOrNull()}?.takeIf{it.size==10}?:base.eqAdvancedOffsetsDb),
        pulseLiftEnabled=p.getBoolean("$k.pl",base.pulseLiftEnabled),pulseLiftIntensity=p.getInt("$k.pli",base.pulseLiftIntensity),
        pulseOrbitMode=p.getString("$k.po.mode", p.getString("$k.po", base.pulseOrbitMode))?:base.pulseOrbitMode,
        pulseOrbitPreset=p.getString("$k.po.preset",base.pulseOrbitPreset)?:base.pulseOrbitPreset,
        pulseOrbitIntensity=p.getInt("$k.po.intensity", p.getInt("$k.poi",base.pulseOrbitIntensity)),
        useDistributorRecommended=p.getBoolean("$k.rec",base.useDistributorRecommended),
        album=p.getString("$k.album",base.album)?:base.album,
        genre=p.getString("$k.genre",base.genre)?:base.genre,
        composer=p.getString("$k.composer",base.composer)?:base.composer
    )
}
private fun saveLocalConverterPreset(context:Context,id:String,p:AudioConversionPreset){context.getSharedPreferences("converter_pro_v192",Context.MODE_PRIVATE).edit().putString("$id.format",p.format).putInt("$id.sr",p.sampleRateHz).putInt("$id.depth",p.bitDepth).putInt("$id.br",p.bitrateKbps).putInt("$id.ch",p.channels).putString("$id.eq",p.eqPresetName).putLong("$id.bass",java.lang.Double.doubleToRawLongBits(p.eqBassDb)).putLong("$id.mid",java.lang.Double.doubleToRawLongBits(p.eqMidDb)).putLong("$id.treble",java.lang.Double.doubleToRawLongBits(p.eqTrebleDb)).putString("$id.adv",p.eqAdvancedOffsetsDb.joinToString(",")).putBoolean("$id.pl",p.pulseLiftEnabled).putInt("$id.pli",p.pulseLiftIntensity).putString("$id.po.mode",p.pulseOrbitMode).putString("$id.po.preset",p.pulseOrbitPreset).putInt("$id.po.intensity",p.pulseOrbitIntensity).putBoolean("$id.rec",p.useDistributorRecommended).putString("$id.album",p.album).putString("$id.genre",p.genre).putString("$id.composer",p.composer).apply()}

private val converterPresetJson = Json { ignoreUnknownKeys = true }
private fun loadNamedConverterPresets(context: Context, artistId: String): List<Pair<String, AudioConversionPreset>> {
    val prefs=context.getSharedPreferences("converter_pro_named_v192",Context.MODE_PRIVATE)
    val prefix="$artistId::"
    return prefs.all.entries.mapNotNull { (key,value) ->
        if(!key.startsWith(prefix) || value !is String) null else runCatching {
            key.removePrefix(prefix) to converterPresetJson.decodeFromString(AudioConversionPreset.serializer(),value)
        }.getOrNull()
    }.sortedBy { it.first.lowercase(Locale.getDefault()) }
}
private fun saveNamedConverterPreset(context: Context, artistId: String, name: String, preset: AudioConversionPreset) {
    val key="$artistId::${name.replace("::","-").take(32)}"
    val value=converterPresetJson.encodeToString(AudioConversionPreset.serializer(),preset)
    context.getSharedPreferences("converter_pro_named_v192",Context.MODE_PRIVATE).edit().putString(key,value).apply()
}

@Composable
private fun BatchArtworkPreview(uri: Uri) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val preview by produceState<androidx.compose.ui.graphics.ImageBitmap?>(initialValue = null, uri) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                context.contentResolver.openInputStream(uri)?.use { input ->
                    android.graphics.BitmapFactory.decodeStream(input)?.asImageBitmap()
                }
            }.getOrNull()
        }
    }
    preview?.let { bitmap ->
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Image(bitmap = bitmap, contentDescription = "Capa da faixa", contentScale = ContentScale.Crop, modifier = Modifier.size(64.dp).clip(RoundedCornerShape(10.dp)))
            Text("Capa individual", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
        }
    }
}
