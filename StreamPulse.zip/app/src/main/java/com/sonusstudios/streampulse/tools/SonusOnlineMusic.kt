package com.sonusstudios.streampulse.tools

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.media.MediaDataSource
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.animation.core.*
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.media3.common.MediaItem
import androidx.media3.common.AudioAttributes as Media3AudioAttributes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.Transaction
import com.google.firebase.database.MutableData
import com.sonusstudios.streampulse.BuildConfig
import com.sonusstudios.streampulse.R
import com.sonusstudios.streampulse.auth.AuthUser
import com.sonusstudios.streampulse.core.SonusMediaStandards
import com.sonusstudios.streampulse.core.SonusMediaPreferences
import com.sonusstudios.streampulse.core.SonusLyricsImporter
import com.sonusstudios.streampulse.core.MembershipTier
import com.sonusstudios.streampulse.core.commercialTier
import com.sonusstudios.streampulse.audio.LocalSpectrumAnalyzer
import com.sonusstudios.streampulse.cloud.CloudAccountManager
import com.sonusstudios.streampulse.stream.SonusStreamPlatformRepository
import com.sonusstudios.streampulse.integration.SonusEditBridge
import com.sonusstudios.streampulse.stream.StreamTimelineEntry
import com.sonusstudios.streampulse.stream.StreamCatalogCandidate
import com.sonusstudios.streampulse.video.PulseCompositionExporter
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.Job
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.text.Normalizer
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.random.Random
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.suspendCancellableCoroutine

internal data class SonusOnlineGenre(
    val name: String,
    val path: String,
    val folderId: Long = 0L
)

internal data class SonusOnlineTrack(
    val path: String,
    val fileName: String,
    val size: Long,
    val fileId: Long = 0L,
    val title: String = "",
    val artist: String = "",
    val album: String = "",
    val genre: String = "",
    val durationMs: Long = 0L,
    val createdAt: Long = 0L,
    val hasThumb: Boolean = false,
    val coverFile: String? = null,
    val year: String = "",
    val trackNumber: String = "",
    val lyrics: String = "",
    val lyricsFormat: String = "TEXT",
    val adminCoverBase64: String? = null
) {
    val displayTitle: String get() = cleanStreamDisplayTitle(title, fileName, artist)
    val displayArtist: String get() = canonicalStreamArtist(artist)
}

private data class PendingStreamPlayback(
    val tracks: List<SonusOnlineTrack>,
    val clicked: SonusOnlineTrack,
    val source: String,
    val genreContinuation: Boolean,
    val openFullPlayerAfterStart: Boolean = false
)

private fun canonicalStreamArtist(raw: String): String =
    raw.trim().replace(Regex("\\s+"), " ").uppercase(Locale.ROOT)

/** Limpeza somente visual: nunca renomeia o arquivo nem altera a URL do Stream. */
private fun cleanStreamDisplayTitle(metadataTitle: String, fileName: String, artist: String): String =
    SonusMediaStandards.cleanDisplayTitle(metadataTitle, fileName, artist)

internal data class SonusResolvedStream(
    val url: String,
    val headers: Map<String, String> = emptyMap(),
    val source: String = "pCloud"
)

internal data class SonusArtistAliasSnapshot(
    val names: Map<Long, String> = emptyMap(),
    val artistIds: Map<Long, String> = emptyMap(),
    val cachedAt: Long = 0L
)

internal data class SonusStreamInitialSnapshot(
    val genres: List<SonusOnlineGenre> = emptyList(),
    val trackMap: Map<SonusOnlineGenre, List<SonusOnlineTrack>> = emptyMap(),
    val publishedGenres: Set<String> = emptySet(),
    val artistAliases: SonusArtistAliasSnapshot = SonusArtistAliasSnapshot()
)

private data class SonusPlaybackDescriptorEntry(
    val stream: SonusResolvedStream,
    val resolvedAt: Long
)

/**
 * Cache curto somente para acelerar o primeiro áudio. URLs temporárias do pCloud
 * nunca ficam presas por toda a sessão: expiram rapidamente e são invalidadas em erro.
 */
private object SonusPlaybackDescriptorCache {
    private const val TTL_MS = 90_000L
    private val cache = java.util.concurrent.ConcurrentHashMap<Long, SonusPlaybackDescriptorEntry>()

    fun get(fileId: Long, now: Long = System.currentTimeMillis()): SonusResolvedStream? {
        val entry = cache[fileId] ?: return null
        if (now - entry.resolvedAt > TTL_MS) {
            cache.remove(fileId, entry)
            return null
        }
        return entry.stream
    }

    fun put(fileId: Long, stream: SonusResolvedStream) {
        if (fileId > 0L) cache[fileId] = SonusPlaybackDescriptorEntry(stream, System.currentTimeMillis())
    }

    fun invalidate(fileId: Long) { cache.remove(fileId) }
}

internal data class SonusShareGalleryImage(
    val fileId: Long,
    val name: String,
    val size: Long = 0L,
    val sourceCode: String = ""
)

/** 0.0.1: arquivo de uma pasta pública do pCloud (galeria do Studio, locuções da rádio). */
internal data class SonusPublicNode(
    val fileId: Long,
    val name: String,
    val size: Long = 0L,
    val contentType: String = ""
)

internal data class SonusPublicLrcFile(
    val fileId: Long,
    val name: String,
    val size: Long = 0L,
    val modifiedAt: Long = 0L
) {
    val titleStem: String get() = name.substringBeforeLast('.', name).trim()
}

internal data class SonusPublicLrcEntry(
    val file: SonusPublicLrcFile,
    val title: String,
    val artist: String = ""
)

internal enum class SonusUnifiedLrcSource { PCLOUD, COMMUNITY, CATALOG }

/**
 * code127: biblioteca OWNER unificada. Uma entrada representa uma única letra
 * sincronizada, independentemente de ela vir da pasta pública LRC ou do catálogo
 * já administrado pelo SONUS. A UI nunca recebe duas fontes para a mesma faixa.
 */
internal data class SonusUnifiedLrcEntry(
    val key: String,
    val title: String,
    val artist: String = "",
    val trackFileId: Long? = null,
    val publicFile: SonusPublicLrcFile? = null,
    val source: SonusUnifiedLrcSource = SonusUnifiedLrcSource.CATALOG,
    val contributorName: String = "",
    val communityStatus: String = ""
)

internal data class SonusShareSource(
    val key: String,
    val title: String,
    val artist: String = "",
    val album: String = "",
    val genre: String = "",
    val durationMs: Long = 0L,
    val audioUri: String = "",
    val lrcText: String = "",
    val streamTrack: SonusOnlineTrack? = null
) {
    val isStream: Boolean get() = streamTrack != null
    val displayArtist: String get() = artist.ifBlank { if (isStream) "SONUS Stream" else "Artista desconhecido" }
    fun rankingTrack(): SonusOnlineTrack = streamTrack ?: SonusOnlineTrack(
        path = "", fileName = title, size = 0L, fileId = key.hashCode().toLong().let { if (it == 0L) -1L else -kotlin.math.abs(it) },
        title = title, artist = artist, album = album, genre = genre, durationMs = durationMs, lyrics = lrcText, lyricsFormat = if (lrcText.contains(Regex("\\[\\d{1,3}:\\d{2}"))) "LRC" else "TEXT"
    )
}

internal fun SonusOnlineTrack.toShareSource(): SonusShareSource = SonusShareSource(
    key = "stream:$fileId",
    title = displayTitle,
    artist = artist,
    album = album,
    genre = genre,
    durationMs = durationMs,
    streamTrack = this
)

internal data class SonusOnlineRef(
    val fileId: Long,
    val size: Long,
    val sourceKey: String = "primary",
    val title: String = "",
    val artist: String = ""
) {
    fun toUriString(title: String = this.title, artist: String = this.artist): String {
        fun enc(value: String) = URLEncoder.encode(value, "UTF-8")
        return "sonusonline://pcloud?fileid=$fileId&size=$size&source=${enc(sourceKey)}&title=${enc(title)}&artist=${enc(artist)}"
    }

    companion object {
        fun parse(raw: String?): SonusOnlineRef? {
            if (raw.isNullOrBlank() || !raw.startsWith("sonusonline://", ignoreCase = true)) return null
            val uri = runCatching { Uri.parse(raw) }.getOrNull() ?: return null
            val fileId = uri.getQueryParameter("fileid")?.toLongOrNull() ?: return null
            val size = uri.getQueryParameter("size")?.toLongOrNull() ?: return null
            if (fileId <= 0L || size <= 0L) return null
            val source = uri.getQueryParameter("source")?.lowercase(Locale.ROOT)?.takeIf { it in setOf("primary", "secondary", "tertiary") } ?: "primary"
            return SonusOnlineRef(fileId, size, source, uri.getQueryParameter("title").orEmpty(), uri.getQueryParameter("artist").orEmpty())
        }
    }
}

/** HTTPS reconhecido como link clicável por mensageiros; a página encaminha ao deep link do app. */
internal fun SonusOnlineRef.toHttpsShareUrl(title: String = this.title, artist: String = this.artist): String {
    val endpoint = BuildConfig.SONUS_SHARE_BASE.trim().removeSuffix("/")
    return Uri.parse(endpoint).buildUpon()
        .appendQueryParameter("fileid", fileId.toString())
        .appendQueryParameter("size", size.toString())
        .appendQueryParameter("source", sourceKey)
        .appendQueryParameter("title", title)
        .appendQueryParameter("artist", artist)
        .build().toString()
}

/**
 * Fonte pública oficial do SONUS Stream.
 *
 * O pCloud é usado somente como armazenamento. O app lê o link público com showpublink
 * e pede o link de áudio somente quando a faixa precisa ser tocada. Nenhuma credencial
 * de escrita, senha ou token do OWNER é incluído no APK.
 */
internal object SonusPCloudClient {
    private val apiBases = listOf("https://api.pcloud.com", "https://eapi.pcloud.com")
    private val primaryPublicCode: String get() = BuildConfig.SONUS_PCLOUD_PUBLIC_CODE
    private val secondaryPublicCode: String get() = BuildConfig.SONUS_PCLOUD_SECONDARY_PUBLIC_CODE
    private val tertiaryPublicCode: String get() = BuildConfig.SONUS_PCLOUD_TERTIARY_PUBLIC_CODE

    private fun codeForSource(sourceKey: String): String = when (sourceKey.lowercase(Locale.ROOT)) {
        "secondary" -> secondaryPublicCode
        "tertiary" -> tertiaryPublicCode
        else -> primaryPublicCode
    }

    private fun encode(value: String): String = URLEncoder.encode(value, "UTF-8")

    private fun requestJson(method: String, params: Map<String, String>): JSONObject {
        var lastError: Throwable? = null
        for (base in apiBases) {
            try {
                val query = params.entries.joinToString("&") { (k, v) -> "${encode(k)}=${encode(v)}" }
                val conn = (URL("$base/$method?$query").openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 8_000
                    readTimeout = 12_000
                    useCaches = false
                    setRequestProperty("Accept", "application/json")
                    setRequestProperty("Accept-Encoding", "identity")
                }
                val body = (if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream)
                    ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                val json = runCatching { JSONObject(body) }.getOrElse { throw IOException("Resposta pCloud inválida") }
                val result = json.optInt("result", -1)
                conn.disconnect()
                if (result == 0) return json
                throw IOException("pCloud erro $result: ${json.optString("error").ifBlank { "requisição recusada" }}")
            } catch (t: Throwable) {
                lastError = t
            }
        }
        throw IOException(lastError?.message ?: "Não foi possível acessar o catálogo pCloud", lastError)
    }

    private fun loadCatalogFromSource(code: String, sourceKey: String): Map<String, List<SonusOnlineTrack>> {
        if (code.isBlank()) return emptyMap()
        val json = requestJson("showpublink", mapOf("code" to code))
        val metadata = json.optJSONObject("metadata") ?: throw IOException("Pasta pública sem metadados")
        val rootContents = metadata.optJSONArray("contents") ?: JSONArray()

        // Cada link público tem um interruptor próprio no painel OWNER. Não agrupamos
        // por nome de subpasta, pois isso fazia MÚSICAS 3 desaparecer quando as pastas
        // internas tinham os mesmos nomes das outras fontes.
        val sourceFolderName = when (sourceKey.lowercase(Locale.ROOT)) {
            "secondary" -> "MÚSICAS 2"
            "tertiary" -> "MÚSICAS 3"
            else -> "MÚSICAS"
        }
        val tracks = collectMp3(rootContents, sourceFolderName, sourceKey)
            .distinctBy { it.fileId }
        return if (tracks.isEmpty()) emptyMap() else mapOf(sourceFolderName to tracks)
    }

    fun loadCatalog(): Map<SonusOnlineGenre, List<SonusOnlineTrack>> {
        if (primaryPublicCode.isBlank() && secondaryPublicCode.isBlank() && tertiaryPublicCode.isBlank()) throw IOException("Fontes públicas do SONUS Stream ausentes")
        val sources = listOf(
            "primary" to primaryPublicCode,
            "secondary" to secondaryPublicCode,
            "tertiary" to tertiaryPublicCode
        ).filter { it.second.isNotBlank() }
        val merged = linkedMapOf<String, Pair<String, MutableList<SonusOnlineTrack>>>()
        var lastError: Throwable? = null
        sources.forEach { (sourceKey, code) ->
            val result = runCatching { loadCatalogFromSource(code, sourceKey) }
            result.onFailure { lastError = it }
            result.getOrNull().orEmpty().forEach { (genreName, tracks) ->
                val key = normalizeStreamSearch(genreName).ifBlank { "sonus stream" }
                val bucket = merged.getOrPut(key) { genreName to mutableListOf() }
                bucket.second += tracks
            }
        }
        if (merged.isEmpty() && lastError != null) throw IOException(lastError?.message ?: "Não foi possível carregar o catálogo SONUS", lastError)
        val out = linkedMapOf<SonusOnlineGenre, List<SonusOnlineTrack>>()
        merged.values.sortedBy { it.first.lowercase(Locale.ROOT) }.forEach { (name, tracks) ->
            val genre = SonusOnlineGenre(name, "sonus-genre:${lrcSafeKey(name)}", 0L)
            // O ID de catálogo já é exclusivo por fonte. Não deduplicar por título/artista:
            // versões diferentes ou faixas homônimas não podem desaparecer do Stream.
            val deduped = tracks.distinctBy { it.fileId }
                .sortedBy { it.displayTitle.lowercase(Locale.getDefault()) }
            if (deduped.isNotEmpty()) out[genre] = deduped
        }
        return out
    }

    private fun lrcSafeKey(raw: String): String = normalizeStreamSearch(raw).replace(Regex("[^a-z0-9]+"), "-").trim('-').ifBlank { "stream" }

    private fun catalogFileId(sourceKey: String, rawFileId: Long): Long = when (sourceKey.lowercase(Locale.ROOT)) {
        "secondary" -> 0x4000000000000000L or (rawFileId and 0x3FFFFFFFFFFFFFFFL)
        "tertiary" -> 0x2000000000000000L or (rawFileId and 0x1FFFFFFFFFFFFFFFL)
        else -> rawFileId
    }

    private fun collectMp3(contents: JSONArray?, genreName: String, sourceKey: String): List<SonusOnlineTrack> {
        if (contents == null) return emptyList()
        val out = mutableListOf<SonusOnlineTrack>()
        for (i in 0 until contents.length()) {
            val node = contents.optJSONObject(i) ?: continue
            if (node.optBoolean("isfolder", false)) {
                val nestedGenre = node.optString("name").trim().ifBlank { genreName }
                out += collectMp3(node.optJSONArray("contents"), nestedGenre, sourceKey)
                continue
            }
            val name = node.optString("name").trim()
            val contentType = node.optString("contenttype")
            if (!name.endsWith(".mp3", true) && !contentType.contains("audio", true)) continue
            val fileId = node.optLong("fileid", 0L)
            val size = node.optLong("size", 0L)
            if (fileId <= 0L || size <= 0L) continue
            val durationRaw = node.optLong("duration", 0L)
            val durationMs = when {
                durationRaw <= 0L -> 0L
                durationRaw < 1_000_000L -> durationRaw * 1000L
                else -> durationRaw
            }
            out += SonusOnlineTrack(
                path = "pcloud-file:$sourceKey:$fileId",
                fileName = name,
                size = size,
                fileId = catalogFileId(sourceKey, fileId),
                title = node.optString("title"),
                artist = node.optString("artist"),
                album = node.optString("album"),
                genre = node.optString("genre").trim().takeIf {
                    SonusMediaStandards.canonicalGenre(it) in SonusMediaStandards.genres
                } ?: genreName,
                durationMs = durationMs,
                createdAt = parsePCloudDate(node.optString("created")).takeIf { it > 0L }
                    ?: parsePCloudDate(node.optString("modified")),
                hasThumb = node.optBoolean("thumb", false)
            )
        }
        return out
    }

    fun streamUrl(fileId: Long, sourceKey: String = "primary"): String {
        val json = requestJson(
            "getpubaudiolink",
            mapOf("code" to codeForSource(sourceKey), "fileid" to fileId.toString(), "contenttype" to "audio/mpeg", "abitrate" to "192")
        )
        return linkFromResponse(json)
    }


    fun directFileUrl(fileId: Long, sourceKey: String = "primary"): String {
        val json = requestJson(
            "getpublinkdownload",
            mapOf("code" to codeForSource(sourceKey), "fileid" to fileId.toString())
        )
        return linkFromResponse(json)
    }

    /** Prefere o arquivo original; o link de áudio transcodificado fica como fallback. */
    fun automaticStreamUrl(fileId: Long, sourceKey: String = "primary"): String = runCatching { directFileUrl(fileId, sourceKey) }
        .getOrElse { streamUrl(fileId, sourceKey) }

    fun listPublicImages(code: String): List<SonusShareGalleryImage> {
        if (code.isBlank()) return emptyList()
        val json = requestJson("showpublink", mapOf("code" to code))
        val metadata = json.optJSONObject("metadata") ?: return emptyList()
        val out = mutableListOf<SonusShareGalleryImage>()
        fun walk(contents: JSONArray?) {
            if (contents == null) return
            for (i in 0 until contents.length()) {
                val node = contents.optJSONObject(i) ?: continue
                if (node.optBoolean("isfolder", false)) {
                    walk(node.optJSONArray("contents"))
                } else {
                    val name = node.optString("name").trim()
                    val type = node.optString("contenttype")
                    val image = type.startsWith("image/", true) || name.endsWith(".jpg",true) || name.endsWith(".jpeg",true) || name.endsWith(".png",true) || name.endsWith(".webp",true)
                    val id = node.optLong("fileid", 0L)
                    if (image && id > 0L) out += SonusShareGalleryImage(id, name, node.optLong("size",0L), code)
                }
            }
        }
        walk(metadata.optJSONArray("contents"))
        return out.distinctBy { it.fileId }.take(1000)
    }

    /** Lista recursivamente todos os arquivos de um link público do pCloud. */
    fun listPublicNodes(code: String): List<SonusPublicNode> {
        if (code.isBlank()) return emptyList()
        val json = requestJson("showpublink", mapOf("code" to code))
        val metadata = json.optJSONObject("metadata") ?: return emptyList()
        val out = mutableListOf<SonusPublicNode>()
        fun walk(contents: JSONArray?) {
            if (contents == null) return
            for (i in 0 until contents.length()) {
                val node = contents.optJSONObject(i) ?: continue
                if (node.optBoolean("isfolder", false)) {
                    walk(node.optJSONArray("contents"))
                } else {
                    val id = node.optLong("fileid", 0L)
                    val name = node.optString("name").trim()
                    if (id > 0L && name.isNotBlank()) out += SonusPublicNode(id, name, node.optLong("size", 0L), node.optString("contenttype"))
                }
            }
        }
        walk(metadata.optJSONArray("contents"))
        return out.distinctBy { it.fileId }
    }

    fun listPublicLrc(code: String): List<SonusPublicLrcFile> {
        if (code.isBlank()) return emptyList()
        val json = requestJson("showpublink", mapOf("code" to code))
        val metadata = json.optJSONObject("metadata") ?: return emptyList()
        val out = mutableListOf<SonusPublicLrcFile>()
        fun walk(contents: JSONArray?) {
            if (contents == null) return
            for (i in 0 until contents.length()) {
                val node = contents.optJSONObject(i) ?: continue
                if (node.optBoolean("isfolder", false)) {
                    walk(node.optJSONArray("contents"))
                } else {
                    val name = node.optString("name").trim()
                    val type = node.optString("contenttype")
                    val isLrc = name.endsWith(".lrc", true) || type.contains("lrc", true)
                    val id = node.optLong("fileid", 0L)
                    if (isLrc && id > 0L) {
                        out += SonusPublicLrcFile(
                            fileId = id,
                            name = name,
                            size = node.optLong("size", 0L),
                            modifiedAt = parsePCloudDate(node.optString("modified"))
                                .takeIf { it > 0L } ?: parsePCloudDate(node.optString("created"))
                        )
                    }
                }
            }
        }
        walk(metadata.optJSONArray("contents"))
        return out.distinctBy { it.fileId }.sortedBy { it.name.lowercase(Locale.ROOT) }
    }

    fun publicTextFile(code: String, fileId: Long, maxChars: Int = 120_000): String {
        val url = publicFileUrl(code, fileId)
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 10_000
            readTimeout = 15_000
            instanceFollowRedirects = true
            useCaches = true
            setRequestProperty("Accept-Encoding", "identity")
        }
        return try {
            if (conn.responseCode !in 200..299) throw IOException("LRC pCloud ${conn.responseCode}")
            val expected = conn.contentLengthLong
            if (expected > 2_000_000L) throw IOException("LRC excede limite de segurança")
            conn.inputStream.bufferedReader(Charsets.UTF_8).use { reader ->
                val out = StringBuilder()
                val buffer = CharArray(4096)
                while (true) {
                    val n = reader.read(buffer)
                    if (n <= 0) break
                    val remaining = maxChars - out.length
                    if (remaining <= 0) break
                    out.append(buffer, 0, minOf(n, remaining))
                }
                out.toString().removePrefix("\uFEFF")
            }
        } finally {
            conn.disconnect()
        }
    }

    fun publicFileUrl(code: String, fileId: Long): String =
        linkFromResponse(requestJson("getpublinkdownload", mapOf("code" to code, "fileid" to fileId.toString())))

    fun publicThumbnailUrl(code: String, fileId: Long): String =
        linkFromResponse(requestJson("getpubthumblink", mapOf("code" to code, "fileid" to fileId.toString(), "size" to "512x512", "crop" to "1")))

    data class StreamProbe(
        val responseCode: Int,
        val contentType: String,
        val contentLength: Long,
        val acceptsRanges: Boolean,
        val firstByteMs: Long,
        val bytesRead: Int
    )

    fun probeUrl(url: String, maxBytes: Int = 32 * 1024, headers: Map<String,String> = emptyMap()): StreamProbe {
        val started = System.currentTimeMillis()
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            instanceFollowRedirects = true
            connectTimeout = 10_000
            readTimeout = 15_000
            useCaches = false
            setRequestProperty("Range", "bytes=0-${maxBytes - 1}")
            setRequestProperty("Accept-Encoding", "identity")
            setRequestProperty("User-Agent", "SONUS/${BuildConfig.VERSION_NAME}")
            headers.forEach { (name, value) -> setRequestProperty(name, value) }
        }
        val code = conn.responseCode
        val type = conn.contentType.orEmpty()
        val length = conn.getHeaderField("Content-Range").orEmpty().substringAfterLast('/', "").toLongOrNull()
            ?: conn.contentLengthLong.takeIf { it > 0L } ?: -1L
        val accepts = code == HttpURLConnection.HTTP_PARTIAL || conn.getHeaderField("Accept-Ranges").orEmpty().contains("bytes", true)
        val input = if (code in 200..299) conn.inputStream else conn.errorStream
        val buffer = ByteArray(maxBytes)
        var total = 0
        var first = -1L
        input?.use { stream ->
            while (total < buffer.size) {
                val read = stream.read(buffer, total, buffer.size - total)
                if (read <= 0) break
                if (first < 0L) first = System.currentTimeMillis() - started
                total += read
            }
        }
        conn.disconnect()
        if (code !in 200..299 || total <= 0) throw IOException("HTTP $code • nenhum byte de áudio recebido")
        return StreamProbe(code, type, length, accepts, if (first >= 0L) first else System.currentTimeMillis() - started, total)
    }

    fun thumbnailUrl(fileId: Long, sourceKey: String = "primary"): String {
        val json = requestJson(
            "getpubthumblink",
            mapOf("code" to codeForSource(sourceKey), "fileid" to fileId.toString(), "size" to "512x512", "crop" to "1")
        )
        return linkFromResponse(json)
    }

    private fun linkFromResponse(json: JSONObject): String {
        val hosts = json.optJSONArray("hosts") ?: throw IOException("pCloud não retornou servidor")
        val host = hosts.optString(0).trim()
        val path = json.optString("path").trim()
        if (host.isBlank() || path.isBlank()) throw IOException("Link de mídia pCloud incompleto")
        val base = when {
            host.startsWith("http://") || host.startsWith("https://") -> host
            else -> "https://$host"
        }
        return base.removeSuffix("/") + "/" + path.removePrefix("/")
    }

    fun streamSize(resolvedUrl: String, fallback: Long): Long {
        val conn = (URL(resolvedUrl).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 9_000
            readTimeout = 12_000
            useCaches = false
            setRequestProperty("Range", "bytes=0-0")
            setRequestProperty("Accept-Encoding", "identity")
        }
        return try {
            val code = conn.responseCode
            val contentRange = conn.getHeaderField("Content-Range").orEmpty()
            val total = contentRange.substringAfterLast('/', "").toLongOrNull()
            if (code == HttpURLConnection.HTTP_PARTIAL && total != null && total > 0L) total
            else conn.contentLengthLong.takeIf { it > 0L } ?: fallback
        } finally {
            runCatching { conn.inputStream?.close() }
            runCatching { conn.errorStream?.close() }
            conn.disconnect()
        }
    }

    fun readRange(start: Long, length: Int, resolvedUrl: String): ByteArray {
        if (length <= 0) return ByteArray(0)
        val end = start + length - 1L
        val conn = (URL(resolvedUrl).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 9_000
            readTimeout = 15_000
            useCaches = false
            setRequestProperty("Range", "bytes=$start-$end")
            setRequestProperty("Accept-Encoding", "identity")
        }
        val code = conn.responseCode
        if (code != HttpURLConnection.HTTP_PARTIAL) {
            conn.disconnect()
            throw IOException("Streaming pCloud não confirmou leitura parcial ($code)")
        }
        return conn.inputStream.use { input ->
            val buffer = ByteArray(length)
            var total = 0
            while (total < length) {
                val read = input.read(buffer, total, length - total)
                if (read <= 0) break
                total += read
            }
            if (total == buffer.size) buffer else buffer.copyOf(total)
        }.also { conn.disconnect() }
    }

    fun downloadThumbnail(fileId: Long, sourceKey: String = "primary", maxBytes: Int = 1_500_000): ByteArray {
        val conn = (URL(thumbnailUrl(fileId, sourceKey)).openConnection() as HttpURLConnection).apply {
            connectTimeout = 8_000
            readTimeout = 10_000
            useCaches = true
        }
        if (conn.responseCode !in 200..299) {
            val code = conn.responseCode
            conn.disconnect()
            throw IOException("Capa pCloud $code")
        }
        val expected = conn.contentLengthLong
        if (expected > maxBytes) {
            conn.disconnect()
            throw IOException("Capa excede limite local")
        }
        return conn.inputStream.use { input ->
            val out = java.io.ByteArrayOutputStream()
            val buffer = ByteArray(16 * 1024)
            var total = 0
            while (true) {
                val read = input.read(buffer)
                if (read <= 0) break
                total += read
                if (total > maxBytes) throw IOException("Capa excede limite local")
                out.write(buffer, 0, read)
            }
            out.toByteArray()
        }.also { conn.disconnect() }
    }

    private fun parsePCloudDate(raw: String): Long = runCatching {
        ZonedDateTime.parse(raw, DateTimeFormatter.RFC_1123_DATE_TIME).toInstant().toEpochMilli()
    }.getOrDefault(0L)
}

/**
 * Leitura remota por blocos pequenos. Mantém uma única origem por faixa e reaproveita
 * somente poucos blocos em memória, evitando downloads integrais e consumo duplicado.
 */
internal class SonusPCloudMediaDataSource(
    private val ref: SonusOnlineRef,
    private val chunkSize: Int = 256 * 1024
) : MediaDataSource() {
    private data class Chunk(val start: Long, val data: ByteArray)
    private val chunks = object : LinkedHashMap<Long, Chunk>(4, .75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<Long, Chunk>?): Boolean = size > 3
    }
    @Volatile private var closed = false
    @Volatile private var resolvedUrl: String? = null
    @Volatile private var resolvedSize: Long = -1L

    private fun url(): String = resolvedUrl ?: synchronized(this) {
        resolvedUrl ?: SonusPCloudClient.automaticStreamUrl(ref.fileId, ref.sourceKey).also { resolvedUrl = it }
    }
    private fun refreshUrl(): String = synchronized(this) {
        resolvedUrl = SonusPCloudClient.automaticStreamUrl(ref.fileId, ref.sourceKey)
        resolvedUrl!!
    }

    private fun streamSize(): Long {
        val known = resolvedSize
        if (known > 0L) return known
        return synchronized(this) {
            if (resolvedSize <= 0L) resolvedSize = SonusPCloudClient.streamSize(url(), ref.size)
            resolvedSize
        }
    }

    override fun readAt(position: Long, buffer: ByteArray, offset: Int, size: Int): Int {
        if (closed) return -1
        val totalSize = streamSize()
        if (position < 0 || position >= totalSize) return -1
        if (size <= 0) return 0
        val blockStart = (position / chunkSize) * chunkSize
        val chunk = synchronized(chunks) { chunks[blockStart] } ?: run {
            val remaining = (totalSize - blockStart).coerceAtLeast(0L)
            val request = min(chunkSize.toLong(), remaining).toInt()
            if (request <= 0) return -1
            val loaded = runCatching { SonusPCloudClient.readRange(blockStart, request, url()) }.getOrElse {
                SonusPCloudClient.readRange(blockStart, request, refreshUrl())
            }
            val value = Chunk(blockStart, loaded)
            synchronized(chunks) { chunks[blockStart] = value }
            value
        }
        val inside = (position - chunk.start).toInt()
        if (inside !in 0 until chunk.data.size) return -1
        val count = min(size, chunk.data.size - inside)
        System.arraycopy(chunk.data, inside, buffer, offset, count)
        return count
    }

    override fun getSize(): Long = streamSize()

    override fun close() {
        closed = true
        synchronized(chunks) { chunks.clear() }
        resolvedUrl = null
        resolvedSize = -1L
    }
}

internal class SonusOnlineMusicRepository(private val context: Context) {
    companion object {
        // Build Fix 4: process-level snapshot. Recreating the Stream screen no longer
        // throws away already parsed catalog/artwork and the first frame can render
        // immediately while Firebase/pCloud revalidate in the background.
        @Volatile private var processGenresCache: List<SonusOnlineGenre>? = null
        @Volatile private var processOverridesCache: Map<Long, Map<String, String>>? = null
        @Volatile private var processArtistAliasSnapshot: SonusArtistAliasSnapshot? = null
        @Volatile private var processInitialStreamSnapshot: SonusStreamInitialSnapshot? = null
        @Volatile private var processLrcIndexCache: List<SonusPublicLrcFile>? = null
        private val processTracksCache = java.util.concurrent.ConcurrentHashMap<String, List<SonusOnlineTrack>>()
        private val processArtworkMemory = object : LinkedHashMap<Long, androidx.compose.ui.graphics.ImageBitmap>(64, 0.75f, true) {
            override fun removeEldestEntry(eldest: MutableMap.MutableEntry<Long, androidx.compose.ui.graphics.ImageBitmap>?): Boolean = size > 64
        }
    }
    private val prefs = context.getSharedPreferences("sonus_online_music_v2", Context.MODE_PRIVATE)
    private val coverDir = File(context.cacheDir, "sonus_music_covers").apply { mkdirs() }
    private val cloud = CloudAccountManager()
    private val syncScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val streamPlatform by lazy { SonusStreamPlatformRepository(context.applicationContext) }

    internal fun sourceKeyForTrack(track: SonusOnlineTrack): String = when {
        track.path.contains(":tertiary:") -> "tertiary"
        track.path.contains(":secondary:") -> "secondary"
        else -> "primary"
    }

    private fun sourceKeyForFileId(fileId: Long): String = allCachedTracks().firstOrNull { it.fileId == fileId }
        ?.let(::sourceKeyForTrack) ?: when {
            (fileId and 0x6000000000000000L) == 0x4000000000000000L -> "secondary"
            (fileId and 0x6000000000000000L) == 0x2000000000000000L -> "tertiary"
            else -> "primary"
        }

    private fun rawFileIdForTrack(track: SonusOnlineTrack): Long =
        track.path.substringAfterLast(':', "").toLongOrNull()?.takeIf { it > 0L } ?: track.fileId

    private fun rawFileIdForFileId(fileId: Long): Long = allCachedTracks().firstOrNull { it.fileId == fileId }
        ?.let(::rawFileIdForTrack) ?: when (sourceKeyForFileId(fileId)) {
            "secondary" -> fileId and 0x3FFFFFFFFFFFFFFFL
            "tertiary" -> fileId and 0x1FFFFFFFFFFFFFFFL
            else -> fileId
        }

    private fun rememberArtwork(fileId: Long, bitmap: androidx.compose.ui.graphics.ImageBitmap?): androidx.compose.ui.graphics.ImageBitmap? {
        if (bitmap != null && fileId > 0L) synchronized(processArtworkMemory) { processArtworkMemory[fileId] = bitmap }
        return bitmap
    }

    private fun inMemoryArtwork(fileId: Long): androidx.compose.ui.graphics.ImageBitmap? =
        synchronized(processArtworkMemory) { processArtworkMemory[fileId] }

    fun peekInitialStreamSnapshot(): SonusStreamInitialSnapshot? = processInitialStreamSnapshot

    /** Invalida sem reler todo o catálogo em segundo plano; a próxima seção reabre o cache sob demanda. */
    private fun invalidateInitialSnapshot() {
        processInitialStreamSnapshot = null
    }

    fun cachedInitialStreamSnapshot(): SonusStreamInitialSnapshot {
        processInitialStreamSnapshot?.let { return it }
        val genres = cachedGenres()
        val tracks = genres.associateWith { cachedTracks(it.path) }
        if (prefs.getString("recent_tracks_index", null) == null) {
            cacheRecentlyAddedIndex(tracks.values.flatten())
        }
        val snapshot = SonusStreamInitialSnapshot(
            genres = genres,
            trackMap = tracks,
            publishedGenres = cachedPublishedGenres(),
            artistAliases = cachedArtistAliasSnapshot()
        )
        processInitialStreamSnapshot = snapshot
        return snapshot
    }

    fun cachedArtistAliasSnapshot(): SonusArtistAliasSnapshot {
        processArtistAliasSnapshot?.let { return it }
        val parsed = runCatching {
            val root = JSONObject(prefs.getString("artist_alias_snapshot", "{}") ?: "{}")
            val items = root.optJSONObject("items") ?: JSONObject()
            val names = linkedMapOf<Long, String>()
            val ids = linkedMapOf<Long, String>()
            items.keys().forEach { rawId ->
                val fileId = rawId.toLongOrNull() ?: return@forEach
                val item = items.optJSONObject(rawId) ?: return@forEach
                item.optString("name").trim().takeIf { it.isNotBlank() }?.let { names[fileId] = it }
                item.optString("artistId").trim().takeIf { it.isNotBlank() }?.let { ids[fileId] = it }
            }
            SonusArtistAliasSnapshot(names, ids, root.optLong("cachedAt", 0L))
        }.getOrDefault(SonusArtistAliasSnapshot())
        processArtistAliasSnapshot = parsed
        return parsed
    }

    private fun saveArtistAliasSnapshot(value: SonusArtistAliasSnapshot) {
        val items = JSONObject()
        (value.names.keys + value.artistIds.keys).forEach { fileId ->
            items.put(fileId.toString(), JSONObject().apply {
                value.names[fileId]?.let { put("name", it) }
                value.artistIds[fileId]?.let { put("artistId", it) }
            })
        }
        prefs.edit().putString(
            "artist_alias_snapshot",
            JSONObject().put("cachedAt", value.cachedAt).put("items", items).toString()
        ).apply()
        processArtistAliasSnapshot = value
        invalidateInitialSnapshot()
    }

    suspend fun refreshArtistAliasSnapshot(force: Boolean = false): SonusArtistAliasSnapshot {
        val cached = cachedArtistAliasSnapshot()
        val now = System.currentTimeMillis()
        if (!force && cached.cachedAt > 0L && now - cached.cachedAt < 2L * 60L * 1000L &&
            (cached.names.isNotEmpty() || cached.artistIds.isNotEmpty())) return cached
        val snapshot = runCatching {
            FirebaseDatabase.getInstance().getReference("streamPublishedArtists")
                .limitToFirst(1000).get().awaitOnlineSnapshot()
        }.getOrNull() ?: return cached
        val names = snapshot.children.mapNotNull { n ->
            val id = n.child("fileId").getValue(Long::class.java) ?: n.key?.toLongOrNull() ?: return@mapNotNull null
            val name = n.child("artistName").getValue(String::class.java).orEmpty().trim()
            if (name.isBlank()) null else id to name
        }.toMap()
        val artistIds = snapshot.children.mapNotNull { n ->
            val id = n.child("fileId").getValue(Long::class.java) ?: n.key?.toLongOrNull() ?: return@mapNotNull null
            val artistId = n.child("artistId").getValue(String::class.java).orEmpty().trim()
            if (artistId.isBlank()) null else id to artistId
        }.toMap()
        return SonusArtistAliasSnapshot(names, artistIds, now).also(::saveArtistAliasSnapshot)
    }

    fun cachedGenres(): List<SonusOnlineGenre> {
        processGenresCache?.let { return it }
        val parsed = runCatching {
            val arr = JSONArray(prefs.getString("genres", "[]") ?: "[]")
            (0 until arr.length()).mapNotNull { i ->
                arr.optJSONObject(i)?.let { o ->
                    SonusOnlineGenre(o.optString("name"), o.optString("path"), o.optLong("folderId"))
                }?.takeIf { it.name.isNotBlank() && it.path.isNotBlank() }
            }
        }.getOrDefault(emptyList())
        processGenresCache = parsed
        return parsed
    }

    private fun cachedRemovedFileIds(): Set<Long> = prefs.getStringSet("removed_file_ids", emptySet()).orEmpty().mapNotNull(String::toLongOrNull).toSet()

    suspend fun refreshRemovedFileIds(): Set<Long> = suspendCancellableCoroutine { cont ->
        FirebaseDatabase.getInstance().getReference("publicConfig/sonusMusic/removedFileIds").get()
            .addOnCompleteListener { task ->
                if (!cont.isActive) return@addOnCompleteListener
                if (task.isSuccessful) {
                    val values = task.result.children.mapNotNull { child ->
                        val active = child.getValue(Boolean::class.java) ?: false
                        child.key?.toLongOrNull()?.takeIf { active }
                    }.toSet()
                    prefs.edit().putStringSet("removed_file_ids", values.map(Long::toString).toSet()).apply()
                    processTracksCache.clear()
                    invalidateInitialSnapshot()
                    cont.resume(values)
                } else {
                    cont.resume(cachedRemovedFileIds())
                }
            }
    }

    fun cachedTracks(genrePath: String): List<SonusOnlineTrack> {
        processTracksCache[genrePath]?.let { return it }
        val parsed = runCatching {
            val removed = cachedRemovedFileIds()
            val arr = JSONArray(prefs.getString("tracks_${key(genrePath)}", "[]") ?: "[]")
            (0 until arr.length())
                .mapNotNull { i -> arr.optJSONObject(i)?.let(::trackFromJson) }
                .filterNot { it.fileId in removed }
                .map(::applyTrackOverride)
        }.getOrDefault(emptyList())
        processTracksCache[genrePath] = parsed
        return parsed
    }

    private fun cachedTrackOverrides(): Map<Long, Map<String, String>> {
        processOverridesCache?.let { return it }
        val parsed = runCatching {
        val root = JSONObject(prefs.getString("track_overrides", "{}") ?: "{}")
        root.keys().asSequence().mapNotNull { rawId ->
            val id = rawId.toLongOrNull() ?: return@mapNotNull null
            val obj = root.optJSONObject(rawId) ?: return@mapNotNull null
            val fields = linkedMapOf<String, String>()
            obj.keys().forEach { key -> fields[key] = obj.optString(key) }
            id to fields
        }.toMap()
        }.getOrDefault(emptyMap())
        processOverridesCache = parsed
        return parsed
    }

    private fun saveTrackOverridesCache(values: Map<Long, Map<String, String>>) {
        val root = JSONObject()
        values.forEach { (id, fields) ->
            val obj = JSONObject(); fields.forEach { (k,v) -> obj.put(k,v) }; root.put(id.toString(), obj)
        }
        prefs.edit().putString("track_overrides", root.toString()).putLong("track_overrides_cached_at", System.currentTimeMillis()).apply()
        processOverridesCache = values
        processTracksCache.clear()
        invalidateInitialSnapshot()
    }

    suspend fun refreshTrackOverrides(force: Boolean = false): Map<Long, Map<String, String>> {
        val cached = cachedTrackOverrides()
        val cachedAt = prefs.getLong("track_overrides_cached_at", 0L)
        if (!force && cachedAt > 0L && System.currentTimeMillis() - cachedAt < 2L * 60L * 1000L) return cached
        val remote = cloud.loadSonusMusicTrackOverrides().getOrNull()
        if (remote != null) { saveTrackOverridesCache(remote); return remote }
        return cached
    }

    fun trackOverride(fileId: Long): Map<String, String> = cachedTrackOverrides()[fileId].orEmpty()

    private fun lrcLookupKey(raw: String): String = normalizeStreamSearch(
        raw.substringBeforeLast('.', raw)
            .replace(Regex("[_]+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    ).replace(Regex("[^a-z0-9]+"), " ").trim()

    private fun cachedPublicLrcIndex(): List<SonusPublicLrcFile> {
        processLrcIndexCache?.let { return it }
        val parsed = runCatching {
            val arr = JSONArray(prefs.getString("public_lrc_index", "[]") ?: "[]")
            buildList {
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val ref = SonusPublicLrcFile(
                        fileId = o.optLong("fileId", 0L), name = o.optString("name"),
                        size = o.optLong("size", 0L), modifiedAt = o.optLong("modifiedAt", 0L)
                    )
                    if (ref.fileId > 0L && ref.name.isNotBlank()) add(ref)
                }
            }.distinctBy { it.fileId }
        }.getOrDefault(emptyList())
        processLrcIndexCache = parsed
        return parsed
    }

    private fun savePublicLrcIndex(values: List<SonusPublicLrcFile>) {
        val arr = JSONArray()
        values.distinctBy { it.fileId }.forEach { ref ->
            arr.put(JSONObject().put("fileId", ref.fileId).put("name", ref.name).put("size", ref.size).put("modifiedAt", ref.modifiedAt))
        }
        prefs.edit().putString("public_lrc_index", arr.toString()).putLong("public_lrc_refresh", System.currentTimeMillis()).apply()
        processLrcIndexCache = values.distinctBy { it.fileId }
    }

    /**
     * code131: a biblioteca LRC pública do pCloud foi aposentada do runtime.
     * Mantemos a assinatura por compatibilidade interna, porém ela nunca enumera a pasta remota.
     */
    suspend fun refreshPublicLrcLibrary(force: Boolean = false): Int = 0

    fun cachedPublicLrcFiles(): List<SonusPublicLrcFile> = emptyList()

    fun cachedPublicLrcEntries(): List<SonusPublicLrcEntry> {
        val tracks = allCachedTracks()
        return cachedPublicLrcFiles().map { ref ->
            val match = tracks.maxByOrNull { track ->
                SonusLyricsResolver.scoreFilename(
                    SonusLyricsQuery(track.displayTitle, track.displayArtist, track.album, track.durationMs), ref.titleStem
                )
            }?.takeIf { track ->
                SonusLyricsResolver.scoreFilename(SonusLyricsQuery(track.displayTitle, track.displayArtist, track.album, track.durationMs), ref.titleStem) >= 95
            }
            SonusPublicLrcEntry(ref, match?.displayTitle ?: ref.titleStem, match?.displayArtist.orEmpty())
        }
    }

    suspend fun publicLrcEntries(force: Boolean = false): List<SonusPublicLrcEntry> = withContext(Dispatchers.IO) {
        emptyList()
    }

    private fun isSynchronizedLrc(text: String, format: String = "LRC"): Boolean {
        if (!format.equals("LRC", ignoreCase = true) && !text.contains('[')) return false
        return Regex("(?m)^\\[\\d{1,3}:\\d{2}(?:[\\.:]\\d{1,3})?]\\s*.*$").containsMatchIn(text)
    }

    /** code131: Developer lista somente LRC já salvas no catálogo/overrides do Stream. */
    fun cachedUnifiedLrcEntries(): List<SonusUnifiedLrcEntry> {
        val tracks = allCachedTracks()
        val entries = mutableListOf<SonusUnifiedLrcEntry>()

        tracks.forEach { track ->
            val catalogText = track.lyrics.trim()
            if (catalogText.isNotBlank() && isSynchronizedLrc(catalogText, track.lyricsFormat)) {
                entries += SonusUnifiedLrcEntry(
                    key = "track:${track.fileId}",
                    title = track.displayTitle,
                    artist = track.displayArtist,
                    trackFileId = track.fileId,
                    source = SonusUnifiedLrcSource.CATALOG
                )
            }
        }

        return entries
            .distinctBy { "${lrcLookupKey(it.title)}|${lrcLookupKey(it.artist)}" }
            .sortedWith(compareBy<SonusUnifiedLrcEntry>({ it.title.lowercase(Locale.ROOT) }, { it.artist.lowercase(Locale.ROOT) }))
    }

    suspend fun scanUnifiedLrcLibrary(force: Boolean = false): List<SonusUnifiedLrcEntry> = withContext(Dispatchers.IO) {
        // code131: nenhuma enumeração da pasta LRC pCloud. Atualiza apenas o catálogo
        // musical/overrides e as contribuições da comunidade.
        if (force || allCachedTracks().isEmpty()) runCatching { refreshCatalogIfChanged(force = force) }
        runCatching { refreshTrackOverrides() }
        val base = cachedUnifiedLrcEntries().toMutableList()
        val communitySnap = runCatching { FirebaseDatabase.getInstance().getReference("streamCommunityLyrics").get().awaitOnlineSnapshot() }.getOrNull()
        communitySnap?.children?.forEach { snap ->
            val fileId = snap.key?.toLongOrNull() ?: return@forEach
            val c = communityLrcFromSnapshot(fileId, snap) ?: return@forEach
            val existingIndex = base.indexOfFirst { it.trackFileId == fileId }
            val communityEntry = SonusUnifiedLrcEntry(
                key = "community:$fileId", title = c.title.ifBlank { allCachedTracks().firstOrNull { it.fileId == fileId }?.displayTitle.orEmpty() },
                artist = c.artist.ifBlank { allCachedTracks().firstOrNull { it.fileId == fileId }?.displayArtist.orEmpty() },
                trackFileId = fileId, source = SonusUnifiedLrcSource.COMMUNITY, contributorName = c.contributorName, communityStatus = c.status
            )
            if (existingIndex < 0) base += communityEntry
        }
        base.sortedWith(compareBy<SonusUnifiedLrcEntry>({ it.title.lowercase(Locale.ROOT) }, { it.artist.lowercase(Locale.ROOT) }))
    }

    suspend fun unifiedLrcText(entry: SonusUnifiedLrcEntry): String? = withContext(Dispatchers.IO) {
        val fileId = entry.trackFileId ?: return@withContext null
        if (entry.source == SonusUnifiedLrcSource.COMMUNITY) {
            communityLrc(fileId)?.lrc?.let { return@withContext it }
        }
        val track = allCachedTracks().firstOrNull { it.fileId == fileId }
        val text = track?.lyrics.orEmpty().trim()
        text.takeIf { it.isNotBlank() && isSynchronizedLrc(it, track?.lyricsFormat.orEmpty()) }
    }

    suspend fun publicLrcText(ref: SonusPublicLrcFile): String? = withContext(Dispatchers.IO) {
        null
    }

    private fun publicLrcCandidatesForTrack(track: SonusOnlineTrack): List<SonusPublicLrcFile> {
        val query = SonusLyricsQuery(track.displayTitle, track.displayArtist, track.album, track.durationMs)
        return cachedPublicLrcFiles().map { it to SonusLyricsResolver.scoreFilename(query, it.titleStem) }
            .filter { it.second >= 70 }
            .sortedByDescending { it.second }
            .map { it.first }
    }

    private fun publicLrcRefForTrack(track: SonusOnlineTrack): SonusPublicLrcFile? =
        publicLrcCandidatesForTrack(track).firstOrNull()

    /**
     * Resolve várias versões candidatas. Filename/versão define o pool; quando necessário
     * a duração da timeline LRC desempata sem misturar ao vivo/acústico/estúdio.
     */
    private suspend fun bestPublicLrcForTrack(track: SonusOnlineTrack): Pair<SonusPublicLrcFile, String>? {
        val query = SonusLyricsQuery(track.displayTitle, track.displayArtist, track.album, track.durationMs)
        val ranked = publicLrcCandidatesForTrack(track).take(5).mapNotNull { ref ->
            val text = publicLrcText(ref) ?: return@mapNotNull null
            val score = SonusLyricsResolver.scoreFilename(query, ref.titleStem) +
                SonusLyricsResolver.durationCompatibility(track.durationMs, text)
            Triple(ref, text, score)
        }.sortedByDescending { it.third }
        val best = ranked.firstOrNull() ?: return null
        return (best.first to best.second).takeIf { best.third >= 90 }
    }

    fun hasPublicLrcForFileId(fileId: Long): Boolean {
        val track = allCachedTracks().firstOrNull { it.fileId == fileId } ?: return false
        return publicLrcRefForTrack(track) != null
    }

    internal data class CommunityLrc(
        val fileId: Long,
        val title: String,
        val artist: String,
        val lrc: String,
        val contributorUid: String,
        val contributorName: String,
        val status: String,
        val createdAt: Long
    )

    private fun communityLrcFromSnapshot(fileId: Long, snap: DataSnapshot): CommunityLrc? {
        if (!snap.exists()) return null
        val status = snap.child("status").getValue(String::class.java).orEmpty().ifBlank { "active" }
        if (status.equals("removed", true)) return null
        val lrc = snap.child("lrc").getValue(String::class.java).orEmpty().trim()
        if (!isSynchronizedLrc(lrc, "LRC")) return null
        return CommunityLrc(
            fileId = fileId,
            title = snap.child("title").getValue(String::class.java).orEmpty(),
            artist = snap.child("artist").getValue(String::class.java).orEmpty(),
            lrc = lrc,
            contributorUid = snap.child("contributorUid").getValue(String::class.java).orEmpty(),
            contributorName = snap.child("contributorName").getValue(String::class.java).orEmpty(),
            status = status,
            createdAt = snap.child("createdAt").getValue(Long::class.java) ?: 0L
        )
    }

    suspend fun communityLrc(fileId: Long): CommunityLrc? = withContext(Dispatchers.IO) {
        runCatching {
            val snap = FirebaseDatabase.getInstance().getReference("streamCommunityLyrics").child(fileId.toString()).get().awaitOnlineSnapshot()
            communityLrcFromSnapshot(fileId, snap)
        }.getOrNull()
    }

    suspend fun submitCommunityLrc(fileId: Long, title: String, artist: String, lrc: String): Result<CommunityLrc> = withContext(Dispatchers.IO) {
        runCatching {
            require(fileId > 0L) { "Música inválida." }
            require(isSynchronizedLrc(lrc, "LRC")) { "A letra precisa conter timestamps LRC válidos." }
            val user = FirebaseAuth.getInstance().currentUser ?: error("Entre na sua conta para compartilhar uma letra.")
            val displayName = user.displayName?.trim().orEmpty().ifBlank { user.email?.substringBefore('@').orEmpty() }.ifBlank { "Usuário SONUS" }.take(80)
            val ref = FirebaseDatabase.getInstance().getReference("streamCommunityLyrics").child(fileId.toString())
            val now = System.currentTimeMillis()
            val value = mapOf(
                "fileId" to fileId,
                "title" to title.take(160),
                "artist" to artist.take(160),
                "lrc" to lrc.trim(),
                "contributorUid" to user.uid,
                "contributorName" to displayName,
                "status" to "active",
                "createdAt" to now,
                "updatedAt" to now
            )
            val committed = suspendCancellableCoroutine<Boolean> { cont ->
                ref.runTransaction(object : Transaction.Handler {
                    override fun doTransaction(currentData: MutableData): Transaction.Result {
                        val existingStatus = currentData.child("status").getValue(String::class.java).orEmpty()
                        val existingLrc = currentData.child("lrc").getValue(String::class.java).orEmpty()
                        if (existingLrc.isNotBlank() && !existingStatus.equals("removed", true)) return Transaction.abort()
                        currentData.value = value
                        return Transaction.success(currentData)
                    }
                    override fun onComplete(error: DatabaseError?, committed: Boolean, currentData: DataSnapshot?) {
                        if (!cont.isActive) return
                        if (error != null) cont.resumeWithException(error.toException()) else cont.resume(committed)
                    }
                })
            }
            require(committed) { "Outra pessoa adicionou a letra antes de você. Atualize a música." }
            CommunityLrc(fileId, title, artist, lrc.trim(), user.uid, displayName, "active", now)
        }
    }

    suspend fun reportCommunityLrc(fileId: Long, reason: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val user = FirebaseAuth.getInstance().currentUser ?: error("Entre na sua conta para denunciar.")
            val cleanReason = reason.trim().take(300).ifBlank { "Outro" }
            val db = FirebaseDatabase.getInstance()
            val id = db.getReference("streamCommunityLyricReports").push().key ?: java.util.UUID.randomUUID().toString()
            val now = System.currentTimeMillis()
            db.getReference("streamCommunityLyricReports").child(id).setValue(mapOf(
                "id" to id, "fileId" to fileId, "reporterUid" to user.uid, "reason" to cleanReason, "status" to "NEW", "createdAt" to now
            )).awaitOnlineVoid()
            val ticket = db.getReference("supportTickets").push()
            val ticketId = ticket.key ?: java.util.UUID.randomUUID().toString()
            ticket.setValue(mapOf(
                "id" to ticketId, "ownerUid" to user.uid,
                "category" to "STREAM_SUBMISSION", "status" to "NEW",
                "subject" to "Denúncia de letra sincronizada",
                "lastMessage" to "Faixa $fileId • $cleanReason",
                "createdAt" to now, "updatedAt" to now,
                "unreadForUser" to false, "unreadForTeam" to true,
                "technical" to mapOf("requestType" to "COMMUNITY_LRC_REPORT", "fileId" to fileId.toString(), "reportId" to id, "reason" to cleanReason)
            )).awaitOnlineVoid()
        }
    }

    suspend fun removeCommunityLrc(fileId: Long): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val user = FirebaseAuth.getInstance().currentUser ?: error("Conta não autenticada.")
            FirebaseDatabase.getInstance().getReference("streamCommunityLyrics").child(fileId.toString()).updateChildren(mapOf(
                "status" to "removed", "removedAt" to System.currentTimeMillis(), "removedBy" to user.uid
            )).awaitOnlineVoid()
        }
    }

    fun lyricsForFileId(fileId: Long): Pair<String, String>? {
        val track = allCachedTracks().firstOrNull { it.fileId == fileId }
        val text = track?.lyrics.orEmpty().trim()
        return text.takeIf { it.isNotBlank() }?.let { it to track?.lyricsFormat.orEmpty().ifBlank { "TEXT" } }
    }

    suspend fun lyricsForFileIdAuto(fileId: Long): Pair<String, String>? = withContext(Dispatchers.IO) {
        val track = allCachedTracks().firstOrNull { it.fileId == fileId }
        // Letras já administradas no próprio Stream continuam soberanas.
        lyricsForFileId(fileId)?.let { return@withContext it }
        communityLrc(fileId)?.let { return@withContext it.lrc to "LRC" }
        if (track != null) {
            SonusLyricsResolver.lrclib(
                context, SonusLyricsQuery(track.displayTitle, track.displayArtist, track.album, track.durationMs)
            )?.let { return@withContext it.text to it.format }
        }
        null
    }

    private fun applyTrackOverride(track: SonusOnlineTrack): SonusOnlineTrack {
        val o = cachedTrackOverrides()[track.fileId] ?: return track
        return track.copy(
            title = o["title"].orEmpty().ifBlank { track.title },
            artist = o["artist"].orEmpty().ifBlank { track.artist },
            album = o["album"].orEmpty().ifBlank { track.album },
            genre = o["genre"].orEmpty().ifBlank { track.genre },
            year = o["year"].orEmpty(),
            trackNumber = o["trackNumber"].orEmpty(),
            lyrics = o["lyrics"].orEmpty(),
            lyricsFormat = o["lyricsFormat"].orEmpty().ifBlank { "TEXT" },
            adminCoverBase64 = o["coverBase64"]?.takeIf { it.isNotBlank() }
        )
    }

    fun allCachedTracks(): List<SonusOnlineTrack> = cachedGenres().flatMap { cachedTracks(it.path) }.distinctBy { it.fileId }

    fun saveCatalog(catalog: Map<SonusOnlineGenre, List<SonusOnlineTrack>>) {
        val genres = catalog.keys.sortedBy { it.name.lowercase(Locale.getDefault()) }
        val arr = JSONArray()
        genres.forEach { g ->
            arr.put(JSONObject().put("name", g.name).put("path", g.path).put("folderId", g.folderId))
            val tracks = catalog[g].orEmpty()
            val trackArray = JSONArray()
            tracks.forEach { trackArray.put(trackToJson(it)) }
            prefs.edit().putString("tracks_${key(g.path)}", trackArray.toString()).apply()
        }
        prefs.edit().putString("genres", arr.toString()).putLong("last_refresh", System.currentTimeMillis()).apply()
        processGenresCache = genres
        processTracksCache.clear()
        catalog.forEach { (genre, tracks) -> processTracksCache[genre.path] = tracks.map(::applyTrackOverride) }
        cacheRecentlyAddedIndex(catalog.values.flatten())
        invalidateInitialSnapshot()
    }

    fun refreshCatalog(): Map<SonusOnlineGenre, List<SonusOnlineTrack>> {
        val removed = cachedRemovedFileIds()
        val raw = SonusPCloudClient.loadCatalog()
        val visible = raw.mapValues { (_, tracks) -> tracks.filterNot { it.fileId in removed } }.filterValues { it.isNotEmpty() }
        saveCatalog(visible)
        return visible.mapValues { (_, tracks) -> tracks.map(::applyTrackOverride) }
    }

    /**
     * Stale-while-revalidate: a Home já nasce do cache e só baixa a árvore pCloud
     * quando a revisão pública realmente mudou. Revisão ausente mantém compatibilidade
     * com catálogos legados e força a sincronização normal.
     */
    suspend fun refreshCatalogIfChanged(force: Boolean = false): Map<SonusOnlineGenre, List<SonusOnlineTrack>> {
        val cached = cachedGenres().associateWith { cachedTracks(it.path) }.filterValues { it.isNotEmpty() }
        val lastRefresh = prefs.getLong("last_refresh", 0L)
        // As três fontes compartilham a mesma sessão: não refazer três listagens pCloud
        // em cada reentrada/alternância de aba. A atualização manual/forçada ignora o TTL.
        if (!force && cached.isNotEmpty() && lastRefresh > 0L &&
            System.currentTimeMillis() - lastRefresh < 3L * 60L * 1000L) return cached
        val localRevision = prefs.getLong("catalog_revision", 0L)
        val remoteRevision = runCatching {
            FirebaseDatabase.getInstance().getReference("publicConfig/sonusMusic/catalogRevision").get().awaitOnlineSnapshot()
                .getValue(Long::class.java) ?: 0L
        }.getOrDefault(0L)
        val secondaryEnabled = BuildConfig.SONUS_PCLOUD_SECONDARY_PUBLIC_CODE.isNotBlank()
        // Com duas fontes públicas, a revisão Firebase da pasta original não representa a conta secundária.
        // Nesse caso o próprio ciclo de refresh do Stream consulta ambas as pastas para incorporar novas faixas.
        if (!force && !secondaryEnabled && cached.isNotEmpty() && remoteRevision > 0L && remoteRevision == localRevision) return cached
        val fresh = withContext(Dispatchers.IO) { refreshCatalog() }
        if (remoteRevision > 0L) prefs.edit().putLong("catalog_revision", remoteRevision).apply()
        return fresh
    }

    fun cachedPublishedGenres(): Set<String> = prefs.getStringSet("published_genres", emptySet()).orEmpty().toSet()

    suspend fun refreshPublishedGenres(): Set<String> {
        val remote = cloud.loadSonusMusicPublishedGenres().getOrNull()
        if (remote != null) {
            prefs.edit().putStringSet("published_genres", remote).apply()
            invalidateInitialSnapshot()
            return remote
        }
        return cachedPublishedGenres()
    }

    suspend fun setPublishedGenres(genres: Set<String>): Result<Unit> {
        val result = cloud.setSonusMusicPublishedGenres(genres)
        if (result.isSuccess) {
            prefs.edit().putStringSet("published_genres", genres).apply()
            invalidateInitialSnapshot()
        }
        return result
    }

    fun queueItem(track: SonusOnlineTrack): PulsePlayerQueueItem = PulsePlayerQueueItem(
        uri = SonusOnlineRef(track.fileId, track.size, sourceKeyForTrack(track), track.displayTitle, track.artist).toUriString(),
        title = track.displayTitle,
        artist = track.artist,
        album = track.album,
        genre = track.genre,
        durationMs = track.durationMs,
        source = "SONUS Stream"
    )

    fun artwork(track: SonusOnlineTrack): androidx.compose.ui.graphics.ImageBitmap? {
        inMemoryArtwork(track.fileId)?.let { return it }
        track.adminCoverBase64?.let { encoded ->
            runCatching { Base64.decode(encoded, Base64.DEFAULT) }.getOrNull()?.let { bytes ->
                return rememberArtwork(track.fileId, runCatching { BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap() }.getOrNull())
            }
        }
        val cached = coverFile(track.fileId)
        if (cached.exists()) return rememberArtwork(track.fileId, runCatching { BitmapFactory.decodeFile(cached.absolutePath)?.asImageBitmap() }.getOrNull())
        if (!track.hasThumb || track.fileId <= 0L) return null
        return runCatching {
            val bytes = SonusPCloudClient.downloadThumbnail(rawFileIdForTrack(track), sourceKeyForTrack(track))
            cached.writeBytes(bytes)
            rememberArtwork(track.fileId, BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap())
        }.getOrNull()
    }

    fun cachedArtwork(track: SonusOnlineTrack): androidx.compose.ui.graphics.ImageBitmap? {
        inMemoryArtwork(track.fileId)?.let { return it }
        track.adminCoverBase64?.let { encoded ->
            runCatching { Base64.decode(encoded, Base64.DEFAULT) }.getOrNull()?.let { bytes ->
                return rememberArtwork(track.fileId, runCatching { BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap() }.getOrNull())
            }
        }
        val file = coverFile(track.fileId)
        return if (file.exists()) rememberArtwork(track.fileId, runCatching { BitmapFactory.decodeFile(file.absolutePath)?.asImageBitmap() }.getOrNull()) else null
    }

    /** Limpa somente capas; histórico, playlists, favoritos e metadados permanecem intactos. */
    fun clearArtworkCache() {
        runCatching { coverDir.deleteRecursively() }
        coverDir.mkdirs()
        synchronized(processArtworkMemory) { processArtworkMemory.clear() }
    }

    fun recordPlayed(track: SonusOnlineTrack) = recordPlayedFileId(track.fileId)

    fun recordPlayedFileId(fileId: Long) {
        if (fileId <= 0L) return
        val recent = recentIds().toMutableList().apply {
            remove(fileId.toString())
            add(0, fileId.toString())
            while (size > 40) removeAt(lastIndex)
        }
        val counts = playCounts().toMutableMap()
        val key = fileId.toString()
        counts[key] = (counts[key] ?: 0) + 1
        val json = JSONObject()
        counts.forEach { (k, v) -> json.put(k, v) }
        prefs.edit()
            .putString("recent", JSONArray(recent).toString())
            .putString("play_counts", json.toString())
            .putString("last_played", key)
            .apply()
    }

    fun recentTracks(all: List<SonusOnlineTrack>, max: Int = 12): List<SonusOnlineTrack> {
        val map = all.associateBy { it.fileId.toString() }
        return recentIds().mapNotNull(map::get).take(max)
    }

    fun favoriteIds(): Set<Long> = prefs.getStringSet("favorites", emptySet()).orEmpty().mapNotNull { it.toLongOrNull() }.toSet()

    fun toggleFavorite(fileId: Long): Set<Long> {
        val next = favoriteIds().toMutableSet()
        val liked = if (fileId in next) { next.remove(fileId); false } else { next.add(fileId); true }
        prefs.edit().putStringSet("favorites", next.map { it.toString() }.toSet()).apply()
        if (fileId > 0L && FirebaseAuth.getInstance().currentUser != null) {
            // A curtida continua instantânea/local; a sincronização analítica é paralela e nunca bloqueia o player.
            syncScope.launch { runCatching { streamPlatform.setSongLike(fileId, liked) } }
        }
        return next
    }

    fun favoriteTracks(all: List<SonusOnlineTrack>): List<SonusOnlineTrack> {
        val ids = favoriteIds()
        return all.filter { it.fileId in ids }
    }

    fun playlists(): Map<String, Set<Long>> = runCatching {
        val json = JSONObject(prefs.getString("playlists", "{}") ?: "{}")
        json.keys().asSequence().associateWith { name ->
            val arr = json.optJSONArray(name) ?: JSONArray()
            (0 until arr.length()).mapNotNull { arr.optLong(it).takeIf { id -> id > 0L } }.toSet()
        }.toSortedMap(String.CASE_INSENSITIVE_ORDER)
    }.getOrDefault(emptyMap())

    fun createPlaylist(name: String): Map<String, Set<Long>> {
        val clean = name.trim().take(48)
        if (clean.isBlank()) return playlists()
        val next = playlists().toMutableMap()
        next.putIfAbsent(clean, emptySet())
        savePlaylists(next)
        return next
    }

    fun addToPlaylist(name: String, fileId: Long): Map<String, Set<Long>> {
        if (fileId <= 0L) return playlists()
        val next = playlists().toMutableMap()
        next[name] = next[name].orEmpty() + fileId
        savePlaylists(next)
        return next
    }

    fun removePlaylist(name: String): Map<String, Set<Long>> {
        val next = playlists().toMutableMap().apply { remove(name) }
        savePlaylists(next)
        return next
    }

    fun playlistTracks(name: String, all: List<SonusOnlineTrack>): List<SonusOnlineTrack> {
        val ids = playlists()[name].orEmpty()
        return all.filter { it.fileId in ids }
    }

    private fun savePlaylists(value: Map<String, Set<Long>>) {
        val json = JSONObject()
        value.forEach { (name, ids) -> json.put(name, JSONArray(ids.toList())) }
        prefs.edit().putString("playlists", json.toString()).apply()
    }

    fun mostPlayed(all: List<SonusOnlineTrack>, max: Int = 12): List<SonusOnlineTrack> {
        val counts = playCounts()
        return all.sortedByDescending { counts[it.fileId.toString()] ?: 0 }.filter { (counts[it.fileId.toString()] ?: 0) > 0 }.take(max)
    }

    fun lastPlayed(all: List<SonusOnlineTrack>): SonusOnlineTrack? {
        val id = prefs.getString("last_played", null)?.toLongOrNull() ?: return null
        return all.firstOrNull { it.fileId == id }
    }

    fun recentlyAdded(all: List<SonusOnlineTrack>, max: Int = 12): List<SonusOnlineTrack> =
        all.sortedWith(compareByDescending<SonusOnlineTrack> { it.createdAt }.thenBy { it.displayTitle }).take(max)

    fun cachedRecentlyAdded(max: Int = 60): List<SonusOnlineTrack> = runCatching {
        val arr = JSONArray(prefs.getString("recent_tracks_index", "[]") ?: "[]")
        val removed = cachedRemovedFileIds()
        (0 until arr.length()).mapNotNull { i -> arr.optJSONObject(i)?.let(::trackFromJson) }
            .filterNot { it.fileId in removed }
            .map(::applyTrackOverride)
            .take(max)
    }.getOrDefault(emptyList())

    private fun cacheRecentlyAddedIndex(tracks: List<SonusOnlineTrack>) {
        val recent = tracks.asSequence().distinctBy { it.fileId }
            .sortedWith(compareByDescending<SonusOnlineTrack> { it.createdAt }.thenBy { it.displayTitle })
            .take(80).toList()
        val arr = JSONArray().apply { recent.forEach { put(trackToJson(it)) } }
        prefs.edit().putString("recent_tracks_index", arr.toString()).apply()
    }

    fun clearCache() {
        val favorites = prefs.getStringSet("favorites", emptySet())
        val recent = prefs.getString("recent", "[]")
        val counts = prefs.getString("play_counts", "{}")
        val last = prefs.getString("last_played", null)
        val published = prefs.getStringSet("published_genres", emptySet())
        val playlists = prefs.getString("playlists", "{}")
        prefs.edit().clear().apply()
        prefs.edit()
            .putStringSet("favorites", favorites)
            .putString("recent", recent)
            .putString("play_counts", counts)
            .putString("last_played", last)
            .putStringSet("published_genres", published)
            .putString("playlists", playlists)
            .apply()
        runCatching { coverDir.listFiles()?.forEach { it.delete() } }
    }

    fun cachedTrackCount(): Int = allCachedTracks().size
    fun lastRefreshMillis(): Long = prefs.getLong("last_refresh", 0L)
    fun cachedResolvedDurationMs(fileId: Long): Long = prefs.getLong("resolved_duration_$fileId", 0L).coerceAtLeast(0L)
    fun rememberResolvedDurationMs(fileId: Long, durationMs: Long) {
        if (fileId > 0L && durationMs > 0L) prefs.edit().putLong("resolved_duration_$fileId", durationMs).apply()
    }

    fun testConnection(): Result<Pair<Int, Int>> = runCatching {
        val catalog = refreshCatalog()
        catalog.size to catalog.values.sumOf { it.size }
    }

    suspend fun loadDirectOverride(fileId: Long): String? = cloud.loadSonusMusicStreamOverride(fileId).getOrNull()

    suspend fun loadAllDirectOverrides(): Map<Long, String> = cloud.loadSonusMusicStreamOverrides().getOrDefault(emptyMap())

    suspend fun saveDirectOverride(fileId: Long, url: String): Result<Unit> = cloud.saveSonusMusicStreamOverride(fileId, url)

    suspend fun removeDirectOverride(fileId: Long): Result<Unit> = cloud.removeSonusMusicStreamOverride(fileId)

    suspend fun saveTrackAdminOverride(fileId: Long, fields: Map<String, String>): Result<Unit> {
        val result = cloud.saveSonusMusicTrackOverride(fileId, fields)
        if (result.isSuccess) refreshTrackOverrides(force = true)
        return result
    }

    suspend fun saveTrackAdminOverridesBatch(updates: Map<Long, Map<String, String>>): Result<Unit> {
        val result = cloud.saveSonusMusicTrackOverridesBatch(updates)
        if (result.isSuccess) refreshTrackOverrides(force = true)
        return result
    }

    suspend fun removeTrackAdminOverride(fileId: Long): Result<Unit> {
        val result = cloud.removeSonusMusicTrackOverride(fileId)
        if (result.isSuccess) refreshTrackOverrides(force = true)
        return result
    }

    /**
     * OWNER pode testar um override privado. Para usuários comuns, a leitura OWNER-only
     * falha silenciosamente e o player usa a URL temporária do pCloud.
     */
    suspend fun resolvePlaybackStream(fileId: Long, sourceKey: String? = null): SonusResolvedStream {
        // Caminho administrativo: preserva override OWNER para testes e ferramentas internas.
        val override = loadDirectOverride(fileId)
        if (!override.isNullOrBlank()) return SonusResolvedStream(override, source = "OWNER override")
        val actualSourceKey = sourceKey?.takeIf { it in setOf("primary", "secondary", "tertiary") } ?: sourceKeyForFileId(fileId)
        return SonusResolvedStream(SonusPCloudClient.automaticStreamUrl(rawFileIdForFileId(fileId), actualSourceKey), source = "catálogo SONUS")
    }

    /**
     * Caminho rápido do player público: Firebase/override não entra antes do primeiro áudio.
     * O descriptor vive poucos segundos, suficiente para clique/próxima faixa, e é renovado
     * automaticamente quando o link temporário falhar.
     */
    suspend fun resolvePlaybackStreamFast(fileId: Long, forceRefresh: Boolean = false, sourceKey: String? = null): SonusResolvedStream {
        if (!forceRefresh) SonusPlaybackDescriptorCache.get(fileId)?.let { return it }
        val actualSourceKey = sourceKey?.takeIf { it in setOf("primary", "secondary", "tertiary") } ?: sourceKeyForFileId(fileId)
        val resolved = withContext(Dispatchers.IO) {
            SonusResolvedStream(SonusPCloudClient.automaticStreamUrl(rawFileIdForFileId(fileId), actualSourceKey), source = "SONUS Stream")
        }
        SonusPlaybackDescriptorCache.put(fileId, resolved)
        return resolved
    }

    fun invalidatePlaybackDescriptor(fileId: Long) { SonusPlaybackDescriptorCache.invalidate(fileId) }

    suspend fun prefetchPlaybackDescriptor(fileId: Long, sourceKey: String? = null) {
        if (fileId > 0L) runCatching { resolvePlaybackStreamFast(fileId, forceRefresh = false, sourceKey = sourceKey) }
    }

    suspend fun prefetchPlaybackDescriptor(track: SonusOnlineTrack) {
        prefetchPlaybackDescriptor(track.fileId, sourceKeyForTrack(track))
    }

    suspend fun resolvePlaybackUrl(fileId: Long, sourceKey: String? = null): String = resolvePlaybackStream(fileId, sourceKey).url

    fun testDirectUrl(url: String): Result<String> = runCatching {
        val probe = SonusPCloudClient.probeUrl(url.trim())
        "HTTP ${probe.responseCode} • ${probe.contentType.ifBlank { "áudio" }} • ${probe.bytesRead / 1024} KB • primeiro byte ${probe.firstByteMs} ms • Range ${if (probe.acceptsRanges) "OK" else "não confirmado"}"
    }

    fun testStreaming(): Result<String> = runCatching {
        val track = allCachedTracks().firstOrNull() ?: refreshCatalog().values.flatten().firstOrNull()
            ?: error("Nenhuma música encontrada")
        val started = System.currentTimeMillis()
        val url = SonusPCloudClient.automaticStreamUrl(rawFileIdForTrack(track), sourceKeyForTrack(track))
        val total = SonusPCloudClient.streamSize(url, track.size)
        val bytes = SonusPCloudClient.readRange(0L, minOf(64 * 1024, total.coerceAtMost(64 * 1024L).toInt()), url)
        if (bytes.isEmpty()) error("O pCloud não entregou bytes do áudio")
        val latency = System.currentTimeMillis() - started
        "${track.displayTitle} • ${bytes.size / 1024} KB lidos • primeiro bloco em ${latency} ms • ${total / 1024} KB"
    }


    suspend fun testStreamingReady(): Result<String> = runCatching {
        val track = allCachedTracks().firstOrNull() ?: withContext(Dispatchers.IO) { refreshCatalog().values.flatten().firstOrNull() }
            ?: error("Nenhuma música encontrada")
        val stream = resolvePlaybackStream(track.fileId)
        val probe = withContext(Dispatchers.IO) { SonusPCloudClient.probeUrl(stream.url, headers = stream.headers) }
        val readyMs = withContext(Dispatchers.Main) {
            val started = System.currentTimeMillis()
            val signal = CompletableDeferred<Unit>()
            val http = DefaultHttpDataSource.Factory().setUserAgent("SONUS/${BuildConfig.VERSION_NAME}").setAllowCrossProtocolRedirects(true)
            if (stream.headers.isNotEmpty()) http.setDefaultRequestProperties(stream.headers)
            val player = ExoPlayer.Builder(context).setMediaSourceFactory(DefaultMediaSourceFactory(http)).build()
            try {
                player.addListener(object : Player.Listener {
                    override fun onPlaybackStateChanged(state: Int) {
                        if (state == Player.STATE_READY && !signal.isCompleted) signal.complete(Unit)
                    }
                    override fun onPlayerError(error: PlaybackException) {
                        if (!signal.isCompleted) signal.completeExceptionally(IOException(error.errorCodeName))
                    }
                })
                player.playWhenReady = false
                player.setMediaItem(MediaItem.fromUri(stream.url))
                player.prepare()
                withTimeout(10_000L) { signal.await() }
                System.currentTimeMillis() - started
            } finally {
                player.release()
            }
        }
        "${track.displayTitle} • ${stream.source} • HTTP ${probe.responseCode} • ${probe.contentType.ifBlank { "áudio" }} • ${probe.bytesRead / 1024} KB • primeiro byte ${probe.firstByteMs} ms • ExoPlayer READY ${readyMs} ms • Range ${if(probe.acceptsRanges)"OK" else "não confirmado"}"
    }

    private fun coverFile(fileId: Long) = File(coverDir, "$fileId.jpg")

    private fun recentIds(): List<String> = runCatching {
        val arr = JSONArray(prefs.getString("recent", "[]") ?: "[]")
        (0 until arr.length()).mapNotNull { arr.optString(it).takeIf { value -> value.isNotBlank() } }
    }.getOrDefault(emptyList())

    private fun playCounts(): Map<String, Int> = runCatching {
        val json = JSONObject(prefs.getString("play_counts", "{}") ?: "{}")
        json.keys().asSequence().associateWith { json.optInt(it, 0) }
    }.getOrDefault(emptyMap())

    private fun trackToJson(t: SonusOnlineTrack) = JSONObject().apply {
        put("path", t.path); put("file", t.fileName); put("size", t.size); put("fileId", t.fileId)
        put("title", t.title); put("artist", t.artist); put("album", t.album); put("genre", t.genre)
        put("duration", t.durationMs); put("createdAt", t.createdAt); put("thumb", t.hasThumb); put("cover", t.coverFile ?: "")
    }

    private fun trackFromJson(o: JSONObject) = SonusOnlineTrack(
        path = o.optString("path"), fileName = o.optString("file"), size = o.optLong("size"), fileId = o.optLong("fileId"),
        title = o.optString("title"), artist = o.optString("artist"), album = o.optString("album"), genre = o.optString("genre"),
        durationMs = o.optLong("duration"), createdAt = o.optLong("createdAt"), hasThumb = o.optBoolean("thumb"),
        coverFile = o.optString("cover").takeIf { it.isNotBlank() }
    ).takeIf { it.path.isNotBlank() && it.fileName.isNotBlank() && it.size > 0L && it.fileId > 0L }

    private fun key(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }.take(24)
}

internal fun loadSonusOnlineArtwork(context: Context, rawUri: String): androidx.compose.ui.graphics.ImageBitmap? {
    val ref = SonusOnlineRef.parse(rawUri) ?: return null
    val repo = SonusOnlineMusicRepository(context)
    val track = repo.allCachedTracks().firstOrNull { it.fileId == ref.fileId } ?: return null
    return repo.cachedArtwork(track) ?: repo.artwork(track)
}


private class SonusStreamPlaybackPreferences(context: Context) {
    private val prefs=context.applicationContext.getSharedPreferences("sonus_stream_playback_v1",Context.MODE_PRIVATE)
    private val experience=SonusStreamExperiencePreferences(context)
    var mobilePlayback:Boolean get()=prefs.getBoolean("mobilePlayback",true);set(v){prefs.edit().putBoolean("mobilePlayback",v).apply()}
    var mobileWarningSeen:Boolean get()=prefs.getBoolean("mobileWarningSeen",false);set(v){prefs.edit().putBoolean("mobileWarningSeen",v).apply()}
    var mobileWarning:Boolean get()=prefs.getBoolean("mobileWarning",false);set(v){prefs.edit().putBoolean("mobileWarning",v).apply()}
    var catalogRefreshMinutes:Int get()=experience.catalogRefreshMinutes;set(v){experience.catalogRefreshMinutes=v}
    var preloadNext:Boolean get()=experience.preloadNext;set(v){experience.preloadNext=v}
    var fadeInSeconds:Int get()=experience.fadeInSeconds;set(v){experience.fadeInSeconds=v}
    var fadeOutSeconds:Int get()=experience.fadeOutSeconds;set(v){experience.fadeOutSeconds=v}
    var crossfadeSeconds:Int get()=experience.crossfadeSeconds;set(v){experience.crossfadeSeconds=v}
    var dataMonitor:Boolean get()=experience.dataMonitor;set(v){experience.dataMonitor=v}
    var lyricsAutoScroll:Boolean get()=experience.lyricsAutoScroll;set(v){experience.lyricsAutoScroll=v}
    var useHistoryRecommendations:Boolean get()=experience.useHistoryRecommendations;set(v){experience.useHistoryRecommendations=v}
    var defaultPlaylistPublic:Boolean get()=experience.defaultPlaylistPublic;set(v){experience.defaultPlaylistPublic=v}
    var lastCatalogRefreshAt:Long get()=experience.lastCatalogRefreshAt;set(v){experience.lastCatalogRefreshAt=v}
    fun dueForCatalogRefresh()=experience.dueForCatalogRefresh()
    fun resetDefaults(){prefs.edit().clear().apply();experience.reset()}
}

@Composable
private fun SonusTopActionChip(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tint: Color,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier.width(60.dp).height(50.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(15.dp),
        color = Color(0xFF111C2A),
        border = BorderStroke(1.dp, tint.copy(alpha = .38f)),
        shadowElevation = 3.dp
    ) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = 2.dp, vertical = 5.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(19.dp))
            Spacer(Modifier.height(3.dp))
            Text(label, color = Color.White.copy(alpha = .92f), fontSize = 7.5.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
        }
    }
}

@Composable
private fun SonusTopSquareButton(
    modifier:Modifier=Modifier,
    background:Color,
    border:Color=Color.White.copy(alpha=.18f),
    content:@Composable BoxScope.()->Unit
){
    Surface(modifier=modifier.size(40.dp),shape=RoundedCornerShape(8.dp),color=background,border=BorderStroke(1.dp,border)){Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center,content=content)}
}
@Composable
private fun SonusAnalyticsIcon(modifier:Modifier=Modifier){
    SonusTopSquareButton(modifier,background=Color(0xFF173C57),border=Color(0xFF43D3FF).copy(alpha=.55f)){
        Row(horizontalArrangement=Arrangement.spacedBy(2.dp),verticalAlignment=Alignment.Bottom,modifier=Modifier.height(23.dp)){
            Box(Modifier.width(5.dp).height(9.dp).background(Color(0xFF4DD7FF),RoundedCornerShape(2.dp)))
            Box(Modifier.width(5.dp).height(16.dp).background(Color(0xFFFFC857),RoundedCornerShape(2.dp)))
            Box(Modifier.width(5.dp).height(22.dp).background(Color(0xFF62E6A6),RoundedCornerShape(2.dp)))
        }
    }
}
@Composable
private fun SonusSettingsIcon(modifier:Modifier=Modifier){
    SonusTopSquareButton(modifier,background=Color(0xFF26333A),border=Color(0xFFFFC857).copy(alpha=.48f)){Icon(Icons.Default.Settings,"Ajustes",tint=Color(0xFFFFC857),modifier=Modifier.size(24.dp))}
}
@Composable
private fun SonusUploadIcon(modifier:Modifier=Modifier){
    SonusTopSquareButton(modifier,background=Color(0xFF0A4E5D),border=Color(0xFF52E6C4).copy(alpha=.56f)){
        Icon(Icons.Default.MusicNote,null,tint=Color(0xFF52E6C4),modifier=Modifier.size(24.dp))
        Icon(Icons.Default.ArrowUpward,"Enviar música",tint=Color(0xFFFFD45C),modifier=Modifier.size(12.dp).align(Alignment.TopEnd).offset((-5).dp,5.dp))
    }
}
@Composable
private fun SonusSearchIcon(modifier:Modifier=Modifier){
    SonusTopSquareButton(modifier,background=Color(0xFF173B63),border=Color(0xFF75B7FF).copy(alpha=.52f)){Icon(Icons.Default.Search,"Pesquisar",tint=Color(0xFF75B7FF),modifier=Modifier.size(24.dp))}
}

@Composable
private fun SonusStreamSettingsDialog(settings:SonusStreamPlaybackPreferences,service:PulsePlayerService?,repo:SonusOnlineMusicRepository,onClose:()->Unit){
    val context=LocalContext.current
    var refreshMinutes by remember{mutableIntStateOf(settings.catalogRefreshMinutes)}
    var preload by remember{mutableStateOf(settings.preloadNext)}
    var fadeIn by remember{mutableFloatStateOf(settings.fadeInSeconds.toFloat())}
    var fadeOut by remember{mutableFloatStateOf(settings.fadeOutSeconds.toFloat())}
    var crossfade by remember{mutableFloatStateOf(settings.crossfadeSeconds.toFloat())}
    var monitor by remember{mutableStateOf(settings.dataMonitor)}
    var lyricsScroll by remember{mutableStateOf(settings.lyricsAutoScroll)};var history by remember{mutableStateOf(settings.useHistoryRecommendations)};var publicPlaylist by remember{mutableStateOf(settings.defaultPlaylistPublic)}
    var mobilePlayback by remember{mutableStateOf(settings.mobilePlayback)}
    var mobileWarning by remember{mutableStateOf(settings.mobileWarning)}
    val refreshOptions=listOf(-1 to "A cada abertura",30 to "30 min",60 to "1 h",120 to "2 h",180 to "3 h",360 to "6 h",720 to "12 h",1440 to "24 h",0 to "Manual")
    AlertDialog(onDismissRequest=onClose,title={Row(verticalAlignment=Alignment.CenterVertically){SonusSettingsIcon();Spacer(Modifier.width(10.dp));Column{Text("Ajustes do SONUS Stream",fontWeight=FontWeight.Black);Text("Reprodução, catálogo e experiência",style=MaterialTheme.typography.labelSmall)}}},text={LazyColumn(verticalArrangement=Arrangement.spacedBy(12.dp),modifier=Modifier.heightIn(max=590.dp)){
        item{Text("CATÁLOGO",fontWeight=FontWeight.Black,fontSize=11.sp,color=Color(0xFF63E2C2))}
        item{Text("Atualização do catálogo",fontWeight=FontWeight.Bold);Text("Atualiza dados básicos no intervalo escolhido. As músicas são consultadas ao abrir uma seção; o botão Atualizar continua disponível.",style=MaterialTheme.typography.labelSmall);LazyRow(horizontalArrangement=Arrangement.spacedBy(6.dp)){items(refreshOptions){(v,label)->FilterChip(selected=refreshMinutes==v,onClick={refreshMinutes=v},label={Text(label,fontSize=10.sp)})}}}
        item{HorizontalDivider();Text("USO DE DADOS",fontWeight=FontWeight.Black,fontSize=11.sp,color=Color(0xFF63E2C2))}
        item{Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("Permitir reprodução com dados móveis",fontWeight=FontWeight.Bold);Text("Desative para usar somente Wi‑Fi",style=MaterialTheme.typography.labelSmall)};Switch(mobilePlayback,{mobilePlayback=it})}}
        item{Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("Avisar antes de usar dados móveis",fontWeight=FontWeight.Bold);Text("Mostra um aviso antes da primeira reprodução móvel",style=MaterialTheme.typography.labelSmall)};Switch(mobileWarning,{mobileWarning=it})}}
        item{HorizontalDivider();Text("REPRODUÇÃO",fontWeight=FontWeight.Black,fontSize=11.sp,color=Color(0xFF63E2C2))}
        item{Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("Pré-carregar próxima música",fontWeight=FontWeight.Bold);Text("Reduz o atraso entre faixas",style=MaterialTheme.typography.labelSmall)};Switch(preload,{preload=it})}}
        item{Text("Fade in: ${fadeIn.toInt()} s",fontWeight=FontWeight.Bold);Slider(fadeIn,{fadeIn=it},valueRange=0f..10f,steps=9)}
        item{Text("Fade out: ${fadeOut.toInt()} s",fontWeight=FontWeight.Bold);Slider(fadeOut,{fadeOut=it},valueRange=0f..10f,steps=9)}
        item{Text("Crossfade: ${crossfade.toInt()} s",fontWeight=FontWeight.Bold);Text("Usa o mesmo motor do SONUS Player • não afeta a Rádio",style=MaterialTheme.typography.labelSmall);Slider(crossfade,{crossfade=it},valueRange=0f..12f,steps=11)}
        item{HorizontalDivider();Text("MONITOR",fontWeight=FontWeight.Black,fontSize=11.sp,color=Color(0xFF63E2C2))}
        item{Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("Monitor de uso de dados",fontWeight=FontWeight.Bold);Text("Mostra velocidade e total da sessão de forma discreta",style=MaterialTheme.typography.labelSmall)};Switch(monitor,{monitor=it})}}
        item{HorizontalDivider();Text("LETRAS E RECOMENDAÇÕES",fontWeight=FontWeight.Black,fontSize=11.sp,color=Color(0xFF63E2C2))}
        item{Row(verticalAlignment=Alignment.CenterVertically){Text("Rolagem automática do LRC",Modifier.weight(1f));Switch(lyricsScroll,{lyricsScroll=it})}}
        item{Row(verticalAlignment=Alignment.CenterVertically){Text("Usar histórico nas recomendações",Modifier.weight(1f));Switch(history,{history=it})}}
        item{Row(verticalAlignment=Alignment.CenterVertically){Text("Nova playlist pública por padrão",Modifier.weight(1f));Switch(publicPlaylist,{publicPlaylist=it})}}
        item{OutlinedButton(onClick={repo.clearArtworkCache();Toast.makeText(context,"Somente as capas em cache foram removidas. Histórico e playlists foram preservados.",Toast.LENGTH_LONG).show()},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.CleaningServices,null);Spacer(Modifier.width(6.dp));Text("Limpar capas em cache")}}
    }},confirmButton={Button(onClick={settings.catalogRefreshMinutes=refreshMinutes;settings.mobilePlayback=mobilePlayback;if(settings.mobileWarning!=mobileWarning)settings.mobileWarningSeen=false;settings.mobileWarning=mobileWarning;settings.preloadNext=preload;settings.fadeInSeconds=fadeIn.toInt();settings.fadeOutSeconds=fadeOut.toInt();settings.crossfadeSeconds=crossfade.toInt();settings.dataMonitor=monitor;settings.lyricsAutoScroll=lyricsScroll;settings.useHistoryRecommendations=history;settings.defaultPlaylistPublic=publicPlaylist;service?.setPreloadNextEnabled(preload);service?.setStreamFade(fadeIn.toInt(),fadeOut.toInt());service?.setCrossfade(crossfade.toInt());onClose()}){Text("Salvar")}},dismissButton={TextButton(onClick=onClose){Text("Cancelar")}})
}

@Composable
private fun StreamMiniMetric(modifier:Modifier,value:String,label:String){
    Surface(modifier=modifier,shape=RoundedCornerShape(13.dp),color=Color.White.copy(alpha=.05f)){
        Column(Modifier.padding(9.dp)){Text(value,fontWeight=FontWeight.Black,fontSize=15.sp);Text(label,fontSize=8.sp,color=Color.White.copy(alpha=.55f))}
    }
}

@Composable
private fun SonusStreamUserAnalyticsDialog(onClose: () -> Unit) {
    val context = LocalContext.current
    val localStore = remember { SonusStreamLocalAnalyticsStore(context) }
    var personalRevision by remember { mutableIntStateOf(0) }
    val liveRevision by localStore.revisionFlow.collectAsState()
    var confirmClear by remember { mutableStateOf(false) }
    val personal = remember(personalRevision, liveRevision) { localStore.snapshotCurrentMonth() }

    val monthLabel = remember(personal.month) {
        val locale = Locale("pt", "BR")
        personal.month.month.getDisplayName(java.time.format.TextStyle.FULL, locale).replaceFirstChar { it.titlecase(locale) } + " ${personal.month.year}"
    }
    val personalAvg = if (personal.validPlays > 0) personal.listeningMs / personal.validPlays else 0L
    val personalCompletion = if (personal.validPlays > 0) personal.completions * 100.0 / personal.validPlays else 0.0
    val personalReplay = if (personal.validPlays > 0) personal.replays * 100.0 / personal.validPlays else 0.0

    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            shape = RectangleShape,
            color = Color(0xFF101017)
        ) {
            Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onClose) { Icon(Icons.Default.ArrowBack, "Voltar") }
                    Column(Modifier.weight(1f)) {
                        Text("Analytics do SONUS Stream", fontWeight = FontWeight.Black, fontSize = 20.sp)
                        Text("$monthLabel • somente mês atual", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = .58f))
                    }
                }

                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(top = 10.dp, bottom = 20.dp)
                ) {
                    item {
                        Surface(shape = RoundedCornerShape(20.dp), color = Color(0xFF171825)) {
                            Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                                Text("Seu mês no SONUS", fontWeight = FontWeight.Black, fontSize = 17.sp)
                                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                    StreamMiniMetric(Modifier.weight(1f), personal.validPlays.toString(), "plays válidos")
                                    StreamMiniMetric(Modifier.weight(1f), "%.1f h".format(personal.listeningMs / 3_600_000.0), "tempo ouvido")
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                    StreamMiniMetric(Modifier.weight(1f), personal.uniqueSongs.toString(), "músicas")
                                    StreamMiniMetric(Modifier.weight(1f), personal.uniqueArtists.toString(), "artistas")
                                    StreamMiniMetric(Modifier.weight(1f), personal.uniqueGenres.toString(), "gêneros")
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                    StreamMiniMetric(Modifier.weight(1f), personal.completions.toString(), "conclusões")
                                    StreamMiniMetric(Modifier.weight(1f), personal.replays.toString(), "replays")
                                    StreamMiniMetric(Modifier.weight(1f), personal.skips.toString(), "pulos")
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                    StreamMiniMetric(Modifier.weight(1f), "%.0f%%".format(personalCompletion), "conclusão")
                                    StreamMiniMetric(Modifier.weight(1f), "%.0f%%".format(personalReplay), "replay")
                                    StreamMiniMetric(Modifier.weight(1f), formatAnalyticsDuration(personalAvg), "média/play")
                                }
                            }
                        }
                    }
                    item { Text("Reproduções por dia", fontWeight = FontWeight.Black, fontSize = 16.sp) }
                    item { StreamMonthlyBarChart(personal.dailyPlays, "reproduções") }
                    if (personal.dailyListeningMs.any { it.second > 0L }) {
                        item { Text("Tempo ouvido por dia", fontWeight = FontWeight.Black, fontSize = 16.sp) }
                        item { StreamMonthlyBarChart(personal.dailyListeningMs.map { it.first to (it.second / 60_000L) }, "min") }
                    }
                    if (personal.topTracks.any { it.validPlays > 0L }) {
                        item { Text("Mais ouvidas do mês", fontWeight = FontWeight.Black, fontSize = 16.sp) }
                        items(personal.topTracks.filter { it.validPlays > 0L }.take(8), key = { "local_${it.fileId}" }) { row ->
                            StreamRankRow(row.title.ifBlank { "Faixa ${row.fileId}" }, row.artist, "${row.validPlays} plays • ${formatAnalyticsDuration(row.listeningMs)}")
                        }
                    }
                    if (personal.topArtists.isNotEmpty()) {
                        item { Text("Artistas mais ouvidos", fontWeight = FontWeight.Black, fontSize = 16.sp) }
                        items(personal.topArtists.take(6)) { row -> StreamRankRow(row.first, "Tempo ouvido", formatAnalyticsDuration(row.second)) }
                    }
                    if (personal.topGenres.isNotEmpty()) {
                        item { Text("Gêneros do mês", fontWeight = FontWeight.Black, fontSize = 16.sp) }
                        items(personal.topGenres.take(6)) { row -> StreamRankRow(row.first, "Tempo ouvido", formatAnalyticsDuration(row.second)) }
                    }
                    item {
                        val insight = when {
                            personal.validPlays == 0L -> "Quando houver reproduções válidas neste mês, o SONUS monta seus padrões daqui — sem inventar métricas."
                            personal.topGenres.isNotEmpty() -> "Neste mês, ${personal.topGenres.first().first} lidera seu tempo ouvido. Você acumulou ${formatAnalyticsDuration(personal.listeningMs)} no Stream."
                            else -> "Você acumulou ${personal.validPlays} reproduções válidas e ${formatAnalyticsDuration(personal.listeningMs)} de áudio neste mês."
                        }
                        Surface(shape = RoundedCornerShape(17.dp), color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = .18f)) {
                            Column(Modifier.padding(12.dp)) {
                                Text("SONUS Insight", fontWeight = FontWeight.Black)
                                Text(insight, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                    item {
                        OutlinedButton(onClick = { confirmClear = true }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.DeleteSweep, null, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(6.dp)); Text("Limpar estatísticas deste mês")
                        }
                    }
                }
            }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Limpar seu mês?") },
            text = { Text("Isso apaga apenas as estatísticas pessoais do mês atual neste aparelho.") },
            confirmButton = {
                Button(onClick = {
                    localStore.clearCurrentMonth()
                    personalRevision++
                    confirmClear = false
                }) { Text("Limpar") }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancelar") } }
        )
    }
}

@Composable
private fun StreamRankRow(title: String, subtitle: String, value: String) {
    Surface(shape = RoundedCornerShape(14.dp), color = Color.White.copy(alpha = .04f)) {
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (subtitle.isNotBlank()) Text(subtitle, style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = .55f), maxLines = 1)
            }
            Text(value, fontWeight = FontWeight.Bold, fontSize = 10.sp)
        }
    }
}

@Composable
private fun StreamMonthlyBarChart(values: List<Pair<String, Long>>, suffix: String) {
    val entries = values.takeLast(31)
    val max = (entries.maxOfOrNull { it.second } ?: 1L).coerceAtLeast(1L)
    Surface(shape = RoundedCornerShape(18.dp), color = Color.White.copy(alpha = .04f)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth().height(88.dp), horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.Bottom) {
                entries.forEach { row ->
                    val ratio = row.second.toFloat() / max.toFloat()
                    Box(Modifier.weight(1f).height((4 + 70 * ratio).dp).background(MaterialTheme.colorScheme.primary.copy(alpha = .22f + .68f * ratio), RoundedCornerShape(topStart = 3.dp, topEnd = 3.dp)))
                }
            }
            val peak = entries.maxByOrNull { it.second }
            Text(if (peak != null) "Pico: ${peak.first.takeLast(5)} • ${peak.second} $suffix" else "Sem dados neste mês.", style = MaterialTheme.typography.labelSmall)
        }
    }
}

private fun formatAnalyticsDuration(ms:Long):String {
    val seconds=(ms/1000L).coerceAtLeast(0L);val m=seconds/60;val s=seconds%60
    return if(m>0)"${m}m ${s}s" else "${s}s"
}

private data class SonusHomePersonalSummary(
    val validPlays: Long = 0L,
    val listeningMs: Long = 0L,
    val topFileId: Long = 0L
)

@Composable
internal fun SonusOnlineMusicScreen(
    accent: Color,
    service: PulsePlayerService?,
    membershipTier: MembershipTier,
    onRequestPlan: (MembershipTier) -> Unit,
    onTrack: (String, Boolean?, Long?) -> Unit,
    onCreatorCenter: () -> Unit = {},
    onOpenFullPlayer: () -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val connectivityManager = remember { context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager }
    fun hasValidatedInternet(): Boolean = connectivityManager.activeNetwork?.let { network ->
        connectivityManager.getNetworkCapabilities(network)?.let { caps ->
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        } == true
    } ?: false
    var networkAvailable by remember { mutableStateOf(hasValidatedInternet()) }
    DisposableEffect(connectivityManager) {
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { networkAvailable = hasValidatedInternet() }
            override fun onLost(network: Network) { networkAvailable = hasValidatedInternet() }
            override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
                networkAvailable = networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                    networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
            }
        }
        runCatching { connectivityManager.registerDefaultNetworkCallback(callback) }
        onDispose { runCatching { connectivityManager.unregisterNetworkCallback(callback) } }
    }
    val emptyPlaybackFlow = remember { MutableStateFlow(PulsePlayerPlaybackState()) }
    val playback by (service?.state ?: emptyPlaybackFlow).collectAsState()
    if (FirebaseAuth.getInstance().currentUser == null) {
        Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Surface(shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .28f)) {
                Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Icon(Icons.Default.Lock, null, tint = accent, modifier = Modifier.size(34.dp))
                    Text("Entre para usar o SONUS Stream", fontWeight = FontWeight.Black, fontSize = 20.sp)
                    Text("O Stream exige uma conta SONUS autenticada para proteger reproduções, curtidas e seguidores contra tráfego artificial.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        return
    }
    val repo = remember { SonusOnlineMusicRepository(context) }
    val streamRepo = remember { SonusStreamPlatformRepository(context) }
    val streamPlatform = remember { SonusStreamPlatformRepository(context) }
    val playbackPrefs = remember { SonusStreamPlaybackPreferences(context) }
    // code131 fast first paint: só lê o snapshot se o Application já o aqueceu.
    // Se ainda não estiver pronto, a primeira composição nasce leve e o cache é
    // desserializado em Dispatchers.IO logo depois, sem bloquear o toque no Stream.
    val processSnapshot = remember { repo.peekInitialStreamSnapshot() }
    remember { SonusStreamOpenTrace.mark("primeira composição do Stream", processSnapshot != null) }
    LaunchedEffect(Unit) { androidx.compose.runtime.withFrameNanos { }; SonusStreamOpenTrace.mark("primeiro frame do Stream") }
    var showStreamSettings by remember { mutableStateOf(false) }
    var showStreamAnalytics by remember { mutableStateOf(false) }
    var showStreamUpload by remember { mutableStateOf(false) }
    var pendingMobileTrack by remember { mutableStateOf<PendingStreamPlayback?>(null) }
    val genrePreferences = remember { SonusStreamExperiencePreferences(context) }
    var published by remember { mutableStateOf(processSnapshot?.publishedGenres ?: repo.cachedPublishedGenres()) }
    var sourceGenres by remember { mutableStateOf(processSnapshot?.genres.orEmpty()) }
    var sourceTrackMap by remember { mutableStateOf(processSnapshot?.trackMap.orEmpty()) }
    var hasSourceSnapshot by remember { mutableStateOf(processSnapshot != null) }
    var genres by remember { mutableStateOf(officialStreamGenres()) }
    var trackMap by remember { mutableStateOf<Map<SonusOnlineGenre, List<SonusOnlineTrack>>>(emptyMap()) }
    var favoriteGenres by remember { mutableStateOf(genrePreferences.favoriteGenres()) }
    var selectedGenre by remember { mutableStateOf<SonusOnlineGenre?>(null) }
    var selectedGenreTab by rememberSaveable { mutableStateOf("Músicas") }
    var activeLibrarySection by rememberSaveable { mutableStateOf<String?>(null) }
    var catalogLoaded by remember { mutableStateOf(false) }
    var catalogLoadInProgress by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    LaunchedEffect(loading) { if (!loading) { androidx.compose.runtime.withFrameNanos { }; SonusStreamOpenTrace.mark("catálogo visível"); SonusStreamOpenTrace.done() } }
    var error by remember { mutableStateOf<String?>(null) }
    var favorites by remember { mutableStateOf(repo.favoriteIds()) }
    var recentIndex by remember { mutableStateOf(repo.cachedRecentlyAdded()) }
    var playlists by remember { mutableStateOf(repo.playlists()) }
    var offlineItems by remember { mutableStateOf(SonusOfflineDownloadManager.list(context)) }
    var offlineDownloading by remember { mutableStateOf<Set<Long>>(emptySet()) }
    var offlineProgress by remember { mutableStateOf<Map<Long, Float>>(emptyMap()) }
    var collectionDownloadLabel by remember { mutableStateOf<String?>(null) }
    var collectionDownloadProgress by remember { mutableFloatStateOf(0f) }
    var selectedPlaylist by remember { mutableStateOf<String?>(null) }
    var showCreatePlaylist by remember { mutableStateOf(false) }
    var playlistTrack by remember { mutableStateOf<SonusOnlineTrack?>(null) }
    var reportTrack by remember { mutableStateOf<SonusOnlineTrack?>(null) }
    var shareTrack by remember { mutableStateOf<SonusOnlineTrack?>(null) }
    var newPlaylistName by remember { mutableStateOf("") }
    var searchQuery by remember { mutableStateOf("") }
    var debouncedSearchQuery by remember { mutableStateOf("") }
    var searchExpanded by rememberSaveable { mutableStateOf(false) }
    var timelineEntries by remember { mutableStateOf<List<StreamTimelineEntry>>(emptyList()) }
    var filter by remember { mutableStateOf("Tudo") }
    val platformPlayCounts = remember { emptyMap<Long, Long>() }
    val initialAliasSnapshot = remember { processSnapshot?.artistAliases ?: SonusArtistAliasSnapshot() }
    var artistAliases by remember { mutableStateOf(initialAliasSnapshot.names) }
    var artistIds by remember { mutableStateOf(initialAliasSnapshot.artistIds) }
    var selectedArtistProfile by remember { mutableStateOf<Pair<SonusOnlineTrack,List<SonusOnlineTrack>>?>(null) }
    var selectedRadioStationId by rememberSaveable { mutableStateOf<String?>(null) }
    var radioPreparing by remember { mutableStateOf(false) }
    var queuePreparing by remember { mutableStateOf(false) }

    LaunchedEffect(sourceGenres, sourceTrackMap, published, hasSourceSnapshot) {
        val projected = withContext(Dispatchers.Default) {
            projectOfficialStreamGenres(context, sourceGenres, sourceTrackMap, published)
        }
        genres = projected.first
        trackMap = projected.second
        catalogLoaded = hasSourceSnapshot
    }

    // code132: a visibilidade segue SOMENTE o estado publicado/oculto de cada pasta. O atalho antigo
    // que forçava qualquer pasta com faixa da fonte secundária a aparecer ignorava o botão do OWNER
    // (MÚSICAS 2 ficava desligada no painel e continuava tocando no Stream).
    val visibleGenres = remember(genres, favoriteGenres) {
        genres.sortedWith(compareBy<SonusOnlineGenre>({ if (it.name in favoriteGenres) 0 else 1 }, { normalizeStreamSearch(it.name) }))
    }
    val allVisibleTracks by produceState<List<SonusOnlineTrack>>(emptyList(), trackMap, visibleGenres, artistAliases) {
        value = withContext(Dispatchers.Default) {
            visibleGenres.flatMap { trackMap[it].orEmpty() }.distinctBy { it.fileId }.map { track ->
                val canonical = canonicalStreamArtist(artistAliases[track.fileId].orEmpty().ifBlank { track.artist })
                track.copy(artist = canonical)
            }
        }
    }
    // O gênero de pasta é o fallback oficial quando o arquivo não traz uma tag GENRE confiável.
    // Isso mantém busca/continuação por estilo útil mesmo em catálogos antigos.
    val catalogGenreByFile by produceState<Map<Long, String>>(emptyMap(), visibleGenres, trackMap) {
        value = withContext(Dispatchers.Default) {
            buildMap<Long, String> {
                visibleGenres.forEach { folder ->
                    trackMap[folder].orEmpty().forEach { track ->
                        if (track.fileId > 0L && folder.name.isNotBlank()) put(track.fileId, folder.name)
                    }
                }
            }
        }
    }
    val albumGroups by produceState<List<List<SonusOnlineTrack>>>(emptyList(), allVisibleTracks) {
        value = withContext(Dispatchers.Default) {
            allVisibleTracks.asSequence()
                .filter { it.album.isNotBlank() }
                .groupBy { "${normalizeStreamSearch(it.album)}::${normalizeStreamSearch(it.artist)}" }
                .values
                .map { tracks -> tracks.distinctBy { it.fileId }.sortedBy { it.displayTitle.lowercase(Locale.ROOT) } }
                .filter { it.isNotEmpty() }
                .sortedBy { it.first().album.lowercase(Locale.ROOT) }
        }
    }

    val timelineTracks = remember(timelineEntries, allVisibleTracks) {
        val byId = allVisibleTracks.associateBy { it.fileId }
        timelineEntries.mapNotNull { byId[it.fileId] }
    }
    val timelineReady = timelineEntries.size >= 10
    val timelineYear = java.time.LocalDate.now().year

    LaunchedEffect(searchQuery) {
        delay(300L)
        debouncedSearchQuery = searchQuery
    }
    val normalizedQuery = remember(debouncedSearchQuery) { normalizeStreamSearch(debouncedSearchQuery) }
    val searchResults by produceState<List<SonusOnlineTrack>>(emptyList(), allVisibleTracks, normalizedQuery) {
        value = withContext(Dispatchers.Default) {
            if (normalizedQuery.isBlank()) emptyList() else allVisibleTracks.filter { track ->
                val exact = normalizeStreamSearch("${track.displayTitle} - ${track.artist}")
                exact.contains(normalizedQuery) ||
                    normalizeStreamSearch(track.displayTitle).contains(normalizedQuery) ||
                    normalizeStreamSearch(track.artist).contains(normalizedQuery) ||
                    normalizeStreamSearch(track.album).contains(normalizedQuery) ||
                    normalizeStreamSearch(track.genre).contains(normalizedQuery)
            }.sortedWith(compareByDescending<SonusOnlineTrack> { normalizeStreamSearch("${it.displayTitle} - ${it.artist}") == normalizedQuery }.thenBy { normalizeStreamSearch(it.displayTitle) })
        }
    }

    val searchPlaylistResults = remember(playlists.keys, normalizedQuery) {
        if (normalizedQuery.isBlank()) emptyList() else playlists.keys.filter { normalizeStreamSearch(it).contains(normalizedQuery) }.take(12)
    }
    val searchGenreResults = remember(visibleGenres, normalizedQuery) {
        if (normalizedQuery.isBlank()) emptyList() else visibleGenres.filter { normalizeStreamSearch(it.name).contains(normalizedQuery) }.take(12)
    }
    val artistPlaylists by produceState<List<List<SonusOnlineTrack>>>(emptyList(), allVisibleTracks, artistIds) {
        value = withContext(Dispatchers.Default) {
        val namedTracks = allVisibleTracks.filter { it.artist.isNotBlank() }
        val stableIdByName = namedTracks
            .groupBy { normalizeStreamSearch(it.artist) }
            .mapValues { (_, list) ->
                list.mapNotNull { artistIds[it.fileId]?.trim()?.takeIf { it.isNotBlank() } }
                    .distinct()
                    .singleOrNull()
            }
        namedTracks.groupBy { track ->
            val normalizedName = normalizeStreamSearch(track.artist)
            val stableId = artistIds[track.fileId]?.trim()?.takeIf { it.isNotBlank() }
                ?: stableIdByName[normalizedName]
            stableId?.let { "id:$it" } ?: "name:$normalizedName"
        }.values
            .filter { it.isNotEmpty() }
            .map { it.distinctBy(SonusOnlineTrack::fileId).take(50) }
            .sortedBy { it.first().artist.lowercase(Locale.ROOT) }
        }
    }
    val searchArtistResults = remember(artistPlaylists, normalizedQuery) {
        if (normalizedQuery.isBlank()) emptyList() else artistPlaylists.filter { group ->
            normalizeStreamSearch(group.firstOrNull()?.artist.orEmpty()).contains(normalizedQuery)
        }.take(12)
    }
    val metered = remember { (context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager)?.isActiveNetworkMetered == true }

    fun refresh(showIndicator: Boolean = true) {
        scope.launch {
            if (showIndicator) loading = true
            try {
                withContext(Dispatchers.IO) { runCatching { repo.refreshTrackOverrides() } }
                withContext(Dispatchers.IO) { runCatching { repo.refreshRemovedFileIds() } }
                val catalogResult = runCatching { repo.refreshCatalogIfChanged(force = true) }
                val publishedResult = withContext(Dispatchers.IO) { runCatching { repo.refreshPublishedGenres() } }
                val latestPublished = publishedResult.getOrNull() ?: published
                published = latestPublished
                catalogResult.onSuccess { fresh ->
                    sourceGenres = fresh.keys.toList()
                    sourceTrackMap = fresh
                    hasSourceSnapshot = true
                    recentIndex = repo.cachedRecentlyAdded()
                    error = null
                    playbackPrefs.lastCatalogRefreshAt = System.currentTimeMillis()
                    if (publishedResult.isSuccess) playbackPrefs.lastBasicRefreshAt = System.currentTimeMillis()
                }.onFailure { error = "Não foi possível atualizar o SONUS Stream agora. ${it.message.orEmpty()}".trim() }
                val aliases = withContext(Dispatchers.IO) { runCatching { repo.refreshArtistAliasSnapshot(force = true) }.getOrNull() }
                if (aliases != null) { artistAliases = aliases.names; artistIds = aliases.artistIds }
            } finally {
                if (showIndicator) loading = false
            }
        }
    }


    var catalogRefreshChecked by remember { mutableStateOf(false) }

    fun maybeRefreshCatalogForUserAction() {
        if (catalogRefreshChecked) return
        catalogRefreshChecked = true
        if (playbackPrefs.catalogRefreshMinutes != 0 && playbackPrefs.dueForCatalogRefresh()) {
            playbackPrefs.lastCatalogRefreshAt = System.currentTimeMillis()
            refresh(showIndicator = false)
        }
    }

    fun loadCachedCatalog() {
        if (catalogLoaded) {
            maybeRefreshCatalogForUserAction()
            return
        }
        if (catalogLoadInProgress) return
        scope.launch {
            catalogLoadInProgress = true
            loading = true
            try {
                val cached = withContext(Dispatchers.IO) { repo.cachedInitialStreamSnapshot() }
                sourceGenres = cached.genres
                sourceTrackMap = cached.trackMap
                hasSourceSnapshot = true
                recentIndex = repo.cachedRecentlyAdded()
                if (cached.artistAliases.names.isNotEmpty() || cached.artistAliases.artistIds.isNotEmpty()) {
                    artistAliases = cached.artistAliases.names
                    artistIds = cached.artistAliases.artistIds
                }
                if (cached.genres.isEmpty()) error = "Ainda não há catálogo em cache. Use Atualizar catálogo para buscar as músicas."
            } finally {
                catalogLoadInProgress = false
                loading = false
            }
            maybeRefreshCatalogForUserAction()
        }
    }

    fun loadGenreCache(genre: SonusOnlineGenre) {
        maybeRefreshCatalogForUserAction()
        if (!catalogLoaded) {
            loadCachedCatalog()
            return
        }
        if (trackMap.containsKey(genre)) return
        trackMap = trackMap + (genre to emptyList())
    }

    LaunchedEffect(Unit) {
        // Atualiza somente a configuração leve de publicação ao abrir o Stream.
        // A árvore de músicas permanece em cache até o usuário abrir uma seção/gênero.
        if (playbackPrefs.dueForBasicRefresh()) {
            val latest = withContext(Dispatchers.IO) { runCatching { repo.refreshPublishedGenres() }.getOrDefault(published) }
            published = latest
            playbackPrefs.lastBasicRefreshAt = System.currentTimeMillis()
        }
    }

    LaunchedEffect(showStreamSettings, playbackPrefs.catalogRefreshMinutes) {
        val minutes = playbackPrefs.catalogRefreshMinutes
        if (showStreamSettings || minutes <= 0) return@LaunchedEffect
        while (true) {
            delay(minutes.toLong() * 60_000L)
            val latest = withContext(Dispatchers.IO) { runCatching { repo.refreshPublishedGenres() }.getOrDefault(published) }
            published = latest
            playbackPrefs.lastBasicRefreshAt = System.currentTimeMillis()
            // Próximo toque em gênero/seção pode revalidar o catálogo de faixas, sem downloads de áudio.
            catalogRefreshChecked = false
        }
    }

    LaunchedEffect(debouncedSearchQuery) {
        if (debouncedSearchQuery.isNotBlank() && !catalogLoaded) loadCachedCatalog()
    }


    fun playContext(
        contextTracks: List<SonusOnlineTrack>,
        clicked: SonusOnlineTrack,
        source: String = "SONUS Stream",
        genreContinuation: Boolean = false,
        openFullPlayerAfterStart: Boolean = false
    ) {
        if (contextTracks.isEmpty()) return
        if (metered && !playbackPrefs.mobilePlayback) {
            Toast.makeText(context,"SONUS Stream está configurado para usar somente Wi‑Fi.",Toast.LENGTH_SHORT).show()
            return
        }
        if (metered && playbackPrefs.mobileWarning && !playbackPrefs.mobileWarningSeen) {
            pendingMobileTrack = PendingStreamPlayback(contextTracks, clicked, source, genreContinuation, openFullPlayerAfterStart)
            return
        }
        val playerService = service ?: run {
            Toast.makeText(context, "Player ainda está iniciando. Tente novamente.", Toast.LENGTH_SHORT).show()
            return
        }
        if (queuePreparing) return
        queuePreparing = true
        scope.launch {
            try {
                val prepared = withContext(Dispatchers.Default) {
                    val effectiveTracks = if (genreContinuation) {
                        buildGenreContinuation(allVisibleTracks, clicked, platformPlayCounts, favorites, catalogGenreByFile)
                    } else contextTracks.distinctBy { it.fileId }
                    if (effectiveTracks.isEmpty()) null else {
                        val queue = effectiveTracks.map { repo.queueItem(it).copy(source = source) }
                        Triple(queue, effectiveTracks.indexOfFirst { it.fileId == clicked.fileId }.coerceAtLeast(0), effectiveTracks.size)
                    }
                }
                if (prepared == null) return@launch
                // Filtragem, ordenação e montagem da fila não bloqueiam mais a thread da UI.
                playerService.setShuffle(false)
                playerService.setQueue(prepared.first, prepared.second, true)
                onTrack("SONUS Stream: ${clicked.displayTitle}", true, null)
                if (openFullPlayerAfterStart) onOpenFullPlayer()
            } catch (t: Throwable) {
                if (t !is kotlinx.coroutines.CancellationException) Toast.makeText(context, t.message ?: "Não foi possível preparar a reprodução.", Toast.LENGTH_LONG).show()
            } finally {
                queuePreparing = false
            }
        }
    }

    fun downloadOne(track: SonusOnlineTrack) {
        val ref = SonusOnlineRef.parse(repo.queueItem(track).uri) ?: return
        if (track.fileId in offlineDownloading) return
        if (SonusOfflineDownloadManager.isDownloaded(context, ref)) {
            SonusOfflineDownloadManager.remove(context, ref)
            offlineItems = SonusOfflineDownloadManager.list(context)
            Toast.makeText(context, "Download removido: ${track.displayTitle}", Toast.LENGTH_SHORT).show()
            return
        }
        offlineDownloading = offlineDownloading + track.fileId
        offlineProgress = offlineProgress + (track.fileId to 0f)
        scope.launch {
            try {
                withContext(Dispatchers.IO) {
                    SonusOfflineDownloadManager.download(context, repo, track) { done, total ->
                        scope.launch { offlineProgress = offlineProgress + (track.fileId to if (total > 0L) (done.toFloat() / total).coerceIn(0f, 1f) else 0f) }
                    }
                }
                offlineItems = withContext(Dispatchers.IO) { SonusOfflineDownloadManager.list(context) }
                Toast.makeText(context, "Download concluído: ${track.displayTitle}", Toast.LENGTH_SHORT).show()
            } catch (t: Throwable) {
                if (t !is kotlinx.coroutines.CancellationException) Toast.makeText(context, t.message ?: "Falha no download", Toast.LENGTH_LONG).show()
            } finally {
                offlineDownloading = offlineDownloading - track.fileId
                offlineProgress = offlineProgress - track.fileId
            }
        }
    }

    fun downloadCollection(tracks: List<SonusOnlineTrack>, label: String) {
        if (tracks.isEmpty() || collectionDownloadLabel != null) return
        scope.launch {
            val refs = tracks.mapNotNull { track -> SonusOnlineRef.parse(repo.queueItem(track).uri)?.let { track to it } }
            if (refs.isEmpty()) {
                Toast.makeText(context, "Esta coleção não tem faixas disponíveis para download offline.", Toast.LENGTH_LONG).show()
                return@launch
            }
            val missing = refs.filterNot { (_, ref) -> SonusOfflineDownloadManager.isDownloaded(context, ref) }
            if (missing.isEmpty()) {
                refs.forEach { (_, ref) -> SonusOfflineDownloadManager.remove(context, ref) }
                offlineItems = withContext(Dispatchers.IO) { SonusOfflineDownloadManager.list(context) }
                Toast.makeText(context, "$label removida da biblioteca offline", Toast.LENGTH_SHORT).show()
                return@launch
            }
            collectionDownloadLabel = label
            var completed = 0
            try {
                missing.forEachIndexed { index, (track, _) ->
                    offlineDownloading = offlineDownloading + track.fileId
                    withContext(Dispatchers.IO) {
                        SonusOfflineDownloadManager.download(context, repo, track) { done, total ->
                            scope.launch {
                                val within = if (total > 0L) (done.toFloat() / total).coerceIn(0f, 1f) else 0f
                                collectionDownloadProgress = ((index + within) / missing.size).coerceIn(0f, 1f)
                            }
                        }
                    }
                    offlineDownloading = offlineDownloading - track.fileId
                    completed++
                }
                offlineItems = withContext(Dispatchers.IO) { SonusOfflineDownloadManager.list(context) }
                Toast.makeText(context, "$completed música(s) baixada(s) • $label", Toast.LENGTH_LONG).show()
            } catch (t: Throwable) {
                if (t !is kotlinx.coroutines.CancellationException) Toast.makeText(context, t.message ?: "Falha ao baixar coleção", Toast.LENGTH_LONG).show()
            } finally {
                offlineDownloading = emptySet()
                collectionDownloadLabel = null
                collectionDownloadProgress = 0f
            }
        }
    }

    fun startRadio(stationId: String, stationTitle: String, stationTracks: List<SonusOnlineTrack>, genreHint: String = "") {
        if (stationTracks.isEmpty()) {
            Toast.makeText(context,"Ainda não há músicas suficientes para esta rádio.",Toast.LENGTH_SHORT).show(); return
        }
        if (metered && !playbackPrefs.mobilePlayback) {
            Toast.makeText(context,"SONUS Stream está configurado para usar somente Wi‑Fi.",Toast.LENGTH_SHORT).show(); return
        }
        val playerService = service ?: run {
            Toast.makeText(context,"Player ainda está iniciando. Tente novamente.",Toast.LENGTH_SHORT).show(); return
        }
        if (radioPreparing) return
        radioPreparing = true
        selectedRadioStationId = stationId
        scope.launch {
            try {
                val start = withContext(Dispatchers.Default) {
                    SonusRadioEngine.prepare(
                        context = context,
                        stationId = stationId,
                        stationTitle = stationTitle,
                        tracks = stationTracks,
                        repository = repo,
                        boostedIds = emptySet(),
                        genreHint = genreHint
                    )
                }
                if (start == null) {
                    Toast.makeText(context,"Não foi possível preparar esta rádio. Tente novamente.",Toast.LENGTH_LONG).show()
                    return@launch
                }
                playerService.setQueue(start.queue, start.index, false)
                playerService.setRepeatMode(0)
                playerService.playIndex(start.index, true, start.startPositionMs)
                onTrack("SONUS Rádio: $stationTitle", true, null)
                Toast.makeText(context,"📻 $stationTitle",Toast.LENGTH_SHORT).show()
            } catch (t: Throwable) {
                if (t !is kotlinx.coroutines.CancellationException) Toast.makeText(context,t.message ?: "Falha ao preparar a rádio.",Toast.LENGTH_LONG).show()
            } finally {
                radioPreparing = false
            }
        }
    }

    /** Mostra a estação sem carregar músicas; a biblioteca só é consultada após o toque. */
    fun startRadioFromCatalog(stationId: String, stationTitle: String, genreName: String = "") {
        if (radioPreparing) return
        if (metered && !playbackPrefs.mobilePlayback) {
            Toast.makeText(context,"SONUS Stream está configurado para usar somente Wi‑Fi.",Toast.LENGTH_SHORT).show(); return
        }
        radioPreparing = true
        selectedRadioStationId = stationId
        scope.launch {
            var handedOffToPlayer = false
            try {
                var localSources = sourceGenres
                var localTracks = sourceTrackMap
                var localPublished = published
                if (!hasSourceSnapshot) {
                    val cached = withContext(Dispatchers.IO) { repo.cachedInitialStreamSnapshot() }
                    localSources = cached.genres
                    localTracks = cached.trackMap
                    localPublished = published
                }
                if (!catalogRefreshChecked && playbackPrefs.catalogRefreshMinutes != 0 && playbackPrefs.dueForCatalogRefresh()) {
                    catalogRefreshChecked = true
                    val latestPublished = withContext(Dispatchers.IO) {
                        runCatching { repo.refreshPublishedGenres() }.getOrDefault(localPublished)
                    }
                    localPublished = latestPublished
                    val fresh = withContext(Dispatchers.IO) {
                        runCatching { repo.refreshCatalogIfChanged(force = true) }.getOrNull()
                    }
                    if (fresh != null) {
                        localSources = fresh.keys.toList()
                        localTracks = fresh
                        playbackPrefs.lastCatalogRefreshAt = System.currentTimeMillis()
                    }
                }
                val projected = withContext(Dispatchers.Default) {
                    projectOfficialStreamGenres(context, localSources, localTracks, localPublished)
                }
                sourceGenres = localSources
                sourceTrackMap = localTracks
                published = localPublished
                hasSourceSnapshot = true
                genres = projected.first
                trackMap = projected.second
                catalogLoaded = true
                recentIndex = withContext(Dispatchers.IO) { repo.cachedRecentlyAdded() }
                val selectedTracks = if (genreName.isBlank()) {
                    projected.second.values.flatten().distinctBy { it.fileId }
                } else {
                    projected.first.firstOrNull { it.name == genreName }
                        ?.let { projected.second[it].orEmpty() }.orEmpty()
                }
                radioPreparing = false
                startRadio(stationId, stationTitle, selectedTracks, genreName)
                handedOffToPlayer = true
            } catch (t: Throwable) {
                if (t !is kotlinx.coroutines.CancellationException) {
                    Toast.makeText(context, t.message ?: "Não foi possível carregar esta estação.", Toast.LENGTH_LONG).show()
                }
            } finally {
                if (!handedOffToPlayer) radioPreparing = false
            }
        }
    }

    LaunchedEffect(Unit) {
        // Uma leitura de eventos por abertura; sem polling constante da Linha do Tempo.
        delay(650L)
        timelineEntries = withContext(Dispatchers.IO) { streamPlatform.timelineForYear().getOrDefault(emptyList()) }
    }

    LaunchedEffect(Unit) {
        // Preferências locais do player são aplicadas sem iniciar consultas de catálogo/rede.
        service?.setPreloadNextEnabled(playbackPrefs.preloadNext)
        service?.setStreamFade(playbackPrefs.fadeInSeconds, playbackPrefs.fadeOutSeconds)
        service?.setCrossfade(playbackPrefs.crossfadeSeconds)
    }



    shareTrack?.let { target ->
        SonusShareDialog(
            source = target.toShareSource(),
            repo = repo,
            platform = streamPlatform,
            service = service,
            membershipTier = membershipTier,
            onRequestPlan = onRequestPlan,
            onClose = { shareTrack = null }
        )
    }

    reportTrack?.let { target ->
        var reason by remember(target.fileId) { mutableStateOf("Direitos autorais") }
        var details by remember(target.fileId) { mutableStateOf("") }
        var sending by remember(target.fileId) { mutableStateOf(false) }
        val reasons=listOf("Direitos autorais","Identidade/voz sem autorização","Conteúdo impróprio","Conteúdo ilegal","Outro")
        AlertDialog(
            onDismissRequest={if(!sending)reportTrack=null},
            title={Text("Denunciar problema com esta música",fontWeight=FontWeight.Black)},
            text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
                Text("${target.displayTitle} • ${target.artist.ifBlank { "SONUS Stream" }}",style=MaterialTheme.typography.bodySmall)
                LazyRow(horizontalArrangement=Arrangement.spacedBy(5.dp)){items(reasons){item->FilterChip(selected=reason==item,onClick={reason=item},label={Text(item,fontSize=8.sp)})}}
                OutlinedTextField(details,{details=it.take(1200)},label={Text("Detalhes opcionais")},modifier=Modifier.fillMaxWidth(),minLines=2)
                Text("A denúncia será analisada pela equipe. Ela não remove automaticamente a música.",style=MaterialTheme.typography.labelSmall)
            }},
            confirmButton={Button(enabled=!sending,onClick={sending=true;scope.launch{val r=SonusStreamPlatformRepository(context).reportPublishedTrack(target.fileId,target.displayTitle,target.artist,reason,details);sending=false;if(r.isSuccess){Toast.makeText(context,"Denúncia enviada para análise.",Toast.LENGTH_SHORT).show();reportTrack=null}else Toast.makeText(context,r.exceptionOrNull()?.message?:"Não foi possível enviar.",Toast.LENGTH_SHORT).show()}}){Text(if(sending)"Enviando…" else "Enviar")}},
            dismissButton={TextButton(enabled=!sending,onClick={reportTrack=null}){Text("Cancelar")}}
        )
    }

if (showCreatePlaylist) {
        AlertDialog(
            onDismissRequest={showCreatePlaylist=false;newPlaylistName=""},
            title={Text("Nova playlist")},
            text={OutlinedTextField(newPlaylistName,{newPlaylistName=it.take(48)},label={Text("Nome")},singleLine=true)},
            confirmButton={Button(onClick={playlists=repo.createPlaylist(newPlaylistName);showCreatePlaylist=false;newPlaylistName=""},enabled=newPlaylistName.trim().isNotBlank()){Text("Criar")}},
            dismissButton={TextButton(onClick={showCreatePlaylist=false;newPlaylistName=""}){Text("Cancelar")}}
        )
    }
    playlistTrack?.let { target ->
        AlertDialog(
            onDismissRequest={playlistTrack=null},
            title={Text("Adicionar à playlist")},
            text={
                Column(verticalArrangement=Arrangement.spacedBy(7.dp)) {
                    if(playlists.isEmpty()) Text("Crie uma playlist primeiro.",style=MaterialTheme.typography.bodySmall)
                    playlists.keys.forEach { name ->
                        OutlinedButton(onClick={playlists=repo.addToPlaylist(name,target.fileId);playlistTrack=null},modifier=Modifier.fillMaxWidth()){Text(name)}
                    }
                }
            },
            confirmButton={TextButton(onClick={playlistTrack=null;showCreatePlaylist=true}){Text("Nova playlist")}},
            dismissButton={TextButton(onClick={playlistTrack=null}){Text("Fechar")}}
        )
    }

    if (showStreamSettings) SonusStreamSettingsDialog(playbackPrefs,service,repo){showStreamSettings=false}
    if(showStreamAnalytics) SonusStreamUserAnalyticsDialog{showStreamAnalytics=false}
    if(showStreamUpload){
        // O painel real de envio é aberto pela Central do Artista existente.
        LaunchedEffect(Unit){showStreamUpload=false;onCreatorCenter()}
    }
    pendingMobileTrack?.let { pending ->
        AlertDialog(
            onDismissRequest={pendingMobileTrack=null},
            title={Text("Você está usando dados móveis",fontWeight=FontWeight.Black)},
            text={Text("A reprodução online pode consumir sua franquia de internet. Você pode continuar agora ou limitar o SONUS Stream ao Wi‑Fi.")},
            confirmButton={Button(onClick={playbackPrefs.mobileWarningSeen=true;val request=pendingMobileTrack;pendingMobileTrack=null;request?.let{playContext(it.tracks,it.clicked,it.source,it.genreContinuation,it.openFullPlayerAfterStart)}}){Text("Continuar")}},
            dismissButton={TextButton(onClick={playbackPrefs.mobilePlayback=false;playbackPrefs.mobileWarningSeen=true;pendingMobileTrack=null}){Text("Usar só Wi‑Fi")}}
        )
    }

    val currentOnlineRef = remember(playback.current?.uri) { SonusOnlineRef.parse(playback.current?.uri) }
    val currentOnlineTrack = remember(currentOnlineRef?.fileId, allVisibleTracks) {
        currentOnlineRef?.fileId?.let { id -> allVisibleTracks.firstOrNull { it.fileId == id } }
    }
    val addedRecentlyTracks = remember(allVisibleTracks, recentIndex, catalogLoaded, published) {
        if (!catalogLoaded) recentIndex.filter { isPublishedStreamTrack(repo, it, published) }.take(12)
        else if (recentIndex.isNotEmpty()) {
            val visibleIds = allVisibleTracks.asSequence().map { it.fileId }.toSet()
            recentIndex.filter { it.fileId in visibleIds }.take(12)
        } else repo.recentlyAdded(allVisibleTracks)
    }
    val recentHistoryTracks = remember(allVisibleTracks) { repo.recentTracks(allVisibleTracks) }
    val favoriteLibraryTracks = remember(allVisibleTracks, favorites) { repo.favoriteTracks(allVisibleTracks) }
    val catholicLibraryTracks = remember(allVisibleTracks, catalogGenreByFile) {
        allVisibleTracks.filter { sonusGenreFamily(effectiveSonusGenre(it, catalogGenreByFile)) == "catolica" }
    }
    val sleepPlaylistTracks = remember(catholicLibraryTracks) {
        catholicLibraryTracks.sortedByDescending { themedTrackScore(it, listOf("dormir","sono","noite","paz","descanso","calma","manto","maria","instrumental","suave")) }.take(30)
    }
    val prayerPlaylistTracks = remember(catholicLibraryTracks) {
        catholicLibraryTracks.sortedByDescending { themedTrackScore(it, listOf("orar","oração","oracao","jesus","maria","graça","graca","fé","fe","senhor","deus","santo")) }.take(30)
    }
    Box(Modifier.fillMaxSize()) {
        if (networkAvailable) {
        LazyColumn(
            Modifier.fillMaxSize().padding(horizontal = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(top = 4.dp, bottom = if (currentOnlineTrack != null) 104.dp else 30.dp)
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(top=3.dp,bottom=3.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                        Text("SONUS",fontWeight=FontWeight.Black,fontSize=15.sp,color=accent,maxLines=1)
                        Text("STREAM",fontWeight=FontWeight.Bold,fontSize=8.sp,color=Color.White.copy(alpha=.54f),letterSpacing=1.6.sp)
                    }
                    Row(horizontalArrangement=Arrangement.spacedBy(4.dp),verticalAlignment=Alignment.CenterVertically){
                        SonusTopActionChip("Enviar música", Icons.Default.LibraryMusic, Color(0xFF52E6C4)) { showStreamUpload=true }
                        SonusTopActionChip("Analytics", Icons.Default.Insights, Color(0xFFFFC857)) { showStreamAnalytics=true }
                        SonusTopActionChip("Busca", Icons.Default.Search, Color(0xFF75B7FF)) { searchExpanded=!searchExpanded; if(!searchExpanded) searchQuery="" }
                        SonusTopActionChip("Ajustes", Icons.Default.Settings, Color(0xFFFFD36A)) { showStreamSettings=true }
                    }
                }
            }
            if(searchExpanded)item{OutlinedTextField(searchQuery,{searchQuery=it.take(120)},modifier=Modifier.fillMaxWidth(),singleLine=true,placeholder={Text("Música, artista ou gênero")},leadingIcon={Icon(Icons.Default.Search,null)},trailingIcon={IconButton(onClick={searchQuery="";searchExpanded=false}){Icon(Icons.Default.Close,"Fechar")}})}
            item {
                val shape = RoundedCornerShape(24.dp)
                val timelineTransition = rememberInfiniteTransition(label="timeline-gradient")
                val timelinePhase by timelineTransition.animateFloat(
                    initialValue=0f,
                    targetValue=1f,
                    animationSpec=infiniteRepeatable(
                        animation=tween(durationMillis=12_000,easing=LinearEasing),
                        repeatMode=RepeatMode.Reverse
                    ),
                    label="timeline-phase"
                )
                val deepBlue=Color(0xFF173E8F); val blue=Color(0xFF245CCB); val purple=Color(0xFF6C3BC1); val deepPurple=Color(0xFF43258D)
                val timelineBrush=Brush.horizontalGradient(
                    listOf(
                        lerp(deepBlue,blue,timelinePhase),
                        lerp(blue,purple,timelinePhase),
                        lerp(purple,deepPurple,timelinePhase)
                    )
                )
                Box(
                    Modifier.fillMaxWidth().height(66.dp).clip(shape)
                        .background(timelineBrush)
                        .clickable {
                            if (!timelineReady) {
                                Toast.makeText(context,"Linha do tempo em construção, ouça um pouco mais.",Toast.LENGTH_SHORT).show()
                            } else if (timelineTracks.isNotEmpty()) {
                                playContext(timelineTracks,timelineTracks.first(),"Linha do Tempo $timelineYear")
                            } else {
                                loadCachedCatalog()
                                Toast.makeText(context,"Carregando as músicas da sua Linha do Tempo. Toque novamente quando o catálogo aparecer.",Toast.LENGTH_SHORT).show()
                            }
                        }
                ) {
                    Row(Modifier.fillMaxSize().padding(horizontal=17.dp),verticalAlignment=Alignment.CenterVertically) {
                        Surface(shape=RoundedCornerShape(16.dp),color=Color.White.copy(alpha=.08f)) {
                            Box(Modifier.size(46.dp),contentAlignment=Alignment.Center){
                                Image(painterResource(R.drawable.sonus_timeline_stopwatch),"Linha do Tempo",Modifier.size(42.dp),contentScale=ContentScale.Fit)
                            }
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Linha do Tempo",color=Color.White,fontWeight=FontWeight.Black,fontSize=16.sp)
                            Text(if(timelineReady) "OUVIR" else "linha do tempo em construção",color=Color.White.copy(alpha=.62f),fontSize=8.sp,fontWeight=if(timelineReady)FontWeight.Bold else FontWeight.Normal)
                        }
                        Icon(if(timelineReady) Icons.Default.PlayArrow else Icons.Default.LockClock,null,tint=Color.White.copy(alpha=.72f))
                    }
                }
            }
            if(loading)item{LinearProgressIndicator(Modifier.fillMaxWidth(),color=accent)}
            if(searchQuery.isNotBlank()){
                item{Text("Resultados da busca",fontWeight=FontWeight.Black,fontSize=18.sp)}
                if(searchResults.isEmpty() && searchArtistResults.isEmpty() && searchPlaylistResults.isEmpty() && searchGenreResults.isEmpty()) {
                    item{Text("Nenhum resultado encontrado para “$searchQuery”.",fontSize=10.sp,color=Color.White.copy(alpha=.58f))}
                }
                if(searchResults.isNotEmpty()) item { Text("Músicas",fontWeight=FontWeight.Bold,fontSize=12.sp,color=accent) }
                items(searchResults.take(30),key={"search-${it.fileId}"}){track->SonusOnlineTrackRow(track,repo,accent,track.fileId in favorites,{favorites=repo.toggleFavorite(track.fileId)},{playlistTrack=track},{shareTrack=track},{reportTrack=track}){playContext(searchResults,it,"Busca",genreContinuation=true)}}
                if(searchArtistResults.isNotEmpty()) item { Text("Artistas",fontWeight=FontWeight.Bold,fontSize=12.sp,color=accent) }
                items(searchArtistResults,key={"search-artist-${normalizeStreamSearch(it.first().artist)}"}) { tracks ->
                    val first=tracks.first()
                    Surface(shape=RoundedCornerShape(12.dp),color=Color(0xFF151923),modifier=Modifier.fillMaxWidth().clickable { selectedArtistProfile=first to tracks }) {
                        Row(Modifier.padding(10.dp),verticalAlignment=Alignment.CenterVertically) { Icon(Icons.Default.Person,null,tint=Color(0xFF75D9C4)); Spacer(Modifier.width(9.dp)); Column(Modifier.weight(1f)){Text(first.artist,fontWeight=FontWeight.Bold);Text("${tracks.size} música(s)",fontSize=9.sp,color=Color.White.copy(alpha=.56f))}; Icon(Icons.Default.ChevronRight,null) }
                    }
                }
                if(searchPlaylistResults.isNotEmpty()) item { Text("Playlists",fontWeight=FontWeight.Bold,fontSize=12.sp,color=accent) }
                items(searchPlaylistResults,key={"search-playlist-$it"}) { name ->
                    Surface(shape=RoundedCornerShape(12.dp),color=Color(0xFF17141E),modifier=Modifier.fillMaxWidth().clickable { activeLibrarySection="playlists"; selectedPlaylist=name }) {
                        Row(Modifier.padding(10.dp),verticalAlignment=Alignment.CenterVertically) { Icon(Icons.Default.QueueMusic,null,tint=Color(0xFFFFC857)); Spacer(Modifier.width(9.dp)); Text(name,Modifier.weight(1f),fontWeight=FontWeight.Bold); Text("${playlists[name].orEmpty().size}",fontSize=9.sp) }
                    }
                }
                if(searchGenreResults.isNotEmpty()) item { Text("Gêneros",fontWeight=FontWeight.Bold,fontSize=12.sp,color=accent) }
                items(searchGenreResults,key={"search-genre-${it.path}"}) { genre ->
                    Surface(shape=RoundedCornerShape(12.dp),color=Color(0xFF151923),modifier=Modifier.fillMaxWidth().clickable { selectedGenre=genre;selectedGenreTab="Músicas";loadGenreCache(genre) }) {
                        Row(Modifier.padding(10.dp),verticalAlignment=Alignment.CenterVertically) { Icon(genreIcon(genre.name),null,tint=accent); Spacer(Modifier.width(9.dp)); Text(genre.name,Modifier.weight(1f),fontWeight=FontWeight.Bold); Icon(Icons.Default.ChevronRight,null) }
                    }
                }
            }

            item {
                Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Icon(Icons.Default.Radio,null,tint=Color(0xFFFFD36A)); Spacer(Modifier.width(7.dp))
                        Column {
                            Text("SONUS Rádio",fontWeight=FontWeight.Black,fontSize=18.sp)
                            Text("Estações leves; a programação é preparada quando você escolhe uma rádio.",fontSize=9.sp,color=Color.White.copy(alpha=.58f))
                        }
                    }
                    Text("Escolha um estilo. As músicas só são consultadas quando você toca na estação.",fontSize=9.sp,color=Color.White.copy(alpha=.58f))
                    LazyRow(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        item {
                            SonusRadioStationChip("📻 Para Você",selectedRadioStationId=="for_you") {
                                startRadioFromCatalog("for_you","Rádio Para Você")
                            }
                        }
                        items(visibleGenres,key={"radio-${normalizeStreamSearch(it.name)}"}) { genre ->
                            val stationId="genre:${normalizeStreamSearch(genre.name)}"
                            SonusRadioStationChip("📻 ${genre.name}",selectedRadioStationId==stationId) {
                                startRadioFromCatalog(stationId,"Rádio ${genre.name}",genre.name)
                            }
                        }
                    }
                    if (radioPreparing) {
                        Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                            CircularProgressIndicator(Modifier.size(15.dp),strokeWidth=2.dp,color=Color(0xFFFFD36A))
                            Text("Preparando estação…",fontSize=9.sp,color=Color.White.copy(alpha=.68f))
                        }
                    }
                }
            }

            item { Text("Acesso rápido",fontWeight=FontWeight.Black,fontSize=18.sp) }
            item {
                LazyRow(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    item { SonusStreamQuickActionCard("Adicionadas","Novas músicas",Icons.Default.LibraryMusic,Color(0xFF72C7FF)) { activeLibrarySection="added"; recentIndex=repo.cachedRecentlyAdded(); if (recentIndex.isEmpty() && !catalogLoaded) loadCachedCatalog() } }
                    item { SonusStreamQuickActionCard("Artistas","Explorar artistas",Icons.Default.Person,Color(0xFF75D9C4)) { activeLibrarySection="artists"; loadCachedCatalog() } }
                    item { SonusStreamQuickActionCard("Playlists","Suas coleções",Icons.Default.QueueMusic,Color(0xFFFFC857)) { activeLibrarySection="playlists"; loadCachedCatalog() } }
                    item { SonusStreamQuickActionCard("Últimas tocadas","Seu histórico",Icons.Default.History,Color(0xFFB9A0FF)) { activeLibrarySection="recent"; loadCachedCatalog() } }
                    item { SonusStreamQuickActionCard("Favoritas","Sua seleção",Icons.Default.Favorite,Color(0xFFFF8EAB)) { activeLibrarySection="favorites"; loadCachedCatalog() } }
                }
            }

            activeLibrarySection?.let { section ->
                item {
                    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
                        Text(when(section){"added"->"Adicionadas recentemente";"artists"->"Artistas";"playlists"->"Playlists";"recent"->"Últimas tocadas";else->"Favoritas"},fontWeight=FontWeight.Black,fontSize=17.sp,modifier=Modifier.weight(1f))
                        TextButton(onClick={activeLibrarySection=null}) { Icon(Icons.Default.Close,null); Text("Fechar") }
                    }
                    if (section == "added") {
                        Text("Faixas já disponíveis no catálogo. Use o painel de gerenciamento para revisar letras e metadados.",fontSize=9.sp,color=Color.White.copy(alpha=.58f))
                        TextButton(onClick=onCreatorCenter) { Icon(Icons.Default.Edit,null); Spacer(Modifier.width(5.dp)); Text("Gerenciar letras e metadados") }
                    }
                }
                when(section) {
                    "added" -> {
                        if (addedRecentlyTracks.isEmpty()) item { Text(if(loading) "Preparando sua lista recente…" else "Ainda não há músicas recentes no catálogo salvo. Toque em Atualizar para sincronizar.",fontSize=11.sp,color=Color.White.copy(alpha=.65f)) }
                        items(addedRecentlyTracks.take(50),key={"added-${it.fileId}"}) { track ->
                            SonusOnlineTrackRow(track,repo,accent,track.fileId in favorites,{favorites=repo.toggleFavorite(track.fileId)},{playlistTrack=track},{shareTrack=track},{reportTrack=track},showGenreStatus=true,genreStatusLabel=catalogGenreByFile[track.fileId]
                                ?: SonusMediaStandards.canonicalGenre(track.genre).takeIf { it in SonusMediaStandards.genres }
                                ?: "Gênero não informado") { playContext(addedRecentlyTracks,track,"Adicionadas recentemente") }
                        }
                    }
                    "recent" -> {
                        if (recentHistoryTracks.isEmpty()) item { Text("Seu histórico aparecerá aqui depois que você ouvir músicas.",fontSize=11.sp,color=Color.White.copy(alpha=.65f)) }
                        items(recentHistoryTracks.take(50),key={"history-${it.fileId}"}) { track ->
                            SonusOnlineTrackRow(track,repo,accent,track.fileId in favorites,{favorites=repo.toggleFavorite(track.fileId)},{playlistTrack=track},{shareTrack=track},{reportTrack=track}) { playContext(recentHistoryTracks,track,"Últimas tocadas") }
                        }
                    }
                    "favorites" -> {
                        if (favoriteLibraryTracks.isEmpty()) item { Text("Toque no coração de uma música para guardá-la aqui.",fontSize=11.sp,color=Color.White.copy(alpha=.65f)) }
                        items(favoriteLibraryTracks.take(50),key={"favorite-${it.fileId}"}) { track ->
                            SonusOnlineTrackRow(track,repo,accent,true,{favorites=repo.toggleFavorite(track.fileId)},{playlistTrack=track},{shareTrack=track},{reportTrack=track}) { playContext(favoriteLibraryTracks,track,"Favoritas") }
                        }
                    }
                    "artists" -> {
                        if (artistPlaylists.isEmpty()) item { Text("Nenhum artista disponível no catálogo salvo.",fontSize=11.sp,color=Color.White.copy(alpha=.65f)) }
                        items(artistPlaylists.take(60),key={list->"artist-${artistIds[list.first().fileId].orEmpty().ifBlank{normalizeStreamSearch(list.first().artist)}}"}) { list ->
                            val first=list.first()
                            Surface(shape=RoundedCornerShape(14.dp),color=Color(0xFF151923),border=BorderStroke(1.dp,Color(0xFF75D9C4).copy(alpha=.20f)),modifier=Modifier.fillMaxWidth().clickable { selectedArtistProfile=first to list }) {
                                Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically) {
                                    Icon(Icons.Default.Person,null,tint=Color(0xFF75D9C4),modifier=Modifier.size(23.dp)); Spacer(Modifier.width(10.dp))
                                    Column(Modifier.weight(1f)) { Text(first.artist,fontWeight=FontWeight.Bold); Text("${list.size} música(s)",fontSize=9.sp,color=Color.White.copy(alpha=.58f)) }
                                    Icon(Icons.Default.ChevronRight,null,tint=Color.White.copy(alpha=.55f))
                                }
                            }
                        }
                    }
                    "playlists" -> {
                        item { Row(verticalAlignment=Alignment.CenterVertically) { Text("Suas playlists",fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f)); TextButton(onClick={showCreatePlaylist=true}) { Icon(Icons.Default.Add,null); Text("Nova") } } }
                        if (playlists.isEmpty()) item { Text("Crie uma playlist para organizar suas músicas.",fontSize=11.sp,color=Color.White.copy(alpha=.65f)) }
                        items(playlists.keys.toList(),key={"playlist-${it}"}) { name ->
                            val count=playlists[name].orEmpty().size
                            Surface(shape=RoundedCornerShape(14.dp),color=Color(0xFF17141E),border=BorderStroke(1.dp,accent.copy(alpha=.18f)),modifier=Modifier.fillMaxWidth().clickable { selectedPlaylist=if(selectedPlaylist==name)null else name }) {
                                Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically) { Icon(Icons.Default.QueueMusic,null,tint=accent); Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) { Text(name,fontWeight=FontWeight.Bold); Text("$count música(s)",fontSize=9.sp,color=Color.White.copy(alpha=.55f)) }; Icon(Icons.Default.ChevronRight,null) }
                            }
                        }
                        item { Text("Álbuns do catálogo",fontWeight=FontWeight.Bold) }
                        if (albumGroups.isEmpty()) item {
                            Text("Os álbuns aparecem aqui quando as músicas tiverem essa informação nos metadados.",fontSize=10.sp,color=Color.White.copy(alpha=.58f))
                        }
                        items(albumGroups.take(60), key={ group ->
                            val first = group.first()
                            "album-${normalizeStreamSearch(first.album)}-${normalizeStreamSearch(first.artist)}"
                        }) { list ->
                            val first = list.first()
                            val albumName = first.album
                            val allDownloaded = list.all { track ->
                                SonusOnlineRef.parse(repo.queueItem(track).uri)?.let { SonusOfflineDownloadManager.isDownloaded(context, it) } == true
                            }
                            Surface(shape=RoundedCornerShape(14.dp),color=Color(0xFF17141E),border=BorderStroke(1.dp,Color(0xFF72C7FF).copy(alpha=.18f))) {
                                Row(Modifier.fillMaxWidth().clickable {
                                    playContext(list, list.first(), "Álbum • $albumName")
                                }.padding(start=12.dp,top=9.dp,bottom=9.dp,end=4.dp),verticalAlignment=Alignment.CenterVertically) {
                                    Icon(Icons.Default.Album,null,tint=Color(0xFF72C7FF),modifier=Modifier.size(22.dp))
                                    Spacer(Modifier.width(10.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(albumName,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis)
                                        Text("${first.artist} • ${list.size} música(s)",fontSize=9.sp,color=Color.White.copy(alpha=.58f),maxLines=1,overflow=TextOverflow.Ellipsis)
                                    }
                                    IconButton(onClick={downloadCollection(list, "Álbum $albumName")},enabled=collectionDownloadLabel==null) {
                                        Icon(if(allDownloaded) Icons.Default.DeleteSweep else Icons.Default.Download,
                                            if(allDownloaded) "Remover álbum offline" else "Baixar álbum",tint=if(allDownloaded) Color(0xFF6FE3B2) else accent)
                                    }
                                }
                            }
                        }
                        item { Text("Playlists SONUS",fontWeight=FontWeight.Bold) }
                        item {
                            LazyRow(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                                if (prayerPlaylistTracks.isNotEmpty()) item { SonusStreamQuickActionCard("Músicas para orar","Seleção católica",Icons.Default.FavoriteBorder,Color(0xFFE5C6FF)) { prayerPlaylistTracks.firstOrNull()?.let { playContext(prayerPlaylistTracks,it,"Playlist • Músicas para orar") } } }
                                if (sleepPlaylistTracks.isNotEmpty()) item { SonusStreamQuickActionCard("Católicas para dormir","Paz e descanso",Icons.Default.NightsStay,Color(0xFF8EB9FF)) { sleepPlaylistTracks.firstOrNull()?.let { playContext(sleepPlaylistTracks,it,"Playlist • Católicas para dormir") } } }
                            }
                        }
                    }
                }
            }

            item {
                Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Gêneros",fontWeight=FontWeight.Black,fontSize=18.sp)
                        Text("18 estilos • toque no coração para priorizar",fontSize=9.sp,color=Color.White.copy(alpha=.52f))
                    }
                    TextButton(onClick={refresh()},enabled=!loading) { Icon(Icons.Default.Refresh,null); Text("Atualizar") }
                }
            }
            item {
                Column(verticalArrangement=Arrangement.spacedBy(10.dp)) {
                    visibleGenres.chunked(2).forEach { pair ->
                        Row(horizontalArrangement=Arrangement.spacedBy(10.dp), modifier=Modifier.fillMaxWidth()) {
                            pair.forEach { genre ->
                                val count = trackMap[genre].orEmpty().size
                                val palette = genrePalette(genre.name)
                                val isFavorite = genre.name in favoriteGenres
                                Surface(
                                    modifier = Modifier.weight(1f).height(116.dp)
                                        .clickable { selectedGenre=genre; selectedGenreTab="Músicas"; loadGenreCache(genre) },
                                    shape = RoundedCornerShape(20.dp), color = Color.Transparent,
                                    border = BorderStroke(1.dp, Color.White.copy(alpha=.14f)), shadowElevation = 2.dp
                                ) {
                                    Box(Modifier.background(Brush.linearGradient(palette)).padding(12.dp)) {
                                        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Surface(shape=RoundedCornerShape(12.dp), color=Color.White.copy(alpha=.16f)) {
                                                    Icon(genreIcon(genre.name), null, tint=Color.White, modifier=Modifier.padding(8.dp).size(22.dp))
                                                }
                                                Spacer(Modifier.weight(1f))
                                                IconButton(onClick={ favoriteGenres=genrePreferences.toggleFavoriteGenre(genre.name) }, modifier=Modifier.size(32.dp)) {
                                                    Icon(if(isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                                        if(isFavorite) "Remover gênero favorito" else "Favoritar gênero", tint=Color.White, modifier=Modifier.size(19.dp))
                                                }
                                            }
                                            Column(verticalArrangement=Arrangement.spacedBy(2.dp)) {
                                                Text(genre.name,color=Color.White,fontWeight=FontWeight.ExtraBold,fontSize=11.sp,lineHeight=12.sp,maxLines=2,overflow=TextOverflow.Ellipsis)
                                                Text(
                                                    if (!catalogLoaded) "Toque para explorar"
                                                    else if(count==1) "1 música" else "$count músicas",
                                                    color=Color.White.copy(alpha=.78f), fontSize=9.sp, maxLines=1
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                            if (pair.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }

            selectedGenre?.let { genre ->
                val genreTracks=trackMap[genre].orEmpty()
                item {
                    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text(genre.name,fontWeight=FontWeight.Black,fontSize=16.sp); Text("Conteúdo carregado ao abrir este gênero",fontSize=8.sp,color=Color.White.copy(alpha=.55f)) }
                        TextButton(onClick={selectedGenre=null}) { Icon(Icons.Default.Close,null); Text("Fechar") }
                    }
                }
                item { Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) { listOf("Músicas","Artistas","Playlists").forEach { tab -> FilterChip(selected=selectedGenreTab==tab,onClick={selectedGenreTab=tab},label={Text(tab,fontSize=9.sp)}) } } }
                when(selectedGenreTab) {
                    "Artistas" -> {
                        val artists=genreTracks.filter { it.artist.isNotBlank() }.groupBy { normalizeStreamSearch(it.artist) }.values.sortedBy { it.first().artist.lowercase(Locale.ROOT) }
                        items(artists,key={"genre-artist-${normalizeStreamSearch(it.first().artist)}"}) { artistTracks ->
                            val first=artistTracks.first()
                            Surface(shape=RoundedCornerShape(13.dp),color=Color(0xFF151923),modifier=Modifier.fillMaxWidth().clickable { selectedArtistProfile=first to artistTracks }) {
                                Row(Modifier.padding(11.dp),verticalAlignment=Alignment.CenterVertically) { Icon(Icons.Default.Person,null,tint=accent); Spacer(Modifier.width(8.dp)); Text(first.artist,Modifier.weight(1f),fontWeight=FontWeight.Bold); Text("${artistTracks.size}",fontSize=9.sp) }
                            }
                        }
                    }
                    "Playlists" -> {
                        if (genreTracks.isNotEmpty()) item { SonusStreamQuickActionCard("Mix ${genre.name}","${genreTracks.size} músicas",genreIcon(genre.name),accent) { genreTracks.firstOrNull()?.let { playContext(genreTracks,it,"Playlist • ${genre.name}") } } }
                    }
                    else -> {
                        if (genreTracks.isEmpty()) item { Text(if(loading) "Lendo músicas deste gênero…" else "Nenhuma música deste gênero no cache. Atualize o catálogo para buscar novos arquivos.",fontSize=10.sp,color=Color.White.copy(alpha=.62f)) }
                        items(genreTracks.take(60),key={"genre-track-${it.fileId}"}) { track ->
                            SonusOnlineTrackRow(track,repo,accent,track.fileId in favorites,{favorites=repo.toggleFavorite(track.fileId)},{playlistTrack=track},{shareTrack=track},{reportTrack=track}) { playContext(genreTracks,track,"Gênero • ${genre.name}") }
                        }
                    }
                }
            }

            if (collectionDownloadLabel != null) item {
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("Baixando $collectionDownloadLabel • ${(collectionDownloadProgress * 100).toInt()}%", fontSize = 10.sp, color = accent, fontWeight = FontWeight.Bold)
                    LinearProgressIndicator(progress = { collectionDownloadProgress }, modifier = Modifier.fillMaxWidth(), color = accent)
                }
            }
            if (offlineItems.isNotEmpty()) {
                item { Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CloudDone, null, tint = Color(0xFF6FE3B2)); Spacer(Modifier.width(7.dp))
                    Text("Biblioteca offline", fontWeight = FontWeight.Black, fontSize = 18.sp, modifier = Modifier.weight(1f))
                    Text("${offlineItems.size} faixas", fontSize = 9.sp, color = Color.White.copy(alpha = .58f))
                } }
                items(offlineItems, key = { "offline:${it.sourceKey}:${it.fileId}" }) { offline ->
                    Surface(shape = RoundedCornerShape(13.dp), color = Color(0xFF141923), border = BorderStroke(1.dp, Color(0xFF6FE3B2).copy(alpha = .16f))) {
                        Row(Modifier.fillMaxWidth().clickable {
                            val queue = offlineItems.map { it.queueItem() }
                            val idx = offlineItems.indexOfFirst { it.fileId == offline.fileId && it.sourceKey == offline.sourceKey }.coerceAtLeast(0)
                            service?.setQueue(queue, idx, true)
                            onTrack("SONUS Stream Offline: ${offline.title}", true, null)
                        }.padding(horizontal = 11.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.OfflinePin, null, tint = Color(0xFF6FE3B2))
                            Spacer(Modifier.width(9.dp))
                            Column(Modifier.weight(1f)) {
                                Text(offline.title, fontWeight = FontWeight.Bold, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(offline.artist.ifBlank { "SONUS Stream" }, fontSize = 8.sp, color = Color.White.copy(alpha = .55f), maxLines = 1)
                            }
                            IconButton(onClick = {
                                SonusOfflineDownloadManager.remove(context, SonusOnlineRef(offline.fileId, offline.size.coerceAtLeast(1L), offline.sourceKey))
                                offlineItems = SonusOfflineDownloadManager.list(context)
                            }) { Icon(Icons.Default.DeleteOutline, "Remover download", tint = Color.White.copy(alpha = .65f)) }
                        }
                    }
                }
            }
            selectedPlaylist?.let { playlistName ->
                val pts = repo.playlistTracks(playlistName, allVisibleTracks)
                if (pts.isNotEmpty()) item {
                    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text("Playlist • $playlistName", Modifier.weight(1f), fontWeight = FontWeight.Black, fontSize = 12.sp)
                            val allDownloaded = pts.all { t -> SonusOnlineRef.parse(repo.queueItem(t).uri)?.let { SonusOfflineDownloadManager.isDownloaded(context, it) } == true }
                            IconButton(onClick = { downloadCollection(pts, "Playlist $playlistName") }, enabled = collectionDownloadLabel == null) {
                                Icon(if (allDownloaded) Icons.Default.DeleteSweep else Icons.Default.Download, if (allDownloaded) "Remover playlist offline" else "Baixar playlist", tint = accent)
                            }
                        }
                        SonusMusicShelf("Músicas", pts, repo, favorites, accent, onFavorite = { id -> favorites = repo.toggleFavorite(id) }) { playContext(pts, it, "Playlist") }
                    }
                }
            }
            error?.let{message->item{Surface(shape=RoundedCornerShape(15.dp),color=Color(0xFF6D2431).copy(alpha=.28f),border=BorderStroke(1.dp,Color(0xFFFF6E86).copy(alpha=.35f))){Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.CloudOff,null,tint=Color(0xFFFF91A3));Spacer(Modifier.width(8.dp));Text(message,Modifier.weight(1f),color=Color.White.copy(alpha=.85f),fontSize=10.sp)}}}}
        }
        } else {
            LazyColumn(
                Modifier.fillMaxSize().padding(horizontal = 14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(top = 16.dp, bottom = 30.dp)
            ) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CloudOff, null, tint = Color(0xFFFFC16B), modifier = Modifier.size(22.dp))
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text("SONUS Stream • Offline", fontWeight = FontWeight.Black, fontSize = 17.sp, color = accent)
                            Text("Sem internet • somente músicas baixadas", fontSize = 10.sp, color = Color.White.copy(alpha = .62f))
                        }
                    }
                }
                if (offlineItems.isEmpty()) {
                    item {
                        Surface(shape = RoundedCornerShape(18.dp), color = Color(0xFF17141E), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                Icon(Icons.Default.LibraryMusic, null, tint = Color(0xFF6FE3B2), modifier = Modifier.size(30.dp))
                                Text("Nenhuma música disponível offline", fontWeight = FontWeight.Bold)
                                Text("Quando voltar a ter conexão, baixe faixas pelo player ou por uma playlist/álbum. Elas aparecerão aqui.", fontSize = 11.sp, color = Color.White.copy(alpha = .65f))
                            }
                        }
                    }
                } else {
                    item { Text("Biblioteca offline • ${offlineItems.size} faixas", fontWeight = FontWeight.Black, fontSize = 14.sp) }
                    items(offlineItems, key = { "offline-only:${it.sourceKey}:${it.fileId}" }) { offline ->
                        Surface(shape = RoundedCornerShape(13.dp), color = Color(0xFF141923), border = BorderStroke(1.dp, Color(0xFF6FE3B2).copy(alpha = .18f))) {
                            Row(Modifier.fillMaxWidth().clickable {
                                val queue = offlineItems.map { it.queueItem() }
                                val idx = offlineItems.indexOfFirst { it.fileId == offline.fileId && it.sourceKey == offline.sourceKey }.coerceAtLeast(0)
                                service?.setQueue(queue, idx, true)
                                onTrack("SONUS Stream Offline: ${offline.title}", true, null)
                            }.padding(horizontal = 12.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.OfflinePin, null, tint = Color(0xFF6FE3B2))
                                Spacer(Modifier.width(9.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(offline.title, fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(offline.artist.ifBlank { "SONUS Stream" }, fontSize = 9.sp, color = Color.White.copy(alpha = .58f), maxLines = 1)
                                }
                                IconButton(onClick = {
                                    SonusOfflineDownloadManager.remove(context, SonusOnlineRef(offline.fileId, offline.size.coerceAtLeast(1L), offline.sourceKey))
                                    offlineItems = SonusOfflineDownloadManager.list(context)
                                }) { Icon(Icons.Default.DeleteOutline, "Remover download", tint = Color.White.copy(alpha = .7f)) }
                            }
                        }
                    }
                }
            }
        }
        if (networkAvailable) currentOnlineTrack?.let { track ->
            SonusStreamMiniPlayer(
                track = track,
                repo = repo,
                playing = playback.playing,
                progress = if (playback.durationMs > 0L) playback.positionMs.toFloat() / playback.durationMs.toFloat() else 0f,
                accent = accent,
                downloaded = currentOnlineRef?.let { SonusOfflineDownloadManager.isDownloaded(context, it) } == true,
                downloading = track.fileId in offlineDownloading,
                downloadProgress = offlineProgress[track.fileId] ?: 0f,
                onDownload = { downloadOne(track) },
                onPrevious = { service?.previous() },
                onToggle = { service?.toggle() },
                onNext = { service?.next(true) },
                onOpen = onOpenFullPlayer,
                modifier = Modifier.align(Alignment.BottomCenter).padding(horizontal = 10.dp, vertical = 8.dp)
            )
        }
        SonusDataUsageMiniMonitor(playbackPrefs.dataMonitor,Modifier.align(Alignment.TopStart).padding(top=48.dp,start=4.dp))
        selectedArtistProfile?.let { (first, artistTracks) ->
            val artistId = artistIds[first.fileId].orEmpty()
            SonusPublicArtistPage(
                artistName = first.artist,
                artistId = artistId,
                tracks = artistTracks,
                repo = repo,
                platform = streamPlatform,
                accent = accent,
                favorites = favorites,
                onFavoriteTrack = { id -> favorites = repo.toggleFavorite(id) },
                onBack = { selectedArtistProfile = null },
                onPlay = { chosen -> playContext(artistTracks, chosen, "Perfil do artista") }
            )
        }
    }

}

@Composable
private fun SonusStreamQuickActionCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accent: Color,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier.width(142.dp).height(88.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(17.dp),
        color = Color(0xFF131C2A),
        border = BorderStroke(1.dp, accent.copy(alpha = .34f)),
        shadowElevation = 2.dp
    ) {
        Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(accent.copy(alpha = .17f), Color(0xFF121B29), Color(0xFF101620)))).padding(10.dp)) {
            Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
                Icon(icon, contentDescription = title, tint = accent, modifier = Modifier.size(22.dp))
                Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                    Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(subtitle, color = Color.White.copy(alpha = .58f), fontSize = 8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

@Composable
private fun SonusRadioStationChip(label:String, selected:Boolean, onClick:()->Unit) {
    val yellow = if(selected) Color(0xFFFFD83D) else Color(0xFFF4C928)
    val textColor = Color(0xFF352B00)
    Surface(
        modifier=Modifier.clip(RoundedCornerShape(50)).clickable(onClick=onClick),
        shape=RoundedCornerShape(50),
        color=yellow,
        border=BorderStroke(1.dp,Color.Black.copy(alpha=if(selected).18f else .10f))
    ) {
        Box(Modifier.padding(horizontal=14.dp,vertical=9.dp)) {
            Text(label,color=textColor,fontWeight=if(selected)FontWeight.Black else FontWeight.ExtraBold,fontSize=10.sp,maxLines=1)
        }
    }
}


private fun canonicalSonusGenre(raw: String): String =
    SonusMediaStandards.canonicalGenre(raw).ifBlank { "Outros" }

private fun effectiveSonusGenre(track:SonusOnlineTrack, fallbackByFile:Map<Long,String>):String =
    track.genre.trim().ifBlank { fallbackByFile[track.fileId].orEmpty().trim() }

/**
 * 0.0.1: estações/gêneros do Stream agrupados EXATAMENTE como a SONUS Rádio do Stream faz: gênero real da faixa
 * (tag/catálogo) e, só quando falta, o gênero da pasta como reserva. Nomes de pasta genéricos ("Músicas") nunca viram estação.
 */
private fun isPublishedStreamTrack(
    repo: SonusOnlineMusicRepository,
    track: SonusOnlineTrack,
    publishedSources: Set<String>
): Boolean {
    val sourceName = when (repo.sourceKeyForTrack(track)) {
        "secondary" -> "MÚSICAS 2"
        "tertiary" -> "MÚSICAS 3"
        else -> "MÚSICAS"
    }
    return publishedSources.any { normalizeStreamSearch(it) == normalizeStreamSearch(sourceName) }
}

private fun officialStreamGenres(): List<SonusOnlineGenre> = SonusMediaStandards.genres.map { name ->
    val key = normalizeStreamSearch(name).replace(Regex("[^a-z0-9]+"), "-").trim('-')
    SonusOnlineGenre(name = name, path = "sonus-genre:official:$key")
}

private fun isInternalStreamSourceName(raw: String): Boolean {
    val n = normalizeStreamSearch(raw).replace(Regex("\\s+"), " ")
    return n == "musicas" || n.matches(Regex("musicas \\d+")) || n == "musica" || n.matches(Regex("musica \\d+"))
}

private fun officialGenreForTrack(context: Context, track: SonusOnlineTrack): String {
    val raw = track.genre.trim()
    val tagged = if (raw.isNotBlank() && !isInternalStreamSourceName(raw)) SonusMediaStandards.canonicalGenre(raw) else ""
    if (tagged in SonusMediaStandards.genres) return tagged
    val artistCategory = SonusArtistGenreCatalog.find(context, track.artist)?.category.orEmpty()
    val byArtist = SonusMediaStandards.canonicalGenre(artistCategory)
    return byArtist.takeIf { it in SonusMediaStandards.genres }.orEmpty()
}

/** Transforma as fontes técnicas em 18 gêneros virtuais; nomes internos nunca viram rótulos de gênero. */
private fun projectOfficialStreamGenres(
    context: Context,
    sourceGenres: List<SonusOnlineGenre>,
    sourceTrackMap: Map<SonusOnlineGenre, List<SonusOnlineTrack>>,
    publishedSources: Set<String>
): Pair<List<SonusOnlineGenre>, Map<SonusOnlineGenre, List<SonusOnlineTrack>>> {
    val official = officialStreamGenres()
    val publishedKeys = publishedSources.map(::normalizeStreamSearch).toSet()
    val allowedSources = sourceGenres.filter { normalizeStreamSearch(it.name) in publishedKeys }
    val grouped = linkedMapOf<String, MutableList<SonusOnlineTrack>>()
    allowedSources.forEach { source ->
        sourceTrackMap[source].orEmpty().forEach { track ->
            val genre = officialGenreForTrack(context, track)
            if (genre.isNotBlank()) grouped.getOrPut(genre) { mutableListOf() }.add(track.copy(genre = genre))
        }
    }
    val map = official.associateWith { genre ->
        grouped[genre.name].orEmpty().distinctBy { it.fileId }
            .sortedWith(compareBy<SonusOnlineTrack> { it.displayTitle.lowercase(Locale.ROOT) }.thenBy { it.fileId })
    }
    return official to map
}

internal fun sonusStreamGenreStations(
    genres: List<SonusOnlineGenre>,
    trackMap: Map<SonusOnlineGenre, List<SonusOnlineTrack>>,
    context: Context? = null
): List<Pair<String, List<SonusOnlineTrack>>> {
    val all = genres.flatMap { trackMap[it].orEmpty() }.distinctBy { it.fileId }
    val normalized = all.mapNotNull { track ->
        val raw = track.genre.takeUnless(::isInternalStreamSourceName).orEmpty()
        val tagged = SonusMediaStandards.canonicalGenre(raw).takeIf { it in SonusMediaStandards.genres }.orEmpty()
        val artist = context?.let { officialGenreForTrack(it, track) }.orEmpty()
        val genre = tagged.ifBlank { artist }
        genre.takeIf { it.isNotBlank() }?.let { it to track.copy(genre = it) }
    }
    return normalized.groupBy({ it.first }, { it.second })
        .toList()
        .sortedBy { pair -> SonusMediaStandards.genres.indexOf(pair.first).let { if (it < 0) Int.MAX_VALUE else it } }
}

private fun sonusGenreFamily(raw:String):String {
    val n=normalizeStreamSearch(raw)
    return when {
        n.isBlank() || n == "outros" || n == "musica" || n == "musicas" -> ""
        n.contains("catol") -> "catolica"
        n.contains("gospel") -> "gospel"
        n.contains("piseiro") || n.contains("forro") -> "piseiro_forro"
        n.contains("sertanejo") -> "sertanejo"
        n.contains("trap") -> "trap"
        n.contains("funk") -> "funk"
        n.contains("pagode") || n.contains("samba") -> "pagode_samba"
        n.contains("rock") -> "rock"
        n.contains("mpb") -> "mpb"
        n.contains("pop") -> "pop"
        n.contains("romant") || n.contains("acust") -> "romantico_acustico"
        else -> normalizeStreamSearch(canonicalSonusGenre(raw))
    }
}

private fun buildGenreContinuation(
    catalog: List<SonusOnlineTrack>,
    clicked: SonusOnlineTrack,
    playCounts: Map<Long,Long>,
    favorites: Set<Long>,
    fallbackGenreByFile: Map<Long,String>
): List<SonusOnlineTrack> {
    val clickedGenre=effectiveSonusGenre(clicked,fallbackGenreByFile)
    val family=sonusGenreFamily(clickedGenre)
    if(family.isBlank()) return listOf(clicked)
    val exact=canonicalSonusGenre(clickedGenre)
    val candidates=catalog
        .filter{it.fileId!=clicked.fileId && sonusGenreFamily(effectiveSonusGenre(it,fallbackGenreByFile))==family}
        .distinctBy{it.fileId}
        .sortedWith(compareByDescending<SonusOnlineTrack>{canonicalSonusGenre(effectiveSonusGenre(it,fallbackGenreByFile))==exact}
            .thenByDescending{it.fileId in favorites}
            .thenByDescending{playCounts[it.fileId]?:0L}
            .thenByDescending{it.createdAt})
    if(candidates.isEmpty()) return listOf(clicked)
    // Mistura artistas sem misturar gêneros: evita oito faixas seguidas do mesmo cantor.
    val groups=candidates.groupBy{normalizeStreamSearch(it.artist).ifBlank{"_sem_artista_${it.fileId}"}}
        .mapValues{(_,v)->v.toMutableList()}.toMutableMap()
    val diversified=mutableListOf<SonusOnlineTrack>()
    val keys=groups.keys.toMutableList()
    var cursor=Math.floorMod(clicked.fileId.hashCode(),keys.size.coerceAtLeast(1))
    while(groups.isNotEmpty() && diversified.size<49){
        val active=groups.keys.toList()
        if(active.isEmpty())break
        val key=active[cursor % active.size]
        val bucket=groups[key] ?: mutableListOf()
        if(bucket.isNotEmpty()) diversified+=bucket.removeAt(0)
        if(bucket.isEmpty()) groups.remove(key) else groups[key]=bucket
        cursor++
    }
    return (listOf(clicked)+diversified).distinctBy{it.fileId}
}

private fun <T> rotateDaily(list:List<T>,seed:Int):List<T>{if(list.isEmpty())return emptyList();val start=Math.floorMod(seed,list.size);return list.drop(start)+list.take(start)}
private fun themedTrackScore(track:SonusOnlineTrack,keywords:List<String>):Int{val text=normalizeStreamSearch(listOf(track.title,track.artist,track.album,track.genre,track.lyrics).joinToString(" "));return keywords.sumOf{if(text.contains(normalizeStreamSearch(it)))4 else 0} + if(sonusGenreFamily(track.genre)=="catolica")5 else 0}
private fun genreIcon(name:String)=when {
    normalizeStreamSearch(name).contains("arrocha") || normalizeStreamSearch(name).contains("sofrencia") -> Icons.Default.Favorite
    normalizeStreamSearch(name).contains("axe") -> Icons.Default.Celebration
    normalizeStreamSearch(name).contains("bossa") || normalizeStreamSearch(name).contains("mpb") -> Icons.Default.Piano
    normalizeStreamSearch(name).contains("brega") -> Icons.Default.MusicNote
    normalizeStreamSearch(name).contains("catol") || normalizeStreamSearch(name).contains("gospel") -> Icons.Default.AutoAwesome
    normalizeStreamSearch(name).contains("eletron") -> Icons.Default.GraphicEq
    normalizeStreamSearch(name).contains("forro") || normalizeStreamSearch(name).contains("piseiro") -> Icons.Default.Piano
    normalizeStreamSearch(name).contains("funk") || normalizeStreamSearch(name).contains("rap") || normalizeStreamSearch(name).contains("trap") -> Icons.Default.Mic
    normalizeStreamSearch(name).contains("internacional") || normalizeStreamSearch(name).contains("pop") -> Icons.Default.Public
    normalizeStreamSearch(name).contains("pagode") || normalizeStreamSearch(name).contains("samba") -> Icons.Default.LibraryMusic
    normalizeStreamSearch(name).contains("reggae") -> Icons.Default.Waves
    normalizeStreamSearch(name).contains("rock") -> Icons.Default.FlashOn
    normalizeStreamSearch(name).contains("romant") -> Icons.Default.FavoriteBorder
    normalizeStreamSearch(name).contains("sertanejo") -> Icons.Default.MusicNote
    normalizeStreamSearch(name).contains("triste") -> Icons.Default.Cloud
    else -> Icons.Default.QueueMusic
}

@Composable
private fun SonusStreamMiniPlayer(
    track: SonusOnlineTrack,
    repo: SonusOnlineMusicRepository,
    playing: Boolean,
    progress: Float,
    downloaded: Boolean,
    downloading: Boolean,
    downloadProgress: Float,
    onDownload: () -> Unit,
    accent: Color,
    onPrevious: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onOpen: () -> Unit,
    modifier: Modifier = Modifier
) {
    val artwork by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, track.fileId) {
        value = withContext(Dispatchers.IO) { repo.cachedArtwork(track) ?: repo.artwork(track) }
    }
    Surface(modifier = modifier.fillMaxWidth().clickable(onClick = onOpen), shape = RoundedCornerShape(19.dp), color = Color(0xFF111019).copy(alpha = .98f), shadowElevation = 10.dp, border = BorderStroke(1.dp, accent.copy(alpha=.25f))) {
        Column {
            LinearProgressIndicator(progress = { progress.coerceIn(0f,1f) }, modifier = Modifier.fillMaxWidth().height(2.dp), color = accent, trackColor = Color.White.copy(alpha=.08f))
            Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).clip(RoundedCornerShape(10.dp)).background(accent.copy(alpha=.12f)), contentAlignment = Alignment.Center) {
                    if (artwork != null) Image(artwork!!, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    else Icon(Icons.Default.MusicNote, null, tint = accent)
                }
                Spacer(Modifier.width(9.dp))
                Column(Modifier.weight(1f)) {
                    Text(track.displayTitle, fontWeight = FontWeight.Black, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(track.artist.ifBlank { "SONUS Stream" }, fontSize = 8.sp, color = Color.White.copy(alpha=.55f), maxLines = 1)
                }
                IconButton(onClick = onPrevious) { Icon(Icons.Default.SkipPrevious, "Anterior", tint = Color.White.copy(alpha=.72f)) }
                IconButton(onClick = onToggle) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, if (playing) "Pausar" else "Reproduzir", tint = accent) }
                IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, "Próxima", tint = Color.White.copy(alpha=.72f)) }
                IconButton(onClick = onDownload, enabled = !downloading) {
                    Icon(if (downloading) Icons.Default.Downloading else if (downloaded) Icons.Default.DownloadDone else Icons.Default.Download,
                        if (downloading) "Baixando ${ (downloadProgress * 100).toInt() }%" else if (downloaded) "Remover download" else "Baixar para offline",
                        tint = if (downloaded) Color(0xFF6FE3B2) else accent)
                }
            }
        }
    }
}

@Composable private fun SonusCompactHero(label:String,track:SonusOnlineTrack,repo:SonusOnlineMusicRepository,accent:Color,onPlay:()->Unit){val art by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null,track.fileId){value=withContext(Dispatchers.IO){repo.cachedArtwork(track) ?: repo.artwork(track)}};Surface(modifier=Modifier.fillMaxWidth().height(102.dp).clickable(onClick=onPlay),shape=RoundedCornerShape(18.dp),color=Color(0xFF17141E).copy(alpha=.94f),border=BorderStroke(1.dp,accent.copy(alpha=.20f))){Row(Modifier.padding(9.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(70.dp).clip(RoundedCornerShape(14.dp)).background(accent.copy(alpha=.12f)),contentAlignment=Alignment.Center){if(art!=null)Image(art!!,null,Modifier.fillMaxSize(),contentScale=ContentScale.Crop)else Icon(Icons.Default.MusicNote,null,tint=accent)};Spacer(Modifier.width(8.dp));Column(Modifier.weight(1f)){Text(label,color=accent,fontSize=9.sp,fontWeight=FontWeight.Black);Text(track.displayTitle,color=Color.White,fontWeight=FontWeight.Black,fontSize=11.sp,maxLines=2,overflow=TextOverflow.Ellipsis);Text(track.artist.ifBlank{"SONUS"},fontSize=8.sp,color=Color.White.copy(alpha=.55f),maxLines=1)}}}}

@Composable private fun SonusCompactMusicShelf(title:String,tracks:List<SonusOnlineTrack>,repo:SonusOnlineMusicRepository,favorites:Set<Long>,accent:Color,circular:Boolean,scale:Float,onFavorite:(Long)->Unit,onPlay:(SonusOnlineTrack)->Unit){val w=(128*scale).toInt().coerceAtLeast(62).dp;Column(verticalArrangement=Arrangement.spacedBy(7.dp)){Text(title,fontWeight=FontWeight.Black,fontSize=17.sp);LazyRow(horizontalArrangement=Arrangement.spacedBy(8.dp)){items(tracks,key={it.fileId}){track->val art by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null,track.fileId){value=withContext(Dispatchers.IO){repo.cachedArtwork(track) ?: repo.artwork(track)}};Column(Modifier.width(w).clickable{onPlay(track)},horizontalAlignment=Alignment.CenterHorizontally){Box(Modifier.size(w).clip(if(circular)androidx.compose.foundation.shape.CircleShape else RoundedCornerShape(13.dp)).background(accent.copy(alpha=.12f)),contentAlignment=Alignment.Center){if(art!=null)Image(art!!,null,Modifier.fillMaxSize(),contentScale=ContentScale.Crop)else Icon(Icons.Default.MusicNote,null,tint=accent)};Spacer(Modifier.height(4.dp));Text(track.displayTitle,color=Color.White,fontWeight=FontWeight.Bold,fontSize=8.sp,maxLines=2,overflow=TextOverflow.Ellipsis)}}}}}

@Composable
private fun SonusStreamQuickAccess(
    tracks: List<SonusOnlineTrack>,
    repo: SonusOnlineMusicRepository,
    accent: Color,
    onPlay: (SonusOnlineTrack) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Acesso rápido", fontWeight = FontWeight.Black, fontSize = 16.sp)
        tracks.chunked(2).forEach { rowTracks ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                rowTracks.forEach { track ->
                    val artwork by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, track.fileId) {
                        value = withContext(Dispatchers.IO) { repo.cachedArtwork(track) ?: repo.artwork(track) }
                    }
                    Surface(
                        modifier = Modifier.weight(1f).height(42.dp).clickable { onPlay(track) },
                        shape = RoundedCornerShape(10.dp),
                        color = Color.White.copy(alpha = .07f),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = .06f))
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.fillMaxHeight().aspectRatio(1f).background(accent.copy(alpha=.14f)), contentAlignment = Alignment.Center) {
                                if (artwork != null) Image(artwork!!, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                                else Icon(Icons.Default.MusicNote, null, tint = accent)
                            }
                            Text(
                                track.displayTitle,
                                modifier = Modifier.padding(horizontal = 6.dp).weight(1f),
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 8.sp,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
                if (rowTracks.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun SonusMusicHeroCard(track: SonusOnlineTrack, repo: SonusOnlineMusicRepository, accent: Color, onPlay:()->Unit) {
    val artwork by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, track.fileId) {
        value=withContext(Dispatchers.IO){repo.cachedArtwork(track) ?: repo.artwork(track)}
    }
    Surface(modifier=Modifier.fillMaxWidth().clickable(onClick=onPlay),shape=RoundedCornerShape(22.dp),color=Color(0xFF112D2B).copy(alpha=.82f),border=BorderStroke(1.dp,accent.copy(alpha=.30f))) {
        Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically) {
            Box(Modifier.size(82.dp).clip(RoundedCornerShape(17.dp)).background(accent.copy(alpha=.12f)),contentAlignment=Alignment.Center) {
                if(artwork!=null) Image(artwork!!,null,Modifier.fillMaxSize(),contentScale=ContentScale.Crop) else Icon(Icons.Default.MusicNote,null,tint=accent,modifier=Modifier.size(34.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Continue ouvindo",color=accent,fontWeight=FontWeight.Black,fontSize=11.sp)
                Text(track.displayTitle,color=Color.White,fontWeight=FontWeight.Black,maxLines=1,overflow=TextOverflow.Ellipsis)
                Text(track.artist.ifBlank{"SONUS Stream"},color=Color.White.copy(alpha=.62f),fontSize=10.sp,maxLines=1,overflow=TextOverflow.Ellipsis)
            }
            FilledIconButton(onClick=onPlay,colors=IconButtonDefaults.filledIconButtonColors(containerColor=accent,contentColor=Color.Black)){Icon(Icons.Default.PlayArrow,null)}
        }
    }
}

private object SonusArtistPhotoMemory {
    private val cache = linkedMapOf<String, androidx.compose.ui.graphics.ImageBitmap>()
    @Synchronized fun get(key:String)=cache[key]
    @Synchronized fun put(key:String,value:androidx.compose.ui.graphics.ImageBitmap){
        cache[key]=value
        while(cache.size>24) cache.remove(cache.keys.first())
    }
}

private suspend fun loadSonusArtistPhoto(
    context:Context,
    platform:SonusStreamPlatformRepository,
    artistId:String
):androidx.compose.ui.graphics.ImageBitmap? = withContext(Dispatchers.IO) {
    if(artistId.isBlank()) return@withContext null
    SonusArtistPhotoMemory.get(artistId)?.let{return@withContext it}
    val profile=runCatching{platform.publicArtistProfile(artistId)}.getOrNull() ?: return@withContext null
    val url=profile.photoUrl.trim()
    if(url.isBlank()) return@withContext null
    val dir=File(context.cacheDir,"sonus_artist_profiles").apply{mkdirs()}
    val key=MessageDigest.getInstance("SHA-256").digest("$artistId|$url".toByteArray()).joinToString(""){"%02x".format(it)}
    val file=File(dir,"$key.img")
    val bmp=runCatching{
        if(!file.exists() || file.length()==0L){
            val conn=URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout=8_000;conn.readTimeout=12_000;conn.instanceFollowRedirects=true
            try{
                require(conn.responseCode in 200..299){"Foto indisponível"}
                conn.inputStream.use{input->file.outputStream().use{output->input.copyTo(output,128*1024)}}
            }finally{conn.disconnect()}
        }
        BitmapFactory.decodeFile(file.absolutePath)?.asImageBitmap()
    }.getOrNull()
    if(bmp!=null) SonusArtistPhotoMemory.put(artistId,bmp)
    bmp
}

@Composable
private fun SonusPublicArtistAvatar(
    artistId:String,
    platform:SonusStreamPlatformRepository,
    size:androidx.compose.ui.unit.Dp,
    accent:Color
){
    val context=LocalContext.current
    val bitmap by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null,artistId){
        value=loadSonusArtistPhoto(context,platform,artistId)
    }
    Surface(
        modifier=Modifier.size(size),
        shape=androidx.compose.foundation.shape.CircleShape,
        color=accent.copy(alpha=.14f),
        border=BorderStroke(1.dp,accent.copy(alpha=.20f))
    ){
        Box(contentAlignment=Alignment.Center){
            if(bitmap!=null) Image(bitmap!!,null,Modifier.fillMaxSize(),contentScale=ContentScale.Crop)
            else Icon(Icons.Default.Person,null,tint=accent,modifier=Modifier.size(size*.55f))
        }
    }
}

@Composable
private fun SonusPublicArtistPage(
    artistName:String,
    artistId:String,
    tracks:List<SonusOnlineTrack>,
    repo:SonusOnlineMusicRepository,
    platform:SonusStreamPlatformRepository,
    accent:Color,
    favorites:Set<Long>,
    onFavoriteTrack:(Long)->Unit,
    onBack:()->Unit,
    onPlay:(SonusOnlineTrack)->Unit
){
    val context=LocalContext.current
    val scope=rememberCoroutineScope()
    val uid=FirebaseAuth.getInstance().currentUser?.uid.orEmpty()
    var following by remember(artistId,uid){mutableStateOf(false)}
    var artistLiked by remember(artistId,uid){mutableStateOf(false)}
    var followers by remember(artistId){mutableLongStateOf(0L)}
    var busy by remember{mutableStateOf(false)}
    LaunchedEffect(artistId,uid){
        if(artistId.isNotBlank()&&uid.isNotBlank()){
            following=runCatching{FirebaseDatabase.getInstance().getReference("streamFollowingByUser").child(uid).child(artistId).get().awaitOnlineSnapshot().exists()}.getOrDefault(false)
            followers=runCatching{FirebaseDatabase.getInstance().getReference("streamArtistPublicStats").child(artistId).child("followers").get().awaitOnlineSnapshot().getValue(Long::class.java)?:0L}.getOrDefault(0L)
            artistLiked=runCatching{platform.artistFavoriteState(artistId)}.getOrDefault(false)
        }
    }
    Surface(Modifier.fillMaxSize(),color=MaterialTheme.colorScheme.background){
        LazyColumn(
            modifier=Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing),
            contentPadding=PaddingValues(bottom=28.dp),
            verticalArrangement=Arrangement.spacedBy(8.dp)
        ){
            item{
                Box(Modifier.fillMaxWidth().height(300.dp)){
                    Box(
                        Modifier.fillMaxWidth().height(215.dp).background(
                            Brush.verticalGradient(listOf(accent.copy(alpha=.34f),MaterialTheme.colorScheme.background))
                        )
                    )
                    IconButton(onClick=onBack,modifier=Modifier.padding(8.dp).align(Alignment.TopStart)){
                        Icon(Icons.Default.ArrowBack,"Voltar")
                    }
                    Column(
                        Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal=20.dp),
                        horizontalAlignment=Alignment.CenterHorizontally
                    ){
                        SonusPublicArtistAvatar(artistId,platform,118.dp,accent)
                        Spacer(Modifier.height(10.dp))
                        Text(artistName,color=Color.White,fontWeight=FontWeight.Black,fontSize=25.sp,maxLines=1,overflow=TextOverflow.Ellipsis)
                        Text("${tracks.size} música(s) • $followers seguidor(es)",color=Color.White.copy(alpha=.62f),fontSize=11.sp)
                    }
                }
            }
            item{
                Row(
                    Modifier.fillMaxWidth().padding(horizontal=16.dp),
                    horizontalArrangement=Arrangement.spacedBy(8.dp)
                ){
                    Button(
                        onClick={
                            scope.launch{
                                busy=true
                                platform.followArtist(artistId,!following).onSuccess{following=it.first;followers=it.second}
                                busy=false
                            }
                        },
                        enabled=!busy&&artistId.isNotBlank(),
                        modifier=Modifier.weight(1f)
                    ){
                        Icon(if(following)Icons.Default.Check else Icons.Default.PersonAdd,null)
                        Spacer(Modifier.width(5.dp));Text(if(following)"Seguindo" else "Seguir",maxLines=1)
                    }
                    FilledTonalIconButton(
                        onClick={scope.launch{platform.favoriteArtist(artistId,!artistLiked).onSuccess{artistLiked=it}}},
                        enabled=artistId.isNotBlank()
                    ){
                        Icon(if(artistLiked)Icons.Default.Favorite else Icons.Default.FavoriteBorder,"Favoritar artista",tint=if(artistLiked)Color(0xFFFF6688) else LocalContentColor.current)
                    }
                }
            }
            item{
                Button(
                    onClick={ tracks.firstOrNull()?.let { onPlay(it) } },
                    enabled=tracks.isNotEmpty(),
                    modifier=Modifier.fillMaxWidth().padding(horizontal=16.dp)
                ){
                    Icon(Icons.Default.PlayArrow,null);Spacer(Modifier.width(6.dp));Text("Ouvir músicas")
                }
            }
            item{
                Text("Músicas",Modifier.padding(horizontal=18.dp,vertical=8.dp),fontWeight=FontWeight.Black,fontSize=20.sp)
            }
            items(tracks,key={"artist-song-${it.fileId}"}){track->
                val artwork by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null,track.fileId){
                    value=withContext(Dispatchers.IO){repo.cachedArtwork(track)?:repo.artwork(track)}
                }
                Surface(
                    modifier=Modifier.padding(horizontal=12.dp).fillMaxWidth().clickable{onPlay(track)},
                    shape=RoundedCornerShape(16.dp),
                    color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.25f)
                ){
                    Row(Modifier.padding(8.dp),verticalAlignment=Alignment.CenterVertically){
                        Box(Modifier.size(54.dp).clip(RoundedCornerShape(11.dp)).background(accent.copy(alpha=.12f)),contentAlignment=Alignment.Center){
                            if(artwork!=null) Image(artwork!!,null,Modifier.fillMaxSize(),contentScale=ContentScale.Crop)
                            else Icon(Icons.Default.MusicNote,null,tint=accent)
                        }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)){
                            Text(track.displayTitle,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis)
                            Text(track.artist.ifBlank{artistName},style=MaterialTheme.typography.labelSmall,maxLines=1,overflow=TextOverflow.Ellipsis)
                        }
                        IconButton(onClick={onFavoriteTrack(track.fileId)}){
                            Icon(if(track.fileId in favorites)Icons.Default.Favorite else Icons.Default.FavoriteBorder,null,tint=if(track.fileId in favorites)Color(0xFFFF6688) else Color.White.copy(alpha=.55f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SonusMusicShelf(
    title:String,
    tracks:List<SonusOnlineTrack>,
    repo:SonusOnlineMusicRepository,
    favorites:Set<Long>,
    accent:Color,
    sponsored:Boolean=false,
    onFavorite:(Long)->Unit,
    onPlay:(SonusOnlineTrack)->Unit
) {
    Column(verticalArrangement=Arrangement.spacedBy(7.dp)) {
        Text(title,fontWeight=FontWeight.Black,fontSize=17.sp)
        LazyRow(horizontalArrangement=Arrangement.spacedBy(9.dp)) {
            items(tracks.take(12),key={it.fileId}) { track ->
                val art by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null,track.fileId) {
                    value=withContext(Dispatchers.IO){repo.cachedArtwork(track) ?: repo.artwork(track)}
                }
                Surface(modifier=Modifier.width(128.dp).clickable{onPlay(track)},shape=RoundedCornerShape(17.dp),color=Color(0xFF17141E).copy(alpha=.96f),border=BorderStroke(1.dp,Color.White.copy(alpha=.06f))) {
                    Column(Modifier.padding(8.dp)) {
                        Box(Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(13.dp)).background(accent.copy(alpha=.12f)),contentAlignment=Alignment.Center) {
                            if(art!=null) Image(art!!,null,Modifier.fillMaxSize(),contentScale=ContentScale.Crop) else Icon(Icons.Default.MusicNote,null,tint=accent)
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(track.displayTitle,color=Color.White,fontWeight=FontWeight.Bold,fontSize=10.sp,maxLines=1,overflow=TextOverflow.Ellipsis)
                        if(sponsored) Text("Patrocinada",color=Color(0xFFFFD36A),fontSize=8.sp,fontWeight=FontWeight.Bold)
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Text(track.artist.ifBlank{"SONUS"},color=Color.White.copy(alpha=.53f),fontSize=8.sp,maxLines=1,overflow=TextOverflow.Ellipsis,modifier=Modifier.weight(1f))
                            IconButton(onClick={onFavorite(track.fileId)},modifier=Modifier.size(28.dp)){Icon(if(track.fileId in favorites)Icons.Default.Favorite else Icons.Default.FavoriteBorder,null,tint=if(track.fileId in favorites)Color(0xFFFF6787) else Color.White.copy(alpha=.45f),modifier=Modifier.size(15.dp))}
                        }
                    }
                }
            }
        }
    }
}

@OptIn(androidx.media3.common.util.UnstableApi::class)
@Composable
internal fun SonusShareDialog(
    source: SonusShareSource,
    repo: SonusOnlineMusicRepository,
    platform: SonusStreamPlatformRepository,
    service: PulsePlayerService?,
    membershipTier: MembershipTier,
    onRequestPlan: (MembershipTier) -> Unit,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val shareIdentityPrefs = remember { context.getSharedPreferences("sonus_share_identity_v1", Context.MODE_PRIVATE) }
    val galleryCodes = listOf(
        "kZspB4JZmPJsxI5SKzQ1dgJWSicA2bQzFJhX",
        "kZlMPSJZIKQmTVCl6w7EgHPazyKmapmHe3cy",
        "kZwyCSJZUAqjAxCrE9zIvbA8MWP1rXS3YaAV"
    )
    val filters = listOf(
        "Original" to false,
        "Cinemático" to false,
        "Pôr do Sol" to false,
        "Filme Vintage" to false,
        "Cidade Noturna" to false,
        "Natural+" to true,
        "Luz Suave" to true,
        "Quente Natural" to true,
        "Frio Natural" to true,
        "Contraste Suave" to true,
        "Cinema Clean" to true,
        "Dourado" to true,
        "Noite Limpa" to true,
        "Pastel Natural" to true,
        "Clareza+" to true
    )
    val durations = listOf(15, 30, 40, 50, 60, 65)
    var mode by remember(source.key) { mutableStateOf("MENU") }
    var fullGallery by remember(source.key) { mutableStateOf<List<SonusShareGalleryImage>>(emptyList()) }
    var galleryLoading by remember(source.key) { mutableStateOf(false) }
    var galleryError by remember(source.key) { mutableStateOf<String?>(null) }
    var selectedImages by remember(source.key) { mutableStateOf<List<SonusShareGalleryImage>>(emptyList()) }
    var selectedFilter by remember(source.key) { mutableStateOf("Original") }
    var durationSeconds by remember(source.key, membershipTier) { mutableIntStateOf(if (commercialTier(membershipTier) == MembershipTier.FREE) 15 else 30) }
    var startSeconds by remember(source.key) { mutableFloatStateOf(0f) }
    var exporting by remember(source.key) { mutableStateOf(false) }
    var exportJob by remember(source.key) { mutableStateOf<Job?>(null) }
    var progress by remember(source.key) { mutableIntStateOf(0) }
    var phase by remember(source.key) { mutableStateOf("") }
    var error by remember(source.key) { mutableStateOf<String?>(null) }
    var savedVideoUri by remember(source.key) { mutableStateOf<Uri?>(null) }
    var resolvedDurationMs by remember(source.key) { mutableLongStateOf(source.durationMs.coerceAtLeast(0L)) }
    var durationResolving by remember(source.key) { mutableStateOf(false) }
    var previewPlayer by remember(source.key) { mutableStateOf<ExoPlayer?>(null) }
    var previewing by remember(source.key) { mutableStateOf(false) }
    var savedMainState by remember(source.key) { mutableStateOf<PulsePlayerPlaybackState?>(null) }
    var signatureText by rememberSaveable { mutableStateOf(shareIdentityPrefs.getString("signature_text", "").orEmpty()) }
    var signatureLogoUriText by rememberSaveable { mutableStateOf(shareIdentityPrefs.getString("signature_logo_uri", "").orEmpty()) }
    var gallerySearchExpanded by rememberSaveable(source.key) { mutableStateOf(false) }
    var gallerySearchQuery by rememberSaveable(source.key) { mutableStateOf("") }
    // Nova abertura do Social Edit = nova ordem de sugestões, mantendo o ranking semântico.
    var suggestionSeed by remember(source.key) { mutableLongStateOf(System.nanoTime() xor source.key.hashCode().toLong()) }
    val signatureLogoUri = signatureLogoUriText.takeIf { it.isNotBlank() }?.let(Uri::parse)
    val hasLyrics = remember(source.key, source.lrcText, source.streamTrack?.lyrics, source.streamTrack?.lyricsFormat) {
        source.lrcText.isNotBlank() || source.streamTrack?.lyrics?.isNotBlank() == true ||
            source.streamTrack?.let { repo.lyricsForFileId(it.fileId)?.first?.isNotBlank() == true } == true
    }
    val paidSocialEdit = commercialTier(membershipTier) != MembershipTier.FREE
    val maxSelectedImages = socialEditMaxSelectedImages(durationSeconds)
    val galleryPreviewLimit = socialEditGalleryPreviewLimit(durationSeconds)
    val suggestedGallery = remember(fullGallery, source.key, galleryPreviewLimit, suggestionSeed) {
        rankShareGalleryImages(context, source.rankingTrack(), fullGallery, galleryPreviewLimit, suggestionSeed)
    }
    val sonusEditInstalled = remember(source.key) { source.isStream && SonusEditBridge.isAvailable(context) }
    LaunchedEffect(membershipTier) {
        if (!paidSocialEdit && durationSeconds != 15) durationSeconds = 15
        if (!paidSocialEdit && filters.any { it.first == selectedFilter && it.second }) selectedFilter = "Original"
    }
    val visibleGallery = remember(fullGallery, suggestedGallery, gallerySearchQuery, galleryPreviewLimit) {
        if (gallerySearchQuery.isBlank()) suggestedGallery.take(galleryPreviewLimit)
        else searchShareGalleryImages(fullGallery, gallerySearchQuery).take(galleryPreviewLimit)
    }
    val identityLogoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            signatureLogoUriText = uri.toString()
            shareIdentityPrefs.edit().putString("signature_logo_uri", uri.toString()).apply()
        }
    }

    fun restoreMainPlayer() {
        previewPlayer?.let { runCatching { it.stop() }; runCatching { it.release() } }
        previewPlayer = null
        previewing = false
        val saved = savedMainState
        savedMainState = null
        if (saved != null && service != null && saved.current != null) {
            val sameQueue = service.state.value.queue == saved.queue
            if (!sameQueue) service.setQueue(saved.queue, saved.index.coerceAtLeast(0), false, saved.positionMs)
            else {
                if (service.state.value.index != saved.index) service.playIndex(saved.index.coerceAtLeast(0), shouldPlay = false, startPositionMs = saved.positionMs)
                else service.seekTo(saved.positionMs)
            }
            if (saved.playing) service.play() else service.pause()
        }
    }

    fun closeSafely() {
        restoreMainPlayer()
        onClose()
    }

    DisposableEffect(source.key) {
        onDispose {
            previewPlayer?.let { runCatching { it.stop() }; runCatching { it.release() } }
            previewPlayer = null
            previewing = false
            val saved = savedMainState
            savedMainState = null
            if (saved != null && service != null && saved.current != null) {
                if (service.state.value.queue != saved.queue) service.setQueue(saved.queue, saved.index.coerceAtLeast(0), false, saved.positionMs)
                else service.seekTo(saved.positionMs)
                if (saved.playing) service.play() else service.pause()
            }
        }
    }

    LaunchedEffect(mode, source.key) {
        if (mode == "VIDEO" && fullGallery.isEmpty() && !galleryLoading) {
            galleryLoading = true
            galleryError = null
            val result = withContext(Dispatchers.IO) { runCatching { galleryCodes.flatMap { code -> SonusPCloudClient.listPublicImages(code) }.distinctBy { "${it.sourceCode}:${it.fileId}" } } }
            fullGallery = result.getOrDefault(emptyList())
            if (selectedImages.isEmpty()) {
                (rankShareGalleryImages(context, source.rankingTrack(), fullGallery, galleryPreviewLimit, suggestionSeed).firstOrNull() ?: fullGallery.randomOrNull(Random(suggestionSeed)))?.let { selectedImages = listOf(it) }
            }
            galleryError = result.exceptionOrNull()?.message ?: if (fullGallery.isEmpty()) "A galeria ainda não possui imagens disponíveis." else null
            galleryLoading = false
        }
        if (mode == "VIDEO" && resolvedDurationMs <= 0L && !durationResolving) {
            durationResolving = true
            val resolved = withContext(Dispatchers.IO) {
                resolveShareSourceDurationMs(context, source, repo)
            }
            if (resolved > 0L) resolvedDurationMs = resolved
            durationResolving = false
        }
    }

    val maxStartSeconds = ((resolvedDurationMs / 1000L) - durationSeconds.toLong()).coerceAtLeast(0L).toFloat()
    LaunchedEffect(durationSeconds, maxStartSeconds) {
        startSeconds = startSeconds.coerceIn(0f, maxStartSeconds)
        if (selectedImages.size > maxSelectedImages) selectedImages = selectedImages.take(maxSelectedImages)
        previewPlayer?.let { if (previewing) it.seekTo((startSeconds * 1000L).toLong()) }
    }

    AlertDialog(
        onDismissRequest = { if (!exporting) closeSafely() },
        modifier = Modifier.fillMaxWidth(.95f).blur(if (exporting) 3.dp else 0.dp),
        properties = DialogProperties(usePlatformDefaultWidth = false),
        title = {
            Column {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painter = painterResource(R.drawable.social_edit_icon),
                        contentDescription = null,
                        modifier = Modifier.size(34.dp),
                        contentScale = ContentScale.Fit
                    )
                    Spacer(Modifier.width(8.dp))
                    Text("SOCIAL EDIT", fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = (if (hasLyrics) Color(0xFF36C985) else Color(0xFFE85B6A)).copy(alpha = .14f),
                        border = BorderStroke(1.dp, (if (hasLyrics) Color(0xFF36C985) else Color(0xFFE85B6A)).copy(alpha = .42f))
                    ) {
                        Row(Modifier.padding(horizontal = 7.dp, vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(6.dp).background(if (hasLyrics) Color(0xFF36C985) else Color(0xFFE85B6A), androidx.compose.foundation.shape.CircleShape))
                            Spacer(Modifier.width(4.dp))
                            Text(if (hasLyrics) "LETRA" else "SEM LETRA", fontSize = 7.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Text("${source.title} • ${source.displayArtist}", style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        },
        text = {
            when (mode) {
                "MENU" -> Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Surface(Modifier.fillMaxWidth().clickable {
                        scope.launch {
                            error = null
                            if (source.isStream) {
                                val track = source.streamTrack ?: return@launch
                                val shareLink = SonusOnlineRef(
                                    fileId = track.fileId,
                                    size = track.size,
                                    sourceKey = repo.sourceKeyForTrack(track),
                                    title = source.title,
                                    artist = source.artist
                                ).toHttpsShareUrl(source.title, source.artist)
                                val text = buildString {
                                    append("🎧 Ouça ${source.title}")
                                    if (source.artist.isNotBlank()) append(" — ${source.artist}")
                                    append(" no SONUS Stream.\n\n")
                                    append(shareLink)
                                }
                                runCatching {
                                    context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(Intent.EXTRA_SUBJECT, source.title)
                                        putExtra(Intent.EXTRA_TEXT, text)
                                    }, "Compartilhar música"))
                                }.onSuccess {
                                    scope.launch(Dispatchers.IO) { platform.recordShare(track.fileId, video = false) }
                                    closeSafely()
                                }.onFailure { error = it.message }
                            } else {
                                val uri = runCatching { Uri.parse(source.audioUri) }.getOrNull()
                                if (uri == null) error = "Arquivo de áudio inválido."
                                else runCatching {
                                    context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                                        type = "audio/*"
                                        putExtra(Intent.EXTRA_SUBJECT, source.title)
                                        putExtra(Intent.EXTRA_TEXT, listOf(source.title, source.artist).filter { it.isNotBlank() }.joinToString(" — "))
                                        putExtra(Intent.EXTRA_STREAM, uri)
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }, "Compartilhar música"))
                                }.onSuccess { closeSafely() }.onFailure { error = it.message }
                            }
                        }
                    }, shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.32f)) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Share, null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text("Compartilhar música", fontWeight = FontWeight.ExtraBold)
                                Text(if (source.isStream) "Título, artista e link da faixa" else "Compartilhar o arquivo de áudio local", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                    Surface(Modifier.fillMaxWidth().clickable { mode = "VIDEO" }, shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.32f)) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.MovieCreation, null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text("Criar vídeo automático", fontWeight = FontWeight.ExtraBold)
                                Text("15s teste • 30/40/50/60/65s PRO • 1080×1920 • letra sincronizada quando houver", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                    Surface(Modifier.fillMaxWidth().clickable {
                        val trackId = source.streamTrack?.fileId
                        when {
                            trackId == null -> error = "O SONUS Edit abre diretamente músicas do SONUS Stream."
                            !sonusEditInstalled -> error = "SONUS Edit não está instalado ou não está disponível neste aparelho."
                            else -> SonusEditBridge.openTrack(context, trackId)
                                .onSuccess { closeSafely() }
                                .onFailure { error = "Não foi possível abrir o SONUS Edit." }
                        }
                    }, shape = RoundedCornerShape(16.dp), color = Color(0xFF5D45D8).copy(alpha = .16f), border = BorderStroke(1.dp, Color(0xFF8B7BFF).copy(alpha = .30f))) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.OpenInNew, null, tint = Color(0xFFA99DFF))
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text("Abrir no SONUS Edit", fontWeight = FontWeight.ExtraBold)
                                Text(if (sonusEditInstalled) "Continua a criação no editor completo" else "Instale/ative o SONUS Edit para continuar", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                    error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                }
                else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.heightIn(max = 500.dp)) {
                    item {
                        Text("Sua assinatura", fontWeight = FontWeight.ExtraBold)
                        Text("Opcional • aparece pequena e discreta no topo do vídeo.", style = MaterialTheme.typography.labelSmall)
                        Spacer(Modifier.height(6.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = signatureText,
                                onValueChange = { value ->
                                    val safeSignature = value.take(42)
                                    signatureText = safeSignature
                                    shareIdentityPrefs.edit().putString("signature_text", safeSignature).apply()
                                },
                                label = { Text("Nome / usuário") },
                                placeholder = { Text("ex: raffa_theoo") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            FilledTonalIconButton(onClick = { identityLogoPicker.launch(arrayOf("image/*")) }) {
                                Icon(if (signatureLogoUri != null) Icons.Default.CheckCircle else Icons.Default.AddPhotoAlternate, "Adicionar logo ou foto")
                            }
                            if (signatureLogoUri != null) {
                                IconButton(onClick = {
                                    signatureLogoUriText = ""
                                    shareIdentityPrefs.edit().remove("signature_logo_uri").apply()
                                }) { Icon(Icons.Default.Close, "Remover logo") }
                            }
                        }
                    }
                    item {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("1. Escolha as imagens", fontWeight = FontWeight.ExtraBold)
                                Text("${selectedImages.size}/$maxSelectedImages selecionadas • mínimo 5s por foto • duração dividida automaticamente • até $galleryPreviewLimit opções carregadas", style = MaterialTheme.typography.labelSmall)
                            }
                            IconButton(onClick = { gallerySearchExpanded = !gallerySearchExpanded; if (!gallerySearchExpanded) gallerySearchQuery = "" }, modifier = Modifier.size(32.dp)) {
                                Icon(Icons.Default.Search, "Pesquisar imagem", modifier = Modifier.size(18.dp))
                            }
                        }
                        if (gallerySearchExpanded) {
                            OutlinedTextField(
                                value = gallerySearchQuery,
                                onValueChange = { gallerySearchQuery = it.take(60) },
                                leadingIcon = { Icon(Icons.Default.Search, null, modifier = Modifier.size(17.dp)) },
                                trailingIcon = if (gallerySearchQuery.isNotBlank()) { { IconButton(onClick = { gallerySearchQuery = "" }) { Icon(Icons.Default.Close, "Limpar pesquisa") } } } else null,
                                placeholder = { Text("Pesquisar no acervo") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                    if (galleryLoading) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
                    galleryError?.let { message -> item { Text(message, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) } }
                    if (fullGallery.isNotEmpty()) item {
                        if (visibleGallery.isEmpty() && gallerySearchQuery.isNotBlank()) {
                            Text("Nenhuma imagem encontrada para ‘$gallerySearchQuery’.", style = MaterialTheme.typography.bodySmall)
                        } else {
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(visibleGallery, key = { "share-image-${it.sourceCode}-${it.fileId}" }) { image ->
                                    val selectedIndex = selectedImages.indexOfFirst { it.fileId == image.fileId && it.sourceCode == image.sourceCode }
                                    SonusShareGalleryThumbnail(
                                        image = image,
                                        code = image.sourceCode,
                                        selected = selectedIndex >= 0,
                                        selectionIndex = selectedIndex.takeIf { it >= 0 }?.plus(1),
                                        onClick = {
                                            if (selectedIndex >= 0) {
                                                selectedImages = selectedImages.filterNot { it.fileId == image.fileId && it.sourceCode == image.sourceCode }
                                            } else if (selectedImages.size < maxSelectedImages) {
                                                selectedImages = selectedImages + image
                                            } else {
                                                Toast.makeText(context, "Limite de $maxSelectedImages imagens para ${durationSeconds}s.", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                    item {
                        Text("2. Duração", fontWeight = FontWeight.ExtraBold)
                        BoxWithConstraints(Modifier.fillMaxWidth()) {
                            val compact = maxWidth < 330.dp
                            val rows = if (compact) durations.chunked(3) else listOf(durations)
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                rows.forEach { rowDurations ->
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                        rowDurations.forEach { sec ->
                                            val locked = sec > 15 && !paidSocialEdit
                                            val selected = durationSeconds == sec
                                            val secondary = when (sec) {
                                                15 -> "TESTE"
                                                65 -> "TikTok 1min+"
                                                else -> if (locked) "PRO" else ""
                                            }
                                            Surface(
                                                modifier = Modifier.weight(1f).height(46.dp).clickable {
                                                    if (locked) onRequestPlan(MembershipTier.PRATA) else durationSeconds = sec
                                                },
                                                shape = RoundedCornerShape(10.dp),
                                                color = if (selected) Color(0xFF34785D) else Color(0xFF285C48),
                                                border = BorderStroke(
                                                    if (selected) 1.5.dp else 1.dp,
                                                    if (selected) Color(0xFFA7D7BF) else Color.White.copy(alpha = .12f)
                                                )
                                            ) {
                                                Column(
                                                    Modifier.fillMaxSize().padding(horizontal = 3.dp, vertical = 5.dp),
                                                    horizontalAlignment = Alignment.CenterHorizontally,
                                                    verticalArrangement = Arrangement.Center
                                                ) {
                                                    Text("${sec}s", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                                                    if (secondary.isNotBlank()) {
                                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                                            if (locked && sec != 65) Icon(Icons.Default.Lock, null, tint = Color.White.copy(.85f), modifier = Modifier.size(7.dp))
                                                            Text(secondary, color = Color.White.copy(.92f), fontSize = if (sec == 65) 5.6.sp else 6.2.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        repeat((if (compact) 3 else 6) - rowDurations.size) { Spacer(Modifier.weight(1f)) }
                                    }
                                }
                            }
                        }
                    }
                    item {
                        Text("3. Início do trecho", fontWeight = FontWeight.ExtraBold)
                        Slider(
                            value = startSeconds,
                            onValueChange = {
                                startSeconds = it
                                if (previewing) previewPlayer?.seekTo((it * 1000L).toLong())
                            },
                            valueRange = 0f..maxStartSeconds.coerceAtLeast(.01f),
                            enabled = maxStartSeconds > 0f && !durationResolving
                        )
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilledTonalIconButton(
                                onClick = {
                                    if (previewing) {
                                        restoreMainPlayer()
                                    } else {
                                        scope.launch {
                                            error = null
                                            restoreMainPlayer()
                                            savedMainState = service?.state?.value
                                            if (savedMainState?.playing == true) service?.pause()
                                            val resolvedUri = withContext(Dispatchers.IO) { resolveShareSourceAudioUri(source, repo) }
                                            if (resolvedUri.isBlank()) {
                                                error = "Não foi possível abrir a prévia do áudio."
                                                restoreMainPlayer()
                                                return@launch
                                            }
                                            val p = buildSharePreviewPlayer(context, resolvedUri)
                                            previewPlayer = p
                                            p.setMediaItem(MediaItem.fromUri(resolvedUri))
                                            p.prepare()
                                            p.seekTo((startSeconds * 1000L).toLong())
                                            p.playWhenReady = true
                                            previewing = true
                                            launch {
                                                while (previewPlayer === p && previewing) {
                                                    delay(120L)
                                                    val dynamicEnd = (startSeconds * 1000L).toLong() + durationSeconds * 1000L
                                                    if (p.currentPosition >= dynamicEnd || p.playbackState == Player.STATE_ENDED) {
                                                        restoreMainPlayer()
                                                        break
                                                    }
                                                }
                                            }
                                        }
                                    }
                                },
                                enabled = !durationResolving && resolvedDurationMs > 0L
                            ) {
                                Icon(if(previewing) Icons.Default.Stop else Icons.Default.PlayArrow, if(previewing) "Parar prévia" else "Ouvir prévia")
                            }
                            OutlinedButton(
                                onClick = {
                                    startSeconds = (startSeconds - 1f).coerceIn(0f, maxStartSeconds)
                                    if (previewing) previewPlayer?.seekTo((startSeconds * 1000L).toLong())
                                },
                                enabled = !durationResolving && resolvedDurationMs > 0L,
                                contentPadding = PaddingValues(horizontal = 7.dp, vertical = 2.dp),
                                modifier = Modifier.height(34.dp)
                            ) { Text("−1", fontSize = 9.sp, fontWeight = FontWeight.Bold) }
                            OutlinedButton(
                                onClick = {
                                    startSeconds = (startSeconds + 1f).coerceIn(0f, maxStartSeconds)
                                    if (previewing) previewPlayer?.seekTo((startSeconds * 1000L).toLong())
                                },
                                enabled = !durationResolving && resolvedDurationMs > 0L,
                                contentPadding = PaddingValues(horizontal = 7.dp, vertical = 2.dp),
                                modifier = Modifier.height(34.dp)
                            ) { Text("+1", fontSize = 9.sp, fontWeight = FontWeight.Bold) }
                            Column(Modifier.weight(1f)) {
                                Text(
                                    if(durationResolving) "Lendo a duração real da música…"
                                    else "${formatShareClock((startSeconds*1000L).toLong())} → ${formatShareClock(((startSeconds+durationSeconds)*1000L).toLong().coerceAtMost(resolvedDurationMs))}",
                                    fontWeight=FontWeight.Bold,
                                    style=MaterialTheme.typography.bodySmall
                                )
                                Text("Play reproduz exatamente o trecho selecionado.", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                    item {
                        Text("4. Filtro", fontWeight = FontWeight.ExtraBold)
                        Text("Veja a personalidade de cada efeito antes de escolher.", style = MaterialTheme.typography.labelSmall)
                        Spacer(Modifier.height(5.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(filters, key = { "share-filter-${it.first}" }) { option ->
                                val filter = option.first
                                val pro = option.second
                                ShareFilterVisualCard(
                                    filter = filter,
                                    selected = selectedFilter == filter,
                                    pro = pro,
                                    locked = pro && !paidSocialEdit,
                                    onClick = {
                                        if (pro && !paidSocialEdit) onRequestPlan(MembershipTier.PRATA)
                                        else selectedFilter = filter
                                    }
                                )
                            }
                        }
                    }
                    error?.let { item { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) } }
                }
            }
        },
        confirmButton = {
            if (mode == "VIDEO") {
                Button(
                    enabled = !exporting && selectedImages.isNotEmpty() && !durationResolving && resolvedDurationMs > 0L,
                    onClick = {
                        val images = selectedImages.take(maxSelectedImages)
                        if (images.isEmpty()) return@Button
                        restoreMainPlayer()
                        exporting = true; error = null; progress = 0; phase = "Preparando"
                        exportJob = scope.launch {
                            val result = createSonusShareVideo(
                                context = context,
                                repo = repo,
                                source = source.copy(durationMs = resolvedDurationMs),
                                images = images,
                                galleryCode = galleryCodes.first(),
                                durationSeconds = durationSeconds,
                                startMs = (startSeconds * 1000L).toLong(),
                                filter = selectedFilter,
                                signatureText = signatureText,
                                signatureLogoUri = signatureLogoUri,
                                onProgress = { p, label -> progress = p; phase = label }
                            )
                            exporting = false
                            exportJob = null
                            result.onSuccess { uri ->
                                val streamTrack = source.streamTrack
                                if (streamTrack != null) scope.launch(Dispatchers.IO) { platform.recordGeneratedShareVideo(streamTrack.fileId) }
                                savedVideoUri = uri
                                phase = "Concluído"
                                progress = 100
                            }.onFailure { error = it.message ?: "Não foi possível criar o vídeo." }
                        }
                    }
                ) { Text(if (exporting) "Criando…" else "Criar vídeo") }
            }
        },
        dismissButton = {
            if (!exporting) TextButton(onClick = {
                restoreMainPlayer()
                if (mode == "VIDEO") mode = "MENU" else onClose()
            }) { Text(if (mode == "VIDEO") "Voltar" else "Fechar") }
        }
    )
    savedVideoUri?.let { savedUri ->
        AlertDialog(
            onDismissRequest = {},
            title = { Text("Vídeo salvo", fontWeight = FontWeight.Black) },
            text = { Text("A exportação terminou e o vídeo já está salvo no aparelho.") },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = {
                        runCatching {
                            context.startActivity(Intent.createChooser(Intent(Intent.ACTION_VIEW).apply {
                                setDataAndType(savedUri, "video/mp4")
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }, "Assistir vídeo"))
                        }.onFailure { error = it.message ?: "Não foi possível abrir o vídeo." }
                    }) { Text("Assistir vídeo") }
                    Button(onClick = {
                        val streamTrack = source.streamTrack
                        runCatching {
                            context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                                type = "video/mp4"
                                putExtra(Intent.EXTRA_STREAM, savedUri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }, "Compartilhar vídeo SOCIAL EDIT"))
                        }.onSuccess {
                            if (streamTrack != null) scope.launch(Dispatchers.IO) { platform.recordShare(streamTrack.fileId, video = true) }
                        }.onFailure { error = it.message ?: "Não foi possível abrir o compartilhamento." }
                    }) { Text("Compartilhar") }
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    savedVideoUri = null
                    selectedImages = selectedImages.take(maxSelectedImages)
                    startSeconds = 0f
                    progress = 0
                    phase = ""
                    mode = "VIDEO"
                }) { Text("Criar outro") }
            }
        )
    }
    if (exporting) {
        SonusShareExportProgressDialog(
            percent = progress,
            phase = phase,
            onCancel = {
                exportJob?.cancel()
                exportJob = null
                exporting = false
                progress = 0
                phase = ""
                error = "Exportação cancelada."
            }
        )
    }
}

@Composable
private fun ShareFilterVisualCard(filter: String, selected: Boolean, pro: Boolean, locked: Boolean, onClick: () -> Unit) {
    val colors = when (filter) {
        "Cinemático" -> listOf(Color(0xFF0C2539), Color(0xFFB56A42))
        "Pôr do Sol" -> listOf(Color(0xFF51234C), Color(0xFFFF8A4D))
        "Filme Vintage" -> listOf(Color(0xFF5E5137), Color(0xFFC9A66B))
        "Cidade Noturna" -> listOf(Color(0xFF071731), Color(0xFF6D5DA8))
        "Natural+" -> listOf(Color(0xFF35544A), Color(0xFF8EAA8A))
        "Luz Suave" -> listOf(Color(0xFF69736A), Color(0xFFD8CFAF))
        "Quente Natural" -> listOf(Color(0xFF6A4938), Color(0xFFD0A57B))
        "Frio Natural" -> listOf(Color(0xFF314D5B), Color(0xFF8DB0B7))
        "Contraste Suave" -> listOf(Color(0xFF333C40), Color(0xFF899598))
        "Cinema Clean" -> listOf(Color(0xFF2D464B), Color(0xFF9C947F))
        "Dourado" -> listOf(Color(0xFF66563A), Color(0xFFC6A86C))
        "Noite Limpa" -> listOf(Color(0xFF1D3346), Color(0xFF667C94))
        "Pastel Natural" -> listOf(Color(0xFF6D6664), Color(0xFFC0A9A0))
        "Clareza+" -> listOf(Color(0xFF445258), Color(0xFFAAB7B8))
        else -> listOf(Color(0xFF2A3544), Color(0xFF6B829B))
    }
    Surface(
        modifier = Modifier.width(96.dp).height(76.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(if (selected) 2.dp else 1.dp, if (selected) MaterialTheme.colorScheme.primary else Color.White.copy(.10f)),
        color = Color.Transparent
    ) {
        Box(Modifier.fillMaxSize().background(Brush.linearGradient(colors))) {
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(.58f)))))
            if (selected) {
                Icon(Icons.Default.CheckCircle, null, tint = Color.White, modifier = Modifier.align(Alignment.TopEnd).padding(6.dp).size(18.dp))
            } else if (locked) {
                Icon(Icons.Default.Lock, null, tint = Color.White.copy(.92f), modifier = Modifier.align(Alignment.TopEnd).padding(6.dp).size(15.dp))
            }
            if (pro) {
                Surface(
                    modifier = Modifier.align(Alignment.TopStart).padding(6.dp),
                    shape = RoundedCornerShape(50),
                    color = Color.Black.copy(alpha = .32f)
                ) { Text("PRO", color = Color.White, fontSize = 6.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)) }
            }
            Text(shareFilterShortName(filter), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 8.sp, modifier = Modifier.align(Alignment.BottomStart).padding(8.dp), maxLines = 1)
        }
    }
}

@OptIn(androidx.media3.common.util.UnstableApi::class)
private fun buildSharePreviewPlayer(context: Context, uri: String): ExoPlayer {
    val builder = ExoPlayer.Builder(context)
    if (uri.startsWith("http", true)) {
        val http = DefaultHttpDataSource.Factory().setConnectTimeoutMs(7_000).setReadTimeoutMs(12_000).setAllowCrossProtocolRedirects(true)
        builder.setMediaSourceFactory(DefaultMediaSourceFactory(context).setDataSourceFactory(http))
    }
    return builder.build().apply {
        setAudioAttributes(Media3AudioAttributes.DEFAULT, true)
        volume = 1f
        repeatMode = Player.REPEAT_MODE_OFF
    }
}

private suspend fun resolveShareSourceAudioUri(source: SonusShareSource, repo: SonusOnlineMusicRepository): String =
    withContext(Dispatchers.IO) {
        source.streamTrack?.let { return@withContext runCatching { repo.resolvePlaybackUrl(it.fileId) }.getOrDefault("") }
        source.audioUri
    }

private suspend fun resolveShareSourceDurationMs(context: Context, source: SonusShareSource, repo: SonusOnlineMusicRepository): Long =
    withContext(Dispatchers.IO) {
        if (source.durationMs > 0L) return@withContext source.durationMs
        source.streamTrack?.let { track ->
            val cachedDuration = repo.cachedResolvedDurationMs(track.fileId)
            if (cachedDuration > 0L) return@withContext cachedDuration
            return@withContext runCatching {
                val stream = repo.resolvePlaybackStream(track.fileId)
                resolveStreamDurationMs(repo, track, stream)
            }.getOrDefault(0L)
        }
        val uri = runCatching { Uri.parse(source.audioUri) }.getOrNull() ?: return@withContext 0L
        val retriever = MediaMetadataRetriever()
        try {
            if (uri.scheme.equals("content", true)) retriever.setDataSource(context, uri)
            else retriever.setDataSource(source.audioUri)
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (_: Throwable) { 0L } finally { runCatching { retriever.release() } }
    }

/** Lê a duração do stream remoto e mantém o resultado no cache local do catálogo. */
private fun resolveStreamDurationMs(
    repo: SonusOnlineMusicRepository,
    track: SonusOnlineTrack,
    stream: SonusResolvedStream
): Long {
    val cachedDuration = repo.cachedResolvedDurationMs(track.fileId)
    if (cachedDuration > 0L) return cachedDuration
    if (track.durationMs > 0L) {
        repo.rememberResolvedDurationMs(track.fileId, track.durationMs)
        return track.durationMs
    }

    val retriever = MediaMetadataRetriever()
    val duration = try {
        retriever.setDataSource(stream.url, stream.headers)
        retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
    } catch (_: Throwable) {
        0L
    } finally {
        runCatching { retriever.release() }
    }
    if (duration > 0L) repo.rememberResolvedDurationMs(track.fileId, duration)
    return duration
}

@Composable
private fun SonusShareGalleryThumbnail(image: SonusShareGalleryImage, code: String, selected: Boolean, selectionIndex: Int? = null, onClick: () -> Unit) {
    val bitmap by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, image.sourceCode, image.fileId) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                val url = SonusPCloudClient.publicThumbnailUrl(image.sourceCode.ifBlank { code }, image.fileId)
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 8_000; conn.readTimeout = 12_000
                try { conn.inputStream.use { BitmapFactory.decodeStream(it)?.asImageBitmap() } } finally { conn.disconnect() }
            }.getOrNull()
        }
    }
    Surface(
        modifier = Modifier.size(86.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(if (selected) 3.dp else 1.dp, if (selected) MaterialTheme.colorScheme.primary else Color.White.copy(alpha=.10f)),
        color = Color.White.copy(alpha=.04f)
    ) {
        Box(contentAlignment = Alignment.Center) {
            if (bitmap != null) Image(bitmap!!, image.name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
            if (selected) Surface(Modifier.align(Alignment.TopEnd).padding(5.dp).size(22.dp), shape = androidx.compose.foundation.shape.CircleShape, color = MaterialTheme.colorScheme.primary) {
                Box(contentAlignment = Alignment.Center) { Text((selectionIndex ?: 1).toString(), color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Black) }
            }
        }
    }
}


/**
 * Ranks the public pCloud artwork catalog for one track without requiring folders.
 * Filename segments separated by "__" act as tags. Exact title/theme matches beat
 * broad genre matches so specific subjects (for example Nossa Senhora Aparecida)
 * are not buried under generic "catolica" artwork.
 */
private fun normalizeShareGallerySearch(value: String): String {
    val decomposed = Normalizer.normalize(value.lowercase(Locale.ROOT), Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "")
    return decomposed
        .replace(Regex("[_\\-\\p{Punct}]+"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()
}

private fun searchShareGalleryImages(
    images: List<SonusShareGalleryImage>,
    rawQuery: String
): List<SonusShareGalleryImage> {
    val query = normalizeShareGallerySearch(rawQuery)
    if (query.isBlank()) return images
    val tokens = query.split(' ').filter { it.isNotBlank() }.distinct()

    data class Hit(val image: SonusShareGalleryImage, val score: Int)
    return images.mapNotNull { image ->
        val name = normalizeShareGallerySearch(image.name.substringBeforeLast('.'))
        if (name.isBlank()) return@mapNotNull null
        val words = name.split(' ').filter { it.isNotBlank() }
        val exactPhrase = name.contains(query)
        val tokenMatches = tokens.count { token ->
            words.any { word -> word == token || word.startsWith(token) || word.contains(token) } || name.contains(token)
        }
        if (!exactPhrase && tokenMatches == 0) return@mapNotNull null
        val allTokens = tokenMatches == tokens.size
        val starts = tokens.count { token -> words.any { it.startsWith(token) } }
        Hit(image, (if (exactPhrase) 1000 else 0) + (if (allTokens) 500 else 0) + tokenMatches * 80 + starts * 20)
    }.sortedWith(compareByDescending<Hit> { it.score }.thenBy { it.image.name.lowercase(Locale.ROOT) })
        .map { it.image }
}

private fun socialEditMaxSelectedImages(durationSeconds:Int):Int = when(durationSeconds) {
    15 -> 3
    30 -> 6
    40 -> 8
    50 -> 10
    60 -> 12
    65 -> 13
    else -> (durationSeconds / 5).coerceIn(1, 13)
}

private fun socialEditGalleryPreviewLimit(durationSeconds:Int):Int = when(durationSeconds) {
    15 -> 8
    30 -> 10
    40 -> 12
    50 -> 15
    60, 65 -> 20
    else -> 8
}

/**
 * Divide a duração REAL do projeto igualmente entre as imagens selecionadas.
 * Os 5 segundos são somente o mínimo permitido por imagem / limite de seleção;
 * nunca uma duração fixa. A última imagem absorve qualquer resto de arredondamento
 * para que a soma feche exatamente na duração total do vídeo.
 */
private fun socialEditImageDurations(totalDurationMs: Long, imageCount: Int): List<Long> {
    require(imageCount > 0) { "Selecione pelo menos uma imagem." }
    val safeTotal = totalDurationMs.coerceAtLeast(imageCount.toLong())
    val base = safeTotal / imageCount
    val remainder = safeTotal % imageCount
    return List(imageCount) { index ->
        base + if (index == imageCount - 1) remainder else 0L
    }
}

private fun rankShareGalleryImages(
    context: Context,
    track: SonusOnlineTrack,
    images: List<SonusShareGalleryImage>,
    limit: Int = 8,
    seed: Long = 0L
): List<SonusShareGalleryImage> {
    if (images.isEmpty()) return emptyList()

    fun norm(value: String): String = normalizeStreamSearch(value)
        .replace(Regex("[^a-z0-9]+"), " ")
        .trim()
        .replace(Regex("\\s+"), " ")

    val title = norm(track.displayTitle)
    val artist = norm(track.artist)
    val album = norm(track.album)
    val genre = norm(track.genre)
    val lyric = norm(track.lyrics.take(3_200))
    val artistGenreProfile = SonusArtistGenreCatalog.find(context, track.artist)
    // Palavras de entidade religiosa no CSV não viram "gênero" por si só. Assim um
    // artista católico não força Maria/Jesus em toda música; essas entidades continuam
    // vindo do título/letra, enquanto "catolico/gospel" orienta a família visual.
    val entityOnlyGenreTerms = setOf("maria", "nossa senhora", "jesus", "cristo", "santo", "santa")
    val artistGenreKeywords = artistGenreProfile?.allKeywords.orEmpty()
        .map(::norm)
        .filter { it.isNotBlank() && it !in entityOnlyGenreTerms }
        .toSet()
    val artistGenreCategory = norm(artistGenreProfile?.category.orEmpty())
    val artistGenreWeight = when (artistGenreProfile?.confidence) {
        "high" -> 92
        "medium" -> 62
        else -> 42
    }
    val semanticContext = listOf(title, artist, album, genre, lyric, artistGenreKeywords.joinToString(" ")).filter { it.isNotBlank() }.joinToString(" ")
    val contextWords = semanticContext.split(' ').filter { it.length >= 3 }.toSet()

    // Relações semânticas específicas continuam tendo prioridade sobre o gênero amplo.
    val relations = mapOf(
        "aparecida" to setOf("nossa senhora aparecida", "nossa senhora", "maria", "padroeira", "devocao"),
        "nossa senhora" to setOf("maria", "virgem", "mae de jesus", "mae", "devocao"),
        "maria" to setOf("nossa senhora", "virgem", "mae de jesus", "devocao"),
        "jesus" to setOf("cristo", "salvador", "cruz", "fe"),
        "cristo" to setOf("jesus", "salvador", "cruz", "fe"),
        "sofrencia" to setOf("saudade", "termino", "coracao partido", "bar", "cerveja"),
        "saudade" to setOf("sofrencia", "termino", "coracao partido", "amor"),
        "romantica" to setOf("amor", "casal", "romance", "saudade"),
        "romantico" to setOf("amor", "casal", "romance", "saudade"),
        "trap" to setOf("urbano", "cidade noturna", "melancolico", "rua"),
        "catolica" to setOf("fe", "igreja", "jesus", "maria", "devocao"),
        "gospel" to setOf("fe", "igreja", "jesus", "oracao", "louvor")
    )

    val activeThemes = buildSet<String> {
        relations.forEach { (theme, related) ->
            if (semanticContext.contains(theme)) {
                add(theme)
                addAll(related)
            }
        }
    }

    data class GenreFamily(
        val id: String,
        val genreAliases: Set<String>,
        val visualTerms: Set<String>,
        val conflictingTerms: Set<String>
    )

    val families = listOf(
        GenreFamily(
            "faith",
            setOf("catolico", "catolica", "gospel", "cristao", "crista", "religioso", "religiosa"),
            setOf("igreja", "cruz", "biblia", "oracao", "ceu", "luz", "fe", "devocao", "jesus", "cristo", "maria", "nossa senhora", "santo", "santa", "altar"),
            setOf("balada", "boate", "ostentacao")
        ),
        GenreFamily(
            "urban",
            setOf("rap", "hip hop", "hiphop", "trap"),
            setOf("urbano", "cidade", "rua", "noite", "neon", "estudio", "predio", "grafite", "carro", "cidade noturna"),
            setOf("vaquejada", "sanfona", "roca")
        ),
        GenreFamily(
            "forro",
            setOf("forro", "piseiro", "vaquejada", "arrocha"),
            setOf("interior", "palco", "festa", "casal", "estrada", "sanfona", "vaquejada", "roca", "sertanejo", "amor", "romance"),
            setOf("grafite", "cyberpunk")
        ),
        GenreFamily(
            "sertanejo",
            setOf("sertanejo", "sofrencia"),
            setOf("casal", "amor", "saudade", "bar", "cerveja", "estrada", "interior", "palco", "violao"),
            setOf("cyberpunk")
        ),
        GenreFamily(
            "rock",
            setOf("rock", "metal", "indie rock"),
            setOf("guitarra", "banda", "palco", "show", "amplificador", "rock", "metal"),
            setOf("sanfona", "vaquejada")
        ),
        GenreFamily(
            "electronic",
            setOf("eletronica", "electronic", "edm", "dance"),
            setOf("neon", "dj", "pista", "festival", "luzes", "cidade", "futurista"),
            setOf("vaquejada", "sanfona")
        ),
        GenreFamily(
            "samba",
            setOf("samba", "pagode"),
            setOf("roda", "samba", "pagode", "cavaquinho", "pandeiro", "festa", "bar", "casal"),
            setOf("cyberpunk")
        )
    )

    fun containsPhrase(haystack: String, term: String): Boolean =
        term.isNotBlank() && (haystack == term || haystack.contains(term))

    val genreSignals = (setOf(genre, artistGenreCategory) + artistGenreKeywords).filter { it.isNotBlank() }
    val activeFamilies = families.filter { family ->
        family.genreAliases.any { alias -> genreSignals.any { containsPhrase(it, alias) } }
    }
    val explicitTrackContext = listOf(title, album, lyric).joinToString(" ")
    val faithTerms = setOf("jesus", "cristo", "maria", "nossa senhora", "deus", "oracao", "fe", "igreja", "santo", "santa", "cruz", "devocao")
    val lyricFaith = faithTerms.any(explicitTrackContext::contains)
    val lyricRomantic = setOf("amor", "saudade", "coracao", "beijo", "casal", "romance", "apaixon").any(explicitTrackContext::contains)
    val profileFaith = artistGenreCategory in setOf("catolico", "gospel")

    data class Scored(val image: SonusShareGalleryImage, val score: Int, val neutral: Boolean)
    val scored = images.map { image ->
        val rawStem = image.name.substringBeforeLast('.')
        val filename = norm(rawStem)
        val tagSegments = rawStem.split("__").map(::norm).filter { it.isNotBlank() }
        val tagWords = tagSegments.flatMap { it.split(' ') }.filter { it.length >= 3 }.toSet()
        val imageText = (listOf(filename) + tagSegments).joinToString(" ")
        var score = 0

        // 1) Título/assunto explícito continua soberano.
        if (title.length >= 4 && filename.contains(title)) score += 210
        title.split(' ').windowed(2, 1, partialWindows = false).forEach { pair ->
            if (filename.contains(pair.joinToString(" "))) score += 60
        }

        // 2) Pessoas/temas inferidos pela letra e título.
        activeThemes.forEach { theme ->
            if (imageText.contains(theme)) score += if (theme.contains(' ')) 90 else 62
        }

        // 3) Tags/contexto textual.
        score += tagWords.count { it in contextWords } * 15
        score += tagSegments.count { segment -> segment.length >= 4 && semanticContext.contains(segment) } * 26

        // 3b) Catálogo artista -> gênero. É um sinal forte, não um filtro absoluto.
        if (artistGenreProfile != null) {
            val directArtistGenreMatches = artistGenreKeywords.count { containsPhrase(imageText, it) }
            if (directArtistGenreMatches > 0) {
                score += (directArtistGenreMatches * artistGenreWeight).coerceAtMost(artistGenreWeight * 2)
            }
            if (artistGenreCategory.isNotBlank() && containsPhrase(imageText, artistGenreCategory)) score += artistGenreWeight

            // Evita o erro clássico: imagem de Maria/Nossa Senhora para um artista de
            // sertanejo/funk/etc. quando a própria música não tem contexto religioso.
            val faithImage = faithTerms.any { containsPhrase(imageText, it) }
            if (!profileFaith && !lyricFaith && faithImage) score -= 260
        }

        // 4) Família de gênero: contexto forte, mas nunca filtro absoluto.
        var hasFamilySignal = false
        activeFamilies.forEach { family ->
            val directAlias = family.genreAliases.any { containsPhrase(imageText, it) }
            val visualMatches = family.visualTerms.count { containsPhrase(imageText, it) }
            val conflicts = family.conflictingTerms.count { containsPhrase(imageText, it) }
            if (directAlias) { score += 48; hasFamilySignal = true }
            if (visualMatches > 0) { score += (visualMatches * 34).coerceAtMost(102); hasFamilySignal = true }
            if (conflicts > 0) score -= (conflicts * 58).coerceAtMost(116)
        }

        // O tema da letra refina o gênero. Trap religioso e forró romântico são exemplos importantes.
        if (lyricFaith && setOf("igreja", "cruz", "biblia", "oracao", "ceu", "luz", "jesus", "cristo", "maria", "nossa senhora").any(imageText::contains)) {
            score += 72
        }
        if (lyricRomantic && setOf("casal", "amor", "romance", "saudade", "coracao", "estrada").any(imageText::contains)) {
            score += 52
        }

        // Compatibilidade literal com o gênero informado ainda ajuda, agora com peso útil.
        if (genre.length >= 3 && filename.contains(genre)) score += 34

        // Imagem neutra = não possui sinais fortes de nenhuma família; é o fallback seguro.
        val anySpecificSignal = families.any { family ->
            family.genreAliases.any { containsPhrase(imageText, it) } ||
                family.visualTerms.any { containsPhrase(imageText, it) }
        }
        Scored(image, score, neutral = !anySpecificSignal)
    }

    val wanted = limit.coerceIn(4, 20)
    val positive = scored.filter { it.score > 0 }
    val random = Random(if (seed != 0L) seed else track.displayTitle.hashCode().toLong())
    if (positive.isNotEmpty()) {
        // Sorteio ponderado sem reposição: a relevância define o conjunto; a aleatoriedade varia a sequência.
        val pool = positive.toMutableList()
        val out = ArrayList<SonusShareGalleryImage>(wanted)
        while (pool.isNotEmpty() && out.size < wanted) {
            val weights = pool.map { (it.score.coerceAtLeast(1) + 24).coerceAtMost(2_000) }
            val total = weights.sum().coerceAtLeast(1)
            var ticket = random.nextInt(total)
            var chosen = 0
            for (i in pool.indices) {
                ticket -= weights[i]
                if (ticket < 0) { chosen = i; break }
            }
            out += pool.removeAt(chosen).image
        }
        return out
    }

    // Sem match semântico, prefira imagens neutras para não inventar uma estética incompatível.
    val neutral = scored.filter { it.neutral }.map { it.image }
    return (if (neutral.isNotEmpty()) neutral else images).shuffled(random).take(wanted)
}

private fun shareFilterShortName(name: String): String = when (name) {
    "Preto e Branco" -> "P&B"
    "Pôr do Sol" -> "Sol"
    "Filme Vintage" -> "Vintage"
    "Cidade Noturna" -> "Noturno"
    else -> name
}

private fun formatShareClock(ms: Long): String {
    val sec = (ms / 1000L).coerceAtLeast(0L)
    return "%02d:%02d".format(sec / 60L, sec % 60L)
}

private data class ShareTimedLyric(val atMs: Long, val text: String)

private fun cleanShareLyricText(raw:String):String =
    raw.replace(Regex("\\[[^\\]]*]"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

private fun parseShareLrc(text: String): List<ShareTimedLyric> {
    val timeRegex = Regex("\\[(\\d{1,3}):(\\d{2})(?:[.,](\\d{1,3}))?]")
    val offsetMs = Regex("\\[offset:([+-]?\\d+)]", RegexOption.IGNORE_CASE).find(text)?.groupValues?.getOrNull(1)?.toLongOrNull() ?: 0L
    val lines = mutableListOf<ShareTimedLyric>()
    text.lineSequence().forEach { raw ->
        val matches = timeRegex.findAll(raw).toList()
        if (matches.isEmpty()) return@forEach
        val withoutTimes = raw.replace(timeRegex, "")
        val lyric = cleanShareLyricText(withoutTimes).takeIf { it.isNotBlank() } ?: return@forEach
        matches.forEach { m ->
            val min = m.groupValues[1].toLongOrNull() ?: 0L
            val sec = m.groupValues[2].toLongOrNull() ?: 0L
            val frac = m.groupValues[3].padEnd(3, '0').take(3).toLongOrNull() ?: 0L
            lines += ShareTimedLyric(((min * 60L + sec) * 1000L + frac + offsetMs).coerceAtLeast(0L), lyric.take(220))
        }
    }
    return lines.sortedBy { it.atMs }.distinctBy { it.atMs to it.text }
}

private fun shareWrapText(text:String,maxChars:Int,maxLines:Int=2):String {
    val words=text.trim().split(Regex("\\s+")).filter{it.isNotBlank()}
    if(words.isEmpty()) return ""
    val lines=mutableListOf<String>()
    var current=""
    for(word in words){
        val candidate=if(current.isBlank())word else "$current $word"
        if(candidate.length<=maxChars || current.isBlank()) current=candidate
        else{
            lines+=current
            current=word
            if(lines.size>=maxLines-1) break
        }
    }
    if(lines.size<maxLines && current.isNotBlank()) lines+=current
    val consumed=lines.joinToString(" ").replace("\n"," ").length
    val original=text.trim().replace(Regex("\\s+")," ")
    if(consumed<original.length && lines.isNotEmpty()){
        lines[lines.lastIndex]=lines.last().take((maxChars-1).coerceAtLeast(4)).trimEnd { it.isWhitespace() }+ "…"
    }
    return lines.take(maxLines).joinToString("\n")
}

private fun shareAdaptiveFont(text:String,base:Float,min:Float):Float = when {
    text.length<=28 -> base
    text.length<=48 -> (base-2f).coerceAtLeast(min)
    text.length<=72 -> (base-4f).coerceAtLeast(min)
    else -> min
}

private fun ensureSonusShareLogo(context:Context):File {
    val out=File(context.cacheDir,"sonus_share_mark_official.png")
    if(!out.exists() || out.length()==0L){
        context.resources.openRawResource(R.drawable.sonus_share_mark).use{input->
            out.outputStream().use{output->input.copyTo(output)}
        }
    }
    return out
}

private fun evenVideoDimension(value:Int):Int = value.coerceAtLeast(2).let{if(it%2==0)it else it-1}.coerceAtLeast(2)

private fun adaptive1080Canvas(imageFile:File):Pair<Int,Int>{
    val options=BitmapFactory.Options().apply{inJustDecodeBounds=true}
    BitmapFactory.decodeFile(imageFile.absolutePath,options)
    require(options.outWidth > 0 && options.outHeight > 0) { "Não foi possível ler as dimensões da imagem selecionada." }
    val w=options.outWidth;val h=options.outHeight
    var outW:Int;var outH:Int
    if(w==h){outW=1080;outH=1080}
    else if(w>h){outH=1080;outW=(1080.0*w/h).roundToInt()}
    else{outW=1080;outH=(1080.0*h/w).roundToInt()}
    val longest=maxOf(outW,outH)
    if(longest>2160){val scale=2160.0/longest;outW=(outW*scale).roundToInt();outH=(outH*scale).roundToInt()}
    return evenVideoDimension(outW) to evenVideoDimension(outH)
}

@OptIn(androidx.media3.common.util.UnstableApi::class)
private suspend fun createSonusShareVideo(
    context: Context,
    repo: SonusOnlineMusicRepository,
    source: SonusShareSource,
    images: List<SonusShareGalleryImage>,
    galleryCode: String,
    durationSeconds: Int,
    startMs: Long,
    filter: String,
    signatureText: String,
    signatureLogoUri: Uri?,
    onProgress: (Int, String) -> Unit
): Result<Uri> = runCatching {
    val durationMs = durationSeconds.coerceIn(15,65) * 1000L
    val safeStart = startMs.coerceAtLeast(0L)
    val safeEnd = if (source.durationMs > 0L) (safeStart + durationMs).coerceAtMost(source.durationMs) else safeStart + durationMs
    val actualDuration = (safeEnd - safeStart).coerceAtLeast(1_000L)
    val selectedImages = images.distinctBy { "${it.sourceCode}:${it.fileId}" }.take(socialEditMaxSelectedImages(durationSeconds))
    require(selectedImages.isNotEmpty()) { "Selecione pelo menos uma imagem." }
    onProgress(2, "Baixando imagens")
    val imageFiles = withContext(Dispatchers.IO) {
        selectedImages.mapIndexed { index, image ->
            val ext = image.name.substringAfterLast('.', "jpg").lowercase(Locale.ROOT).takeIf { it in setOf("jpg","jpeg","png","webp") } ?: "jpg"
            val sourceCode = image.sourceCode.ifBlank { galleryCode }
            val out = File(context.cacheDir, "sonus_share_${sourceCode.hashCode()}_${image.fileId}_${System.currentTimeMillis()}_${index}.$ext")
            val url = SonusPCloudClient.publicFileUrl(sourceCode, image.fileId)
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout = 15_000; conn.readTimeout = 30_000; conn.instanceFollowRedirects = true
            try { conn.inputStream.use { input -> out.outputStream().use { output -> input.copyTo(output, 256 * 1024) } } } finally { conn.disconnect() }
            require(out.length() > 0L) { "Uma das imagens selecionadas não pôde ser baixada." }
            out
        }
    }
    // Compartilhar usa saída social previsível: 9:16 físico, sem depender de metadata de rotação.
    val canvasWidth = 1080
    val canvasHeight = 1920
    try {
        onProgress(6, "Preparando áudio")
        val audioUrl = resolveShareSourceAudioUri(source,repo)
        require(audioUrl.isNotBlank()){"Não foi possível acessar o áudio selecionado."}
        val lrc = if(source.streamTrack!=null){
            val track=source.streamTrack
            val lyricSource=repo.lyricsForFileIdAuto(track.fileId) ?: track.lyrics.takeIf{it.isNotBlank()}?.let{it to track.lyricsFormat}
            lyricSource?.takeIf{it.second.equals("LRC",true)||it.first.contains(Regex("\\[\\d{1,3}:\\d{2}"))}?.first.orEmpty()
        } else source.lrcText
        val lyrics = parseShareLrc(lrc)
        val clipEnd = safeStart + actualDuration
        val palette = intArrayOf(
            android.graphics.Color.rgb(255,227,77),
            android.graphics.Color.rgb(72,255,154),
            android.graphics.Color.rgb(255,77,109),
            android.graphics.Color.rgb(72,200,255),
            android.graphics.Color.rgb(190,124,255),
            android.graphics.Color.rgb(255,101,200)
        )
        val lyricLayers = lyrics.mapIndexedNotNull { index, line ->
            val next = lyrics.getOrNull(index + 1)?.atMs ?: clipEnd
            if(next <= safeStart || line.atMs >= clipEnd) return@mapIndexedNotNull null
            val layerStart=(maxOf(line.atMs,safeStart)-safeStart).coerceAtLeast(0L)
            val layerEnd=(minOf(next,clipEnd)-safeStart).coerceAtLeast(layerStart+500L).coerceAtMost(actualDuration)
            val wrapped=shareWrapText(line.text,if(canvasHeight>=canvasWidth)34 else 52,2)
            if(wrapped.isBlank()) return@mapIndexedNotNull null
            PulseCompositionExporter.TextLayer(
                text = wrapped,
                colorArgb = palette[index % palette.size],
                startMs = layerStart,
                endMs = layerEnd,
                presetName = "Pulse Sans Regular",
                fontSize = shareAdaptiveFont(line.text,24f,17f),
                positionX = 0f,
                positionY = .02f,
                strokeWidth = 1.8f,
                strokeColorArgb = android.graphics.Color.argb(220,0,0,0),
                shadowEnabled = true,
                glowRadius = .30f,
                lineHeightScale = 1.04f,
                autoFitSafeWidth = true,
                maxWidthFraction = .84f,
                entryAnimation = "Fade In",
                exitAnimation = "Fade Out"
            )
        }
        val titleText=shareWrapText(source.title,if(canvasHeight>=canvasWidth)38 else 60,2)
        val artistText=shareWrapText(source.displayArtist.uppercase(Locale.ROOT),if(canvasHeight>=canvasWidth)44 else 70,1)
        val identityLayers = buildList {
            signatureText.trim().takeIf { it.isNotBlank() }?.let { signature ->
                add(PulseCompositionExporter.TextLayer(
                    text = signature,
                    colorArgb = android.graphics.Color.WHITE,
                    startMs = 0L, endMs = actualDuration,
                    presetName = "SONUS Cursive",
                    fontFamilyName = "cursive",
                    italic = true,
                    fontSize = shareAdaptiveFont(signature, 17f, 12f),
                    positionX = if (signatureLogoUri != null) .10f else 0f,
                    positionY = -.84f,
                    strokeWidth = .8f,
                    strokeColorArgb = android.graphics.Color.argb(180,0,0,0),
                    shadowEnabled = true,
                    autoFitSafeWidth = true,
                    maxWidthFraction = if (signatureLogoUri != null) .58f else .72f,
                    entryAnimation = "Nenhum", exitAnimation = "Nenhum"
                ))
            }
            add(PulseCompositionExporter.TextLayer(
                text = titleText,
                colorArgb = android.graphics.Color.rgb(255,224,70),
                startMs = 0L, endMs = actualDuration,
                presetName = "Pulse Sans Regular",
                fontSize = shareAdaptiveFont(source.title,21f,15f),
                positionX = 0f, positionY = .69f,
                strokeWidth = 1.4f, strokeColorArgb = android.graphics.Color.argb(220,0,0,0),
                shadowEnabled=true, glowRadius=.10f,
                lineHeightScale=1.02f,
                autoFitSafeWidth = true,
                maxWidthFraction = .82f,
                entryAnimation = "Nenhum", exitAnimation = "Nenhum"
            ))
            add(PulseCompositionExporter.TextLayer(
                text = artistText,
                colorArgb = android.graphics.Color.WHITE,
                startMs = 0L, endMs = actualDuration,
                presetName = "Pulse Sans Regular",
                fontSize = shareAdaptiveFont(source.displayArtist,17f,13f),
                positionX = 0f, positionY = .735f,
                strokeWidth = 1.2f, strokeColorArgb = android.graphics.Color.argb(220,0,0,0),
                shadowEnabled=true,
                autoFitSafeWidth = true,
                maxWidthFraction = .84f,
                entryAnimation = "Nenhum", exitAnimation = "Nenhum"
            ))
        }
        val summary = PulseCompositionExporter.export(
            context = context,
            visuals = buildList {
                val durations = socialEditImageDurations(actualDuration, imageFiles.size)
                imageFiles.forEachIndexed { index, file ->
                    val segmentDuration = durations[index]
                    add(PulseCompositionExporter.Visual(
                        uri = Uri.fromFile(file),
                        isImage = true,
                        durationMs = segmentDuration,
                        trimStartMs = 0L,
                        trimEndMs = segmentDuration,
                        animationIn = "Fade In 1.5s",
                        animationOut = "Fade Out 1.5s"
                    ))
                }
            },
            audios = listOf(PulseCompositionExporter.Audio(
                uri = Uri.parse(audioUrl),
                trimStartMs = safeStart,
                trimEndMs = safeStart + actualDuration,
                fadeInMs = 2_000L,
                fadeOutMs = 2_000L
            )),
            outputName = "SONUS_${source.title.take(45).replace(Regex("[^A-Za-z0-9À-ÿ _-]"), "_")}_${System.currentTimeMillis()}.mp4",
            fps = 60,
            codec = "H.264",
            keepHdr = false,
            canvasWidth = canvasWidth,
            canvasHeight = canvasHeight,
            fillCrop = true,
            bitrateMbps = 12,
            grade = PulseCompositionExporter.Grade(filter = filter),
            selectedEffect = "Nenhum",
            muteOriginalMedia = true,
            textLayers = identityLayers + lyricLayers,
            mediaOverlay = signatureLogoUri?.let { logoUri ->
                PulseCompositionExporter.MediaOverlay(
                    uri = logoUri, isImage = true, startMs = 0L, endMs = actualDuration,
                    scale = .105f, opacity = .96f,
                    positionX = if (signatureText.isBlank()) 0f else -.18f,
                    positionY = -.84f
                )
            },
            extraMediaOverlays = listOf(
                PulseCompositionExporter.MediaOverlay(
                    uri = Uri.parse("android.resource://${context.packageName}/${R.raw.sonus_share_particles}"),
                    isImage = false,
                    startMs = 0L,
                    endMs = actualDuration,
                    scale = 1f,
                    opacity = .46f,
                    positionX = 0f,
                    positionY = 0f,
                    effectName = "Chroma Key",
                    loop = true,
                    fullFrame = true
                )
            ),
            visualizer = null,
            onProgress = { p -> onProgress(p.percent.coerceAtLeast(8), p.phase) }
        ).getOrThrow()
        require(kotlin.math.abs(summary.width-canvasWidth)<=2 && kotlin.math.abs(summary.height-canvasHeight)<=2) { "O vídeo não respeitou a proporção solicitada: esperado ${canvasWidth}×${canvasHeight}, recebido ${summary.width}×${summary.height}." }
        summary.uri
    } finally {
        imageFiles.forEach { file -> runCatching { file.delete() } }
    }
}


@Composable
private fun SonusOnlineTrackRow(
    track: SonusOnlineTrack,
    repo: SonusOnlineMusicRepository,
    accent: Color,
    favorite:Boolean,
    onFavorite:()->Unit,
    onAddPlaylist:()->Unit,
    onShare:()->Unit,
    onReport:()->Unit,
    showGenreStatus: Boolean = false,
    genreStatusLabel: String? = null,
    onPlay: (SonusOnlineTrack) -> Unit
) {
    val artwork by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, track.fileId) {
        value=withContext(Dispatchers.IO){repo.cachedArtwork(track) ?: repo.artwork(track)}
    }
    Surface(modifier=Modifier.fillMaxWidth().clickable{onPlay(track)},shape=RoundedCornerShape(15.dp),color=Color(0xFF17141E).copy(alpha=.96f),border=BorderStroke(1.dp,Color.White.copy(alpha=.06f))) {
        Row(Modifier.padding(9.dp),verticalAlignment=Alignment.CenterVertically) {
            Box(Modifier.size(52.dp).clip(RoundedCornerShape(11.dp)).background(accent.copy(alpha=.13f)),contentAlignment=Alignment.Center) {
                if(artwork!=null) Image(artwork!!,null,Modifier.fillMaxSize(),contentScale=ContentScale.Crop) else Icon(Icons.Default.MusicNote,null,tint=accent)
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(track.displayTitle,color=Color.White,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis)
                Text(track.artist.ifBlank{"SONUS Stream"},color=Color.White.copy(alpha=.58f),fontSize=9.sp,maxLines=1,overflow=TextOverflow.Ellipsis)
                if (showGenreStatus) {
                    Text("${genreStatusLabel?.takeIf { it.isNotBlank() } ?: track.genre.ifBlank { "Gênero não informado" }} • Disponível no Stream",color=Color(0xFF80DCC4),fontSize=8.sp,maxLines=1,overflow=TextOverflow.Ellipsis)
                } else if(track.album.isNotBlank()) Text(track.album,color=Color.White.copy(alpha=.40f),fontSize=8.sp,maxLines=1,overflow=TextOverflow.Ellipsis)
            }
            IconButton(onClick=onFavorite){Icon(if(favorite)Icons.Default.Favorite else Icons.Default.FavoriteBorder,null,tint=if(favorite)Color(0xFFFF6787) else Color.White.copy(alpha=.52f))}
            IconButton(onClick=onAddPlaylist){Icon(Icons.Default.PlaylistAdd,"Adicionar à playlist",tint=Color.White.copy(alpha=.62f))}
            IconButton(onClick=onShare){Icon(Icons.Default.Share,"Compartilhar",tint=accent)}
            IconButton(onClick=onReport){Icon(Icons.Default.Flag,"Denunciar problema",tint=Color.White.copy(alpha=.52f))}
            Icon(Icons.Default.PlayArrow,"Reproduzir",tint=accent)
        }
    }
}

@Composable
internal fun SonusMusicDeveloperPanel(authUser: AuthUser, pendingLrc: String? = null, onPendingLrcConsumed: () -> Unit = {}) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val repo = remember { SonusOnlineMusicRepository(context) }
    val streamRepo = remember { SonusStreamPlatformRepository(context) }
    var genres by remember { mutableStateOf(repo.cachedGenres()) }
    var tracks by remember { mutableIntStateOf(repo.cachedTrackCount()) }
    var published by remember { mutableStateOf(repo.cachedPublishedGenres()) }
    var directOverrides by remember { mutableStateOf<Map<Long, String>>(emptyMap()) }
    var lastRefresh by remember { mutableLongStateOf(repo.lastRefreshMillis()) }
    var status by remember { mutableStateOf<String?>(null) }
    var sourceDiagnostics by remember { mutableStateOf<List<String>>(emptyList()) }
    var checkingSources by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    // code133: cada pasta tem o seu próprio "salvando"; o botão não depende mais do "Atualizar" (busy).
    var savingGenres by remember { mutableStateOf<Set<String>>(emptySet()) }
    val publishMutex = remember { Mutex() }
    var expandedGenre by remember { mutableStateOf<String?>(null) }
    var selectedTrack by remember { mutableStateOf<SonusOnlineTrack?>(null) }
    var overrideUrl by remember { mutableStateOf("") }
    var overrideStatus by remember { mutableStateOf<String?>(null) }
    var overrideBusy by remember { mutableStateOf(false) }
    var editTitle by remember { mutableStateOf("") }
    var editArtist by remember { mutableStateOf("") }
    var editAlbum by remember { mutableStateOf("") }
    var editGenre by remember { mutableStateOf("") }
    var editYear by remember { mutableStateOf("") }
    var editTrackNumber by remember { mutableStateOf("") }
    var editLyrics by remember { mutableStateOf("") }
    var editLyricsFormat by remember { mutableStateOf("TEXT") }
    var editCoverBase64 by remember { mutableStateOf("") }
    var search by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("Todas") }
    var showBulkMetadataEditor by remember { mutableStateOf(false) }

    val coverPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            scope.launch(Dispatchers.IO) {
                val encoded = runCatching {
                    val bitmap = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                        ?: error("Não foi possível ler a imagem")
                    val maxSide = 900
                    val ratio = minOf(1f, maxSide.toFloat() / maxOf(bitmap.width, bitmap.height).coerceAtLeast(1))
                    val scaled = if (ratio < 1f) Bitmap.createScaledBitmap(bitmap, (bitmap.width * ratio).toInt().coerceAtLeast(1), (bitmap.height * ratio).toInt().coerceAtLeast(1), true) else bitmap
                    val out = ByteArrayOutputStream(); scaled.compress(Bitmap.CompressFormat.JPEG, 82, out)
                    Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
                }
                withContext(Dispatchers.Main) {
                    encoded.onSuccess { editCoverBase64 = it; overrideStatus = "✓ Capa pronta para salvar" }
                        .onFailure { overrideStatus = "Falha ao ler capa: ${it.message}" }
                }
            }
        }
    }
    val lyricsPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                val loaded = withContext(Dispatchers.IO) { SonusLyricsImporter.read(context, uri) }
                loaded.onSuccess { doc ->
                    editLyrics = doc.text
                    editLyricsFormat = doc.format
                    overrideStatus = "✓ Letra importada (${doc.format})"
                }.onFailure { overrideStatus = "Falha ao importar letra: ${it.message}" }
            }
        }
    }


    fun refreshLocal() {
        genres = repo.cachedGenres()
        tracks = repo.cachedTrackCount()
        lastRefresh = repo.lastRefreshMillis()
    }

    // code133: toda etapa de rede do painel tem limite de tempo. Antes, uma etapa lenta/travada deixava `busy`
    // verdadeiro para sempre e todos os botões (inclusive os das pastas) ficavam bloqueados.
    suspend fun <T> guarded(ms: Long = 20_000L, block: suspend () -> T): Result<T> {
        val job = scope.async(Dispatchers.IO) { runCatching { block() } }
        return withTimeoutOrNull(ms) { job.await() }
            ?: run { job.cancel(); Result.failure(IllegalStateException("tempo esgotado (${ms / 1000}s)")) }
    }

    fun sync(showStatus:Boolean=true) {
        scope.launch {
            if (busy) { if (showStatus) status = "Já existe uma atualização em andamento…"; return@launch }
            if(showStatus) status="Atualizando catálogo…"
            busy=true
            try {
                val metadataOverrides = guarded { repo.refreshTrackOverrides() }
                guarded { repo.refreshRemovedFileIds() }
                val catalog = guarded { repo.refreshCatalog() }
                val pub = guarded(15_000L) { repo.refreshPublishedGenres() }
                val overrides = guarded(15_000L) { repo.loadAllDirectOverrides() }
                catalog.onSuccess{
                    refreshLocal()
                    val candidates = repo.cachedGenres().flatMap { g -> repo.cachedTracks(g.path) }.distinctBy { it.fileId }.map { t ->
                        StreamCatalogCandidate(t.fileId,t.displayTitle,t.artist,t.genre)
                    }
                    val linked = guarded { streamRepo.syncApprovedCatalogLinks(candidates,authUser).getOrDefault(0) }.getOrDefault(0)
                    if(showStatus && linked>0) status="✓ Catálogo atualizado • $linked vínculo(s) de artista reconhecido(s)"
                }.onFailure{if(showStatus)status="Falha: ${it.message ?: "catálogo indisponível"}"}
                // Não sobrescreve a escolha do OWNER enquanto uma gravação de pasta ainda está em andamento.
                pub.onSuccess { remotePublished ->
                    if (savingGenres.isEmpty()) {
                        val availableSources = repo.cachedGenres().map { it.name }.toSet()
                        val shouldEnableThird = "MÚSICAS 3" in availableSources &&
                            "MÚSICAS" in remotePublished && "MÚSICAS 2" in remotePublished &&
                            "MÚSICAS 3" !in remotePublished
                        if (shouldEnableThird) {
                            val migrated = remotePublished + "MÚSICAS 3"
                            val saved = guarded(15_000L) { repo.setPublishedGenres(migrated).getOrThrow() }
                            published = if (saved.isSuccess) migrated else remotePublished
                            if (saved.isFailure && showStatus) {
                                status = "Uma biblioteca complementar foi encontrada; ative sua publicação para exibir as faixas no Stream."
                            }
                        } else {
                            published = remotePublished
                        }
                    }
                }
                overrides.onSuccess{directOverrides=it}
                if (catalog.isSuccess && showStatus && status?.contains("vínculo(s)") != true && status?.contains("biblioteca complementar foi encontrada") != true) {
                    status = "✓ Catálogo atualizado • ${repo.cachedGenres().size} pasta(s) de músicas • ${repo.cachedTrackCount()} música(s)"
                }
            } finally {
                busy=false
            }
        }
    }

    LaunchedEffect(Unit) {
        sync(false)
        while(true){ delay(300_000L); sync(false) }
    }

    LaunchedEffect(selectedTrack?.fileId) {
        val track = selectedTrack ?: return@LaunchedEffect
        overrideBusy = true
        overrideStatus = null
        withContext(Dispatchers.IO) { runCatching { repo.refreshTrackOverrides() } }
        overrideUrl = withContext(Dispatchers.IO) { repo.loadDirectOverride(track.fileId).orEmpty() }
        val fields = repo.trackOverride(track.fileId)
        editTitle = fields["title"].orEmpty().ifBlank { track.displayTitle }
        editArtist = fields["artist"].orEmpty().ifBlank { track.artist }
        editAlbum = fields["album"].orEmpty().ifBlank { track.album }
        editGenre = fields["genre"].orEmpty().ifBlank { track.genre }
        editYear = fields["year"].orEmpty()
        editTrackNumber = fields["trackNumber"].orEmpty()
        editLyrics = fields["lyrics"].orEmpty()
        editLyricsFormat = fields["lyricsFormat"].orEmpty().ifBlank { "TEXT" }
        if (!pendingLrc.isNullOrBlank()) {
            editLyrics = pendingLrc.take(120_000)
            editLyricsFormat = "LRC"
            overrideStatus = "✓ LRC do Editor carregado. Revise e salve esta faixa."
            onPendingLrcConsumed()
        }
        editCoverBase64 = fields["coverBase64"].orEmpty()
        overrideBusy = false
    }

    selectedTrack?.let { track ->
        var ownerGenreExpanded by remember(track.fileId) { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { if(!overrideBusy) selectedTrack = null },
            confirmButton = { TextButton(onClick={selectedTrack=null},enabled=!overrideBusy){Text("Fechar")} },
            title = { Text(track.displayTitle, fontWeight=FontWeight.Black) },
            text = {
                Column(
                    Modifier.fillMaxWidth().heightIn(max=590.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement=Arrangement.spacedBy(9.dp)
                ) {
                    Text("Administração privada da faixa",fontWeight=FontWeight.Bold,color=Color(0xFF63E2C2))
                    Text("ID interno: ${track.fileId}",fontSize=9.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.55f))
                    Text("Origem: ${track.path}",fontSize=9.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.55f))

                    OutlinedTextField(value=overrideUrl,onValueChange={overrideUrl=it;overrideStatus=null},label={Text("Link direto de reprodução")},placeholder={Text("https://…")},minLines=2,modifier=Modifier.fillMaxWidth())
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                        Button(onClick={scope.launch{overrideBusy=true;val r=withContext(Dispatchers.IO){repo.saveDirectOverride(track.fileId,overrideUrl)};overrideStatus=if(r.isSuccess){directOverrides=directOverrides+(track.fileId to overrideUrl.trim());"✓ Link direto salvo"}else"Falha ao salvar link: ${r.exceptionOrNull()?.message}";overrideBusy=false}},enabled=!overrideBusy&&overrideUrl.trim().startsWith("https://",true),modifier=Modifier.weight(1f)){Text("Salvar link")}
                        OutlinedButton(onClick={scope.launch{overrideBusy=true;val r=withContext(Dispatchers.IO){repo.testDirectUrl(overrideUrl)};overrideStatus=r.fold({"✓ $it"},{"Falha: ${it.message ?: "stream inválido"}"});overrideBusy=false}},enabled=!overrideBusy&&overrideUrl.trim().startsWith("https://",true),modifier=Modifier.weight(1f)){Text("Testar")}
                    }
                    OutlinedButton(onClick={scope.launch{overrideBusy=true;val r=withContext(Dispatchers.IO){repo.removeDirectOverride(track.fileId)};if(r.isSuccess){overrideUrl="";directOverrides=directOverrides-track.fileId;overrideStatus="✓ Resolução automática restaurada"}else overrideStatus="Falha ao remover link: ${r.exceptionOrNull()?.message}";overrideBusy=false}},enabled=!overrideBusy&&(overrideUrl.isNotBlank()||track.fileId in directOverrides),modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Restore,null);Spacer(Modifier.width(4.dp));Text("Usar stream automático")}

                    HorizontalDivider()
                    Text("Tags e detalhes",fontWeight=FontWeight.Black)
                    OutlinedTextField(editTitle,{editTitle=it.take(120)},label={Text("Título")},singleLine=true,modifier=Modifier.fillMaxWidth())
                    OutlinedTextField(editArtist,{editArtist=it.take(120)},label={Text("Artista")},singleLine=true,modifier=Modifier.fillMaxWidth())
                    OutlinedTextField(editAlbum,{editAlbum=it.take(120)},label={Text("Álbum")},singleLine=true,modifier=Modifier.fillMaxWidth())
                    Box(Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick={ownerGenreExpanded=true},modifier=Modifier.fillMaxWidth()) {
                            Column(Modifier.weight(1f),horizontalAlignment=Alignment.Start){Text("Gênero",style=MaterialTheme.typography.labelSmall);Text(SonusMediaPreferences.initialGenre(context,editGenre),maxLines=1,overflow=TextOverflow.Ellipsis)}
                            Icon(Icons.Default.ArrowDropDown,null)
                        }
                        DropdownMenu(expanded=ownerGenreExpanded,onDismissRequest={ownerGenreExpanded=false}) {
                            SonusMediaStandards.genres.forEach { genre -> DropdownMenuItem(text={Text(genre)},onClick={ownerGenreExpanded=false;editGenre=genre;SonusMediaPreferences.saveLastGenre(context,genre)}) }
                        }
                    }
                    Row(horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                        OutlinedTextField(editYear,{editYear=it.filter(Char::isDigit).take(4)},label={Text("Ano")},singleLine=true,modifier=Modifier.weight(1f))
                        OutlinedTextField(editTrackNumber,{editTrackNumber=it.filter{c->c.isDigit()||c=='/'}.take(12)},label={Text("Faixa")},singleLine=true,modifier=Modifier.weight(1f))
                    }

                    Text("Capa",fontWeight=FontWeight.Bold)
                    if(editCoverBase64.isNotBlank()) {
                        val bytes=remember(editCoverBase64){runCatching{Base64.decode(editCoverBase64,Base64.DEFAULT)}.getOrNull()}
                        val preview=remember(bytes){bytes?.let{runCatching{BitmapFactory.decodeByteArray(it,0,it.size)?.asImageBitmap()}.getOrNull()}}
                        Box(Modifier.size(108.dp).clip(RoundedCornerShape(15.dp)).background(Color.White.copy(alpha=.06f)),contentAlignment=Alignment.Center){if(preview!=null)Image(preview,null,Modifier.fillMaxSize(),contentScale=ContentScale.Crop)else Icon(Icons.Default.Image,null)}
                    }
                    Row(horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                        OutlinedButton(onClick={coverPicker.launch("image/*")},modifier=Modifier.weight(1f)){Icon(Icons.Default.Image,null);Spacer(Modifier.width(4.dp));Text(if(editCoverBase64.isBlank())"Adicionar capa" else "Trocar capa")}
                        if(editCoverBase64.isNotBlank()) OutlinedButton(onClick={editCoverBase64=""},modifier=Modifier.weight(1f)){Text("Remover")}
                    }

                    Text("Letra",fontWeight=FontWeight.Bold)
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                        FilterChip(selected=editLyricsFormat=="TEXT",onClick={editLyricsFormat="TEXT"},label={Text("TXT")})
                        FilterChip(selected=editLyricsFormat=="LRC",onClick={editLyricsFormat="LRC"},label={Text("LRC")})
                        OutlinedButton(onClick={lyricsPicker.launch(SonusLyricsImporter.pickerMimeTypes())}){Icon(Icons.Default.UploadFile,null);Spacer(Modifier.width(3.dp));Text("Importar")}
                    }
                    OutlinedTextField(editLyrics,{editLyrics=it.take(120_000)},label={Text(if(editLyricsFormat=="LRC")"Letra sincronizada LRC" else "Letra / texto")},minLines=6,maxLines=12,modifier=Modifier.fillMaxWidth())
                    Text(if(editLyricsFormat=="LRC")"LRC será sincronizado pelo tempo do SONUS PLAYER." else "Texto simples aparece com rolagem manual.",fontSize=9.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.55f))

                    Button(
                        onClick={scope.launch{
                            overrideBusy=true
                            val fields=linkedMapOf(
                                "title" to editTitle,
                                "artist" to editArtist,
                                "album" to editAlbum,
                                "genre" to editGenre,
                                "year" to editYear,
                                "trackNumber" to editTrackNumber,
                                "lyrics" to editLyrics,
                                "lyricsFormat" to editLyricsFormat,
                                "coverBase64" to editCoverBase64
                            )
                            val r=withContext(Dispatchers.IO){repo.saveTrackAdminOverride(track.fileId,fields)}
                            overrideStatus=if(r.isSuccess){refreshLocal();"✓ Tags, capa e letra salvas no catálogo"}else"Falha ao salvar detalhes: ${r.exceptionOrNull()?.message ?: "erro"}"
                            overrideBusy=false
                        }},
                        enabled=!overrideBusy,
                        modifier=Modifier.fillMaxWidth()
                    ){Icon(Icons.Default.Save,null);Spacer(Modifier.width(5.dp));Text("Salvar detalhes da faixa")}
                    OutlinedButton(onClick={scope.launch{overrideBusy=true;val r=withContext(Dispatchers.IO){repo.removeTrackAdminOverride(track.fileId)};if(r.isSuccess){editTitle=track.displayTitle;editArtist=track.artist;editAlbum=track.album;editGenre=track.genre;editYear="";editTrackNumber="";editLyrics="";editLyricsFormat="TEXT";editCoverBase64="";overrideStatus="✓ Metadados originais restaurados"}else overrideStatus="Falha ao restaurar: ${r.exceptionOrNull()?.message}";overrideBusy=false}},enabled=!overrideBusy,modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Restore,null);Spacer(Modifier.width(4.dp));Text("Restaurar metadados originais")}

                    Text("Links e controles administrativos ficam somente no OWNER. Usuários recebem apenas título, capa, letra e demais dados finais.",fontSize=9.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.56f))
                    if(overrideBusy) LinearProgressIndicator(Modifier.fillMaxWidth())
                    overrideStatus?.let{Text(it,fontSize=10.sp,color=if(it.startsWith("✓"))Color(0xFF78E6A8) else Color(0xFFFF9A9A))}
                }
            }
        )
    }


    Column(verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Surface(shape=RoundedCornerShape(18.dp), color=Color(0xFF14283A), border=BorderStroke(1.dp, Color(0xFF63E2C2).copy(alpha=.30f))) {
            Row(Modifier.fillMaxWidth().clickable { showBulkMetadataEditor = true }.padding(14.dp), verticalAlignment=Alignment.CenterVertically) {
                Icon(Icons.Default.LibraryMusic, null, tint=Color(0xFF63E2C2), modifier=Modifier.size(27.dp))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("Edição de música em lote", color=Color.White, fontWeight=FontWeight.Black)
                    Text("Atualize gênero, artista, álbum e ano em várias faixas de uma vez.", color=Color.White.copy(alpha=.68f), style=MaterialTheme.typography.labelSmall)
                }
                Icon(Icons.Default.ChevronRight, null, tint=Color.White.copy(alpha=.8f))
            }
        }
        if (showBulkMetadataEditor) SonusBulkMetadataEditor(repo = repo, genres = genres, onClose = { showBulkMetadataEditor = false }, onSaved = { refreshLocal(); status = it })
        Surface(shape=RoundedCornerShape(22.dp),color=Color(0xFF102F2B).copy(alpha=.92f),border=BorderStroke(1.dp,Color(0xFF63E2C2).copy(alpha=.32f))) {
            Column(Modifier.padding(15.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Surface(shape=RoundedCornerShape(14.dp),color=Color(0xFF63E2C2).copy(alpha=.14f)){Icon(Icons.Default.Public,null,tint=Color(0xFF63E2C2),modifier=Modifier.padding(10.dp))}
                    Spacer(Modifier.width(9.dp))
                    Column(Modifier.weight(1f)){Text("SONUS Stream",color=Color.White,fontWeight=FontWeight.Black,fontSize=19.sp);Text("Catálogo pCloud • controle OWNER",color=Color.White.copy(alpha=.58f),style=MaterialTheme.typography.labelSmall)}
                    AssistChip(onClick={},label={Text("pCloud público")})
                }
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                    DevMetric(Modifier.weight(1f),genres.size.toString(),"fontes")
                    DevMetric(Modifier.weight(1f),tracks.toString(),"músicas")
                    DevMetric(Modifier.weight(1f),directOverrides.size.toString(),"links")
                }
                Text(if(lastRefresh>0)"Última atualização: ${java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.SHORT,java.text.DateFormat.SHORT).format(java.util.Date(lastRefresh))}" else "Catálogo ainda não sincronizado.",color=Color.White.copy(alpha=.58f),style=MaterialTheme.typography.labelSmall)
                Row(horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                    Button(onClick={sync(true)},enabled=!busy,modifier=Modifier.weight(1f)){Icon(Icons.Default.Refresh,null);Spacer(Modifier.width(4.dp));Text("Atualizar")}
                    OutlinedButton(onClick={scope.launch{busy=true;try{val r=guarded(25_000L){repo.testStreamingReady().getOrThrow()};status=r.fold({"✓ Streaming disponível • $it"},{"Falha no streaming: ${it.message}"})}finally{busy=false}}},enabled=!busy,modifier=Modifier.weight(1f)){Text("Testar stream")}
                }
                OutlinedButton(onClick={repo.clearCache();refreshLocal();status="Cache local limpo."},enabled=!busy,modifier=Modifier.fillMaxWidth()){Text("Limpar capas em cache")}
                OutlinedButton(
                    onClick = {
                        if (!checkingSources) scope.launch {
                            checkingSources = true
                            sourceDiagnostics = emptyList()
                            val configured = listOf(
                                "Pasta 1 • Música" to BuildConfig.SONUS_PCLOUD_PUBLIC_CODE,
                                "Pasta 2 • Música" to BuildConfig.SONUS_PCLOUD_SECONDARY_PUBLIC_CODE,
                                "Pasta 3 • Música" to BuildConfig.SONUS_PCLOUD_TERTIARY_PUBLIC_CODE
                            )
                            sourceDiagnostics = withContext(Dispatchers.IO) {
                                configured.mapIndexed { index, (label, code) ->
                                    if (code.isBlank()) "$label: NÃO CONFIGURADA"
                                    else runCatching {
                                        val count = SonusPCloudClient.listPublicNodes(code).count { node ->
                                            node.name.endsWith(".mp3", true) || node.contentType.startsWith("audio/", true)
                                        }
                                        "$label: ${if (count > 0) "OK" else "ACESSÍVEL, SEM ÁUDIOS"} • $count arquivo(s)"
                                    }.getOrElse { "$label: FALHA • ${it.message ?: "erro de leitura"}" }
                                }
                            }
                            checkingSources = false
                        }
                    },
                    enabled = !checkingSources && !busy,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (checkingSources) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                    else Icon(Icons.Default.FolderOpen, null)
                    Spacer(Modifier.width(7.dp))
                    Text(if (checkingSources) "Verificando três pastas…" else "Verificar as 3 pastas de músicas")
                }
                sourceDiagnostics.forEach { line ->
                    Text(line, color = if (line.contains(": OK")) Color(0xFF78E6A8) else Color(0xFFFFC078), style = MaterialTheme.typography.labelSmall)
                }
                status?.let{Text(it,color=if(it.startsWith("✓"))Color(0xFF78E6A8) else Color.White.copy(alpha=.78f),style=MaterialTheme.typography.bodySmall)}
            }
        }

        if (!pendingLrc.isNullOrBlank()) {
            Surface(shape=RoundedCornerShape(14.dp),color=Color(0xFF397B61).copy(alpha=.18f),border=BorderStroke(1.dp,Color(0xFF63E2C2).copy(alpha=.35f))) {
                Text("LRC pronto para adicionar • selecione uma música abaixo",modifier=Modifier.padding(11.dp),fontWeight=FontWeight.Bold,color=Color(0xFF78E6A8))
            }
        }
        Text("Publicação das bibliotecas do Stream",fontWeight=FontWeight.Black,fontSize=17.sp)
        Text("Gerencie a visibilidade das bibliotecas e os links de cada faixa. Os nomes técnicos das fontes ficam ocultos.",color=MaterialTheme.colorScheme.onSurface.copy(alpha=.58f),style=MaterialTheme.typography.bodySmall)
        OutlinedTextField(search,{search=it.take(80)},label={Text("Buscar música ou artista")},leadingIcon={Icon(Icons.Default.Search,null)},singleLine=true,modifier=Modifier.fillMaxWidth())
        LazyRow(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            items(listOf("Todas","Sem link","Com link","Publicadas","Ocultas")) { name ->
                FilterChip(selected=filter==name,onClick={filter=name},label={Text(name)})
            }
        }
        genres.forEach { genre ->
            val allTracks=repo.cachedTracks(genre.path)
            val enabled=genre.name in published
            val visibleTracks=allTracks.filter { track ->
                val q=search.trim().lowercase(Locale.getDefault())
                val matchesQ=q.isBlank() || track.displayTitle.lowercase(Locale.getDefault()).contains(q) || track.artist.lowercase(Locale.getDefault()).contains(q)
                val matchesFilter=when(filter){
                    "Sem link" -> track.fileId !in directOverrides
                    "Com link" -> track.fileId in directOverrides
                    "Publicadas" -> enabled
                    "Ocultas" -> !enabled
                    else -> true
                }
                matchesQ && matchesFilter
            }
            Surface(shape=RoundedCornerShape(17.dp),color=Color.White.copy(alpha=.045f),border=BorderStroke(1.dp,if(enabled)Color(0xFF63E2C2).copy(alpha=.30f) else Color.White.copy(alpha=.08f)),modifier=Modifier.fillMaxWidth().clickable{expandedGenre=if(expandedGenre==genre.path)null else genre.path}) {
                Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically) {
                    Icon(Icons.Default.QueueMusic,null,tint=if(enabled)Color(0xFF63E2C2) else Color.White.copy(alpha=.50f));Spacer(Modifier.width(9.dp))
                    Column(Modifier.weight(1f)){Text(streamSourceDisplayName(genre.name),fontWeight=FontWeight.Bold);Text("${allTracks.size} música(s) • ${if(enabled)"Publicado" else "Oculto"}",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.55f))}
                    Icon(if(expandedGenre==genre.path)Icons.Default.ExpandLess else Icons.Default.ExpandMore,null,tint=MaterialTheme.colorScheme.onSurface.copy(alpha=.55f))
                    Spacer(Modifier.width(5.dp))
                    Switch(checked=enabled,onCheckedChange={ next ->
                        val name=genre.name
                        // code133: a tela muda na hora; se o servidor não confirmar, volta ao estado anterior.
                        published=published.toMutableSet().apply{if(next)add(name) else remove(name)}
                        savingGenres=savingGenres+name
                        status="Salvando \"$name\"…"
                        scope.launch {
                            try {
                                val r=publishMutex.withLock { val toSave=published; guarded(15_000L){repo.setPublishedGenres(toSave).getOrThrow()} }
                                if(r.isSuccess){
                                    status="✓ $name: ${if(next)"publicado" else "oculto"}"
                                } else {
                                    published=published.toMutableSet().apply{if(next)remove(name) else add(name)}
                                    status="Não foi possível salvar \"$name\": ${r.exceptionOrNull()?.message ?: "sem resposta do servidor"}. Nada mudou; tente de novo."
                                }
                            } finally {
                                savingGenres=savingGenres-name
                            }
                        }
                    },enabled=genre.name !in savingGenres)
                }
            }
            if(expandedGenre==genre.path) {
                visibleTracks.forEach { track ->
                    val hasLink=track.fileId in directOverrides
                    Surface(shape=RoundedCornerShape(14.dp),color=Color.Black.copy(alpha=.16f),modifier=Modifier.fillMaxWidth().padding(start=14.dp).clickable{selectedTrack=track}) {
                        Row(Modifier.padding(11.dp),verticalAlignment=Alignment.CenterVertically){
                            Icon(if(hasLink)Icons.Default.Link else Icons.Default.MusicNote,null,tint=if(hasLink)Color(0xFF63E2C2) else MaterialTheme.colorScheme.onSurface.copy(alpha=.55f));Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)){Text(track.displayTitle,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis);Text(track.artist.ifBlank{"SONUS Stream"},fontSize=9.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.55f),maxLines=1,overflow=TextOverflow.Ellipsis)}
                            AssistChip(onClick={selectedTrack=track},label={Text(if(hasLink)"Link configurado" else "Abrir ficha")})
                        }
                    }
                }
                if(visibleTracks.isEmpty()) Text("Nenhuma faixa neste filtro.",fontSize=10.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.55f),modifier=Modifier.padding(start=20.dp,top=3.dp,bottom=5.dp))
            }
        }
    }
}

@Composable private fun DevMetric(modifier:Modifier,value:String,label:String){
    Surface(modifier,shape=RoundedCornerShape(14.dp),color=Color.White.copy(alpha=.065f)){Column(Modifier.padding(9.dp),horizontalAlignment=Alignment.CenterHorizontally){Text(value,color=Color.White,fontWeight=FontWeight.Black,fontSize=19.sp);Text(label,color=Color.White.copy(alpha=.54f),fontSize=8.sp)}}
}



private fun buildForYouToday(
    allVisibleTracks: List<SonusOnlineTrack>,
    mostPlayed: List<SonusOnlineTrack>,
    favoriteIds: Set<Long>,
    preferredGenre: String,
    multipliers: Map<Long, Double>,
    max: Int
): List<SonusOnlineTrack> {
    if (allVisibleTracks.isEmpty()) return emptyList()
    val rank = mostPlayed.mapIndexed { index, track -> track.fileId to (mostPlayed.size - index).coerceAtLeast(1) }.toMap()
    val seed = java.time.LocalDate.now().toEpochDay() xor (FirebaseAuth.getInstance().currentUser?.uid?.hashCode()?.toLong() ?: 0L)
    val random = Random(seed)
    val pool = allVisibleTracks.filter { (multipliers[it.fileId] ?: 1.0) > 0.0 }.toMutableList()
    val out = mutableListOf<SonusOnlineTrack>()
    while (pool.isNotEmpty() && out.size < max) {
        val weights = pool.map { track ->
            var w = 1.0
            w += (rank[track.fileId] ?: 0) * .9
            if (track.fileId in favoriteIds) w += 3.5
            if (preferredGenre.isNotBlank() && canonicalSonusGenre(track.genre).equals(preferredGenre, true)) w += 2.5
            w *= (multipliers[track.fileId] ?: 1.0).coerceIn(.1, 4.0)
            w.coerceAtLeast(.05)
        }
        val total = weights.sum().coerceAtLeast(.01)
        var pick = random.nextDouble() * total
        var chosen = 0
        for (i in weights.indices) { pick -= weights[i]; if (pick <= 0) { chosen=i; break } }
        out += pool.removeAt(chosen)
    }
    return out
}

private fun normalizeStreamSearch(value:String):String = Normalizer.normalize(value.trim().lowercase(Locale.ROOT), Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")

private suspend fun com.google.android.gms.tasks.Task<com.google.firebase.auth.GetTokenResult>.awaitSonusToken(): String =
    suspendCancellableCoroutine { cont ->
        addOnSuccessListener { result -> if (cont.isActive) cont.resume(result.token.orEmpty()) }
        addOnFailureListener { error -> if (cont.isActive) cont.resumeWithException(error) }
    }

private fun genrePalette(name: String): List<Color> {
    val n = normalizeStreamSearch(name)
    return when {
        n.contains("arrocha") -> listOf(Color(0xFF542A74), Color(0xFFB34D92))
        n == "axe" -> listOf(Color(0xFF8B4C16), Color(0xFFE59A35))
        n.contains("bossa") || n.contains("mpb") -> listOf(Color(0xFF145B63), Color(0xFF40A6A2))
        n.contains("brega") -> listOf(Color(0xFF71345D), Color(0xFFD9678E))
        n.contains("catol") || n.contains("gospel") -> listOf(Color(0xFF225D73), Color(0xFF43A6BE))
        n.contains("eletron") -> listOf(Color(0xFF293A87), Color(0xFF6767E8))
        n.contains("forro") || n.contains("piseiro") -> listOf(Color(0xFF8D2738), Color(0xFFE44E55))
        n == "funk" -> listOf(Color(0xFF4A267D), Color(0xFF9E5BE0))
        n.contains("internacional") -> listOf(Color(0xFF1E4E70), Color(0xFF458ED0))
        n.contains("pagode") || n.contains("samba") -> listOf(Color(0xFF17634F), Color(0xFF48B58A))
        n == "pop" -> listOf(Color(0xFF8C316C), Color(0xFFE76FA9))
        n.contains("rap") || n.contains("hip hop") || n.contains("trap") -> listOf(Color(0xFF49236D), Color(0xFF9057D8))
        n.contains("reggae") -> listOf(Color(0xFF35632B), Color(0xFF91B34B))
        n.contains("rock") -> listOf(Color(0xFF333B51), Color(0xFF8C5068))
        n.contains("romant") -> listOf(Color(0xFF7B2859), Color(0xFFD8528E))
        n.contains("sertanejo") -> listOf(Color(0xFF765020), Color(0xFFC98C3C))
        n.contains("sofrencia") -> listOf(Color(0xFF6D283A), Color(0xFFBC5264))
        n.contains("triste") -> listOf(Color(0xFF344B73), Color(0xFF6B8DBA))
        else -> listOf(Color(0xFF174A72), Color(0xFF2D91C7))
    }
}

private fun streamSourceDisplayName(raw:String):String = when (normalizeStreamSearch(raw)) {
    "musicas", "musica" -> "Biblioteca principal"
    "musicas 2", "musica 2" -> "Biblioteca complementar 1"
    "musicas 3", "musica 3" -> "Biblioteca complementar 2"
    else -> "Biblioteca adicional"
}

private suspend fun com.google.android.gms.tasks.Task<com.google.firebase.database.DataSnapshot>.awaitOnlineSnapshot(): com.google.firebase.database.DataSnapshot =
    suspendCancellableCoroutine { cont ->
        addOnSuccessListener { if (cont.isActive) cont.resume(it) }
        addOnFailureListener { if (cont.isActive) cont.resumeWithException(it) }
    }

private suspend fun com.google.android.gms.tasks.Task<Void>.awaitOnlineVoid(): Unit =
    suspendCancellableCoroutine { cont ->
        addOnSuccessListener { if (cont.isActive) cont.resume(Unit) }
        addOnFailureListener { if (cont.isActive) cont.resumeWithException(it) }
    }
