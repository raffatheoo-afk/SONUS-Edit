package com.sonusstudios.streampulse.core

import java.math.BigInteger
import java.security.MessageDigest

/**
 * Identificador público estável de uma submissão/música SONUS.
 * Não é segredo nem credencial; existe apenas para suporte e localização precisa.
 *
 * 14 dígitos reduzem bastante a chance de colisão sem expor o ID interno do Firebase.
 */
fun sonusMusicPublicId(submissionId: String): String {
    val clean = submissionId.trim()
    if (clean.isBlank()) return "sonusmusic00000000000000"
    val digest = MessageDigest.getInstance("SHA-256")
        .digest(("SONUS-MUSIC:" + clean).toByteArray(Charsets.UTF_8))
    val number = BigInteger(1, digest)
        .mod(BigInteger("100000000000000"))
        .toString()
        .padStart(14, '0')
    return "sonusmusic$number"
}
