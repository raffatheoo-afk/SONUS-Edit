package com.sonusstudios.streampulse.tools

import com.sonusstudios.streampulse.core.SonusAutoCreateDocument
import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.*
import android.net.Uri
import android.os.*
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import com.sonusstudios.streampulse.core.MembershipTier
import com.sonusstudios.streampulse.core.commercialTier
import com.sonusstudios.streampulse.core.UserPreferences
import com.sonusstudios.streampulse.notifications.SonusNotificationCenter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import kotlin.math.*

private val PulseOrange = Color(0xFFFF8A22)
private val PulseCyan = Color(0xFF25D8FF)
private val PulseViolet = Color(0xFF9B6CFF)
private val ProDark = Color(0xFF071019)

private fun tierAtLeast(current: MembershipTier, required: MembershipTier) = commercialTier(current).ordinal >= commercialTier(required).ordinal

@Composable
private fun ProToolScaffold(title: String, accent: Color, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(ProDark, accent.copy(alpha=.10f), Color(0xFF05090F))))) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(horizontal=8.dp, vertical=5.dp), verticalAlignment=Alignment.CenterVertically) {
                IconButton(onClick=onBack) { Icon(Icons.Default.ArrowBack, "Voltar", tint=Color.White) }
                Text(title, fontSize=22.sp, fontWeight=FontWeight.Black, color=Color.White)
            }
            Column(Modifier.fillMaxSize().padding(horizontal=16.dp), verticalArrangement=Arrangement.spacedBy(12.dp), content=content)
        }
    }
}

@Composable
private fun AccessGate(required: String, accent: Color) {
    Card(colors=CardDefaults.cardColors(containerColor=accent.copy(alpha=.14f)), border=BorderStroke(1.dp,accent.copy(alpha=.45f))) {
        Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.spacedBy(8.dp)) {
            Icon(Icons.Default.Lock, null, tint=accent, modifier=Modifier.size(38.dp))
            Text("Recurso $required", fontWeight=FontWeight.Black, color=Color.White)
            Text("Disponível neste plano e nos superiores.", color=Color.White.copy(alpha=.68f), textAlign=TextAlign.Center)
        }
    }
}

// ----------------------------- SONUS TUNE ---------------------------------
private data class TunerReading(
    val frequency: Float? = null,
    val note: String = "—",
    val octave: Int? = null,
    val cents: Float = 0f,
    val confidence: Float = 0f,
    val signal: Float = 0f
)

private fun noteFromFrequency(freq: Float, a4: Float = 440f): TunerReading {
    if (freq <= 0f || !freq.isFinite()) return TunerReading()
    val midiFloat = 69.0 + 12.0 * (ln(freq / a4) / ln(2.0))
    val midi = midiFloat.roundToInt()
    val names = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
    val note = names[(midi % 12 + 12) % 12]
    val octave = midi / 12 - 1
    val target = a4 * 2.0.pow((midi - 69) / 12.0)
    val cents = (1200.0 * (ln(freq / target) / ln(2.0))).toFloat().coerceIn(-50f, 50f)
    return TunerReading(freq, note, octave, cents)
}

private fun yinPitch(samples: ShortArray, sampleRate: Int = 44100, minHz: Int = 45, maxHz: Int = 1200): Pair<Float?, Float> {
    val n = samples.size
    val minLag = (sampleRate / maxHz).coerceAtLeast(2)
    val maxLag = (sampleRate / minHz).coerceAtMost(n / 2)
    if (maxLag <= minLag) return null to 0f
    val diff = DoubleArray(maxLag + 1)
    val end = n - maxLag
    for (tau in minLag..maxLag) {
        var sum = 0.0
        var i = 0
        while (i < end) {
            val d = samples[i].toDouble() - samples[i + tau]
            sum += d * d
            i += 2
        }
        diff[tau] = sum
    }
    var running = 0.0
    val cmnd = DoubleArray(maxLag + 1) { 1.0 }
    for (tau in minLag..maxLag) {
        running += diff[tau]
        cmnd[tau] = if (running == 0.0) 1.0 else diff[tau] * tau / running.coerceAtLeast(1e-9)
    }
    var best = -1
    var tau = minLag
    while (tau <= maxLag) {
        if (cmnd[tau] < 0.15) {
            while (tau + 1 <= maxLag && cmnd[tau + 1] < cmnd[tau]) tau++
            best = tau
            break
        }
        tau++
    }
    if (best < 0) best = (minLag..maxLag).minByOrNull { cmnd[it] } ?: return null to 0f
    val conf = (1.0 - cmnd[best]).coerceIn(0.0, 1.0).toFloat()
    if (conf < .70f) return null to conf
    val x0 = (best - 1).coerceAtLeast(minLag)
    val x2 = (best + 1).coerceAtMost(maxLag)
    val s0 = cmnd[x0]; val s1 = cmnd[best]; val s2 = cmnd[x2]
    val denom = (2.0 * s1 - s2 - s0)
    val refined = if (abs(denom) < 1e-9) best.toDouble() else best + (s2 - s0) / (2.0 * denom)
    return (sampleRate / refined).toFloat() to conf
}

/**
 * Code122: separa detecção de apresentação. O YIN continua respondendo rápido, mas o
 * ponteiro recebe uma leitura com mediana + EMA + histerese de nota + hold de sinal.
 */
private class TunerStabilizer {
    private val centsWindow = ArrayDeque<Float>()
    private var stableKey: String? = null
    private var candidateKey: String? = null
    private var candidateCount = 0
    private var smoothedCents = 0f
    private var smoothedFrequency: Float? = null
    private var lastValidAt = 0L
    private var lastReading = TunerReading()

    fun push(frequency: Float?, confidence: Float, signal: Float, now: Long): TunerReading {
        if (frequency == null || confidence < .70f || signal < .025f) {
            return if (now - lastValidAt <= 420L && lastReading.frequency != null) {
                lastReading.copy(confidence = confidence, signal = signal)
            } else {
                val returning = smoothedCents * .72f
                smoothedCents = if (abs(returning) < .35f) 0f else returning
                lastReading = TunerReading(cents = smoothedCents, confidence = confidence, signal = signal)
                lastReading
            }
        }

        val raw = noteFromFrequency(frequency, 440f)
        val key = "${raw.note}${raw.octave}"
        if (stableKey == null) {
            stableKey = key
        } else if (key != stableKey) {
            if (candidateKey == key) candidateCount++ else { candidateKey = key; candidateCount = 1 }
            // Mudança real precisa aparecer em leituras consecutivas. Isso também segura saltos de oitava/harmônicos.
            if (candidateCount < 3) {
                lastValidAt = now
                return lastReading.copy(confidence = confidence, signal = signal)
            }
            stableKey = key
            candidateKey = null
            candidateCount = 0
            centsWindow.clear()
            smoothedCents = raw.cents
            smoothedFrequency = frequency
        } else {
            candidateKey = null
            candidateCount = 0
        }

        centsWindow.addLast(raw.cents)
        while (centsWindow.size > 5) centsWindow.removeFirst()
        val median = centsWindow.sorted()[centsWindow.size / 2]
        val alpha = if (abs(median - smoothedCents) > 16f) .34f else .22f
        smoothedCents += (median - smoothedCents) * alpha
        smoothedFrequency = smoothedFrequency?.let { it + (frequency - it) * .25f } ?: frequency
        lastValidAt = now
        lastReading = raw.copy(
            frequency = smoothedFrequency,
            cents = smoothedCents.coerceIn(-50f, 50f),
            confidence = confidence,
            signal = signal
        )
        return lastReading
    }

    fun reset() {
        centsWindow.clear(); stableKey = null; candidateKey = null; candidateCount = 0
        smoothedCents = 0f; smoothedFrequency = null; lastValidAt = 0L; lastReading = TunerReading()
    }
}

@Composable
internal fun PulseTuneScreen(
    onBack: () -> Unit,
    prefs: UserPreferences,
    membershipTier: MembershipTier,
    unlimited: Boolean,
    premiumUsesRemaining: Int,
    onTrack: (String, Boolean?, Long?) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var reading by remember { mutableStateOf(TunerReading()) }
    var listening by remember { mutableStateOf(false) }
    var tunedLatched by remember { mutableStateOf(false) }
    var recorder by remember { mutableStateOf<AudioRecord?>(null) }
    var job by remember { mutableStateOf<Job?>(null) }
    val stabilizer = remember { TunerStabilizer() }
    var permissionKick by remember { mutableIntStateOf(0) }

    fun stop() {
        job?.cancel(); job = null
        runCatching { recorder?.stop() }; runCatching { recorder?.release() }
        recorder = null; listening = false
    }

    fun beginListening() {
        stop()
        stabilizer.reset()
        listening = true
        job = scope.launch(Dispatchers.Default) {
            val sr = 44100
            val minBuffer = AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val candidates = buildList {
                if (Build.VERSION.SDK_INT >= 24) add(MediaRecorder.AudioSource.UNPROCESSED)
                add(MediaRecorder.AudioSource.VOICE_RECOGNITION)
                add(MediaRecorder.AudioSource.MIC)
            }
            var local: AudioRecord? = null
            for (source in candidates) {
                val attempt = runCatching {
                    AudioRecord(source, sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(minBuffer * 2, 16384))
                }.getOrNull()
                if (attempt?.state == AudioRecord.STATE_INITIALIZED) { local = attempt; break }
                runCatching { attempt?.release() }
            }
            val activeRecorder = local ?: run {
                withContext(Dispatchers.Main.immediate) { listening = false }
                return@launch
            }
            recorder = activeRecorder
            val analysis = ShortArray(8192)
            val hop = ShortArray(2048)
            var filled = 0
            try {
                activeRecorder.startRecording()
                while (isActive) {
                    val got = activeRecorder.read(hop, 0, hop.size)
                    if (got <= 0) continue
                    if (got < hop.size) java.util.Arrays.fill(hop, got, hop.size, 0.toShort())
                    System.arraycopy(analysis, hop.size, analysis, 0, analysis.size - hop.size)
                    System.arraycopy(hop, 0, analysis, analysis.size - hop.size, hop.size)
                    filled = (filled + got).coerceAtMost(analysis.size)
                    if (filled < analysis.size / 2) continue

                    var sum = 0.0
                    for (sample in analysis) { val v = sample / 32768.0; sum += v * v }
                    val rms = sqrt(sum / analysis.size)
                    val signal = (rms * 7.5).toFloat().coerceIn(0f, 1f)
                    val (pitch, conf) = if (rms > .0038) yinPitch(analysis, sr) else null to 0f
                    val stable = stabilizer.push(pitch, conf, signal, SystemClock.elapsedRealtime())
                    withContext(Dispatchers.Main.immediate) { reading = stable }
                }
            } finally {
                runCatching { activeRecorder.stop() }; runCatching { activeRecorder.release() }
                if (recorder === activeRecorder) recorder = null
            }
        }
    }

    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) permissionKick++ else listening = false
    }
    fun start() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) beginListening()
        else permission.launch(Manifest.permission.RECORD_AUDIO)
    }

    LaunchedEffect(permissionKick) { if (permissionKick > 0) beginListening() }
    // Se a permissão já existe, abrir o SONUS Tune já ouvindo. Primeiro uso apenas solicita a permissão.
    LaunchedEffect(Unit) {
        delay(180)
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) beginListening()
        else permission.launch(Manifest.permission.RECORD_AUDIO)
    }
    DisposableEffect(Unit) { onDispose { stop() } }

    LaunchedEffect(reading.frequency, reading.cents) {
        val tuned = reading.frequency != null && abs(reading.cents) <= 3f && reading.confidence >= .72f
        if (tuned && !tunedLatched) {
            delay(220)
            if (reading.frequency != null && abs(reading.cents) <= 3f) {
                PulseHaptics.perform(context, prefs, PulseHapticEvent.TUNED, forTuner = true)
                tunedLatched = true
            }
        }
        if (tunedLatched && (reading.frequency == null || abs(reading.cents) > 6f)) tunedLatched = false
    }

    val tuned = reading.frequency != null && (tunedLatched || abs(reading.cents) <= 3f)
    val action = when {
        reading.frequency == null -> "AGUARDANDO SINAL"
        tuned -> "AFINADA"
        reading.cents < 0 -> "UM POUCO BAIXA"
        else -> "UM POUCO ALTA"
    }
    val accent = when {
        tuned -> Color(0xFF58E39A)
        reading.frequency == null -> Color(0xFF70819E)
        else -> PulseOrange
    }

    ProToolScaffold("SONUS TUNE", PulseOrange, onBack) {
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF080E17)),
            border = BorderStroke(1.dp, accent.copy(alpha = .42f)),
            shape = RoundedCornerShape(32.dp),
            modifier = Modifier.fillMaxWidth().weight(1f, false)
        ) {
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 18.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                Surface(shape = RoundedCornerShape(30.dp), color = accent.copy(alpha = .12f)) {
                    Text(action, Modifier.padding(horizontal = 14.dp, vertical = 6.dp), color = accent, fontWeight = FontWeight.Black, fontSize = 12.sp)
                }
                TunerGauge(reading, tuned)
                Text(
                    "${reading.note}${reading.octave ?: ""}",
                    fontSize = 60.sp,
                    fontWeight = FontWeight.Black,
                    color = if (tuned) Color(0xFF63E7A2) else Color.White
                )
                Text(
                    reading.frequency?.let { String.format(Locale.US, "%.1f Hz", it) } ?: "Toque uma nota",
                    color = Color.White.copy(alpha = .62f), fontSize = 15.sp
                )
                if (reading.frequency != null) {
                    Text(String.format(Locale.US, "%+.1f cents", reading.cents), color = accent.copy(alpha = .88f), fontWeight = FontWeight.SemiBold)
                }
                Spacer(Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { reading.signal },
                    modifier = Modifier.fillMaxWidth(.68f).height(4.dp).clip(CircleShape),
                    color = accent,
                    trackColor = Color.White.copy(alpha = .06f)
                )
                Text("Detecção automática • cromática", color = Color.White.copy(alpha=.35f), fontSize = 11.sp)
            }
        }
        Button(
            onClick = { if (listening) stop() else start() },
            colors = ButtonDefaults.buttonColors(containerColor = if (listening) Color(0xFF1C2940) else PulseOrange),
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(18.dp)
        ) {
            Icon(if (listening) Icons.Default.Pause else Icons.Default.Mic, null)
            Spacer(Modifier.width(7.dp))
            Text(if (listening) "Pausar escuta" else "Ouvir novamente", fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun TunerGauge(r: TunerReading, tuned: Boolean) {
    val target = if (r.frequency == null) 0f else (r.cents / 50f).coerceIn(-1f, 1f)
    val needle by animateFloatAsState(
        targetValue = target,
        animationSpec = spring(dampingRatio = .84f, stiffness = 155f),
        label = "tunerNeedle"
    )
    val accent = if (tuned) Color(0xFF58E39A) else PulseOrange
    Canvas(Modifier.fillMaxWidth().height(190.dp)) {
        val c = Offset(size.width / 2f, size.height * .94f)
        val radius = min(size.width * .43f, size.height * .83f)
        val bounds = androidx.compose.ui.geometry.Rect(c.x - radius, c.y - radius, c.x + radius, c.y + radius)
        // Painel de precisão: trilho neutro e zona central em destaque.
        drawArc(Color.White.copy(alpha = .10f), 198f, 144f, false, bounds.topLeft, bounds.size, style = Stroke(10.dp.toPx(), cap = StrokeCap.Round))
        drawArc(PulseOrange.copy(alpha = .45f), 252f, 27f, false, bounds.topLeft, bounds.size, style = Stroke(10.dp.toPx(), cap = StrokeCap.Round))
        drawArc(Color(0xFF58E39A), 279f, 18f, false, bounds.topLeft, bounds.size, style = Stroke(11.dp.toPx(), cap = StrokeCap.Round))
        drawArc(PulseOrange.copy(alpha = .45f), 297f, 27f, false, bounds.topLeft, bounds.size, style = Stroke(10.dp.toPx(), cap = StrokeCap.Round))
        for (i in -10..10) {
            val angle = Math.toRadians((288 + i * 7.2).toDouble())
            val outer = radius - 16.dp.toPx()
            val inner = outer - if (i % 5 == 0) 15.dp.toPx() else 8.dp.toPx()
            val p1 = Offset(c.x + cos(angle).toFloat() * outer, c.y + sin(angle).toFloat() * outer)
            val p2 = Offset(c.x + cos(angle).toFloat() * inner, c.y + sin(angle).toFloat() * inner)
            drawLine(Color.White.copy(alpha = if (i == 0) .9f else .35f), p1, p2, if (i == 0) 3f else 1.6f, StrokeCap.Round)
        }
        val angle = Math.toRadians((288 + needle * 68.0).toDouble())
        val end = Offset(c.x + cos(angle).toFloat() * (radius - 31.dp.toPx()), c.y + sin(angle).toFloat() * (radius - 31.dp.toPx()))
        drawLine(accent.copy(alpha = .20f), c, end, 11.dp.toPx(), StrokeCap.Round)
        drawLine(Color.White, c, end, 4.dp.toPx(), StrokeCap.Round)
        drawCircle(accent.copy(alpha = .20f), 18.dp.toPx(), c)
        drawCircle(accent, 9.dp.toPx(), c)
        drawCircle(Color.White, 3.dp.toPx(), c)
    }
}

// -------------------------- Pulse Transcribe ------------------------------
@Composable
internal fun PulseTranscribeScreen(onBack:()->Unit,prefs:UserPreferences,membershipTier:MembershipTier,unlimited:Boolean,premiumUsesRemaining:Int,onTrack:(String,Boolean?,Long?)->Unit){
    val context=LocalContext.current;val scope=rememberCoroutineScope()
    val tierAllowed=unlimited||tierAtLeast(membershipTier,MembershipTier.PRATA)||membershipTier==MembershipTier.FREE
    val usageAvailable=unlimited||premiumUsesRemaining>0
    val allowed=tierAllowed&&usageAvailable
    var uri by remember{mutableStateOf<Uri?>(null)};var name by remember{mutableStateOf("Nenhum áudio selecionado")};var text by remember{mutableStateOf("")};var status by remember{mutableStateOf("Pronto")};var transcriber by remember{mutableStateOf<PulseSpeechTranscriber?>(null)};var usageRecorded by remember{mutableStateOf(false)}
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){u->u?.let{uri=it;name=queryDisplayName(context,it);text="";usageRecorded=false}}
    DisposableEffect(Unit){onDispose{transcriber?.destroy()}}
    fun start(){
        val src=uri?:return
        if(!allowed)return
        status="Preparando áudio…";text="";usageRecorded=false
        scope.launch{
            val pcm=withContext(Dispatchers.IO){prepareSpeechPcm(context,src)}
            if(pcm==null){status="Não foi possível preparar o áudio";onTrack("Pulse Transcribe",false,null);return@launch}
            status="Transcrevendo…"
            val tr=PulseSpeechTranscriber(context,{partial->text=partial},{final->
                text=final
                val ok=final.isNotBlank()
                status=if(ok)"Concluído • 1 Uso Premium" else "Nenhum texto reconhecido"
                if(!usageRecorded){usageRecorded=true;onTrack("Pulse Transcribe",ok,null)}
            },{msg->status=msg;if(!usageRecorded){usageRecorded=true;onTrack("Pulse Transcribe",false,null)}})
            transcriber=tr;tr.transcribePcmFile(pcm,"pt-BR")
        }
    }
    ProToolScaffold("Pulse Transcribe",PulseCyan,onBack){
        if(!tierAllowed){AccessGate("Ouro+",PulseCyan);return@ProToolScaffold}
        if(!usageAvailable){AccessGate("Sem Moedas SONUS",PulseCyan);return@ProToolScaffold}
        Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF071A26)),border=BorderStroke(1.dp,PulseCyan.copy(alpha=.35f))){Column(Modifier.fillMaxWidth().padding(15.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){Row(verticalAlignment=Alignment.CenterVertically){Surface(Modifier.size(54.dp),shape=RoundedCornerShape(18.dp),color=PulseCyan.copy(alpha=.14f)){Box(contentAlignment=Alignment.Center){Icon(Icons.Default.RecordVoiceOver,null,tint=PulseCyan,modifier=Modifier.size(31.dp))}};Spacer(Modifier.width(10.dp));Column{Text(name,fontWeight=FontWeight.Bold,color=Color.White);Text(status,color=PulseCyan,fontSize=12.sp)}};Button({picker.launch(arrayOf("audio/*","video/*"))},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.AudioFile,null);Spacer(Modifier.width(6.dp));Text("Escolher áudio ou vídeo")};Button(::start,enabled=uri!=null&&allowed,colors=ButtonDefaults.buttonColors(containerColor=PulseCyan,contentColor=Color.Black),modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.AutoAwesome,null);Spacer(Modifier.width(6.dp));Text(if(unlimited)"Transcrever • ilimitado" else "Transcrever • 1 Uso Premium",fontWeight=FontWeight.Black)}}}
        Card(colors=CardDefaults.cardColors(containerColor=Color.Black.copy(alpha=.28f)),modifier=Modifier.fillMaxWidth().weight(1f)){LazyColumn(Modifier.fillMaxSize().padding(15.dp)){item{Text(if(text.isBlank())"O texto reconhecido aparecerá aqui em blocos conforme o mecanismo do aparelho processar o áudio." else text,color=Color.White,lineHeight=23.sp)}}}
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton({android.content.ClipData.newPlainText("Transcrição",text).also{context.getSystemService(android.content.ClipboardManager::class.java)?.setPrimaryClip(it)}},enabled=text.isNotBlank(),modifier=Modifier.weight(1f)){Icon(Icons.Default.ContentCopy,null);Text(" Copiar")};OutlinedButton({shareText(context,text)},enabled=text.isNotBlank(),modifier=Modifier.weight(1f)){Icon(Icons.Default.Share,null);Text(" Compartilhar")}}
        Text("Sem chave de API: usa o reconhecedor do aparelho. No Android 13+ usa a injeção oficial de áudio; em versões anteriores ativa o modo de compatibilidade quando o serviço instalado aceita áudio de arquivo.",fontSize=10.sp,color=Color.White.copy(alpha=.5f))
    }
}

internal class PulseSpeechTranscriber(private val context:Context,private val onPartial:(String)->Unit,private val onFinal:(String)->Unit,private val onError:(String)->Unit){
    private var recognizer:SpeechRecognizer?=null
    private var pfd:android.os.ParcelFileDescriptor?=null
    private val segments=mutableListOf<String>()
    private var compatibilityRetry=false
    private var currentFile:File?=null
    private var currentLanguage="pt-BR"

    fun transcribePcmFile(file:File,language:String){
        if(!SpeechRecognizer.isRecognitionAvailable(context)){onError("Reconhecimento de voz indisponível neste aparelho.");return}
        currentFile=file;currentLanguage=language;compatibilityRetry=false;segments.clear()
        startRecognizer(file,language,segmented = Build.VERSION.SDK_INT >= 33)
    }

    private fun startRecognizer(file:File,language:String,segmented:Boolean){
        destroyRecognizerOnly()
        recognizer=if(Build.VERSION.SDK_INT>=31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(context)) SpeechRecognizer.createOnDeviceSpeechRecognizer(context) else SpeechRecognizer.createSpeechRecognizer(context)
        recognizer?.setRecognitionListener(object:RecognitionListener{
            override fun onReadyForSpeech(params:Bundle?){}
            override fun onBeginningOfSpeech(){}
            override fun onRmsChanged(rmsdB:Float){}
            override fun onBufferReceived(buffer:ByteArray?){}
            override fun onEndOfSpeech(){}
            override fun onError(error:Int){
                closeAudio()
                // Alguns mecanismos de reconhecimento em Android 11/12 aceitam AUDIO_SOURCE,
                // mas rejeitam a sessão segmentada. Fazemos uma segunda tentativa compatível.
                if(Build.VERSION.SDK_INT<33 && !compatibilityRetry && currentFile!=null){
                    compatibilityRetry=true
                    startRecognizer(currentFile!!,currentLanguage,segmented=false)
                } else onError("Reconhecimento interrompido (código $error). O serviço de voz deste aparelho pode não aceitar áudio de arquivo.")
            }
            override fun onResults(results:Bundle?){
                val r=results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if(r.isNotBlank())segments+=r
                closeAudio();onFinal(segments.distinct().joinToString("\n"))
            }
            override fun onPartialResults(partialResults:Bundle?){
                val r=partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if(r.isNotBlank())onPartial((segments+r).joinToString("\n"))
            }
            override fun onEvent(eventType:Int,params:Bundle?){}
            override fun onSegmentResults(segmentResults:Bundle){
                val r=segmentResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if(r.isNotBlank()){segments+=r;onPartial(segments.joinToString("\n"))}
            }
            override fun onEndOfSegmentedSession(){closeAudio();onFinal(segments.distinct().joinToString("\n"))}
        })
        pfd=android.os.ParcelFileDescriptor.open(file,android.os.ParcelFileDescriptor.MODE_READ_ONLY)
        val intent=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply{
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE,language)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE,true)
            // Literais mantêm compatibilidade binária em APIs antigas; serviços atualizados podem
            // aceitar o mesmo contrato antes da API 33, enquanto Android 13+ usa a API oficial.
            putExtra("android.speech.extra.AUDIO_SOURCE",pfd)
            putExtra("android.speech.extra.AUDIO_SOURCE_CHANNEL_COUNT",1)
            putExtra("android.speech.extra.AUDIO_SOURCE_ENCODING",AudioFormat.ENCODING_PCM_16BIT)
            putExtra("android.speech.extra.AUDIO_SOURCE_SAMPLING_RATE",16000)
            if(segmented && Build.VERSION.SDK_INT>=33){
                putExtra(RecognizerIntent.EXTRA_SEGMENTED_SESSION,RecognizerIntent.EXTRA_AUDIO_SOURCE)
                putExtra(RecognizerIntent.EXTRA_ENABLE_FORMATTING,RecognizerIntent.FORMATTING_OPTIMIZE_QUALITY)
            }
        }
        recognizer?.startListening(intent)
    }
    private fun closeAudio(){runCatching{pfd?.close()};pfd=null}
    private fun destroyRecognizerOnly(){closeAudio();runCatching{recognizer?.cancel()};runCatching{recognizer?.destroy()};recognizer=null}
    fun destroy(){destroyRecognizerOnly();currentFile=null}
}

internal fun prepareSpeechPcm(context:Context,uri:Uri):File?=runCatching{val dir=File(context.cacheDir,"pulse_transcribe").apply{mkdirs()};val src=File(dir,"src_${System.nanoTime()}.bin");context.contentResolver.openInputStream(uri)?.use{i->src.outputStream().use{i.copyTo(it)}}?:error("open");val out=File(dir,"speech_${System.nanoTime()}.pcm");val cmd="-y -i '${src.absolutePath.replace("'","'\\''")}' -vn -ac 1 -ar 16000 -f s16le '${out.absolutePath.replace("'","'\\''")}'";val session=FFmpegKit.execute(cmd);src.delete();if(!ReturnCode.isSuccess(session.returnCode))error("ffmpeg");out}.getOrNull()

// --------------------------- Stem Splitter -------------------------------
@Composable internal fun PulseStemSplitterScreen(onBack:()->Unit,prefs:UserPreferences,premiumUseAvailable:Boolean=true,onTrack:(String,Boolean?,Long?)->Unit){
    val context=LocalContext.current;val scope=rememberCoroutineScope();var input by remember{mutableStateOf<Uri?>(null)};var name by remember{mutableStateOf("Selecione uma faixa")};var mode by remember{mutableStateOf("Instrumental")};var busy by remember{mutableStateOf(false)};var msg by remember{mutableStateOf("Separação local 2 stems • sem upload")}
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){u->u?.let{input=it;name=queryDisplayName(context,it)}}
    val saver=rememberLauncherForActivityResult(SonusAutoCreateDocument("audio/wav")){out->val src=input;if(out!=null&&src!=null){busy=true;SonusProcessNotifier.publish(context,"Stem Splitter",0);scope.launch{val started=System.currentTimeMillis();val ok=withContext(Dispatchers.IO){processStem(context,src,out,mode)};busy=false;if(ok)SonusProcessNotifier.publish(context,"Stem Splitter",100) else SonusProcessNotifier.fail(context,"Stem Splitter");msg=if(ok)"$mode exportado com sucesso" else "Não foi possível processar esta faixa";PulseHaptics.perform(context,prefs,if(ok)PulseHapticEvent.SUCCESS else PulseHapticEvent.WARNING);SonusNotificationCenter.add(context,if(ok)"Stem Splitter concluído" else "Falha no Stem Splitter",if(ok)"$mode foi exportado como uma nova cópia." else "O processamento não pôde ser concluído.","FERRAMENTAS",importantExternal=false);onTrack("SONUS Stem Splitter",ok,System.currentTimeMillis()-started)}}}
    ProToolScaffold("SONUS Stem Splitter",Color(0xFF37B7FF),onBack){Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF071B28))){Column(Modifier.fillMaxWidth().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){Icon(Icons.Default.CallSplit,null,tint=Color(0xFF37B7FF),modifier=Modifier.size(42.dp));Text(name,fontWeight=FontWeight.Black,color=Color.White);Text(msg,color=Color.White.copy(alpha=.62f));Button({picker.launch(arrayOf("audio/*"))},modifier=Modifier.fillMaxWidth()){Text("Escolher música")};Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){listOf("Instrumental","Vocal").forEach{m->FilterChip(mode==m,{mode=m},{Text(m)},modifier=Modifier.weight(1f))}};Button({saver.launch("SONUS_Stem_${mode}_${System.currentTimeMillis()}.wav")},enabled=input!=null&&!busy&&premiumUseAvailable,modifier=Modifier.fillMaxWidth()){if(busy)CircularProgressIndicator(Modifier.size(18.dp),strokeWidth=2.dp);Text(if(busy)"  Separando…" else "Exportar $mode")}}};Text("O motor local atual entrega voz/instrumental. Stems dedicados de bateria/baixo exigem um modelo neural embarcado e permanecem preparados para evolução sem fingir separação que o aparelho não executou.",fontSize=11.sp,color=Color.White.copy(alpha=.52f))}
}

private fun processStem(context:Context,input:Uri,out:Uri,mode:String):Boolean=runCatching{val dir=File(context.cacheDir,"stem_splitter").apply{mkdirs()};val src=File(dir,"in_${System.nanoTime()}.bin");val dst=File(dir,"out_${System.nanoTime()}.wav");context.contentResolver.openInputStream(input)?.use{i->src.outputStream().use{i.copyTo(it)}}?:error("open");val filter=if(mode=="Instrumental")"pan=stereo|c0=c0-c1|c1=c1-c0" else "pan=mono|c0=0.5*c0+0.5*c1,highpass=f=120,lowpass=f=8000";val session=FFmpegKit.execute("-y -i '${src.absolutePath}' -af '$filter' -c:a pcm_s16le '${dst.absolutePath}'");if(!ReturnCode.isSuccess(session.returnCode))error("ffmpeg");context.contentResolver.openOutputStream(out)?.use{o->dst.inputStream().use{it.copyTo(o)}}?:error("save");src.delete();dst.delete();true}.getOrDefault(false)

// ---------------------------- Voice Cleaner ------------------------------
@Composable internal fun PulseVoiceCleanerScreen(onBack:()->Unit,prefs:UserPreferences,premiumUseAvailable:Boolean=true,onTrack:(String,Boolean?,Long?)->Unit){
    val context=LocalContext.current;val scope=rememberCoroutineScope();var input by remember{mutableStateOf<Uri?>(null)};var name by remember{mutableStateOf("Selecione voz, podcast ou gravação")};var strength by remember{mutableFloatStateOf(.55f)};var busy by remember{mutableStateOf(false)};var msg by remember{mutableStateOf("Redução de ruído • compressor • limiter • normalização")}
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){u->u?.let{input=it;name=queryDisplayName(context,it)}}
    val saver=rememberLauncherForActivityResult(SonusAutoCreateDocument("audio/wav")){out->val src=input;if(out!=null&&src!=null){busy=true;SonusProcessNotifier.publish(context,"Voice Cleaner",0);scope.launch{val started=System.currentTimeMillis();val ok=withContext(Dispatchers.IO){cleanVoice(context,src,out,strength)};busy=false;if(ok)SonusProcessNotifier.publish(context,"Voice Cleaner",100) else SonusProcessNotifier.fail(context,"Voice Cleaner");msg=if(ok)"Voz limpa exportada" else "Falha no processamento";PulseHaptics.perform(context,prefs,if(ok)PulseHapticEvent.SUCCESS else PulseHapticEvent.WARNING);SonusNotificationCenter.add(context,if(ok)"Voice Cleaner concluído" else "Falha no Voice Cleaner",if(ok)"A voz limpa foi exportada como uma nova cópia." else "O processamento não pôde ser concluído.","FERRAMENTAS",importantExternal=false);onTrack("SONUS Voice Cleaner",ok,System.currentTimeMillis()-started)}}}
    ProToolScaffold("SONUS Voice Cleaner",Color(0xFF6CE4C1),onBack){Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF081D1A)),border=BorderStroke(1.dp,Color(0xFF6CE4C1).copy(alpha=.32f))){Column(Modifier.fillMaxWidth().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){Row(verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.CleaningServices,null,tint=Color(0xFF6CE4C1),modifier=Modifier.size(40.dp));Spacer(Modifier.width(10.dp));Column{Text(name,fontWeight=FontWeight.Black,color=Color.White);Text(msg,fontSize=11.sp,color=Color.White.copy(alpha=.6f))}};Button({picker.launch(arrayOf("audio/*"))},modifier=Modifier.fillMaxWidth()){Text("Escolher áudio")};Text("Limpeza ${(strength*100).roundToInt()}%",color=Color.White,fontWeight=FontWeight.Bold);Slider(strength,{strength=it},valueRange=.2f..1f);Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){listOf("Noise gate","De-noise","Comp","Limiter").forEach{AssistChip({}, {Text(it)},enabled=false)}};Button({saver.launch("SONUS_VoiceCleaner_${System.currentTimeMillis()}.wav")},enabled=input!=null&&!busy&&premiumUseAvailable,modifier=Modifier.fillMaxWidth()){Text(if(busy)"Processando…" else if(!premiumUseAvailable)"Sem Moedas SONUS" else "Limpar e exportar")}}}}
}
private fun cleanVoice(context:Context,input:Uri,out:Uri,strength:Float):Boolean=runCatching{val dir=File(context.cacheDir,"voice_cleaner").apply{mkdirs()};val src=File(dir,"in_${System.nanoTime()}.bin");val dst=File(dir,"out_${System.nanoTime()}.wav");context.contentResolver.openInputStream(input)?.use{i->src.outputStream().use{i.copyTo(it)}}?:error("open");val noise=(6+strength*18).roundToInt();val filter="highpass=f=70,afftdn=nf=-$noise,acompressor=threshold=-18dB:ratio=3:attack=12:release=120:makeup=2,alimiter=limit=0.90,loudnorm=I=-16:LRA=9:TP=-1.2";val sess=FFmpegKit.execute("-y -i '${src.absolutePath}' -af '$filter' -c:a pcm_s16le '${dst.absolutePath}'");if(!ReturnCode.isSuccess(sess.returnCode))error("ffmpeg");context.contentResolver.openOutputStream(out)?.use{o->dst.inputStream().use{it.copyTo(o)}}?:error("save");src.delete();dst.delete();true}.getOrDefault(false)

// ------------------------------ Metronome --------------------------------
@Composable internal fun PulseMetronomeScreen(onBack:()->Unit,prefs:UserPreferences,onTrack:(String,Boolean?,Long?)->Unit){
    val context=LocalContext.current;val scope=rememberCoroutineScope();var bpm by remember{mutableIntStateOf(120)};var beats by remember{mutableIntStateOf(4)};var running by remember{mutableStateOf(false)};var beat by remember{mutableIntStateOf(0)};var tapTimes by remember{mutableStateOf(listOf<Long>())};val tone=remember{ToneGenerator(AudioManager.STREAM_MUSIC,70)}
    LaunchedEffect(running,bpm,beats){if(running){while(isActive){beat=(beat%beats)+1;tone.startTone(if(beat==1)ToneGenerator.TONE_PROP_BEEP2 else ToneGenerator.TONE_PROP_BEEP,55);PulseHaptics.perform(context,prefs,PulseHapticEvent.TAP);delay((60000L/bpm).coerceAtLeast(120L))}}else beat=0}
    DisposableEffect(Unit){onDispose{tone.release()}}
    ProToolScaffold("Metrônomo Pro",Color(0xFFB982FF),onBack){Box(Modifier.fillMaxWidth().height(250.dp),contentAlignment=Alignment.Center){val phase=if(beats<=1)0f else (beat-1)/(beats-1f);Canvas(Modifier.fillMaxSize()){drawCircle(Color(0xFFB982FF).copy(alpha=.10f),size.minDimension*.38f,center);drawCircle(Color(0xFFB982FF),16.dp.toPx(),Offset(size.width*(.18f+.64f*phase),size.height*.55f))};Column(horizontalAlignment=Alignment.CenterHorizontally){Text("$bpm",fontSize=58.sp,fontWeight=FontWeight.Black,color=Color.White);Text("BPM",color=Color.White.copy(alpha=.58f));Text(if(running)"Tempo $beat / $beats" else "Pronto",color=Color(0xFFB982FF))}};Slider(bpm.toFloat(),{bpm=it.roundToInt()},valueRange=40f..240f,steps=199);Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){listOf(2,3,4,6).forEach{b->FilterChip(beats==b,{beats=b},{Text("$b/4")},modifier=Modifier.weight(1f))}};Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton({val now=System.currentTimeMillis();val list=(tapTimes+now).takeLast(5);tapTimes=list;if(list.size>=2){val avg=list.zipWithNext{a,b->b-a}.average();if(avg>0)bpm=(60000/avg).roundToInt().coerceIn(40,240)}},modifier=Modifier.weight(1f)){Text("TAP")};Button({running=!running},modifier=Modifier.weight(2f)){Icon(if(running)Icons.Default.Stop else Icons.Default.PlayArrow,null);Text(if(running)" Parar" else " Iniciar")}}}
}

// --------------------------- BPM + Key detector --------------------------
@Composable internal fun PulseBpmKeyScreen(onBack:()->Unit,prefs:UserPreferences,onTrack:(String,Boolean?,Long?)->Unit){
    val context=LocalContext.current;val scope=rememberCoroutineScope();var uri by remember{mutableStateOf<Uri?>(null)};var name by remember{mutableStateOf("Escolha uma música")};var busy by remember{mutableStateOf(false)};var bpm by remember{mutableStateOf<Int?>(null)};var key by remember{mutableStateOf<String?>(null)};var confidence by remember{mutableIntStateOf(0)}
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){u->u?.let{uri=it;name=queryDisplayName(context,it);bpm=null;key=null}}
    fun analyze(){val src=uri?:return;busy=true;scope.launch{val r=withContext(Dispatchers.IO){detectBpmAndKey(context,src)};busy=false;bpm=r.first;key=r.second;confidence=r.third;PulseHaptics.perform(context,prefs,if(r.first!=null)PulseHapticEvent.SUCCESS else PulseHapticEvent.WARNING)}}
    ProToolScaffold("Detector de BPM & Tom",Color(0xFFFFD05A),onBack){Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF221B08))){Column(Modifier.fillMaxWidth().padding(16.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(8.dp)){Icon(Icons.Default.Equalizer,null,tint=Color(0xFFFFD05A),modifier=Modifier.size(45.dp));Text(name,fontWeight=FontWeight.Bold,color=Color.White,textAlign=TextAlign.Center);Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){ResultPanel("BPM",bpm?.toString()?:"—",Modifier.weight(1f));ResultPanel("Tom",key?:"—",Modifier.weight(1f))};if(bpm!=null)Text("Confiança aproximada: $confidence%",color=Color.White.copy(alpha=.58f));Button({picker.launch(arrayOf("audio/*"))},modifier=Modifier.fillMaxWidth()){Text("Escolher música")};Button(::analyze,enabled=uri!=null&&!busy,colors=ButtonDefaults.buttonColors(containerColor=Color(0xFFFFD05A),contentColor=Color.Black),modifier=Modifier.fillMaxWidth()){Text(if(busy)"Analisando…" else "Detectar BPM e tonalidade",fontWeight=FontWeight.Black)}}};Text("Análise totalmente local baseada em transientes e energia cromática; resultados de tonalidade são estimativas musicais, especialmente em faixas muito percussivas.",fontSize=10.sp,color=Color.White.copy(alpha=.48f))}
}
@Composable private fun ResultPanel(label:String,value:String,modifier:Modifier){Surface(modifier=modifier.height(88.dp),shape=RoundedCornerShape(20.dp),color=Color.Black.copy(alpha=.25f),border=BorderStroke(1.dp,Color.White.copy(alpha=.12f))){Column(Modifier.fillMaxSize(),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Text(value,fontSize=30.sp,fontWeight=FontWeight.Black,color=Color.White);Text(label,fontSize=11.sp,color=Color.White.copy(alpha=.55f))}}}

private fun detectBpmAndKey(context:Context,uri:Uri):Triple<Int?,String?,Int>{
    val pcm=decodePcm(context,uri,11025,45)?:return Triple(null,null,0);if(pcm.size<22050)return Triple(null,null,0)
    val frame=512;val energy=DoubleArray(pcm.size/frame);for(f in energy.indices){var sum=0.0;val st=f*frame;for(i in st until min(pcm.size,st+frame)){val v=pcm[i]/32768.0;sum+=v*v};energy[f]=sqrt(sum/frame)}
    val onset=DoubleArray(energy.size);for(i in 1 until energy.size)onset[i]=max(0.0,energy[i]-energy[i-1]);val rate=11025.0/frame
    var bestBpm=0;var bestScore=-1.0;var total=0.0
    for(b in 60..200){val lag=(rate*60.0/b).roundToInt().coerceAtLeast(1);var score=0.0;for(i in lag until onset.size)score+=onset[i]*onset[i-lag];if(score>bestScore){bestScore=score;bestBpm=b};total+=max(0.0,score)}
    val names=arrayOf("C","C#","D","D#","E","F","F#","G","G#","A","A#","B");val chroma=DoubleArray(12);val n=4096;val hop=8192
    var pos=0;while(pos+n<pcm.size){for(pc in 0..11){var e=0.0;for(oct in 2..6){val midi=12*(oct+1)+pc;val hz=440.0*2.0.pow((midi-69)/12.0);if(hz>5000)continue;e+=goertzel(pcm,pos,n,11025,hz)};chroma[pc]+=e};pos+=hop}
    val k=chroma.indices.maxByOrNull{chroma[it]}?:0;val sum=chroma.sum().coerceAtLeast(1e-9);val conf=((chroma[k]/sum)*300).roundToInt().coerceIn(25,95);return Triple(bestBpm.takeIf{bestScore>0},names[k],conf)
}
private fun goertzel(data:ShortArray,start:Int,n:Int,sr:Int,hz:Double):Double{val w=2*Math.PI*hz/sr;val coeff=2*cos(w);var s0=0.0;var s1=0.0;var s2=0.0;var i=0;while(i<n){s0=data[start+i]/32768.0+coeff*s1-s2;s2=s1;s1=s0;i+=2};return s1*s1+s2*s2-coeff*s1*s2}
private fun decodePcm(context:Context,uri:Uri,sr:Int,maxSeconds:Int):ShortArray?=runCatching{val dir=File(context.cacheDir,"pulse_analysis").apply{mkdirs()};val src=File(dir,"src_${System.nanoTime()}.bin");val raw=File(dir,"raw_${System.nanoTime()}.pcm");context.contentResolver.openInputStream(uri)?.use{i->src.outputStream().use{i.copyTo(it)}}?:error("open");val sess=FFmpegKit.execute("-y -t $maxSeconds -i '${src.absolutePath}' -vn -ac 1 -ar $sr -f s16le '${raw.absolutePath}'");src.delete();if(!ReturnCode.isSuccess(sess.returnCode))error("ffmpeg");val bytes=raw.readBytes();raw.delete();val shorts=ShortArray(bytes.size/2);ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(shorts);shorts}.getOrNull()

private fun queryDisplayName(context:Context,uri:Uri):String{var name="arquivo";context.contentResolver.query(uri,arrayOf(android.provider.OpenableColumns.DISPLAY_NAME),null,null,null)?.use{c->if(c.moveToFirst()){val i=c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);if(i>=0)name=c.getString(i)?:name}};return name}
private fun shareText(context:Context,text:String){runCatching{context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_TEXT,text)},"Compartilhar transcrição"))}}
