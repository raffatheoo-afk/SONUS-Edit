package com.sonusstudios.streampulse.tools

import android.app.Application
import android.app.KeyguardManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.ServiceConnection
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

/** Preferência do usuário: mostrar o player SONUS por cima da tela de bloqueio. Ligada por padrão. */
internal object SonusLockScreenPrefs {
    private const val PREFS = "sonus_lock_screen_v1"
    private const val KEY_ENABLED = "enabled"

    fun enabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ENABLED, true)

    fun setEnabled(context: Context, value: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_ENABLED, value).apply()
    }
}

/**
 * code132: pontos de entrada da tela de bloqueio.
 *
 * 1) [contentIntent] é usado pelo cartão/notificação de mídia do próprio PulsePlayerService. Tocar nele com o
 *    aparelho bloqueado abre [SonusLockScreenActivity] por cima do bloqueio, sem destravar. Desbloqueado,
 *    a atividade apenas encaminha para o app como sempre.
 * 2) Tentativa automática ao apagar/acender a tela enquanto há música tocando. A partir do Android 10 o sistema
 *    pode bloquear a abertura de telas em segundo plano; quando bloqueia, nada acontece e o caminho (1) continua valendo.
 */
internal object SonusLockScreenController {
    @Volatile private var installed = false

    fun contentIntent(context: Context, requestCode: Int): PendingIntent {
        val intent = Intent(context, SonusLockScreenActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(
            context, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    @Synchronized
    fun install(app: Application) {
        if (installed) return
        installed = true
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                if (!SonusLockScreenPrefs.enabled(context)) return
                val audio = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
                if (!audio.isMusicActive) return
                val launch = Intent(context, SonusLockScreenActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NO_ANIMATION)
                    .putExtra(SonusLockScreenActivity.EXTRA_AUTO, true)
                runCatching { context.startActivity(launch) }
            }
        }
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        }
        runCatching { ContextCompat.registerReceiver(app, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED) }
    }
}

/**
 * Tela do player por cima da tela de bloqueio. Usa o MESMO PulsePlayerService do Player (bindService):
 * Play/Pause, Anterior e Próxima comandam a fila atual e o estado/posição vêm do próprio serviço.
 * Não existe segundo mecanismo de reprodução e nenhuma permissão nova é necessária.
 */
class SonusLockScreenActivity : ComponentActivity() {
    private var service by mutableStateOf<PulsePlayerService?>(null)
    private var bound = false
    private var unlockReceiver: BroadcastReceiver? = null

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val connected = (binder as? PulsePlayerService.LocalBinder)?.service()
            connected?.reconcileTransportState()
            service = connected
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            service = null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val auto = intent?.getBooleanExtra(EXTRA_AUTO, false) == true
        val keyguard = getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        val locked = keyguard?.isKeyguardLocked == true
        if (!locked || !SonusLockScreenPrefs.enabled(this)) {
            // Sem bloqueio (ou recurso desligado): esta atividade é só um trampolim transparente até o app.
            if (!auto) openApp()
            finish()
            return
        }
        configureWindow()
        bound = runCatching { bindService(Intent(this, PulsePlayerService::class.java), connection, 0) }.getOrDefault(false)
        if (!bound) {
            // Nenhum player em execução: não há o que mostrar sobre o bloqueio.
            if (!auto) openApp()
            finish()
            return
        }
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                finish()
            }
        }
        unlockReceiver = receiver
        runCatching {
            ContextCompat.registerReceiver(this, receiver, IntentFilter(Intent.ACTION_USER_PRESENT), ContextCompat.RECEIVER_NOT_EXPORTED)
        }
        setContent {
            SonusLockScreenContent(
                service = service,
                autoLaunched = auto,
                onClose = { finish() },
                onOpenApp = { openAppAfterUnlock() }
            )
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
    }

    override fun onDestroy() {
        unlockReceiver?.let { runCatching { unregisterReceiver(it) } }
        unlockReceiver = null
        if (bound) {
            runCatching { unbindService(connection) }
            bound = false
        }
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    private fun configureWindow() {
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
        } else {
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED)
        }
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.TRANSPARENT
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = false
    }

    private fun openApp() {
        val launch = packageManager.getLaunchIntentForPackage(packageName) ?: return
        runCatching { startActivity(launch) }
    }

    private fun openAppAfterUnlock() {
        val keyguard = getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        if (keyguard != null && keyguard.isKeyguardLocked) {
            keyguard.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
                override fun onDismissSucceeded() {
                    openApp()
                    finish()
                }
            })
        } else {
            openApp()
            finish()
        }
    }

    companion object {
        const val EXTRA_AUTO = "com.sonusstudios.streampulse.lockscreen.AUTO"
    }
}

private val LockAccent = Color(0xFF46DCFF)

@Composable
private fun SonusLockScreenContent(
    service: PulsePlayerService?,
    autoLaunched: Boolean,
    onClose: () -> Unit,
    onOpenApp: () -> Unit
) {
    val context = LocalContext.current
    val fallback = remember { MutableStateFlow(PulsePlayerPlaybackState()) }
    val state by (service?.state ?: fallback).collectAsState()
    val item = state.current

    // Nada tocando (ou abertura automática com a música já pausada): não cobre o bloqueio à toa.
    LaunchedEffect(service) {
        if (service == null) return@LaunchedEffect
        delay(900L)
        val s = service.state.value
        if (s.current == null || (autoLaunched && !s.playing)) onClose()
    }

    // Letras sob demanda para a faixa atual. Trocar de faixa cancela a busca anterior e descarta o resultado antigo.
    var lyrics by remember { mutableStateOf<SonusLockLyrics?>(null) }
    var searching by remember { mutableStateOf(false) }
    LaunchedEffect(item?.uri) {
        lyrics = null
        val current = item
        if (current == null) {
            searching = false
            return@LaunchedEffect
        }
        searching = true
        val loaded = SonusLockScreenLyricsLoader.load(context, current, state.durationMs)
        lyrics = loaded
        searching = false
    }
    val activeIndex = remember(lyrics, state.positionMs) {
        lyrics?.let { SonusLockScreenLyricsLoader.indexAt(it, state.positionMs) } ?: -1
    }

    // Relógio próprio: a tela cobre o relógio do sistema do bloqueio.
    val is24 = remember { android.text.format.DateFormat.is24HourFormat(context) }
    val clock by produceState(initialValue = System.currentTimeMillis()) {
        while (true) {
            value = System.currentTimeMillis()
            delay(10_000L)
        }
    }
    val timeText = remember(clock) { SimpleDateFormat(if (is24) "HH:mm" else "h:mm", Locale.getDefault()).format(Date(clock)) }
    val dateText = remember(clock) {
        val pattern = android.text.format.DateFormat.getBestDateTimePattern(Locale.getDefault(), "EEEEdMMMM")
        SimpleDateFormat(pattern, Locale.getDefault()).format(Date(clock)).replaceFirstChar { it.uppercase() }
    }

    val softShadow = Shadow(Color.Black.copy(alpha = 0.65f), Offset(0f, 2f), 10f)
    val shadowStyle = TextStyle(shadow = softShadow)

    // Fundo translúcido: só um véu suave para dar contraste, sem retângulo opaco sobre o papel de parede.
    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0x59000000), Color(0x1F000000), Color(0x5C000000), Color(0xB3000000))
                )
            )
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 22.dp, vertical = 8.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                Column(Modifier.weight(1f)) {
                    Text(timeText, color = Color.White, fontSize = 50.sp, fontWeight = FontWeight.Light, style = shadowStyle)
                    Text(dateText, color = Color.White.copy(alpha = 0.85f), fontSize = 14.sp, style = shadowStyle)
                }
                IconButton(onClick = onClose) {
                    Icon(Icons.Default.Close, contentDescription = "Fechar", tint = Color.White)
                }
            }
            Spacer(Modifier.height(12.dp))
            Text(
                item?.title ?: "SONUS",
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = shadowStyle
            )
            Text(
                item?.artist?.ifBlank { "SONUS" } ?: "SONUS",
                color = LockAccent,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = shadowStyle
            )

            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                val loadedLyrics = lyrics
                if (loadedLyrics == null) {
                    Text(
                        if (searching) "Buscando letra…" else "Letra indisponível para esta música",
                        color = Color.White.copy(alpha = 0.72f),
                        fontSize = 15.sp,
                        style = shadowStyle
                    )
                } else {
                    LockLyricsList(loadedLyrics, activeIndex, softShadow)
                }
            }

            val fraction = if (state.durationMs > 0L) (state.positionMs.toFloat() / state.durationMs.toFloat()).coerceIn(0f, 1f) else 0f
            LinearProgressIndicator(
                progress = { fraction },
                modifier = Modifier.fillMaxWidth().height(3.dp).clip(CircleShape),
                color = Color.White,
                trackColor = Color.White.copy(alpha = 0.25f)
            )
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(formatLockTime(state.positionMs), color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp, style = shadowStyle)
                Text(formatLockTime(state.durationMs), color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp, style = shadowStyle)
            }
            Spacer(Modifier.height(8.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { service?.previous() }, modifier = Modifier.size(60.dp)) {
                    Icon(Icons.Default.SkipPrevious, contentDescription = "Faixa anterior", tint = Color.White, modifier = Modifier.size(36.dp))
                }
                Box(
                    Modifier
                        .size(72.dp)
                        .clip(CircleShape)
                        .background(Color.White)
                        .clickable { service?.toggle() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        if (state.playing) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (state.playing) "Pausar" else "Reproduzir",
                        tint = Color(0xFF071A3D),
                        modifier = Modifier.size(42.dp)
                    )
                }
                IconButton(onClick = { service?.next(true) }, modifier = Modifier.size(60.dp)) {
                    Icon(Icons.Default.SkipNext, contentDescription = "Próxima faixa", tint = Color.White, modifier = Modifier.size(36.dp))
                }
            }
            TextButton(onClick = onOpenApp, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                Text("Abrir SONUS", color = Color.White.copy(alpha = 0.85f), style = shadowStyle)
            }
        }
    }
}

@Composable
private fun LockLyricsList(lyrics: SonusLockLyrics, activeIndex: Int, shadow: Shadow) {
    val listState = rememberLazyListState()
    LaunchedEffect(activeIndex, lyrics) {
        if (lyrics.synced && activeIndex >= 0) listState.animateScrollToItem((activeIndex - 2).coerceAtLeast(0))
    }
    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(vertical = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        itemsIndexed(lyrics.lines) { index, line ->
            val active = lyrics.synced && index == activeIndex
            val distance = if (lyrics.synced && activeIndex >= 0) abs(index - activeIndex) else 0
            val target = when {
                !lyrics.synced -> 0.9f
                active -> 1f
                distance == 1 -> 0.62f
                else -> 0.4f
            }
            val alpha by animateFloatAsState(target, label = "lock-lyric-alpha")
            Text(
                line.text,
                color = Color.White.copy(alpha = alpha),
                fontSize = if (active) 26.sp else 19.sp,
                lineHeight = if (active) 32.sp else 25.sp,
                fontWeight = if (active) FontWeight.ExtraBold else FontWeight.SemiBold,
                style = TextStyle(shadow = shadow)
            )
        }
    }
}

private fun formatLockTime(ms: Long): String {
    val total = (ms.coerceAtLeast(0L) / 1000L).toInt()
    return "%d:%02d".format(total / 60, total % 60)
}
