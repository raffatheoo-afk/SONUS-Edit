package com.sonusstudios.streampulse.audio

import java.text.Normalizer
import kotlin.math.ln

/** EQ Auto determinístico e adaptativo: gênero como ponto de partida + correção tímbrica da faixa. */
internal object SonusSmartEq {
    private data class GenreRule(val keys: List<String>, val preset: String)
    private val rules = listOf(
        GenreRule(listOf("drum and bass", "drum & bass", "breakbeat"), "Drum & Bass / Breakbeat"),
        GenreRule(listOf("alternative rock", "rock alternativo", "alternative", "alternativo"), "Alternativo"),
        GenreRule(listOf("classic rock", "rock classico", "rock clássico"), "Rock Clássico"),
        GenreRule(listOf("hard rock"), "Hard Rock"), GenreRule(listOf("punk rock", "punk"), "Punk Rock"),
        GenreRule(listOf("indie rock", "indie"), "Indie Rock"), GenreRule(listOf("heavy metal", "metal"), "Metal"),
        GenreRule(listOf("sertanejo"), "Sertanejo"), GenreRule(listOf("country"), "Country"),
        GenreRule(listOf("piseiro"), "Piseiro"), GenreRule(listOf("forro", "forró"), "Forró"),
        GenreRule(listOf("funk brasileiro", "funk carioca", "funk"), "Funk Brasileiro"),
        GenreRule(listOf("boom bap", "hip hop", "hip-hop", "rap"), "Rap / Boom Bap"),
        GenreRule(listOf("trap"), "Trap"), GenreRule(listOf("r&b", "rhythm and blues"), "R&B"),
        GenreRule(listOf("gospel", "religious", "cristao", "cristão", "worship"), "Gospel"),
        GenreRule(listOf("pagode"), "Pagode"), GenreRule(listOf("samba"), "Samba"),
        GenreRule(listOf("mpb"), "MPB"), GenreRule(listOf("bossa nova", "bossa"), "Bossa Nova"),
        GenreRule(listOf("reggaeton"), "Reggaeton"), GenreRule(listOf("reggae"), "Reggae"),
        GenreRule(listOf("salsa", "latin", "latino"), "Latin / Salsa"),
        GenreRule(listOf("techno", "trance"), "Techno / Trance"),
        GenreRule(listOf("house", "edm", "dance", "electronic", "eletronica", "eletrônica", "synth pop"), "Dance / House"),
        GenreRule(listOf("jazz"), "Jazz"), GenreRule(listOf("blues"), "Blues"),
        GenreRule(listOf("classical", "classico", "clássico", "erudita", "orchestral", "orquestral"), "Orquestral"),
        GenreRule(listOf("soundtrack", "trilha sonora", "cinematic", "score"), "Trilha Sonora / Cinema"),
        GenreRule(listOf("piano"), "Piano"), GenreRule(listOf("ambient"), "Ambient"),
        GenreRule(listOf("lofi", "lo-fi", "chillhop"), "Lo-fi"),
        GenreRule(listOf("acoustic", "acustico", "acústico"), "Acústico"),
        GenreRule(listOf("folk"), "Folk"), GenreRule(listOf("soul"), "Soul"),
        GenreRule(listOf("vocal", "podcast", "spoken word"), "Podcast / Voz"),
        GenreRule(listOf("pop"), "Pop"), GenreRule(listOf("rock"), "Rock")
    )

    fun normalize(value: String): String = Normalizer.normalize(value.lowercase(), Normalizer.Form.NFD)
        .replace(Regex("\\p{Mn}+"), "")
        .replace(Regex("[^a-z0-9&]+"), " ")
        .trim()

    fun presetForGenre(rawGenre: String): String? {
        val genre = normalize(rawGenre)
        if (genre.isBlank()) return null
        // Regras ordenadas do mais específico para o mais genérico evitam substring ambígua.
        return rules.firstOrNull { rule -> rule.keys.any { key ->
            val normalizedKey = normalize(key)
            Regex("(^|\\s)${Regex.escape(normalizedKey)}($|\\s)").containsMatchIn(genre) || genre == normalizedKey
        } }?.preset
    }

    fun genreBase(rawGenre: String): List<Float> {
        val preset = presetForGenre(rawGenre) ?: "Neutro"
        return SonusEqPresetCatalog.curves[preset]?.map { it.toFloat() }
            ?: SonusEqPresetCatalog.curves.getValue("Neutro").map { it.toFloat() }
    }

    /**
     * Converte o espectro log de 64 bandas em uma correção de 10 bandas pequena e suave.
     * O espectro é somente uma característica da gravação, não uma referência de qualidade.
     */
    fun adaptPerTrack(base: List<Float>, analysis: AudioAnalysis): List<Float> {
        if (analysis.frames.isEmpty()) return base.take(10)
        val bins = FloatArray(64)
        analysis.frames.forEach { frame ->
            val values = frame.values
            for (i in 0 until minOf(64, values.size)) bins[i] += values[i].coerceIn(0f, 1f)
        }
        val count = analysis.frames.size.toFloat().coerceAtLeast(1f)
        for (i in bins.indices) bins[i] /= count
        val correction = FloatArray(10)
        for (band in 0 until 10) {
            // Faixas logarítmicas aproximadas alinhadas às frequências do equalizador.
            val idx = (band * 63f / 9f).toInt().coerceIn(0, 63)
            val local = ((bins[(idx - 1).coerceAtLeast(0)] + bins[idx] + bins[(idx + 1).coerceAtMost(63)]) / 3f)
            val global = bins.average().toFloat().coerceAtLeast(.035f)
            val ratioDb = (20.0 * ln((global + .04f) / (local + .04f)) / ln(10.0)).toFloat()
            correction[band] = (ratioDb * .10f).coerceIn(-1.15f, 1.15f)
        }
        val smooth = correction.indices.map { i ->
            val left = correction[(i - 1).coerceAtLeast(0)]
            val center = correction[i]
            val right = correction[(i + 1).coerceAtMost(9)]
            (left * .22f + center * .56f + right * .22f)
        }
        return (0 until 10).map { i -> ((base.getOrElse(i) { 0f } + smooth[i]) * .88f).coerceIn(-4f, 4f) }
    }
}
