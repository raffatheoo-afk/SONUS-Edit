package com.sonusstudios.streampulse.core

import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.math.roundToInt

object HealthEngine {
    fun calculate(
        entries: List<DailyStreamEntry>,
        missingDays: Int = 0,
        cycleStartIso: String? = null,
        cycleEndIso: String? = null,
        referenceDateIso: String = LocalDate.now().toString()
    ): HealthResult {
        val start = cycleStartIso?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
        val end = cycleEndIso?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
        val reference = runCatching { LocalDate.parse(referenceDateIso) }.getOrDefault(LocalDate.now())

        val scoped = if (start != null && end != null) {
            entries.filter { entry ->
                val date = runCatching { LocalDate.parse(entry.dateIso) }.getOrNull() ?: return@filter false
                !date.isBefore(start) && !date.isAfter(end)
            }
        } else entries

        val totalCycleDays = if (start != null && end != null && !end.isBefore(start)) {
            (ChronoUnit.DAYS.between(start, end) + 1L).toInt().coerceAtLeast(1)
        } else 30

        var score = 0
        var positive = 0
        var weak = 0
        val scored = scoped.sortedBy { it.dateIso }.map { entry ->
            val points = if (start != null && end != null) {
                pointsForDate(start, end, LocalDate.parse(entry.dateIso), entry.streams)
            } else {
                pointsForStreams(entry.streams, 3)
            }
            if (points > 0) positive++ else weak++
            score += points
            entry.copy(points = points)
        }
        score = score.coerceAtMost(100)

        val possiblePoints = if (start != null && end != null && !end.isBefore(start) && !reference.isBefore(start)) {
            val cappedReference = if (reference.isAfter(end)) end else reference
            val elapsedDays = (ChronoUnit.DAYS.between(start, cappedReference) + 1L).toInt().coerceIn(0, totalCycleDays)
            (0 until elapsedDays).sumOf { positivePointsForDay(totalCycleDays, it) }
        } else if (scored.isNotEmpty()) {
            scored.filter { it.points > 0 }.sumOf { it.points }
                .coerceAtLeast(scored.size * 3)
        } else 0

        val performance = when {
            scored.isEmpty() || possiblePoints <= 0 -> 0.0
            else -> (score.coerceAtLeast(0).toDouble() / possiblePoints.toDouble() * 100.0).coerceIn(0.0, 100.0)
        }
        val label = labelForPerformance(performance, scored.isEmpty())
        val emoji = emojiForPerformance(performance, scored.isEmpty())

        return HealthResult(
            score = score,
            emoji = emoji,
            label = label,
            scoredDays = scored.size,
            positiveDays = positive,
            weakDays = weak,
            missingDays = missingDays,
            lastDay = scored.maxByOrNull { it.dateIso },
            possiblePoints = possiblePoints,
            performancePercent = performance,
            cycleStartIso = cycleStartIso,
            cycleEndIso = cycleEndIso
        )
    }

    fun calculateFromSnapshots(
        snapshots: List<StreamSnapshot>,
        manualRecords: List<DailyStreamRecord> = emptyList(),
        cycle: CycleWindow? = null,
        referenceDate: LocalDate = LocalDate.now(),
        entryMode: String = "AUTO",
        cycleId: String? = null
    ): HealthResult {
        val explicitStart = cycle?.startIso?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
        val explicitEnd = cycle?.endIso?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
        if (cycle != null && explicitStart != null && explicitEnd != null && !explicitEnd.isBefore(explicitStart)) {
            // Saúde, Histórico, médias e projeções precisam enxergar a mesma contabilidade.
            // O snapshot acumulado nunca é tratado como "+total daquele dia".
            val metrics = StreamMetricsEngine.cycleMetrics(
                snapshots = snapshots,
                dailyRecords = manualRecords,
                cycleStart = explicitStart,
                cycleEnd = explicitEnd,
                referenceDate = referenceDate,
                entryMode = entryMode,
                cycleId = cycleId
            )
            return calculate(
                entries = metrics.dailyEntries,
                missingDays = 0,
                cycleStartIso = cycle.startIso,
                cycleEndIso = cycle.endIso,
                referenceDateIso = referenceDate.toString()
            )
        }
        val extraction = extractDailyEntries(snapshots, manualRecords, includeFirstSnapshot = true)
        val resolvedCycle = cycle ?: inferLatestCycle(snapshots, extraction.entries)
        return calculate(
            entries = extraction.entries,
            missingDays = extraction.missingDays,
            cycleStartIso = resolvedCycle?.startIso,
            cycleEndIso = resolvedCycle?.endIso,
            referenceDateIso = referenceDate.toString()
        )
    }

    /**
     * Série diária exata usada pela Saúde do Projeto. Várias leituras no mesmo dia
     * contam como um único fechamento diário e registros manuais têm prioridade.
     */
    fun exactDailyEntries(
        snapshots: List<StreamSnapshot>,
        manualRecords: List<DailyStreamRecord> = emptyList()
    ): List<DailyStreamEntry> =
        extractDailyEntries(snapshots, manualRecords, includeFirstSnapshot = true).entries

    /** Série para tendência/gráficos. O primeiro acumulado vira baseline quando há retroativos. */
    fun analyticsDailyEntries(
        snapshots: List<StreamSnapshot>,
        manualRecords: List<DailyStreamRecord> = emptyList()
    ): List<DailyStreamEntry> =
        extractDailyEntries(
            snapshots,
            manualRecords,
            includeFirstSnapshot = manualRecords.isEmpty()
        ).entries

    /**
     * Série estrita para projeções. Nunca transforma o primeiro acumulado do ciclo em
     * "streams do dia": usa somente diferenças entre fechamentos consecutivos e
     * registros manuais explícitos. Evita inflação do Pulso ao Vivo.
     */
    fun projectableDailyEntries(
        snapshots: List<StreamSnapshot>,
        manualRecords: List<DailyStreamRecord> = emptyList()
    ): List<DailyStreamEntry> =
        extractDailyEntries(snapshots, manualRecords, includeFirstSnapshot = false).entries

    fun exactDailyStreams(
        snapshots: List<StreamSnapshot>,
        manualRecords: List<DailyStreamRecord> = emptyList()
    ): List<Long> = exactDailyEntries(snapshots, manualRecords).map { it.streams }

    fun missingDays(
        snapshots: List<StreamSnapshot>,
        manualRecords: List<DailyStreamRecord> = emptyList()
    ): Int = extractDailyEntries(snapshots, manualRecords, includeFirstSnapshot = true).missingDays

    fun pointsForDate(cycleStart: LocalDate, cycleEnd: LocalDate, date: LocalDate, streams: Long): Int {
        if (streams <= 70L) return -3
        if (streams <= 130L) return -2
        if (streams <= 200L) return -1
        if (date.isBefore(cycleStart) || date.isAfter(cycleEnd)) return 3
        val totalDays = (ChronoUnit.DAYS.between(cycleStart, cycleEnd) + 1L).toInt().coerceAtLeast(1)
        val index = ChronoUnit.DAYS.between(cycleStart, date).toInt().coerceIn(0, totalDays - 1)
        return positivePointsForDay(totalDays, index)
    }

    fun pointsForStreams(streams: Long, positivePoints: Int = 3): Int = when {
        streams <= 70L -> -3
        streams <= 130L -> -2
        streams <= 200L -> -1
        else -> positivePoints.coerceAtLeast(1)
    }

    /** Distribui exatamente 100 pontos positivos pelo ciclo. Em ciclos de 28–31 dias resulta em +3/+4. */
    fun positivePointsForDay(totalDays: Int, dayIndex: Int): Int {
        val days = totalDays.coerceAtLeast(1)
        val base = 100 / days
        val remainder = 100 % days
        val index = dayIndex.coerceIn(0, days - 1)
        val before = (index * remainder) / days
        val after = ((index + 1) * remainder) / days
        return base + if (after > before) 1 else 0
    }

    private fun inferLatestCycle(snapshots: List<StreamSnapshot>, entries: List<DailyStreamEntry>): CycleWindow? {
        val latest = snapshots.maxWithOrNull(compareBy<StreamSnapshot> { it.dateIso }.thenBy { it.recordedAtEpochMillis })
        if (latest != null) {
            return CycleWindow(latest.cycleStartIso, latest.cycleEndIso, "Ciclo registrado")
        }
        val first = entries.minByOrNull { it.dateIso } ?: return null
        val last = entries.maxByOrNull { it.dateIso } ?: return null
        return CycleWindow(first.dateIso, last.dateIso, "Período registrado")
    }

    private fun extractDailyEntries(
        snapshots: List<StreamSnapshot>,
        manualRecords: List<DailyStreamRecord>,
        includeFirstSnapshot: Boolean
    ): DailyExtraction {
        val entries = mutableListOf<DailyStreamEntry>()

        snapshots
            .groupBy { it.cycleStartIso }
            .values
            .forEach { cycleSnapshots ->
                val latestByDate = latestPerDate(cycleSnapshots)
                if (latestByDate.isEmpty()) return@forEach

                val first = latestByDate.first()
                if (includeFirstSnapshot && first.cumulativeStreams >= 0) {
                    entries += dailyEntry(first.dateIso, first.cumulativeStreams)
                }

                latestByDate.zipWithNext().forEach { (previous, current) ->
                    val previousDate = LocalDate.parse(previous.dateIso)
                    val currentDate = LocalDate.parse(current.dateIso)
                    val days = ChronoUnit.DAYS.between(previousDate, currentDate)
                    val delta = current.cumulativeStreams - previous.cumulativeStreams
                    if (days >= 1 && delta >= 0) entries += dailyEntry(current.dateIso, delta)
                }
            }

        val dailyByDate = entries
            .groupBy { it.dateIso }
            .mapValues { (date, sameDay) -> dailyEntry(date, sameDay.maxOf { it.streams }) }
            .toMutableMap()

        manualRecords.forEach { record ->
            dailyByDate[record.dateIso] = dailyEntry(record.dateIso, record.streams.coerceAtLeast(0L))
        }

        val daily = dailyByDate.values.sortedBy { it.dateIso }
        val missing = daily.zipWithNext().sumOf { (previous, current) ->
            val days = ChronoUnit.DAYS.between(LocalDate.parse(previous.dateIso), LocalDate.parse(current.dateIso))
            (days - 1).coerceAtLeast(0).toInt()
        }
        return DailyExtraction(daily, missing)
    }

    private fun latestPerDate(snapshots: List<StreamSnapshot>): List<StreamSnapshot> {
        val ordered = snapshots.sortedWith(compareBy<StreamSnapshot> { it.dateIso }.thenBy { it.recordedAtEpochMillis })
        val map = linkedMapOf<String, StreamSnapshot>()
        ordered.forEach { map[it.dateIso] = it }
        return map.values.sortedBy { it.dateIso }
    }

    private fun dailyEntry(dateIso: String, streams: Long): DailyStreamEntry =
        DailyStreamEntry(dateIso = dateIso, streams = streams, points = pointsForStreams(streams, 3))

    fun emojiFor(score: Int): String = when {
        score < 0 -> "💥"
        score <= 10 -> "💣"
        score <= 20 -> "⚫"
        score <= 30 -> "🔴"
        score <= 40 -> "🟤"
        score <= 50 -> "🟣"
        score <= 60 -> "🟠"
        score <= 70 -> "🟡"
        score <= 85 -> "🔵"
        else -> "🟢"
    }

    fun labelFor(score: Int): String = when {
        score < 0 -> "Crítico"
        score <= 10 -> "Muito fraco"
        score <= 20 -> "Fraco"
        score <= 30 -> "Atenção"
        score <= 40 -> "Instável"
        score <= 50 -> "Reagindo"
        score <= 60 -> "Regular"
        score <= 70 -> "Bom"
        score <= 85 -> "Muito bom"
        else -> "Excelente"
    }

    fun labelForPerformance(percent: Double, noData: Boolean = false): String = when {
        noData -> "Sem dados"
        percent >= 90.0 -> "Excelente"
        percent >= 80.0 -> "Muito bom"
        percent >= 70.0 -> "Bom"
        percent >= 55.0 -> "Regular"
        percent >= 40.0 -> "Atenção"
        percent >= 25.0 -> "Fraco"
        else -> "Crítico"
    }

    fun emojiForPerformance(percent: Double, noData: Boolean = false): String = when {
        noData -> "⚪"
        percent >= 90.0 -> "🟢"
        percent >= 80.0 -> "🔵"
        percent >= 70.0 -> "🟡"
        percent >= 55.0 -> "🟠"
        percent >= 40.0 -> "🟣"
        percent >= 25.0 -> "🔴"
        else -> "💥"
    }

    private data class DailyExtraction(val entries: List<DailyStreamEntry>, val missingDays: Int)
}
