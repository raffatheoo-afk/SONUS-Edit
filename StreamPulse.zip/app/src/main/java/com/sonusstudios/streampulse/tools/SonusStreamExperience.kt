package com.sonusstudios.streampulse.tools

import android.content.Context
import android.net.TrafficStats
import android.os.Process
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

internal class SonusStreamExperiencePreferences(context: Context) {
    private val p=context.applicationContext.getSharedPreferences("sonus_stream_experience_v2",Context.MODE_PRIVATE)
    var catalogRefreshMinutes:Int get()=p.getInt("catalogRefreshMinutes",0);set(v){p.edit().putInt("catalogRefreshMinutes",v).apply()}
    var preloadNext:Boolean get()=p.getBoolean("preloadNext",true);set(v){p.edit().putBoolean("preloadNext",v).apply()}
    var fadeInSeconds:Int get()=p.getInt("fadeInSeconds",0);set(v){p.edit().putInt("fadeInSeconds",v.coerceIn(0,10)).apply()}
    var fadeOutSeconds:Int get()=p.getInt("fadeOutSeconds",0);set(v){p.edit().putInt("fadeOutSeconds",v.coerceIn(0,10)).apply()}
    var crossfadeSeconds:Int get()=p.getInt("crossfadeSeconds",0);set(v){p.edit().putInt("crossfadeSeconds",v.coerceIn(0,12)).apply()}
    var dataMonitor:Boolean get()=p.getBoolean("dataMonitor",false);set(v){p.edit().putBoolean("dataMonitor",v).apply()}
    var lyricsAutoScroll:Boolean get()=p.getBoolean("lyricsAutoScroll",true);set(v){p.edit().putBoolean("lyricsAutoScroll",v).apply()}
    var useHistoryRecommendations:Boolean get()=p.getBoolean("useHistoryRecommendations",true);set(v){p.edit().putBoolean("useHistoryRecommendations",v).apply()}
    var defaultPlaylistPublic:Boolean get()=p.getBoolean("defaultPlaylistPublic",true);set(v){p.edit().putBoolean("defaultPlaylistPublic",v).apply()}
    var lastCatalogRefreshAt:Long get()=p.getLong("lastCatalogRefreshAt",0L);set(v){p.edit().putLong("lastCatalogRefreshAt",v).apply()}
    fun dueForCatalogRefresh(now:Long=System.currentTimeMillis()):Boolean {
        val m=catalogRefreshMinutes
        if(m<=0) return true // Sempre ao abrir
        return now-lastCatalogRefreshAt >= m*60_000L
    }
    fun reset(){p.edit().clear().apply()}
}

@Composable
internal fun SonusDataUsageMiniMonitor(enabled:Boolean, modifier:Modifier=Modifier){
    if(!enabled)return
    val uid=remember{Process.myUid()}
    val startRx=remember{TrafficStats.getUidRxBytes(uid).coerceAtLeast(0L)}
    val startTx=remember{TrafficStats.getUidTxBytes(uid).coerceAtLeast(0L)}
    var lastRx by remember{mutableLongStateOf(startRx)}; var lastTx by remember{mutableLongStateOf(startTx)}
    var bps by remember{mutableLongStateOf(0L)}; var total by remember{mutableLongStateOf(0L)}
    LaunchedEffect(enabled){while(enabled){delay(1000);val r=TrafficStats.getUidRxBytes(uid).coerceAtLeast(lastRx);val t=TrafficStats.getUidTxBytes(uid).coerceAtLeast(lastTx);bps=(r-lastRx+t-lastTx).coerceAtLeast(0L);total=(r-startRx+t-startTx).coerceAtLeast(0L);lastRx=r;lastTx=t}}
    fun rate(v:Long)=when{v>=1024*1024->"%.1f MB/s".format(v/1024.0/1024.0);v>=1024->"%.0f KB/s".format(v/1024.0);else->"$v B/s"}
    fun size(v:Long)=when{v>=1024*1024->"%.1f MB".format(v/1024.0/1024.0);v>=1024->"%.0f KB".format(v/1024.0);else->"$v B"}
    Surface(modifier=modifier,shape=RoundedCornerShape(8.dp),color=Color.Black.copy(alpha=.58f)){Text("${rate(bps)} • ${size(total)}",modifier=Modifier.padding(horizontal=7.dp,vertical=3.dp),fontSize=8.sp,color=Color.White.copy(alpha=.80f),fontWeight=FontWeight.Medium)}
}
