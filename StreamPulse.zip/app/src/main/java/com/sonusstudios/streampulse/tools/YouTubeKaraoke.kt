package com.sonusstudios.streampulse.tools

import android.content.Context
import android.content.ContextWrapper
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.text.Html
import androidx.activity.ComponentActivity
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.PlayerConstants
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.options.IFramePlayerOptions
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView
import com.sonusstudios.streampulse.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.util.Locale

internal data class YouTubeVideoResult(
    val videoId: String,
    val title: String,
    val channelTitle: String,
    val thumbnailUrl: String?
)

/**
 * Busca pública da YouTube Data API v3.
 *
 * A chave é injetada no BuildConfig pelo Codemagic e continua restrita no
 * Google Cloud ao package + SHA-1 + YouTube Data API v3.
 */
internal object YouTubeSearchClient {
    private const val ENDPOINT = "https://www.googleapis.com/youtube/v3/search"
    private const val MAX_CACHE = 12

    private val cache = object : LinkedHashMap<String, List<YouTubeVideoResult>>(MAX_CACHE, .75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, List<YouTubeVideoResult>>?): Boolean =
            size > MAX_CACHE
    }

    suspend fun search(context: Context, rawQuery: String, mode: String): Result<List<YouTubeVideoResult>> =
        withContext(Dispatchers.IO) {
            runCatching {
                val apiKey = BuildConfig.YOUTUBE_API_KEY.trim()
                require(apiKey.isNotBlank()) {
                    "A busca interna do YouTube não foi configurada nesta compilação."
                }

                val searchText = "${rawQuery.trim()} ${mode.trim()}".trim()
                require(searchText.isNotBlank()) { "Digite o nome de uma música." }

                val language = Locale.getDefault().language.takeIf { it.length == 2 } ?: "pt"
                val country = Locale.getDefault().country.takeIf { it.length == 2 } ?: "BR"
                val cacheKey = "$language|$country|${searchText.lowercase(Locale.ROOT)}"
                synchronized(cache) { cache[cacheKey] }?.let { return@runCatching it }

                val encoded = URLEncoder.encode(searchText, Charsets.UTF_8.name())
                val url = URL(
                    "$ENDPOINT?part=snippet&type=video&maxResults=25" +
                        "&videoEmbeddable=true&videoSyndicated=true&safeSearch=moderate" +
                        "&relevanceLanguage=$language&regionCode=$country" +
                        "&fields=items(id/videoId,snippet(title,channelTitle,thumbnails/medium/url))" +
                        "&q=$encoded&key=${URLEncoder.encode(apiKey, Charsets.UTF_8.name())}"
                )

                val connection = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 10_000
                    readTimeout = 12_000
                    setRequestProperty("Accept", "application/json")
                    setRequestProperty("X-Android-Package", context.packageName)
                    setRequestProperty("X-Android-Cert", androidSigningSha1(context))
                }

                try {
                    val status = connection.responseCode
                    val stream = if (status in 200..299) connection.inputStream else connection.errorStream
                    val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                    if (status !in 200..299) {
                        val apiMessage = runCatching {
                            JSONObject(body).optJSONObject("error")?.optString("message")
                        }.getOrNull().orEmpty()
                        error(
                            when (status) {
                                403 -> "O YouTube recusou a credencial ou a cota da pesquisa. Verifique a configuração da API."
                                429 -> "Muitas pesquisas em pouco tempo. Tente novamente em instantes."
                                else -> apiMessage.ifBlank { "Falha ao pesquisar no YouTube (HTTP $status)." }
                            }
                        )
                    }

                    val root = JSONObject(body)
                    val items = root.optJSONArray("items")
                    val result = buildList {
                        if (items != null) {
                            for (i in 0 until items.length()) {
                                val item = items.optJSONObject(i) ?: continue
                                val videoId = item.optJSONObject("id")?.optString("videoId").orEmpty()
                                if (videoId.isBlank()) continue
                                val snippet = item.optJSONObject("snippet") ?: continue
                                val thumbnail = snippet.optJSONObject("thumbnails")
                                    ?.optJSONObject("medium")
                                    ?.optString("url")
                                    ?.takeIf { it.isNotBlank() }
                                add(
                                    YouTubeVideoResult(
                                        videoId = videoId,
                                        title = decodeHtml(snippet.optString("title")),
                                        channelTitle = decodeHtml(snippet.optString("channelTitle")),
                                        thumbnailUrl = thumbnail
                                    )
                                )
                            }
                        }
                    }
                    synchronized(cache) { cache[cacheKey] = result }
                    result
                } finally {
                    connection.disconnect()
                }
            }
        }

    private fun decodeHtml(value: String): String =
        Html.fromHtml(value, Html.FROM_HTML_MODE_LEGACY).toString()

}

@Suppress("DEPRECATION")
private fun androidSigningSha1(context: Context): String {
    val info = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
        context.packageManager.getPackageInfo(context.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
    } else {
        context.packageManager.getPackageInfo(context.packageName, PackageManager.GET_SIGNATURES)
    }
    val signature = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
        info.signingInfo?.apkContentsSigners?.firstOrNull()
    } else {
        info.signatures?.firstOrNull()
    } ?: error("Assinatura Android não encontrada.")

    return MessageDigest.getInstance("SHA-1")
        .digest(signature.toByteArray())
        .joinToString("") { byte -> "%02X".format(byte.toInt() and 0xFF) }
}

internal data class YouTubePlaylistResult(
    val playlistId: String,
    val title: String,
    val channelTitle: String,
    val thumbnailUrl: String?,
    val videos: List<YouTubeVideoResult>
)

/** Leitura de playlists públicas/não listadas usando somente a YouTube Data API v3. */
internal object YouTubePlaylistClient {
    private const val API_BASE = "https://www.googleapis.com/youtube/v3"

    fun extractPlaylistId(raw: String): String? {
        val text = raw.trim()
        if (text.isBlank()) return null
        // Também aceita o ID puro para facilitar testes/links copiados parcialmente.
        if (!text.contains("/") && !text.contains("?") && !text.contains("&") && text.length >= 10) return text
        return runCatching {
            val uri = android.net.Uri.parse(text)
            uri.getQueryParameter("list")?.takeIf { it.isNotBlank() }
        }.getOrNull()
    }

    suspend fun load(context: Context, rawLinkOrId: String): Result<YouTubePlaylistResult> =
        withContext(Dispatchers.IO) {
            runCatching {
                val apiKey = BuildConfig.YOUTUBE_API_KEY.trim()
                require(apiKey.isNotBlank()) { "A integração do YouTube não foi configurada nesta compilação." }
                val playlistId = extractPlaylistId(rawLinkOrId)
                    ?: error("Link de playlist inválido. Cole um link do YouTube que contenha ?list=…")

                val detailsUrl = URL(
                    "$API_BASE/playlists?part=snippet,contentDetails&id=${URLEncoder.encode(playlistId, Charsets.UTF_8.name())}" +
                        "&fields=items(id,snippet(title,channelTitle,thumbnails/medium/url),contentDetails/itemCount)" +
                        "&key=${URLEncoder.encode(apiKey, Charsets.UTF_8.name())}"
                )
                val details = getJson(context, detailsUrl)
                val playlist = details.optJSONArray("items")?.optJSONObject(0)
                    ?: error("Playlist não encontrada ou não está disponível publicamente.")
                val snippet = playlist.optJSONObject("snippet") ?: JSONObject()
                val title = decodeHtmlValue(snippet.optString("title")).ifBlank { "Playlist do YouTube" }
                val channel = decodeHtmlValue(snippet.optString("channelTitle"))
                val cover = snippet.optJSONObject("thumbnails")?.optJSONObject("medium")?.optString("url")?.takeIf { it.isNotBlank() }

                val videos = mutableListOf<YouTubeVideoResult>()
                var pageToken: String? = null
                var pages = 0
                do {
                    val tokenPart = pageToken?.takeIf { it.isNotBlank() }?.let { "&pageToken=${URLEncoder.encode(it, Charsets.UTF_8.name())}" }.orEmpty()
                    val itemsUrl = URL(
                        "$API_BASE/playlistItems?part=snippet,contentDetails&maxResults=50" +
                            "&playlistId=${URLEncoder.encode(playlistId, Charsets.UTF_8.name())}$tokenPart" +
                            "&fields=nextPageToken,items(snippet(title,videoOwnerChannelTitle,channelTitle,thumbnails/medium/url,resourceId/videoId),contentDetails/videoId)" +
                            "&key=${URLEncoder.encode(apiKey, Charsets.UTF_8.name())}"
                    )
                    val root = getJson(context, itemsUrl)
                    val items = root.optJSONArray("items") ?: JSONArray()
                    for (i in 0 until items.length()) {
                        val item = items.optJSONObject(i) ?: continue
                        val itemSnippet = item.optJSONObject("snippet") ?: continue
                        val id = item.optJSONObject("contentDetails")?.optString("videoId").orEmpty()
                            .ifBlank { itemSnippet.optJSONObject("resourceId")?.optString("videoId").orEmpty() }
                        if (id.isBlank()) continue
                        val itemTitle = decodeHtmlValue(itemSnippet.optString("title"))
                        if (itemTitle.equals("Deleted video", true) || itemTitle.equals("Private video", true)) continue
                        val itemChannel = decodeHtmlValue(itemSnippet.optString("videoOwnerChannelTitle").ifBlank { itemSnippet.optString("channelTitle") })
                        val thumb = itemSnippet.optJSONObject("thumbnails")?.optJSONObject("medium")?.optString("url")?.takeIf { it.isNotBlank() }
                        videos += YouTubeVideoResult(id, itemTitle.ifBlank { "Vídeo do YouTube" }, itemChannel, thumb)
                    }
                    pageToken = root.optString("nextPageToken").takeIf { it.isNotBlank() }
                    pages++
                } while (pageToken != null && pages < 10) // até 500 itens por carregamento

                require(videos.isNotEmpty()) { "A playlist não possui vídeos disponíveis para reprodução." }
                YouTubePlaylistResult(playlistId, title, channel, cover, videos.distinctBy { it.videoId })
            }
        }

    private fun getJson(context: Context, url: URL): JSONObject {
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 10_000
            readTimeout = 15_000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("X-Android-Package", context.packageName)
            setRequestProperty("X-Android-Cert", androidSigningSha1(context))
        }
        try {
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (status !in 200..299) {
                val apiMessage = runCatching { JSONObject(body).optJSONObject("error")?.optString("message") }.getOrNull().orEmpty()
                error(when (status) {
                    403 -> "O YouTube recusou a credencial, a cota ou o acesso a esta playlist."
                    404 -> "Playlist não encontrada."
                    429 -> "Muitas solicitações ao YouTube. Tente novamente em instantes."
                    else -> apiMessage.ifBlank { "Falha ao consultar a playlist (HTTP $status)." }
                })
            }
            return JSONObject(body)
        } finally {
            connection.disconnect()
        }
    }

    private fun decodeHtmlValue(value: String): String =
        Html.fromHtml(value, Html.FROM_HTML_MODE_LEGACY).toString()
}

@Composable
internal fun YouTubeThumbnail(url: String?, modifier: Modifier = Modifier) {
    val bitmap by produceState<Bitmap?>(initialValue = null, key1 = url) {
        value = if (url.isNullOrBlank()) null else withContext(Dispatchers.IO) {
            runCatching {
                val connection = URL(url).openConnection().apply {
                    connectTimeout = 7_000
                    readTimeout = 8_000
                }
                connection.getInputStream().use(BitmapFactory::decodeStream)
            }.getOrNull()
        }
    }
    Box(modifier = modifier.background(Color.Black.copy(alpha = .22f)), contentAlignment = Alignment.Center) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap!!.asImageBitmap(),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else if (!url.isNullOrBlank()) {
            CircularProgressIndicator()
        }
    }
}

/**
 * Um único controlador é mantido durante toda a tela do Karaokê.
 * Selecionar outro resultado reutiliza o mesmo player, interrompe o vídeo atual
 * e carrega o novo. Isso evita múltiplos WebViews/lifecycles concorrentes.
 */
internal class StreamPulseYouTubeController {
    internal var player: YouTubePlayer? = null
    internal var pendingVideoId: String? = null
    private var loadedVideoId: String? = null

    var ready by mutableStateOf(false)
        private set
    var isPlaying by mutableStateOf(false)
        private set
    var qualityLabel by mutableStateOf("Automática")
        private set
    var errorMessage by mutableStateOf<String?>(null)
        private set
    var stateLabel by mutableStateOf("Preparando player...")
        private set
    var endedGeneration by mutableStateOf(0)
        private set

    internal fun attach(youTubePlayer: YouTubePlayer) {
        player = youTubePlayer
        ready = true
        errorMessage = null
        stateLabel = "Player pronto"
        pendingVideoId?.let { load(it, force = true) }
    }

    internal fun detach() {
        player = null
        ready = false
        isPlaying = false
        loadedVideoId = null
        stateLabel = "Player encerrado"
    }

    fun load(videoId: String, force: Boolean = false) {
        pendingVideoId = videoId
        if (!ready) return
        if (!force && loadedVideoId == videoId) return
        errorMessage = null
        stateLabel = "Carregando vídeo..."
        player?.loadVideo(videoId, 0f)
        loadedVideoId = videoId
    }

    fun retry() {
        pendingVideoId?.let {
            loadedVideoId = null
            load(it, force = true)
        }
    }

    fun play() {
        if (ready) player?.play()
    }

    fun pause() {
        if (ready) player?.pause()
    }

    fun reportStalledPlayer() {
        if (errorMessage == null && ready && stateLabel in setOf("Player pronto", "Carregando vídeo...", "Aguardando reprodução")) {
            errorMessage = "O player do YouTube não respondeu a tempo neste aparelho. Tente recarregar ou escolha outro resultado."
            stateLabel = "Player sem resposta"
            isPlaying = false
        }
    }

    internal fun onState(state: PlayerConstants.PlayerState) {
        isPlaying = state == PlayerConstants.PlayerState.PLAYING
        if (state == PlayerConstants.PlayerState.ENDED) endedGeneration += 1
        stateLabel = when (state.toString().uppercase(Locale.US)) {
            "PLAYING" -> "Reproduzindo"
            "PAUSED" -> "Pausado"
            "BUFFERING" -> "Carregando..."
            "ENDED" -> "Vídeo finalizado"
            "VIDEO_CUED" -> "Vídeo pronto"
            "UNSTARTED" -> "Aguardando reprodução"
            else -> "Player conectado"
        }
    }

    internal fun onQuality(quality: PlayerConstants.PlaybackQuality) {
        qualityLabel = qualityFriendlyLabel(quality.toString())
    }

    internal fun onError(error: PlayerConstants.PlayerError) {
        isPlaying = false
        val raw = error.toString().uppercase(Locale.US)
        errorMessage = when {
            "MISSING_HTTP_REFERER" in raw || "REQUEST_MISSING" in raw ->
                "O YouTube não conseguiu identificar o SONUS (Referer). Atualize/recarregue o player."
            "NOT_PLAYABLE" in raw || "EMBEDDED" in raw ->
                "Este vídeo não permite reprodução incorporada. Escolha outro resultado."
            "NOT_FOUND" in raw ->
                "Este vídeo não está mais disponível."
            "HTML" in raw ->
                "O player HTML5 do YouTube não conseguiu reproduzir este vídeo neste aparelho."
            else ->
                "O YouTube interrompeu a reprodução ($raw). Tente recarregar ou escolha outro resultado."
        }
        stateLabel = "Falha no player"
    }

    private fun qualityFriendlyLabel(rawValue: String): String {
        val raw = rawValue.uppercase(Locale.US)
        return when {
            "HD2160" in raw || "HIGH_RES" in raw -> "4K/Alta"
            "HD1440" in raw -> "1440p"
            "HD1080" in raw -> "1080p"
            "HD720" in raw -> "720p"
            "LARGE" in raw -> "480p"
            "MEDIUM" in raw -> "360p"
            "SMALL" in raw || "TINY" in raw -> "Baixa"
            else -> "Automática"
        }
    }
}

@Composable
internal fun rememberStreamPulseYouTubeController(): StreamPulseYouTubeController =
    remember { StreamPulseYouTubeController() }

private tailrec fun Context.findComponentActivity(): ComponentActivity? = when (this) {
    is ComponentActivity -> this
    is ContextWrapper -> baseContext.findComponentActivity()
    else -> null
}

/**
 * Player baseado na biblioteca android-youtube-player v13, que usa a IFrame Player API
 * oficial e já trata origin/HTTP Referer de aplicativos Android.
 *
 * A UI web interna fica sem controles (controls=0); o StreamPulse fornece Play/Pause
 * e rotação fora da área de vídeo. A qualidade é escolhida automaticamente pelo
 * YouTube — a IFrame API não oferece mais alteração programática de qualidade.
 */
@Composable
internal fun YouTubeEmbedPlayer(
    videoId: String,
    controller: StreamPulseYouTubeController,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val activity = remember(context) { context.findComponentActivity() }
    val playerView = remember(context) {
        YouTubePlayerView(context).apply {
            enableAutomaticInitialization = false
        }
    }

    DisposableEffect(playerView, activity) {
        activity?.lifecycle?.addObserver(playerView)

        val options = IFramePlayerOptions.Builder(context)
            .controls(0)
            .rel(0)
            .fullscreen(0)
            .build()

        val listener = object : AbstractYouTubePlayerListener() {
            override fun onReady(youTubePlayer: YouTubePlayer) {
                controller.attach(youTubePlayer)
            }

            override fun onStateChange(
                youTubePlayer: YouTubePlayer,
                state: PlayerConstants.PlayerState
            ) {
                controller.onState(state)
            }

            override fun onPlaybackQualityChange(
                youTubePlayer: YouTubePlayer,
                playbackQuality: PlayerConstants.PlaybackQuality
            ) {
                controller.onQuality(playbackQuality)
            }

            override fun onError(
                youTubePlayer: YouTubePlayer,
                error: PlayerConstants.PlayerError
            ) {
                controller.onError(error)
            }
        }

        playerView.initialize(listener, true, options)

        onDispose {
            activity?.lifecycle?.removeObserver(playerView)
            controller.detach()
            runCatching { playerView.release() }
        }
    }

    LaunchedEffect(videoId, controller.ready) {
        controller.pendingVideoId = videoId
        if (controller.ready) controller.load(videoId)
    }

    AndroidView(
        modifier = modifier.background(Color.Black),
        factory = { playerView }
    )
}
