package com.sonusstudios.streampulse.data

import android.content.Context
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.MutableData
import com.google.firebase.database.Transaction
import com.google.firebase.database.ValueEventListener
import com.sonusstudios.streampulse.core.DistributorId
import com.sonusstudios.streampulse.core.RoyaltyPayment
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.math.sqrt
import java.util.Locale

/**
 * Aggregate-only financial learning layer.
 *
 * The backend never receives an artist name, UID, payment id, payment amount or raw stream count
 * inside the global aggregate. A local preference prevents normal duplicate submissions from this
 * installation. Only statistical moments and an RPM histogram are shared across users.
 */
class FinancialLearningCloud(context: Context) {
    data class Snapshot(
        val averageRpm: Double,
        val medianRpm: Double,
        val spreadRpm: Double,
        val minRpm: Double,
        val maxRpm: Double,
        val accuracyPercent: Double?,
        val sampleCount: Int
    )

    private val appContext = context.applicationContext
    private val db = FirebaseDatabase.getInstance()
    private val auth = FirebaseAuth.getInstance()
    private val sent = appContext.getSharedPreferences("sonus_financial_learning_v1", Context.MODE_PRIVATE)

    suspend fun read(distributor: DistributorId): Snapshot? {
        if (auth.currentUser == null) return null
        val snap = db.getReference("financialLearningGlobal")
            .child(distributor.name.lowercase())
            .awaitSnapshot()
        return snapshotFrom(snap)
    }

    suspend fun submitAndRead(distributor: DistributorId, payment: RoyaltyPayment): Snapshot? {
        if (auth.currentUser == null) return null
        val rpm = payment.effectiveRpmBrlPerThousand
            ?: payment.cycleStreams.takeIf { it > 0L }?.let { payment.amountBrl / it.toDouble() * 1_000.0 }
        if (rpm == null || !rpm.isFinite() || rpm <= 0.0 || rpm > 250.0) return read(distributor)

        val dedupeKey = "sent_${payment.id}"
        if (!sent.getBoolean(dedupeKey, false)) {
            val estimate = payment.estimatedBrlBeforeCalibration?.takeIf { it > 0.0 }
            val errorPercent = estimate?.let { kotlin.math.abs(payment.amountBrl - it) / payment.amountBrl.coerceAtLeast(.01) * 100.0 }
            val ref = db.getReference("financialLearningGlobal").child(distributor.name.lowercase())
            val committed = ref.runAggregateTransaction(rpm, errorPercent)
            if (committed) sent.edit().putBoolean(dedupeKey, true).apply()
        }
        return read(distributor)
    }

    private fun snapshotFrom(s: DataSnapshot): Snapshot? {
        val count = s.child("sampleCount").getValue(Long::class.java)?.toInt() ?: 0
        if (count <= 0) return null
        val sum = s.child("sumRpm").getValue(Double::class.java) ?: return null
        val sumSq = s.child("sumRpmSq").getValue(Double::class.java) ?: (sum * sum / count)
        val average = (sum / count).coerceAtLeast(0.0)
        val variance = (sumSq / count - average * average).coerceAtLeast(0.0)
        val min = s.child("minRpm").getValue(Double::class.java) ?: average
        val max = s.child("maxRpm").getValue(Double::class.java) ?: average
        val accuracySamples = s.child("accuracySamples").getValue(Long::class.java)?.toInt() ?: 0
        val errorSum = s.child("sumAbsErrorPercent").getValue(Double::class.java) ?: 0.0
        val accuracy = if (accuracySamples > 0) (100.0 - errorSum / accuracySamples).coerceIn(0.0, 100.0) else null
        return Snapshot(average, histogramMedian(s.child("rpmHistogram"), count), sqrt(variance), min, max, accuracy, count)
    }

    private fun histogramMedian(hist: DataSnapshot, total: Int): Double {
        if (total <= 0) return 0.0
        val target = (total + 1) / 2
        var seen = 0L
        val buckets = hist.children.mapNotNull { child ->
            val index = child.key?.removePrefix("b")?.toIntOrNull() ?: return@mapNotNull null
            index to (child.getValue(Long::class.java) ?: 0L)
        }.sortedBy { it.first }
        for ((index, count) in buckets) {
            seen += count
            if (seen >= target) return index * BUCKET_SIZE + BUCKET_SIZE / 2.0
        }
        return buckets.lastOrNull()?.first?.let { it * BUCKET_SIZE + BUCKET_SIZE / 2.0 } ?: 0.0
    }

    private suspend fun com.google.firebase.database.DatabaseReference.runAggregateTransaction(
        rpm: Double,
        errorPercent: Double?
    ): Boolean = suspendCancellableCoroutine { cont ->
        runTransaction(object : Transaction.Handler {
            override fun doTransaction(current: MutableData): Transaction.Result {
                val oldCount = current.child("sampleCount").getValue(Long::class.java) ?: 0L
                val oldSum = current.child("sumRpm").getValue(Double::class.java) ?: 0.0
                val oldSq = current.child("sumRpmSq").getValue(Double::class.java) ?: 0.0
                val oldMin = current.child("minRpm").getValue(Double::class.java)
                val oldMax = current.child("maxRpm").getValue(Double::class.java)
                current.child("sampleCount").value = oldCount + 1L
                current.child("sumRpm").value = oldSum + rpm
                current.child("sumRpmSq").value = oldSq + rpm * rpm
                current.child("minRpm").value = oldMin?.let { kotlin.math.min(it, rpm) } ?: rpm
                current.child("maxRpm").value = oldMax?.let { kotlin.math.max(it, rpm) } ?: rpm
                if (errorPercent != null && errorPercent.isFinite()) {
                    val oldAccuracyCount = current.child("accuracySamples").getValue(Long::class.java) ?: 0L
                    val oldError = current.child("sumAbsErrorPercent").getValue(Double::class.java) ?: 0.0
                    current.child("accuracySamples").value = oldAccuracyCount + 1L
                    current.child("sumAbsErrorPercent").value = oldError + errorPercent.coerceIn(0.0, 500.0)
                }
                val bucket = (rpm / BUCKET_SIZE).toInt().coerceIn(0, MAX_BUCKET)
                val bucketNode = current.child("rpmHistogram").child(String.format(Locale.US, "b%03d", bucket))
                bucketNode.value = (bucketNode.getValue(Long::class.java) ?: 0L) + 1L
                current.child("updatedAt").value = System.currentTimeMillis()
                return Transaction.success(current)
            }

            override fun onComplete(error: DatabaseError?, committed: Boolean, currentData: DataSnapshot?) {
                if (!cont.isActive) return
                if (error != null) cont.resumeWithException(error.toException()) else cont.resume(committed)
            }
        })
    }

    private suspend fun com.google.firebase.database.Query.awaitSnapshot(): DataSnapshot =
        suspendCancellableCoroutine { cont ->
            addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) { if (cont.isActive) cont.resume(snapshot) }
                override fun onCancelled(error: DatabaseError) { if (cont.isActive) cont.resumeWithException(error.toException()) }
            })
        }

    companion object {
        private const val BUCKET_SIZE = 0.50
        private const val MAX_BUCKET = 500
    }
}
