package com.sonusstudios.streampulse.tools

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

internal data class SonusOfflineTrack(
    val fileId: Long,
    val sourceKey: String,
    val title: String,
    val artist: String,
    val album: String,
    val genre: String,
    val durationMs: Long,
    val size: Long,
    val file: File
) {
    fun queueItem(): PulsePlayerQueueItem = PulsePlayerQueueItem(
        uri = Uri.fromFile(file).toString(), title = title, artist = artist,
        album = album, genre = genre, durationMs = durationMs, source = "SONUS Stream • Offline"
    )
}

/**
 * Downloads SONUS Stream tracks to the app cache (private, not exported to Files/MediaStore).
 * Android's Clear cache, Clear data, and uninstall remove these files automatically.
 */
internal object SonusOfflineDownloadManager {
    private const val PREFS = "sonus_stream_offline_v1"
    private const val KEY_ITEMS = "items"
    private const val MAX_TRACK_BYTES = 256L * 1024L * 1024L

    private fun root(context: Context): File = File(context.cacheDir, "sonus_stream_downloads").apply { mkdirs() }
    private fun key(sourceKey: String, fileId: Long) = "${sourceKey}_${fileId}"
    private fun target(context: Context, sourceKey: String, fileId: Long) = File(root(context), "${key(sourceKey, fileId)}.mp3")

    fun isDownloaded(context: Context, ref: SonusOnlineRef): Boolean =
        target(context, ref.sourceKey, ref.fileId).let { it.isFile && it.length() > 0L }

    fun fileFor(context: Context, ref: SonusOnlineRef): File? =
        target(context, ref.sourceKey, ref.fileId).takeIf { it.isFile && it.length() > 0L }

    fun remove(context: Context, ref: SonusOnlineRef): Boolean {
        val removed = target(context, ref.sourceKey, ref.fileId).let { !it.exists() || it.delete() }
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val items = readItems(prefs.getString(KEY_ITEMS, "[]").orEmpty())
            .filterNot { it.optLong("fileId") == ref.fileId && it.optString("sourceKey") == ref.sourceKey }
        prefs.edit().putString(KEY_ITEMS, JSONArray(items).toString()).apply()
        return removed
    }

    fun list(context: Context): List<SonusOfflineTrack> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val array = runCatching { JSONArray(prefs.getString(KEY_ITEMS, "[]") ?: "[]") }.getOrDefault(JSONArray())
        val valid = mutableListOf<SonusOfflineTrack>()
        val clean = JSONArray()
        for (i in 0 until array.length()) {
            val obj = array.optJSONObject(i) ?: continue
            val id = obj.optLong("fileId")
            val source = obj.optString("sourceKey", "primary")
            if (id <= 0L || source !in setOf("primary", "secondary", "tertiary")) continue
            val file = target(context, source, id)
            if (!file.isFile || file.length() <= 0L) continue
            clean.put(obj)
            valid += SonusOfflineTrack(
                fileId = id, sourceKey = source, title = obj.optString("title").ifBlank { "Música" },
                artist = obj.optString("artist"), album = obj.optString("album"), genre = obj.optString("genre"),
                durationMs = obj.optLong("durationMs"), size = file.length(), file = file
            )
        }
        if (clean.length() != array.length()) prefs.edit().putString(KEY_ITEMS, clean.toString()).apply()
        return valid.sortedBy { it.title.lowercase() }
    }

    suspend fun download(
        context: Context,
        repository: SonusOnlineMusicRepository,
        track: SonusOnlineTrack,
        onProgress: (downloaded: Long, total: Long) -> Unit = { _, _ -> }
    ): File = withContext(Dispatchers.IO) {
        val sourceKey = repository.sourceKeyForTrack(track)
        val existing = target(context, sourceKey, track.fileId)
        if (existing.isFile && existing.length() > 0L) return@withContext existing
        val url = repository.resolvePlaybackUrl(track.fileId, sourceKey)
        val part = File(root(context), "${key(sourceKey, track.fileId)}.part")
        part.delete()
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 20_000
            readTimeout = 45_000
            instanceFollowRedirects = true
            useCaches = false
            setRequestProperty("Accept-Encoding", "identity")
            setRequestProperty("User-Agent", "SONUS/${com.sonusstudios.streampulse.BuildConfig.VERSION_NAME}")
        }
        val coroutineContext = currentCoroutineContext()
        try {
            val code = connection.responseCode
            if (code !in 200..299) throw IOException("Falha no download (HTTP $code)")
            val headerSize = connection.contentLengthLong.takeIf { it > 0L } ?: track.size
            if (headerSize > MAX_TRACK_BYTES) throw IOException("A faixa excede o limite de 256 MB")
            var count = 0L
            connection.inputStream.buffered().use { input ->
                part.outputStream().buffered().use { output ->
                    val buffer = ByteArray(64 * 1024)
                    while (true) {
                        coroutineContext.ensureActive()
                        val read = input.read(buffer)
                        if (read < 0) break
                        count += read
                        if (count > MAX_TRACK_BYTES) throw IOException("A faixa excede o limite de 256 MB")
                        output.write(buffer, 0, read)
                        onProgress(count, headerSize)
                    }
                }
            }
            if (count <= 0L) throw IOException("O servidor não enviou dados de áudio")
            if (track.size > 0L && count < track.size * 0.90) throw IOException("Download incompleto. Tente novamente.")
            if (!part.renameTo(existing)) {
                part.copyTo(existing, overwrite = true)
                part.delete()
            }
            val entry = JSONObject().apply {
                put("fileId", track.fileId); put("sourceKey", sourceKey); put("title", track.displayTitle)
                put("artist", track.artist); put("album", track.album); put("genre", track.genre)
                put("durationMs", track.durationMs); put("size", existing.length())
            }
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val items: MutableList<JSONObject> = mutableListOf<JSONObject>().apply {
                addAll(readItems(prefs.getString(KEY_ITEMS, "[]").orEmpty()).filterNot {
                    it.optLong("fileId") == track.fileId && it.optString("sourceKey") == sourceKey
                })
                add(entry)
            }
            prefs.edit().putString(KEY_ITEMS, JSONArray(items).toString()).apply()
            onProgress(count, count)
            existing
        } catch (t: Throwable) {
            part.delete()
            throw t
        } finally {
            connection.disconnect()
        }
    }

    private fun readItems(raw: String): MutableList<JSONObject> {
        val array = runCatching { JSONArray(raw) }.getOrDefault(JSONArray())
        return (0 until array.length()).mapNotNull { array.optJSONObject(it) }.toMutableList()
    }
}
