package com.sonusstudios.streampulse.tools

import com.sonusstudios.streampulse.core.SonusAutoCreateDocument
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint
import android.graphics.Typeface
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.abs
import kotlin.math.max

@Composable
internal fun UtilityHeader(title:String,onBack:()->Unit){
    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
        IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,null)}
        Spacer(Modifier.width(4.dp));Text(title,fontWeight=FontWeight.Black,style=MaterialTheme.typography.headlineSmall)
    }
}

internal enum class QuickAudioKind(val title:String) {
    NORMALIZE("Normalizador de Volume"), FADE("Fade In / Fade Out"), SILENCE("Silêncio Inteligente"), LOOP("Criador de Loop")
}

@Composable
internal fun QuickAudioProcessorTool(kind: QuickAudioKind, onBack:()->Unit, onTrack:(String,Boolean?,Long?)->Unit, premiumUseAvailable:Boolean=true) {
    val context= LocalContext.current; val scope= rememberCoroutineScope()
    var input by remember{ mutableStateOf<Uri?>(null) }; var msg by remember{ mutableStateOf<String?>(null) }; var busy by remember{ mutableStateOf(false) }
    var fade by remember{ mutableFloatStateOf(3f) }; var loopStart by remember{ mutableFloatStateOf(0f) }; var loopDuration by remember{ mutableFloatStateOf(15f) }
    val pick= rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){u-> if(u!=null){input=u;msg=null}}
    val save= rememberLauncherForActivityResult(SonusAutoCreateDocument("audio/wav")){out->
        val src=input
        if(out!=null && src!=null){scope.launch{busy=true;msg="Processando…";val ok=withContext(Dispatchers.IO){processAudioQuick(context,src,out,kind,fade,loopStart,loopDuration)};busy=false;msg=if(ok)"Arquivo salvo com sucesso." else "Não foi possível concluir o processamento.";onTrack(kind.title,ok,null)}}
    }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp),contentPadding=PaddingValues(bottom=28.dp)){
        item{UtilityHeader(kind.title,onBack)}
        item{Text(when(kind){QuickAudioKind.NORMALIZE->"Ajusta loudness e pico com processamento local.";QuickAudioKind.FADE->"Cria entrada e saída suaves sem alterar o original.";QuickAudioKind.SILENCE->"Remove silêncio excessivo no começo e no final.";QuickAudioKind.LOOP->"Recorta um trecho exato para criar um loop."})}
        item{Button({pick.launch(arrayOf("audio/*"))},Modifier.fillMaxWidth()){Icon(Icons.Default.AudioFile,null);Spacer(Modifier.width(7.dp));Text(if(input==null)"Selecionar áudio" else "Trocar áudio")}}
        if(input!=null){
            if(kind==QuickAudioKind.FADE)item{Column{Text("Duração do fade: ${fade.toInt()} s",fontWeight=FontWeight.Bold);Slider(fade,{fade=it},valueRange=1f..10f,steps=8)}}
            if(kind==QuickAudioKind.LOOP)item{Column(verticalArrangement=Arrangement.spacedBy(6.dp)){Text("Início: ${loopStart.toInt()} s");Slider(loopStart,{loopStart=it},valueRange=0f..180f);Text("Duração: ${loopDuration.toInt()} s");Slider(loopDuration,{loopDuration=it},valueRange=3f..60f)}}
            item{Button({save.launch("${kind.name.lowercase()}_sonus.wav")},Modifier.fillMaxWidth(),enabled=!busy&&premiumUseAvailable){Text(if(busy)"Processando…" else if(!premiumUseAvailable)"Sem Moedas SONUS" else "Processar e salvar")}}
        }
        msg?.let{item{Text(it,fontWeight=FontWeight.Bold)}}
    }
}

private fun q(s:String)="'"+s.replace("'","'\\''")+"'"
private fun processAudioQuick(context:Context,input:Uri,output:Uri,kind:QuickAudioKind,fade:Float,start:Float,duration:Float):Boolean=runCatching{
    val dir=File(context.cacheDir,"sonus_quick_audio").apply{mkdirs()}; val src=File(dir,"src_${System.nanoTime()}.bin"); val dst=File(dir,"out_${System.nanoTime()}.wav")
    context.contentResolver.openInputStream(input)?.use{i->src.outputStream().use{i.copyTo(it)}}?:error("open")
    val filter=when(kind){
        QuickAudioKind.NORMALIZE->"loudnorm=I=-14:LRA=9:TP=-1.0"
        QuickAudioKind.FADE->"afade=t=in:st=0:d=${fade.coerceIn(1f,10f)},areverse,afade=t=in:st=0:d=${fade.coerceIn(1f,10f)},areverse"
        QuickAudioKind.SILENCE->"silenceremove=start_periods=1:start_duration=0.12:start_threshold=-48dB:stop_periods=-1:stop_duration=0.35:stop_threshold=-48dB"
        QuickAudioKind.LOOP->"atrim=start=${start.coerceAtLeast(0f)}:duration=${duration.coerceIn(3f,60f)},asetpts=N/SR/TB"
    }
    val s=FFmpegKit.execute("-y -i ${q(src.absolutePath)} -vn -af ${q(filter)} -c:a pcm_s16le ${q(dst.absolutePath)}")
    if(!ReturnCode.isSuccess(s.returnCode)) error("ffmpeg")
    context.contentResolver.openOutputStream(output)?.use{o->dst.inputStream().use{it.copyTo(o)}}?:error("save")
    src.delete();dst.delete();true
}.getOrDefault(false)

@Composable
internal fun ClippingDetectorTool(onBack:()->Unit,onTrack:(String,Boolean?,Long?)->Unit){
    val context=LocalContext.current;val scope=rememberCoroutineScope();var result by remember{mutableStateOf<AudioDeepAnalysis?>(null)};var busy by remember{mutableStateOf(false)};var msg by remember{mutableStateOf<String?>(null)}
    val pick=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){u->if(u!=null){scope.launch{busy=true;result=withContext(Dispatchers.IO){runCatching{AudioToolEngine.analyze(context,u)}.getOrNull()};busy=false;msg=if(result==null)"Falha na análise." else null;onTrack("Detector de Clipping",result!=null,null)}}}
    LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{UtilityHeader("Detector de Clipping",onBack)};item{Button({pick.launch(arrayOf("audio/*"))},Modifier.fillMaxWidth()){Text(if(busy)"Analisando…" else "Selecionar e analisar áudio")}};result?.let{r->item{Card{Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){Text("Resultado",fontWeight=FontWeight.Black);Text("Pico: ${r.peakDbfs?.let{String.format("%.2f dBFS",it)}?:"—"}");Text("Clipping: ${r.clippingPercent?.let{String.format("%.3f%%",it)}?:"—"}");Text("Loudness: ${r.loudnessLufs?.let{String.format("%.1f LUFS",it)}?:"—"}");r.qualityNotes.forEach{Text("• $it")}}}}};msg?.let{item{Text(it)}}}
}

@Composable
internal fun ABCompareTool(onBack:()->Unit){
    val context=LocalContext.current;var a by remember{mutableStateOf<Uri?>(null)};var b by remember{mutableStateOf<Uri?>(null)};var playing by remember{mutableStateOf<String?>(null)};var player by remember{mutableStateOf<MediaPlayer?>(null)}
    fun play(uri:Uri?,label:String){if(uri==null)return;player?.release();player=MediaPlayer().apply{setDataSource(context,uri);setOnPreparedListener{it.start();playing=label};setOnCompletionListener{playing=null};prepareAsync()}}
    DisposableEffect(Unit){onDispose{player?.release()}}
    val pickA=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){a=it};val pickB=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){b=it}
    LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{UtilityHeader("Comparador A/B",onBack)};item{Text("Compare duas versões alternando instantaneamente entre A e B.")};item{Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button({pickA.launch(arrayOf("audio/*"))},Modifier.weight(1f)){Text("Escolher A")};Button({pickB.launch(arrayOf("audio/*"))},Modifier.weight(1f)){Text("Escolher B")}}};item{Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){FilledTonalButton({play(a,"A")},Modifier.weight(1f),enabled=a!=null){Text(if(playing=="A")"▶ A" else "Ouvir A")};FilledTonalButton({play(b,"B")},Modifier.weight(1f),enabled=b!=null){Text(if(playing=="B")"▶ B" else "Ouvir B")}}}}
}

internal enum class ImageExtraKind(val title:String){COMPRESS("Compressor de Imagem"),PALETTE("Paleta de Cores"),WATERMARK("Marca d'água"),BATCH("Imagens em Lote"),PROMO("Kit de Divulgação")}

@Composable
internal fun ImageExtraTool(kind:ImageExtraKind,onBack:()->Unit,onTrack:(String,Boolean?,Long?)->Unit){
    val context=LocalContext.current;val scope=rememberCoroutineScope();var uri by remember{mutableStateOf<Uri?>(null)};var uris by remember{mutableStateOf<List<Uri>>(emptyList())};var bmp by remember{mutableStateOf<Bitmap?>(null)};var msg by remember{mutableStateOf<String?>(null)};var quality by remember{mutableFloatStateOf(82f)};var watermark by remember{mutableStateOf("SONUS")};var wmStyle by remember{mutableStateOf("Padrão")};var wmSize by remember{mutableStateOf("Médio")};var wmAlpha by remember{mutableFloatStateOf(70f)};var wmPng by remember{mutableStateOf<Bitmap?>(null)}
    val pick=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){u->if(u!=null){uri=u;bmp=loadBitmapSafe(context,u);msg=null}}
    val pickMany=rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()){list->uris=list;msg="${list.size} imagem(ns) selecionada(s)."}
    val pickWatermark=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){u->wmPng=u?.let{loadBitmapSafe(context,it)};msg=if(wmPng!=null)"PNG de marca d'água carregado." else "Não foi possível carregar o PNG."}
    val save=rememberLauncherForActivityResult(SonusAutoCreateDocument("image/png")){out->val source=bmp;if(out!=null&&source!=null){scope.launch{val ok=withContext(Dispatchers.IO){saveImageExtra(context,source,out,kind,quality.toInt(),watermark,wmStyle,wmSize,wmAlpha.toInt(),wmPng)};msg=if(ok)"Imagem salva." else "Falha ao salvar.";onTrack(kind.title,ok,null)}}}
    LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp),contentPadding=PaddingValues(bottom=28.dp)){
        item{UtilityHeader(kind.title,onBack)}
        if(kind==ImageExtraKind.BATCH){item{Button({pickMany.launch(arrayOf("image/*"))},Modifier.fillMaxWidth()){Text("Selecionar várias imagens")}};if(uris.isNotEmpty())item{Button({scope.launch{val n=withContext(Dispatchers.IO){batchCompressToGallery(context,uris,quality.toInt())};msg="$n arquivo(s) exportado(s) para Imagens/Sonus."}},Modifier.fillMaxWidth()){Text("Comprimir lote")}}}
        else{item{Button({pick.launch(arrayOf("image/*"))},Modifier.fillMaxWidth()){Text("Selecionar imagem")}}}
        bmp?.let{image->item{Image(image.asImageBitmap(),null,Modifier.fillMaxWidth().heightIn(max=280.dp),contentScale=ContentScale.Fit)}}
        if(kind==ImageExtraKind.COMPRESS)item{Column{Text("Qualidade: ${quality.toInt()}%",fontWeight=FontWeight.Bold);Slider(quality,{quality=it},valueRange=45f..100f)}}
        if(kind==ImageExtraKind.WATERMARK){
            item{Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
                OutlinedTextField(watermark,{watermark=it.take(40)},label={Text("Texto da marca d'água")},modifier=Modifier.fillMaxWidth())
                Text("Fonte",fontWeight=FontWeight.Bold);Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){listOf("Padrão","Serif","Mono").forEach{x->FilterChip(wmStyle==x,{wmStyle=x},{Text(x)})}}
                Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){listOf("Condensada","Elegante","Assinatura").forEach{x->FilterChip(wmStyle==x,{wmStyle=x},{Text(x)})}}
                Text("Tamanho",fontWeight=FontWeight.Bold);Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){listOf("Pequeno","Médio","Grande").forEach{x->FilterChip(wmSize==x,{wmSize=x},{Text(x)})}}
                Text("Transparência: ${wmAlpha.toInt()}%");Slider(wmAlpha,{wmAlpha=it},valueRange=20f..100f)
                OutlinedButton({pickWatermark.launch(arrayOf("image/png"))},Modifier.fillMaxWidth()){Text(if(wmPng==null)"Adicionar PNG transparente" else "Trocar PNG da marca d'água")}
                if(wmPng!=null)Text("PNG será aplicado no canto inferior direito no tamanho $wmSize.",style=MaterialTheme.typography.bodySmall)
            }}
        }
        if(kind==ImageExtraKind.PALETTE && bmp!=null)item{PaletteView(bmp!!)}
        if(bmp!=null && kind !in listOf(ImageExtraKind.PALETTE,ImageExtraKind.BATCH))item{Button({save.launch("${kind.name.lowercase()}_sonus.png")},Modifier.fillMaxWidth()){Text("Processar e salvar")}}
        msg?.let{item{Text(it,fontWeight=FontWeight.Bold)}}
    }
}

private fun loadBitmapSafe(context:Context,uri:Uri):Bitmap?=runCatching{context.contentResolver.openInputStream(uri)?.use{BitmapFactory.decodeStream(it)}}.getOrNull()
private fun saveImageExtra(context:Context,src:Bitmap,out:Uri,kind:ImageExtraKind,quality:Int,text:String,style:String,size:String,alpha:Int,logo:Bitmap?):Boolean=runCatching{
    val result=when(kind){
        ImageExtraKind.COMPRESS->src
        ImageExtraKind.WATERMARK->{
            val b=src.copy(Bitmap.Config.ARGB_8888,true);val c=Canvas(b);val scale=when(size){"Pequeno"->0.65f;"Grande"->1.45f;else->1f};val a=(255*(alpha/100f)).toInt().coerceIn(20,255)
            if(logo!=null){val target=(src.width*0.18f*scale).toInt().coerceAtLeast(24);val h=(logo.height*(target.toFloat()/logo.width)).toInt().coerceAtLeast(12);val l=Bitmap.createScaledBitmap(logo,target,h,true);val p=Paint(Paint.ANTI_ALIAS_FLAG).apply{this.alpha=a};c.drawBitmap(l,(src.width-target-24).toFloat(),(src.height-h-24).toFloat(),p)}
            else{val family=when(style){"Serif","Elegante"->Typeface.SERIF;"Mono"->Typeface.MONOSPACE;"Condensada"->Typeface.create("sans-serif-condensed",Typeface.NORMAL);"Assinatura"->Typeface.create("cursive",Typeface.ITALIC);else->Typeface.DEFAULT};val p=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=AndroidColor.argb(a,255,255,255);textSize=max(28f,src.width/20f)*scale;typeface=family;setShadowLayer(3f,1f,1f,AndroidColor.BLACK)};c.drawText(text.ifBlank{"SONUS"},24f,src.height-36f,p)};b}
        else->src
    };context.contentResolver.openOutputStream(out)?.use{o->result.compress(if(kind==ImageExtraKind.COMPRESS)Bitmap.CompressFormat.JPEG else Bitmap.CompressFormat.PNG,quality,o)}?:false
}.getOrDefault(false)

private fun removeEdgeBackground(src:Bitmap,tolerance:Int):Bitmap{
    val b=src.copy(Bitmap.Config.ARGB_8888,true);val corners=listOf(src.getPixel(0,0),src.getPixel(src.width-1,0),src.getPixel(0,src.height-1),src.getPixel(src.width-1,src.height-1));val br=corners.sumOf{AndroidColor.red(it)}/4;val bg=corners.sumOf{AndroidColor.green(it)}/4;val bb=corners.sumOf{AndroidColor.blue(it)}/4
    val threshold=tolerance*3
    for(y in 0 until b.height)for(x in 0 until b.width){val p=b.getPixel(x,y);val d=abs(AndroidColor.red(p)-br)+abs(AndroidColor.green(p)-bg)+abs(AndroidColor.blue(p)-bb);if(d<threshold)b.setPixel(x,y,AndroidColor.TRANSPARENT)}
    return b
}

@Composable private fun PaletteView(bmp:Bitmap){val colors=remember(bmp){dominantColors(bmp)};Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Text("Cores principais",fontWeight=FontWeight.Black);colors.forEach{c->val hex=String.format("#%06X",0xFFFFFF and c);Surface(color=Color(c),shape=MaterialTheme.shapes.medium){Text(hex,Modifier.fillMaxWidth().padding(12.dp),color=if(AndroidColor.luminance(c)<0.45)Color.White else Color.Black,fontWeight=FontWeight.Bold)}}}}
private fun dominantColors(bmp:Bitmap):List<Int>{val buckets=linkedMapOf<Int,Int>();val step=max(1,max(bmp.width,bmp.height)/120);for(y in 0 until bmp.height step step)for(x in 0 until bmp.width step step){val p=bmp.getPixel(x,y);val r=AndroidColor.red(p)/32*32;val g=AndroidColor.green(p)/32*32;val b=AndroidColor.blue(p)/32*32;val k=AndroidColor.rgb(r,g,b);buckets[k]=(buckets[k]?:0)+1};return buckets.entries.sortedByDescending{it.value}.take(6).map{it.key}}

private fun saveBitmapGallery(context:Context,bmp:Bitmap,name:String,format:Bitmap.CompressFormat=Bitmap.CompressFormat.JPEG,quality:Int=90):Boolean=runCatching{val values=ContentValues().apply{put(MediaStore.Images.Media.DISPLAY_NAME,name);put(MediaStore.Images.Media.MIME_TYPE,if(format==Bitmap.CompressFormat.PNG)"image/png" else "image/jpeg");if(Build.VERSION.SDK_INT>=29)put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/Sonus")};val uri=context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values)?:error("insert");context.contentResolver.openOutputStream(uri)?.use{bmp.compress(format,quality,it)}?:error("out");true}.getOrDefault(false)
private fun batchCompressToGallery(context:Context,uris:List<Uri>,quality:Int):Int=uris.count{u->loadBitmapSafe(context,u)?.let{saveBitmapGallery(context,it,"sonus_${System.nanoTime()}.jpg",Bitmap.CompressFormat.JPEG,quality)}==true}
private fun cropCenter(src:Bitmap,w:Int,h:Int):Bitmap{val target=w.toFloat()/h;val ratio=src.width.toFloat()/src.height;val cropW=if(ratio>target)(src.height*target).toInt() else src.width;val cropH=if(ratio>target)src.height else (src.width/target).toInt();val x=(src.width-cropW)/2;val y=(src.height-cropH)/2;return Bitmap.createScaledBitmap(Bitmap.createBitmap(src,x,y,cropW,cropH),w,h,true)}
private fun exportPromoKit(context:Context,bmp:Bitmap):Int{val specs=listOf(1200 to 1200,1920 to 1080,1080 to 1920);return specs.count{(w,h)->saveBitmapGallery(context,cropCenter(bmp,w,h),"sonus_${w}x${h}_${System.nanoTime()}.jpg")}}
