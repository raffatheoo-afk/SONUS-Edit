package com.sonusstudios.streampulse.tools

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import com.sonusstudios.streampulse.audio.AudioConversionEngine
import com.sonusstudios.streampulse.audio.AudioSourceInfo
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import java.util.concurrent.CountDownLatch
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt


data class AudioDeepAnalysis(
    val source: AudioSourceInfo,
    val codec: String? = null,
    val peakDbfs: Double? = null,
    val rmsDbfs: Double? = null,
    val clippingPercent: Double? = null,
    val loudnessLufs: Double? = null,
    val truePeakDbtp: Double? = null,
    val crestFactorDb: Double? = null,
    val waveform: List<Float> = emptyList(),
    val qualityNotes: List<String> = emptyList()
)

data class SuggestedSegment(val startSeconds: Double, val durationSeconds: Double, val confidence: Int)

data class AudioMetadata(
    val title: String = "",
    val artist: String = "",
    val albumArtist: String = "",
    val album: String = "",
    val composer: String = "",
    val author: String = "",
    val genre: String = "",
    val year: String = "",
    val track: String = "",
    val trackTotal: String = "",
    val disc: String = "",
    val discTotal: String = "",
    val bpm: String = "",
    val isrc: String = "",
    val copyright: String = "",
    val comment: String = "",
    val lyrics: String = ""
)

enum class ArtworkWriteMode { KEEP, REPLACE, REMOVE }

enum class SquareMode { CROP, FIT_BACKGROUND, CENTER, STRETCH }

data class ImageInfo(val width: Int, val height: Int, val mime: String?, val sizeBytes: Long?)

object AudioToolEngine {
    private fun quote(value: String): String = "'" + value.replace("'", "'\\''") + "'"

    private fun cacheInput(context: Context, uri: Uri, prefix: String): File {
        val dir = File(context.cacheDir, "tool_suite").apply { mkdirs() }
        val name = queryName(context, uri)
        val ext = name.substringAfterLast('.', "bin").take(8)
        val file = File(dir, "${prefix}_${System.nanoTime()}.$ext")
        context.contentResolver.openInputStream(uri)?.use { input -> file.outputStream().use { input.copyTo(it) } }
            ?: error("Não foi possível abrir o arquivo.")
        return file
    }

    private fun queryName(context: Context, uri: Uri): String {
        var name = "arquivo"
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getColumnIndex(OpenableColumns.DISPLAY_NAME).takeIf { it >= 0 }?.let { name = c.getString(it) ?: name }
        }
        return name
    }

    private fun execute(command: String, onProgress: (Float) -> Unit = {}): Result<Unit> = runCatching {
        val latch = CountDownLatch(1)
        var success = false
        var message = ""
        FFmpegKit.executeAsync(command, { session ->
            success = ReturnCode.isSuccess(session.returnCode)
            message = session.allLogsAsString?.takeLast(600).orEmpty()
            latch.countDown()
        }, null, { stats ->
            // Sem duração conhecida aqui: animação de atividade limitada a 95%.
            onProgress((stats.time / 60_000.0).coerceIn(0.03, 0.95).toFloat())
        })
        latch.await()
        if (!success) error(message.ifBlank { "O processamento não foi concluído." })
    }

    fun analyze(context: Context, uri: Uri): AudioDeepAnalysis {
        val source = AudioConversionEngine.inspect(context, uri)
        val tempIn = cacheInput(context, uri, "analyze_in")
        val raw = File(tempIn.parentFile, "pcm_${System.nanoTime()}.raw")
        try {
            execute("-y -i ${quote(tempIn.absolutePath)} -vn -ac 1 -ar 8000 -f s16le ${quote(raw.absolutePath)}").getOrThrow()
            val bytes = raw.readBytes()
            if (bytes.size < 2) return AudioDeepAnalysis(source = source, qualityNotes = listOf("Não foi possível medir a forma de onda."))
            val shorts = ShortArray(bytes.size / 2)
            ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(shorts)
            var peak = 0
            var sumSq = 0.0
            var clipped = 0L
            val bins = 220
            val wave = MutableList(bins) { 0f }
            shorts.forEachIndexed { i, sample ->
                val a = abs(sample.toInt())
                peak = max(peak, a)
                sumSq += sample.toDouble() * sample.toDouble()
                if (a >= 32700) clipped++
                val bin = (i.toLong() * bins / shorts.size.coerceAtLeast(1)).toInt().coerceIn(0, bins - 1)
                wave[bin] = max(wave[bin], a / 32768f)
            }
            val rms = sqrt(sumSq / shorts.size.coerceAtLeast(1))
            fun db(value: Double): Double = if (value <= 0.0) -120.0 else 20.0 * kotlin.math.log10(value / 32768.0)
            val clipping = clipped * 100.0 / shorts.size.coerceAtLeast(1)
            val rmsDb = db(rms)
            val peakDb = db(peak.toDouble())
            val loudnessLog = runCatching {
                val session = FFmpegKit.execute("-hide_banner -i ${quote(tempIn.absolutePath)} -af loudnorm=I=-16:LRA=11:TP=-1.0:print_format=json -f null -")
                session.allLogsAsString.orEmpty()
            }.getOrDefault("")
            fun jsonMetric(key: String): Double? = Regex("""\"$key\"\s*:\s*\"?(-?[0-9.]+|[-+]?inf)\"?""")
                .find(loudnessLog)?.groupValues?.getOrNull(1)?.toDoubleOrNull()
            val lufs = jsonMetric("input_i")
            val truePeak = jsonMetric("input_tp")
            val crest = peakDb - rmsDb
            val notes = buildList {
                if (clipping > .05) add("Possível clipping detectado em ${String.format(Locale.US, "%.2f", clipping)}% das amostras.")
                else add("Sem clipping relevante detectado na amostra analisada.")
                if (rmsDb < -30) add("Nível médio relativamente baixo; avalie normalização antes da distribuição.")
                if (lufs != null && lufs > -8) add("Loudness muito alto; verifique se a dinâmica foi excessivamente comprimida.")
                if (truePeak != null && truePeak > -0.5) add("True peak muito próximo de 0 dBTP; codecs com perdas podem criar novos picos.")
                if ((source.sampleRateHz ?: 44100) < 44100) add("Sample rate abaixo de 44,1 kHz.")
                if ((source.channels ?: 2) == 1) add("Arquivo mono.") else add("Arquivo estéreo/multicanal detectado.")
            }
            val retriever = MediaMetadataRetriever()
            val codec = runCatching {
                retriever.setDataSource(tempIn.absolutePath)
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_MIMETYPE)
            }.getOrNull()
            runCatching { retriever.release() }
            return AudioDeepAnalysis(source, codec, peakDb, rmsDb, clipping, lufs, truePeak, crest, wave, notes)
        } finally {
            tempIn.delete(); raw.delete()
        }
    }

    /**
     * Heurística local sem IA: energia, densidade de transientes e repetição aproximada.
     * Retorna o trecho mais "forte" para preview/corte automático, não afirma que é refrão.
     */
    fun suggestSegment(context: Context, uri: Uri, targetSeconds: Int, variant: Int = 0): SuggestedSegment {
        val info = AudioConversionEngine.inspect(context, uri)
        val duration = (info.durationMs ?: 0L) / 1000.0
        if (duration <= targetSeconds) return SuggestedSegment(0.0, min(duration, targetSeconds.toDouble()), 100)
        val tempIn = cacheInput(context, uri, "segment_in")
        val raw = File(tempIn.parentFile, "segment_${System.nanoTime()}.raw")
        try {
            execute("-y -i ${quote(tempIn.absolutePath)} -vn -ac 1 -ar 4000 -f s16le ${quote(raw.absolutePath)}").getOrThrow()
            val bytes = raw.readBytes()
            val shorts = ShortArray(bytes.size / 2)
            ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(shorts)
            val sampleRate = 4000
            val frameSamples = sampleRate / 2 // 0,5 s
            val frames = max(1, shorts.size / frameSamples)
            val energy = DoubleArray(frames)
            val transient = DoubleArray(frames)
            for (f in 0 until frames) {
                val start = f * frameSamples
                val end = min(shorts.size, start + frameSamples)
                var sum = 0.0
                var diff = 0.0
                var prev = 0
                for (i in start until end) {
                    val v = shorts[i].toInt()
                    sum += v.toDouble() * v
                    if (i > start) diff += abs(v - prev)
                    prev = v
                }
                val count = max(1, end - start)
                energy[f] = sqrt(sum / count) / 32768.0
                transient[f] = diff / count / 65536.0
            }
            val windowFrames = max(1, targetSeconds * 2)
            val maxStart = max(0, frames - windowFrames)
            val candidates = mutableListOf<Pair<Int, Double>>()
            for (start in 0..maxStart) {
                val end = min(frames, start + windowFrames)
                var e = 0.0; var t = 0.0; var variation = 0.0
                for (i in start until end) {
                    e += energy[i]; t += transient[i]
                    if (i > start) variation += abs(energy[i] - energy[i - 1])
                }
                val n = max(1, end - start)
                e /= n; t /= n; variation /= n
                val centerSec = (start + n / 2.0) * .5
                // Favorece regiões centrais/tardias, onde refrões/drops costumam aparecer, sem assumir estrutura fixa.
                val position = when {
                    centerSec < duration * .12 -> .70
                    centerSec > duration * .92 -> .75
                    centerSec in duration * .28..duration * .82 -> 1.10
                    else -> 1.0
                }
                val score = (e * .62 + t * .23 + variation * .15) * position
                candidates += start to score
            }
            // Mantém alternativas suficientemente afastadas para o botão “Tentar outro trecho”.
            val ranked = candidates.sortedByDescending { it.second }
            val separated = mutableListOf<Pair<Int, Double>>()
            val minimumDistanceFrames = max(2, windowFrames / 2)
            for (candidate in ranked) {
                if (separated.none { abs(it.first - candidate.first) < minimumDistanceFrames }) {
                    separated += candidate
                    if (separated.size >= 6) break
                }
            }
            val choices = if (separated.isNotEmpty()) separated else ranked.take(1)
            val chosen = choices[(variant.coerceAtLeast(0)) % choices.size]
            val startSec = (chosen.first * .5).coerceIn(0.0, max(0.0, duration - targetSeconds))
            val confidence = ((chosen.second.coerceAtLeast(0.0) * 180.0) + 55).toInt().coerceIn(55, 96)
            return SuggestedSegment(startSec, targetSeconds.toDouble(), confidence)
        } finally { tempIn.delete(); raw.delete() }
    }

    fun exportSegment(
        context: Context,
        inputUri: Uri,
        outputUri: Uri,
        startSeconds: Double,
        durationSeconds: Double,
        fadeIn: Boolean,
        fadeOut: Boolean,
        outputFormat: String = "MP3"
    ): Result<Unit> = runCatching {
        val input = cacheInput(context, inputUri, "cut_in")
        val ext = when (outputFormat.uppercase()) { "WAV" -> "wav"; "FLAC" -> "flac"; else -> "mp3" }
        val output = File(input.parentFile, "cut_${System.nanoTime()}.$ext")
        try {
            val filters = mutableListOf<String>()
            if (fadeIn) filters += "afade=t=in:st=0:d=${min(1.2, durationSeconds / 4)}"
            if (fadeOut) filters += "afade=t=out:st=${max(0.0, durationSeconds - min(1.2, durationSeconds / 4))}:d=${min(1.2, durationSeconds / 4)}"
            val codec = when (ext) { "wav" -> "-c:a pcm_s16le"; "flac" -> "-c:a flac"; else -> "-c:a libmp3lame -b:a 256k" }
            val filterArg = if (filters.isEmpty()) "" else "-af ${quote(filters.joinToString(","))}"
            execute("-y -ss $startSeconds -i ${quote(input.absolutePath)} -t $durationSeconds -vn $filterArg $codec ${quote(output.absolutePath)}").getOrThrow()
            context.contentResolver.openOutputStream(outputUri, "w")!!.use { out -> output.inputStream().use { it.copyTo(out) } }
        } finally { input.delete(); output.delete() }
    }

    private fun parsePair(value: String): Pair<String, String> {
        val raw = value.trim()
        if (raw.isBlank()) return "" to ""
        val parts = raw.split('/', limit = 2)
        return parts.firstOrNull().orEmpty().trim() to parts.getOrNull(1).orEmpty().trim()
    }

    private fun unescapeFfmetadata(value: String): String = value
        .replace("\\n", "\n")
        .replace("\\=", "=")
        .replace("\\;", ";")
        .replace("\\#", "#")
        .replace("\\\\", "\\")

    private fun readFfMetadata(file: File): Map<String, String> {
        val metaFile = File(file.parentFile, "ffmeta_${System.nanoTime()}.txt")
        return try {
            val session = FFmpegKit.execute("-y -hide_banner -i ${quote(file.absolutePath)} -f ffmetadata ${quote(metaFile.absolutePath)}")
            if (!ReturnCode.isSuccess(session.returnCode) || !metaFile.exists()) emptyMap()
            else {
                val out = linkedMapOf<String, String>()
                var currentKey: String? = null
                val current = StringBuilder()
                fun flush() {
                    val key = currentKey ?: return
                    out[key.lowercase(Locale.US)] = unescapeFfmetadata(current.toString())
                    currentKey = null
                    current.setLength(0)
                }
                metaFile.readLines(Charsets.UTF_8).forEach { line ->
                    if (line.startsWith(';') || line.startsWith('#') || line.isBlank()) return@forEach
                    if (line.endsWith("\\") && '=' !in line && currentKey != null) {
                        current.append(line.dropLast(1)).append('\n')
                    } else {
                        flush()
                        val idx = line.indexOf('=')
                        if (idx > 0) {
                            currentKey = line.substring(0, idx).trim()
                            current.append(line.substring(idx + 1))
                        }
                    }
                }
                flush()
                out
            }
        } catch (_: Throwable) {
            emptyMap()
        } finally {
            runCatching { metaFile.delete() }
        }
    }

    fun readMetadata(context: Context, uri: Uri): AudioMetadata {
        val temp = cacheInput(context, uri, "meta_read")
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(temp.absolutePath)
            val ff = readFfMetadata(temp)
            val trackPair = parsePair(ff["track"].orEmpty().ifBlank { r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_CD_TRACK_NUMBER).orEmpty() })
            val discPair = parsePair(ff["disc"].orEmpty().ifBlank { r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DISC_NUMBER).orEmpty() })
            AudioMetadata(
                title = ff["title"].orEmpty().ifBlank { r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE).orEmpty() },
                artist = ff["artist"].orEmpty().ifBlank { r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST).orEmpty() },
                albumArtist = ff["album_artist"].orEmpty().ifBlank { r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST).orEmpty() },
                album = ff["album"].orEmpty().ifBlank { r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM).orEmpty() },
                composer = ff["composer"].orEmpty().ifBlank { r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_COMPOSER).orEmpty() },
                author = ff["author"].orEmpty().ifBlank { r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_AUTHOR).orEmpty() },
                genre = ff["genre"].orEmpty().ifBlank { r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_GENRE).orEmpty() },
                year = ff["date"].orEmpty().ifBlank { ff["year"].orEmpty() }.ifBlank { r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_YEAR).orEmpty() },
                track = trackPair.first,
                trackTotal = trackPair.second,
                disc = discPair.first,
                discTotal = discPair.second,
                bpm = ff["bpm"].orEmpty().ifBlank { ff["tbpm"].orEmpty() },
                isrc = ff["isrc"].orEmpty(),
                copyright = ff["copyright"].orEmpty(),
                comment = ff["comment"].orEmpty(),
                lyrics = ff["lyrics"].orEmpty().ifBlank { ff["unsyncedlyrics"].orEmpty() }
            )
        } finally { runCatching { r.release() }; temp.delete() }
    }

    fun readEmbeddedArtwork(context: Context, uri: Uri): Bitmap? {
        val temp = cacheInput(context, uri, "art_read")
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(temp.absolutePath)
            r.embeddedPicture?.let { BitmapFactory.decodeByteArray(it, 0, it.size) }
        } finally { runCatching { r.release() }; temp.delete() }
    }

    fun writeMetadata(
        context: Context,
        inputUri: Uri,
        outputUri: Uri,
        metadata: AudioMetadata,
        artworkUri: Uri? = null,
        artworkMode: ArtworkWriteMode = if (artworkUri != null) ArtworkWriteMode.REPLACE else ArtworkWriteMode.KEEP
    ): Result<Unit> = runCatching {
        val input = cacheInput(context, inputUri, "meta_in")
        val ext = queryName(context, inputUri).substringAfterLast('.', "mp3").lowercase(Locale.US)
        val output = File(input.parentFile, "meta_${System.nanoTime()}.$ext")
        val artwork = if (artworkMode == ArtworkWriteMode.REPLACE) artworkUri?.let { cacheInput(context, it, "meta_art") } else null
        try {
            val supportsEmbeddedArt = ext in setOf("mp3", "m4a", "mp4", "flac")
            val canEmbedArt = artwork != null && supportsEmbeddedArt
            val args = buildString {
                append("-y -hide_banner -i ${quote(input.absolutePath)} ")
                if (canEmbedArt) {
                    append("-i ${quote(artwork!!.absolutePath)} -map 0:a:0 -map 1:v:0 -c:a copy -c:v mjpeg -disposition:v:0 attached_pic ")
                    if (ext == "mp3") append("-id3v2_version 3 ")
                } else if (artworkMode == ArtworkWriteMode.REMOVE || !supportsEmbeddedArt) {
                    append("-map 0:a:0 -c:a copy ")
                } else {
                    append("-map 0:a:0 -map '0:v?' -c copy ")
                }
                append("-map_metadata 0 ")
                fun m(k: String, v: String) { append("-metadata ${quote("$k=$v")} ") }
                m("title", metadata.title)
                m("artist", metadata.artist)
                m("album_artist", metadata.albumArtist)
                m("album", metadata.album)
                m("composer", metadata.composer)
                m("author", metadata.author)
                m("genre", metadata.genre)
                m("date", metadata.year)
                val trackValue = when {
                    metadata.track.isBlank() -> ""
                    metadata.trackTotal.isBlank() -> metadata.track
                    else -> "${metadata.track}/${metadata.trackTotal}"
                }
                val discValue = when {
                    metadata.disc.isBlank() -> ""
                    metadata.discTotal.isBlank() -> metadata.disc
                    else -> "${metadata.disc}/${metadata.discTotal}"
                }
                m("track", trackValue)
                m("disc", discValue)
                m("bpm", metadata.bpm)
                m("isrc", metadata.isrc)
                m("copyright", metadata.copyright)
                m("comment", metadata.comment)
                m("lyrics", metadata.lyrics)
                if (canEmbedArt) append("-metadata:s:v ${quote("title=Album cover")} -metadata:s:v ${quote("comment=Cover (front)")} ")
                append(quote(output.absolutePath))
            }
            val session = FFmpegKit.execute(args)
            if (!ReturnCode.isSuccess(session.returnCode)) {
                val log = session.allLogsAsString?.takeLast(1600).orEmpty()
                error(log.ifBlank { "FFmpeg não conseguiu gravar os metadados." })
            }
            require(output.exists() && output.length() > 0L) { "O arquivo final não foi criado." }
            context.contentResolver.openOutputStream(outputUri, "w")?.use { out ->
                output.inputStream().use { it.copyTo(out) }
            } ?: error("Não foi possível abrir o destino para gravação.")
        } finally { input.delete(); output.delete(); artwork?.delete() }
    }

    fun enhanceVoiceFile(context: Context, inputFile: File, outputUri: Uri, strongNoiseReduction: Boolean): Result<Unit> = runCatching {
        require(inputFile.exists()) { "Gravação não encontrada." }
        val output = File(context.cacheDir, "voice_file_${System.nanoTime()}.wav")
        try {
            val filter = if (strongNoiseReduction) {
                "highpass=f=75,afftdn=nf=-28,acompressor=threshold=-18dB:ratio=2.5:attack=12:release=180,alimiter=limit=0.95"
            } else {
                "highpass=f=65,afftdn=nf=-34,equalizer=f=85:t=q:w=1.1:g=2.2,equalizer=f=150:t=q:w=1.2:g=1.2,equalizer=f=280:t=q:w=1.2:g=-1.0,equalizer=f=3000:t=q:w=1.2:g=1.5,acompressor=threshold=-20dB:ratio=2.2:attack=15:release=220:makeup=1.35,alimiter=limit=0.90"
            }
            execute("-y -i ${quote(inputFile.absolutePath)} -vn -af ${quote(filter)} -c:a pcm_s16le ${quote(output.absolutePath)}").getOrThrow()
            context.contentResolver.openOutputStream(outputUri, "w")?.use { out ->
                output.inputStream().use { it.copyTo(out) }
            } ?: error("Não foi possível salvar a gravação processada.")
        } finally {
            output.delete()
        }
    }

    fun enhanceVoice(context: Context, inputUri: Uri, outputUri: Uri, strongNoiseReduction: Boolean): Result<Unit> = runCatching {
        val input = cacheInput(context, inputUri, "voice_in")
        val output = File(input.parentFile, "voice_${System.nanoTime()}.wav")
        try {
            val filter = if (strongNoiseReduction) {
                "highpass=f=75,afftdn=nf=-28,acompressor=threshold=-18dB:ratio=2.5:attack=12:release=180,alimiter=limit=0.95"
            } else {
                "highpass=f=70,afftdn=nf=-34,acompressor=threshold=-20dB:ratio=2:attack=15:release=220,alimiter=limit=0.97"
            }
            execute("-y -i ${quote(input.absolutePath)} -vn -af ${quote(filter)} -c:a pcm_s16le ${quote(output.absolutePath)}").getOrThrow()
            context.contentResolver.openOutputStream(outputUri, "w")?.use { out ->
                output.inputStream().use { it.copyTo(out) }
            } ?: error("Não foi possível salvar o áudio processado.")
        } finally {
            input.delete()
            output.delete()
        }
    }

    fun convertRecording(context: Context, inputFile: File, outputUri: Uri, format: String, bitrateKbps: Int): Result<Unit> = runCatching {
        val ext = format.lowercase().replace("m4a/aac", "m4a").replace("webm/opus", "webm")
        val output = File(context.cacheDir, "record_export_${System.nanoTime()}.$ext")
        try {
            val codec = when (format.uppercase()) {
                "WAV" -> "-c:a pcm_s16le"
                "MP3" -> "-c:a libmp3lame -b:a ${bitrateKbps.coerceIn(32, 320)}k"
                "M4A", "M4A/AAC", "AAC" -> "-c:a aac -b:a ${bitrateKbps.coerceIn(32, 320)}k"
                "FLAC" -> "-c:a flac -compression_level 8"
                "OGG" -> "-c:a libvorbis -q:a 6"
                "OPUS" -> "-c:a libopus -b:a ${bitrateKbps.coerceIn(48, 256)}k"
                "WEBM", "WEBM/OPUS" -> "-c:a libopus -b:a ${bitrateKbps.coerceIn(48, 256)}k"
                "AMR" -> "-c:a libopencore_amrnb -ar 8000 -ac 1 -b:a 12.2k"
                else -> error("Formato não suportado: $format")
            }
            execute("-y -i ${quote(inputFile.absolutePath)} -vn $codec ${quote(output.absolutePath)}").getOrThrow()
            context.contentResolver.openOutputStream(outputUri, "w")!!.use { out -> output.inputStream().use { it.copyTo(out) } }
        } finally { output.delete() }
    }

    fun inspectImage(context: Context, uri: Uri): ImageInfo {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        var size: Long? = null
        context.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c -> if (c.moveToFirst()) c.getColumnIndex(OpenableColumns.SIZE).takeIf { it >= 0 && !c.isNull(it) }?.let { size = c.getLong(it) } }
        return ImageInfo(opts.outWidth, opts.outHeight, opts.outMimeType ?: context.contentResolver.getType(uri), size)
    }

    fun convertSquareImage(
        context: Context,
        inputUri: Uri,
        outputUri: Uri,
        size: Int,
        format: String,
        quality: Int,
        mode: SquareMode
    ): Result<Unit> = convertImage(context, inputUri, outputUri, size, size, format, quality, mode)

    fun convertImage(
        context: Context,
        inputUri: Uri,
        outputUri: Uri,
        width: Int,
        height: Int,
        format: String,
        quality: Int,
        mode: SquareMode
    ): Result<Unit> = runCatching {
        val bitmap = context.contentResolver.openInputStream(inputUri)?.use { BitmapFactory.decodeStream(it) } ?: error("Imagem inválida.")
        val target = createResizedImage(bitmap, width.coerceIn(256, 8192), height.coerceIn(256, 8192), mode)
        try {
            context.contentResolver.openOutputStream(outputUri, "w")?.use { out ->
                when (format.uppercase()) {
                    "PNG" -> target.compress(Bitmap.CompressFormat.PNG, 100, out)
                    "WEBP" -> {
                        val webp = if (android.os.Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.WEBP
                        target.compress(webp, quality.coerceIn(10, 100), out)
                    }
                    "JPG", "JPEG" -> target.compress(Bitmap.CompressFormat.JPEG, quality.coerceIn(10, 100), out)
                    "HEIC", "HEIF" -> {
                        require(android.os.Build.VERSION.SDK_INT >= 28) { "HEIC não é suportado nesta versão do Android." }
                        val temp = File(context.cacheDir, "cover_${System.nanoTime()}.heic")
                        try { HeicImageWriter.write(target, quality.coerceIn(10, 100), temp); temp.inputStream().use { it.copyTo(out) } } finally { temp.delete() }
                    }
                    "BMP", "TIFF", "TIF" -> {
                        val png = File(context.cacheDir, "sonus_img_${System.nanoTime()}.png")
                        val ext = if(format.uppercase()=="BMP") "bmp" else "tiff"
                        val converted = File(context.cacheDir, "sonus_img_${System.nanoTime()}.$ext")
                        try {
                            png.outputStream().use { target.compress(Bitmap.CompressFormat.PNG,100,it) }
                            val session=FFmpegKit.execute("-y -i '${png.absolutePath}' '${converted.absolutePath}'")
                            require(ReturnCode.isSuccess(session.returnCode) && converted.exists()) { "Este formato não pôde ser codificado neste aparelho." }
                            converted.inputStream().use { it.copyTo(out) }
                        } finally { png.delete(); converted.delete() }
                    }
                    else -> error("Formato de imagem não suportado.")
                }
            } ?: error("Não foi possível salvar a imagem.")
        } finally { if (target !== bitmap) target.recycle(); bitmap.recycle() }
    }

    private fun createResizedImage(source: Bitmap, width: Int, height: Int, mode: SquareMode): Bitmap {
        if (mode == SquareMode.STRETCH) return Bitmap.createScaledBitmap(source, width, height, true)
        val out = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(out)
        canvas.drawColor(android.graphics.Color.BLACK)
        val sw = source.width.toFloat(); val sh = source.height.toFloat()
        val scale = when (mode) {
            SquareMode.CROP -> max(width / sw, height / sh)
            SquareMode.FIT_BACKGROUND, SquareMode.CENTER -> min(width / sw, height / sh)
            SquareMode.STRETCH -> 1f
        }
        val dw = sw * scale; val dh = sh * scale
        if (mode == SquareMode.FIT_BACKGROUND && (dw < width || dh < height)) {
            val bgScale = max(width / sw, height / sh)
            val bgW = sw * bgScale; val bgH = sh * bgScale
            val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { alpha = 90 }
            canvas.drawBitmap(source, null, android.graphics.RectF((width-bgW)/2, (height-bgH)/2, (width+bgW)/2, (height+bgH)/2), paint)
        }
        canvas.drawBitmap(source, null, android.graphics.RectF((width-dw)/2, (height-dh)/2, (width+dw)/2, (height+dh)/2), android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG))
        return out
    }
}
