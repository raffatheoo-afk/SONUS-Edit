package com.sonusstudios.streampulse.tools

import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

private data class SavedYouTubePlaylist(
    val playlistId: String,
    val link: String,
    val name: String,
    val sourceTitle: String,
    val channelTitle: String,
    val thumbnailUrl: String?,
    val favorite: Boolean
)

private class YouTubePlaylistStore(context: Context) {
    private val prefs = context.getSharedPreferences("sonus_youtube_playlists_v1", Context.MODE_PRIVATE)

    fun all(): List<SavedYouTubePlaylist> = runCatching {
        val arr = JSONArray(prefs.getString("playlists", "[]") ?: "[]")
        buildList {
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val id = o.optString("playlistId")
                if (id.isBlank()) continue
                add(
                    SavedYouTubePlaylist(
                        playlistId = id,
                        link = o.optString("link"),
                        name = o.optString("name").ifBlank { o.optString("sourceTitle").ifBlank { "Playlist do YouTube" } },
                        sourceTitle = o.optString("sourceTitle"),
                        channelTitle = o.optString("channelTitle"),
                        thumbnailUrl = o.optString("thumbnailUrl").takeIf { it.isNotBlank() },
                        favorite = o.optBoolean("favorite", false)
                    )
                )
            }
        }.sortedWith(compareByDescending<SavedYouTubePlaylist> { it.favorite }.thenBy { it.name.lowercase() })
    }.getOrDefault(emptyList())

    private fun write(items: List<SavedYouTubePlaylist>) {
        val arr = JSONArray()
        items.forEach { p ->
            arr.put(JSONObject().apply {
                put("playlistId", p.playlistId)
                put("link", p.link)
                put("name", p.name)
                put("sourceTitle", p.sourceTitle)
                put("channelTitle", p.channelTitle)
                put("thumbnailUrl", p.thumbnailUrl ?: "")
                put("favorite", p.favorite)
            })
        }
        prefs.edit().putString("playlists", arr.toString()).apply()
    }

    fun save(result: YouTubePlaylistResult, link: String, preferredName: String? = null): List<SavedYouTubePlaylist> {
        val current = all()
        val old = current.firstOrNull { it.playlistId == result.playlistId }
        val item = SavedYouTubePlaylist(
            playlistId = result.playlistId,
            link = link.trim().ifBlank { "https://www.youtube.com/playlist?list=${result.playlistId}" },
            name = preferredName?.trim().takeUnless { it.isNullOrBlank() } ?: old?.name ?: result.title,
            sourceTitle = result.title,
            channelTitle = result.channelTitle,
            thumbnailUrl = result.thumbnailUrl,
            favorite = old?.favorite ?: false
        )
        val updated = listOf(item) + current.filterNot { it.playlistId == result.playlistId }
        write(updated)
        return all()
    }

    fun rename(id: String, name: String): List<SavedYouTubePlaylist> {
        val clean = name.trim().take(80)
        if (clean.isBlank()) return all()
        write(all().map { if (it.playlistId == id) it.copy(name = clean) else it })
        return all()
    }

    fun toggleFavorite(id: String): List<SavedYouTubePlaylist> {
        write(all().map { if (it.playlistId == id) it.copy(favorite = !it.favorite) else it })
        return all()
    }

    fun remove(id: String): List<SavedYouTubePlaylist> {
        write(all().filterNot { it.playlistId == id })
        return all()
    }
}

@Composable
internal fun YouTubePlaylistHubScreen(accent: Color) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val store = remember { YouTubePlaylistStore(context) }
    val controller = rememberStreamPulseYouTubeController()

    var link by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var status by remember { mutableStateOf<String?>(null) }
    var loaded by remember { mutableStateOf<YouTubePlaylistResult?>(null) }
    var selectedIndex by remember { mutableIntStateOf(-1) }
    var saved by remember { mutableStateOf(store.all()) }
    var renameTarget by remember { mutableStateOf<SavedYouTubePlaylist?>(null) }
    var renameText by remember { mutableStateOf("") }

    fun loadPlaylist(raw: String) {
        val target = raw.trim()
        if (target.isBlank() || loading) return
        scope.launch {
            loading = true
            error = null
            status = null
            val result = YouTubePlaylistClient.load(context, target)
            result.onSuccess { playlist ->
                loaded = playlist
                selectedIndex = 0
                link = target
                controller.load(playlist.videos.first().videoId, force = true)
                status = "${playlist.videos.size} vídeo(s) carregados"
            }.onFailure { problem ->
                loaded = null
                selectedIndex = -1
                error = problem.message ?: "Não foi possível carregar a playlist."
            }
            loading = false
        }
    }

    LaunchedEffect(controller.endedGeneration) {
        val playlist = loaded ?: return@LaunchedEffect
        if (controller.endedGeneration <= 0 || playlist.videos.isEmpty()) return@LaunchedEffect
        val next = if (selectedIndex < playlist.videos.lastIndex) selectedIndex + 1 else 0
        selectedIndex = next
        controller.load(playlist.videos[next].videoId, force = true)
    }

    renameTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text("Renomear playlist") },
            text = {
                OutlinedTextField(
                    value = renameText,
                    onValueChange = { renameText = it.take(80) },
                    label = { Text("Nome no SONUS") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    saved = store.rename(target.playlistId, renameText)
                    renameTarget = null
                }, enabled = renameText.isNotBlank()) { Text("Salvar") }
            },
            dismissButton = { TextButton(onClick = { renameTarget = null }) { Text("Cancelar") } }
        )
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 28.dp)
    ) {
        item {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color.Black.copy(alpha = .28f),
                border = BorderStroke(1.dp, accent.copy(alpha = .34f))
            ) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(shape = RoundedCornerShape(13.dp), color = accent.copy(alpha = .16f)) {
                            Icon(Icons.Default.PlaylistPlay, null, tint = accent, modifier = Modifier.padding(10.dp))
                        }
                        Spacer(Modifier.width(9.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Playlists do YouTube", fontWeight = FontWeight.Black, fontSize = 20.sp)
                            Text("Cole um link e reproduza pelo player oficial incorporado.", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = .58f))
                        }
                    }
                    OutlinedTextField(
                        value = link,
                        onValueChange = { link = it.take(500); error = null },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        leadingIcon = { Icon(Icons.Default.Link, null) },
                        label = { Text("Link da playlist do YouTube") },
                        placeholder = { Text("youtube.com/playlist?list=…") }
                    )
                    Button(onClick = { loadPlaylist(link) }, enabled = link.isNotBlank() && !loading, modifier = Modifier.fillMaxWidth()) {
                        if (loading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                        else Icon(Icons.Default.CloudDownload, null)
                        Spacer(Modifier.width(7.dp))
                        Text(if (loading) "Carregando playlist…" else "Carregar playlist")
                    }
                    Text("O SONUS salva apenas o link, nome e favorito localmente. Os vídeos continuam sendo reproduzidos pelo YouTube.", fontSize = 9.sp, color = Color.White.copy(alpha = .50f))
                    error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                    status?.let { Text(it, color = accent, style = MaterialTheme.typography.bodySmall) }
                }
            }
        }

        loaded?.let { playlist ->
            val current = playlist.videos.getOrNull(selectedIndex)
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = .30f)),
                    border = BorderStroke(1.dp, accent.copy(alpha = .30f))
                ) {
                    Column(Modifier.padding(11.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            YouTubeThumbnail(playlist.thumbnailUrl, Modifier.size(70.dp).clip(RoundedCornerShape(12.dp)))
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(playlist.title, fontWeight = FontWeight.Black, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text(playlist.channelTitle, style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = .58f), maxLines = 1)
                                Text("${playlist.videos.size} vídeo(s)", style = MaterialTheme.typography.labelSmall, color = accent)
                            }
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { saved = store.save(playlist, link); status = "Playlist salva no SONUS" },
                                modifier = Modifier.weight(1f)
                            ) { Icon(Icons.Default.BookmarkAdd, null); Spacer(Modifier.width(5.dp)); Text("Salvar link") }
                            val isSavedFavorite = saved.firstOrNull { it.playlistId == playlist.playlistId }?.favorite == true
                            OutlinedButton(
                                onClick = {
                                    if (saved.none { it.playlistId == playlist.playlistId }) saved = store.save(playlist, link)
                                    saved = store.toggleFavorite(playlist.playlistId)
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(if (isSavedFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null)
                                Spacer(Modifier.width(5.dp)); Text("Favorita")
                            }
                        }
                        current?.let { video ->
                            YouTubeEmbedPlayer(video.videoId, controller, Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(16.dp)))
                            Text(video.title, fontWeight = FontWeight.Black, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text(video.channelTitle, style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = .58f), maxLines = 1)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                                IconButton(onClick = {
                                    if (playlist.videos.isNotEmpty()) {
                                        selectedIndex = if (selectedIndex > 0) selectedIndex - 1 else playlist.videos.lastIndex
                                        controller.load(playlist.videos[selectedIndex].videoId, true)
                                    }
                                }) { Icon(Icons.Default.SkipPrevious, "Anterior") }
                                FilledIconButton(onClick = { if (controller.isPlaying) controller.pause() else controller.play() }) {
                                    Icon(if (controller.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "Play/Pause")
                                }
                                IconButton(onClick = {
                                    if (playlist.videos.isNotEmpty()) {
                                        selectedIndex = if (selectedIndex < playlist.videos.lastIndex) selectedIndex + 1 else 0
                                        controller.load(playlist.videos[selectedIndex].videoId, true)
                                    }
                                }) { Icon(Icons.Default.SkipNext, "Próxima") }
                            }
                            controller.errorMessage?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                        }
                    }
                }
            }

            item { Text("Faixas da playlist", fontWeight = FontWeight.Black, color = Color.White) }
            itemsIndexed(playlist.videos, key = { _, v -> v.videoId }) { index, video ->
                Surface(
                    modifier = Modifier.fillMaxWidth().clickable {
                        selectedIndex = index
                        controller.load(video.videoId, force = true)
                    },
                    shape = RoundedCornerShape(14.dp),
                    color = if (index == selectedIndex) accent.copy(alpha = .18f) else Color.Black.copy(alpha = .22f),
                    border = if (index == selectedIndex) BorderStroke(1.dp, accent.copy(alpha = .42f)) else null
                ) {
                    Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        YouTubeThumbnail(video.thumbnailUrl, Modifier.size(width = 82.dp, height = 46.dp).clip(RoundedCornerShape(8.dp)))
                        Spacer(Modifier.width(9.dp))
                        Column(Modifier.weight(1f)) {
                            Text(video.title, fontWeight = if (index == selectedIndex) FontWeight.Black else FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text(video.channelTitle, style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = .52f), maxLines = 1)
                        }
                        if (index == selectedIndex) Icon(Icons.Default.GraphicEq, null, tint = accent)
                    }
                }
            }
        }

        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Playlists salvas", Modifier.weight(1f), fontWeight = FontWeight.Black, color = Color.White)
                Text("${saved.size}", color = accent, fontWeight = FontWeight.Bold)
            }
        }
        if (saved.isEmpty()) {
            item { Text("Nenhuma playlist salva ainda.", color = Color.White.copy(alpha = .58f)) }
        } else {
            items(saved, key = { it.playlistId }) { item ->
                Surface(
                    modifier = Modifier.fillMaxWidth().clickable { link = item.link; loadPlaylist(item.link) },
                    shape = RoundedCornerShape(15.dp),
                    color = Color.Black.copy(alpha = .24f),
                    border = BorderStroke(1.dp, if (item.favorite) accent.copy(alpha = .42f) else Color.White.copy(alpha = .08f))
                ) {
                    Row(Modifier.padding(9.dp), verticalAlignment = Alignment.CenterVertically) {
                        YouTubeThumbnail(item.thumbnailUrl, Modifier.size(58.dp).clip(RoundedCornerShape(10.dp)))
                        Spacer(Modifier.width(9.dp))
                        Column(Modifier.weight(1f)) {
                            Text(item.name, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(item.channelTitle.ifBlank { item.sourceTitle }, style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = .54f), maxLines = 1)
                        }
                        IconButton(onClick = { saved = store.toggleFavorite(item.playlistId) }) {
                            Icon(if (item.favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Favorita", tint = if (item.favorite) Color(0xFFFF5A70) else Color.White.copy(alpha = .70f))
                        }
                        IconButton(onClick = { renameTarget = item; renameText = item.name }) { Icon(Icons.Default.Edit, "Renomear") }
                        IconButton(onClick = { saved = store.remove(item.playlistId) }) { Icon(Icons.Default.DeleteOutline, "Remover") }
                    }
                }
            }
        }
    }
}
