package com.sonusstudios.streampulse.tools

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import androidx.core.app.NotificationCompat
import com.sonusstudios.streampulse.MainActivity
import com.sonusstudios.streampulse.R

/**
 * Notificação neutra de processamento do SONUS.
 * Centraliza notificações de progresso para tarefas longas sem criar overlay.
 */
object SonusProcessNotifier {
    private const val CHANNEL_ID = "sonus_processing"
    private const val CHANNEL_NAME = "Processamentos SONUS"

    private fun manager(context: Context): NotificationManager =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    private fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager(context).createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    CHANNEL_NAME,
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "Progresso de conversões e processamentos do SONUS"
                    setSound(null, null)
                    enableVibration(false)
                }
            )
        }
    }

    private fun idFor(title: String): Int = 4600 + (title.hashCode() and 0x0FFF)

    fun publish(context: Context, title: String, progress: Int? = null, detail: String? = null) {
        ensureChannel(context)
        val safe = progress?.coerceIn(0, 100)
        val intent = Intent(context, MainActivity::class.java)
        val pending = PendingIntent.getActivity(
            context,
            idFor(title),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val complete = safe == 100
        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_sonus_notification)
            .setContentTitle(title)
            .setContentText(detail ?: when {
                complete -> "Concluído"
                safe != null -> "$safe%"
                else -> "Processando…"
            })
            .setContentIntent(pending)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setOngoing(!complete)
            .setAutoCancel(complete)
            .setPriority(NotificationCompat.PRIORITY_LOW)

        if (safe != null && !complete) builder.setProgress(100, safe, false)
        else builder.setProgress(0, 0, false)

        runCatching { manager(context).notify(idFor(title), builder.build()) }
    }

    fun clear(context: Context, title: String) {
        runCatching { manager(context).cancel(idFor(title)) }
    }

    fun fail(context: Context, title: String, detail: String = "Não foi possível concluir o processamento") {
        ensureChannel(context)
        val intent = Intent(context, MainActivity::class.java)
        val pending = PendingIntent.getActivity(
            context,
            idFor(title),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_sonus_notification)
            .setContentTitle(title)
            .setContentText(detail)
            .setContentIntent(pending)
            .setOnlyAlertOnce(true)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
        runCatching { manager(context).notify(idFor(title), notification) }
    }

    fun isOffline(context: Context): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val caps = cm?.activeNetwork?.let(cm::getNetworkCapabilities)
        return caps == null ||
            !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) ||
            !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }
}
