package com.sonusstudios.streampulse.cloud

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.TrafficStats

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class DeveloperRemoteSection {
    REMOTE, PROMOS, ANALYTICS, TOOLS, LOGS, INFRA, COMMUNITY
}

@Composable
fun DeveloperRemotePanel(uid: String, section: DeveloperRemoteSection = DeveloperRemoteSection.REMOTE) {
    val context = LocalContext.current
    val cloud = remember { CloudAccountManager() }
    val scope = rememberCoroutineScope()
    var coupons by remember { mutableStateOf<List<PromoCoupon>>(emptyList()) }
    var analytics by remember { mutableStateOf<AdminAnalyticsSnapshot?>(null) }
    var status by remember { mutableStateOf<String?>(null) }
    var couponLoadError by remember { mutableStateOf<String?>(null) }
    var analyticsError by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    var showCreate by remember { mutableStateOf(false) }
    var editingCoupon by remember { mutableStateOf<PromoCoupon?>(null) }
    var savingCoupon by remember { mutableStateOf(false) }
    var editorError by remember { mutableStateOf<String?>(null) }
    var allPaused by remember { mutableStateOf(false) }
    var counterEnabled by remember { mutableStateOf(true) }
    var counterMinimumText by remember { mutableStateOf("100") }
    var analyticsPeriod by remember { mutableStateOf("7 dias") }

    fun firebaseFriendlyError(prefix: String, throwable: Throwable?): String {
        val raw = throwable?.message.orEmpty()
        return when {
            "permission" in raw.lowercase() || "denied" in raw.lowercase() ->
                "$prefix: permissão negada pelo Firebase. Publique as regras da mesma versão do APK."
            raw.isNotBlank() -> "$prefix: ${raw.take(180)}"
            else -> "$prefix. Verifique internet e regras do Firebase."
        }
    }

    fun refresh() {
        scope.launch {
            loading = true
            couponLoadError = null
            analyticsError = null
            val couponResult = withContext(Dispatchers.IO) { cloud.listCoupons() }
            if (couponResult.isSuccess) coupons = couponResult.getOrDefault(emptyList())
            else couponLoadError = firebaseFriendlyError("Falha ao carregar códigos", couponResult.exceptionOrNull())

            val analyticsResult = withContext(Dispatchers.IO) { cloud.loadAdminAnalytics() }
            if (analyticsResult.isSuccess) analytics = analyticsResult.getOrNull()
            else analyticsError = firebaseFriendlyError("Falha ao carregar analytics", analyticsResult.exceptionOrNull())

            val pausedResult = withContext(Dispatchers.IO) { runCatching { cloud.couponsPaused() } }
            if (pausedResult.isSuccess) allPaused = pausedResult.getOrDefault(false)
            loading = false
        }
    }
    LaunchedEffect(section) { refresh() }

    if (showCreate || editingCoupon != null) {
        CouponEditorDialog(
            initial = editingCoupon,
            saving = savingCoupon,
            externalError = editorError,
            onDismiss = {
                if (!savingCoupon) {
                    showCreate = false
                    editingCoupon = null
                    editorError = null
                }
            },
            onSave = { coupon ->
                scope.launch {
                    savingCoupon = true
                    editorError = null
                    val r = withContext(Dispatchers.IO) { cloud.saveCoupon(coupon) }
                    savingCoupon = false
                    if (r.isSuccess) {
                        status = "Código ${coupon.code} salvo no Firebase."
                        showCreate = false
                        editingCoupon = null
                        refresh()
                    } else editorError = firebaseFriendlyError("Não foi possível salvar o código", r.exceptionOrNull())
                }
            }
        )
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
        when (section) {
            DeveloperRemoteSection.REMOTE -> {
                DeveloperPanelHeader(Icons.Default.AdminPanelSettings, "Administração remota", "Controle central de recursos, métricas, acesso e backend.")
                val a = analytics
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
                    AdminMetric(Modifier.weight(1f), a?.registeredUsers?.toString() ?: "—", "usuários")
                    AdminMetric(Modifier.weight(1f), a?.onlineUsers?.toString() ?: "—", "online")
                    AdminMetric(Modifier.weight(1f), coupons.count { it.active }.toString(), "cupons ativos")
                }
                Card {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text("Estado do backend", fontWeight = FontWeight.ExtraBold)
                        Text(if (analyticsError == null && couponLoadError == null) "Firebase e controles administrativos respondendo." else "Há itens que exigem atenção.", color = if (analyticsError == null && couponLoadError == null) Color(0xFF4CAF79) else MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                        analyticsError?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall) }
                        couponLoadError?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall) }
                        OutlinedButton(onClick = { refresh() }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(6.dp)); Text("Atualizar painel") }
                    }
                }
            }

            DeveloperRemoteSection.PROMOS -> {
                DeveloperPanelHeader(Icons.Default.ConfirmationNumber, "Códigos promocionais", "Crie, pause, edite e acompanhe campanhas sem perder nenhuma função existente.")
                val active = coupons.count { it.active }
                val paused = coupons.size - active
                val totalUses = coupons.sumOf { it.usedCount }
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
                    AdminMetric(Modifier.weight(1f), active.toString(), "ativos")
                    AdminMetric(Modifier.weight(1f), paused.toString(), "pausados")
                    AdminMetric(Modifier.weight(1f), totalUses.toString(), "resgates")
                }
                if (coupons.any { it.usedCount > 0 }) DeveloperMiniBars("Resgates por código", coupons.sortedByDescending { it.usedCount }.take(6).map { it.code to it.usedCount }, Color(0xFFFF4F8B))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { editorError = null; showCreate = true }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(5.dp)); Text("Novo código") }
                    OutlinedButton(onClick = {
                        scope.launch {
                            val next = !allPaused
                            val r = withContext(Dispatchers.IO) { cloud.pauseAllCoupons(next) }
                            if (r.isSuccess) allPaused = next
                            status = if (r.isSuccess) { if (next) "Todos os códigos foram pausados." else "Códigos reativados." }
                            else firebaseFriendlyError("Falha ao alterar códigos", r.exceptionOrNull())
                        }
                    }, modifier = Modifier.weight(1f)) { Text(if (allPaused) "Reativar todos" else "Pausar todos") }
                }
                couponLoadError?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                if (couponLoadError == null && coupons.isEmpty()) Text("Nenhum código criado ainda.", style = MaterialTheme.typography.bodySmall)
                coupons.take(30).forEach { coupon ->
                    CouponAdminCard(coupon, allPaused,
                        onToggle = {
                            scope.launch {
                                val r = withContext(Dispatchers.IO) { cloud.saveCoupon(coupon.copy(active = !coupon.active)) }
                                status = if (r.isSuccess) "Status de ${coupon.code} atualizado." else firebaseFriendlyError("Falha ao atualizar ${coupon.code}", r.exceptionOrNull())
                                if (r.isSuccess) refresh()
                            }
                        },
                        onEdit = { editorError = null; editingCoupon = coupon },
                        onDelete = {
                            scope.launch {
                                val r = withContext(Dispatchers.IO) { cloud.deleteCoupon(coupon.code) }
                                status = if (r.isSuccess) "${coupon.code} excluído." else firebaseFriendlyError("Falha ao excluir ${coupon.code}", r.exceptionOrNull())
                                if (r.isSuccess) refresh()
                            }
                        }
                    )
                }
                status?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = if ("Falha" in it || "perm" in it.lowercase()) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary) }
            }

            DeveloperRemoteSection.ANALYTICS -> {
                DeveloperPanelHeader(Icons.Default.QueryStats, "Analytics", "Usuários, atividade e navegação do produto em um único painel.")
                if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
                analyticsError?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                analytics?.let { a ->
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
                        AdminMetric(Modifier.weight(1f), a.registeredUsers.toString(), "registrados")
                        AdminMetric(Modifier.weight(1f), a.onlineUsers.toString(), "online agora")
                        AdminMetric(Modifier.weight(1f), a.activeToday.toString(), "ativos hoje")
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
                        AdminMetric(Modifier.weight(1f), a.active7d.toString(), "ativos 7d")
                        AdminMetric(Modifier.weight(1f), a.active30d.toString(), "ativos 30d")
                        AdminMetric(Modifier.weight(1f), a.newUsers30d.toString(), "novos 30d")
                    }
                    DeveloperMiniBars("Atividade", listOf("Hoje" to a.activeToday, "7d" to a.active7d, "30d" to a.active30d, "Novos" to a.newUsers30d), Color(0xFF34D8F5))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        items(listOf("Hoje", "7 dias", "30 dias")) { period -> FilterChip(selected = analyticsPeriod == period, onClick = { analyticsPeriod = period }, label = { Text(period) }) }
                    }
                    val pages = when (analyticsPeriod) { "Hoje" -> a.pageCountsToday; "30 dias" -> a.pageCounts30d; else -> a.pageCounts7d }
                    UsageRankingCard("Telas mais acessadas • $analyticsPeriod", pages, emptyMap(), emptyMap())
                    if (a.couponUses.isNotEmpty()) Card { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text("Cupons mais resgatados", fontWeight = FontWeight.Bold)
                        a.couponUses.entries.take(8).forEach { Text("${it.key} • ${it.value} resgates", style = MaterialTheme.typography.bodySmall) }
                    } }
                }
            }

            DeveloperRemoteSection.TOOLS -> {
                DeveloperPanelHeader(Icons.Default.BuildCircle, "Uso das ferramentas", "Ranking, conclusão e tempo médio das ferramentas do SONUS.")
                analyticsError?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                analytics?.let { a ->
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) { items(listOf("Hoje", "7 dias", "30 dias")) { period -> FilterChip(analyticsPeriod == period, { analyticsPeriod = period }, { Text(period) }) } }
                    val tools = when (analyticsPeriod) { "Hoje" -> a.toolCountsToday; "30 dias" -> a.toolCounts30d; else -> a.toolCounts7d }
                    DeveloperMiniBars("Uso por ferramenta", tools.entries.sortedByDescending { it.value }.take(6).map { it.key.take(9) to it.value }, Color(0xFFB46BFF))
                    UsageRankingCard("Ferramentas mais usadas • $analyticsPeriod", tools, a.successCounts, a.averageDurationMs)
                }
            }

            DeveloperRemoteSection.LOGS -> {
                DeveloperPanelHeader(Icons.Default.BugReport, "Logs & erros", "Falhas agregadas, avisos e diagnóstico do backend.")
                analyticsError?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                analytics?.let { a ->
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
                        AdminMetric(Modifier.weight(1f), a.errorCounts7d.values.sum().toString(), "falhas 7d")
                        AdminMetric(Modifier.weight(1f), a.warnings.size.toString(), "avisos")
                    }
                    Card { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Diagnóstico recente", fontWeight = FontWeight.ExtraBold)
                        if (a.warnings.isEmpty()) Text("Firebase/analytics: leituras administrativas OK", color = Color(0xFF4CAF79), style = MaterialTheme.typography.bodySmall)
                        else a.warnings.take(8).forEach { Text("⚠ ${it.take(180)}", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                        if (a.errorCounts7d.isEmpty()) Text("Sem falhas agregadas nos últimos 7 dias.", style = MaterialTheme.typography.bodySmall)
                        else a.errorCounts7d.entries.take(10).forEach { Text("${it.key}: ${it.value}", style = MaterialTheme.typography.labelSmall) }
                    } }
                }
            }

            DeveloperRemoteSection.INFRA -> {
                DeveloperPanelHeader(Icons.Default.CloudQueue, "Firebase & infraestrutura", "Rede, sessão e saúde dos serviços online.")
                FirebaseInfrastructureCard(context = context, analyticsOk = analytics != null && analyticsError == null)
            }

            DeveloperRemoteSection.COMMUNITY -> {
                DeveloperPanelHeader(Icons.Default.Groups, "Comunidade", "Controle do contador público e regras de exibição.")
                Text("Nunca fabrica usuários: abaixo do mínimo aparece apenas “Comunidade em crescimento”. Acima dele, o valor real é arredondado para baixo.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .58f))
                Row(verticalAlignment = Alignment.CenterVertically) { Switch(counterEnabled, { counterEnabled = it }); Spacer(Modifier.width(9.dp)); Text("Exibir contador público quando atingir o mínimo") }
                OutlinedTextField(counterMinimumText, { counterMinimumText = it.filter(Char::isDigit).take(7) }, label = { Text("Número mínimo real") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth())
                Button(onClick = {
                    val minimum = counterMinimumText.toIntOrNull()?.coerceAtLeast(1) ?: 100
                    scope.launch {
                        val r = withContext(Dispatchers.IO) { cloud.setPublicCommunityConfig(counterEnabled, minimum) }
                        status = if (r.isSuccess) "Exibição pública atualizada." else firebaseFriendlyError("Falha ao salvar configuração pública", r.exceptionOrNull())
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text("Salvar configuração pública") }
                status?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary) }
            }
        }
    }
}

@Composable
private fun DeveloperPanelHeader(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = .24f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = .26f))
    ) {
        Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.primary.copy(alpha = .15f)) {
                Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(11.dp).size(25.dp))
            }
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .62f))
            }
        }
    }
}

@Composable
private fun DeveloperMiniBars(title: String, values: List<Pair<String, Int>>, tint: Color) {
    if (values.isEmpty()) return
    val maxValue = values.maxOfOrNull { it.second }?.coerceAtLeast(1) ?: 1
    Card(colors = CardDefaults.cardColors(containerColor = tint.copy(alpha=.07f)), border = BorderStroke(1.dp, tint.copy(alpha=.18f))) {
        Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth().height(132.dp), horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.Bottom) {
                values.forEach { (label, value) ->
                    val ratio = (value.toFloat() / maxValue.toFloat()).coerceIn(.05f, 1f)
                    Column(Modifier.weight(1f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                        Text(value.toString(), fontSize=8.sp, fontWeight=FontWeight.Bold, color=tint)
                        Spacer(Modifier.height(3.dp))
                        Box(Modifier.fillMaxWidth(.62f).height((68f * ratio).dp).background(tint.copy(alpha=.85f), RoundedCornerShape(topStart=7.dp, topEnd=7.dp)))
                        Spacer(Modifier.height(4.dp))
                        Text(label, maxLines=2, textAlign=androidx.compose.ui.text.style.TextAlign.Center, overflow=androidx.compose.ui.text.style.TextOverflow.Ellipsis, fontSize=7.sp, color=MaterialTheme.colorScheme.onSurface.copy(alpha=.55f))
                    }
                }
            }
        }
    }
}

@Composable
private fun UsageRankingCard(
    title: String,
    entries: Map<String, Int>,
    successCounts: Map<String, Pair<Int, Int>>,
    averageDurationMs: Map<String, Long>
) {
    Card {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            if (entries.isEmpty()) {
                Text("Ainda não há atividade suficiente nesse período.", style = MaterialTheme.typography.bodySmall)
            } else {
                entries.entries.take(10).forEachIndexed { index, e ->
                    Row(Modifier.fillMaxWidth()) {
                        Text("${index + 1}. ${e.key}", modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                        Text("${e.value}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                    }
                    val success = successCounts[e.key]
                    val avg = averageDurationMs[e.key]
                    if (success != null || avg != null) {
                        Text(
                            buildString {
                                success?.let {
                                    append("conclusão ${if (it.second > 0) it.first * 100 / it.second else 0}%")
                                }
                                if (success != null && avg != null) append(" • ")
                                avg?.let { append("média ${formatDuration(it)}") }
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = .52f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminMetric(modifier: Modifier, value: String, label: String) {
    Surface(modifier, shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = .55f)) {
        Column(Modifier.padding(11.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp); Text(label, fontSize = 9.sp)
        }
    }
}

@Composable
private fun CouponAdminCard(c: PromoCoupon, allPaused: Boolean, onToggle: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit) {
    val now = System.currentTimeMillis()
    val statusLabel = when {
        allPaused -> "Pausado global"
        !c.active -> "Pausado"
        c.expiresAtEpochMillis != null && c.expiresAtEpochMillis <= now -> "Expirado"
        !c.unlimitedUses && c.usedCount >= c.maxUses -> "Esgotado"
        else -> "Ativo"
    }
    Card(border = BorderStroke(1.dp, if (statusLabel == "Ativo") Color(0xFF4CAF79).copy(alpha=.35f) else MaterialTheme.colorScheme.outline.copy(alpha=.2f))) {
        Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(c.code, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                AssistChip(onClick = onToggle, label = { Text(statusLabel) })
                IconButton(onClick = onEdit) { Icon(Icons.Default.Edit, "Editar") }
                IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, null, tint = MaterialTheme.colorScheme.error) }
            }
            Text(couponBenefitLabel(c), style = MaterialTheme.typography.bodySmall)
            Text(buildString {
                append(if (c.unlimitedUses) "${c.usedCount} resgates • usos ilimitados" else "${c.usedCount}/${c.maxUses} resgates")
                c.expiresAtEpochMillis?.let { append(" • expira ${formatDate(it)}") }
            }, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha=.54f))
            if (c.description.isNotBlank()) Text(c.description, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun FirebaseInfrastructureCard(context: Context, analyticsOk: Boolean) {
    val uid = android.os.Process.myUid()
    val startRx = remember { TrafficStats.getUidRxBytes(uid).coerceAtLeast(0L) }
    val startTx = remember { TrafficStats.getUidTxBytes(uid).coerceAtLeast(0L) }
    var rx by remember { mutableLongStateOf(startRx) }
    var tx by remember { mutableLongStateOf(startTx) }
    var networkLabel by remember { mutableStateOf("Verificando") }
    LaunchedEffect(Unit) {
        while (true) {
            rx = TrafficStats.getUidRxBytes(uid).coerceAtLeast(startRx)
            tx = TrafficStats.getUidTxBytes(uid).coerceAtLeast(startTx)
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            val caps = cm?.activeNetwork?.let(cm::getNetworkCapabilities)
            networkLabel = when {
                caps == null -> "Offline"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi‑Fi"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Dados móveis"
                else -> "Online"
            }
            delay(1800)
        }
    }
    fun mb(value: Long): String = String.format(Locale.US, "%.2f MB", value.coerceAtLeast(0L) / (1024.0 * 1024.0))
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF102636).copy(alpha=.82f)),
        border = BorderStroke(1.dp, Color(0xFF3EB8E5).copy(alpha=.38f))
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CloudQueue, null, tint = Color(0xFF64D8FF))
                Spacer(Modifier.width(8.dp))
                Text("Firebase / infraestrutura", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier=Modifier.fillMaxWidth()) {
                AdminMetric(Modifier.weight(1f), if(analyticsOk) "OK" else "Atenção", "Realtime/analytics")
                AdminMetric(Modifier.weight(1f), mb(rx-startRx), "download sessão")
                AdminMetric(Modifier.weight(1f), mb(tx-startTx), "upload sessão")
            }
            Text("Rede atual: $networkLabel", color=Color.White.copy(alpha=.78f), style=MaterialTheme.typography.bodySmall)
            Surface(shape=RoundedCornerShape(12.dp), color=Color.White.copy(alpha=.06f)) {
                Column(Modifier.padding(10.dp), verticalArrangement=Arrangement.spacedBy(4.dp)) {
                    Text("Métricas avançadas do Firebase", color=Color.White, fontWeight=FontWeight.Bold)
                    Text("Armazenamento global, conexões totais, tráfego do banco e carga dependem de um backend protegido com Google Cloud Monitoring. O APK nunca recebe credenciais administrativas.", color=Color.White.copy(alpha=.66f), style=MaterialTheme.typography.labelSmall)
                    Text("Em preparação • monitor local e Analytics Owner continuam ativos", color=Color(0xFF64D8FF), fontWeight=FontWeight.Bold, style=MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@Composable
private fun CouponEditorDialog(
    initial: PromoCoupon? = null,
    saving: Boolean,
    externalError: String?,
    onDismiss: () -> Unit,
    onSave: (PromoCoupon) -> Unit
) {
    var code by remember(initial?.code) { mutableStateOf(initial?.code.orEmpty()) }
    var type by remember(initial?.code) { mutableStateOf(initial?.type ?: CouponType.COINS) }
    var coins by remember(initial?.code) { mutableIntStateOf(initial?.amount?.takeIf { it > 0 } ?: 5) }
    var tier by remember(initial?.code) { mutableStateOf(when(initial?.tierName?.uppercase(Locale.US)) {
        "PLUS" -> "BRONZE"
        "STUDIO" -> "PRATA"
        "MAX" -> "OURO"
        "DIAMOND" -> "DIAMANTE"
        null, "" -> "OURO"
        else -> initial?.tierName ?: "OURO"
    }) }
    var durationHours by remember(initial?.code) { mutableIntStateOf(initial?.durationHours?.takeIf { it > 0 } ?: 24) }
    var discount by remember(initial?.code) { mutableIntStateOf(initial?.discountPercent?.takeIf { it > 0 } ?: 10) }
    var maxUses by remember(initial?.code) { mutableStateOf((initial?.maxUses ?: 100).toString()) }
    var unlimited by remember(initial?.code) { mutableStateOf(initial?.unlimitedUses ?: false) }
    var expiryDays by remember(initial?.code) {
        val days = initial?.expiresAtEpochMillis?.let { ((it - System.currentTimeMillis()).coerceAtLeast(86_400_000L) / 86_400_000L).toInt() } ?: 30
        mutableStateOf(days.toString())
    }
    var description by remember(initial?.code) { mutableStateOf(initial?.description.orEmpty()) }
    var active by remember(initial?.code) { mutableStateOf(initial?.active ?: true) }
    val generated = { "SP" + System.currentTimeMillis().toString(36).takeLast(7).uppercase(Locale.US) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Criar código promocional" else "Editar ${initial.code}") },
        text = {
            Column(Modifier.fillMaxWidth().heightIn(max = 560.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    code,
                    { code = it.uppercase(Locale.US).filter { ch -> ch.isLetterOrDigit() || ch == '_' || ch == '-' }.take(32) },
                    label = { Text("Código") },
                    trailingIcon = if (initial == null) ({ IconButton(onClick = { code = generated() }) { Icon(Icons.Default.AutoAwesome, null) } }) else null,
                    singleLine = true,
                    enabled = initial == null,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Benefício", fontWeight = FontWeight.Bold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(CouponType.entries.filterNot { it == CouponType.AD_REWARD_2X }) { t -> FilterChip(type == t, { type = t }, { Text(typeLabel(t)) }) }
                }
                when (type) {
                    CouponType.COINS -> LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(listOf(5, 10, 20)) { n -> FilterChip(coins == n, { coins = n }, { Text("+$n") }) }
                    }
                    CouponType.PREMIUM -> {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("OURO", "DIAMANTE").forEach { v -> FilterChip(tier == v, { tier = v }, { Text(v) }) }
                        }
                        DurationChips(durationHours) { durationHours = it }
                    }
                    CouponType.REMOVE_ADS -> Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(24, 48).forEach { h -> FilterChip(durationHours == h, { durationHours = h }, { Text("${h}h") }) }
                    }
                    CouponType.DISCOUNT -> {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("OURO", "DIAMANTE").forEach { v -> FilterChip(tier == v, { tier = v }, { Text(v) }) }
                        }
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(listOf(10, 20, 30, 40, 50)) { pct -> FilterChip(discount == pct, { discount = pct }, { Text("$pct%") }) }
                        }
                    }
                    CouponType.AD_REWARD_2X -> DurationChips(durationHours) { durationHours = it }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(unlimited, { unlimited = it }); Text("Sem limite de resgates")
                }
                if (!unlimited) {
                    OutlinedTextField(
                        maxUses,
                        { maxUses = it.filter(Char::isDigit).take(4) },
                        label = { Text("Máximo de usuários (até 5.000)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                OutlinedTextField(
                    expiryDays,
                    { expiryDays = it.filter(Char::isDigit).take(4) },
                    label = { Text("Código expira em quantos dias?") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(description, { description = it.take(140) }, label = { Text("Descrição interna") }, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(active, { active = it }); Spacer(Modifier.width(8.dp)); Text(if (active) "Código ativo" else "Código pausado")
                }
                if (initial != null) Text("${initial.usedCount} resgate(s) já registrado(s).", style = MaterialTheme.typography.bodySmall)
                externalError?.let {
                    Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                }
                if (saving) LinearProgressIndicator(Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            Button(enabled = !saving, onClick = {
                val clean = code.ifBlank { generated() }
                val now = System.currentTimeMillis()
                val days = expiryDays.toIntOrNull()?.coerceAtLeast(1) ?: 30
                onSave(
                    PromoCoupon(
                        code = clean,
                        type = type,
                        amount = if (type == CouponType.COINS) coins else 0,
                        tierName = if (type in listOf(CouponType.PREMIUM, CouponType.DISCOUNT)) tier else null,
                        durationHours = when (type) {
                            CouponType.PREMIUM, CouponType.REMOVE_ADS, CouponType.AD_REWARD_2X -> durationHours
                            CouponType.DISCOUNT -> 24 * 30
                            else -> 0
                        },
                        discountPercent = if (type == CouponType.DISCOUNT) discount else 0,
                        active = active,
                        unlimitedUses = unlimited,
                        maxUses = maxUses.toIntOrNull()?.coerceIn(1, 5000) ?: 100,
                        expiresAtEpochMillis = now + days * 86_400_000L,
                        description = description,
                        createdAtEpochMillis = initial?.createdAtEpochMillis ?: now,
                        usedCount = initial?.usedCount ?: 0
                    )
                )
            }) { Text("Salvar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable private fun DurationChips(selected:Int,onSelect:(Int)->Unit){LazyRow(horizontalArrangement=Arrangement.spacedBy(6.dp)){items(listOf(24,48,168,360,720)){h->FilterChip(selected==h,{onSelect(h)},{Text(when(h){24->"1 dia";48->"2 dias";168->"7 dias";360->"15 dias";else->"30 dias"})})}}}
private fun typeLabel(t:CouponType)=when(t){CouponType.COINS->"Moedas SONUS";CouponType.PREMIUM->"Premium";CouponType.REMOVE_ADS->"Sem Ads";CouponType.DISCOUNT->"Desconto";CouponType.AD_REWARD_2X->"Ads 2x • legado"}
private fun couponBenefitLabel(c:PromoCoupon)=when(c.type){CouponType.COINS->"+${c.amount} Moedas SONUS";CouponType.PREMIUM->"${c.tierName} • ${c.durationHours/24} dia(s)";CouponType.REMOVE_ADS->"Remover anúncios • ${c.durationHours}h";CouponType.DISCOUNT->"${c.discountPercent}% • ${c.tierName}";CouponType.AD_REWARD_2X->"Bônus 2x de anúncio • legado"}
private fun formatDate(epoch:Long)=runCatching{LocalDateTime.ofInstant(java.time.Instant.ofEpochMilli(epoch),ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))}.getOrDefault("—")
private fun formatDuration(ms:Long):String{val s=ms/1000;val m=s/60;val h=m/60;return if(h>0)"${h}h ${m%60}min" else "${m}min"}
