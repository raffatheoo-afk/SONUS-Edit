package com.sonusstudios.streampulse.integration

import android.content.Context
import android.content.Intent
import android.net.Uri

/**
 * Contrato mínimo SONUS -> SONUS Edit.
 * Só transporta identificadores/metadados públicos; nunca tokens, credenciais ou URLs privadas.
 */
object SonusEditBridge {
    const val PACKAGE = "com.sonusstudios.sonusedit"
    private const val SCHEME = "sonusedit"
    private const val HOST_CREATE = "create"

    private fun intentFor(trackId: Long, startMs: Long? = null, durationMs: Long? = null): Intent {
        val uri = Uri.Builder()
            .scheme(SCHEME)
            .authority(HOST_CREATE)
            .appendQueryParameter("source", "sonus")
            .appendQueryParameter("trackId", trackId.toString())
            .apply {
                startMs?.coerceAtLeast(0L)?.let { appendQueryParameter("startMs", it.toString()) }
                durationMs?.takeIf { it > 0L }?.let { appendQueryParameter("durationMs", it.toString()) }
            }
            .build()
        return Intent(Intent.ACTION_VIEW, uri).setPackage(PACKAGE)
    }

    fun isAvailable(context: Context): Boolean = runCatching {
        context.packageManager.resolveActivity(intentFor(1L), 0) != null
    }.getOrDefault(false)

    fun openTrack(context: Context, trackId: Long, startMs: Long? = null, durationMs: Long? = null): Result<Unit> = runCatching {
        require(trackId > 0L) { "Faixa SONUS inválida." }
        context.startActivity(intentFor(trackId, startMs, durationMs))
    }
}
