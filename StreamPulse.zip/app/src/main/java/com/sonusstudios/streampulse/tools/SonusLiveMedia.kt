package com.sonusstudios.streampulse.tools

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.Normalizer
import java.util.Locale
import kotlin.random.Random

/** Mesmo link público da galeria SONUS usada pelo Social Edit. */
internal const val SONUS_GALLERY_PUBLIC_CODE = "kZspB4JZmPJsxI5SKzQ1dgJWSicA2bQzFJhX"
internal val SONUS_GALLERY_PUBLIC_CODES = listOf(
    SONUS_GALLERY_PUBLIC_CODE,
    "kZlMPSJZIKQmTVCl6w7EgHPazyKmapmHe3cy",
    "kZwyCSJZUAqjAxCrE9zIvbA8MWP1rXS3YaAV"
)

internal data class SonusLiveMediaItem(val fileId: Long, val name: String, val size: Long, val isVideo: Boolean, val sourceCode: String = SONUS_GALLERY_PUBLIC_CODE)

internal data class LiveSlide(val item: SonusLiveMediaItem, val file: File, val image: ImageBitmap?)

internal object SonusLiveMediaRepo {
    private val imageExt = setOf("jpg", "jpeg", "png", "webp")
    private val videoExt = setOf("mp4", "mov", "webm", "mkv", "3gp", "m4v")
    private const val MAX_VIDEO_BYTES = 120L * 1024 * 1024
    private const val CACHE_LIMIT_BYTES = 700L * 1024 * 1024
    @Volatile private var cached: List<SonusLiveMediaItem>? = null
    @Volatile private var cachedAt = 0L
    private val preparedLock = Any()
    private val preparedByFamily = mutableMapOf<String, ArrayDeque<LiveSlide>>()

    suspend fun list(): List<SonusLiveMediaItem> = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        cached?.takeIf { now - cachedAt < 6 * 3_600_000L }?.let { return@withContext it }
        val items = SONUS_GALLERY_PUBLIC_CODES.flatMap { code ->
            runCatching {
                SonusPCloudClient.listPublicNodes(code).mapNotNull { n ->
                    val ext = n.name.substringAfterLast('.', "").lowercase(Locale.ROOT)
                    val isVideo = ext in videoExt || n.contentType.startsWith("video/", true)
                    val isImage = ext in imageExt || n.contentType.startsWith("image/", true)
                    when {
                        isVideo && n.size in 1..MAX_VIDEO_BYTES -> SonusLiveMediaItem(n.fileId, n.name, n.size, true, code)
                        isVideo && n.size == 0L -> SonusLiveMediaItem(n.fileId, n.name, n.size, true, code)
                        isImage -> SonusLiveMediaItem(n.fileId, n.name, n.size, false, code)
                        else -> null
                    }
                }
            }.getOrDefault(emptyList())
        }.distinctBy { "${it.sourceCode}:${it.fileId}" }
        if (items.isNotEmpty()) { cached = items; cachedAt = now }
        items.ifEmpty { cached.orEmpty() }
    }

    /**
     * Prepara e decodifica as primeiras cenas ainda na configuração. A fila fica guardada
     * em memória e é consumida pelo palco da LIVE, evitando baixar/selecionar tudo de novo
     * depois da contagem regressiva.
     */
    suspend fun warmUp(context: Context, count: Int = 1, themeWords: List<String> = emptyList()): Int = withContext(Dispatchers.IO) {
        if (count <= 0) return@withContext 0
        val key = liveThemeFamily(themeWords).name
        synchronized(preparedLock) {
            preparedByFamily.clear()
            preparedByFamily[key] = ArrayDeque()
        }
        val photos = list().filter { !it.isVideo }
        if (photos.isEmpty()) return@withContext 0
        val recent = mutableListOf<Long>()
        val item = pickLiveMedia(photos, themeWords, recent, videoShare = 0) ?: return@withContext 0
        // Uma cena inicial, com limite rígido de tempo. O restante é responsabilidade
        // do refillQueue do palco, que trabalha em segundo plano sem bloquear o início.
        val prepared = withTimeoutOrNull(14_000L) {
            runCatching {
                val fetched = fetch(context, item) ?: return@runCatching null
                val bitmap = decodeSlideImage(fetched.first) ?: return@runCatching null
                LiveSlide(item, fetched.first, bitmap)
            }.getOrNull()
        }
        if (prepared != null) synchronized(preparedLock) {
            preparedByFamily.getOrPut(key) { ArrayDeque() }.addLast(prepared)
        }
        if (prepared == null) 0 else 1
    }

    /** Retira, uma única vez, as cenas já prontas para a mesma família de conteúdo. */
    fun takePrepared(themeWords: List<String>): List<LiveSlide> = synchronized(preparedLock) {
        val key = liveThemeFamily(themeWords).name
        val queue = preparedByFamily.remove(key) ?: preparedByFamily.entries.firstOrNull()?.let { entry ->
            preparedByFamily.remove(entry.key)
        } ?: return@synchronized emptyList()
        buildList { while (queue.isNotEmpty()) add(queue.removeFirst()) }
    }

    private fun dir(context: Context): File = File(context.cacheDir, "sonus_live_media").apply { mkdirs() }

    /** Baixa (ou reaproveita do cache) e devolve o arquivo e quantos bytes vieram da rede nesta chamada. */
    suspend fun fetch(context: Context, item: SonusLiveMediaItem): Pair<File, Long>? = withContext(Dispatchers.IO) {
        val ext = item.name.substringAfterLast('.', if (item.isVideo) "mp4" else "jpg").lowercase(Locale.ROOT).take(5)
        val cacheKey = "${item.sourceCode.hashCode()}_${item.fileId}"
        val target = File(dir(context), "${cacheKey}.$ext")
        if (target.exists() && target.length() > 0L) {
            target.setLastModified(System.currentTimeMillis())
            return@withContext target to 0L
        }
        runCatching {
            val url = SonusPCloudClient.publicFileUrl(item.sourceCode, item.fileId)
            val tmp = File(dir(context), "${cacheKey}.part")
            val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 12_000; readTimeout = 25_000; instanceFollowRedirects = true
            }
            var total = 0L
            try {
                if (conn.responseCode !in 200..299) return@runCatching null
                conn.inputStream.use { input -> tmp.outputStream().use { out ->
                    val buf = ByteArray(32 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n <= 0) break
                        total += n
                        if (total > MAX_VIDEO_BYTES) { throw IllegalStateException("arquivo grande demais") }
                        out.write(buf, 0, n)
                    }
                } }
            } finally { conn.disconnect() }
            if (!tmp.renameTo(target)) { tmp.copyTo(target, overwrite = true); tmp.delete() }
            trim(context)
            target to total
        }.getOrNull().also { if (it == null) File(dir(context), "${item.sourceCode.hashCode()}_${item.fileId}.part").delete() }
    }

    private fun trim(context: Context) {
        val files = dir(context).listFiles()?.filter { it.isFile && !it.name.endsWith(".part") }?.sortedBy { it.lastModified() } ?: return
        var size = files.sumOf { it.length() }
        for (f in files) {
            if (size <= CACHE_LIMIT_BYTES) break
            size -= f.length(); f.delete()
        }
    }
}

private fun liveNorm(value: String): String =
    Normalizer.normalize(value.lowercase(Locale.ROOT), Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")
        .replace(Regex("[^a-z0-9]+"), " ").trim()

private enum class LiveContentFamily { RELIGIOUS, SECULAR, NEUTRAL, AMBIGUOUS }

private val liveReligiousTerms = setOf(
    "jesus", "cristo", "maria", "nossa senhora", "santo", "santa", "igreja", "oracao",
    "gospel", "catolico", "catolica", "biblia", "adoracao", "louvor", "deus", "terco",
    "padre", "evangelho", "sagrado", "sacra", "faith", "worship", "church", "cross"
)
private val liveSecularTerms = setOf(
    "sertanejo", "universitario", "forro", "piseiro", "trap", "pop", "rock", "funk", "pagode",
    "samba", "sofrencia", "balada", "farra", "bebida", "bebendo", "traicao", "desilusao",
    "ciume", "vaquejada", "arrocha", "party", "nightclub", "concert", "festival"
)

private fun containsLiveTerm(normalized: String, term: String): Boolean =
    Regex("(?:^| )${Regex.escape(term)}(?:$| )").containsMatchIn(normalized)

/**
 * A LIVE usa primeiro o gênero (themeWords[0]); o título só classifica quando o gênero é genérico.
 * Ambiguidade é tratada como neutra: nunca muda a LIVE nem inventa um gênero.
 */
private fun liveThemeFamily(themeWords: List<String>): LiveContentFamily {
    val genre = liveNorm(themeWords.firstOrNull().orEmpty())
    val title = liveNorm(themeWords.drop(1).joinToString(" "))
    fun hasAny(text: String, terms: Set<String>) = terms.any { containsLiveTerm(text, it) }
    val genreReligious = hasAny(genre, liveReligiousTerms)
    val genreSecular = hasAny(genre, liveSecularTerms)
    if (genreReligious && !genreSecular) return LiveContentFamily.RELIGIOUS
    if (genreSecular && !genreReligious) return LiveContentFamily.SECULAR
    if (genreReligious || genreSecular) return LiveContentFamily.NEUTRAL
    val titleReligious = hasAny(title, liveReligiousTerms)
    val titleSecular = hasAny(title, liveSecularTerms)
    return when {
        titleReligious && !titleSecular -> LiveContentFamily.RELIGIOUS
        titleSecular && !titleReligious -> LiveContentFamily.SECULAR
        else -> LiveContentFamily.NEUTRAL
    }
}

private fun liveMediaFamily(item: SonusLiveMediaItem): LiveContentFamily {
    val name = liveNorm(item.name.substringBeforeLast('.'))
    val religious = liveReligiousTerms.any { containsLiveTerm(name, it) }
    val secular = liveSecularTerms.any { containsLiveTerm(name, it) }
    return when {
        religious && secular -> LiveContentFamily.AMBIGUOUS
        religious -> LiveContentFamily.RELIGIOUS
        secular -> LiveContentFamily.SECULAR
        else -> LiveContentFamily.NEUTRAL
    }
}

/** Escolhe mídia compatível com o gênero, sem misturar conteúdo religioso e secular e sem repetir as últimas. */
internal fun pickLiveMedia(
    all: List<SonusLiveMediaItem>,
    themeWords: List<String>,
    recent: List<Long>,
    videoShare: Int,
    random: Random = Random.Default
): SonusLiveMediaItem? {
    if (all.isEmpty()) return null
    val family = liveThemeFamily(themeWords)
    val classified = all.map { it to liveMediaFamily(it) }
    val compatible = classified.filter { (_, mediaFamily) ->
        when (family) {
            LiveContentFamily.RELIGIOUS -> mediaFamily == LiveContentFamily.RELIGIOUS || mediaFamily == LiveContentFamily.NEUTRAL
            LiveContentFamily.SECULAR -> mediaFamily == LiveContentFamily.SECULAR || mediaFamily == LiveContentFamily.NEUTRAL
            LiveContentFamily.NEUTRAL -> mediaFamily == LiveContentFamily.NEUTRAL
            LiveContentFamily.AMBIGUOUS -> false
        }
    }.map { it.first }.ifEmpty {
        // Se não houver mídia nomeada para um subgênero (ex.: arrocha/brega),
        // usa reserva segura: conteúdo não religioso para gêneros seculares/neutros.
        when (family) {
            LiveContentFamily.SECULAR, LiveContentFamily.NEUTRAL -> classified.filter { it.second == LiveContentFamily.SECULAR || it.second == LiveContentFamily.NEUTRAL }.map { it.first }
            LiveContentFamily.RELIGIOUS -> classified.filter { it.second == LiveContentFamily.RELIGIOUS || it.second == LiveContentFamily.NEUTRAL }.map { it.first }
            LiveContentFamily.AMBIGUOUS -> emptyList()
        }
    }
    if (compatible.isEmpty()) return null
    val tokens = themeWords.drop(1).map(::liveNorm).flatMap { it.split(' ') }.filter { it.length >= 3 }.distinct()
    val themed = if (tokens.isEmpty()) emptyList() else compatible.filter { m ->
        val name = liveNorm(m.name.substringBeforeLast('.'))
        tokens.any { name.contains(it) }
    }
    val pool = themed.ifEmpty { compatible }
    val avoid = recent.takeLast(minOf(12, (pool.size - 1).coerceAtLeast(0))).toSet()
    val fresh = pool.filter { it.fileId !in avoid }.ifEmpty { pool }
    val videos = fresh.filter { it.isVideo }
    val images = fresh.filter { !it.isVideo }
    val wantVideo = videos.isNotEmpty() && (images.isEmpty() || random.nextInt(100) < videoShare)
    return (if (wantVideo) videos else images.ifEmpty { videos }).randomOrNull(random)
}

private fun decodeSlideImage(file: File): ImageBitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(file.absolutePath, bounds)
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    var sample = 1
    while (bounds.outWidth / sample > 1440 || bounds.outHeight / sample > 1440) sample *= 2
    val opts = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.RGB_565 }
    return BitmapFactory.decodeFile(file.absolutePath, opts)?.asImageBitmap()
}

/**
 * Palco de mídia da live: fotos trocam no intervalo escolhido; vídeos tocam sempre MUDOS e até o fim.
 * A próxima mídia é baixada e decodificada enquanto a atual está na tela, e a troca é sempre um fade.
 */
@OptIn(androidx.media3.common.util.UnstableApi::class)
@Composable
internal fun LiveMediaStage(
    pool: List<SonusLiveMediaItem>,
    themeWords: List<String>,
    intervalSeconds: Int,
    videoShare: Int,
    onNetworkBytes: (Long) -> Unit,
    modifier: Modifier = Modifier,
    landscapeMode: Boolean = false
) {
    val context = LocalContext.current
    val latestTheme by rememberUpdatedState(themeWords)
    val latestPool by rememberUpdatedState(pool)
    val latestInterval by rememberUpdatedState(intervalSeconds)
    val latestShare by rememberUpdatedState(videoShare)
    val latestBytes by rememberUpdatedState(onNetworkBytes)
    var current by remember { mutableStateOf<LiveSlide?>(null) }
    var transitionIndex by remember { mutableIntStateOf(0) }
    var videoEnded by remember { mutableStateOf<CompletableDeferred<Unit>>(CompletableDeferred()) }

    LaunchedEffect(Unit) {
        // A fila preparada durante a configuração é independente da listagem de galeria
        // iniciada ao entrar no ar: a primeira cena aparece sem esperar uma segunda consulta.
        val recent = ArrayDeque<Long>()
        suspend fun prepare(): LiveSlide? {
            val availablePool = latestPool
            if (availablePool.isEmpty()) return null
            repeat(4) {
                val item = withContext(Dispatchers.Default) {
                    pickLiveMedia(availablePool, latestTheme, recent.toList(), latestShare)
                } ?: return null
                recent.addLast(item.fileId); if (recent.size > 24) recent.removeFirst()
                val fetched = withTimeoutOrNull(15_000L) { SonusLiveMediaRepo.fetch(context, item) } ?: return@repeat
                if (fetched.second > 0L) latestBytes(fetched.second)
                if (item.isVideo) return LiveSlide(item, fetched.first, null)
                val bmp = withContext(Dispatchers.IO) { decodeSlideImage(fetched.first) } ?: return@repeat
                return LiveSlide(item, fetched.first, bmp)
            }
            return null
        }
        val preparedQueue = ArrayDeque<LiveSlide>().apply {
            SonusLiveMediaRepo.takePrepared(latestTheme).forEach(::addLast)
        }
        suspend fun refillQueue() {
            // A listagem secundária pode terminar depois da primeira cena. Espera só
            // no job de fundo; nunca segura a troca ou o desenho da imagem atual.
            var attempts = 0
            while (isActive && latestPool.isEmpty() && attempts < 120) {
                delay(500L)
                attempts++
            }
            while (isActive && latestPool.isNotEmpty() && preparedQueue.size < 5) {
                val prepared = runCatching { prepare() }.getOrNull() ?: break
                preparedQueue.addLast(prepared)
            }
        }

        var activeSlide = preparedQueue.removeFirstOrNull()
        while (isActive && activeSlide == null) {
            // O palco permanece no cenário oficial SONUS e tenta novamente com intervalo
            // limitado; falha de mídia não encerra uma LIVE que já iniciou o áudio.
            activeSlide = runCatching { prepare() }.getOrNull()
            if (activeSlide == null) delay(5_000L)
        }
        if (!isActive || activeSlide == null) return@LaunchedEffect
        videoEnded = CompletableDeferred()
        current = activeSlide
        transitionIndex = (0..4).filter { it != transitionIndex }.random()
        // Mantém até cinco cenas prontas em segundo plano; a troca não espera download.
        var prefetch = async { refillQueue() }
        while (isActive) {
            // activeSlide é atualizado a cada troca; captura uma referência não nula
            // para que o compilador e o player usem exatamente a cena exibida.
            val displayedSlide = activeSlide ?: break
            if (displayedSlide.item.isVideo) {
                // Vídeo respeita a duração original; o player sinaliza fim ou erro.
                // Não aplicar o intervalo das fotos nem cortar vídeos longos por timeout.
                videoEnded.await()
            } else {
                delay(latestInterval.coerceIn(5, 600) * 1_000L)
            }
            // A apresentação nunca inicia download na rotina de troca. Se a fila
            // esvaziar, mantém a cena atual enquanto a reposição trabalha em segundo
            // plano; só troca quando houver outra cena já baixada e decodificada.
            while (isActive && preparedQueue.isEmpty()) {
                if (prefetch.isCompleted) prefetch = async { refillQueue() }
                delay(500L)
            }
            if (!isActive) break
            val next = preparedQueue.removeFirstOrNull() ?: continue
            videoEnded = CompletableDeferred()
            current = next
            activeSlide = next
            transitionIndex = (0..4).filter { it != transitionIndex }.random()
            if (prefetch.isCompleted) prefetch = async { refillQueue() }
        }
    }

    Box(modifier.background(Color.Black)) {
        if (landscapeMode) {
            current?.image?.let { bitmap ->
                Image(
                    bitmap = bitmap,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize().graphicsLayer { scaleX = 1.16f; scaleY = 1.16f }.blur(18.dp).alpha(.52f)
                )
                Box(Modifier.fillMaxSize().background(Color(0x99050A14)))
            } ?: Box(Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Brush.horizontalGradient(listOf(Color(0xFF10182B), Color(0xFF080B12), Color(0xFF10182B)))))
        }
        val stageModifier = if (landscapeMode) Modifier.fillMaxHeight().aspectRatio(9f / 16f).align(androidx.compose.ui.Alignment.Center) else Modifier.fillMaxSize()
        Box(stageModifier) {
        AnimatedContent(
            targetState = current,
            transitionSpec = {
                when (transitionIndex % 5) {
                    0 -> fadeIn(tween(420)) togetherWith fadeOut(tween(420))
                    1 -> (slideInHorizontally(tween(360)) { it / 10 } + fadeIn(tween(360))) togetherWith (slideOutHorizontally(tween(360)) { -it / 10 } + fadeOut(tween(360)))
                    2 -> (scaleIn(tween(420), initialScale = .985f) + fadeIn(tween(420))) togetherWith (scaleOut(tween(420), targetScale = 1.015f) + fadeOut(tween(420)))
                    3 -> (slideInVertically(tween(360)) { it / 12 } + fadeIn(tween(360))) togetherWith (slideOutVertically(tween(360)) { -it / 12 } + fadeOut(tween(360)))
                    else -> (slideInHorizontally(tween(380)) { -it / 12 } + fadeIn(tween(380))) togetherWith (slideOutHorizontally(tween(380)) { it / 12 } + fadeOut(tween(380)))
                }
            },
            label = "live-media"
        ) { slide ->
            if (slide == null) {
                // Enquanto a primeira mídia carrega: fundo da marca (nunca tela preta).
                Box(
                    Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color(0xFF050A1F), Color(0xFF16093A), Color(0xFF050A1F)))),
                    contentAlignment = androidx.compose.ui.Alignment.Center
                ) {
                    Image(
                        painter = androidx.compose.ui.res.painterResource(com.sonusstudios.streampulse.R.drawable.sonus_symbol_official),
                        contentDescription = null, modifier = Modifier.fillMaxSize(0.5f).alpha(0.32f)
                    )
                }
            } else if (slide.image != null) {
                Image(bitmap = slide.image, contentDescription = null, contentScale = if (landscapeMode) ContentScale.Fit else ContentScale.Crop, modifier = Modifier.fillMaxSize())
            } else {
                LiveMutedVideo(slide.file, fit = landscapeMode) { videoEnded.complete(Unit) }
            }
        }
        }
    }
}

@OptIn(androidx.media3.common.util.UnstableApi::class)
@Composable
private fun LiveMutedVideo(file: File, fit: Boolean = false, onEnded: () -> Unit) {
    val context = LocalContext.current
    val player = remember(file) {
        ExoPlayer.Builder(context)
            // false = nunca pede o foco de áudio: o vídeo mudo não pausa nem abaixa a música da rádio.
            .setAudioAttributes(AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(), false)
            .build().apply {
                volume = 0f
                trackSelectionParameters = trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, true).build()
                repeatMode = Player.REPEAT_MODE_OFF
                setMediaItem(MediaItem.fromUri(Uri.fromFile(file)))
                playWhenReady = true
                prepare()
            }
    }
    val endedCallback by rememberUpdatedState(onEnded)
    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) endedCallback()
            }
            override fun onPlayerError(error: PlaybackException) { endedCallback() }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener); player.release() }
    }
    AndroidView(
        factory = { ctx -> PlayerView(ctx).apply { useController = false; resizeMode = if (fit) AspectRatioFrameLayout.RESIZE_MODE_FIT else AspectRatioFrameLayout.RESIZE_MODE_ZOOM; this.player = player } },
        modifier = Modifier.fillMaxSize().alpha(1f)
    )
}
