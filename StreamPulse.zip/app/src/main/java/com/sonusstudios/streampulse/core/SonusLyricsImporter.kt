package com.sonusstudios.streampulse.core

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns

/** Resultado padronizado da importação TXT/LRC no app inteiro. */
data class SonusLyricsDocument(
    val name: String,
    val text: String,
    val format: String
)

object SonusLyricsImporter {
    fun pickerMimeTypes(): Array<String> = arrayOf("*/*")

    fun read(context: Context, uri: Uri, maxChars: Int = 120_000): Result<SonusLyricsDocument> = runCatching {
        val name = displayName(context, uri).ifBlank { uri.lastPathSegment.orEmpty() }
        require(SonusMediaStandards.isLyricsFileName(name)) { "Selecione um arquivo .TXT ou .LRC." }
        val text = context.contentResolver.openInputStream(uri)
            ?.bufferedReader(Charsets.UTF_8)
            ?.use { it.readText().take(maxChars) }
            .orEmpty()
        require(text.isNotBlank()) { "O arquivo de letra está vazio." }
        val format = SonusMediaStandards.lyricsFormat(name, text)
        if (name.endsWith(".lrc", ignoreCase = true)) {
            require(SonusMediaStandards.isSyncedLrc(text)) { "O arquivo .LRC não contém marcações de tempo válidas." }
        }
        SonusLyricsDocument(name = name, text = text, format = format)
    }

    fun displayName(context: Context, uri: Uri): String = runCatching {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (!cursor.moveToFirst()) return@use ""
            val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (index >= 0) cursor.getString(index).orEmpty() else ""
        }.orEmpty()
    }.getOrDefault("")
}
