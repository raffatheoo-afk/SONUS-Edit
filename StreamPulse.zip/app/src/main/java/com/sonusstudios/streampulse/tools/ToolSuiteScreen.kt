package com.sonusstudios.streampulse.tools

import com.sonusstudios.streampulse.core.SonusAutoCreateDocument
import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.net.TrafficStats
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.StatFs
import android.provider.Settings
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import com.sonusstudios.streampulse.R
import com.sonusstudios.streampulse.audio.AudioConversionEngine
import com.sonusstudios.streampulse.core.*
import com.sonusstudios.streampulse.notifications.SonusNotificationCenter
import java.io.File
import java.time.LocalDateTime
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.ChronoUnit
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.roundToInt

enum class ToolId {
    HUB, PULSE_PLAYER, ANALYZER, CUTTER, PREVIEW, METADATA, COVER, COVER_PRO, RECORDER, KARAOKE, VIDEO_AUDIO, VIDEO_CONVERTER, MERGE, MERGE_VIDEO, PITCH, VOCAL,
    PULSE_TUNE, TRANSCRIBE, STEM_SPLITTER, VOICE_CLEANER, METRONOME, BPM_KEY,
    NORMALIZER, FADE, SILENCE, CLIPPING, LOOP,
    IMG_COMPRESS, IMG_PALETTE, IMG_WATERMARK, IMG_BATCH, IMAGE_RENAME_BATCH, FILE_SPLIT, TAG_BATCH, RENAME_BATCH, DUPLICATES, SONUS_LAB, SONUS_AUTOMIX, LRC_EDITOR
}

enum class ToolHubVariant { FULL, HIGHLIGHTS }

private data class ToolCardInfo(val id: ToolId?, val title: String, val subtitle: String, val icon: ImageVector, val colors: List<Color>, val requiredTier: MembershipTier? = null)

@Composable
fun ToolSuiteScreen(
    state: AppState,
    artist: Artist,
    pulseCoins: Int,
    unlimited: Boolean,
    membershipTier: MembershipTier,
    preferences: UserPreferences,
    onAudioConverter: () -> Unit,
    onOpenBlackBox: () -> Unit,
    onSpendCoins: suspend (Int) -> Boolean,
    onWatchRewardedAd: () -> Unit,
    onUnlockFeature24h: (feature: PulseFeaturePass, onUnlocked: () -> Unit, onUnavailable: (String) -> Unit) -> Unit,
    onTrack: (name: String, success: Boolean?, durationMs: Long?) -> Unit,
    hubVariant: ToolHubVariant = ToolHubVariant.FULL,
    initialTool: ToolId = ToolId.HUB,
    onInitialToolConsumed: () -> Unit = {},
    unreadNotifications: Int = 0,
    onNotifications: () -> Unit = {},
    onPremiumUseRecorded: (String) -> Unit = {},
    onRequestPlan: (MembershipTier) -> Unit = {},
    ownerAccess: Boolean = false,
    onOwnerSaveLrc: suspend (Long, String) -> Result<Unit> = { _, _ -> Result.failure(IllegalStateException("OWNER indisponível")) },
    onOpenOwnerSonusMusic: (String) -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var tool by remember { mutableStateOf(initialTool) }
    val meteredPremiumTools = remember {
        setOf(
            ToolId.STEM_SPLITTER, ToolId.VOICE_CLEANER, ToolId.NORMALIZER,
            ToolId.TAG_BATCH, ToolId.DUPLICATES, ToolId.PULSE_TUNE,
            ToolId.VIDEO_AUDIO, ToolId.RECORDER, ToolId.TRANSCRIBE
        )
    }
    // code97: a telemetria não desconta moedas. Cada ferramenta cobra somente na ação
    // explicitamente definida (exportar, ampliar lote, AutoMix etc.). Isso evita cobrança
    // dupla e mantém Gravador/Afinador/Cortador realmente livres.
    val trackedOnTrack: (String, Boolean?, Long?) -> Unit = { name, success, duration ->
        if (success == true && tool != ToolId.HUB && tool != ToolId.PULSE_PLAYER) {
            onPremiumUseRecorded(name)
        }
        onTrack(name, success, duration)
    }
    LaunchedEffect(Unit) { if (initialTool != ToolId.HUB) onInitialToolConsumed() }
    AnimatedContent(tool, transitionSpec = { fadeIn() togetherWith fadeOut() }, label = "tool-suite") { current ->
        when (current) {
            ToolId.HUB -> if (hubVariant == ToolHubVariant.HIGHLIGHTS) {
                HighlightsHub(
                    coins = pulseCoins,
                    unlimited = unlimited,
                    rewardEligible = membershipTier == MembershipTier.FREE || ((commercialTier(membershipTier) == MembershipTier.PRATA || commercialTier(membershipTier) == MembershipTier.OURO) && state.preferences.pulseMonthlyCoins <= 0 && state.preferences.pulseBonusCoins < 10),
                    onAudioConverter = onAudioConverter,
                    onOpenRecorder = { tool = ToolId.RECORDER },
                    onOpenVocal = { tool = ToolId.VOCAL },
                    onOpenTune = { tool = ToolId.PULSE_TUNE },
                    onOpenTranscribe = { tool = ToolId.TRANSCRIBE },
                    onOpenSonusLab = { tool = ToolId.SONUS_LAB },
                    onOpenAutoMix = { tool = ToolId.SONUS_AUTOMIX },
                    onOpenImage = { tool = ToolId.COVER_PRO },
                    onOpenVideoAudio = { tool = ToolId.VIDEO_AUDIO },
                    onOpenMergeAudio = { tool = ToolId.MERGE },
                    onOpenMergeVideo = { tool = ToolId.MERGE_VIDEO },
                    onOpenTool = { tool = it },
                    onOpenBlackBox = onOpenBlackBox,
                    membershipTier = membershipTier,
                    preferences = state.preferences,
                    onWatchAd = onWatchRewardedAd,
                    onTrack = trackedOnTrack,
                    unreadNotifications = unreadNotifications,
                    onNotifications = onNotifications,
                    onRequestPlan = onRequestPlan,
                    onSpendCoins = onSpendCoins,
                    onOpenLrcEditor = { tool = ToolId.LRC_EDITOR }
                )
            } else {
                ToolHub(
                    artist, pulseCoins, unlimited, membershipTier, state.preferences, onAudioConverter,
                    { tool = it }, onSpendCoins, onWatchRewardedAd, trackedOnTrack, onRequestPlan
                )
            }
            ToolId.LRC_EDITOR -> LrcEditorTool(
                onBack = { tool = ToolId.HUB },
                ownerAccess = ownerAccess,
                membershipTier = membershipTier,
                coins = pulseCoins,
                unlimited = unlimited,
                onSpendCoin = { onSpendCoins(1) },
                onOwnerSaveLrc = onOwnerSaveLrc,
                onOpenOwnerSonusMusic = onOpenOwnerSonusMusic,
                onTrack = trackedOnTrack
            )
            ToolId.ANALYZER -> AudioAnalyzerTool({ tool = ToolId.HUB }, trackedOnTrack, onAudioConverter, { tool = ToolId.CUTTER })
            ToolId.CUTTER -> VideoMultiCutterTool(
                onBack = { tool = ToolId.HUB }, membershipTier = membershipTier, coins = pulseCoins, unlimited = unlimited,
                onSpend = onSpendCoins, onWatchAd = onWatchRewardedAd, onTrack = trackedOnTrack
            )
            ToolId.PREVIEW -> PreviewTool({ tool = ToolId.HUB }, true, pulseCoins, onSpendCoins, trackedOnTrack)
            ToolId.METADATA -> MetadataTool({ tool = ToolId.HUB }, true, pulseCoins, onSpendCoins, trackedOnTrack)
            ToolId.COVER -> CoverConverterTool({ tool = ToolId.HUB }, true, pulseCoins, onSpendCoins, trackedOnTrack, premiumMode = false)
            ToolId.COVER_PRO -> CoverConverterTool({ tool = ToolId.HUB }, true, pulseCoins, onSpendCoins, trackedOnTrack, premiumMode = false)
            ToolId.RECORDER -> VoiceRecorderTool({ tool = ToolId.HUB }, unlimited, pulseCoins, onSpendCoins, trackedOnTrack)
            ToolId.KARAOKE -> KaraokeTool({ tool = ToolId.HUB }, trackedOnTrack, state.preferences)
            ToolId.PULSE_PLAYER -> PulsePlayerScreen(
                membershipTier = membershipTier,
                preferences = state.preferences,
                ownerUnlimited = unlimited,
                onBack = { tool = ToolId.HUB },
                onUnlockFeature24h = onUnlockFeature24h,
                onTrack = trackedOnTrack,
                onCreatorAction = { action ->
                    when (action) {
                        PulseCreatorAction.ANALYZER -> tool = ToolId.ANALYZER
                        PulseCreatorAction.CUTTER -> tool = ToolId.CUTTER
                        PulseCreatorAction.CONVERTER -> onAudioConverter()
                        PulseCreatorAction.PITCH -> tool = ToolId.PITCH
                        PulseCreatorAction.VOCAL -> tool = ToolId.VOCAL
                        PulseCreatorAction.METADATA -> tool = ToolId.METADATA
                        PulseCreatorAction.MERGE -> tool = ToolId.MERGE
                        PulseCreatorAction.VIDEO_AUDIO -> tool = ToolId.VIDEO_AUDIO
                    }
                },
                onRequestPlan = onRequestPlan
            )
            ToolId.VIDEO_AUDIO -> VideoToAudioTool(
                onBack = { tool = ToolId.HUB },
                membershipTier = membershipTier,
                unlimited = unlimited,
                coins = pulseCoins,
                proUnlocked = true,
                onUnlock24h = { unlocked, unavailable -> onUnlockFeature24h(PulseFeaturePass.VIDEO_AUDIO_PRO, unlocked, unavailable) },
                onSpend = onSpendCoins,
                onWatchAd = onWatchRewardedAd,
                onTrack = trackedOnTrack
            )
            ToolId.VIDEO_CONVERTER -> VideoConverterTool(onBack = { tool = ToolId.HUB }, onTrack = trackedOnTrack)
            ToolId.MERGE -> MergeAudioTool(
                onBack = { tool = ToolId.HUB },
                membershipTier = membershipTier,
                coins = pulseCoins,
                unlimited = unlimited,
                onSpend = onSpendCoins,
                onWatchAd = onWatchRewardedAd,
                onTrack = trackedOnTrack
            )
            ToolId.MERGE_VIDEO -> MergeVideoTool(
                onBack = { tool = ToolId.HUB },
                membershipTier = membershipTier,
                coins = pulseCoins,
                unlimited = unlimited,
                onSpend = onSpendCoins,
                onWatchAd = onWatchRewardedAd,
                onTrack = trackedOnTrack
            )
            ToolId.PITCH -> PitchShiftTool(
                onBack = { tool = ToolId.HUB },
                unlimited = true,
                coins = pulseCoins,
                proUnlocked = true,
                onUnlock24h = { unlocked, unavailable -> onUnlockFeature24h(PulseFeaturePass.PITCH_PRO, unlocked, unavailable) },
                onSpend = onSpendCoins,
                onTrack = trackedOnTrack
            )
            ToolId.VOCAL -> VocalRemoverTool(
                onBack = { tool = ToolId.HUB },
                unlimited = unlimited,
                coins = pulseCoins,
                proUnlocked = hasFeatureAccess(membershipTier, state.preferences, PulseFeaturePass.VOCAL_REMOVER, unlimited) || membershipTier == MembershipTier.FREE,
                onUnlock24h = { unlocked, unavailable -> onUnlockFeature24h(PulseFeaturePass.VOCAL_REMOVER, unlocked, unavailable) },
                onSpend = onSpendCoins,
                onTrack = trackedOnTrack
            )
            ToolId.PULSE_TUNE -> PulseTuneScreen({ tool = ToolId.HUB }, state.preferences, membershipTier, unlimited, pulseCoins, trackedOnTrack)
            ToolId.TRANSCRIBE -> PulseTranscribeScreen({ tool = ToolId.HUB }, state.preferences, membershipTier, unlimited, pulseCoins, trackedOnTrack)
            ToolId.STEM_SPLITTER -> PulseStemSplitterScreen({ tool = ToolId.HUB }, state.preferences, unlimited || pulseCoins > 0, trackedOnTrack)
            ToolId.VOICE_CLEANER -> PulseVoiceCleanerScreen({ tool = ToolId.HUB }, state.preferences, unlimited || pulseCoins > 0, trackedOnTrack)
            ToolId.METRONOME -> PulseMetronomeScreen({ tool = ToolId.HUB }, state.preferences, trackedOnTrack)
            ToolId.BPM_KEY -> PulseBpmKeyScreen({ tool = ToolId.HUB }, state.preferences, trackedOnTrack)
            ToolId.NORMALIZER -> QuickAudioProcessorTool(QuickAudioKind.NORMALIZE, { tool = ToolId.HUB }, trackedOnTrack, premiumUseAvailable = unlimited || pulseCoins > 0)
            ToolId.FADE -> QuickAudioProcessorTool(QuickAudioKind.FADE, { tool = ToolId.HUB }, trackedOnTrack)
            ToolId.SILENCE -> QuickAudioProcessorTool(QuickAudioKind.SILENCE, { tool = ToolId.HUB }, trackedOnTrack)
            ToolId.CLIPPING -> ClippingDetectorTool({ tool = ToolId.HUB }, trackedOnTrack)
            ToolId.LOOP -> QuickAudioProcessorTool(QuickAudioKind.LOOP, { tool = ToolId.HUB }, trackedOnTrack)
            ToolId.IMG_COMPRESS -> ImageExtraTool(ImageExtraKind.COMPRESS, { tool = ToolId.HUB }, trackedOnTrack)
            ToolId.IMG_PALETTE -> ImageExtraTool(ImageExtraKind.PALETTE, { tool = ToolId.HUB }, trackedOnTrack)
            ToolId.IMG_WATERMARK -> ImageExtraTool(ImageExtraKind.WATERMARK, { tool = ToolId.HUB }, trackedOnTrack)
            ToolId.IMG_BATCH -> ImageExtraTool(ImageExtraKind.BATCH, { tool = ToolId.HUB }, trackedOnTrack)
            ToolId.IMAGE_RENAME_BATCH -> ImageBatchRenameTool({ tool = ToolId.HUB }, trackedOnTrack)
            ToolId.FILE_SPLIT -> FileUtilityTool(FileUtilityKind.SPLIT, { tool = ToolId.HUB }, trackedOnTrack)
            ToolId.TAG_BATCH -> FileUtilityTool(
                kind = FileUtilityKind.TAG_BATCH,
                onBack = { tool = ToolId.HUB },
                onTrack = trackedOnTrack,
                premiumUseAvailable = true,
                membershipTier = membershipTier,
                coins = pulseCoins,
                unlimited = unlimited,
                onSpendCoins = onSpendCoins,
                onWatchAd = onWatchRewardedAd
            )
            ToolId.RENAME_BATCH -> FileUtilityTool(FileUtilityKind.RENAME_BATCH, { tool = ToolId.HUB }, trackedOnTrack)
            ToolId.DUPLICATES -> FileUtilityTool(FileUtilityKind.DUPLICATES, { tool = ToolId.HUB }, trackedOnTrack, premiumUseAvailable = unlimited || pulseCoins > 0)
            ToolId.SONUS_LAB -> SonusLabScreen(membershipTier, pulseCoins, onSpendCoins, { tool = ToolId.HUB }, trackedOnTrack)
            ToolId.SONUS_AUTOMIX -> SonusAutoMixScreen(membershipTier, pulseCoins, onSpendCoins, { tool = ToolId.HUB }, trackedOnTrack)
        }
    }
}

@Composable
private fun ToolHub(
    artist: Artist,
    coins: Int,
    unlimited: Boolean,
    membershipTier: MembershipTier,
    preferences: UserPreferences,
    onAudioConverter: () -> Unit,
    onOpen: (ToolId) -> Unit,
    onSpendCoins: suspend (Int) -> Boolean,
    onWatchAd: () -> Unit,
    onTrack: (String, Boolean?, Long?) -> Unit,
    onRequestPlan: (MembershipTier) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var pendingCoinTool by remember { mutableStateOf<ToolCardInfo?>(null) }
    // 0.6.0: categorias viram uma linguagem visual fixa também para mini apps futuros.
    val groups = listOf(
        "ÁUDIO" to listOf(
            ToolCardInfo(ToolId.PITCH, "Alterar Tom", "Semitons + cents", Icons.Default.Tune, listOf(Color(0xFF11354B), Color(0xFF176A8C))),
            ToolCardInfo(ToolId.STEM_SPLITTER, "Stem Splitter", "Voz e instrumental", Icons.Default.CallSplit, listOf(Color(0xFF11354B), Color(0xFF176A8C)), MembershipTier.PRATA),
            ToolCardInfo(ToolId.VOICE_CLEANER, "Voice Cleaner", "Limpeza vocal", Icons.Default.CleaningServices, listOf(Color(0xFF11354B), Color(0xFF176A8C)), MembershipTier.PRATA),
            ToolCardInfo(ToolId.BPM_KEY, "BPM & Tom", "Análise musical", Icons.Default.Equalizer, listOf(Color(0xFF11354B), Color(0xFF176A8C))),
            ToolCardInfo(ToolId.NORMALIZER, "Normalizador", "Volume / loudness", Icons.Default.VolumeUp, listOf(Color(0xFF12384F), Color(0xFF1D7AA0)), MembershipTier.PRATA),
            ToolCardInfo(ToolId.FADE, "Fade In / Out", "Entrada e saída", Icons.Default.Waves, listOf(Color(0xFF12384F), Color(0xFF1D7AA0)), MembershipTier.FREE),
            ToolCardInfo(ToolId.SILENCE, "Silêncio Inteligente", "Limpar bordas", Icons.Default.ContentCut, listOf(Color(0xFF12384F), Color(0xFF1D7AA0)), MembershipTier.FREE),
            ToolCardInfo(ToolId.CLIPPING, "Detector Clipping", "Picos e distorção", Icons.Default.WarningAmber, listOf(Color(0xFF12384F), Color(0xFF1D7AA0)), MembershipTier.FREE),
            ToolCardInfo(ToolId.LOOP, "Criador de Loop", "Trecho repetível", Icons.Default.Loop, listOf(Color(0xFF12384F), Color(0xFF1D7AA0)), MembershipTier.FREE)
        ),
        "EDIÇÃO E ARQUIVO" to listOf(
            ToolCardInfo(ToolId.ANALYZER, "Analisador", "Qualidade e loudness", Icons.Default.GraphicEq, listOf(Color(0xFF3A214F), Color(0xFF704091))),
            ToolCardInfo(ToolId.CUTTER, "Cortador Pro", "Vídeo • multitreccho", Icons.Default.ContentCut, listOf(Color(0xFF3A214F), Color(0xFF704091)), MembershipTier.PRATA),
            ToolCardInfo(ToolId.PREVIEW, "Preview", "15s • 30s • 60s", Icons.Default.SlowMotionVideo, listOf(Color(0xFF3A214F), Color(0xFF704091))),
            ToolCardInfo(ToolId.METADATA, "Metadados", "Ler e editar tags", Icons.Default.Sell, listOf(Color(0xFF3A214F), Color(0xFF704091))),
            ToolCardInfo(ToolId.FILE_SPLIT, "Divisor de Áudio", "Dividir por duração", Icons.Default.CallSplit, listOf(Color(0xFF3A214F), Color(0xFF704091)), MembershipTier.FREE),
            ToolCardInfo(ToolId.TAG_BATCH, "Tags em Lote", "Editar vários arquivos", Icons.Default.Label, listOf(Color(0xFF3A214F), Color(0xFF704091)), MembershipTier.PRATA),
            ToolCardInfo(ToolId.RENAME_BATCH, "Renomeador em Lote", "Padrões automáticos", Icons.Default.DriveFileRenameOutline, listOf(Color(0xFF3A214F), Color(0xFF704091)), MembershipTier.FREE),
            ToolCardInfo(ToolId.DUPLICATES, "Localizar Duplicados", "Encontrar repetidos", Icons.Default.ContentCopy, listOf(Color(0xFF3A214F), Color(0xFF704091)), MembershipTier.PRATA)
        ),
        "IMAGEM E CAPA" to listOf(
            ToolCardInfo(ToolId.COVER, "Recorte Inteligente", "Adaptar proporção", Icons.Default.Crop, listOf(Color(0xFF6A3A10), Color(0xFFA96924)), MembershipTier.FREE),
            ToolCardInfo(ToolId.IMG_PALETTE, "Paleta de Cores", "HEX e cores", Icons.Default.Palette, listOf(Color(0xFF6A3A10), Color(0xFFA96924)), MembershipTier.FREE),
            ToolCardInfo(ToolId.COVER, "Verificador Capa", "Resolução e formato", Icons.Default.FactCheck, listOf(Color(0xFF6A3A10), Color(0xFFA96924)), MembershipTier.FREE),
            ToolCardInfo(ToolId.IMG_WATERMARK, "Marca d'água", "Texto ou PNG", Icons.Default.BrandingWatermark, listOf(Color(0xFF6A3A10), Color(0xFFA96924)), MembershipTier.FREE)
        )
    )
    pendingCoinTool?.let { info ->
        val required = info.requiredTier ?: MembershipTier.PRATA
        AlertDialog(
            onDismissRequest = { pendingCoinTool = null },
            title = { Text("Liberar ${info.title}") },
            text = { Text("Quando uma ferramenta precisar de moeda, um anúncio recompensado pode liberar +1 Moeda SONUS quando elegível.") },
            confirmButton = { TextButton(onClick = { onWatchAd(); pendingCoinTool = null }) { Text("Assistir e ganhar +1 moeda") } },
            dismissButton = { TextButton(onClick = { pendingCoinTool = null }) { Text("Cancelar") } }
        )
    }
    var selectedStudioCategory by rememberSaveable { mutableStateOf(groups.first().first) }
    val visibleStudioGroupRaw = groups.firstOrNull { it.first == selectedStudioCategory } ?: groups.first()
    val visibleStudioGroup = visibleStudioGroupRaw.first to visibleStudioGroupRaw.second.sortedBy { it.requiredTier?.ordinal ?: MembershipTier.FREE.ordinal }
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(11.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 30.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("STUDIO SONUS", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Sua central de áudio e criação no SONUS.", color = MaterialTheme.colorScheme.onSurface.copy(alpha = .62f))
                }
                Surface(shape=RoundedCornerShape(14.dp),color=MaterialTheme.colorScheme.primaryContainer){Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal=10.dp,vertical=7.dp)) {
                    Icon(Icons.Default.WorkspacePremium, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(5.dp))
                    Text(if(unlimited) "∞" else "$coins/${monthlyToolUsageAllowance(membershipTier)}", fontSize=10.sp, fontWeight=FontWeight.ExtraBold)
                }}
            }
        }
        item {
            val categoryAccent = mapOf(
                "ÁUDIO" to Color(0xFF35BFEA),
                "EDIÇÃO E ARQUIVO" to Color(0xFFA87BE8),
                "IMAGEM E CAPA" to Color(0xFFE0A44C)
            )
            val compactLabel = mapOf(
                "ÁUDIO" to "Áudio",
                "EDIÇÃO E ARQUIVO" to "Edição/Arquivo",
                "IMAGEM E CAPA" to "Imagem/Capa"
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                groups.map { it.first }.forEach { category ->
                    val selected = selectedStudioCategory == category
                    val accent = categoryAccent[category] ?: MaterialTheme.colorScheme.primary
                    Surface(
                        modifier = Modifier.weight(1f).clickable { selectedStudioCategory = category },
                        shape = RoundedCornerShape(999.dp),
                        color = if(selected) accent.copy(alpha=.24f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.50f),
                        border = BorderStroke(1.dp, accent.copy(alpha=if(selected).82f else .30f))
                    ) {
                        Text(
                            compactLabel[category] ?: category,
                            modifier = Modifier.padding(horizontal=3.dp, vertical=8.dp),
                            textAlign = TextAlign.Center, maxLines=1, fontSize=9.sp, fontWeight=FontWeight.ExtraBold,
                            color = if(selected) accent else MaterialTheme.colorScheme.onSurface.copy(alpha=.76f)
                        )
                    }
                }
            }
        }
        if (membershipTier == MembershipTier.FREE && coins < 10) {
            item {
                OutlinedButton(onClick = { PulseHaptics.perform(context, preferences, PulseHapticEvent.TAP); onWatchAd() }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.SmartDisplay, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Assistir anúncio • +1 moeda (máx. 10)")
                }
            }
        }
        listOf(visibleStudioGroup).forEach { (category, tools) ->
            item {
                Text(category, fontSize=11.sp, letterSpacing=1.1.sp, fontWeight=FontWeight.Black, color=MaterialTheme.colorScheme.primary, modifier=Modifier.padding(top=5.dp, start=2.dp))
            }
            item {
                val rows = (tools.size + 2) / 3
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    modifier = Modifier.fillMaxWidth().height((rows * 88).dp),
                    userScrollEnabled = false,
                    horizontalArrangement = Arrangement.spacedBy(7.dp),
                    verticalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    items(tools) { info ->
                        CompactToolTile(
                            title = info.title, subtitle = info.subtitle, colors = info.colors, icon = info.icon, plan = info.requiredTier,
                            onClick = {
                                PulseHaptics.perform(context, preferences, PulseHapticEvent.TAP)
                                onTrack(info.title, null, null)
                                val action = {
                                    when (info.title) {
                                        "Conversor de Áudio" -> onAudioConverter()
                                        else -> info.id?.let(onOpen)
                                    }
                                }
                                // Code97: abrir uma ferramenta nunca consome moeda. Cada ferramenta
                                // aplica sua própria regra somente na operação tarifada (lote, exportação etc.).
                                action()
                            }
                        )
                    }
                }
            }
        }
        item {
            Text(
                "O arquivo original nunca é alterado. Processamentos e exportações criam novas cópias.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = .52f),
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun PremiumUsagePanel(
    coins: Int,
    unlimited: Boolean,
    tier: MembershipTier,
    rewardEligible: Boolean,
    onWatchAd: () -> Unit
) {
    val context = LocalContext.current
    val allowance = monthlyToolUsageAllowance(tier)
    val planLabel = when (tier) {
        MembershipTier.FREE -> "FREE"
        MembershipTier.BRONZE, MembershipTier.PRATA -> "Prata"
        MembershipTier.OURO -> "Ouro"
        MembershipTier.DIAMANTE -> "Diamante"
    }
    val progress = if (unlimited || allowance == Int.MAX_VALUE) 1f else (coins.toFloat() / allowance.coerceAtLeast(1).toFloat()).coerceIn(0f, 1f)
    val today = LocalDate.now()
    val nextCycle = YearMonth.from(today).plusMonths(1).atDay(1)
    val renewDays = ChronoUnit.DAYS.between(today, nextCycle).coerceAtLeast(1)
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = .72f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .16f))
    ) {
        Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.WorkspacePremium, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text("Moedas SONUS", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                    Text("Plano $planLabel", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .60f))
                }
                Text(
                    if (unlimited || allowance == Int.MAX_VALUE) "∞" else "$coins / $allowance",
                    fontWeight = FontWeight.Black,
                    fontSize = 18.sp
                )
            }
            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
            Text(
                if (unlimited || allowance == Int.MAX_VALUE) "Ferramentas Premium sem limite mensal."
                else if (rewardEligible) "1 anúncio recompensado libera +1 Moeda SONUS quando a recompensa estiver disponível."
                else "O saldo renova em $renewDays dia(s), no próximo ciclo mensal.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = .62f)
            )
            if (rewardEligible) {
                if (coins < 1) {
                    OutlinedButton(
                        onClick = { onWatchAd() },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.SmartDisplay, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Assistir anúncio • +1 moeda (máx. 10)")
                    }
                } else {
                    Text(
                        "Moedas disponíveis • elas são cobradas somente nas ações tarifadas de cada ferramenta.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun HighlightsHub(
    coins: Int, unlimited: Boolean, rewardEligible: Boolean,
    onAudioConverter: () -> Unit, onOpenRecorder: () -> Unit,
    onOpenVocal: () -> Unit, onOpenTune: () -> Unit, onOpenTranscribe: () -> Unit,
    onOpenSonusLab: () -> Unit, onOpenAutoMix: () -> Unit, onOpenImage: () -> Unit, onOpenVideoAudio: () -> Unit,
    onOpenMergeAudio: () -> Unit, onOpenMergeVideo: () -> Unit, onOpenTool: (ToolId) -> Unit,
    onOpenBlackBox: () -> Unit,
    membershipTier: MembershipTier,
    preferences: UserPreferences, onWatchAd: () -> Unit, onTrack: (String, Boolean?, Long?) -> Unit,
    unreadNotifications: Int, onNotifications: () -> Unit,
    onRequestPlan: (MembershipTier) -> Unit,
    onSpendCoins: suspend (Int) -> Boolean,
    onOpenLrcEditor: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var pendingRewardAction by remember { mutableStateOf<(() -> Unit)?>(null) }
    var pendingRewardName by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(coins, pendingRewardAction) {
        val action = pendingRewardAction
        if (membershipTier == MembershipTier.FREE && coins > 0 && action != null) {
            if (onSpendCoins(1)) {
                pendingRewardAction = null
                pendingRewardName?.let { onTrack(it, null, null) }
                pendingRewardName = null
                action()
            }
        }
    }
    data class HItem(
        val title: String,
        val subtitle: String,
        val art: String,
        val colors: List<Color>,
        val tier: MembershipTier? = null,
        val action: () -> Unit
    )
    fun launch(name: String, tier: MembershipTier? = null, action: () -> Unit) {
        PulseHaptics.perform(context, preferences, PulseHapticEvent.TAP)
        // code97: abrir ferramenta nunca consome moeda. A cobrança acontece somente
        // quando o usuário executa a ação tarifada dentro da própria ferramenta.
        onTrack(name, null, null)
        action()
    }


    // Build Fix 4: imagem primeiro, áudio logo abaixo, especiais no centro e vídeo no final.
    val items = listOf(
        HItem("Imagem Convert", "Formato • tamanho • lote", "image_convert", listOf(Color(0xFF145B46), Color(0xFF33A678)), MembershipTier.FREE) { launch("Imagem Convert", MembershipTier.FREE, onOpenImage) },
        HItem("Renomear Imagens", "Lote • nomes • sequência", "image_rename", listOf(Color(0xFF245C43), Color(0xFF66A85E))) { launch("Renomear imagens em lote") { onOpenTool(ToolId.IMAGE_RENAME_BATCH) } },
        HItem("Conversor Áudio", "Formatos • qualidade", "audio_convert", listOf(Color(0xFF7B1E2B), Color(0xFFD94A45))) { launch("Conversor de áudio", null, onAudioConverter) },
        HItem("Mesclar Áudio", "PRO • 1 moeda / 5", "audio_merge", listOf(Color(0xFF8B2334), Color(0xFFE45C4B)), MembershipTier.PRATA) { launch("Mesclar Áudio", MembershipTier.PRATA, onOpenMergeAudio) },
        HItem("Gravador de Voz", "REC • voz • waveform", "recorder", listOf(Color(0xFF74172F), Color(0xFFCF3E58)), MembershipTier.FREE) { launch("Gravador de Voz", MembershipTier.FREE, onOpenRecorder) },
        HItem("Afinador", "Afinação precisa", "tuner", listOf(Color(0xFF8B2D24), Color(0xFFE26545)), MembershipTier.FREE) { launch("Afinador", MembershipTier.FREE, onOpenTune) },
        HItem("AutoMix", "PRO • mix automático", "automix", listOf(Color(0xFF6E2438), Color(0xFFC94B5C)), MembershipTier.PRATA) { launch("SONUS AutoMix", MembershipTier.PRATA, onOpenAutoMix) },
        HItem("Tags em Lote", "PRO • 1 moeda / 5", "tag_batch", listOf(Color(0xFF791E2E), Color(0xFFD84B55)), MembershipTier.PRATA) { launch("Tags em Lote", MembershipTier.PRATA) { onOpenTool(ToolId.TAG_BATCH) } },
        HItem("Caixa Preta SONUS", "Gravação contínua • local", "black_box", listOf(Color(0xFF050609), Color(0xFF15171C)), MembershipTier.PRATA) { launch("Caixa Preta SONUS", MembershipTier.PRATA, onOpenBlackBox) },
        HItem("Editor LRC", "Letra • tempo • sincronização", "lrc_editor", listOf(Color(0xFF24252B), Color(0xFF555862))) { launch("Editor LRC", MembershipTier.FREE, onOpenLrcEditor) },
        HItem("Vídeo → Áudio", "Extrair trilha sonora", "video_audio", listOf(Color(0xFF155080), Color(0xFF3B9CD5))) { launch("Vídeo → Áudio", null, onOpenVideoAudio) },
        HItem("Mesclar Vídeo", "PRO • 1 moeda / 5", "video_merge", listOf(Color(0xFF244E89), Color(0xFF638ED9)), MembershipTier.PRATA) { launch("Mesclar Vídeo", MembershipTier.PRATA, onOpenMergeVideo) },
        HItem("Cortador Pro", "PRO • vídeo multitreccho", "cutter", listOf(Color(0xFF274D7A), Color(0xFF4F91C8)), MembershipTier.PRATA) { launch("Cortador Pro", MembershipTier.PRATA) { onOpenTool(ToolId.CUTTER) } },
        HItem("Conversor de Vídeo", "Formato • FPS • resolução", "video_convert", listOf(Color(0xFF1A5C8C), Color(0xFF4EA8E3)), MembershipTier.FREE) { launch("Conversor de Vídeo", MembershipTier.FREE) { onOpenTool(ToolId.VIDEO_CONVERTER) } }
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(top = 15.dp, bottom = 30.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("DESTAQUES SONUS", fontSize = 24.sp, fontWeight = FontWeight.Black)
                    Text("Ferramentas essenciais, organizadas para chegar mais rápido ao que importa.", fontSize = 9.5.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .58f))
                }
                Surface(shape = RoundedCornerShape(14.dp), color = Color.White.copy(alpha=.07f), modifier = Modifier.clickable(enabled = rewardEligible && coins < 10, onClick = onWatchAd)) {
                    Row(Modifier.padding(horizontal=10.dp, vertical=7.dp), verticalAlignment=Alignment.CenterVertically) {
                        Icon(Icons.Default.MonetizationOn, "Moedas SONUS", tint=Color(0xFFFFD76A), modifier=Modifier.size(18.dp)); Spacer(Modifier.width(5.dp));
                        Text("Moedas", fontWeight=FontWeight.Bold, fontSize=9.sp); Spacer(Modifier.width(5.dp)); Text(if (unlimited) "∞" else coins.toString(), fontWeight=FontWeight.Black, fontSize=12.sp)
                    }
                }
            }
        }
        item {
            val rows = (items.size + 1) / 2
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.fillMaxWidth().height((rows * 90).dp),
                userScrollEnabled = false,
                horizontalArrangement = Arrangement.spacedBy(9.dp),
                verticalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                items(items) { info ->
                    GlossyHighlightTile(info.title, info.subtitle, info.art, info.colors, info.tier, membershipTier, unlimited || coins > 0, info.action)
                }
            }
        }
        if (membershipTier == MembershipTier.FREE && coins < 10) {
            item {
                OutlinedButton(onClick = onWatchAd, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.SmartDisplay, null); Spacer(Modifier.width(7.dp)); Text("Assistir anúncio • +1 moeda (máx. 10)")
                }
            }
        }
    }
}

@Composable
private fun GlossyHighlightTile(
    title: String,
    subtitle: String,
    art: String,
    colors: List<Color>,
    requiredTier: MembershipTier?,
    tier: MembershipTier,
    usageAvailable: Boolean,
    onClick: () -> Unit
) {
    // Code97: o selo informa a categoria do recurso; a cobrança/limite é aplicada dentro de cada ferramenta.
    val locked = false
    Surface(
        modifier = Modifier.fillMaxWidth().height(81.dp).clip(RoundedCornerShape(20.dp)).clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        color = Color.Transparent,
        border = BorderStroke(1.dp, Color.White.copy(alpha = .13f)),
        tonalElevation = 2.dp
    ) {
        Box(
            Modifier.background(
                Brush.linearGradient(
                    listOf(
                        colors.first(),
                        colors.last().copy(alpha = .96f)
                    )
                )
            )
        ) {
            // Acabamento acetinado: cor plena, sem vidro, reflexo ou cápsula atrás do texto.
            Row(
                Modifier.fillMaxSize().padding(horizontal = 11.dp, vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    modifier = Modifier.size(45.dp),
                    shape = RoundedCornerShape(14.dp),
                    color = Color.Black.copy(alpha = .13f),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = .17f))
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        SonusHighlightIllustration(art = art, accent = colors.last())
                    }
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                    Text(title, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 11.sp, lineHeight = 12.5.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(3.dp))
                    Text(subtitle, color = Color.White.copy(alpha = .84f), fontSize = 8.sp, lineHeight = 9.5.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
            }
            // Code98: selo discreto de acesso. Nada de bolinhas verde/vermelha que pareçam online/offline.
            val premium = requiredTier != null && requiredTier != MembershipTier.FREE
            Surface(
                modifier = Modifier.align(Alignment.TopEnd).padding(6.dp),
                shape = RoundedCornerShape(8.dp),
                color = Color.Black.copy(alpha = .28f),
                border = BorderStroke(1.dp, Color.White.copy(alpha = .14f))
            ) {
                Row(Modifier.padding(horizontal=5.dp, vertical=2.dp), verticalAlignment=Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (premium) Icons.Default.AutoAwesome else Icons.Default.LockOpen,
                        contentDescription = null,
                        tint = if (premium) Color(0xFFFFD66B) else Color.White.copy(alpha=.90f),
                        modifier = Modifier.size(9.dp)
                    )
                    Spacer(Modifier.width(2.dp))
                    Text(if (premium) "PRO" else "FREE", color = Color.White.copy(alpha=.92f), fontSize = 6.5.sp, fontWeight = FontWeight.Black)
                }
            }
        }
    }
}

@Composable
private fun SonusHighlightIllustration(art: String, accent: Color) {
    Canvas(Modifier.size(36.dp)) {
        val w = size.width
        val h = size.height
        val white = Color.White.copy(alpha = .96f)
        val soft = Color.White.copy(alpha = .52f)
        val glow = accent.copy(alpha = .92f)
        val stroke = (w * .065f).coerceAtLeast(1.6f)
        fun line(a: Offset, b: Offset, color: Color = white, width: Float = stroke) = drawLine(color, a, b, width, StrokeCap.Round)
        fun wave(y: Float, from: Float, to: Float, phase: Float, color: Color = white) {
            val p = Path()
            var x = from
            while (x <= to) {
                val n = (x - from) / (to - from).coerceAtLeast(1f)
                val yy = y + kotlin.math.sin(n * kotlin.math.PI.toFloat() * 4f + phase) * h * .085f
                if (x == from) p.moveTo(x, yy) else p.lineTo(x, yy)
                x += w / 20f
            }
            drawPath(p, color, style = Stroke(stroke, cap = StrokeCap.Round))
        }
        when (art) {
            "audio_convert" -> {
                wave(h*.56f, w*.12f, w*.67f, 0f)
                drawCircle(glow, w*.12f, Offset(w*.72f,h*.35f))
                line(Offset(w*.72f,h*.35f), Offset(w*.72f,h*.70f))
                line(Offset(w*.72f,h*.35f), Offset(w*.88f,h*.30f))
                drawCircle(white, w*.075f, Offset(w*.86f,h*.67f))
                line(Offset(w*.18f,h*.24f), Offset(w*.42f,h*.24f), soft)
                line(Offset(w*.42f,h*.24f), Offset(w*.36f,h*.17f), soft)
                line(Offset(w*.42f,h*.24f), Offset(w*.36f,h*.31f), soft)
            }
            "audio_merge" -> {
                wave(h*.32f,w*.08f,w*.46f,0f,soft); wave(h*.70f,w*.08f,w*.46f,1.2f,soft)
                line(Offset(w*.44f,h*.32f),Offset(w*.64f,h*.51f),glow)
                line(Offset(w*.44f,h*.70f),Offset(w*.64f,h*.51f),glow)
                wave(h*.51f,w*.62f,w*.92f,.5f,white)
            }
            "recorder" -> {
                drawRoundRect(glow, Offset(w*.34f,h*.10f), Size(w*.32f,h*.48f), CornerRadius(w*.16f,w*.16f))
                drawRoundRect(Color.Black.copy(alpha=.24f), Offset(w*.40f,h*.16f), Size(w*.20f,h*.34f), CornerRadius(w*.10f,w*.10f))
                drawArc(white, 0f, 180f, false, Offset(w*.23f,h*.30f), Size(w*.54f,h*.42f), style=Stroke(stroke, cap=StrokeCap.Round))
                line(Offset(w*.50f,h*.70f),Offset(w*.50f,h*.86f)); line(Offset(w*.34f,h*.86f),Offset(w*.66f,h*.86f))
            }
            "tuner" -> {
                drawArc(white, 205f, 130f, false, Offset(w*.14f,h*.20f), Size(w*.72f,h*.72f), style=Stroke(stroke, cap=StrokeCap.Round))
                line(Offset(w*.50f,h*.67f),Offset(w*.68f,h*.30f),glow,stroke*1.15f)
                drawCircle(white,w*.06f,Offset(w*.50f,h*.67f))
                listOf(.25f,.38f,.62f,.75f).forEach { x -> line(Offset(w*x,h*.30f),Offset(w*x,h*.36f),soft,stroke*.65f) }
            }
            "automix" -> {
                wave(h*.37f,w*.07f,w*.93f,0f,white); wave(h*.64f,w*.07f,w*.93f,2.2f,glow)
                drawCircle(Color.White.copy(alpha=.9f),w*.07f,Offset(w*.50f,h*.50f))
                drawCircle(glow,w*.035f,Offset(w*.50f,h*.50f))
            }
            "image_convert" -> {
                drawRoundRect(white, Offset(w*.12f,h*.16f), Size(w*.62f,h*.60f), CornerRadius(w*.08f,w*.08f), style=Stroke(stroke))
                val p=Path().apply{moveTo(w*.18f,h*.66f);lineTo(w*.34f,h*.46f);lineTo(w*.46f,h*.57f);lineTo(w*.59f,h*.39f);lineTo(w*.70f,h*.66f)}
                drawPath(p,glow,style=Stroke(stroke,cap=StrokeCap.Round))
                drawCircle(white,w*.055f,Offset(w*.28f,h*.31f))
                line(Offset(w*.72f,h*.27f),Offset(w*.90f,h*.27f)); line(Offset(w*.90f,h*.27f),Offset(w*.84f,h*.20f)); line(Offset(w*.90f,h*.27f),Offset(w*.84f,h*.34f))
            }
            "image_rename" -> {
                drawRoundRect(white, Offset(w*.10f,h*.16f), Size(w*.58f,h*.62f), CornerRadius(w*.07f,w*.07f), style=Stroke(stroke))
                drawCircle(glow,w*.055f,Offset(w*.25f,h*.31f))
                val mountain=Path().apply{moveTo(w*.17f,h*.66f);lineTo(w*.31f,h*.49f);lineTo(w*.43f,h*.59f);lineTo(w*.58f,h*.40f);lineTo(w*.64f,h*.66f)}
                drawPath(mountain,soft,style=Stroke(stroke*.85f,cap=StrokeCap.Round))
                line(Offset(w*.73f,h*.34f),Offset(w*.90f,h*.34f),glow)
                line(Offset(w*.73f,h*.50f),Offset(w*.87f,h*.50f),white)
                line(Offset(w*.73f,h*.66f),Offset(w*.84f,h*.66f),soft)
                line(Offset(w*.86f,h*.72f),Offset(w*.93f,h*.79f),glow,stroke*.9f)
                line(Offset(w*.93f,h*.79f),Offset(w*.97f,h*.72f),glow,stroke*.9f)
            }
            "tag_batch" -> {
                repeat(3){i ->
                    val y=h*(.20f+i*.20f); val p=Path().apply{moveTo(w*.16f,y);lineTo(w*.64f,y);lineTo(w*.82f,y+h*.10f);lineTo(w*.64f,y+h*.20f);lineTo(w*.16f,y+h*.20f);close()}
                    drawPath(p, if(i==1) glow else white.copy(alpha=.78f), style=Stroke(stroke,cap=StrokeCap.Round))
                    drawCircle(soft,w*.025f,Offset(w*.58f,y+h*.10f))
                }
            }
            "metadata" -> {
                val p=Path().apply{moveTo(w*.12f,h*.22f);lineTo(w*.60f,h*.22f);lineTo(w*.88f,h*.50f);lineTo(w*.60f,h*.78f);lineTo(w*.12f,h*.78f);close()}
                drawPath(p,white,style=Stroke(stroke,cap=StrokeCap.Round)); drawCircle(glow,w*.055f,Offset(w*.59f,h*.35f))
                line(Offset(w*.23f,h*.43f),Offset(w*.52f,h*.43f),soft); line(Offset(w*.23f,h*.57f),Offset(w*.60f,h*.57f),soft)
            }
            "cover" -> {
                drawRoundRect(white, Offset(w*.15f,h*.14f), Size(w*.58f,h*.66f), CornerRadius(w*.07f,w*.07f), style=Stroke(stroke))
                drawCircle(glow,w*.075f,Offset(w*.31f,h*.34f)); line(Offset(w*.23f,h*.68f),Offset(w*.40f,h*.50f),soft);line(Offset(w*.40f,h*.50f),Offset(w*.59f,h*.67f),soft)
                line(Offset(w*.62f,h*.67f),Offset(w*.72f,h*.77f),white);line(Offset(w*.72f,h*.77f),Offset(w*.90f,h*.53f),white)
            }
            "video_audio" -> {
                drawRoundRect(white, Offset(w*.08f,h*.20f), Size(w*.56f,h*.54f), CornerRadius(w*.06f,w*.06f), style=Stroke(stroke))
                val tri=Path().apply{moveTo(w*.29f,h*.34f);lineTo(w*.29f,h*.60f);lineTo(w*.50f,h*.47f);close()};drawPath(tri,glow)
                wave(h*.62f,w*.62f,w*.95f,.3f,white)
            }
            "video_merge" -> {
                drawRoundRect(white, Offset(w*.10f,h*.18f), Size(w*.50f,h*.48f), CornerRadius(w*.06f,w*.06f), style=Stroke(stroke))
                drawRoundRect(white, Offset(w*.38f,h*.34f), Size(w*.50f,h*.48f), CornerRadius(w*.06f,w*.06f), style=Stroke(stroke))
                line(Offset(w*.50f,h*.21f),Offset(w*.74f,h*.21f),glow);line(Offset(w*.74f,h*.21f),Offset(w*.68f,h*.14f),glow);line(Offset(w*.74f,h*.21f),Offset(w*.68f,h*.28f),glow)
            }
            "video_convert" -> {
                drawRoundRect(white, Offset(w*.08f,h*.20f), Size(w*.54f,h*.56f), CornerRadius(w*.08f,w*.08f), style=Stroke(stroke))
                val tri=Path().apply{moveTo(w*.27f,h*.35f);lineTo(w*.27f,h*.61f);lineTo(w*.48f,h*.48f);close()}
                drawPath(tri,glow)
                line(Offset(w*.64f,h*.34f),Offset(w*.90f,h*.34f),white)
                line(Offset(w*.90f,h*.34f),Offset(w*.83f,h*.27f),white); line(Offset(w*.90f,h*.34f),Offset(w*.83f,h*.41f),white)
                line(Offset(w*.88f,h*.66f),Offset(w*.62f,h*.66f),glow)
                line(Offset(w*.62f,h*.66f),Offset(w*.69f,h*.59f),glow); line(Offset(w*.62f,h*.66f),Offset(w*.69f,h*.73f),glow)
            }
            "cutter" -> {
                drawCircle(white,w*.12f,Offset(w*.28f,h*.32f),style=Stroke(stroke)); drawCircle(white,w*.12f,Offset(w*.28f,h*.70f),style=Stroke(stroke))
                line(Offset(w*.38f,h*.40f),Offset(w*.86f,h*.16f),white);line(Offset(w*.38f,h*.62f),Offset(w*.86f,h*.86f),glow)
                drawCircle(white,w*.045f,Offset(w*.46f,h*.51f))
            }
            "black_box" -> {
                drawRoundRect(white,Offset(w*.17f,h*.18f),Size(w*.66f,h*.64f),CornerRadius(w*.08f),style=Stroke(stroke))
                drawCircle(glow,w*.12f,Offset(w*.50f,h*.50f),style=Stroke(stroke))
                line(Offset(w*.50f,h*.38f),Offset(w*.50f,h*.62f),white,stroke*.7f)
                line(Offset(w*.38f,h*.50f),Offset(w*.62f,h*.50f),soft,stroke*.7f)
            }
            "lrc_editor" -> {
                drawRoundRect(white,Offset(w*.16f,h*.18f),Size(w*.48f,h*.62f),CornerRadius(w*.05f),style=Stroke(stroke))
                line(Offset(w*.24f,h*.34f),Offset(w*.54f,h*.34f),soft,stroke*.7f); line(Offset(w*.24f,h*.48f),Offset(w*.50f,h*.48f),soft,stroke*.7f); line(Offset(w*.24f,h*.62f),Offset(w*.46f,h*.62f),soft,stroke*.7f)
                drawCircle(glow,w*.17f,Offset(w*.72f,h*.60f),style=Stroke(stroke)); line(Offset(w*.72f,h*.60f),Offset(w*.72f,h*.50f),white,stroke*.8f); line(Offset(w*.72f,h*.60f),Offset(w*.80f,h*.64f),white,stroke*.8f)
            }
        }
    }
}

@Composable
private fun FeaturedToolTile(
    title: String,
    subtitle: String,
    colors: List<Color>,
    onClick: () -> Unit,
    customImage: Boolean,
    icon: ImageVector,
    animatedRgb: Boolean = false,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.height(118.dp).clip(RoundedCornerShape(22.dp)).clickable(onClick = onClick),
        shape = RoundedCornerShape(24.dp),
        color = Color.Transparent,
        border = BorderStroke(1.dp, Color.White.copy(alpha = .11f))
    ) {
        Column(
            Modifier.background(Brush.linearGradient(colors)).padding(horizontal = 10.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            when {
                customImage -> Image(
                    painterResource(R.drawable.tool_audio_converter),
                    null,
                    modifier = Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)),
                    contentScale = ContentScale.Crop
                )
                animatedRgb -> RgbKaraokeIcon(icon)
                else -> FeaturedIcon(icon)
            }
            Text(title, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, maxLines = 2)
            Text(subtitle, color = Color.White.copy(alpha = .78f), fontSize = 9.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun FeaturedIcon(icon: ImageVector) {
    Surface(
        modifier = Modifier.size(44.dp),
        shape = RoundedCornerShape(15.dp),
        color = Color.Black.copy(alpha = .20f),
        border = BorderStroke(1.dp, Color.White.copy(alpha = .22f))
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = Color.White, modifier = Modifier.size(26.dp))
        }
    }
}

@Composable
private fun RgbKaraokeIcon(icon: ImageVector) {
    val transition = rememberInfiniteTransition(label = "karaoke-rgb")
    val rotation by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(animation = tween(2600, easing = LinearEasing)),
        label = "karaoke-rgb-rotation"
    )
    Box(Modifier.size(48.dp), contentAlignment = Alignment.Center) {
        Canvas(
            Modifier.fillMaxSize().graphicsLayer { rotationZ = rotation }
        ) {
            drawCircle(
                brush = Brush.sweepGradient(
                    listOf(
                        Color(0xFFFF3B6B), Color(0xFFFFB02E), Color(0xFF62E36A),
                        Color(0xFF22C7FF), Color(0xFF7C5CFF), Color(0xFFFF4FD8), Color(0xFFFF3B6B)
                    )
                ),
                style = Stroke(width = 5.dp.toPx())
            )
        }
        Surface(
            modifier = Modifier.size(40.dp),
            shape = RoundedCornerShape(22.dp),
            color = Color.Black.copy(alpha = .38f),
            border = BorderStroke(1.dp, Color.White.copy(alpha = .28f))
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = Color.White, modifier = Modifier.size(24.dp))
            }
        }
    }
}

@Composable
private fun CompactToolTile(
    title: String,
    subtitle: String,
    colors: List<Color>,
    icon: ImageVector,
    plan: MembershipTier? = null,
    onClick: () -> Unit
) {
    val iconTint = when {
        title.contains("Vídeo") -> Color(0xFF48C7FF)
        title.contains("Mesclar") -> Color(0xFF62E6C7)
        title.contains("Tom") -> Color(0xFFFFC857)
        title.contains("Stem") -> Color(0xFFA78BFA)
        title.contains("Cleaner") -> Color(0xFF5EEAD4)
        title.contains("Metrônomo") -> Color(0xFFFF7A90)
        title.contains("BPM") -> Color(0xFF38BDF8)
        title.contains("Analisador") -> Color(0xFF60A5FA)
        title.contains("Cortador") -> Color(0xFFF472B6)
        title.contains("Preview") -> Color(0xFFC084FC)
        title.contains("Metadados") -> Color(0xFFFBBF24)
        title.contains("Capa") -> Color(0xFFFB923C)
        title.contains("YouTube") -> Color(0xFFFF5A5A)
        else -> Color(0xFF67E8F9)
    }
    val planBadge = when (plan?.let(::commercialTier)) {
        MembershipTier.PRATA -> "PRATA"
        MembershipTier.OURO -> "OURO"
        MembershipTier.DIAMANTE -> "DIAMANTE"
        else -> "FREE"
    }
    val badgeColor = when (planBadge) {
        "BRONZE" -> Color(0xFFB87333)
        "PRATA" -> Color(0xFFC8CED8)
        "OURO" -> Color(0xFFFFC94A)
        "DIAMANTE" -> Color(0xFF69E6FF)
        else -> Color(0xFF3F86FF)
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .height(81.dp)
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        color = Color.Transparent,
        border = BorderStroke(1.dp, Color.White.copy(alpha = .09f))
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.linearGradient(colors))
                .padding(horizontal = 7.dp, vertical = 7.dp)
        ) {
            Column(
                Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Surface(
                    modifier = Modifier.size(35.dp),
                    shape = RoundedCornerShape(12.dp),
                    color = Color.Black.copy(alpha = .18f),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = .18f))
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(icon, null, tint = iconTint, modifier = Modifier.size(22.dp))
                    }
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    title,
                    color = Color.White,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 10.4.sp,
                    lineHeight = 11.sp,
                    maxLines = 2,
                    textAlign = TextAlign.Center
                )
                Text(
                    subtitle,
                    color = Color.White.copy(alpha = .72f),
                    fontSize = 7.5.sp,
                    lineHeight = 8.1.sp,
                    maxLines = 1,
                    textAlign = TextAlign.Center
                )
            }

            Surface(
                modifier = Modifier.align(Alignment.TopEnd),
                shape = RoundedCornerShape(6.dp),
                color = badgeColor.copy(alpha = .92f),
                border = BorderStroke(1.dp, Color.White.copy(alpha = .28f))
            ) {
                Text(
                    planBadge,
                    color = if (planBadge == "PRATA" || planBadge == "OURO") Color(0xFF161616) else Color.White,
                    fontSize = 5.8.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                )
            }
        }
    }
}

@Composable
private fun ToolHeader(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Voltar") }
        Text(title, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
private fun ToolIntroCard(
    title: String,
    description: String,
    bullets: List<String>,
    colors: List<Color>
) {
    Surface(shape = RoundedCornerShape(22.dp), color = Color.Transparent, border = BorderStroke(1.dp, Color.White.copy(alpha = .10f))) {
        Column(
            Modifier.fillMaxWidth().background(Brush.linearGradient(colors)).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            Text(title, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
            Text(description, color = Color.White.copy(alpha = .78f), style = MaterialTheme.typography.bodySmall)
            bullets.forEach { Text("• $it", color = Color.White.copy(alpha = .72f), style = MaterialTheme.typography.labelSmall) }
            Text("🔒 Processamento local • original preservado", color = Color.White.copy(alpha = .62f), style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun AudioAnalyzerTool(onBack: () -> Unit, onTrack: (String, Boolean?, Long?) -> Unit, onAudioConverter: () -> Unit, onCutter: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var analysis by remember { mutableStateOf<AudioDeepAnalysis?>(null) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            busy = true; error = null; val started = System.currentTimeMillis()
            val result = withContext(Dispatchers.IO) { runCatching { AudioToolEngine.analyze(context, uri) } }
            busy = false
            analysis = result.getOrNull(); error = result.exceptionOrNull()?.message
            onTrack("Analisador: concluir", result.isSuccess, System.currentTimeMillis() - started)
        }
    }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), contentPadding = PaddingValues(bottom = 28.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { ToolHeader("Analisador de áudio", onBack) }
        item { ToolIntroCard(
            "Diagnóstico técnico de verdade",
            "Meça loudness, pico, clipping, dinâmica e a forma de onda antes de distribuir ou processar sua música.",
            listOf("LUFS e true peak quando disponíveis", "Crest factor e clipping", "Recomendações práticas do arquivo"),
            listOf(Color(0xFF102A52), Color(0xFF3157A4), Color(0xFF1C3A67))
        ) }
        item { Button(onClick = { picker.launch(arrayOf("audio/*")) }, modifier = Modifier.fillMaxWidth(), enabled = !busy) { Icon(Icons.Default.AudioFile, null); Spacer(Modifier.width(8.dp)); Text(if (busy) "Analisando..." else "Selecionar áudio") } }
        if (busy) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
        error?.let { item { Text(it, color = MaterialTheme.colorScheme.error) } }
        analysis?.let { a ->
            item {
                val score = audioQualityScore(a)
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = .34f))) {
                    Column(Modifier.padding(15.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Saúde técnica do arquivo", fontWeight = FontWeight.ExtraBold)
                        AudioQualityGauge(score)
                        Text("$score/100", fontWeight = FontWeight.Black, fontSize = 24.sp)
                    }
                }
            }
            item { WaveformCard(a.waveform, "Forma de onda analisada") }
            item {
                Card { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Diagnóstico técnico", fontWeight = FontWeight.ExtraBold)
                    Spec("Arquivo", a.source.displayName); Spec("Formato", a.source.mimeType ?: a.codec ?: "—")
                    Spec("Duração", a.source.durationMs?.let(::formatDuration) ?: "—")
                    Spec("Sample rate", a.source.sampleRateHz?.let { "${it / 1000.0} kHz" } ?: "—")
                    Spec("Canais", a.source.channels?.toString() ?: "—")
                    Spec("Bitrate", a.source.bitrate?.let { "${it / 1000} kbps" } ?: "—")
                    Spec("Pico", a.peakDbfs?.let { String.format(Locale.US, "%.1f dBFS", it) } ?: "—")
                    Spec("True peak", a.truePeakDbtp?.let { String.format(Locale.US, "%.1f dBTP", it) } ?: "—")
                    Spec("Loudness", a.loudnessLufs?.let { String.format(Locale.US, "%.1f LUFS-I", it) } ?: "—")
                    Spec("RMS", a.rmsDbfs?.let { String.format(Locale.US, "%.1f dBFS", it) } ?: "—")
                    Spec("Crest factor", a.crestFactorDb?.let { String.format(Locale.US, "%.1f dB", it) } ?: "—")
                    Spec("Clipping", a.clippingPercent?.let { String.format(Locale.US, "%.3f%%", it) } ?: "—")
                } }
            }
            item { Card { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(if ((a.clippingPercent ?: 0.0) < .05) "✓ Arquivo em boas condições" else "⚠ Pontos precisam de atenção", fontWeight = FontWeight.ExtraBold)
                a.qualityNotes.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
            } } }
            item {
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                    OutlinedButton(onClick=onAudioConverter,modifier=Modifier.weight(1f)){Icon(Icons.Default.Transform,null);Spacer(Modifier.width(5.dp));Text("Conversor")}
                    OutlinedButton(onClick=onCutter,modifier=Modifier.weight(1f)){Icon(Icons.Default.ContentCut,null);Spacer(Modifier.width(5.dp));Text("Cortador")}
                }
            }
        }
    }
}

private fun audioQualityScore(a: AudioDeepAnalysis): Int {
    var score = 100
    if ((a.clippingPercent ?: 0.0) > .05) score -= 28
    if ((a.truePeakDbtp ?: -2.0) > -.5) score -= 12
    if ((a.source.sampleRateHz ?: 44100) < 44100) score -= 10
    a.loudnessLufs?.let { if (it > -8 || it < -28) score -= 10 }
    a.crestFactorDb?.let { if (it < 5.0) score -= 10 else if (it > 22.0) score -= 5 }
    return score.coerceIn(0, 100)
}

@Composable
private fun AudioQualityGauge(score: Int) {
    val color = when (score) { in 0..30 -> Color(0xFFD04D4D); in 31..55 -> Color(0xFFB56A45); in 56..75 -> Color(0xFFE3A348); in 76..90 -> Color(0xFF54B97A); else -> Color(0xFF3F8DDF) }
    Canvas(Modifier.size(width = 210.dp, height = 105.dp).padding(top = 8.dp)) {
        val stroke = 14.dp.toPx()
        drawArc(Color.White.copy(alpha = .10f), 180f, 180f, false, style = Stroke(stroke, cap = StrokeCap.Round))
        drawArc(color, 180f, 180f * (score / 100f), false, style = Stroke(stroke, cap = StrokeCap.Round))
        val angle = Math.toRadians((180 + 180 * score / 100.0))
        val center = Offset(size.width / 2, size.height)
        val r = size.width * .39f
        val end = Offset(center.x + (kotlin.math.cos(angle) * r).toFloat(), center.y + (kotlin.math.sin(angle) * r).toFloat())
        drawLine(color, center, end, 5.dp.toPx(), StrokeCap.Round)
        drawCircle(color, 7.dp.toPx(), center)
    }
}

@Composable
private fun Spec(label: String, value: String) { Row(Modifier.fillMaxWidth()) { Text(label, color = MaterialTheme.colorScheme.onSurface.copy(alpha=.58f), modifier=Modifier.weight(1f)); Text(value, fontWeight=FontWeight.Bold) } }

@Composable
private fun WaveformCard(values: List<Float>, title: String) {
    val waveformColor = Color(0xFFFF455E)
    Card { Column(Modifier.padding(14.dp)) {
        Text(title, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Canvas(Modifier.fillMaxWidth().height(82.dp)) {
            if (values.isEmpty()) return@Canvas
            val mid = size.height / 2f
            val step = size.width / values.size.coerceAtLeast(1)
            values.forEachIndexed { i, amp ->
                val h = amp.coerceIn(0f,1f) * mid * .92f
                drawLine(waveformColor, Offset(i*step, mid-h), Offset(i*step, mid+h), strokeWidth = max(1f, step*.55f), cap = StrokeCap.Round)
            }
        }
    } }
}

@Composable
private fun AudioCutterTool(
    onBack: () -> Unit,
    unlimited: Boolean,
    coins: Int,
    onSpend: suspend (Int) -> Boolean,
    onTrack: (String, Boolean?, Long?) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var uri by remember { mutableStateOf<Uri?>(null) }
    var info by remember { mutableStateOf<com.sonusstudios.streampulse.audio.AudioSourceInfo?>(null) }
    var waveform by remember { mutableStateOf<List<Float>>(emptyList()) }
    var range by remember { mutableStateOf(0f..1f) }
    var suggested by remember { mutableStateOf<SuggestedSegment?>(null) }
    var suggestionVariant by remember { mutableIntStateOf(0) }
    var fadeIn by remember { mutableStateOf(true) }
    var fadeOut by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var pendingStart by remember { mutableDoubleStateOf(0.0) }
    var pendingDuration by remember { mutableDoubleStateOf(0.0) }
    var manualStart by remember { mutableStateOf("") }
    var manualEnd by remember { mutableStateOf("") }
    var waveZoom by remember { mutableFloatStateOf(1f) }
    var cutFormat by remember { mutableStateOf("MP3") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { picked ->
        if (picked != null) {
            uri = picked
            info = AudioConversionEngine.inspect(context, picked)
            range = 0f..1f
            suggested = null
            suggestionVariant = 0
            message = null
            scope.launch {
                busy = true
                waveform = withContext(Dispatchers.IO) {
                    runCatching { AudioToolEngine.analyze(context, picked).waveform }.getOrDefault(emptyList())
                }
                busy = false
            }
        }
    }
    val saver = rememberLauncherForActivityResult(SonusAutoCreateDocument("audio/mpeg")) { out ->
        val source = uri
        if (out != null && source != null) scope.launch {
            busy = true
            val started = System.currentTimeMillis()
            val r = withContext(Dispatchers.IO) {
                AudioToolEngine.exportSegment(context, source, out, pendingStart, pendingDuration, fadeIn, fadeOut, cutFormat)
            }
            message = if (!r.isSuccess) "Falha: ${r.exceptionOrNull()?.message ?: "não foi possível salvar"}" else "✓ Corte salvo com sucesso"
            busy = false
            onTrack("Cortador: exportar", r.isSuccess, System.currentTimeMillis() - started)
        }
    }

    val durationSec = ((info?.durationMs ?: 0L) / 1000.0).coerceAtLeast(.1)
    val startSec = durationSec * range.start
    val endSec = durationSec * range.endInclusive
    val selected = (endSec - startSec).coerceAtLeast(.1)

    fun requestSuggestion(variant: Int) {
        val source = uri ?: return
        scope.launch {
            busy = true
            val started = System.currentTimeMillis()
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    AudioToolEngine.suggestSegment(
                        context,
                        source,
                        minOf(30, maxOf(8, durationSec.toInt() / 4)),
                        variant
                    )
                }
            }
            suggested = result.getOrNull()
            suggested?.let { seg ->
                range = (seg.startSeconds / durationSec).toFloat().coerceIn(0f, 1f)..
                    ((seg.startSeconds + seg.durationSeconds) / durationSec).toFloat().coerceIn(0f, 1f)
            }
            message = result.exceptionOrNull()?.message
            busy = false
            onTrack("Cortador: automático", result.isSuccess, System.currentTimeMillis() - started)
        }
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        contentPadding = PaddingValues(bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { ToolHeader("Cortador de áudio Pro", onBack) }
        item { ToolIntroCard(
            "Corte visual e preciso",
            "Escolha o trecho pela waveform, defina tempos manualmente, use fades e receba uma sugestão automática local.",
            listOf("Marcadores de início e fim", "Fade-in / Fade-out", "Sugestão por energia e transientes"),
            listOf(Color(0xFF321744), Color(0xFF6A2C83), Color(0xFF37245C))
        ) }
        item {
            Button(onClick = { picker.launch(arrayOf("audio/*")) }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.AudioFile, null); Spacer(Modifier.width(8.dp)); Text("Selecionar música")
            }
        }
        info?.let { i ->
            if (waveform.isNotEmpty()) item {
                Column(verticalArrangement=Arrangement.spacedBy(5.dp)){
                    WaveformCard(zoomWaveform(waveform,waveZoom,(range.start+range.endInclusive)/2f), "Forma de onda • zoom ${String.format(Locale.US,"%.1fx",waveZoom)}")
                    Row(verticalAlignment=Alignment.CenterVertically){
                        Icon(Icons.Default.ZoomIn,null);Spacer(Modifier.width(6.dp));
                        Slider(waveZoom,{waveZoom=it},valueRange=1f..8f,modifier=Modifier.weight(1f));
                        Text(String.format(Locale.US,"%.1fx",waveZoom),style=MaterialTheme.typography.labelSmall)
                    }
                }
            }
            item {
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(i.displayName, fontWeight = FontWeight.ExtraBold)
                        Text("${formatDuration(i.durationMs ?: 0)} • seleção ${formatSec(startSec)} → ${formatSec(endSec)}")
                        RangeSlider(value = range, onValueChange = { range = it }, valueRange = 0f..1f)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(manualStart, { manualStart = it.take(8) }, label = { Text("Início") }, placeholder = { Text(formatSec(startSec)) }, singleLine = true, modifier = Modifier.weight(1f))
                            OutlinedTextField(manualEnd, { manualEnd = it.take(8) }, label = { Text("Fim") }, placeholder = { Text(formatSec(endSec)) }, singleLine = true, modifier = Modifier.weight(1f))
                            IconButton(onClick = {
                                val s = parseTimeInput(manualStart) ?: startSec
                                val e = parseTimeInput(manualEnd) ?: endSec
                                val safeS = s.coerceIn(0.0, durationSec)
                                val safeE = e.coerceIn(safeS + .1, durationSec)
                                range = (safeS / durationSec).toFloat()..(safeE / durationSec).toFloat()
                            }) { Icon(Icons.Default.Check, "Aplicar tempos") }
                        }
                        Text("Duração resultante: ${formatSec(selected)}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                        AudioSelectionPlayer(uri = uri!!, startMs = (startSec * 1000).toInt(), endMs = (endSec * 1000).toInt())
                        Row {
                            FilterChip(fadeIn, { fadeIn = !fadeIn }, { Text("Fade-in") })
                            Spacer(Modifier.width(8.dp))
                            FilterChip(fadeOut, { fadeOut = !fadeOut }, { Text("Fade-out") })
                        }
                        Text("Formato de saída",fontWeight=FontWeight.Bold)
                        LazyRow(horizontalArrangement=Arrangement.spacedBy(7.dp)){
                            items(listOf("WAV","FLAC","MP3")){f->FilterChip(cutFormat==f,{cutFormat=f},{Text(f)})}
                        }
                        Text(if(cutFormat=="MP3")"MP3 cria uma nova cópia comprimida em 256 kbps." else "$cutFormat preserva a saída sem perdas.",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.6f))
                    }
                }
            }
            item {
                Button(
                    onClick = { suggestionVariant = 0; requestSuggestion(0) },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.AutoFixHigh, null); Spacer(Modifier.width(8.dp))
                    Text(if (busy) "Analisando áudio..." else "Corte automático")
                }
            }
            suggested?.let { seg ->
                item {
                    Card {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            Text(
                                "Trecho sugerido • confiança ${seg.confidence}% • ${formatSec(seg.startSeconds)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                            OutlinedButton(
                                onClick = {
                                    suggestionVariant += 1
                                    requestSuggestion(suggestionVariant)
                                },
                                enabled = !busy,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(7.dp)); Text("Tentar outro trecho")
                            }
                        }
                    }
                }
            }
            item {
                Button(
                    onClick = {
                        pendingStart = startSec
                        pendingDuration = selected
                        val ext=when(cutFormat){"WAV"->"wav";"FLAC"->"flac";else->"mp3"}
                        saver.launch("corte_${i.displayName.substringBeforeLast('.')}.$ext")
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !busy
                ) {
                    Icon(Icons.Default.Save, null); Spacer(Modifier.width(8.dp))
                    Text("Salvar corte")
                }
            }
        }
        if (busy) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
        message?.let { item { Text(it, fontWeight = FontWeight.Bold) } }
    }
}

@Composable
private fun AudioSelectionPlayer(uri: Uri, startMs: Int, endMs: Int) {
    val context=LocalContext.current; var playing by remember(uri,startMs,endMs){mutableStateOf(false)}; var player by remember{mutableStateOf<MediaPlayer?>(null)}
    DisposableEffect(uri){onDispose{runCatching{player?.release()}}}
    Row(verticalAlignment=Alignment.CenterVertically){
        IconButton(onClick={ if(playing){player?.pause();playing=false}else{runCatching{player?.release()};player=MediaPlayer().apply{setDataSource(context,uri);prepare();seekTo(startMs);start()};playing=true} }){Icon(if(playing)Icons.Default.Pause else Icons.Default.PlayArrow,null)}
        Text("Ouvir seleção",fontWeight=FontWeight.SemiBold);Spacer(Modifier.weight(1f));Text("${formatSec(startMs/1000.0)} – ${formatSec(endMs/1000.0)}",style=MaterialTheme.typography.bodySmall)
    }
    LaunchedEffect(playing,endMs){while(playing){val p=player;if(p==null||!p.isPlaying||p.currentPosition>=endMs){p?.pause();playing=false;break};delay(100)}}
}

@Composable
private fun PreviewTool(
    onBack: () -> Unit,
    unlimited: Boolean,
    coins: Int,
    onSpend: suspend (Int) -> Boolean,
    onTrack: (String, Boolean?, Long?) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var uri by remember { mutableStateOf<Uri?>(null) }
    var name by remember { mutableStateOf("preview") }
    var info by remember { mutableStateOf<com.sonusstudios.streampulse.audio.AudioSourceInfo?>(null) }
    var previews by remember { mutableStateOf<Map<Int, SuggestedSegment>>(emptyMap()) }
    var waveform by remember { mutableStateOf<List<Float>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<Pair<Int, SuggestedSegment>?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var activePreview by remember { mutableStateOf<Int?>(null) }
    var playing by remember { mutableStateOf(false) }
    var player by remember { mutableStateOf<MediaPlayer?>(null) }

    fun stopPlayer() {
        runCatching { player?.stop() }
        runCatching { player?.release() }
        player = null; activePreview = null; playing = false
    }
    fun playPreview(seconds: Int, seg: SuggestedSegment) {
        val source = uri ?: return
        if (activePreview == seconds && playing) {
            player?.pause(); playing = false; return
        }
        stopPlayer()
        val p = MediaPlayer()
        runCatching {
            p.setDataSource(context, source)
            p.prepare()
            p.seekTo((seg.startSeconds * 1000).toInt())
            p.start()
            p.setOnCompletionListener { playing = false; activePreview = null }
            player = p; activePreview = seconds; playing = true
        }.onFailure { runCatching { p.release() }; message = "Falha ao reproduzir: ${it.message}" }
    }
    DisposableEffect(Unit) { onDispose { stopPlayer() } }
    LaunchedEffect(playing, activePreview, previews) {
        while (playing) {
            val key = activePreview
            val seg = key?.let { previews[it] }
            val p = player
            if (p == null || seg == null || !p.isPlaying || p.currentPosition >= ((seg.startSeconds + seg.durationSeconds) * 1000).toInt()) {
                p?.pause(); playing = false; activePreview = null; break
            }
            delay(90)
        }
    }

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            stopPlayer(); uri = u
            info = AudioConversionEngine.inspect(context, u)
            name = info?.displayName?.substringBeforeLast('.') ?: "preview"
            previews = emptyMap(); waveform = emptyList(); message = null
            scope.launch {
                busy = true
                val started = System.currentTimeMillis()
                val generated = withContext(Dispatchers.IO) {
                    runCatching {
                        val a = AudioToolEngine.analyze(context, u)
                        waveform = a.waveform
                        listOf(15, 30, 60).mapIndexed { index, seconds -> seconds to AudioToolEngine.suggestSegment(context, u, seconds, index) }.toMap()
                    }
                }
                previews = generated.getOrDefault(emptyMap())
                message = generated.exceptionOrNull()?.message
                busy = false
                onTrack("Preview: gerar", generated.isSuccess, System.currentTimeMillis() - started)
            }
        }
    }
    val save = rememberLauncherForActivityResult(SonusAutoCreateDocument("audio/mpeg")) { out ->
        val src = uri; val p = pending
        if (out != null && src != null && p != null) scope.launch {
            stopPlayer(); busy = true; val started = System.currentTimeMillis()
            val r = withContext(Dispatchers.IO) { AudioToolEngine.exportSegment(context, src, out, p.second.startSeconds, p.second.durationSeconds, true, true, "MP3") }
            message = if (!r.isSuccess) "Falha ao salvar preview." else "✓ Preview de ${p.first}s salvo"
            busy = false; onTrack("Preview: exportar ${p.first}s", r.isSuccess, System.currentTimeMillis() - started)
        }
    }
    fun saveAllPreviews() {
        val src = uri
        if (src != null && previews.size == 3) scope.launch {
            stopPlayer(); busy = true; val started = System.currentTimeMillis()
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    previews.toSortedMap().forEach { (seconds, seg) ->
                        val out = com.sonusstudios.streampulse.core.SonusStorage.createAudio(
                            context,
                            "${name}_${seconds}s.mp3",
                            "audio/mpeg"
                        ) ?: error("Não foi possível criar ${seconds}s.")
                        val exported = AudioToolEngine.exportSegment(context, src, out, seg.startSeconds, seg.durationSeconds, true, true, "MP3")
                        if (exported.isSuccess) com.sonusstudios.streampulse.core.SonusStorage.finish(context, out)
                        else {
                            com.sonusstudios.streampulse.core.SonusStorage.abort(context, out)
                            exported.getOrThrow()
                        }
                    }
                }
            }
            message = if (!result.isSuccess) "Falha ao salvar todos: ${result.exceptionOrNull()?.message ?: "erro de gravação"}" else "✓ Previews de 15s, 30s e 60s salvos em SONUS/Audio"
            busy = false; onTrack("Preview: salvar todos", result.isSuccess, System.currentTimeMillis() - started)
        }
    }

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), contentPadding = PaddingValues(bottom = 28.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { ToolHeader("Gerador de preview", onBack) }
        item { ToolIntroCard(
            "Três cortes prontos para conteúdo",
            "Gere 15s, 30s e 60s, ajuste o início e escute cada versão antes de exportar.",
            listOf("Sugestão local por energia/transientes", "Fade nas bordas", "Um único player: nunca toca previews por cima"),
            listOf(Color(0xFF123D3A), Color(0xFF277B68), Color(0xFF194B52))
        ) }
        item { Button(onClick = { pick.launch(arrayOf("audio/*")) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.LibraryMusic, null); Spacer(Modifier.width(7.dp)); Text("Selecionar música e gerar previews") } }
        if (busy) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
        if (waveform.isNotEmpty()) item { WaveformCard(waveform, "Mapa de energia do áudio") }
        items(previews.toList()) { (seconds, seg) ->
            Card(border = if (activePreview == seconds) BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary) else null) {
                Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text("Preview $seconds segundos", fontWeight = FontWeight.ExtraBold); Text("${formatSec(seg.startSeconds)} • confiança ${seg.confidence}%", style = MaterialTheme.typography.bodySmall) }
                        if (activePreview == seconds) AssistChip(onClick = {}, label = { Text(if (playing) "Reproduzindo" else "Pausado") }, leadingIcon = { Icon(Icons.Default.GraphicEq, null) })
                    }
                    val maxStart = max(0.0, ((info?.durationMs ?: 0L) / 1000.0) - seconds)
                    if (maxStart > 0.1) {
                        Text("Início do corte: ${formatSec(seg.startSeconds)}", style = MaterialTheme.typography.labelSmall)
                        Slider(value = seg.startSeconds.toFloat().coerceIn(0f, maxStart.toFloat()), onValueChange = { v -> previews = previews + (seconds to seg.copy(startSeconds = v.toDouble())) }, valueRange = 0f..maxStart.toFloat())
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { playPreview(seconds, seg) }, modifier = Modifier.weight(1f)) { Icon(if (activePreview == seconds && playing) Icons.Default.Pause else Icons.Default.PlayArrow, null); Spacer(Modifier.width(5.dp)); Text("Ouvir") }
                        Button(onClick = { pending = seconds to seg; save.launch("${name}_${seconds}s.mp3") }, modifier = Modifier.weight(1f)) { Text("Salvar") }
                    }
                }
            }
        }
        if (previews.size == 3) item { OutlinedButton(onClick = { saveAllPreviews() }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.FolderZip, null); Spacer(Modifier.width(7.dp)); Text("Salvar os três") } }
        message?.let { item { Text(it, fontWeight = FontWeight.Bold) } }
    }
}

private fun loadMetadataDefaults(context: Context): AudioMetadata {
    val p = context.getSharedPreferences("sonus_metadata_defaults_v2", Context.MODE_PRIVATE)
    return AudioMetadata(
        artist = p.getString("artist", "").orEmpty(),
        albumArtist = p.getString("albumArtist", "").orEmpty(),
        album = p.getString("album", "").orEmpty(),
        composer = p.getString("composer", "").orEmpty(),
        author = p.getString("author", "").orEmpty(),
        genre = p.getString("genre", "").orEmpty(),
        year = p.getString("year", "").orEmpty(),
        bpm = p.getString("bpm", "").orEmpty(),
        copyright = p.getString("copyright", "").orEmpty(),
        comment = p.getString("comment", "").orEmpty()
    )
}

private fun saveMetadataDefaults(context: Context, meta: AudioMetadata) {
    context.getSharedPreferences("sonus_metadata_defaults_v2", Context.MODE_PRIVATE).edit()
        .putString("artist", meta.artist)
        .putString("albumArtist", meta.albumArtist)
        .putString("album", meta.album)
        .putString("composer", meta.composer)
        .putString("author", meta.author)
        .putString("genre", meta.genre)
        .putString("year", meta.year)
        .putString("bpm", meta.bpm)
        .putString("copyright", meta.copyright)
        .putString("comment", meta.comment)
        .apply()
}

private fun mergeBlankMetadata(current: AudioMetadata, defaults: AudioMetadata): AudioMetadata = current.copy(
    artist = current.artist.ifBlank { defaults.artist },
    albumArtist = current.albumArtist.ifBlank { defaults.albumArtist },
    album = current.album.ifBlank { defaults.album },
    composer = current.composer.ifBlank { defaults.composer },
    author = current.author.ifBlank { defaults.author },
    genre = current.genre.ifBlank { defaults.genre },
    year = current.year.ifBlank { defaults.year },
    bpm = current.bpm.ifBlank { defaults.bpm },
    copyright = current.copyright.ifBlank { defaults.copyright },
    comment = current.comment.ifBlank { defaults.comment }
)

private fun audioMimeForName(name: String): String = when (name.substringAfterLast('.', "mp3").lowercase(Locale.US)) {
    "mp3" -> "audio/mpeg"
    "m4a", "mp4" -> "audio/mp4"
    "aac" -> "audio/aac"
    "flac" -> "audio/flac"
    "wav" -> "audio/wav"
    "ogg" -> "audio/ogg"
    "opus" -> "audio/opus"
    "aif", "aiff" -> "audio/aiff"
    else -> "audio/*"
}

@Composable
private fun MetadataTool(onBack:()->Unit,unlimited:Boolean,coins:Int,onSpend:suspend(Int)->Boolean,onTrack:(String,Boolean?,Long?)->Unit){
    val context=LocalContext.current
    val scope=rememberCoroutineScope()
    val clipboard=LocalClipboardManager.current
    var uri by remember{mutableStateOf<Uri?>(null)}
    var meta by remember{mutableStateOf(AudioMetadata())}
    var originalMeta by remember{mutableStateOf(AudioMetadata())}
    var filename by remember{mutableStateOf("audio.mp3")}
    var message by remember{mutableStateOf<String?>(null)}
    var info by remember{mutableStateOf<com.sonusstudios.streampulse.audio.AudioSourceInfo?>(null)}
    var artwork by remember{mutableStateOf<Bitmap?>(null)}
    var artworkUri by remember{mutableStateOf<Uri?>(null)}
    var artworkMode by remember{mutableStateOf(ArtworkWriteMode.KEEP)}
    var saving by remember{mutableStateOf(false)}
    var lyricsSource by remember{mutableStateOf("")}

    val pick=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){u->
        if(u!=null){
            uri=u
            val inspected=AudioConversionEngine.inspect(context,u)
            filename=inspected.displayName
            info=inspected
            scope.launch{
                val read=withContext(Dispatchers.IO){AudioToolEngine.readMetadata(context,u)}
                val enriched=mergeBlankMetadata(read,loadMetadataDefaults(context))
                meta=enriched
                originalMeta=read
                artwork=withContext(Dispatchers.IO){AudioToolEngine.readEmbeddedArtwork(context,u)}
                artworkUri=null
                artworkMode=ArtworkWriteMode.KEEP
                lyricsSource=if(read.lyrics.contains(Regex("\\[\\d{1,2}:\\d{2}"))) "LRC incorporado" else if(read.lyrics.isNotBlank()) "Letra incorporada" else ""
                onTrack("Metadados: ler",true,null)
            }
        }
    }
    val pickArt=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){u->
        if(u!=null){artworkUri=u;artworkMode=ArtworkWriteMode.REPLACE;scope.launch{artwork=withContext(Dispatchers.IO){loadPreviewBitmap(context,u)}}}
    }
    val pickLyrics=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){u->
        if(u!=null)scope.launch{
            val imported=withContext(Dispatchers.IO){SonusLyricsImporter.read(context,u)}
            imported.onSuccess{doc->
                meta=meta.copy(lyrics=doc.text)
                lyricsSource=if(doc.format=="LRC") "LRC importado • sincronização preservada" else "TXT importado"
            }.onFailure{message=it.message?:"Não foi possível importar a letra."}
        }
    }

    fun saveNow(){
        val src=uri?:return
        scope.launch{
            if(!unlimited && coins<=0){message="Você precisa de 1 Moeda SONUS para salvar os metadados.";return@launch}
            saving=true
            message=null
            val outName="metadados_${filename}"
            val out=withContext(Dispatchers.IO){SonusStorage.createAudio(context,outName,audioMimeForName(filename),SonusStorage.Bucket.AUDIO)}
            if(out==null){message="Falha: não foi possível criar o arquivo de saída";saving=false;return@launch}
            val st=System.currentTimeMillis()
            val r=withContext(Dispatchers.IO){AudioToolEngine.writeMetadata(context,src,out,meta,artworkUri,artworkMode)}
            if(r.isSuccess){
                val paid = unlimited || onSpend(1)
                if(paid){
                    withContext(Dispatchers.IO){SonusStorage.finish(context,out);saveMetadataDefaults(context,meta)}
                    originalMeta=meta
                    artworkMode=ArtworkWriteMode.KEEP
                    artworkUri=null
                    SonusNotificationCenter.recordPremiumUse(context,"Metadados")
                    message="✓ Nova cópia salva em Música/SONUS/Audio • ${if(unlimited)"Diamante" else "1 Moeda SONUS"}"
                }else{
                    withContext(Dispatchers.IO){SonusStorage.abort(context,out)}
                    message="Não foi possível descontar 1 Moeda SONUS. Nenhum arquivo foi salvo."
                }
            }else{
                withContext(Dispatchers.IO){SonusStorage.abort(context,out)}
                message="Falha: ${r.exceptionOrNull()?.message?.lineSequence()?.lastOrNull()?.take(180) ?: "não foi possível salvar"}"
            }
            saving=false
            onTrack("Metadados: salvar",r.isSuccess,System.currentTimeMillis()-st)
        }
    }

    LazyColumn(Modifier.fillMaxSize().padding(horizontal=16.dp),contentPadding=PaddingValues(bottom=28.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        item{ToolHeader("Metadados de áudio",onBack)}
        item{ToolIntroCard("Ficha completa da música","Edite tags, capa e letras sem alterar o arquivo original.",listOf("Tags ID3 completas","Capa incorporada","Letras TXT, LRC ou área de transferência"),listOf(Color(0xFF6D1624),Color(0xFFB62B3F),Color(0xFF7A1D2C)))}
        item{Button(onClick={pick.launch(arrayOf("audio/*"))},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Sell,null);Spacer(Modifier.width(7.dp));Text("Selecionar arquivo")}}
        if(uri!=null){
            item{Card{Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                Row(verticalAlignment=Alignment.CenterVertically){
                    if(artwork!=null&&artworkMode!=ArtworkWriteMode.REMOVE){Image(artwork!!.asImageBitmap(),"Capa incorporada",modifier=Modifier.size(90.dp).clip(RoundedCornerShape(14.dp)),contentScale=ContentScale.Crop)}
                    else{Surface(modifier=Modifier.size(90.dp),shape=RoundedCornerShape(14.dp),color=MaterialTheme.colorScheme.surfaceVariant){Box(contentAlignment=Alignment.Center){Icon(Icons.Default.Album,null,modifier=Modifier.size(42.dp))}}}
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)){Text(filename,fontWeight=FontWeight.ExtraBold,maxLines=2);Text(buildList{info?.durationMs?.let{add(formatDuration(it))};info?.sampleRateHz?.let{add("${it/1000.0} kHz")};info?.bitrate?.let{add("${it/1000} kbps")}}.joinToString(" • "),style=MaterialTheme.typography.bodySmall)}
                }
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                    OutlinedButton(onClick={pickArt.launch(arrayOf("image/*"))},modifier=Modifier.weight(1f)){Icon(Icons.Default.AddPhotoAlternate,null);Spacer(Modifier.width(5.dp));Text("Trocar capa")}
                    OutlinedButton(onClick={artworkMode=ArtworkWriteMode.REMOVE;artworkUri=null},modifier=Modifier.weight(1f)){Icon(Icons.Default.HideImage,null);Spacer(Modifier.width(5.dp));Text("Remover")}
                }
            }}}
            item{
                val changed=metadataChangedCount(originalMeta,meta)+(if(artworkMode!=ArtworkWriteMode.KEEP)1 else 0)
                Surface(shape=RoundedCornerShape(14.dp),color=if(changed>0)MaterialTheme.colorScheme.primaryContainer.copy(alpha=.45f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.35f)){
                    Row(Modifier.fillMaxWidth().padding(11.dp),verticalAlignment=Alignment.CenterVertically){Icon(if(changed>0)Icons.Default.CompareArrows else Icons.Default.CheckCircle,null);Spacer(Modifier.width(7.dp));Text(if(changed>0)"Antes → Depois: $changed alteração(ões) pendente(s)" else "Metadados carregados • nenhuma alteração ainda",fontWeight=FontWeight.SemiBold)}
                }
            }
            item{Card{Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                Text("Informações principais",fontWeight=FontWeight.ExtraBold)
                MetaField("Título",meta.title){meta=meta.copy(title=it)}
                MetaField("Artista",meta.artist){meta=meta.copy(artist=it)}
                MetaField("Artista do álbum",meta.albumArtist){meta=meta.copy(albumArtist=it)}
                MetaField("Álbum",meta.album){meta=meta.copy(album=it)}
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Box(Modifier.weight(1f)){MetaField("Faixa",meta.track){meta=meta.copy(track=it.take(12))}};Box(Modifier.weight(1f)){MetaField("Total faixas",meta.trackTotal){meta=meta.copy(trackTotal=it.take(12))}}}
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Box(Modifier.weight(1f)){MetaField("Disco",meta.disc){meta=meta.copy(disc=it.take(12))}};Box(Modifier.weight(1f)){MetaField("Total discos",meta.discTotal){meta=meta.copy(discTotal=it.take(12))}}}
                MetaField("Compositor",meta.composer){meta=meta.copy(composer=it)}
                MetaField("Autor",meta.author){meta=meta.copy(author=it)}
                MetaChoiceField("Gênero", SonusMediaPreferences.initialGenre(context, meta.genre), SonusMediaStandards.genres) { selected ->
                    SonusMediaPreferences.saveLastGenre(context, selected)
                    meta=meta.copy(genre=selected)
                }
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Box(Modifier.weight(1f)){MetaField("Ano / data",meta.year){meta=meta.copy(year=it.take(16))}};Box(Modifier.weight(1f)){MetaField("BPM",meta.bpm){meta=meta.copy(bpm=it.filter{c->c.isDigit()||c=='.'}.take(8))}}}
                MetaField("ISRC",meta.isrc){meta=meta.copy(isrc=it.take(24))}
                MetaField("Copyright",meta.copyright){meta=meta.copy(copyright=it)}
                MetaField("Comentário",meta.comment){meta=meta.copy(comment=it)}
            }}}
            item{Card{Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                Row(verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Lyrics,null);Spacer(Modifier.width(7.dp));Column(Modifier.weight(1f)){Text("Letra da música",fontWeight=FontWeight.ExtraBold);Text(lyricsSource.ifBlank{"Nenhuma letra carregada"},style=MaterialTheme.typography.labelSmall)}}
                OutlinedTextField(value=meta.lyrics,onValueChange={meta=meta.copy(lyrics=it);lyricsSource=if(it.contains(Regex("\\[\\d{1,2}:\\d{2}")))"LRC / letra sincronizada" else if(it.isNotBlank())"Letra editada" else ""},label={Text("Letra / LRC")},minLines=5,maxLines=12,modifier=Modifier.fillMaxWidth())
                Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){
                    OutlinedButton(onClick={pickLyrics.launch(SonusLyricsImporter.pickerMimeTypes())},modifier=Modifier.weight(1f)){Icon(Icons.Default.FileOpen,null);Spacer(Modifier.width(4.dp));Text("TXT/LRC")}
                    OutlinedButton(onClick={val t=clipboard.getText()?.text.orEmpty();if(t.isNotBlank()){meta=meta.copy(lyrics=t);lyricsSource="Área de transferência"}},modifier=Modifier.weight(1f)){Icon(Icons.Default.ContentPaste,null);Spacer(Modifier.width(4.dp));Text("Colar")}
                }
                TextButton(onClick={meta=meta.copy(lyrics="");lyricsSource=""},modifier=Modifier.fillMaxWidth()){Text("Remover letra")}
            }}}
            item{Card{Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){
                Text("Preenchimento rápido",fontWeight=FontWeight.ExtraBold)
                Text("Artista, álbum, gênero e outros dados recorrentes ficam memorizados para preencher campos vazios nas próximas músicas.",style=MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                    OutlinedButton(onClick={meta=mergeBlankMetadata(meta,loadMetadataDefaults(context))},modifier=Modifier.weight(1f)){Text("Usar últimos")}
                    OutlinedButton(onClick={context.getSharedPreferences("sonus_metadata_defaults_v2",Context.MODE_PRIVATE).edit().clear().apply()},modifier=Modifier.weight(1f)){Text("Limpar memória")}
                }
            }}}
            item{Button(onClick={saveNow()},enabled=!saving,modifier=Modifier.fillMaxWidth()){if(saving)CircularProgressIndicator(Modifier.size(18.dp),strokeWidth=2.dp)else Icon(Icons.Default.Save,null);Spacer(Modifier.width(7.dp));Text(if(saving)"Salvando…" else "Salvar nova cópia")}}
        }
        message?.let{item{Text(it,fontWeight=FontWeight.Bold)}}
    }
}

private fun metadataChangedCount(a:AudioMetadata,b:AudioMetadata):Int = listOf(
    a.title!=b.title,a.artist!=b.artist,a.albumArtist!=b.albumArtist,a.album!=b.album,a.composer!=b.composer,a.author!=b.author,
    a.genre!=b.genre,a.year!=b.year,a.track!=b.track,a.trackTotal!=b.trackTotal,a.disc!=b.disc,a.discTotal!=b.discTotal,
    a.bpm!=b.bpm,a.isrc!=b.isrc,a.copyright!=b.copyright,a.comment!=b.comment,a.lyrics!=b.lyrics
).count{it}

@Composable private fun MetaField(label:String,value:String,onChange:(String)->Unit){OutlinedTextField(value,onChange,label={Text(label)},singleLine=true,modifier=Modifier.fillMaxWidth())}
@Composable private fun MetaChoiceField(label:String,value:String,options:List<String>,onChange:(String)->Unit){
    var expanded by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxWidth()){
        OutlinedButton(onClick={expanded=true},modifier=Modifier.fillMaxWidth()){
            Column(Modifier.weight(1f),horizontalAlignment=Alignment.Start){Text(label,style=MaterialTheme.typography.labelSmall);Text(value.ifBlank{"Selecione"},maxLines=1,overflow=TextOverflow.Ellipsis)}
            Icon(Icons.Default.ArrowDropDown,null)
        }
        DropdownMenu(expanded=expanded,onDismissRequest={expanded=false}){
            options.forEach{option->DropdownMenuItem(text={Text(option)},onClick={expanded=false;onChange(option)})}
        }
    }
}


private data class ImageRenameItem(val uri: Uri, val originalName: String, val proposedName: String)

private fun imageDisplayName(context: Context, uri: Uri): String {
    return runCatching {
        context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    }.getOrNull().orEmpty().ifBlank { uri.lastPathSegment?.substringAfterLast('/') ?: "imagem" }
}

private fun imageExtension(name: String): String = name.substringAfterLast('.', "").takeIf { it.length in 2..5 }.orEmpty()
private fun imageBaseName(name: String): String = if (imageExtension(name).isBlank()) name else name.substringBeforeLast('.')

private fun numberedImageName(baseRaw: String, index: Int, total: Int, originalName: String): String {
    val cleanBase = baseRaw.trim().replace(Regex("[\\/:*?\"<>|]"), "_").trim().ifBlank { "Imagem" }
    val digits = maxOf(2, total.toString().length)
    val suffix = index.toString().padStart(digits, '0')
    val ext = imageExtension(originalName)
    return buildString {
        append(cleanBase).append(' ').append(suffix)
        if (ext.isNotBlank()) append('.').append(ext.lowercase(Locale.ROOT))
    }
}

private fun normalizeIndividualImageName(raw: String, originalName: String): String {
    val clean = raw.trim().replace(Regex("[\\/:*?\"<>|]"), "_").trim()
    if (clean.isBlank()) return originalName
    val originalExt = imageExtension(originalName)
    val typedExt = imageExtension(clean)
    return if (typedExt.isNotBlank() || originalExt.isBlank()) clean else "$clean.${originalExt.lowercase(Locale.ROOT)}"
}

private fun documentSupportsRename(context: Context, uri: Uri): Boolean {
    if (!DocumentsContract.isDocumentUri(context, uri)) return false
    return runCatching {
        context.contentResolver.query(uri, arrayOf(DocumentsContract.Document.COLUMN_FLAGS), null, null, null)?.use { cursor ->
            if (!cursor.moveToFirst()) return@use false
            val flags = cursor.getLong(0)
            flags and DocumentsContract.Document.FLAG_SUPPORTS_RENAME.toLong() != 0L
        } ?: false
    }.getOrDefault(false)
}

private fun imageMediaUri(context: Context, uri: Uri): Uri? {
    if (uri.authority == MediaStore.AUTHORITY) return uri
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q || !DocumentsContract.isDocumentUri(context, uri)) return null
    return runCatching { MediaStore.getMediaUri(context, uri) }.getOrNull()
}

private fun renameImageDocument(context: Context, uri: Uri, requestedName: String): Result<Uri> = runCatching {
    val originalName = imageDisplayName(context, uri)
    val finalName = normalizeIndividualImageName(requestedName, originalName)
    require(finalName.isNotBlank()) { "INVALID_NAME: nome vazio." }
    if (finalName.equals(originalName, ignoreCase = false)) return@runCatching uri

    // SAF: só chama renameDocument quando o provedor declarou suporte real.
    if (documentSupportsRename(context, uri)) {
        try {
            DocumentsContract.renameDocument(context.contentResolver, uri, finalName)?.let { return@runCatching it }
        } catch (security: SecurityException) {
            throw IllegalStateException("MEDIASTORE_WRITE_DENIED: o Android não autorizou alterar esta imagem.", security)
        } catch (_: Throwable) {
            // O provedor declarou suporte mas falhou. Ainda tentamos o MediaStore real abaixo.
        }
    }

    // OpenMultipleDocuments pode devolver um document:// que representa uma mídia local.
    // Em Android 10+ resolvemos o URI equivalente do MediaStore antes do DISPLAY_NAME update.
    val writableUri = imageMediaUri(context, uri)
        ?: if (uri.authority == MediaStore.AUTHORITY) uri else null
        ?: throw IllegalStateException("PROVIDER_NO_RENAME: este provedor não oferece renomeação para o SONUS.")
    val values = android.content.ContentValues().apply { put(MediaStore.MediaColumns.DISPLAY_NAME, finalName) }
    val changed = try {
        context.contentResolver.update(writableUri, values, null, null)
    } catch (security: SecurityException) {
        throw IllegalStateException("MEDIASTORE_WRITE_DENIED: o Android não autorizou alterar esta imagem.", security)
    }
    require(changed > 0) { "URI_NOT_RESOLVED: não foi possível localizar a imagem no armazenamento de mídia." }
    writableUri
}

@Composable
private fun BatchImagePreviewRow(uri: Uri, index: Int) {
    val context = LocalContext.current
    val preview by produceState<Bitmap?>(null, uri) { value = withContext(Dispatchers.IO) { loadPreviewBitmap(context, uri) } }
    val info by produceState<ImageInfo?>(null, uri) { value = withContext(Dispatchers.IO) { AudioToolEngine.inspectImage(context, uri) } }
    val name = remember(uri) { imageDisplayName(context, uri) }
    Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .28f)) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            Box(Modifier.size(54.dp).clip(RoundedCornerShape(9.dp)).background(Color.Black.copy(.16f)), contentAlignment = Alignment.Center) {
                preview?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
            }
            Column(Modifier.weight(1f)) {
                Text("${index.toString().padStart(2,'0')} • $name", fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                info?.let { Text("${it.width}×${it.height} • ${it.mime ?: "imagem"} • ${it.sizeBytes?.let(::formatBytes) ?: "—"}", style = MaterialTheme.typography.labelSmall) }
            }
        }
    }
}

@Composable
private fun ImageBatchRenameTool(onBack: () -> Unit, onTrack: (String, Boolean?, Long?) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var items by remember { mutableStateOf<List<ImageRenameItem>>(emptyList()) }
    var baseName by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var renameProgress by remember { mutableIntStateOf(0) }

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { selected ->
        if (selected.isNotEmpty()) {
            selected.forEach { uri -> runCatching { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } }
            items = selected.map { uri ->
                val name = imageDisplayName(context, uri)
                ImageRenameItem(uri, name, name)
            }
            baseName = ""
            message = "${selected.size} imagem(ns) pronta(s) para renomear."
        }
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        contentPadding = PaddingValues(bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { ToolHeader("Renomear imagens em lote", onBack) }
        item { Text("Renomeie uma por uma ou use um nome-base. O SONUS numera automaticamente para evitar nomes iguais.", style = MaterialTheme.typography.bodySmall) }
        item {
            Button(onClick = { pick.launch(arrayOf("image/*")) }, modifier = Modifier.fillMaxWidth(), enabled = !busy) {
                Icon(Icons.Default.AddPhotoAlternate, null); Spacer(Modifier.width(7.dp)); Text("Selecionar imagens")
            }
        }
        if (items.isNotEmpty()) {
            item {
                Card {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Nome-base para todas", fontWeight = FontWeight.ExtraBold)
                        OutlinedTextField(
                            value = baseName,
                            onValueChange = { value ->
                                baseName = value
                                if (value.isNotBlank()) {
                                    items = items.mapIndexed { index, item -> item.copy(proposedName = numberedImageName(value, index + 1, items.size, item.originalName)) }
                                }
                            },
                            label = { Text("Ex.: Céu azul") },
                            supportingText = { Text("Exemplo: Céu azul 01, Céu azul 02, Céu azul 03…") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                    }
                }
            }
            items(items, key = { it.uri.toString() }) { item ->
                val index = items.indexOfFirst { it.uri == item.uri }
                val preview by produceState<Bitmap?>(null, item.uri) { value = withContext(Dispatchers.IO) { loadPreviewBitmap(context, item.uri) } }
                Card {
                    Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                        Box(Modifier.size(58.dp).clip(RoundedCornerShape(10.dp)).background(Color.Black.copy(.16f)), contentAlignment = Alignment.Center) {
                            preview?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
                        }
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(item.originalName, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            OutlinedTextField(
                                value = item.proposedName,
                                onValueChange = { value ->
                                    items = items.mapIndexed { i, old -> if (i == index) old.copy(proposedName = value) else old }
                                },
                                label = { Text("Novo nome") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }
            item {
                Button(
                    enabled = !busy && items.all { it.proposedName.isNotBlank() },
                    onClick = {
                        scope.launch {
                            busy = true
                            renameProgress = 0
                            val started = System.currentTimeMillis()
                            var ok = 0
                            var failed = 0
                            val requested = mutableSetOf<String>()
                            val diagnostics = linkedMapOf<String, Int>()
                            val renamedItems = items.toMutableList()
                            items.forEachIndexed { itemIndex, item ->
                                val finalName = normalizeIndividualImageName(item.proposedName, item.originalName)
                                if (!requested.add(finalName.lowercase(Locale.ROOT))) {
                                    failed++
                                    diagnostics["DUPLICATE_NAME"] = (diagnostics["DUPLICATE_NAME"] ?: 0) + 1
                                } else {
                                    val result = withContext(Dispatchers.IO) { renameImageDocument(context, item.uri, finalName) }
                                    if (result.isSuccess) {
                                        ok++
                                        renamedItems[itemIndex] = item.copy(uri = result.getOrDefault(item.uri), originalName = finalName, proposedName = finalName)
                                    } else {
                                        failed++
                                        val raw = result.exceptionOrNull()?.message.orEmpty()
                                        val code = listOf("MEDIASTORE_WRITE_DENIED", "PROVIDER_NO_RENAME", "URI_NOT_RESOLVED", "INVALID_NAME").firstOrNull { raw.startsWith(it) } ?: "UNKNOWN_ERROR"
                                        diagnostics[code] = (diagnostics[code] ?: 0) + 1
                                    }
                                }
                                renameProgress = (((itemIndex + 1).toFloat() / items.size.coerceAtLeast(1)) * 100f).toInt().coerceIn(0, 100)
                            }
                            busy = false
                            message = if (failed == 0) {
                                "✓ $ok imagem(ns) renomeada(s) com sucesso."
                            } else {
                                val hint = when {
                                    diagnostics.containsKey("MEDIASTORE_WRITE_DENIED") -> "O Android bloqueou a escrita em parte da seleção."
                                    diagnostics.containsKey("PROVIDER_NO_RENAME") -> "Algumas imagens vieram de um provedor que não permite renomear."
                                    diagnostics.containsKey("DUPLICATE_NAME") -> "Existem nomes repetidos no lote."
                                    else -> "Algumas imagens não puderam ser localizadas para renomeação."
                                }
                                "$ok renomeada(s) • $failed falha(s). $hint"
                            }
                            onTrack("Renomear imagens em lote", failed == 0, System.currentTimeMillis() - started)
                            items = renamedItems
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (busy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Icon(Icons.Default.DriveFileRenameOutline, null)
                    Spacer(Modifier.width(7.dp)); Text(if (busy) "Renomeando…" else "Renomear ${items.size} imagem(ns)")
                }
            }
        }
        message?.let { item { Text(it, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall) } }
    }
    if (busy) SonusExportProgressDialog(percent=renameProgress, phase="Renomeando imagens…", title="Renomear Imagens")
}

@Composable
private fun CoverConverterTool(
    onBack: () -> Unit,
    unlimited: Boolean,
    coins: Int,
    onSpend: suspend (Int) -> Boolean,
    onTrack: (String, Boolean?, Long?) -> Unit,
    premiumMode: Boolean = false
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var uri by remember { mutableStateOf<Uri?>(null) }
    var batchUris by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var info by remember { mutableStateOf<ImageInfo?>(null) }
    var width by remember { mutableIntStateOf(3000) }
    var height by remember { mutableIntStateOf(3000) }
    var customWidth by remember { mutableStateOf("3000") }
    var customHeight by remember { mutableStateOf("3000") }
    var preserveSourceRatio by remember { mutableStateOf(false) }
    var format by remember { mutableStateOf("JPG") }
    var quality by remember { mutableIntStateOf(94) }
    var mode by remember { mutableStateOf(SquareMode.CROP) }
    val imagePrefs = remember { context.getSharedPreferences("sonus_image_converter", android.content.Context.MODE_PRIVATE) }
    var message by remember { mutableStateOf<String?>(null) }
    var exportBusy by remember { mutableStateOf(false) }
    var exportProgress by remember { mutableIntStateOf(0) }
    var customFolder by remember { mutableStateOf(context.getSharedPreferences("sonus_image_output", android.content.Context.MODE_PRIVATE).getString("tree", null)?.let(Uri::parse)) }

    val preview by produceState<Bitmap?>(initialValue = null, key1 = uri) {
        value = uri?.let { withContext(Dispatchers.IO) { loadPreviewBitmap(context, it) } }
    }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { selected ->
        if (selected.isNotEmpty()) {
            batchUris = selected
            uri = selected.first()
            info = AudioToolEngine.inspectImage(context, selected.first())
            message = if(selected.size > 1) "${selected.size} imagens selecionadas • as mesmas configurações serão aplicadas ao lote." else null
        }
    }
    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { tree ->
        if(tree!=null){ runCatching{context.contentResolver.takePersistableUriPermission(tree, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION)}; customFolder=tree;context.getSharedPreferences("sonus_image_output", android.content.Context.MODE_PRIVATE).edit().putString("tree",tree.toString()).apply() }
    }
    val mime = when (format) {
        "PNG" -> "image/png"
        "WEBP" -> "image/webp"
        "HEIC", "HEIF" -> "image/heic"
        "BMP" -> "image/bmp"
        "TIFF", "TIF" -> "image/tiff"
        else -> "image/jpeg"
    }
    val formats = buildList {
        addAll(listOf("JPG", "JPEG", "PNG", "WEBP", "BMP", "TIFF", "TIF"))
        if (Build.VERSION.SDK_INT >= 28) addAll(listOf("HEIC", "HEIF"))
    }
    LaunchedEffect(width,height,format,quality,mode) {
        imagePrefs.edit().putInt("width",width).putInt("height",height).putString("format",format).putInt("quality",quality).putString("mode",mode.name).apply()
    }
    LaunchedEffect(Unit) {
        width=imagePrefs.getInt("width",3000);height=imagePrefs.getInt("height",3000);customWidth=width.toString();customHeight=height.toString();
        format=imagePrefs.getString("format","JPG") ?: "JPG"; quality=100;
        mode=runCatching{SquareMode.valueOf(imagePrefs.getString("mode",SquareMode.FIT_BACKGROUND.name)!!)}.getOrDefault(SquareMode.FIT_BACKGROUND)
    }
    val sourceRatio = info?.takeIf { it.height > 0 }?.let { it.width.toDouble() / it.height } ?: 1.0
    val estimatedBytes = info?.sizeBytes?.let { bytes ->
        val srcPixels = ((info?.width ?: 1).toLong() * (info?.height ?: 1).toLong()).coerceAtLeast(1L)
        val outPixels = width.toLong() * height.toLong()
        val q = if (format == "PNG") 1.0 else quality / 94.0
        (bytes * (outPixels.toDouble() / srcPixels).coerceIn(.08, 12.0) * q.coerceIn(.4, 1.2)).toLong()
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        contentPadding = PaddingValues(bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(11.dp)
    ) {
        item { ToolHeader(if(premiumMode) "Converter e redimensionar imagens • PRO" else "Imagem e capa", onBack) }
        if(premiumMode) item { Text("Modo profissional: HEIC, qualidade máxima e dimensões avançadas para capas de alta resolução.", style=MaterialTheme.typography.bodySmall, color=MaterialTheme.colorScheme.primary) }
        item {
            Button(onClick = { pick.launch(arrayOf("image/*")) }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.AddPhotoAlternate, null); Spacer(Modifier.width(7.dp)); Text("Selecionar imagem(ns)")
            }
        }
        if (batchUris.size > 1) {
            item {
                Card {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("${batchUris.size} imagens selecionadas", fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                            Text("Lote", color = Color(0xFF58D7A3), fontWeight = FontWeight.Bold)
                        }
                        Text("Todas receberão as configurações abaixo.", style = MaterialTheme.typography.bodySmall)
                        Column(verticalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.heightIn(max = 280.dp).verticalScroll(rememberScrollState())) {
                            batchUris.forEachIndexed { index, itemUri ->
                                BatchImagePreviewRow(itemUri, index + 1)
                            }
                        }
                    }
                }
            }
        } else {
            info?.let { i ->
                item {
                    Card {
                        Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Imagem original", fontWeight = FontWeight.ExtraBold)
                            Spec("Dimensões", "${i.width}×${i.height}")
                            Text("${i.width}×${i.height} • ${i.mime ?: "—"} • ${i.sizeBytes?.let(::formatBytes) ?: "—"}", style=MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            preview?.let { bmp ->
                item {
                    Card {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            Text("Prévia do enquadramento", fontWeight = FontWeight.Bold)
                            Image(
                                bitmap = bmp.asImageBitmap(),
                                contentDescription = "Prévia da capa",
                                modifier = Modifier.fillMaxWidth().aspectRatio((width.toFloat() / height.coerceAtLeast(1)).coerceIn(.45f, 2.2f)).clip(RoundedCornerShape(18.dp)),
                                contentScale = if (mode == SquareMode.CROP) ContentScale.Crop else ContentScale.Fit
                            )
                            Text("Saída: ${width}×${height} • estimado ${estimatedBytes?.let(::formatBytes) ?: "—"}", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
        if (uri != null) {
            item {
                Card {
                    Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        Text("Presets quadrados", fontWeight = FontWeight.Bold)
                        listOf(1200, 1400, 1600, 2000, 3000, 4000, 6000, 8000).chunked(3).forEach { row ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) { row.forEach { v ->
                                FilterChip(width == v && height == v, { width=v;height=v;customWidth=v.toString();customHeight=v.toString();preserveSourceRatio=false }, { Text("$v") }, modifier=Modifier.weight(1f))
                            }; repeat(4-row.size){Spacer(Modifier.weight(1f))} }
                        }
                        Text("Presets retangulares", fontWeight = FontWeight.Bold)
                        listOf(1280 to 720,1920 to 1080,3840 to 2160,720 to 1280,1080 to 1920,2160 to 3840).chunked(3).forEach { row ->
                            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(5.dp)){row.forEach{(w,h)->FilterChip(width==w&&height==h,{width=w;height=h;customWidth=w.toString();customHeight=h.toString();preserveSourceRatio=false},{Text("${w}×${h}",fontSize=9.sp)},modifier=Modifier.weight(1f))}}
                        }
                        Text("Formato", fontWeight = FontWeight.Bold)
                        formats.chunked(4).forEach { row -> Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){ row.forEach { f -> FilterChip(format==f,{format=f},{Text(f)},modifier=Modifier.weight(1f)) }; repeat(4-row.size){Spacer(Modifier.weight(1f))} } }
                        Text("Destino", fontWeight = FontWeight.Bold)
                        Text(if(customFolder==null) "Padrão: Imagens/SONUS/Images" else "Pasta personalizada selecionada", style=MaterialTheme.typography.bodySmall)
                        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                            OutlinedButton(onClick={folderPicker.launch(customFolder)},modifier=Modifier.weight(1f)){Text("Escolher pasta")}
                            if(customFolder!=null) OutlinedButton(onClick={customFolder=null;context.getSharedPreferences("sonus_image_output", android.content.Context.MODE_PRIVATE).edit().remove("tree").apply()}){Text("Usar padrão")}
                        }

                    }
                }
            }
            item {
                Button(
                    onClick = {
                        val ext = when (format) { "PNG" -> "png"; "WEBP" -> "webp"; "HEIC" -> "heic"; "HEIF" -> "heif"; "JPEG" -> "jpeg"; "BMP" -> "bmp"; "TIFF" -> "tiff"; "TIF" -> "tif"; else -> "jpg" }
                        val sources=batchUris.ifEmpty { listOfNotNull(uri) }; if(sources.isEmpty()) return@Button
                        scope.launch {
                            exportBusy=true; exportProgress=0
                            val started=System.currentTimeMillis(); var ok=0; var failed=0; var blocked=0; var usageOk=unlimited || onSpend(1)
                            if(!usageOk){exportBusy=false;message="Você precisa de 1 Moeda SONUS para usar Imagem Convert.";return@launch}
                            if(!unlimited) SonusNotificationCenter.recordPremiumUse(context,"Imagem Convert")
                            for ((index, src) in sources.withIndex()) {
                                val name="sonus_${System.currentTimeMillis()}_${index+1}_${width}x$height.$ext"
                                val out=withContext(Dispatchers.IO){ customFolder?.let{com.sonusstudios.streampulse.core.SonusStorage.createInTree(context,it,name,mime)} ?: com.sonusstudios.streampulse.core.SonusStorage.createImage(context,name,mime) }
                                if(out==null){failed++;continue}
                                val r=withContext(Dispatchers.IO){AudioToolEngine.convertImage(context,src,out,width,height,format,100,SquareMode.FIT_BACKGROUND)}
                                if(r.isSuccess){
                                    if(customFolder==null)com.sonusstudios.streampulse.core.SonusStorage.finish(context,out)
                                    if(unlimited) SonusNotificationCenter.recordPremiumUse(context,"Imagem Convert")
                                    ok++

                                }else{failed++;if(customFolder==null)com.sonusstudios.streampulse.core.SonusStorage.abort(context,out)}
                                exportProgress=(((index+1).toFloat()/sources.size.coerceAtLeast(1))*100f).toInt().coerceIn(0,100)
                            }
                            exportBusy=false
                            message=when {
                                !usageOk -> "Moeda SONUS indisponível."
                                failed==0 -> "✓ $ok imagem(ns) processada(s) em ${width}×${height}${if(unlimited) " • Diamante" else " • 1 Moeda SONUS pela operação"}"
                                else -> "$ok concluída(s) • $failed falha(s)"
                            }
                            onTrack("Imagem: converter e redimensionar",failed==0&&blocked==0&&usageOk,System.currentTimeMillis()-started)
                        }
                    },
                    enabled = !exportBusy && (unlimited || coins > 0),
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    colors = ButtonDefaults.buttonColors(containerColor=Color(0xFF1E9E55),contentColor=Color.White)
                ) { Text("Converter e salvar",fontWeight=FontWeight.Bold) }
            }
        }
        message?.let { item { Text(it, fontWeight = FontWeight.Bold) } }
    }
    if(exportBusy) SonusExportProgressDialog(percent=exportProgress,phase="Convertendo e salvando imagens…",title="Imagem Convert")
}

@Composable
private fun VoiceRecorderTool(
    onBack: () -> Unit,
    unlimited: Boolean,
    coins: Int,
    onSpend: suspend (Int) -> Boolean,
    onTrack: (String, Boolean?, Long?) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val rec by RecorderBus.state.collectAsState()

    var sampleRate by remember { mutableIntStateOf(48000) }
    var channels by remember { mutableIntStateOf(1) }
    var bitDepth by remember { mutableIntStateOf(16) }
    var mode by remember { mutableStateOf("VOICE") }
    var format by remember { mutableStateOf("WAV") }
    var bitrate by remember { mutableIntStateOf(256) }
    var skipSilence by remember { mutableStateOf(false) }
    var countdownSeconds by remember { mutableIntStateOf(0) }
    var countdownLeft by remember { mutableIntStateOf(0) }
    var pendingStart by remember { mutableStateOf(false) }
    var timerMinutes by remember { mutableIntStateOf(0) }
    var markers by remember { mutableStateOf<List<Long>>(emptyList()) }
    var selectedDeviceId by remember { mutableIntStateOf(-1) }
    var settingsOpen by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var wave by remember { mutableStateOf(List(96) { 0f }) }
    var lastFile by remember { mutableStateOf<File?>(null) }
    var lastPublicUri by remember { mutableStateOf<Uri?>(null) }
    var lastAutoSavedPath by remember { mutableStateOf<String?>(null) }
    var exportBusy by remember { mutableStateOf(false) }
    var exportProgress by remember { mutableIntStateOf(0) }
    var previewPlayer by remember { mutableStateOf<MediaPlayer?>(null) }
    var previewPlaying by remember { mutableStateOf(false) }
    var renameOpen by remember { mutableStateOf(false) }
    var renameValue by remember { mutableStateOf("") }
    val recorderHistoryPrefs = remember { context.getSharedPreferences("sonus_recorder_history_v1", Context.MODE_PRIVATE) }
    var historyClearedAt by remember { mutableLongStateOf(recorderHistoryPrefs.getLong("cleared_at", 0L)) }
    var confirmClearHistory by remember { mutableStateOf(false) }

    val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    var inputDevices by remember { mutableStateOf(audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS).toList()) }
    fun refreshInputs() {
        inputDevices = audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS).toList()
        if (selectedDeviceId != -1 && inputDevices.none { it.id == selectedDeviceId }) selectedDeviceId = -1
    }

    val selectedInput = inputDevices.firstOrNull { it.id == selectedDeviceId }
    val selectedChannelCounts = selectedInput?.channelCounts?.toList().orEmpty()
    val availableChannelOptions = buildList {
        add(1); add(2)
        if (selectedInput != null && selectedChannelCounts.any { it >= 6 }) add(6)
        if (selectedInput != null && selectedChannelCounts.any { it >= 8 }) add(8)
    }.distinct()
    val availableBitDepths = buildList {
        add(16)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) add(24)
        add(32)
    }

    LaunchedEffect(selectedDeviceId, inputDevices) {
        if (channels !in availableChannelOptions) channels = if (2 in availableChannelOptions) 2 else 1
    }
    LaunchedEffect(rec.amplitude) {
        if (rec.recording) wave = (wave.drop(1) + rec.amplitude.coerceIn(0f, 1f)).takeLast(96)
        if (!rec.recording && rec.outputPath != null) lastFile = File(rec.outputPath)
    }
    LaunchedEffect(rec.durationMs, timerMinutes) {
        if (rec.recording && timerMinutes > 0 && rec.durationMs >= timerMinutes * 60_000L) {
            VoiceRecorderService.stop(context)
            message = "✓ Temporizador concluído."
        }
    }
    LaunchedEffect(pendingStart) {
        if (pendingStart) {
            countdownLeft = countdownSeconds
            while (countdownLeft > 0 && pendingStart) { delay(1000); countdownLeft-- }
            if (pendingStart) {
                VoiceRecorderService.start(context, sampleRate, channels, mode, selectedDeviceId, skipSilence, bitDepth)
                markers = emptyList()
                wave = List(96) { 0f }
            }
            pendingStart = false
        }
    }

    // Code122: a gravação nasce e é finalizada no armazenamento privado. Somente depois
    // de um WAV válido (>0 bytes) o item público do MediaStore é criado e publicado.
    LaunchedEffect(rec.recording, rec.outputPath) {
        val path = rec.outputPath
        if (!rec.recording && !path.isNullOrBlank() && path != lastAutoSavedPath) {
            val file = File(path)
            if (file.exists() && file.length() > 44L) {
                lastAutoSavedPath = path
                lastPublicUri = null
                val saved = withContext(Dispatchers.IO) {
                    runCatching {
                        val publicName = file.name.ifBlank { "SONUS_${System.currentTimeMillis()}.wav" }
                        val uri = SonusStorage.createAudio(context, publicName, "audio/wav", SonusStorage.Bucket.RECORDINGS)
                            ?: error("Não foi possível criar o arquivo final.")
                        try {
                            SonusStorage.openOutput(context, uri)?.use { output -> file.inputStream().use { it.copyTo(output) } }
                                ?: error("Não foi possível escrever a gravação final.")
                            SonusStorage.finish(context, uri)
                            uri
                        } catch (t: Throwable) {
                            SonusStorage.abort(context, uri)
                            throw t
                        }
                    }
                }
                lastPublicUri = saved.getOrNull()
                message = if (saved.isSuccess) "✓ Gravação salva em SONUS/Recordings." else "Não foi possível salvar a gravação. O rascunho foi preservado."
                onTrack("Gravador: salvar WAV", saved.isSuccess, null)
            }
        }
    }

    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) pendingStart = true else message = "Permissão de microfone necessária."
    }

    fun requestStart() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            pendingStart = true
        } else permission.launch(Manifest.permission.RECORD_AUDIO)
    }

    fun mimeFor(formatName: String): String = when (formatName) {
        "MP3" -> "audio/mpeg"
        "FLAC" -> "audio/flac"
        "M4A/AAC" -> "audio/mp4"
        "OGG" -> "audio/ogg"
        "OPUS" -> "audio/opus"
        "WEBM/OPUS" -> "audio/webm"
        "AMR" -> "audio/amr"
        else -> "audio/wav"
    }

    fun exportCurrent(noiseReduction: Boolean = false) {
        val source = lastFile?.takeIf { it.exists() && it.length() > 44L } ?: run {
            message = "Nenhuma gravação válida para salvar."
            return
        }
        scope.launch {
            exportBusy = true; exportProgress = 8
            val started = System.currentTimeMillis()
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val outFormat = if (noiseReduction) "WAV" else format
                    val ext = recordExt(outFormat)
                    val suffix = if (noiseReduction) "_sem_ruido" else "_${outFormat.replace('/', '_')}"
                    val name = "${source.nameWithoutExtension}$suffix.$ext"
                    val uri = SonusStorage.createAudio(context, name, mimeFor(outFormat), SonusStorage.Bucket.RECORDINGS)
                        ?: error("Não foi possível criar o arquivo de saída.")
                    try {
                        val engine = if (noiseReduction) {
                            AudioToolEngine.enhanceVoiceFile(context, source, uri, strongNoiseReduction = true)
                        } else {
                            AudioToolEngine.convertRecording(context, source, uri, outFormat, bitrate)
                        }
                        engine.getOrThrow()
                        SonusStorage.finish(context, uri)
                        uri
                    } catch (t: Throwable) {
                        SonusStorage.abort(context, uri)
                        throw t
                    }
                }
            }
            exportProgress = 100; exportBusy = false
            message = if (result.isSuccess) {
                if (noiseReduction) "✓ Nova cópia com redução de ruído salva." else "✓ Exportado em $format para SONUS/Recordings."
            } else "Não foi possível concluir a exportação. A gravação original foi preservada."
            onTrack(if (noiseReduction) "Gravador: reduzir ruído" else "Gravador: exportar $format", result.isSuccess, System.currentTimeMillis() - started)
        }
    }

    fun togglePreview() {
        val file = lastFile?.takeIf { it.exists() } ?: return
        if (previewPlaying) {
            previewPlayer?.stop(); previewPlayer?.release(); previewPlayer = null; previewPlaying = false
        } else {
            runCatching {
                MediaPlayer().apply {
                    setDataSource(file.absolutePath)
                    setOnCompletionListener { player -> player.release(); previewPlayer = null; previewPlaying = false }
                    prepare(); start()
                    previewPlayer = this
                    previewPlaying = true
                }
            }.onFailure { message = "Não foi possível reproduzir esta gravação." }
        }
    }
    DisposableEffect(Unit) { onDispose { runCatching { previewPlayer?.release() } } }

    val freeSpace = remember(rec.bytesWritten) { StatFs(context.filesDir.absolutePath).availableBytes }
    val recBytesPerSample = when (rec.bitDepth) { 24 -> 3L; 32 -> 4L; else -> 2L }
    val byteRate = (rec.sampleRate.coerceAtLeast(1) * rec.channels.coerceAtLeast(1) * recBytesPerSample).coerceAtLeast(1L)
    val remainingMs = freeSpace / byteRate * 1000L
    val recentRecordings = remember(lastFile, rec.recording, historyClearedAt) {
        File(context.filesDir, "recordings").listFiles()
            ?.filter { it.extension.equals("wav", true) && it.lastModified() > historyClearedAt }
            ?.sortedByDescending { it.lastModified() }
            ?.take(5)
            .orEmpty()
    }

    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF05070B), Color(0xFF10182A), Color(0xFF06080E)))
        )
    ) {
        LazyColumn(
            Modifier.fillMaxSize().padding(horizontal = 16.dp),
            contentPadding = PaddingValues(bottom = 30.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Voltar", tint = Color.White) }
                    Column(Modifier.weight(1f)) {
                        Text("Gravador de Voz", color = Color.White, fontWeight = FontWeight.Black, fontSize = 22.sp)
                        Text("SONUS REC", color = Color(0xFF7EA8FF), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    }
                    FilledTonalIconButton(onClick = { settingsOpen = true }, colors = IconButtonDefaults.filledTonalIconButtonColors(containerColor = Color(0xFF1C2944))) {
                        Icon(Icons.Default.Tune, "Ajustes", tint = Color(0xFF9DBBFF))
                    }
                }
            }
            item {
                Card(
                    shape = RoundedCornerShape(30.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0A101B)),
                    border = BorderStroke(1.dp, Color(0xFF35548D).copy(alpha = .65f))
                ) {
                    Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Surface(shape = RoundedCornerShape(50), color = when { rec.paused -> Color(0xFFFFB548).copy(.16f); rec.recording -> Color(0xFFFF4768).copy(.16f); else -> Color(0xFF5F8FFF).copy(.14f) }) {
                            Text(
                                when { pendingStart -> "COMEÇANDO EM ${countdownLeft.coerceAtLeast(0)}"; rec.paused -> "PAUSADO"; rec.recording -> "GRAVANDO"; else -> "PRONTO" },
                                Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                                color = when { rec.paused -> Color(0xFFFFC96B); rec.recording -> Color(0xFFFF7189); else -> Color(0xFF90B1FF) },
                                fontWeight = FontWeight.Black,
                                style = MaterialTheme.typography.labelMedium
                            )
                        }
                        Text(formatDuration(rec.durationMs), color = Color.White, fontSize = 52.sp, fontWeight = FontWeight.Light)
                        Canvas(Modifier.fillMaxWidth().height(110.dp)) {
                            if (wave.isEmpty()) return@Canvas
                            val mid = size.height / 2f
                            val step = size.width / wave.size.coerceAtLeast(1)
                            wave.forEachIndexed { index, amp ->
                                val h = (6f + amp * size.height * .40f).coerceAtMost(size.height * .46f)
                                val x = index * step + step / 2f
                                drawLine(Color(0xFF7EA8FF).copy(alpha = .45f + amp * .55f), Offset(x, mid - h), Offset(x, mid + h), strokeWidth = max(2f, step * .34f), cap = StrokeCap.Round)
                            }
                            drawLine(Color.White.copy(alpha=.08f), Offset(0f, mid), Offset(size.width, mid), 1f)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(18.dp), verticalAlignment = Alignment.CenterVertically) {
                            if (!rec.recording && !pendingStart) {
                                Button(onClick = ::requestStart, shape = CircleShape, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF4768)), modifier = Modifier.size(84.dp), contentPadding = PaddingValues(0.dp)) {
                                    Icon(Icons.Default.Mic, "Gravar", modifier = Modifier.size(34.dp))
                                }
                            } else if (pendingStart) {
                                OutlinedButton(onClick = { pendingStart = false; countdownLeft = 0 }, shape = RoundedCornerShape(18.dp)) { Text("Cancelar") }
                            } else {
                                FilledTonalIconButton(onClick = { if (rec.paused) VoiceRecorderService.resume(context) else VoiceRecorderService.pause(context) }, modifier = Modifier.size(62.dp), colors = IconButtonDefaults.filledTonalIconButtonColors(containerColor = Color(0xFF223354))) {
                                    Icon(if (rec.paused) Icons.Default.PlayArrow else Icons.Default.Pause, "Pausar/continuar", tint = Color.White)
                                }
                                Button(onClick = { VoiceRecorderService.stop(context) }, shape = CircleShape, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF4768)), modifier = Modifier.size(76.dp), contentPadding = PaddingValues(0.dp)) {
                                    Icon(Icons.Default.Stop, "Finalizar", modifier = Modifier.size(31.dp))
                                }
                                FilledTonalIconButton(onClick = { markers = markers + rec.durationMs }, modifier = Modifier.size(62.dp), colors = IconButtonDefaults.filledTonalIconButtonColors(containerColor = Color(0xFF1B2843))) {
                                    Icon(Icons.Default.BookmarkAdd, "Marcar", tint = Color(0xFF93B5FF))
                                }
                            }
                        }
                        Text(
                            if (rec.recording) "${formatBytes(rec.bytesWritten)} • espaço para ~${formatDuration(remainingMs)}" else "Toque no microfone para começar",
                            color = Color.White.copy(alpha = .52f), style = MaterialTheme.typography.labelMedium
                        )
                    }
                }
            }

            lastFile?.takeIf { it.exists() && !rec.recording }?.let { file ->
                item {
                    Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF111A2C))) {
                        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("Última gravação", color = Color.White, fontWeight = FontWeight.Black, fontSize = 18.sp)
                            Text(file.name, color = Color(0xFFB9C9E8), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("${formatDuration(rec.durationMs)} • ${formatBytes(file.length())} • WAV", color = Color.White.copy(alpha=.55f), style = MaterialTheme.typography.bodySmall)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = ::togglePreview, modifier = Modifier.weight(1f)) {
                                    Icon(if (previewPlaying) Icons.Default.Stop else Icons.Default.PlayArrow, null); Spacer(Modifier.width(5.dp)); Text(if (previewPlaying) "Parar" else "Ouvir")
                                }
                                OutlinedButton(onClick = { renameValue = file.nameWithoutExtension; renameOpen = true }, modifier = Modifier.weight(1f)) {
                                    Icon(Icons.Default.DriveFileRenameOutline, null); Spacer(Modifier.width(5.dp)); Text("Renomear")
                                }
                            }
                            TextButton(
                                onClick = {
                                    runCatching { previewPlayer?.release() }; previewPlayer = null; previewPlaying = false
                                    lastPublicUri?.let { runCatching { context.contentResolver.delete(it, null, null) } }
                                    runCatching { file.delete() }
                                    lastFile = null; lastPublicUri = null; message = "Gravação removida."
                                },
                                modifier = Modifier.align(Alignment.End)
                            ) { Icon(Icons.Default.DeleteOutline, null); Spacer(Modifier.width(5.dp)); Text("Excluir", color = Color(0xFFFF7C90)) }
                            Button(onClick = { exportCurrent(false) }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4E78D8))) {
                                Icon(Icons.Default.SaveAlt, null); Spacer(Modifier.width(7.dp)); Text("Salvar/exportar em $format", fontWeight = FontWeight.Bold)
                            }
                            OutlinedButton(onClick = { exportCurrent(true) }, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Default.GraphicEq, null); Spacer(Modifier.width(7.dp)); Text("Criar cópia com redução de ruído")
                            }
                        }
                    }
                }
            }

            if (markers.isNotEmpty() && !rec.recording) item {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF151B27)), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(13.dp)) {
                        Text("Marcadores", color = Color.White, fontWeight = FontWeight.Bold)
                        markers.forEachIndexed { i, ms -> Text("${i + 1}. ${formatDuration(ms)}", color = Color.White.copy(.65f), style = MaterialTheme.typography.bodySmall) }
                    }
                }
            }
            if (recentRecordings.isNotEmpty() && !rec.recording) item {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0D1422)), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text("Gravações recentes", color = Color.White, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                            TextButton(onClick = { confirmClearHistory = true }) {
                                Icon(Icons.Default.DeleteSweep, null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Limpar")
                            }
                        }
                        recentRecordings.forEach { f ->
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.AudioFile, null, tint = Color(0xFF729CF0), modifier = Modifier.size(18.dp)); Spacer(Modifier.width(7.dp))
                                Text(f.name, modifier = Modifier.weight(1f), color = Color.White.copy(.72f), style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(formatBytes(f.length()), color = Color.White.copy(.42f), style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
            message?.let { item { Text(it, color = if (it.startsWith("✓")) Color(0xFF66D996) else Color(0xFFFFC66D), fontWeight = FontWeight.Bold) } }
            rec.warning?.let { item { Text("ℹ $it", color = Color(0xFF90B1FF), style = MaterialTheme.typography.bodySmall) } }
            rec.error?.let { item { Text("Não foi possível continuar a gravação.", color = Color(0xFFFF7189)) } }
        }
    }

    if (confirmClearHistory) {
        AlertDialog(
            onDismissRequest = { confirmClearHistory = false },
            title = { Text("Limpar histórico?") },
            text = { Text("A lista de gravações recentes será limpa. Os arquivos de áudio salvos no aparelho não serão excluídos.") },
            confirmButton = {
                Button(onClick = {
                    historyClearedAt = System.currentTimeMillis()
                    recorderHistoryPrefs.edit().putLong("cleared_at", historyClearedAt).apply()
                    confirmClearHistory = false
                    message = "✓ Histórico limpo. Seus áudios foram preservados."
                }) { Text("Limpar") }
            },
            dismissButton = { TextButton(onClick = { confirmClearHistory = false }) { Text("Cancelar") } }
        )
    }

    if (settingsOpen) {
        Dialog(onDismissRequest = { settingsOpen = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Card(
                Modifier.fillMaxWidth(.94f).fillMaxHeight(.88f),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0A101B)),
                border = BorderStroke(1.dp, Color(0xFF36558E))
            ) {
                Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text("Ajustes do gravador", color = Color.White, fontWeight = FontWeight.Black, fontSize = 21.sp); Text("Som, qualidade e automações", color = Color(0xFF8FA9D8), style = MaterialTheme.typography.bodySmall) }
                        IconButton(onClick = { settingsOpen = false }) { Icon(Icons.Default.Close, "Fechar", tint = Color.White) }
                    }
                    LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        item {
                            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF142548)), shape = RoundedCornerShape(18.dp)) {
                                Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("Saída", color = Color(0xFF9FBCFF), fontWeight = FontWeight.Black)
                                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        items(listOf("WAV", "MP3", "M4A/AAC", "FLAC", "OGG", "OPUS", "WEBM/OPUS", "AMR")) { x -> FilterChip(format == x, { format = x }, { Text(x) }) }
                                    }
                                    if (format in listOf("MP3", "M4A/AAC", "OPUS", "WEBM/OPUS")) {
                                        val options = SonusMediaStandards.bitratePresets(format)
                                        Text("Bitrate", color = Color.White, fontWeight = FontWeight.Bold)
                                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            items(options) { value -> FilterChip(bitrate == value, { bitrate = value }, { Text("$value kbps") }) }
                                        }
                                    }
                                }
                            }
                        }
                        item {
                            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF241D42)), shape = RoundedCornerShape(18.dp)) {
                                Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("Qualidade de captura", color = Color(0xFFC6AEFF), fontWeight = FontWeight.Black)
                                    Text("Preset", color = Color.White, fontWeight = FontWeight.Bold)
                                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        items(listOf("VOICE", "MUSIC", "PODCAST", "INTERVIEW", "INSTRUMENT", "AMBIENT", "ASMR")) { preset ->
                                            FilterChip(mode == preset, { mode = preset }, { Text(preset.lowercase().replaceFirstChar { it.uppercase() }) })
                                        }
                                    }
                                    Text("Sample rate", color = Color.White, fontWeight = FontWeight.Bold)
                                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) { items(listOf(44100,48000,88200,96000,192000)) { r -> FilterChip(sampleRate==r,{sampleRate=r},{Text("${r/1000.0}k")}) } }
                                    Text("Canais", color = Color.White, fontWeight = FontWeight.Bold)
                                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) { items(availableChannelOptions) { count -> FilterChip(channels==count,{channels=count},{Text(channelLabelUi(count))}) } }
                                    Text("Profundidade", color = Color.White, fontWeight = FontWeight.Bold)
                                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) { items(availableBitDepths) { depth -> FilterChip(bitDepth==depth,{bitDepth=depth},{Text(if(depth==32)"32-bit float" else "$depth-bit")}) } }
                                }
                            }
                        }
                        item {
                            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF123329)), shape = RoundedCornerShape(18.dp)) {
                                Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("Comportamento", color = Color(0xFF7FE1B0), fontWeight = FontWeight.Black)
                                    Row(verticalAlignment = Alignment.CenterVertically) { Switch(skipSilence,{skipSilence=it}); Spacer(Modifier.width(8.dp)); Column { Text("Ignorar silêncio", color=Color.White,fontWeight=FontWeight.Bold); Text("Reduz pausas e tamanho do rascunho.",color=Color.White.copy(.55f),style=MaterialTheme.typography.labelSmall) } }
                                    Text("Contagem regressiva", color = Color.White, fontWeight = FontWeight.Bold)
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf(0,3,5,10).forEach { sec -> FilterChip(countdownSeconds==sec,{countdownSeconds=sec},{Text(if(sec==0)"Off" else "${sec}s")}) } }
                                    Text("Parar automaticamente", color = Color.White, fontWeight = FontWeight.Bold)
                                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) { items(listOf(0,5,10,30,60)) { min -> FilterChip(timerMinutes==min,{timerMinutes=min},{Text(if(min==0)"Off" else "${min}min")}) } }
                                }
                            }
                        }
                        item {
                            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF312116)), shape = RoundedCornerShape(18.dp)) {
                                Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text("Entrada", color = Color(0xFFFFBE7C), fontWeight = FontWeight.Black, modifier = Modifier.weight(1f)); TextButton(onClick = ::refreshInputs) { Text("Atualizar") } }
                                    FilterChip(selectedDeviceId==-1,{selectedDeviceId=-1},{Text("Automática")})
                                    inputDevices.forEach { device -> FilterChip(selectedDeviceId==device.id,{selectedDeviceId=device.id},{Text(device.productName?.toString()?.take(28) ?: "Entrada ${device.id}")}) }
                                }
                            }
                        }
                    }
                    Button(onClick = { settingsOpen = false }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4E78D8))) { Text("Concluir", fontWeight = FontWeight.Black) }
                }
            }
        }
    }

    if (renameOpen) {
        AlertDialog(
            onDismissRequest = { renameOpen = false },
            title = { Text("Renomear gravação") },
            text = { OutlinedTextField(renameValue, { renameValue = it }, singleLine = true, label = { Text("Nome") }) },
            confirmButton = {
                TextButton(onClick = {
                    val source = lastFile
                    if (source != null) {
                        val safe = renameValue.trim().replace(Regex("[\\/:*?\"<>|]"), "_").ifBlank { source.nameWithoutExtension }
                        val target = File(source.parentFile, "$safe.wav")
                        val ok = source == target || source.renameTo(target)
                        if (ok) {
                            lastFile = target
                            val publicRenamed = lastPublicUri?.let { uri ->
                                runCatching {
                                    context.contentResolver.update(uri, android.content.ContentValues().apply { put(MediaStore.MediaColumns.DISPLAY_NAME, "$safe.wav") }, null, null) > 0
                                }.getOrDefault(false)
                            } ?: true
                            message = if (publicRenamed) "✓ Gravação renomeada." else "✓ Rascunho renomeado; o nome público será atualizado na próxima exportação."
                        } else message = "Não foi possível renomear o rascunho."
                    }
                    renameOpen = false
                }) { Text("Renomear") }
            },
            dismissButton = { TextButton(onClick = { renameOpen = false }) { Text("Cancelar") } }
        )
    }
    if (exportBusy) SonusExportProgressDialog(percent = exportProgress, phase = "Finalizando arquivo…", title = "Gravador de Voz")
}

@Composable
internal fun KaraokeTool(onBack: () -> Unit, onTrack: (String, Boolean?, Long?) -> Unit, preferences: UserPreferences) {
    val context = LocalContext.current
    val configuration = LocalConfiguration.current
    val activity = remember(context) { context.findActivityForTools() }
    val scope = rememberCoroutineScope()
    val rec by RecorderBus.state.collectAsState()
    val playerController = rememberStreamPulseYouTubeController()

    var query by remember { mutableStateOf("") }
    var searchMode by remember { mutableStateOf("karaoke") }
    var searching by remember { mutableStateOf(false) }
    var searchError by remember { mutableStateOf<String?>(null) }
    var results by remember { mutableStateOf<List<YouTubeVideoResult>>(emptyList()) }
    var selectedVideo by remember { mutableStateOf<YouTubeVideoResult?>(null) }
    var sessionStarted by remember { mutableLongStateOf(0L) }
    var score by remember { mutableStateOf<Int?>(null) }
    var components by remember { mutableStateOf<Map<String, Int>>(emptyMap()) }
    var analysisQuality by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var showQualityInfo by remember { mutableStateOf(false) }
    var karaokeFullscreen by remember { mutableStateOf(false) }
    var lastRecordingPath by remember { mutableStateOf<String?>(null) }
    var lastRecordingTitle by remember { mutableStateOf("Apresentação SONUS") }
    var recordingPlayer by remember { mutableStateOf<MediaPlayer?>(null) }
    var recordingPlaying by remember { mutableStateOf(false) }
    var saveBusy by remember { mutableStateOf(false) }

    val saveRecordingLauncher = rememberLauncherForActivityResult(SonusAutoCreateDocument("audio/mp4", com.sonusstudios.streampulse.core.SonusStorage.Bucket.RECORDINGS)) { out ->
        val path = lastRecordingPath
        if (out != null && path != null) {
            scope.launch {
                saveBusy = true
                val started = System.currentTimeMillis()
                val result = withContext(Dispatchers.IO) {
                    AudioToolEngine.convertRecording(context, File(path), out, "M4A/AAC", 256)
                }
                saveBusy = false
                message = if (result.isSuccess) "✓ Apresentação salva em alta qualidade." else "Falha ao salvar: ${result.exceptionOrNull()?.message ?: "erro desconhecido"}"
                onTrack("Karaokê: salvar gravação", result.isSuccess, System.currentTimeMillis() - started)
            }
        }
    }

    DisposableEffect(activity) {
        onDispose {
            // Ao sair do Karaokê, devolve a tela para o comportamento normal do aparelho.
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            runCatching { recordingPlayer?.release() }
        }
    }

    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            VoiceRecorderService.start(context, 48000, 2, "VOICE", bitDepth = 24)
            sessionStarted = System.currentTimeMillis()
            score = null
            components = emptyMap()
            analysisQuality = null
            message = null
        } else {
            message = "Permissão de microfone necessária para avaliar a apresentação."
        }
    }

    fun searchInsideStreamPulse() {
        if (query.isBlank() || searching) return
        scope.launch {
            searching = true
            searchError = null
            message = null
            if (SonusProcessNotifier.isOffline(context)) { searching=false; searchError="Sem internet para pesquisar no YouTube."; return@launch }
            val started = System.currentTimeMillis()
            val result = YouTubeSearchClient.search(context, query, searchMode)
            searching = false
            if (result.isSuccess) {
                results = result.getOrDefault(emptyList())
                selectedVideo = null
                if (results.isEmpty()) {
                    searchError = "Nenhum vídeo incorporável foi encontrado. Tente outra busca."
                }
            } else {
                results = emptyList()
                selectedVideo = null
                searchError = result.exceptionOrNull()?.message ?: "Não foi possível pesquisar no YouTube."
            }
            onTrack("Karaokê: busca interna", result.isSuccess, System.currentTimeMillis() - started)
        }
    }

    fun finishPerformance() {
        val elapsed = (System.currentTimeMillis() - sessionStarted).coerceAtLeast(0L)
        val durationMs = max(rec.durationMs, elapsed)
        val enoughTime = durationMs >= 8_000L
        val enoughVoice = rec.voicedRatio >= .15f && rec.averageAmplitude >= .014f && rec.pitchHz > 0f

        lastRecordingPath = rec.outputPath
        lastRecordingTitle = selectedVideo?.title?.take(80) ?: "Apresentação SONUS"
        VoiceRecorderService.stop(context)

        if (!enoughTime) {
            score = null
            components = emptyMap()
            analysisQuality = "Insuficiente"
            message = "Apresentação curta demais para pontuar. Cante por pelo menos 8 segundos."
            onTrack("Karaokê: apresentação curta", false, durationMs)
            return
        }
        if (!enoughVoice) {
            score = null
            components = emptyMap()
            analysisQuality = "Insuficiente"
            message = "Não detectamos canto suficiente para avaliar. Tente cantar mais perto do microfone."
            onTrack("Karaokê: voz insuficiente", false, durationMs)
            return
        }

        val energy = (((rec.averageAmplitude - .014f) / .21f) * 100f)
            .roundToInt().coerceIn(0, 100)
        val voice = (((rec.voicedRatio - .12f) / .68f) * 100f)
            .roundToInt().coerceIn(0, 100)
        val stability = (rec.pitchStability * 100f).roundToInt().coerceIn(0, 100)
        val rhythm = ((1f - (abs(rec.voicedRatio - .58f) / .58f)) * 100f)
            .roundToInt().coerceIn(0, 100)
        val clippingPenalty = if (rec.averageAmplitude > .88f) 10 else 0
        val final = (
            voice * .30f +
                stability * .28f +
                rhythm * .22f +
                energy * .20f -
                clippingPenalty
            ).roundToInt().coerceIn(0, 100)

        components = linkedMapOf(
            "Voz" to voice,
            "Estabilidade" to stability,
            "Ritmo aprox." to rhythm,
            "Energia" to energy
        )
        score = final
        analysisQuality = when {
            durationMs >= 30_000L && rec.voicedRatio >= .35f -> "Boa"
            durationMs >= 15_000L && rec.voicedRatio >= .22f -> "Moderada"
            else -> "Limitada"
        }
        message = null
        onTrack("Karaokê: ${selectedVideo?.title?.take(70) ?: "apresentação"} • $final/100", true, durationMs)
    }

    val liveScore = remember(rec.recording, rec.durationMs, rec.averageAmplitude, rec.voicedRatio, rec.pitchStability) {
        if (!rec.recording || rec.durationMs < 1_000L || rec.voicedRatio < .05f) 0
        else {
            val e = (((rec.averageAmplitude - .014f) / .21f) * 100f).roundToInt().coerceIn(0, 100)
            val v = (((rec.voicedRatio - .12f) / .68f) * 100f).roundToInt().coerceIn(0, 100)
            val st = (rec.pitchStability * 100f).roundToInt().coerceIn(0, 100)
            (e * .28f + v * .38f + st * .34f).roundToInt().coerceIn(0, 100)
        }
    }

    LaunchedEffect(selectedVideo?.videoId, playerController.ready) {
        if (selectedVideo != null && playerController.ready) {
            delay(12_000)
            playerController.reportStalledPlayer()
        }
    }

    LaunchedEffect(playerController.endedGeneration) {
        if (playerController.endedGeneration > 0 && rec.recording) {
            finishPerformance()
            message = "Música finalizada • apresentação encerrada automaticamente."
        }
    }

    if (showQualityInfo) {
        AlertDialog(
            onDismissRequest = { showQualityInfo = false },
            title = { Text("Qualidade do vídeo") },
            text = {
                Text(
                    "Qualidade atual: ${playerController.qualityLabel}.\n\n" +
                        "O YouTube escolhe a qualidade automaticamente conforme conexão, aparelho e disponibilidade do vídeo. " +
                        "A API oficial não permite ao SONUS forçar manualmente 720p/1080p."
                )
            },
            confirmButton = { TextButton(onClick = { showQualityInfo = false }) { Text("Entendi") } }
        )
    }

    if (karaokeFullscreen && selectedVideo != null) {
        DisposableEffect(Unit) {
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            onDispose { activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED }
        }
        Dialog(
            onDismissRequest = { karaokeFullscreen = false },
            properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
        ) {
            Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
                YouTubeEmbedPlayer(
                    videoId = selectedVideo!!.videoId,
                    controller = playerController,
                    modifier = Modifier.fillMaxSize()
                )
                IconButton(
                    onClick = { karaokeFullscreen = false },
                    modifier = Modifier.align(Alignment.TopEnd).padding(12.dp).background(Color.Black.copy(alpha=.55f), CircleShape)
                ) { Icon(Icons.Default.FullscreenExit, "Sair da tela cheia", tint=Color.White) }
            }
        }
    }

    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF080B19), Color(0xFF15102E), Color(0xFF071624)))
        )
    ) {
        KaraokeStageBackground(Modifier.matchParentSize())
        LazyColumn(
            Modifier.fillMaxSize().padding(horizontal = 16.dp),
            contentPadding = PaddingValues(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Voltar", tint = Color.White) }
                Column(Modifier.weight(1f)) {
                    Text("Karaokê SONUS", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black)
                    Text("Seu palco • cante, grave e acompanhe seu desempenho", color = Color.White.copy(alpha = .68f), style = MaterialTheme.typography.bodySmall)
                }
                if (preferences.showDataUsageMonitor) SessionDataUsageChip(preferences)
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF171B38).copy(alpha = .90f))) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Pesquise, escolha e reproduza sem sair do SONUS.", fontWeight = FontWeight.Bold, color = Color.White)
                    Text(
                        "Pesquisa e reprodução usam recursos oficiais do YouTube. O SONUS não baixa mídia nem bloqueia anúncios. " +
                            "A avaliação vocal é local e não afirma comparar notas musicais exatas da gravação original.",
                        style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = .72f)
                    )
                }
            }
        }
        item {
            OutlinedTextField(
                query,
                { query = it },
                label = { Text("Qual música você quer cantar?") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                enabled = !searching
            )
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                items(listOf("karaoke", "instrumental", "playback", "com letra")) { suffix ->
                    val accent = when (suffix) {
                        "karaoke" -> Color(0xFF9C6BFF)
                        "instrumental" -> Color(0xFF39A9FF)
                        "playback" -> Color(0xFFFF8A4C)
                        else -> Color(0xFF47D7A5)
                    }
                    FilterChip(
                        selected = searchMode == suffix,
                        onClick = { searchMode = suffix },
                        label = { Text(suffix) },
                        enabled = !searching,
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = accent.copy(alpha = .30f), selectedLabelColor = Color.White),
                        border = FilterChipDefaults.filterChipBorder(enabled = !searching, selected = searchMode == suffix, borderColor = accent.copy(alpha=.55f), selectedBorderColor = accent)
                    )
                }
            }
        }
        item {
            Button(
                onClick = { searchInsideStreamPulse() },
                enabled = query.isNotBlank() && !searching,
                modifier = Modifier.fillMaxWidth().height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C4DFF), contentColor = Color.White)
            ) {
                if (searching) {
                    CircularProgressIndicator(modifier = Modifier.size(19.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                    Text("Pesquisando...")
                } else {
                    Icon(Icons.Default.Search, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Pesquisar no YouTube")
                }
            }
        }
        searchError?.let { errorText ->
            item {
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer,
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text(
                        errorText,
                        modifier = Modifier.padding(12.dp),
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        selectedVideo?.let { video ->
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF10152D).copy(alpha = .94f))) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        Text(video.title, fontWeight = FontWeight.ExtraBold, color = Color.White)
                        Text(
                            video.channelTitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = .62f)
                        )

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(if (configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) 320.dp else 220.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color.Black),
                            contentAlignment = Alignment.Center
                        ) {
                            YouTubeEmbedPlayer(
                                videoId = video.videoId,
                                controller = playerController,
                                modifier = Modifier.fillMaxSize()
                            )

                            if (!playerController.ready && playerController.errorMessage == null) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    CircularProgressIndicator(color = Color.White)
                                    Spacer(Modifier.height(8.dp))
                                    Text(
                                        playerController.stateLabel,
                                        color = Color.White.copy(alpha = .82f),
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            }

                            playerController.errorMessage?.let { problem ->
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(Color.Black.copy(alpha = .90f))
                                        .padding(18.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Icon(Icons.Default.ErrorOutline, null, tint = Color(0xFFFF7A7A))
                                    Spacer(Modifier.height(8.dp))
                                    Text(
                                        "Não foi possível reproduzir este vídeo",
                                        color = Color.White,
                                        fontWeight = FontWeight.ExtraBold,
                                        textAlign = TextAlign.Center
                                    )
                                    Spacer(Modifier.height(6.dp))
                                    Text(
                                        problem,
                                        color = Color.White.copy(alpha = .78f),
                                        style = MaterialTheme.typography.bodySmall,
                                        textAlign = TextAlign.Center
                                    )
                                    Spacer(Modifier.height(10.dp))
                                    OutlinedButton(onClick = { playerController.retry() }) {
                                        Icon(Icons.Default.Refresh, null)
                                        Spacer(Modifier.width(6.dp))
                                        Text("Tentar novamente")
                                    }
                                }
                            }
                        }

                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(7.dp)
                        ) {
                            FilledTonalButton(
                                onClick = {
                                    if (playerController.isPlaying) playerController.pause() else playerController.play()
                                },
                                enabled = playerController.ready && playerController.errorMessage == null,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    if (playerController.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    null
                                )
                                Spacer(Modifier.width(5.dp))
                                Text(if (playerController.isPlaying) "Pausar" else "Play")
                            }
                            OutlinedButton(
                                onClick = { showQualityInfo = true },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.HighQuality, null)
                                Spacer(Modifier.width(5.dp))
                                Text(playerController.qualityLabel, maxLines = 1)
                            }
                            OutlinedButton(
                                onClick = { karaokeFullscreen = true },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Fullscreen, null)
                                Spacer(Modifier.width(4.dp))
                                Text("Tela cheia")
                            }
                        }
                        Text(
                            "${playerController.stateLabel} • controles ficam fora do vídeo para manter o player limpo.",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = .58f)
                        )
                    }
                }
            }
        }

        if (results.isNotEmpty()) {
            item { Text("Resultados", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp) }
            items(results, key = { it.videoId }) { video ->
                Card(
                    modifier = Modifier.fillMaxWidth().clickable {
                        if (rec.recording) finishPerformance()
                        selectedVideo = video
                        // Um único player é reutilizado. A biblioteca interrompe o vídeo anterior
                        // quando loadVideo() recebe o novo videoId.
                        playerController.load(video.videoId, force = true)
                        onTrack("Karaokê: selecionar vídeo", true, null)
                    }
                ) {
                    Row(
                        Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(11.dp)
                    ) {
                        YouTubeThumbnail(
                            video.thumbnailUrl,
                            Modifier.width(124.dp).height(70.dp).clip(RoundedCornerShape(11.dp))
                        )
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(video.title, fontWeight = FontWeight.Bold, maxLines = 2, fontSize = 14.sp)
                            Text(
                                video.channelTitle,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = .60f),
                                maxLines = 1
                            )
                        }
                        Icon(Icons.Default.PlayCircle, contentDescription = "Reproduzir vídeo", tint = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }

        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF17152F).copy(alpha = .94f))) {
                Column(
                    Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("Desempenho vocal", fontWeight = FontWeight.ExtraBold, color = Color.White)

                    if (rec.recording) {
                        Surface(shape = RoundedCornerShape(50), color = Color(0xFFE53935).copy(alpha=.18f), border = BorderStroke(1.dp, Color(0xFFE53935))) {
                            Text("● GRAVANDO • Qualidade Alta automática", color = Color(0xFFFF7B7B), fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal=11.dp, vertical=6.dp), style=MaterialTheme.typography.labelMedium)
                        }
                        KaraokeScoreSpeedometer(score = liveScore, live = true)
                        Text("${formatDuration(rec.durationMs)} • voz detectada ${(rec.voicedRatio * 100).roundToInt()}%")
                        LinearProgressIndicator(
                            progress = { rec.amplitude.coerceIn(0f, 1f) },
                            modifier = Modifier.fillMaxWidth()
                        )
                        if (rec.pitchHz > 0f) {
                            Text(
                                "Pitch aproximado ${rec.pitchHz.roundToInt()} Hz • estabilidade ${(rec.pitchStability * 100).roundToInt()}%",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        Text(
                            "O marcador ao vivo mede atividade, estabilidade e energia da voz — não acerto de notas da música.",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = .58f),
                            textAlign = TextAlign.Center
                        )
                        Button(onClick = { finishPerformance() }, modifier = Modifier.fillMaxWidth()) {
                            Text("Finalizar apresentação")
                        }
                    } else {
                        score?.let { finalScore ->
                            Box(
                                modifier = Modifier.fillMaxWidth(),
                                contentAlignment = Alignment.Center
                            ) {
                                KaraokeScoreSpeedometer(score = finalScore, live = false)
                                if (finalScore <= 15) BombRain(Modifier.matchParentSize())
                            }
                            Text(
                                karaokeReaction(finalScore),
                                fontSize = if (finalScore >= 96) 30.sp else 34.sp,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                karaokeFeedback(finalScore),
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                            analysisQuality?.let {
                                Text(
                                    "Qualidade da análise: $it",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f)
                                )
                            }
                            components.forEach { (label, value) ->
                                Row(Modifier.fillMaxWidth()) {
                                    Text(label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha=.78f))
                                    Text("$value/100", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall, color = Color.White)
                                }
                            }
                        }
                        if (lastRecordingPath != null) {
                            Text("Sua apresentação", color=Color.White, fontWeight=FontWeight.ExtraBold)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                                OutlinedButton(
                                    onClick = {
                                        val path = lastRecordingPath ?: return@OutlinedButton
                                        if (recordingPlaying) { recordingPlayer?.pause(); recordingPlaying=false } else {
                                            runCatching { recordingPlayer?.release() }
                                            recordingPlayer = MediaPlayer().apply { setDataSource(path); prepare(); start(); setOnCompletionListener { recordingPlaying=false } }
                                            recordingPlaying=true
                                        }
                                    }, modifier=Modifier.weight(1f)
                                ) { Icon(if(recordingPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,null); Spacer(Modifier.width(4.dp)); Text(if(recordingPlaying) "Pausar" else "Ouvir") }
                                Button(
                                    onClick = {
                                        val clean = lastRecordingTitle.replace(Regex("[^\\p{L}\\p{N}._-]+"), "_").take(55)
                                        saveRecordingLauncher.launch("${clean}_${LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmm"))}.m4a")
                                    }, enabled=!saveBusy, modifier=Modifier.weight(1f)
                                ) { Icon(Icons.Default.Download,null); Spacer(Modifier.width(4.dp)); Text(if(saveBusy) "Salvando" else "Salvar") }
                                OutlinedButton(onClick={
                                    recordingPlayer?.release(); recordingPlayer=null; recordingPlaying=false
                                    lastRecordingPath?.let { runCatching { File(it).delete() } }
                                    lastRecordingPath=null; message="Gravação descartada."
                                },modifier=Modifier.weight(1f)){Icon(Icons.Default.DeleteOutline,null);Spacer(Modifier.width(4.dp));Text("Descartar")}
                            }
                        }
                        Button(
                            onClick = { permission.launch(Manifest.permission.RECORD_AUDIO) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Mic, null)
                            Spacer(Modifier.width(8.dp))
                            Text(if (score == null) "Iniciar apresentação" else "Nova apresentação")
                        }
                    }
                }
            }
        }

        message?.let {
            item {
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text(
                        it,
                        modifier = Modifier.padding(12.dp),
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                }
            }
        }
        }
    }
}

@Composable
private fun KaraokeStageBackground(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "karaoke-stage")
    val sway by transition.animateFloat(-.12f, .12f, infiniteRepeatable(tween(4200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "spotlight-sway")
    val glow by transition.animateFloat(.35f, .72f, infiniteRepeatable(tween(2600), RepeatMode.Reverse), label = "floor-glow")
    Canvas(modifier) {
        val top = Offset(size.width / 2f, 0f)
        fun beam(originX: Float, targetX: Float, color: Color) {
            val path = Path().apply {
                moveTo(originX - 18.dp.toPx(), 0f)
                lineTo(originX + 18.dp.toPx(), 0f)
                lineTo(targetX + size.width * .18f, size.height * .62f)
                lineTo(targetX - size.width * .18f, size.height * .62f)
                close()
            }
            drawPath(path, Brush.verticalGradient(listOf(color.copy(alpha=.24f), color.copy(alpha=.015f))))
        }
        beam(size.width*.24f, size.width*(.38f+sway), Color(0xFF7C4DFF))
        beam(size.width*.76f, size.width*(.62f-sway), Color(0xFF29B6F6))
        drawOval(Brush.radialGradient(listOf(Color(0xFF7C4DFF).copy(alpha=glow*.28f), Color.Transparent)), topLeft=Offset(size.width*.05f,size.height*.73f), size=Size(size.width*.9f,size.height*.20f))
    }
}

@Composable
private fun SessionDataUsageChip(preferences: UserPreferences) {
    val context = LocalContext.current
    val uid = android.os.Process.myUid()
    val startRx = remember { TrafficStats.getUidRxBytes(uid).coerceAtLeast(0L) }
    val startTx = remember { TrafficStats.getUidTxBytes(uid).coerceAtLeast(0L) }
    val startedAt = remember { System.currentTimeMillis() }
    var rx by remember { mutableLongStateOf(startRx) }
    var tx by remember { mutableLongStateOf(startTx) }
    var downBps by remember { mutableLongStateOf(0L) }
    var upBps by remember { mutableLongStateOf(0L) }
    var peakBps by remember { mutableLongStateOf(0L) }
    var mobile by remember { mutableStateOf(false) }
    var online by remember { mutableStateOf(true) }
    var details by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        var lastRx=startRx; var lastTx=startTx
        while (true) {
            val nr=TrafficStats.getUidRxBytes(uid).coerceAtLeast(startRx); val nt=TrafficStats.getUidTxBytes(uid).coerceAtLeast(startTx)
            downBps=(nr-lastRx).coerceAtLeast(0L); upBps=(nt-lastTx).coerceAtLeast(0L); peakBps=maxOf(peakBps,downBps+upBps)
            rx=nr;tx=nt;lastRx=nr;lastTx=nt
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            val caps = cm?.activeNetwork?.let(cm::getNetworkCapabilities)
            online = caps != null
            mobile = caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true
            delay(1500)
        }
    }
    val down = (rx-startRx).coerceAtLeast(0L)
    val up = (tx-startTx).coerceAtLeast(0L)
    val used = down + up
    val warning = preferences.warnOnMobileData && mobile && used >= preferences.mobileDataWarningMb.toLong()*1024L*1024L
    val accent = when { !online -> Color(0xFFE53935); warning -> Color(0xFFFF9800); else -> Color(0xFF29B6F6) }
    Surface(
        modifier = Modifier.clickable { details = true },
        shape=RoundedCornerShape(50), color=accent.copy(alpha=.18f), border=BorderStroke(1.dp,accent.copy(alpha=.65f))
    ) {
        Row(Modifier.padding(horizontal=8.dp,vertical=5.dp),verticalAlignment=Alignment.CenterVertically) {
            Text(if(!online) "●" else if(warning) "⚠" else "📶",fontSize=12.sp,color=accent)
            Spacer(Modifier.width(4.dp))
            Text(if(!online) "Offline" else "≈${formatBytes(used)}",color=Color.White,fontWeight=FontWeight.Bold,style=MaterialTheme.typography.labelSmall)
        }
    }
    if (details) {
        val duration = System.currentTimeMillis() - startedAt
        AlertDialog(
            onDismissRequest = { details = false },
            title = { Text("Uso de dados • Karaokê") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Download: ≈${formatBytes(down)}")
                    Text("Upload: ≈${formatBytes(up)}")
                    Text("Sessão: ${formatDuration(duration)}")
                    Text("Velocidade: ↓ ${formatBytes(downBps)}/s • ↑ ${formatBytes(upBps)}/s")
                    Text("Pico: ${formatBytes(peakBps)}/s")
                    Text("Rede: ${if(!online) "Offline" else if(mobile) "Dados móveis" else "Wi‑Fi / rede local"}")
                    Text("O valor é aproximado e mede o tráfego do processo SONUS durante esta sessão.", style=MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = { TextButton(onClick={details=false}) { Text("Fechar") } }
        )
    }
}

@Composable
private fun KaraokeScoreSpeedometer(score: Int, live: Boolean) {
    val safe = score.coerceIn(0, 100)
    val animated by animateFloatAsState(
        targetValue = safe.toFloat(),
        animationSpec = tween(if (live) 260 else 900, easing = FastOutSlowInEasing),
        label = "karaoke-score"
    )
    val colors = listOf(
        Color(0xFF181818), Color(0xFFE53935), Color(0xFF8E44AD),
        Color(0xFFFF7A21), Color(0xFFFFC928), Color(0xFF26A65B), Color(0xFF3185FC)
    )
    Box(
        modifier = Modifier.fillMaxWidth().height(180.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 10.dp)) {
            val stroke = 14.dp.toPx()
            val arcSize = minOf(size.width, size.height * 1.8f)
            val left = (size.width - arcSize) / 2f
            val top = size.height * .10f
            val sweep = 180f / colors.size
            colors.forEachIndexed { index, color ->
                drawArc(
                    color = color,
                    startAngle = 180f + index * sweep,
                    sweepAngle = sweep - 1.2f,
                    useCenter = false,
                    topLeft = Offset(left, top),
                    size = Size(arcSize, arcSize),
                    style = Stroke(width = stroke, cap = StrokeCap.Round)
                )
            }
            val center = Offset(size.width / 2f, top + arcSize / 2f)
            val angle = Math.toRadians((180f + animated * 1.8f).toDouble())
            val radius = arcSize * .36f
            val tip = Offset(
                center.x + (cos(angle) * radius).toFloat(),
                center.y + (sin(angle) * radius).toFloat()
            )
            drawLine(
                color = Color.White,
                start = center,
                end = tip,
                strokeWidth = 4.dp.toPx(),
                cap = StrokeCap.Round
            )
            drawCircle(Color.White, radius = 7.dp.toPx(), center = center)
        }
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(top = 74.dp)
        ) {
            Text(animated.roundToInt().toString(), fontSize = 37.sp, fontWeight = FontWeight.ExtraBold)
            Text(if (live) "AO VIVO" else "/ 100", style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun BombRain(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "bomb-rain")
    val fall by transition.animateFloat(
        initialValue = -20f,
        targetValue = 180f,
        animationSpec = infiniteRepeatable(tween(1700, easing = LinearEasing)),
        label = "bomb-y"
    )
    BoxWithConstraints(modifier = modifier.clip(RoundedCornerShape(18.dp))) {
        listOf(0.06f, 0.22f, 0.39f, 0.57f, 0.74f, 0.90f).forEachIndexed { index, fraction ->
            Text(
                "💣",
                fontSize = 22.sp,
                modifier = Modifier.offset(
                    x = maxWidth * fraction,
                    y = (fall + index * 24f - 110f).dp
                )
            )
        }
    }
}

private fun karaokeReaction(score: Int): String = when (score.coerceIn(0, 100)) {
    in 0..15 -> "💣"
    in 16..40 -> "👎"
    in 41..60 -> "👏"
    in 61..75 -> "🥰"
    in 76..95 -> "😍"
    else -> "🎉 🎈 🥳"
}

private fun karaokeFeedback(score: Int): String = when (score.coerceIn(0, 100)) {
    in 0..15 -> "Quase não conseguimos avaliar uma apresentação consistente."
    in 16..40 -> "Tem espaço para soltar mais a voz e manter constância."
    in 41..60 -> "Boa base. Continue e tente manter mais estabilidade."
    in 61..75 -> "Mandou bem! Sua apresentação ficou consistente."
    in 76..95 -> "Excelente apresentação! 🔥"
    else -> "Apresentação incrível! Você dominou o palco. 🎉"
}

private tailrec fun Context.findActivityForTools(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivityForTools()
    else -> null
}

private fun loadPreviewBitmap(context: Context, uri: Uri): Bitmap? {
    val resolver = context.contentResolver
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    var sample = 1
    while (bounds.outWidth / sample > 1200 || bounds.outHeight / sample > 1200) sample *= 2
    val options = BitmapFactory.Options().apply { inSampleSize = sample.coerceAtLeast(1) }
    return resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
}

private fun channelLabelUi(count:Int):String=when(count){1->"Mono";2->"Estéreo";6->"5.1";8->"7.1";else->"$count canais"}
private fun deviceType(d:AudioDeviceInfo):String=when(d.type){AudioDeviceInfo.TYPE_USB_DEVICE,AudioDeviceInfo.TYPE_USB_HEADSET->"USB";AudioDeviceInfo.TYPE_BLUETOOTH_SCO->"Bluetooth";AudioDeviceInfo.TYPE_WIRED_HEADSET->"Fone com microfone";AudioDeviceInfo.TYPE_BUILTIN_MIC->"Microfone interno";else->"Entrada de áudio"}
private fun recordExt(format:String)=when(format){"M4A/AAC"->"m4a";"WEBM/OPUS"->"webm";else->format.lowercase()}
private fun formatDuration(ms:Long):String{val s=(ms/1000).coerceAtLeast(0);return "%02d:%02d".format(s/60,s%60)}
private fun formatLongDuration(ms:Long):String {
    val totalMin=(ms/60_000L).coerceAtLeast(0L)
    val h=totalMin/60
    val m=totalMin%60
    return if(h>0) "${h}h ${m}min" else "${m}min"
}
private fun formatSec(seconds:Double):String{val s=seconds.toInt().coerceAtLeast(0);return "%02d:%02d".format(s/60,s%60)}
private fun zoomWaveform(values:List<Float>,zoom:Float,centerFraction:Float):List<Float>{
    if(values.isEmpty()||zoom<=1.01f)return values
    val count=(values.size/zoom.coerceIn(1f,8f)).roundToInt().coerceIn(8,values.size)
    val center=(centerFraction.coerceIn(0f,1f)*(values.lastIndex)).roundToInt()
    val start=(center-count/2).coerceIn(0,(values.size-count).coerceAtLeast(0))
    return values.subList(start,(start+count).coerceAtMost(values.size))
}

private fun parseTimeInput(text:String):Double?{val t=text.trim();if(t.isBlank())return null;return if(':' in t){val p=t.split(':');if(p.size!=2)null else (p[0].toDoubleOrNull()?.times(60))?.plus(p[1].toDoubleOrNull()?:return null)}else t.toDoubleOrNull()}
private fun formatBytes(bytes:Long):String=when{bytes>=1024L*1024*1024->String.format(Locale.US,"%.2f GB",bytes/(1024.0*1024*1024));bytes>=1024L*1024->String.format(Locale.US,"%.1f MB",bytes/(1024.0*1024));bytes>=1024->String.format(Locale.US,"%.0f KB",bytes/1024.0);else->"$bytes B"}
