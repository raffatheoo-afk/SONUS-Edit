package com.sonusstudios.streampulse.video

import android.content.Context
import android.opengl.GLES20
import androidx.media3.common.Effect
import androidx.media3.common.util.Size
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BaseGlShaderProgram
import androidx.media3.effect.GlEffect
import androidx.media3.effect.GlShaderProgram
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.RgbAdjustment
import androidx.media3.effect.RgbFilter
import androidx.media3.effect.AlphaScale

/**
 * GPU effects shared by SONUS video composition/export.
 *
 * The architecture is intentionally small: one shader program with bounded parameters and
 * deterministic fallback. The effect vocabulary is inspired by the MIT-licensed ClearCut
 * project, but this implementation is SONUS-specific and keeps the current Media3 pipeline.
 */
@UnstableApi
internal class SonusShaderEffect(
    private val mode: Int,
    private val p1: Float = 1f,
    private val p2: Float = 0f,
    private val p3: Float = 0f,
    private val p4: Float = 0f,
) : GlEffect {
    override fun toGlShaderProgram(context: Context, useHdr: Boolean): GlShaderProgram =
        Program(mode, p1, p2, p3, p4)

    private class Program(
        private val mode: Int,
        private val p1: Float,
        private val p2: Float,
        private val p3: Float,
        private val p4: Float,
    ) : BaseGlShaderProgram(false, 1) {
        private var programId = 0
        private var aPosition = -1
        private var aTexCoord = -1
        private var uTexture = -1
        private var uMode = -1
        private var uP1 = -1
        private var uP2 = -1
        private var uP3 = -1
        private var uP4 = -1
        private var uTime = -1
        private var uTexel = -1
        private var width = 1
        private var height = 1
        private lateinit var buffer: java.nio.FloatBuffer

        override fun configure(inputWidth: Int, inputHeight: Int): Size {
            width = inputWidth.coerceAtLeast(1)
            height = inputHeight.coerceAtLeast(1)
            if (programId == 0) setupProgram()
            return Size(inputWidth, inputHeight)
        }

        override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
            GLES20.glUseProgram(programId)
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, inputTexId)
            if (uTexture >= 0) GLES20.glUniform1i(uTexture, 0)
            if (uMode >= 0) GLES20.glUniform1i(uMode, mode)
            if (uP1 >= 0) GLES20.glUniform1f(uP1, finite(p1, 1f))
            if (uP2 >= 0) GLES20.glUniform1f(uP2, finite(p2, 0f))
            if (uP3 >= 0) GLES20.glUniform1f(uP3, finite(p3, 0f))
            if (uP4 >= 0) GLES20.glUniform1f(uP4, finite(p4, 0f))
            if (uTime >= 0) GLES20.glUniform1f(uTime, presentationTimeUs / 1_000_000f)
            if (uTexel >= 0) GLES20.glUniform2f(uTexel, 1f / width, 1f / height)

            buffer.position(0)
            if (aPosition >= 0) {
                GLES20.glEnableVertexAttribArray(aPosition)
                GLES20.glVertexAttribPointer(aPosition, 2, GLES20.GL_FLOAT, false, 16, buffer)
            }
            buffer.position(2)
            if (aTexCoord >= 0) {
                GLES20.glEnableVertexAttribArray(aTexCoord)
                GLES20.glVertexAttribPointer(aTexCoord, 2, GLES20.GL_FLOAT, false, 16, buffer)
            }
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
            if (aPosition >= 0) GLES20.glDisableVertexAttribArray(aPosition)
            if (aTexCoord >= 0) GLES20.glDisableVertexAttribArray(aTexCoord)
        }

        override fun release() {
            super.release()
            if (programId != 0) {
                GLES20.glDeleteProgram(programId)
                programId = 0
            }
        }

        private fun setupProgram() {
            val vs = compile(GLES20.GL_VERTEX_SHADER, VERT)
            val fs = compile(GLES20.GL_FRAGMENT_SHADER, FRAG)
            programId = GLES20.glCreateProgram()
            GLES20.glAttachShader(programId, vs)
            GLES20.glAttachShader(programId, fs)
            GLES20.glLinkProgram(programId)
            GLES20.glDeleteShader(vs)
            GLES20.glDeleteShader(fs)
            val linked = IntArray(1)
            GLES20.glGetProgramiv(programId, GLES20.GL_LINK_STATUS, linked, 0)
            if (linked[0] == 0) {
                val log = GLES20.glGetProgramInfoLog(programId)
                GLES20.glDeleteProgram(programId)
                programId = 0
                throw IllegalStateException("SONUS shader link failed: $log")
            }
            aPosition = GLES20.glGetAttribLocation(programId, "aPosition")
            aTexCoord = GLES20.glGetAttribLocation(programId, "aTexCoord")
            uTexture = GLES20.glGetUniformLocation(programId, "uTexture")
            uMode = GLES20.glGetUniformLocation(programId, "uMode")
            uP1 = GLES20.glGetUniformLocation(programId, "uP1")
            uP2 = GLES20.glGetUniformLocation(programId, "uP2")
            uP3 = GLES20.glGetUniformLocation(programId, "uP3")
            uP4 = GLES20.glGetUniformLocation(programId, "uP4")
            uTime = GLES20.glGetUniformLocation(programId, "uTime")
            uTexel = GLES20.glGetUniformLocation(programId, "uTexel")
            val vertices = floatArrayOf(
                -1f, -1f, 0f, 0f,
                 1f, -1f, 1f, 0f,
                -1f,  1f, 0f, 1f,
                 1f,  1f, 1f, 1f,
            )
            buffer = java.nio.ByteBuffer.allocateDirect(vertices.size * 4)
                .order(java.nio.ByteOrder.nativeOrder())
                .asFloatBuffer()
                .put(vertices)
            buffer.position(0)
        }

        private fun compile(type: Int, source: String): Int {
            val shader = GLES20.glCreateShader(type)
            GLES20.glShaderSource(shader, source)
            GLES20.glCompileShader(shader)
            val compiled = IntArray(1)
            GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, compiled, 0)
            if (compiled[0] == 0) {
                val log = GLES20.glGetShaderInfoLog(shader)
                GLES20.glDeleteShader(shader)
                throw IllegalStateException("SONUS shader compile failed: $log")
            }
            return shader
        }

        private fun finite(value: Float, fallback: Float) = if (value.isFinite()) value else fallback

        companion object {
            private const val VERT = """
                attribute vec4 aPosition;
                attribute vec2 aTexCoord;
                varying vec2 vTexCoord;
                void main() {
                    gl_Position = aPosition;
                    vTexCoord = aTexCoord;
                }
            """

            private const val FRAG = """
                precision mediump float;
                varying vec2 vTexCoord;
                uniform sampler2D uTexture;
                uniform int uMode;
                uniform float uP1;
                uniform float uP2;
                uniform float uP3;
                uniform float uP4;
                uniform float uTime;
                uniform vec2 uTexel;

                float hash(vec2 p) {
                    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
                }

                vec4 sampleBlur(vec2 uv, float radius) {
                    // Stable normalized Gaussian-like kernel. The previous wide 3x3 sampling
                    // produced an overly destructive result at Full HD. This keeps energy at 1.0
                    // and uses smaller symmetric taps, matching preview/export more closely.
                    vec2 t = uTexel * max(0.75, radius);
                    vec4 c = texture2D(uTexture, uv) * 0.28;
                    c += texture2D(uTexture, clamp(uv + vec2(t.x, 0.0), 0.0, 1.0)) * 0.12;
                    c += texture2D(uTexture, clamp(uv - vec2(t.x, 0.0), 0.0, 1.0)) * 0.12;
                    c += texture2D(uTexture, clamp(uv + vec2(0.0, t.y), 0.0, 1.0)) * 0.12;
                    c += texture2D(uTexture, clamp(uv - vec2(0.0, t.y), 0.0, 1.0)) * 0.12;
                    c += texture2D(uTexture, clamp(uv + vec2(t.x, t.y), 0.0, 1.0)) * 0.06;
                    c += texture2D(uTexture, clamp(uv + vec2(-t.x, t.y), 0.0, 1.0)) * 0.06;
                    c += texture2D(uTexture, clamp(uv + vec2(t.x, -t.y), 0.0, 1.0)) * 0.06;
                    c += texture2D(uTexture, clamp(uv - vec2(t.x, t.y), 0.0, 1.0)) * 0.06;
                    return c;
                }

                // Optimized separable Gaussian pass (equivalent to a 9-tap kernel with
                // bilinear sampling). Two SonusShaderEffect(mode=1) passes -- horizontal
                // then vertical -- form the final Gaussian Blur, mirroring the safer
                // ClearCut strategy instead of blurring the whole frame in one destructive pass.
                vec4 sampleGaussianAxis(vec2 uv, float radius, float vertical) {
                    vec2 axis = vertical > 0.5 ? vec2(0.0, uTexel.y) : vec2(uTexel.x, 0.0);
                    axis *= max(0.55, radius);
                    vec4 sum = texture2D(uTexture, uv) * 0.2270270270;
                    vec2 o1 = axis * 1.3846153846;
                    vec2 o2 = axis * 3.2307692308;
                    sum += texture2D(uTexture, clamp(uv + o1, 0.0, 1.0)) * 0.3162162162;
                    sum += texture2D(uTexture, clamp(uv - o1, 0.0, 1.0)) * 0.3162162162;
                    sum += texture2D(uTexture, clamp(uv + o2, 0.0, 1.0)) * 0.0702702703;
                    sum += texture2D(uTexture, clamp(uv - o2, 0.0, 1.0)) * 0.0702702703;
                    return sum;
                }

                void main() {
                    vec2 uv = vTexCoord;
                    vec4 c = texture2D(uTexture, uv);
                    if (uMode == 1) {
                        c = sampleGaussianAxis(uv, clamp(uP1, 0.55, 7.0), uP2);
                    } else if (uMode == 2) {
                        float px = max(2.0, uP1);
                        vec2 grid = vec2(px) * uTexel;
                        vec2 q = floor(uv / grid) * grid + grid * 0.5;
                        c = texture2D(uTexture, q);
                    } else if (uMode == 3) {
                        vec2 p = uv * 2.0 - 1.0;
                        float r2 = dot(p, p);
                        float k = clamp(uP1, -0.8, 1.2) * 0.35;
                        vec2 q = p * (1.0 + k * r2);
                        q = q * 0.5 + 0.5;
                        if (q.x < 0.0 || q.x > 1.0 || q.y < 0.0 || q.y > 1.0) c = vec4(0.0,0.0,0.0,1.0);
                        else c = texture2D(uTexture, q);
                    } else if (uMode == 4) {
                        float amp = clamp(uP1, 0.0, 1.0) * 0.035;
                        uv.x += sin(uv.y * 30.0 + uTime * 3.0) * amp;
                        c = texture2D(uTexture, uv);
                    } else if (uMode == 5) {
                        float a = clamp(uP1, 0.0, 2.0) * 0.006;
                        float r = texture2D(uTexture, uv + vec2(a,0.0)).r;
                        float g = texture2D(uTexture, uv).g;
                        float b = texture2D(uTexture, uv - vec2(a,0.0)).b;
                        c = vec4(r,g,b,c.a);
                    } else if (uMode == 6) {
                        float gate = step(0.78, hash(vec2(floor(uTime * 8.0), floor(uv.y * 24.0))));
                        float shift = gate * (hash(vec2(floor(uv.y*35.0), floor(uTime*12.0))) - 0.5) * 0.06 * clamp(uP1,0.0,1.0);
                        vec2 q = vec2(fract(uv.x + shift), uv.y);
                        float r = texture2D(uTexture, q + vec2(0.005*uP1,0.0)).r;
                        float g = texture2D(uTexture, q).g;
                        float b = texture2D(uTexture, q - vec2(0.005*uP1,0.0)).b;
                        c = vec4(r,g,b,c.a);
                    } else if (uMode == 7) {
                        vec2 p = uv - vec2(0.5);
                        float d = length(p) / 0.7071;
                        float v = smoothstep(clamp(uP2,0.15,0.95), 1.0, d) * clamp(uP1,0.0,1.0);
                        c.rgb *= 1.0 - v * 0.85;
                    } else if (uMode == 8) {
                        float n = hash(uv * vec2(1531.0, 997.0) + uTime * 13.0) - 0.5;
                        c.rgb = clamp(c.rgb + n * clamp(uP1,0.0,1.0) * 0.22, 0.0, 1.0);
                    } else if (uMode == 9) {
                        float a = clamp(uP1,0.0,2.5);
                        vec4 blur = sampleBlur(uv, 1.0);
                        c.rgb = clamp(c.rgb + (c.rgb - blur.rgb) * a, 0.0, 1.0);
                    } else if (uMode == 10) {
                        float levels = clamp(uP1,2.0,16.0);
                        c.rgb = floor(c.rgb * levels) / max(1.0, levels - 1.0);
                    } else if (uMode == 11) {
                        vec3 x = c.rgb;
                        c.rgb = clamp(vec3(
                            dot(x, vec3(0.393,0.769,0.189)),
                            dot(x, vec3(0.349,0.686,0.168)),
                            dot(x, vec3(0.272,0.534,0.131))
                        ),0.0,1.0);
                    } else if (uMode == 12) {
                        c.rgb = vec3(1.0) - c.rgb;
                    } else if (uMode == 13) {
                        float line = 0.96 + 0.04 * sin(uv.y * 900.0);
                        float noise = (hash(uv * 800.0 + uTime) - 0.5) * 0.08 * uP1;
                        c.rgb = clamp(c.rgb * line + noise,0.0,1.0);
                    } else if (uMode == 14) {
                        vec2 p = uv - vec2(0.5);
                        float flare = max(0.0, 1.0 - length(p - vec2(0.30*sin(uTime*0.35), -0.18)) * 2.3);
                        c.rgb += vec3(1.0,0.42,0.10) * flare * clamp(uP1,0.0,1.0) * 0.38;
                        c.rgb = clamp(c.rgb,0.0,1.0);
                    } else if (uMode == 15) {
                        vec2 center = vec2(0.5);
                        vec2 dir = center - uv;
                        float strength = clamp(uP1, 0.0, 1.0) * 0.18;
                        vec4 sum = vec4(0.0);
                        sum += texture2D(uTexture, uv) * 0.22;
                        sum += texture2D(uTexture, clamp(uv + dir*strength*0.20,0.0,1.0)) * 0.16;
                        sum += texture2D(uTexture, clamp(uv + dir*strength*0.40,0.0,1.0)) * 0.15;
                        sum += texture2D(uTexture, clamp(uv + dir*strength*0.60,0.0,1.0)) * 0.14;
                        sum += texture2D(uTexture, clamp(uv + dir*strength*0.80,0.0,1.0)) * 0.13;
                        sum += texture2D(uTexture, clamp(uv - dir*strength*0.25,0.0,1.0)) * 0.10;
                        sum += texture2D(uTexture, clamp(uv - dir*strength*0.50,0.0,1.0)) * 0.10;
                        c = sum;
                    } else if (uMode == 16) {
                        float strength = clamp(uP1, 0.0, 1.0) * 18.0;
                        float angle = uP2;
                        vec2 dir = vec2(cos(angle), sin(angle)) * uTexel * strength;
                        vec4 sum = vec4(0.0);
                        sum += texture2D(uTexture, clamp(uv-dir*0.75,0.0,1.0))*0.12;
                        sum += texture2D(uTexture, clamp(uv-dir*0.50,0.0,1.0))*0.15;
                        sum += texture2D(uTexture, clamp(uv-dir*0.25,0.0,1.0))*0.18;
                        sum += texture2D(uTexture, uv)*0.20;
                        sum += texture2D(uTexture, clamp(uv+dir*0.25,0.0,1.0))*0.18;
                        sum += texture2D(uTexture, clamp(uv+dir*0.50,0.0,1.0))*0.10;
                        sum += texture2D(uTexture, clamp(uv+dir*0.75,0.0,1.0))*0.07;
                        c = sum;
                    } else if (uMode == 17) {
                        float focus = clamp(uP2, 0.05, 0.95);
                        float widthBand = clamp(uP3, 0.05, 0.70);
                        float d = abs(uv.y - focus);
                        float blurMix = smoothstep(widthBand*0.45, widthBand, d);
                        vec4 blurred = sampleBlur(uv, 2.0 + clamp(uP1,0.0,1.0)*9.0);
                        c = mix(c, blurred, blurMix);
                    } else if (uMode == 18) {
                        vec2 q = uv;
                        q.x = 1.0 - q.x;
                        c = texture2D(uTexture, q);
                    } else if (uMode == 19) {
                        // Default green-screen key. Parameters mirror the ClearCut threshold/smoothing/spill model.
                        vec3 key = vec3(0.0, 1.0, 0.0);
                        float distanceToKey = distance(c.rgb, key);
                        float threshold = clamp(uP1, 0.02, 0.95);
                        float smoothing = max(0.001, clamp(uP2, 0.001, 0.5));
                        float alpha = smoothstep(threshold, threshold + smoothing, distanceToKey);
                        float greenDominance = max(0.0, c.g - max(c.r, c.b));
                        vec3 despilled = c.rgb;
                        despilled.g = max(max(c.r, c.b), c.g - greenDominance * clamp(uP3, 0.0, 1.0));
                        c = vec4(despilled, c.a * alpha);
                    } else if (uMode == 20) {
                        float lum = dot(c.rgb, vec3(0.2126,0.7152,0.0722));
                        float shadowMask = 1.0 - smoothstep(0.15,0.62,lum);
                        float highMask = smoothstep(0.42,0.92,lum);
                        c.rgb += shadowMask * uP1 * 0.24;
                        c.rgb += highMask * uP2 * 0.20;
                        c.rgb = (c.rgb - vec3(0.5)) * (1.0 + uP3 * 0.35) + vec3(0.5);
                        c.rgb = mix(c.rgb, vec3(dot(c.rgb,vec3(0.333))), clamp(uP4,0.0,1.0)*0.28);
                        c.rgb = clamp(c.rgb,0.0,1.0);
                    } else if (uMode >= 21 && uMode <= 38) {
                        float animDur = max(0.08, uP1);
                        float clipDur = max(animDur, uP2);
                        // Media3 entrega presentationTime global na sequência. Para efeitos por
                        // clipe, convertemos explicitamente para o relógio local da imagem.
                        float localTime = max(0.0, uTime - max(0.0, uP3));
                        float inP = smoothstep(0.0, 1.0, clamp(localTime / animDur, 0.0, 1.0));
                        float outP = smoothstep(0.0, 1.0, clamp((localTime - (clipDur - animDur)) / animDur, 0.0, 1.0));
                        vec2 q = uv;
                        float alphaMul = 1.0;
                        if (uMode == 21) {
                            alphaMul = inP;
                        } else if (uMode == 22) {
                            alphaMul = 1.0 - outP;
                        } else if (uMode == 23) {
                            float sc = mix(1.16, 1.0, inP);
                            q = (uv - vec2(0.5)) / sc + vec2(0.5);
                        } else if (uMode == 24) {
                            float sc = mix(1.0, 1.16, outP);
                            q = (uv - vec2(0.5)) / sc + vec2(0.5);
                        } else if (uMode == 25) q.x += (1.0 - inP);
                        else if (uMode == 26) q.x -= (1.0 - inP);
                        else if (uMode == 27) q.y += (1.0 - inP);
                        else if (uMode == 28) q.y -= (1.0 - inP);
                        else if (uMode == 29) {
                            float a = (1.0-inP) * 0.42;
                            float cs=cos(a), sn=sin(a);
                            vec2 p=uv-vec2(0.5);
                            q=vec2(cs*p.x-sn*p.y,sn*p.x+cs*p.y)+vec2(0.5);
                        } else if (uMode == 30) {
                            float sc = 0.82 + 0.18 * inP;
                            q = (uv - vec2(0.5)) / sc + vec2(0.5);
                            alphaMul = inP;
                        } else if (uMode == 31) q.x -= outP;
                        else if (uMode == 32) q.x += outP;
                        else if (uMode == 33) q.y -= outP;
                        else if (uMode == 34) q.y += outP;
                        else if (uMode == 35) {
                            float a = outP * 0.42;
                            float cs=cos(a), sn=sin(a);
                            vec2 p=uv-vec2(0.5);
                            q=vec2(cs*p.x-sn*p.y,sn*p.x+cs*p.y)+vec2(0.5);
                            alphaMul = 1.0-outP;
                        } else if (uMode == 36) {
                            float sc = 1.0 - 0.18 * outP;
                            q = (uv - vec2(0.5)) / sc + vec2(0.5);
                            alphaMul = 1.0-outP;
                        } else if (uMode == 37 || uMode == 38) {
                            float p = uMode == 37 ? inP : (1.0-outP);
                            float n = hash(floor(uv * 120.0));
                            alphaMul = smoothstep(n - 0.12, n + 0.12, p);
                        }
                        if (q.x < 0.0 || q.x > 1.0 || q.y < 0.0 || q.y > 1.0) {
                            c = vec4(0.0,0.0,0.0,1.0);
                        } else {
                            c = texture2D(uTexture, q);
                            c.rgb *= alphaMul;
                        }
                    }
                    gl_FragColor = c;
                }
            """
        }
    }
}

@UnstableApi
internal object SonusVideoFxFactory {
    fun effectFor(name: String, amount: Float = 1f): Effect? {
        val n = name.lowercase()
        val a = amount.coerceIn(0f, 2f)
        return when {
            n == "nenhum" || n == "original" -> null
            n.contains("gaussian blur") || n == "blur" -> SonusShaderEffect(1, 1.15f + a * 2.15f)
            n.contains("zoom blur") -> SonusShaderEffect(15, .45f * a)
            n.contains("directional blur") -> SonusShaderEffect(16, .42f * a, .35f)
            n.contains("mosaic") -> SonusShaderEffect(2, 18f + a * 16f)
            n.contains("pixel") -> SonusShaderEffect(2, 5f + a * 7f)
            n.contains("fisheye") -> SonusShaderEffect(3, .65f * a)
            n.contains("wave") -> SonusShaderEffect(4, .7f * a)
            n.contains("chromatic") || n.contains("rgb split") -> SonusShaderEffect(5, .9f * a)
            n.contains("glitch") -> SonusShaderEffect(6, .75f * a)
            n.contains("vignette") -> SonusShaderEffect(7, .65f * a, .62f)
            n.contains("grain") || n == "noise" -> SonusShaderEffect(8, .5f * a)
            n.contains("sharpen") || n == "edge" -> SonusShaderEffect(9, .55f * a)
            n.contains("posterize") -> SonusShaderEffect(10, 6f)
            n.contains("sepia") -> SonusShaderEffect(11)
            n.contains("invert") -> SonusShaderEffect(12)
            n.contains("vhs") || n.contains("scanline") -> SonusShaderEffect(13, .8f * a)
            n.contains("light leak") || n.contains("film burn") -> SonusShaderEffect(14, .85f * a)
            n.contains("radial blur") -> SonusShaderEffect(15, .72f * a)
            n.contains("motion blur") -> SonusShaderEffect(16, .68f * a, .35f)
            n.contains("tilt shift") -> SonusShaderEffect(17, .70f * a, .50f, .26f)
            n.contains("mirror") || n.contains("espelho") -> SonusShaderEffect(18)
            n.contains("chroma key") || n.contains("green screen") -> SonusShaderEffect(19, .28f, .10f, .72f)
            else -> null
        }
    }

    /** Returns the complete stack for a named effect. Gaussian blur deliberately uses
     * two separable passes; every other effect stays single-pass. */
    fun effectStackFor(name: String, amount: Float = 1f): List<Effect> {
        val n = name.lowercase()
        if (n.contains("gaussian blur") || n == "blur") {
            val radius = 1.0f + amount.coerceIn(0f, 2f) * 1.35f
            return listOf(
                SonusShaderEffect(1, radius, 0f),
                SonusShaderEffect(1, radius, 1f)
            )
        }
        return listOfNotNull(effectFor(name, amount))
    }

    fun clipAnimationEffects(entry: String, exit: String, clipDurationMs: Long, clipStartMs: Long = 0L): List<Effect> {
        val clipSec = (clipDurationMs.coerceAtLeast(1L) / 1000f).coerceAtLeast(.1f)
        val clipStartSec = clipStartMs.coerceAtLeast(0L) / 1000f
        val wantsOnePointFiveFade = entry.equals("Fade In 1.5s", true) || exit.equals("Fade Out 1.5s", true)
        val wantsTwoSecondFade = entry.equals("Fade In 2s", true) || exit.equals("Fade Out 2s", true)
        val animSec = when {
            wantsOnePointFiveFade -> minOf(1.5f, clipSec / 2f)
            wantsTwoSecondFade -> minOf(2.0f, clipSec / 2f)
            else -> minOf(.70f, (clipSec * .28f).coerceAtLeast(.18f))
        }
        fun entryEffect(name: String): Effect? = when (name.lowercase()) {
            "fade in", "fade in 1.5s", "fade in 2s" -> SonusShaderEffect(21, animSec, clipSec, clipStartSec)
            "zoom in" -> SonusShaderEffect(23, animSec, clipSec, clipStartSec)
            "slide esquerda" -> SonusShaderEffect(25, animSec, clipSec, clipStartSec)
            "slide direita" -> SonusShaderEffect(26, animSec, clipSec, clipStartSec)
            "slide cima" -> SonusShaderEffect(27, animSec, clipSec, clipStartSec)
            "slide baixo" -> SonusShaderEffect(28, animSec, clipSec, clipStartSec)
            "spin in" -> SonusShaderEffect(29, animSec, clipSec, clipStartSec)
            "pop in" -> SonusShaderEffect(30, animSec, clipSec, clipStartSec)
            "dissolve" -> SonusShaderEffect(37, animSec, clipSec, clipStartSec)
            else -> null
        }
        fun exitEffect(name: String): Effect? = when (name.lowercase()) {
            "fade out", "fade out 1.5s", "fade out 2s" -> SonusShaderEffect(22, animSec, clipSec, clipStartSec)
            "zoom out" -> SonusShaderEffect(24, animSec, clipSec, clipStartSec)
            "slide esquerda" -> SonusShaderEffect(31, animSec, clipSec, clipStartSec)
            "slide direita" -> SonusShaderEffect(32, animSec, clipSec, clipStartSec)
            "slide cima" -> SonusShaderEffect(33, animSec, clipSec, clipStartSec)
            "slide baixo" -> SonusShaderEffect(34, animSec, clipSec, clipStartSec)
            "spin out" -> SonusShaderEffect(35, animSec, clipSec, clipStartSec)
            "pop out" -> SonusShaderEffect(36, animSec, clipSec, clipStartSec)
            "dissolve" -> SonusShaderEffect(38, animSec, clipSec, clipStartSec)
            else -> null
        }
        return buildList {
            entryEffect(entry)?.let(::add)
            exitEffect(exit)?.let(::add)
        }
    }

    fun gradeEffect(shadows: Float, highlights: Float, contrastShape: Float, fade: Float): Effect? {
        val s = shadows.coerceIn(-1f,1f)
        val h = highlights.coerceIn(-1f,1f)
        val c = contrastShape.coerceIn(-1f,1f)
        val f = fade.coerceIn(0f,1f)
        if (kotlin.math.abs(s) < .001f && kotlin.math.abs(h) < .001f && kotlin.math.abs(c) < .001f && f < .001f) return null
        return SonusShaderEffect(20, s, h, c, f)
    }
}

/** Single source of truth for SONUS color grading and filter stacks.
 * Preview and export both call this builder so the order and math stay equivalent.
 */
@UnstableApi
internal object SonusGradeFxFactory {
    private data class Tuning(
        val brightness: Float = 0f, val exposure: Float = 0f, val contrast: Float = 0f,
        val saturation: Float = 0f, val temperature: Float = 0f, val tint: Float = 0f,
        val shadows: Float = 0f, val highlights: Float = 0f, val sharpen: Float = 0f,
        val fade: Float = 0f, val vignette: Float = 0f, val grain: Float = 0f
    )

    fun global(
        brightness: Float, exposure: Float, saturation: Float, contrast: Float,
        temperature: Float, tint: Float, highlights: Float, whites: Float, blacks: Float, shadows: Float,
        sharpen: Float, fade: Float, vignette: Float, grain: Float, opacity: Float
    ): List<Effect> {
        val out = mutableListOf<Effect>()
        val satDelta = (saturation * 100f).coerceIn(-100f, 100f)
        val lightDelta = (exposure * 35f).coerceIn(-100f, 100f)
        if (kotlin.math.abs(satDelta) > .01f || kotlin.math.abs(lightDelta) > .01f) {
            out += HslAdjustment.Builder().adjustSaturation(satDelta).adjustLightness(lightDelta).build()
        }
        if (kotlin.math.abs(brightness) > .001f) out += Brightness(brightness.coerceIn(-1f, 1f))
        if (kotlin.math.abs(contrast) > .001f) out += Contrast(contrast.coerceIn(-1f, 1f))
        if (kotlin.math.abs(temperature) > .001f || kotlin.math.abs(tint) > .001f) {
            out += RgbAdjustment.Builder()
                .setRedScale((1f + temperature * .18f + tint * .05f).coerceAtLeast(.55f))
                .setGreenScale((1f - tint * .08f).coerceAtLeast(.55f))
                .setBlueScale((1f - temperature * .18f + tint * .05f).coerceAtLeast(.55f))
                .build()
        }
        SonusVideoFxFactory.gradeEffect(
            shadows = (shadows + blacks * .45f).coerceIn(-1f, 1f),
            highlights = (highlights + whites * .45f).coerceIn(-1f, 1f),
            contrastShape = (whites - blacks).coerceIn(-1f, 1f),
            fade = fade.coerceIn(0f, 1f)
        )?.let(out::add)
        if (sharpen > .001f) out += SonusShaderEffect(9, sharpen.coerceIn(0f, 1f) * 1.2f)
        if (vignette > .001f) out += SonusShaderEffect(7, vignette.coerceIn(0f, 1f), .64f)
        if (grain > .001f) out += SonusShaderEffect(8, grain.coerceIn(0f, 1f))
        if (opacity < .999f) out += AlphaScale(opacity.coerceIn(0f, 1f))
        return out
    }

    fun filter(name: String, preset: PulseVideoPresetCatalog.FilterPreset?): List<Effect> {
        if (name.equals("Original", true)) return emptyList()
        val out = mutableListOf<Effect>()
        val lower = name.lowercase()
        val tuning = tuning(name)
        if (lower.contains("preto e branco") || lower.contains("grayscale") || lower == "noir") {
            out += RgbFilter.createGrayscaleFilter()
        }
        val presetSatDelta = (preset?.saturationPercent ?: 100f) - 100f
        val presetExposure = preset?.exposureEv ?: 0f
        val presetContrast = (preset?.contrast ?: 0f) / 100f
        val sat = (presetSatDelta + tuning.saturation * 100f).coerceIn(-100f, 100f)
        val light = (tuning.exposure * 35f + presetExposure * 18f).coerceIn(-100f, 100f)
        if (kotlin.math.abs(sat) > .01f || kotlin.math.abs(light) > .01f) {
            out += HslAdjustment.Builder().adjustSaturation(sat).adjustLightness(light).build()
        }
        if (kotlin.math.abs(tuning.brightness) > .001f) out += Brightness(tuning.brightness.coerceIn(-1f,1f))
        val c = (presetContrast + tuning.contrast).coerceIn(-1f,1f)
        if (kotlin.math.abs(c) > .001f) out += Contrast(c)
        val temp = ((preset?.temperature ?: 0f) / 100f + tuning.temperature).coerceIn(-1f,1f)
        val tint = ((preset?.tint ?: 0f) / 100f + tuning.tint).coerceIn(-1f,1f)
        if (kotlin.math.abs(temp) > .001f || kotlin.math.abs(tint) > .001f) {
            out += RgbAdjustment.Builder()
                .setRedScale((1f + temp*.18f + tint*.05f).coerceAtLeast(.55f))
                .setGreenScale((1f - tint*.08f).coerceAtLeast(.55f))
                .setBlueScale((1f - temp*.18f + tint*.05f).coerceAtLeast(.55f)).build()
        }
        SonusVideoFxFactory.gradeEffect(tuning.shadows, tuning.highlights, 0f, tuning.fade)?.let(out::add)
        val sharpen = (tuning.sharpen + ((preset?.sharpen ?: 0f) / 100f)).coerceIn(0f,1f)
        if (sharpen > .001f) out += SonusShaderEffect(9, sharpen * 1.2f)
        if (tuning.vignette > .001f) out += SonusShaderEffect(7, tuning.vignette.coerceIn(0f,1f), .64f)
        if (tuning.grain > .001f) out += SonusShaderEffect(8, tuning.grain.coerceIn(0f,1f))
        out += SonusVideoFxFactory.effectStackFor(name)
        return out
    }

    private fun tuning(name: String): Tuning = when(name.lowercase()) {
        "warm tone", "warm" -> Tuning(temperature=.32f, saturation=.08f)
        "cool tone", "cool" -> Tuning(temperature=-.30f, saturation=.04f)
        "cyberpunk" -> Tuning(contrast=.18f, saturation=.26f, tint=.20f, shadows=-.08f)
        "noir" -> Tuning(contrast=.28f, shadows=-.18f, highlights=.08f, vignette=.28f)
        "sepia" -> Tuning(temperature=.18f, saturation=-.18f, contrast=.05f)
        "posterize" -> Tuning(contrast=.08f, saturation=.12f)
        "faded" -> Tuning(contrast=-.16f, saturation=-.12f, fade=.45f)
        "teal & orange" -> Tuning(contrast=.16f, saturation=.14f, temperature=.12f, tint=-.10f)
        "golden" -> Tuning(exposure=.08f, temperature=.26f, saturation=.12f)
        "blue hour" -> Tuning(exposure=-.06f, temperature=-.35f, tint=.08f, saturation=-.05f)
        "moody" -> Tuning(exposure=-.10f, contrast=.22f, saturation=-.12f, shadows=-.18f, vignette=.20f)
        "clean" -> Tuning(exposure=.08f, contrast=.05f, saturation=.03f, sharpen=.12f)
        "bright" -> Tuning(exposure=.18f, brightness=.06f, saturation=.06f)
        "vintage" -> Tuning(contrast=-.08f, saturation=-.14f, temperature=.16f, fade=.25f, grain=.18f, vignette=.16f)
        "retro" -> Tuning(contrast=.04f, saturation=-.08f, temperature=.12f, grain=.22f)
        "cinema", "cinemático" -> Tuning(contrast=.20f, saturation=.06f, shadows=-.10f, highlights=-.08f, vignette=.16f)
        "night", "cidade noturna" -> Tuning(exposure=-.12f, contrast=.18f, temperature=-.24f, saturation=.08f, highlights=-.18f)
        "natural+" -> Tuning(exposure=.02f, saturation=.01f, sharpen=.03f)
        "luz suave" -> Tuning(exposure=.03f, contrast=-.02f, highlights=-.03f)
        "quente natural" -> Tuning(temperature=.04f, saturation=.01f)
        "frio natural" -> Tuning(temperature=-.04f)
        "contraste suave" -> Tuning(contrast=.03f, shadows=.02f)
        "cinema clean" -> Tuning(contrast=.03f, saturation=-.01f, temperature=.01f)
        "dourado" -> Tuning(temperature=.06f, saturation=.02f)
        "noite limpa" -> Tuning(exposure=.02f, contrast=.02f, temperature=-.03f, sharpen=.03f)
        "pastel natural" -> Tuning(exposure=.02f, contrast=-.03f, saturation=-.02f)
        "clareza+" -> Tuning(contrast=.02f, sharpen=.05f)
        "neon", "neon pop" -> Tuning(contrast=.16f, saturation=.32f, sharpen=.10f)
        else -> Tuning()
    }
}

/** Shared real-time effect stack for SONUS video preview/export.
 * Uses the same Media3 primitives and SONUS GPU shaders used by export; no decorative Canvas fallbacks.
 */
@UnstableApi
internal object SonusPreviewFxFactory {
    private data class Tuning(
        val brightness: Float = 0f, val exposure: Float = 0f, val contrast: Float = 0f,
        val saturation: Float = 0f, val temperature: Float = 0f, val tint: Float = 0f,
        val shadows: Float = 0f, val highlights: Float = 0f, val sharpen: Float = 0f,
        val fade: Float = 0f, val vignette: Float = 0f, val grain: Float = 0f
    )

    fun build(
        filter: String, effect: String,
        brightness: Float, exposure: Float, saturation: Float, contrast: Float,
        temperature: Float, tint: Float, highlights: Float, whites: Float, blacks: Float, shadows: Float,
        sharpen: Float, fade: Float, vignette: Float, grain: Float, opacity: Float,
        filterPreset: PulseVideoPresetCatalog.FilterPreset? = null
    ): List<Effect> {
        val out = SonusGradeFxFactory.global(
            brightness, exposure, saturation, contrast, temperature, tint,
            highlights, whites, blacks, shadows, sharpen, fade, vignette, grain, opacity
        ).toMutableList()
        out += SonusGradeFxFactory.filter(filter, filterPreset)
        out += SonusVideoFxFactory.effectStackFor(effect)
        return out
    }

    private fun tuning(name: String): Tuning = when(name.lowercase()) {
        "warm tone", "warm" -> Tuning(temperature=.32f, saturation=.08f)
        "cool tone", "cool" -> Tuning(temperature=-.30f, saturation=.04f)
        "cyberpunk" -> Tuning(contrast=.18f, saturation=.26f, tint=.20f, shadows=-.08f)
        "noir" -> Tuning(contrast=.28f, shadows=-.18f, highlights=.08f, vignette=.28f)
        "sepia" -> Tuning(temperature=.18f, saturation=-.18f, contrast=.05f)
        "faded" -> Tuning(contrast=-.16f, saturation=-.12f, fade=.45f)
        "teal & orange" -> Tuning(contrast=.16f, saturation=.14f, temperature=.12f, tint=-.10f)
        "golden" -> Tuning(exposure=.08f, temperature=.26f, saturation=.12f)
        "blue hour" -> Tuning(exposure=-.06f, temperature=-.35f, tint=.08f, saturation=-.05f)
        "moody" -> Tuning(exposure=-.10f, contrast=.22f, saturation=-.12f, shadows=-.18f, vignette=.20f)
        "clean" -> Tuning(exposure=.08f, contrast=.05f, saturation=.03f, sharpen=.12f)
        "bright" -> Tuning(exposure=.18f, brightness=.06f, saturation=.06f)
        "vintage" -> Tuning(contrast=-.08f, saturation=-.14f, temperature=.16f, fade=.25f, grain=.18f, vignette=.16f)
        "retro" -> Tuning(contrast=.04f, saturation=-.08f, temperature=.12f, grain=.22f)
        "cinema", "cinemático" -> Tuning(contrast=.20f, saturation=.06f, shadows=-.10f, highlights=-.08f, vignette=.16f)
        "night" -> Tuning(exposure=-.12f, contrast=.18f, temperature=-.24f, saturation=.08f, highlights=-.18f)
        "neon" -> Tuning(contrast=.16f, saturation=.32f, sharpen=.10f)
        else -> Tuning()
    }
}

