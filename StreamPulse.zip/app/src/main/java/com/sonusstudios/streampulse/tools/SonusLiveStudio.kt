package com.sonusstudios.streampulse.tools

import android.content.Context
import android.content.res.Configuration
import android.media.AudioManager
import android.net.TrafficStats
import android.os.Process
import android.os.SystemClock
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonusstudios.streampulse.core.MembershipTier
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.flow.first
import java.text.Normalizer
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin
import kotlin.random.Random

private val LiveRed = Color(0xFFFF3B4E)
private val LiveCyan = Color(0xFF46DCFF)
private val LiveBg = Color(0xFF080C1C)

private fun liveCatalogKey(raw: String): String = Normalizer.normalize(raw.trim().lowercase(Locale.ROOT), Normalizer.Form.NFD)
    .replace(Regex("\\p{M}+"), "").replace(Regex("\\s+"), " ")

private enum class LivePhase { TUTORIAL, CONFIG, COUNTDOWN, ON_AIR, ENDED }
private enum class LiveSource { RADIO, STREAM, LOCAL }
private data class LiveStation(val id: String, val title: String, val hint: String, val tracks: List<SonusOnlineTrack>)
private data class LiveCta(val text: String, val color: Color, val darkText: Boolean = false)

private val liveIntervals = listOf(15, 30, 45, 60, 90, 120)

// Chamadas que se alternam: cada uma com a sua cor e o seu pedido.
private val liveCtas = listOf(
    LiveCta("Se inscreva no canal", Color(0xFFE5202F)),
    LiveCta("Deixe seu like", Color(0xFF1E88E5)),
    LiveCta("Deixe seu comentário", Color(0xFF2E9E57)),
    LiveCta("Colabore com o canal", Color(0xFFFFC107), darkText = true),
    LiveCta("Compartilhe esta LIVE", Color(0xFF6D5CE8)),
    LiveCta("Ative as notificações", Color(0xFF008C95)),
    LiveCta("Siga o canal", Color(0xFF8E44AD))
)

/**
 * SONUS Studio ao vivo (0.0.1). A transmissão é feita 100% pelo TikTok (modo Jogo / transmitir a tela):
 * este Studio é só a tela limpa que fica aparecendo. Usa o MESMO player do app (rádio/Stream/biblioteca),
 * mostra letras, galeria SONUS (fotos e vídeos mudos) e conta o tempo de live do plano.
 */
@Composable
internal fun SonusLiveStudioScreen(
    membershipTier: MembershipTier,
    ownerUnlimited: Boolean,
    playback: PulsePlayerPlaybackState,
    service: PulsePlayerService?,
    onTrack: (String, Boolean?, Long?) -> Unit,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val limits = remember(membershipTier, ownerUnlimited) { SonusLiveUsage.limitsFor(membershipTier, ownerUnlimited) }
    val audio = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }

    var phaseName by rememberSaveable { mutableStateOf(if (SonusLiveUsage.tutorialSeen(context)) LivePhase.CONFIG.name else LivePhase.TUTORIAL.name) }
    val phase = LivePhase.valueOf(phaseName)
    var usage by remember { mutableStateOf(SonusLiveUsage.snapshot(context)) }

    // Catálogo do Stream: estações/gêneros pela MESMA regra da SONUS Rádio do Stream (gênero da faixa, nunca nome de pasta).
    var radioStations by remember { mutableStateOf<List<LiveStation>>(emptyList()) }
    var genreStations by remember { mutableStateOf<List<LiveStation>>(emptyList()) }
    var catalogLoading by remember { mutableStateOf(true) }
    var localTracks by remember { mutableIntStateOf(0) }
    val repo = remember { SonusOnlineMusicRepository(context.applicationContext) }
    LaunchedEffect(Unit) {
        suspend fun rebuildStations() {
            val loaded = withContext(Dispatchers.IO) {
                val snap = repo.cachedInitialStreamSnapshot()
                // Comparação sem diferenciar maiúsculas/minúsculas/espaços: evita ocultar
                // gêneros publicados por pequenas diferenças de escrita no catálogo.
                val published = snap.publishedGenres.map { it.trim() }.filter { it.isNotBlank() }
                val visible = snap.genres.filter { folder -> published.any { liveCatalogKey(it) == liveCatalogKey(folder.name) } }
                val all = visible.flatMap { snap.trackMap[it].orEmpty() }.distinctBy { it.fileId }
                val genre = sonusStreamGenreStations(visible, snap.trackMap, context)
                    .map { (name, tracks) -> LiveStation("genre:${name.trim().lowercase(Locale.ROOT)}", "Rádio $name", name, tracks.distinctBy { it.fileId }) }
                    .filter { it.tracks.isNotEmpty() }
                val forYou = if (all.size >= 3) listOf(LiveStation("for_you", "Rádio Para Você", "", all.shuffled())) else emptyList()
                Triple(forYou + genre, genre, sonusLocalLibraryQueue(context).size)
            }
            radioStations = loaded.first
            genreStations = loaded.second
            localTracks = loaded.third
            catalogLoading = false
        }
        rebuildStations()
        // Uma única revalidação após mostrar o cache. Não mantém polling de catálogo
        // enquanto o usuário configura a LIVE; a tela continua responsiva e leve.
        withContext(Dispatchers.IO) {
            runCatching { repo.refreshCatalogIfChanged() }
            runCatching { repo.refreshPublishedGenres() }
        }
        rebuildStations()
    }

    var sourceName by rememberSaveable { mutableStateOf(LiveSource.RADIO.name) }
    val source = LiveSource.valueOf(sourceName)
    var radioId by rememberSaveable { mutableStateOf("for_you") }
    var genreId by rememberSaveable { mutableStateOf("") }
    var intervalSeconds by rememberSaveable { mutableStateOf(30) }
    val livePreferences = remember(context) { context.getSharedPreferences("sonus_live_preferences_v1", Context.MODE_PRIVATE) }
    var countdownSeconds by rememberSaveable {
        mutableIntStateOf(livePreferences.getInt("countdown_seconds", 10).coerceAtLeast(10))
    }
    var videoShare by rememberSaveable { mutableStateOf(40) }
    var muteMicOnStart by rememberSaveable { mutableStateOf(true) }
    var previewId by remember { mutableStateOf<String?>(null) }
    var preparedSceneCount by remember { mutableIntStateOf(0) }
    var mediaPreparing by remember { mutableStateOf(false) }
    var mediaRetryKey by remember { mutableIntStateOf(0) }

    val selectedRadio = radioStations.firstOrNull { it.id == radioId } ?: radioStations.firstOrNull()
    val selectedGenre = genreStations.firstOrNull { it.id == genreId } ?: genreStations.firstOrNull()

    // Prepara somente a primeira cena. O palco repõe até cinco cenas em segundo plano;
    // a LIVE nunca fica bloqueada aguardando um lote inteiro de imagens.
    LaunchedEffect(sourceName, radioId, genreId, selectedRadio?.id, selectedGenre?.id, mediaRetryKey) {
        val themeWords = when (source) {
            LiveSource.RADIO -> listOf(selectedRadio?.hint.orEmpty(), selectedRadio?.title.orEmpty())
            LiveSource.STREAM -> listOf(selectedGenre?.hint.orEmpty(), selectedGenre?.title.orEmpty())
            LiveSource.LOCAL -> listOf("Biblioteca interna", "Música")
        }.filter { it.isNotBlank() }
        preparedSceneCount = 0
        mediaPreparing = true
        try {
            preparedSceneCount = SonusLiveMediaRepo.warmUp(context, count = 1, themeWords = themeWords)
        } finally {
            mediaPreparing = false
        }
    }

    var startedAt by remember { mutableLongStateOf(0L) }
    var rxStart by remember { mutableLongStateOf(-1L) }
    var netBytes by remember { mutableLongStateOf(0L) }
    var endedByLimit by remember { mutableStateOf(false) }
    var summarySeconds by remember { mutableLongStateOf(0L) }
    var summaryBytes by remember { mutableLongStateOf(0L) }
    var countdown by remember { mutableIntStateOf(countdownSeconds) }

    fun finishLive(byLimit: Boolean) {
        if (phase != LivePhase.ON_AIR) return
        val elapsedMs = (SystemClock.elapsedRealtime() - startedAt).coerceAtLeast(0L)
        val rx = TrafficStats.getUidRxBytes(Process.myUid())
        val bytes = if (rx >= 0L && rxStart >= 0L) (rx - rxStart).coerceAtLeast(netBytes) else netBytes
        SonusLiveUsage.finishSession(context, elapsedMs / 1000L, bytes)
        runCatching { audio.isMicrophoneMute = false }
        onTrack("SONUS Studio ao vivo", true, elapsedMs)
        summarySeconds = elapsedMs / 1000L
        summaryBytes = bytes
        endedByLimit = byLimit
        usage = SonusLiveUsage.snapshot(context)
        service?.pause()
        phaseName = LivePhase.ENDED.name
    }

    /** Monta a fila escolhida no player. Devolve false (com aviso) se não for possível iniciar. */
    suspend fun startMusic(): Boolean {
        val svc = service ?: run { Toast.makeText(context, "Player ainda está iniciando. Tente novamente.", Toast.LENGTH_SHORT).show(); return false }
        if (SonusLiveUsage.remainingSeconds(context, limits) <= 0L) {
            Toast.makeText(context, "Seu tempo de live acabou por hoje ou neste mês.", Toast.LENGTH_LONG).show(); return false
        }
        when (source) {
            LiveSource.RADIO -> {
                val station = selectedRadio ?: run { Toast.makeText(context, "Ainda não há músicas suficientes para a rádio.", Toast.LENGTH_SHORT).show(); return false }
                // Montagem da programação fora da thread principal: listas grandes não
                // podem congelar a contagem nem atrasar o início da LIVE.
                val start = withContext(Dispatchers.Default) {
                    SonusRadioEngine.prepare(context, station.id, station.title, station.tracks, repo, emptySet(), station.hint)
                } ?: run { Toast.makeText(context, "Não foi possível montar a rádio agora.", Toast.LENGTH_SHORT).show(); return false }
                svc.setQueue(start.queue, start.index, false)
                svc.setRepeatMode(0)
                svc.playIndex(start.index, true, start.startPositionMs)
            }
            LiveSource.STREAM -> {
                val station = selectedGenre ?: run { Toast.makeText(context, "Escolha um gênero do Stream.", Toast.LENGTH_SHORT).show(); return false }
                val queue = withContext(Dispatchers.Default) { station.tracks.shuffled().map { repo.queueItem(it) } }
                svc.setShuffle(false)
                svc.setQueue(queue, 0, true)
                svc.setRepeatMode(2)
            }
            LiveSource.LOCAL -> {
                val queue = withContext(Dispatchers.IO) { sonusLocalLibraryQueue(context) }
                if (queue.isEmpty()) { Toast.makeText(context, "Nenhuma música no telefone. Vincule sua biblioteca no Player.", Toast.LENGTH_LONG).show(); return false }
                svc.setShuffle(false)
                svc.setQueue(queue.shuffled(), 0, true)
                svc.setRepeatMode(2)
            }
        }
        // Áudio limpo: o microfone do aparelho é silenciado ao começar (recomendado; dá para religar no painel).
        // Não muda para ON_AIR só porque o comando foi enviado. Confirma que o player
        // realmente entrou em reprodução; caso contrário, retorna à configuração.
        val started = withTimeoutOrNull(10_000L) {
            svc.state.first { it.playing && it.current != null }
            true
        } ?: false
        if (!started) {
            runCatching { svc.pause() }
            Toast.makeText(context, "A música não iniciou. Verifique a fonte e tente novamente.", Toast.LENGTH_LONG).show()
            return false
        }
        if (muteMicOnStart) runCatching { audio.isMicrophoneMute = true }
        previewId = null
        return true
    }

    // Contagem regressiva e início: só depois dela a música começa e o tempo passa a contar.
    LaunchedEffect(phase) {
        if (phase != LivePhase.COUNTDOWN) return@LaunchedEffect
        for (n in countdownSeconds.coerceAtLeast(10) downTo 1) { countdown = n; delay(1_000L) }
        if (startMusic()) {
            startedAt = SystemClock.elapsedRealtime()
            rxStart = TrafficStats.getUidRxBytes(Process.myUid())
            netBytes = 0L
            phaseName = LivePhase.ON_AIR.name
        } else {
            phaseName = LivePhase.CONFIG.name
        }
    }

    // Tempo de live: só roda no ar, em segundos reais do relógio monotônico.
    LaunchedEffect(phase) {
        if (phase != LivePhase.ON_AIR) return@LaunchedEffect
        var last = SystemClock.elapsedRealtime()
        while (isActive) {
            delay(1_000L)
            val now = SystemClock.elapsedRealtime()
            val delta = (now - last) / 1000L
            if (delta > 0L) { SonusLiveUsage.addSeconds(context, delta); last += delta * 1000L }
            if (SonusLiveUsage.remainingSeconds(context, limits) <= 0L) { finishLive(true); break }
        }
    }
    // Segurança: se a tela for fechada com a live no ar, encerra a contagem e devolve microfone e barras do app.
    DisposableEffect(Unit) {
        onDispose {
            if (phase == LivePhase.ON_AIR) {
                val elapsed = (SystemClock.elapsedRealtime() - startedAt).coerceAtLeast(0L)
                SonusLiveUsage.finishSession(context, elapsed / 1000L, netBytes)
            }
            runCatching { audio.isMicrophoneMute = false }
            SonusLiveChrome.onAir = false
            SonusLiveChrome.barRevealed = false
        }
    }
    val immersive = phase == LivePhase.COUNTDOWN || phase == LivePhase.ON_AIR
    SonusLiveImmersiveEffect(active = immersive)
    LaunchedEffect(immersive) { SonusLiveChrome.onAir = immersive; if (!immersive) SonusLiveChrome.barRevealed = false }
    val view = LocalView.current
    DisposableEffect(immersive) {
        view.keepScreenOn = immersive
        onDispose { view.keepScreenOn = false }
    }

    Box(Modifier.fillMaxSize().background(LiveBg)) {
        when (phase) {
            LivePhase.TUTORIAL -> LiveTutorial(
                onDone = { SonusLiveUsage.setTutorialSeen(context); phaseName = LivePhase.CONFIG.name },
                onClose = onClose
            )
            LivePhase.CONFIG -> LiveConfig(
                limits = limits, usage = usage, catalogLoading = catalogLoading,
                radioStations = radioStations, genreStations = genreStations, localTracks = localTracks,
                source = source, onSource = { sourceName = it.name },
                radioId = selectedRadio?.id.orEmpty(), onRadio = { radioId = it },
                genreId = selectedGenre?.id.orEmpty(), onGenre = { genreId = it },
                previewId = previewId, previewPlaying = playback.playing,
                onPreview = { st ->
                    val svc = service
                    if (svc != null) {
                        if (previewId == st.id && playback.playing) svc.pause() else {
                            svc.setShuffle(false)
                            svc.setQueue(st.tracks.shuffled().map { repo.queueItem(it) }, 0, true)
                            svc.setRepeatMode(2)
                            previewId = st.id
                            genreId = st.id
                        }
                    }
                },
                intervalSeconds = intervalSeconds, onInterval = { intervalSeconds = it },
                countdownSeconds = countdownSeconds,
                onCountdown = { value ->
                    countdownSeconds = value.coerceAtLeast(10)
                    livePreferences.edit().putInt("countdown_seconds", countdownSeconds).apply()
                },
                videoShare = videoShare, onVideoShare = { videoShare = it },
                muteMicOnStart = muteMicOnStart, onMuteMic = { muteMicOnStart = it },
                remainingSeconds = SonusLiveUsage.remainingSeconds(context, limits),
                preparedSceneCount = preparedSceneCount,
                mediaPreparing = mediaPreparing,
                onRetryMedia = { mediaRetryKey++ },
                onStart = { service?.pause(); phaseName = LivePhase.COUNTDOWN.name },
                onTutorial = { phaseName = LivePhase.TUTORIAL.name }, onClose = onClose
            )
            LivePhase.COUNTDOWN -> LiveCountdown(countdown)
            LivePhase.ON_AIR -> LiveOnAir(
                playback = playback, service = service, audio = audio,
                stationTitle = (if (source == LiveSource.RADIO) selectedRadio?.title else null) ?: "SONUS",
                themeFallback = (if (source == LiveSource.RADIO) selectedRadio?.hint else selectedGenre?.hint).orEmpty(),
                muteMicOnStart = muteMicOnStart, intervalSeconds = intervalSeconds, videoShare = videoShare,
                onBytes = { netBytes += it }, onEnd = { finishLive(false) }
            )
            LivePhase.ENDED -> LiveEnded(
                byLimit = endedByLimit, seconds = summarySeconds, bytes = summaryBytes,
                onBack = { usage = SonusLiveUsage.snapshot(context); phaseName = LivePhase.CONFIG.name },
                onClose = onClose
            )
        }
    }
}

// ───────────────────────── Tutorial ─────────────────────────

@Composable
private fun LiveTutorial(onDone: () -> Unit, onClose: () -> Unit) {
    val steps = listOf(
        "1. Abra o TikTok e entre em LIVE" to "Toque em + e escolha LIVE. O SONUS não está ligado ao TikTok: quem inicia a live é você, lá.",
        "2. Escolha o modo Jogo" to "Na parte de baixo da tela da LIVE, escolha o modo Jogo. É o modo do TikTok que transmite a tela do celular. Se ele pedir uma categoria ou jogo, escolha qualquer uma.",
        "3. Permita a transmissão da tela" to "Inicie a live e aceite o aviso do Android para gravar/transmitir a tela. O TikTok passa a mostrar tudo o que aparece no celular.",
        "4. Som do aparelho, sem microfone" to "No TikTok, deixe ligado o som do aparelho (som do jogo) e desligue o microfone. Assim sai só a música limpa do SONUS, sem ruído do ambiente. O SONUS também silencia o microfone sozinho ao começar.",
        "5. Não Perturbar" to "Ative o Não Perturbar do Android para que notificações e mensagens não apareçam na tela transmitida.",
        "6. Volte ao SONUS" to "Abra o SONUS (o TikTok continua transmitindo), toque em LIVE no Player, escolha rádio, gênero do Stream ou sua biblioteca, ajuste o tempo de troca das imagens e toque em Iniciar live.",
        "7. Durante a live" to "Toque na tela para mostrar os comandos e a barra do SONUS por alguns segundos. Você pode girar o celular para paisagem.",
        "8. Para terminar" to "Toque em Encerrar live no SONUS (o tempo para de contar) e depois encerre a transmissão no TikTok."
    )
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Sensors, null, tint = LiveRed, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(10.dp))
            Text("Como fazer sua live", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
            IconButton(onClick = onClose) { Icon(Icons.Default.Close, "Fechar", tint = Color.White) }
        }
        Spacer(Modifier.height(6.dp))
        Text("A transmissão é feita inteiramente pelo TikTok. O SONUS entrega um Studio limpo que roda sem parar.", color = Color.White.copy(alpha = .72f), fontSize = 13.sp)
        Spacer(Modifier.height(14.dp))
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(steps) { (title, body) ->
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color.White.copy(alpha = .06f))
                        .border(1.dp, Color.White.copy(alpha = .10f), RoundedCornerShape(16.dp)).padding(14.dp)
                ) {
                    Text(title, color = LiveCyan, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Spacer(Modifier.height(4.dp))
                    Text(body, color = Color.White.copy(alpha = .85f), fontSize = 13.sp, lineHeight = 18.sp)
                }
            }
            item {
                Text("Os nomes e as telas do TikTok mudam com o tempo e a live pode exigir um mínimo de seguidores. Se algum botão estiver com outro nome, procure pela transmissão de tela/jogo.", color = Color.White.copy(alpha = .55f), fontSize = 11.sp)
            }
        }
        Spacer(Modifier.height(10.dp))
        Button(onClick = onDone, modifier = Modifier.fillMaxWidth().height(52.dp), colors = ButtonDefaults.buttonColors(containerColor = LiveRed)) {
            Text("Entendi, configurar a live", fontWeight = FontWeight.Bold)
        }
    }
}

// ───────────────────────── Configuração ─────────────────────────

@Composable
private fun LiveConfig(
    limits: SonusLiveLimits, usage: SonusLiveUsageSnapshot, catalogLoading: Boolean,
    radioStations: List<LiveStation>, genreStations: List<LiveStation>, localTracks: Int,
    source: LiveSource, onSource: (LiveSource) -> Unit,
    radioId: String, onRadio: (String) -> Unit,
    genreId: String, onGenre: (String) -> Unit,
    previewId: String?, previewPlaying: Boolean, onPreview: (LiveStation) -> Unit,
    intervalSeconds: Int, onInterval: (Int) -> Unit,
    countdownSeconds: Int, onCountdown: (Int) -> Unit,
    videoShare: Int, onVideoShare: (Int) -> Unit,
    muteMicOnStart: Boolean, onMuteMic: (Boolean) -> Unit,
    remainingSeconds: Long,
    preparedSceneCount: Int, mediaPreparing: Boolean, onRetryMedia: () -> Unit,
    onStart: () -> Unit, onTutorial: () -> Unit, onClose: () -> Unit
) {
    // A preparação visual é assíncrona e não é pré-requisito para iniciar o áudio.
    // Com zero imagens prontas, o palco exibe o cenário oficial SONUS e tenta novamente.
    val canStart = remainingSeconds > 0L && when (source) {
        LiveSource.RADIO -> radioStations.isNotEmpty()
        LiveSource.STREAM -> genreStations.isNotEmpty()
        LiveSource.LOCAL -> localTracks > 0
    }
    LazyColumn(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Sensors, null, tint = LiveRed, modifier = Modifier.size(28.dp))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("Studio ao vivo", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black)
                    Text("Prepare tudo antes de iniciar a live.", color = Color.White.copy(alpha = .65f), fontSize = 12.sp)
                }
                TextButton(onClick = onTutorial) { Text("Tutorial", color = LiveCyan) }
                IconButton(onClick = onClose) { Icon(Icons.Default.Close, "Fechar", tint = Color.White) }
            }
        }
        item { LiveUsageCard(limits, usage) }
        item { LiveSectionTitle("Música") }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item { LiveChoiceChip("📻 SONUS Rádio", source == LiveSource.RADIO) { onSource(LiveSource.RADIO) } }
                item { LiveChoiceChip("SONUS Stream", source == LiveSource.STREAM) { onSource(LiveSource.STREAM) } }
                item { LiveChoiceChip("Biblioteca interna", source == LiveSource.LOCAL) { onSource(LiveSource.LOCAL) } }
            }
        }
        when (source) {
            LiveSource.RADIO -> item {
                Column {
                    if (catalogLoading) LiveHint("Carregando as estações…")
                    else if (radioStations.isEmpty()) LiveHint("O catálogo do Stream ainda não está disponível neste aparelho.")
                    else {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(radioStations, key = { it.id }) { st ->
                                LiveChoiceChip("📻 ${st.title.removePrefix("Rádio ")}", st.id == radioId) { onRadio(st.id) }
                            }
                        }
                        LiveHint("Só músicas da estação escolhida, com a locução da SONUS a cada 4 músicas.")
                    }
                }
            }
            LiveSource.STREAM -> {
                if (catalogLoading) item { LiveHint("Carregando os gêneros…") }
                else if (genreStations.isEmpty()) item { LiveHint("O catálogo do Stream ainda não está disponível neste aparelho.") }
                else {
                    items(genreStations, key = { it.id }) { st ->
                        LiveGenreCard(
                            name = st.hint, count = st.tracks.size, selected = st.id == genreId,
                            playing = previewId == st.id && previewPlaying,
                            onSelect = { onGenre(st.id) }, onPlay = { onPreview(st) }
                        )
                    }
                    item { LiveHint("Toque no ▶ para ouvir o gênero antes de iniciar. A live toca só o gênero escolhido, em ordem aleatória, sem locução.") }
                }
            }
            LiveSource.LOCAL -> {
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            if (localTracks > 0) "$localTracks música(s) no seu telefone, em ordem aleatória." else "Nenhuma música encontrada no telefone. Vincule sua biblioteca no Player para usar esta opção.",
                            color = Color.White.copy(alpha = .8f), fontSize = 13.sp
                        )
                        LiveWarning("⚠️ Músicas com direitos autorais podem causar a interrupção da live. Prefira o SONUS Stream.")
                    }
                }
            }
        }
        item { LiveSectionTitle("Contagem regressiva") }
        item {
            Column {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(listOf(10, 15, 20, 30)) { seconds ->
                        LiveChoiceChip("$seconds s", countdownSeconds == seconds) { onCountdown(seconds) }
                    }
                }
                LiveHint("A contagem mínima e padrão é 10 segundos, para preparar áudio e imagens antes de entrar no ar.")
            }
        }
        item { LiveSectionTitle("Troca das imagens") }
        item {
            Column {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(liveIntervals) { s -> LiveChoiceChip("$s s", s == intervalSeconds) { onInterval(s) } }
                }
                LiveHint("Vale só para fotos. Os vídeos da galeria tocam sempre mudos e até o fim.")
            }
        }
        item { LiveSectionTitle("Fotos e vídeos") }
        item {
            Column {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item { LiveChoiceChip("Mais fotos", videoShare == 15) { onVideoShare(15) } }
                    item { LiveChoiceChip("Equilibrado", videoShare == 40) { onVideoShare(40) } }
                    item { LiveChoiceChip("Mais vídeos", videoShare == 70) { onVideoShare(70) } }
                }
                LiveHint("Vídeos gastam mais internet que fotos.")
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                LiveSectionTitle("Preparação das cenas")
                Text(
                    when {
                        preparedSceneCount > 0 -> "Primeira cena pronta. As próximas imagens serão carregadas em segundo plano."
                        mediaPreparing -> "Preparando a primeira cena… você já pode iniciar a LIVE."
                        else -> "A LIVE pode iniciar com o cenário SONUS enquanto as imagens são carregadas novamente."
                    },
                    color = if (preparedSceneCount > 0) LiveCyan else Color(0xFFFFC66D),
                    fontSize = 12.sp
                )
                if (!mediaPreparing && preparedSceneCount == 0) {
                    OutlinedButton(onClick = onRetryMedia, modifier = Modifier.fillMaxWidth()) {
                        Text("Tentar preparar as imagens novamente")
                    }
                }
            }
        }
        item { LiveSectionTitle("Áudio da live") }
        item {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Silenciar o microfone ao iniciar", color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
                    Switch(checked = muteMicOnStart, onCheckedChange = onMuteMic)
                }
                LiveHint("Recomendado: o som sai limpo, sem ruído do ambiente. No TikTok, ative o som do aparelho (veja o Tutorial).")
            }
        }
        item {
            Column {
                Button(
                    onClick = onStart, enabled = canStart, modifier = Modifier.fillMaxWidth().height(58.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = LiveRed)
                ) {
                    Icon(Icons.Default.Sensors, null); Spacer(Modifier.width(8.dp))
                    Text(
                        when {
                            remainingSeconds <= 0L -> "Tempo de live esgotado"
                            mediaPreparing -> "Iniciar live • preparando mídia"
                            preparedSceneCount > 0 -> "Iniciar live"
                            else -> "Iniciar live • cenário SONUS"
                        },
                        fontWeight = FontWeight.Black, fontSize = 17.sp
                    )
                }
                Text("O tempo só começa a contar quando a live entra no ar e para em Encerrar live.", color = Color.White.copy(alpha = .5f), fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp, bottom = 24.dp))
            }
        }
    }
}

@Composable
private fun LiveGenreCard(name: String, count: Int, selected: Boolean, playing: Boolean, onSelect: () -> Unit, onPlay: () -> Unit) {
    val border = if (selected) LiveCyan else Color.White.copy(alpha = .12f)
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
            .background(if (selected) LiveCyan.copy(alpha = .10f) else Color.White.copy(alpha = .05f))
            .border(1.2.dp, border, RoundedCornerShape(16.dp)).clickable(onClick = onSelect).padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text("$count música(s)", color = Color.White.copy(alpha = .65f), fontSize = 12.sp)
        }
        Box(Modifier.size(44.dp).clip(CircleShape).background(if (playing) LiveRed else Color.White.copy(alpha = .14f)).clickable(onClick = onPlay), contentAlignment = Alignment.Center) {
            Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, if (playing) "Pausar" else "Ouvir", tint = Color.White)
        }
    }
}

@Composable
private fun LiveUsageCard(limits: SonusLiveLimits, usage: SonusLiveUsageSnapshot) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Color.White.copy(alpha = .06f))
            .border(1.dp, Color.White.copy(alpha = .10f), RoundedCornerShape(18.dp)).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Seu tempo de live", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        if (limits.unlimited) {
            Text("Tempo ilimitado", color = LiveCyan, fontWeight = FontWeight.Bold)
        } else {
            LiveUsageBar("Hoje", usage.usedTodaySeconds, limits.dailySeconds)
            LiveUsageBar("Neste mês", usage.usedMonthSeconds, limits.monthlySeconds)
        }
        Text(
            "Internet usada na última live: ${SonusLiveUsage.formatBytes(usage.lastSessionBytes)} • Total em lives: ${SonusLiveUsage.formatBytes(usage.totalBytes)} (${usage.sessions} lives)",
            color = Color.White.copy(alpha = .6f), fontSize = 11.sp
        )
    }
}

@Composable
private fun LiveUsageBar(label: String, used: Long, limit: Long) {
    val left = (limit - used).coerceAtLeast(0L)
    val fraction = if (limit <= 0L) 0f else (left.toFloat() / limit.toFloat()).coerceIn(0f, 1f)
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = Color.White.copy(alpha = .8f), fontSize = 12.sp)
            Text("restam ${SonusLiveUsage.formatDuration(left)} de ${SonusLiveUsage.formatDuration(limit)}", color = Color.White.copy(alpha = .8f), fontSize = 12.sp)
        }
        Spacer(Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { fraction }, modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape),
            color = if (fraction > 0.2f) LiveCyan else LiveRed, trackColor = Color.White.copy(alpha = .12f)
        )
    }
}

@Composable
private fun LiveSectionTitle(text: String) { Text(text, color = Color.White, fontWeight = FontWeight.Black, fontSize = 16.sp) }

@Composable
private fun LiveHint(text: String) { Text(text, color = Color.White.copy(alpha = .55f), fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp)) }

@Composable
private fun LiveChoiceChip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(selected = selected, onClick = onClick, label = { Text(label, fontWeight = FontWeight.SemiBold) })
}

@Composable
private fun LiveWarning(text: String) {
    Text(text, color = Color(0xFFFFD36A), fontSize = 12.sp, modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0x33FFB300)).padding(12.dp))
}

// ───────────────────────── Contagem regressiva ─────────────────────────

@Composable
private fun LiveCountdown(n: Int) {
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text("A live começa em", color = Color.White.copy(alpha = .8f), fontSize = 18.sp)
        Text("$n", color = LiveRed, fontSize = 120.sp, fontWeight = FontWeight.Black)
        Text("Confira se o TikTok já está transmitindo a tela.", color = Color.White.copy(alpha = .6f), fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 32.dp))
    }
}

// ───────────────────────── No ar ─────────────────────────

@Composable
private fun LiveOnAir(
    playback: PulsePlayerPlaybackState, service: PulsePlayerService?, audio: AudioManager,
    stationTitle: String, themeFallback: String, muteMicOnStart: Boolean, intervalSeconds: Int, videoShare: Int,
    onBytes: (Long) -> Unit, onEnd: () -> Unit
) {
    val context = LocalContext.current
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val item = playback.current
    val isVoice = item?.kind == PulseQueueKind.RADIO_VOICE
    var themeGenre by remember { mutableStateOf(themeFallback) }
    var themeTitle by remember { mutableStateOf("") }
    LaunchedEffect(item?.uri) {
        if (item != null && item.kind != PulseQueueKind.RADIO_VOICE) {
            if (item.genre.isNotBlank()) themeGenre = item.genre
            themeTitle = item.title
        }
    }
    val themeWords = remember(themeGenre, themeTitle) { listOf(themeGenre, themeTitle) }

    var pool by remember { mutableStateOf<List<SonusLiveMediaItem>>(emptyList()) }
    LaunchedEffect(Unit) { pool = SonusLiveMediaRepo.list() }

    // Comandos: aparecem ao tocar (junto com a barra inferior do SONUS) e somem sozinhos em 7 s.
    var overlay by remember { mutableStateOf(false) }
    var overlayTick by remember { mutableIntStateOf(0) }
    var confirmEnd by remember { mutableStateOf(false) }
    LaunchedEffect(overlay, overlayTick, confirmEnd) {
        if (overlay) {
            SonusLiveChrome.barRevealed = true
            if (!confirmEnd) {
                delay(7_000L)
                overlay = false
                SonusLiveChrome.barRevealed = false
            }
        } else {
            SonusLiveChrome.barRevealed = false
        }
    }

    // Chamadas coloridas (inscrever / like / comentário / colaborar): ~8 s a cada ~40 s.
    var ctaIndex by remember { mutableIntStateOf(0) }
    var ctaShown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(15_000L)
        while (isActive) {
            ctaShown = true
            delay(7_000L)
            ctaShown = false
            ctaIndex = (ctaIndex + 1) % liveCtas.size
            delay(7_000L)
        }
    }
    var promoIndex by remember { mutableIntStateOf(0) }
    var promoShown by remember { mutableStateOf(false) }
    val promoEligible by rememberUpdatedState(!isVoice)
    // LiveOnAir só existe enquanto a fase ON_AIR está na composição; o efeito é
    // cancelado automaticamente quando a tela sai do ar.
    LaunchedEffect(Unit) {
        try {
            delay(120_000L)
            while (isActive) {
                if (promoEligible) {
                    promoShown = true
                    delay(8_000L)
                    promoShown = false
                    promoIndex = (promoIndex + 1) % 2
                }
                delay(112_000L)
            }
        } finally { promoShown = false }
    }

    var voiceCtaIndex by remember { mutableIntStateOf(0) }
    LaunchedEffect(isVoice) {
        if (isVoice) { voiceCtaIndex = ctaIndex; ctaIndex = (ctaIndex + 1) % liveCtas.size }
    }

    var micMuted by remember { mutableStateOf(runCatching { audio.isMicrophoneMute }.getOrDefault(muteMicOnStart)) }
    val maxVol = remember { audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    var volume by remember { mutableIntStateOf(audio.getStreamVolume(AudioManager.STREAM_MUSIC)) }

    Box(
        Modifier.fillMaxSize().clickable(indication = null, interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }) {
            overlay = true
            overlayTick++
        }
    ) {
        if (landscape) {
            // Paisagem: a imagem principal permanece inteira no centro; a mesma imagem preenche o fundo desfocada.
            LiveMediaStage(pool = pool, themeWords = themeWords, intervalSeconds = intervalSeconds, videoShare = videoShare, onNetworkBytes = onBytes, modifier = Modifier.fillMaxSize(), landscapeMode = true)
            Row(Modifier.fillMaxSize()) {
                Box(Modifier.weight(1f).fillMaxHeight().background(Brush.horizontalGradient(listOf(Color(0xCC070B16), Color(0x55070B16)))).padding(22.dp), contentAlignment = Alignment.CenterStart) {
                    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        LiveNowPlaying(item, isVoice, stationTitle, !overlay)
                        AnimatedVisibility(visible = ctaShown && !isVoice, enter = fadeIn(), exit = fadeOut()) { LiveCtaPill(liveCtas[ctaIndex], big = false) }
                    }
                }
                Box(Modifier.fillMaxHeight().aspectRatio(9f / 16f)) {
                    LiveParticles(Modifier.fillMaxSize())
                    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x22000000), Color(0x00000000), Color(0x55000000)))))
                }
                Box(Modifier.weight(1f).fillMaxHeight().background(Brush.horizontalGradient(listOf(Color(0x55070B16), Color(0xCC070B16)))).padding(22.dp), contentAlignment = Alignment.Center) {
                    // Mantém a lateral limpa: sem letra gigante ou texto central sobre a imagem.
                }
            }
        } else {
            LiveMediaStage(pool = pool, themeWords = themeWords, intervalSeconds = intervalSeconds, videoShare = videoShare, onNetworkBytes = onBytes, modifier = Modifier.fillMaxSize())
            LiveParticles(Modifier.fillMaxSize())
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x59000000), Color(0x1F000000), Color(0x5C000000), Color(0xB3000000)))))
            Column(Modifier.align(Alignment.BottomStart).navigationBarsPadding().padding(start = 20.dp, end = 20.dp, bottom = 22.dp)) {
                AnimatedVisibility(visible = ctaShown && !isVoice, enter = fadeIn(), exit = fadeOut()) { LiveCtaPill(liveCtas[ctaIndex], big = false) }
                Spacer(Modifier.height(10.dp))
                LiveNowPlaying(item, isVoice, stationTitle, !overlay)
            }
        }

        // Pausa da locução: sem imagem, com a chamada em destaque.
        AnimatedVisibility(visible = isVoice, enter = fadeIn(tween(500)), exit = fadeOut(tween(500))) {
            val next = playback.queue.getOrNull(playback.index + 1)
            val progress = if (playback.durationMs > 0L) (playback.positionMs.toFloat() / playback.durationMs.toFloat()).coerceIn(0f, 1f) else 0f
            LiveVoiceBreak(stationTitle, next?.takeIf { it.kind != PulseQueueKind.RADIO_VOICE }?.title.orEmpty(), progress, liveCtas[voiceCtaIndex % liveCtas.size], landscape)
        }

        // Divulgação compacta, apenas sobre músicas e nunca sobre a locução ou o painel de comandos.
        AnimatedVisibility(
            visible = promoShown && !isVoice && !overlay,
            modifier = Modifier.align(if (landscape) Alignment.BottomEnd else Alignment.BottomCenter).padding(horizontal = 12.dp).padding(bottom = 78.dp),
            enter = fadeIn(tween(350)), exit = fadeOut(tween(350))
        ) { LiveAppPromo(promoIndex, compact = landscape) }

        // Comandos (overlay).
        AnimatedVisibility(visible = overlay, enter = fadeIn(tween(250)), exit = fadeOut(tween(300))) {
            Box(Modifier.fillMaxSize().background(Color(0x99000000))) {
                Column(Modifier.fillMaxSize().statusBarsPadding().padding(start = 18.dp, end = 18.dp, top = 14.dp, bottom = 84.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(10.dp).clip(CircleShape).background(LiveRed))
                        Spacer(Modifier.width(8.dp))
                        Text("AO VIVO", color = Color.White, fontWeight = FontWeight.Black, fontSize = 13.sp, modifier = Modifier.weight(1f))
                        OutlinedButton(onClick = { confirmEnd = true; overlayTick++ }, border = BorderStroke(1.dp, LiveRed)) { Text("Encerrar live", color = LiveRed, fontWeight = FontWeight.Bold) }
                    }
                    Spacer(Modifier.weight(1f))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.VolumeUp, null, tint = Color.White)
                        Slider(
                            value = volume.toFloat(), valueRange = 0f..maxVol.toFloat(),
                            onValueChange = { v -> volume = v.toInt(); runCatching { audio.setStreamVolume(AudioManager.STREAM_MUSIC, volume, 0) }; overlayTick++ },
                            modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                            colors = SliderDefaults.colors(thumbColor = LiveCyan, activeTrackColor = LiveCyan)
                        )
                        IconButton(onClick = {
                            runCatching { audio.isMicrophoneMute = !audio.isMicrophoneMute }
                            micMuted = runCatching { audio.isMicrophoneMute }.getOrDefault(false)
                            overlayTick++
                        }) {
                            Icon(if (micMuted) Icons.Default.MicOff else Icons.Default.Mic, if (micMuted) "Microfone mudo" else "Microfone ligado", tint = if (micMuted) LiveRed else Color.White)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    val fraction = if (playback.durationMs > 0L) (playback.positionMs.toFloat() / playback.durationMs.toFloat()).coerceIn(0f, 1f) else 0f
                    LinearProgressIndicator(progress = { fraction }, modifier = Modifier.fillMaxWidth().height(4.dp).clip(CircleShape), color = Color.White, trackColor = Color.White.copy(alpha = .25f))
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { service?.previous(); overlayTick++ }, modifier = Modifier.size(56.dp)) { Icon(Icons.Default.SkipPrevious, "Anterior", tint = Color.White, modifier = Modifier.size(34.dp)) }
                        Box(Modifier.size(68.dp).clip(CircleShape).background(Color.White).clickable { service?.toggle(); overlayTick++ }, contentAlignment = Alignment.Center) {
                            Icon(if (playback.playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color(0xFF071A3D), modifier = Modifier.size(40.dp))
                        }
                        IconButton(onClick = { service?.next(true); overlayTick++ }, modifier = Modifier.size(56.dp)) { Icon(Icons.Default.SkipNext, "Próxima", tint = Color.White, modifier = Modifier.size(34.dp)) }
                    }
                }
            }
        }
    }

    if (confirmEnd) {
        AlertDialog(
            onDismissRequest = { confirmEnd = false },
            title = { Text("Encerrar a live?") },
            text = { Text("O tempo de live para de contar. Depois, lembre de encerrar a transmissão no TikTok.") },
            confirmButton = { TextButton(onClick = { confirmEnd = false; onEnd() }) { Text("Encerrar", color = LiveRed, fontWeight = FontWeight.Bold) } },
            dismissButton = { TextButton(onClick = { confirmEnd = false }) { Text("Continuar live") } }
        )
    }
}

@Composable
internal fun LiveAppPromo(index: Int, compact: Boolean) {
    val sonus = index % 2 == 0
    Row(
        Modifier.widthIn(max = if (compact) 286.dp else 340.dp)
            .fillMaxWidth(if (compact) .92f else .84f)
            .clip(RoundedCornerShape(50))
            .background(Color(0xD9111827))
            .border(1.dp, Color.White.copy(alpha = .22f), RoundedCornerShape(50))
            .padding(horizontal = 12.dp, vertical = if (compact) 7.dp else 9.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(Icons.Default.Download, contentDescription = "Baixe o SONUS", tint = LiveCyan, modifier = Modifier.size(if (compact) 16.dp else 18.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
            Text(if (sonus) "BAIXE O SONUS" else "BAIXE O SONUS EDIT", color = Color.White, fontWeight = FontWeight.Black, fontSize = if (compact) 9.sp else 10.sp, maxLines = 1)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Icon(Icons.Default.Send, contentDescription = "Telegram", tint = Color(0xFF58B7F5), modifier = Modifier.size(11.dp))
                Text("Telegram  @sonusappupdate", color = Color(0xFFB8E6FF), fontWeight = FontWeight.SemiBold, fontSize = if (compact) 8.sp else 9.sp, maxLines = 1)
            }
        }
    }
}

@Composable
private fun LiveNowPlaying(item: PulsePlayerQueueItem?, isVoice: Boolean, stationTitle: String, visible: Boolean) {
    // Some enquanto os comandos estão na tela, para nunca ficar por baixo dos botões.
    AnimatedVisibility(visible = visible && item != null && !isVoice, enter = fadeIn(tween(400)), exit = fadeOut(tween(200))) {
        Crossfade(targetState = item?.uri, animationSpec = tween(600), label = "now-playing") { _ ->
            Column {
                if (item != null) {
                    Text(item.title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, maxLines = 2, overflow = TextOverflow.Ellipsis, style = TextStyle(shadow = Shadow(Color.Black.copy(.7f), Offset(0f, 3f), 12f)))
                    Text(item.artist.ifBlank { stationTitle }, color = LiveCyan, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, style = TextStyle(shadow = Shadow(Color.Black.copy(.7f), Offset(0f, 2f), 8f)))
                }
            }
        }
    }
}

@Composable
private fun LiveCtaPill(cta: LiveCta, big: Boolean) {
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(cta.color).padding(horizontal = if (big) 34.dp else 16.dp, vertical = if (big) 16.dp else 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(cta.text, color = if (cta.darkText) Color(0xFF1B1B1B) else Color.White, fontWeight = FontWeight.Black, fontSize = if (big) 24.sp else 14.sp)
    }
}

@Composable
private fun LiveVoiceBreak(stationTitle: String, nextTitle: String, progress: Float, cta: LiveCta, compact: Boolean) {
    val infinite = rememberInfiniteTransition(label = "voice")
    val phase by infinite.animateFloat(0f, 1f, infiniteRepeatable(tween(1600, easing = LinearEasing), RepeatMode.Restart), label = "voice-phase")
    val pulse by infinite.animateFloat(0.94f, 1.06f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "voice-pulse")
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0A0F2E), Color(0xFF1A0B2E), Color(0xFF05060F))))) {
        LiveParticles(Modifier.fillMaxSize())
        Column(Modifier.fillMaxSize().padding(if (compact) 16.dp else 28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text("📻", fontSize = if (compact) 28.sp else 44.sp)
            Text(stationTitle, color = Color.White, fontSize = if (compact) 20.sp else 26.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
            Spacer(Modifier.height(if (compact) 8.dp else 22.dp))
            Canvas(Modifier.fillMaxWidth().height(if (compact) 40.dp else 80.dp)) {
                val bars = 28
                val w = size.width / (bars * 1.6f)
                for (i in 0 until bars) {
                    val x = i * (size.width / bars) + w / 2
                    val amp = (0.25f + 0.75f * abs(sin((i * 0.45f + phase * 2f * PI.toFloat()))))
                    val h = size.height * amp
                    drawRect(Brush.verticalGradient(listOf(LiveCyan, Color(0xFFB36BFF))), Offset(x, (size.height - h) / 2f), Size(w, h))
                }
            }
            Spacer(Modifier.height(if (compact) 10.dp else 26.dp))
            Box(Modifier.scale(pulse)) { LiveCtaPill(cta, big = true) }
            Spacer(Modifier.height(if (compact) 10.dp else 26.dp))
            LinearProgressIndicator(progress = { 1f - progress }, modifier = Modifier.width(160.dp).height(4.dp).clip(CircleShape), color = Color.White.copy(alpha = .8f), trackColor = Color.White.copy(alpha = .15f))
            if (nextTitle.isNotBlank()) Text("A seguir: $nextTitle", color = Color.White.copy(alpha = .7f), fontSize = 14.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 12.dp))
        }
    }
}

/** Partículas suaves caindo sobre a imagem (única camada de partículas do Studio). */
@Composable
private fun LiveParticles(modifier: Modifier = Modifier) {
    val infinite = rememberInfiniteTransition(label = "particles")
    val t by infinite.animateFloat(0f, 1f, infiniteRepeatable(tween(14_000, easing = LinearEasing), RepeatMode.Restart), label = "particles-t")
    val seeds = remember { List(46) { Triple(Random.nextFloat(), Random.nextFloat(), 0.4f + Random.nextFloat() * 1.3f) } }
    Canvas(modifier) {
        for ((sx, sy, sz) in seeds) {
            val speed = 0.6f + sz * 0.5f
            val y = ((sy + t * speed) % 1f) * size.height
            val x = (sx + sin((t * 2f * PI.toFloat()) + sx * 9f) * 0.018f) * size.width
            drawCircle(Color.White.copy(alpha = 0.18f + 0.22f * (sz / 1.7f)), radius = 1.6f + sz * 2.2f, center = Offset(x, y))
        }
    }
}

// ───────────────────────── Fim da live ─────────────────────────

@Composable
private fun LiveEnded(byLimit: Boolean, seconds: Long, bytes: Long, onBack: () -> Unit, onClose: () -> Unit) {
    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Text(if (byLimit) "Fim da transmissão" else "Live encerrada", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
        Spacer(Modifier.height(10.dp))
        Text("Obrigado por assistir.", color = Color.White.copy(alpha = .75f), fontSize = 15.sp)
        Spacer(Modifier.height(24.dp))
        Text("Duração: ${SonusLiveUsage.formatDuration(seconds)}", color = LiveCyan, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Text("Internet usada: ${SonusLiveUsage.formatBytes(bytes)}", color = LiveCyan, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        if (byLimit) Text("Seu tempo de live acabou.", color = Color.White.copy(alpha = .6f), fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
        Spacer(Modifier.height(28.dp))
        Button(onClick = onBack, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("Voltar ao Studio") }
        TextButton(onClick = onClose) { Text("Sair", color = Color.White.copy(alpha = .8f)) }
    }
}
