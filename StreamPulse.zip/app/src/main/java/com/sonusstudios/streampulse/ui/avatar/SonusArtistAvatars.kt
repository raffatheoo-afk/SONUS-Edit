package com.sonusstudios.streampulse.ui.avatar

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import com.sonusstudios.streampulse.core.MembershipTier
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

enum class SonusAvatarTheme { INSTRUMENTS, FLOWERS, ANIMALS, CHARACTERS, COSMOS }

data class SonusAvatarSpec(
    val id: String,
    val title: String,
    val tier: MembershipTier,
    val collection: String,
    val theme: SonusAvatarTheme,
    val index: Int
)

object SonusAvatarCatalog {
    private fun make(
        prefix: String,
        count: Int,
        tier: MembershipTier,
        collection: String,
        theme: SonusAvatarTheme,
        names: List<String>
    ) = (0 until count).map { index ->
        SonusAvatarSpec(
            id = "${prefix}_${index + 1}",
            title = names.getOrElse(index) { "$collection ${index + 1}" },
            tier = tier,
            collection = collection,
            theme = theme,
            index = index
        )
    }

    val instruments = make(
        "free_instrument", 10, MembershipTier.FREE, "Essenciais Sonoros", SonusAvatarTheme.INSTRUMENTS,
        listOf("Violão", "Guitarra", "Piano", "Microfone", "Bateria", "Sax", "Trompete", "Headphone", "Vinil", "Teclado")
    )
    val flowers = make(
        "bronze_flower", 10, MembershipTier.BRONZE, "Jardim SONUS", SonusAvatarTheme.FLOWERS,
        listOf("Rosa", "Girassol", "Lírio", "Tulipa", "Orquídea", "Lavanda", "Margarida", "Camélia", "Hibisco", "Peônia")
    )
    val animals = make(
        "silver_animal", 10, MembershipTier.PRATA, "Fauna SONUS", SonusAvatarTheme.ANIMALS,
        listOf("Lobo", "Leão", "Coruja", "Raposa", "Pantera", "Águia", "Cervo", "Tigre", "Cavalo", "Borboleta")
    )
    val characters = make(
        "gold_character", 10, MembershipTier.OURO, "Personas SONUS", SonusAvatarTheme.CHARACTERS,
        listOf("Vox", "Lyra", "Beat", "Nova", "Echo", "Riff", "Melo", "Aura", "Tempo", "Sol")
    )
    val cosmos = make(
        "diamond_cosmos", 20, MembershipTier.DIAMANTE, "Cosmos SONUS", SonusAvatarTheme.COSMOS,
        listOf(
            "Órbita Azul", "Estrela Rubi", "Lua Prisma", "Nebulosa Violeta", "Cometa Solar",
            "Planeta Aurora", "Estrela Ciano", "Lua Dourada", "Galáxia Rosa", "Cometa Índigo",
            "Planeta Esmeralda", "Supernova", "Lua Coral", "Nebulosa Celeste", "Cometa Magenta",
            "Planeta Eclipse", "Estrela Polar", "Lua Boreal", "Galáxia Diamante", "Cosmos SONUS"
        )
    )
    val all: List<SonusAvatarSpec> = instruments + flowers + animals + characters + cosmos
    fun byId(id: String?): SonusAvatarSpec? = all.firstOrNull { it.id == id }
    fun unlocked(spec: SonusAvatarSpec, tier: MembershipTier, owner: Boolean = false): Boolean = owner || tier.ordinal >= spec.tier.ordinal
}

private val palettes = listOf(
    listOf(Color(0xFF081B3A), Color(0xFF1479FF), Color(0xFF38D7FF)),
    listOf(Color(0xFF2A0B42), Color(0xFF8A3FFC), Color(0xFFFF5BC8)),
    listOf(Color(0xFF2E1307), Color(0xFFE46D2D), Color(0xFFFFD15C)),
    listOf(Color(0xFF092D25), Color(0xFF1BA784), Color(0xFF68F2C0)),
    listOf(Color(0xFF350A18), Color(0xFFE43B62), Color(0xFFFF8A9F)),
    listOf(Color(0xFF10132C), Color(0xFF5057E8), Color(0xFF9BA3FF)),
    listOf(Color(0xFF191919), Color(0xFF616161), Color(0xFFE8E8E8)),
    listOf(Color(0xFF2A1D05), Color(0xFFB88713), Color(0xFFFFE083)),
    listOf(Color(0xFF022D36), Color(0xFF00A9C7), Color(0xFF8EFBFF)),
    listOf(Color(0xFF250A31), Color(0xFFB029D8), Color(0xFFFF7BEF))
)
private val cosmosPalettes = listOf(
    listOf(Color(0xFF03152F), Color(0xFF0B63F6), Color(0xFF54E9FF)),
    listOf(Color(0xFF310912), Color(0xFFC21D44), Color(0xFFFF6F91)),
    listOf(Color(0xFF18103A), Color(0xFF6952E8), Color(0xFFBFA7FF)),
    listOf(Color(0xFF25083A), Color(0xFF8E28C9), Color(0xFFFF65D8)),
    listOf(Color(0xFF361704), Color(0xFFF06A12), Color(0xFFFFD65A)),
    listOf(Color(0xFF07342E), Color(0xFF16A77F), Color(0xFF8BFFD8)),
    listOf(Color(0xFF062B38), Color(0xFF00A8C6), Color(0xFF93FBFF)),
    listOf(Color(0xFF302104), Color(0xFFC18B16), Color(0xFFFFE991)),
    listOf(Color(0xFF31091F), Color(0xFFD42B79), Color(0xFFFF91C5)),
    listOf(Color(0xFF12174A), Color(0xFF3F50D9), Color(0xFF9EA8FF)),
    listOf(Color(0xFF083527), Color(0xFF25A96A), Color(0xFFA0FFB9)),
    listOf(Color(0xFF3B1307), Color(0xFFE14D24), Color(0xFFFFB26F)),
    listOf(Color(0xFF2A0D20), Color(0xFFC84D74), Color(0xFFFFA5A5)),
    listOf(Color(0xFF062A3B), Color(0xFF158BC4), Color(0xFF75E5FF)),
    listOf(Color(0xFF33052D), Color(0xFFD61EB0), Color(0xFFFF84EB)),
    listOf(Color(0xFF080A10), Color(0xFF394357), Color(0xFFB7C8E8)),
    listOf(Color(0xFF12253D), Color(0xFF5B92C9), Color(0xFFE5F4FF)),
    listOf(Color(0xFF052F2B), Color(0xFF3EC7B5), Color(0xFFB0FFF3)),
    listOf(Color(0xFF18072E), Color(0xFF7650D7), Color(0xFFE2D5FF)),
    listOf(Color(0xFF13052F), Color(0xFF7B20C8), Color(0xFFFF4FD8))
)


@Composable
fun SonusAvatarArtwork(
    avatarId: String,
    modifier: Modifier = Modifier,
    locked: Boolean = false
) {
    val spec = SonusAvatarCatalog.byId(avatarId) ?: return
    val palette = if (spec.theme == SonusAvatarTheme.COSMOS) cosmosPalettes[spec.index % cosmosPalettes.size]
    else palettes[(spec.index + spec.tier.ordinal * 2) % palettes.size]
    Box(
        modifier = modifier
            .background(Color.Black, CircleShape)
            .border(1.dp, Color.White.copy(alpha = .16f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val c = Offset(w / 2f, h / 2f)
            drawCircle(brush = Brush.radialGradient(palette.reversed(), center = Offset(w * .42f, h * .34f), radius = w * .78f), radius = w * .5f, center = c)
            drawCircle(Color.Black.copy(alpha = .18f), radius = w * .47f, center = c, style = Stroke(w * .015f))
            when (spec.theme) {
                SonusAvatarTheme.INSTRUMENTS -> drawInstrument(spec.index, palette)
                SonusAvatarTheme.FLOWERS -> drawFlower(spec.index, palette)
                SonusAvatarTheme.ANIMALS -> drawAnimal(spec.index, palette)
                SonusAvatarTheme.CHARACTERS -> drawCharacter(spec.index, palette)
                SonusAvatarTheme.COSMOS -> drawCosmos(spec.index, palette)
            }
        }
        if (locked) {
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .52f), CircleShape), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Lock, contentDescription = "Bloqueado", tint = Color.White)
            }
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawInstrument(index: Int, p: List<Color>) {
    val w = size.width; val h = size.height; val white = Color.White.copy(alpha = .92f); val accent = p.last()
    when (index % 10) {
        0, 1 -> { // violão/guitarra
            rotate(if (index == 0) -28f else 24f) {
                drawCircle(accent, w * .16f, Offset(w * .42f, h * .61f))
                drawCircle(Color.Black.copy(alpha = .65f), w * .055f, Offset(w * .42f, h * .61f))
                drawRoundRect(white, Offset(w * .48f, h * .23f), Size(w * .07f, h * .39f), CornerRadius(w * .035f))
                drawRoundRect(accent, Offset(w * .48f, h * .19f), Size(w * .07f, h * .08f), CornerRadius(w * .025f))
                drawLine(white, Offset(w * .39f, h * .50f), Offset(w * .55f, h * .50f), w * .018f)
            }
        }
        2 -> { // piano
            drawRoundRect(Color.Black.copy(alpha = .72f), Offset(w * .18f, h * .34f), Size(w * .64f, h * .34f), CornerRadius(w * .05f))
            val keyW = w * .075f
            repeat(7) { i -> drawRoundRect(white, Offset(w * (.235f + i * .075f), h * .40f), Size(keyW * .82f, h * .22f), CornerRadius(w * .012f)) }
            repeat(5) { i -> drawRoundRect(Color.Black, Offset(w * (.29f + i * .09f), h * .40f), Size(w * .035f, h * .13f), CornerRadius(w * .01f)) }
        }
        3 -> { // mic
            drawRoundRect(white, Offset(w * .39f, h * .20f), Size(w * .22f, h * .34f), CornerRadius(w * .11f))
            drawArc(accent, 0f, 180f, false, Offset(w * .31f, h * .34f), Size(w * .38f, h * .32f), style = Stroke(w * .035f, cap = StrokeCap.Round))
            drawLine(white, Offset(w * .50f, h * .64f), Offset(w * .50f, h * .78f), w * .04f, cap = StrokeCap.Round)
            drawLine(white, Offset(w * .38f, h * .78f), Offset(w * .62f, h * .78f), w * .04f, cap = StrokeCap.Round)
        }
        4 -> { // drums
            drawOval(accent, Offset(w * .24f, h * .35f), Size(w * .52f, h * .30f))
            drawOval(Color.Black.copy(alpha=.35f), Offset(w * .24f, h * .31f), Size(w * .52f, h * .18f), style=Stroke(w*.025f))
            drawLine(white, Offset(w*.30f,h*.25f),Offset(w*.56f,h*.52f),w*.025f,cap=StrokeCap.Round)
            drawLine(white, Offset(w*.70f,h*.25f),Offset(w*.44f,h*.52f),w*.025f,cap=StrokeCap.Round)
        }
        5 -> { // sax abstract
            val path=Path().apply{moveTo(w*.42f,h*.22f);cubicTo(w*.66f,h*.30f,w*.35f,h*.60f,w*.63f,h*.72f);cubicTo(w*.74f,h*.77f,w*.77f,h*.64f,w*.70f,h*.58f)}
            drawPath(path, accent, style=Stroke(w*.085f,cap=StrokeCap.Round))
            drawCircle(white,w*.035f,Offset(w*.57f,h*.42f));drawCircle(white,w*.03f,Offset(w*.53f,h*.52f))
        }
        6 -> { // trumpet
            drawLine(white,Offset(w*.25f,h*.52f),Offset(w*.62f,h*.52f),w*.07f,cap=StrokeCap.Round)
            val bell=Path().apply{moveTo(w*.60f,h*.38f);lineTo(w*.82f,h*.28f);lineTo(w*.82f,h*.72f);lineTo(w*.60f,h*.62f);close()}
            drawPath(bell,accent);repeat(3){i->drawLine(white,Offset(w*(.38f+i*.07f),h*.39f),Offset(w*(.38f+i*.07f),h*.50f),w*.025f)}
        }
        7 -> { // headphones
            drawArc(white, 195f, 150f, false, Offset(w*.22f,h*.18f),Size(w*.56f,h*.56f),style=Stroke(w*.07f,cap=StrokeCap.Round))
            drawRoundRect(accent,Offset(w*.20f,h*.46f),Size(w*.15f,h*.27f),CornerRadius(w*.06f));drawRoundRect(accent,Offset(w*.65f,h*.46f),Size(w*.15f,h*.27f),CornerRadius(w*.06f))
        }
        8 -> { // vinyl
            drawCircle(Color(0xFF101010),w*.30f,Offset(w*.50f,h*.50f));drawCircle(accent,w*.085f,Offset(w*.50f,h*.50f));drawCircle(white,w*.018f,Offset(w*.50f,h*.50f))
            repeat(3){i->drawCircle(white.copy(alpha=.25f),w*(.14f+i*.05f),Offset(w*.50f,h*.50f),style=Stroke(w*.01f))}
        }
        else -> { // keyboard
            drawRoundRect(Color.Black.copy(alpha=.70f),Offset(w*.13f,h*.35f),Size(w*.74f,h*.30f),CornerRadius(w*.04f))
            repeat(10){i->drawRoundRect(white,Offset(w*(.17f+i*.065f),h*.40f),Size(w*.052f,h*.19f),CornerRadius(w*.008f))}
            drawCircle(accent,w*.035f,Offset(w*.22f,h*.30f));drawCircle(accent,w*.035f,Offset(w*.32f,h*.30f))
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawFlower(index: Int, p: List<Color>) {
    val w=size.width;val h=size.height;val center=Offset(w*.5f,h*.48f);val petals=5+(index%5);val radius=w*(.19f+(index%3)*.018f)
    val petalColor=if(index%2==0)p.last() else Color.White.copy(alpha=.88f)
    repeat(petals){i->
        val a=2.0*PI*i/petals - PI/2
        val pc=Offset(center.x+cos(a).toFloat()*radius,center.y+sin(a).toFloat()*radius)
        rotate((a*180/PI).toFloat()+90f,pivot=pc){drawOval(petalColor,Offset(pc.x-w*.095f,pc.y-h*.16f),Size(w*.19f,h*.27f))}
    }
    drawCircle(p[1],w*.105f,center);drawCircle(Color.White.copy(alpha=.8f),w*.035f,center)
    drawLine(Color(0xFF83E39B),Offset(w*.50f,h*.58f),Offset(w*.48f,h*.82f),w*.035f,cap=StrokeCap.Round)
    if(index%2==1){drawOval(Color(0xFF71C989),Offset(w*.34f,h*.69f),Size(w*.16f,h*.08f));drawOval(Color(0xFF71C989),Offset(w*.49f,h*.73f),Size(w*.18f,h*.08f))}
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawAnimal(index: Int, p: List<Color>) {
    val w=size.width;val h=size.height;val face=Offset(w*.50f,h*.53f);val fur=Color.White.copy(alpha=.88f);val accent=p.last()
    // head + ears/horns variants create ten distinct original animal emblems
    drawOval(fur,Offset(w*.27f,h*.31f),Size(w*.46f,h*.44f))
    when(index%10){
        0,3,4,7->{
            val left=Path().apply{moveTo(w*.31f,h*.38f);lineTo(w*.19f,h*.15f);lineTo(w*.42f,h*.29f);close()};val right=Path().apply{moveTo(w*.69f,h*.38f);lineTo(w*.81f,h*.15f);lineTo(w*.58f,h*.29f);close()};drawPath(left,accent);drawPath(right,accent)
        }
        1->{repeat(10){i->val a=2*PI*i/10;drawCircle(accent,w*.09f,Offset(face.x+cos(a).toFloat()*w*.23f,face.y+sin(a).toFloat()*w*.23f))};drawOval(fur,Offset(w*.29f,h*.33f),Size(w*.42f,h*.40f))}
        2->{drawCircle(accent,w*.18f,Offset(w*.36f,h*.48f));drawCircle(accent,w*.18f,Offset(w*.64f,h*.48f))}
        5->{val beak=Path().apply{moveTo(w*.50f,h*.52f);lineTo(w*.73f,h*.60f);lineTo(w*.50f,h*.64f);close()};drawPath(beak,accent)}
        6->{drawLine(accent,Offset(w*.34f,h*.32f),Offset(w*.23f,h*.12f),w*.04f);drawLine(accent,Offset(w*.66f,h*.32f),Offset(w*.77f,h*.12f),w*.04f);drawLine(accent,Offset(w*.23f,h*.12f),Offset(w*.16f,h*.20f),w*.03f);drawLine(accent,Offset(w*.77f,h*.12f),Offset(w*.84f,h*.20f),w*.03f)}
        8->{drawRoundRect(accent,Offset(w*.29f,h*.23f),Size(w*.14f,h*.20f),CornerRadius(w*.06f));drawRoundRect(accent,Offset(w*.57f,h*.23f),Size(w*.14f,h*.20f),CornerRadius(w*.06f))}
        9->{repeat(4){i->val y=h*(.37f+i*.09f);drawOval(accent.copy(alpha=.9f-i*.1f),Offset(w*.15f,y),Size(w*.30f,h*.16f));drawOval(accent.copy(alpha=.9f-i*.1f),Offset(w*.55f,y),Size(w*.30f,h*.16f))};drawOval(fur,Offset(w*.45f,h*.28f),Size(w*.10f,h*.45f))}
    }
    if(index!=9){drawCircle(Color(0xFF111827),w*.035f,Offset(w*.40f,h*.50f));drawCircle(Color(0xFF111827),w*.035f,Offset(w*.60f,h*.50f));drawCircle(accent,w*.055f,Offset(w*.50f,h*.61f));drawArc(Color(0xFF111827),20f,140f,false,Offset(w*.42f,h*.57f),Size(w*.16f,h*.13f),style=Stroke(w*.018f))}
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawCharacter(index: Int, p: List<Color>) {
    val w=size.width;val h=size.height;val skin=listOf(Color(0xFFFFD0B5),Color(0xFFD99A72),Color(0xFF8E5A43),Color(0xFFF0B98E))[index%4];val accent=p.last()
    // shoulders
    drawOval(accent.copy(alpha=.85f),Offset(w*.18f,h*.67f),Size(w*.64f,h*.32f))
    drawCircle(skin,w*.19f,Offset(w*.50f,h*.48f))
    when(index%10){
        0->{drawArc(Color(0xFF141526),185f,170f,false,Offset(w*.28f,h*.20f),Size(w*.44f,h*.38f),style=Stroke(w*.10f,cap=StrokeCap.Round));drawRoundRect(accent,Offset(w*.26f,h*.42f),Size(w*.10f,h*.22f),CornerRadius(w*.04f));drawRoundRect(accent,Offset(w*.64f,h*.42f),Size(w*.10f,h*.22f),CornerRadius(w*.04f))}
        1->{val hair=Path().apply{moveTo(w*.31f,h*.39f);cubicTo(w*.28f,h*.18f,w*.72f,h*.13f,w*.70f,h*.43f);cubicTo(w*.61f,h*.29f,w*.48f,h*.32f,w*.31f,h*.39f);close()};drawPath(hair,Color(0xFF24113B))}
        2->{drawRoundRect(Color(0xFF111827),Offset(w*.29f,h*.25f),Size(w*.42f,h*.10f),CornerRadius(w*.05f));drawRoundRect(accent,Offset(w*.53f,h*.20f),Size(w*.27f,h*.08f),CornerRadius(w*.04f))}
        3->{repeat(7){i->drawLine(accent,Offset(w*(.31f+i*.06f),h*.37f),Offset(w*(.34f+i*.05f),h*(.16f+(i%2)*.05f)),w*.035f,cap=StrokeCap.Round)}}
        4->{drawCircle(Color(0xFF101010),w*.055f,Offset(w*.39f,h*.49f));drawCircle(Color(0xFF101010),w*.055f,Offset(w*.61f,h*.49f));drawLine(Color(0xFF101010),Offset(w*.445f,h*.49f),Offset(w*.555f,h*.49f),w*.018f)}
        5->{drawRoundRect(accent,Offset(w*.31f,h*.24f),Size(w*.38f,h*.12f),CornerRadius(w*.05f));drawLine(accent,Offset(w*.33f,h*.32f),Offset(w*.68f,h*.32f),w*.055f)}
        6->{drawArc(Color(0xFF111827),190f,160f,false,Offset(w*.27f,h*.20f),Size(w*.46f,h*.38f),style=Stroke(w*.075f,cap=StrokeCap.Round));drawCircle(accent,w*.07f,Offset(w*.27f,h*.49f));drawCircle(accent,w*.07f,Offset(w*.73f,h*.49f))}
        7->{val halo=Rect(Offset(w*.32f,h*.18f),Size(w*.36f,h*.11f));drawOval(accent,halo.topLeft,halo.size,style=Stroke(w*.025f))}
        8->{drawLine(accent,Offset(w*.31f,h*.30f),Offset(w*.69f,h*.30f),w*.06f,cap=StrokeCap.Round);drawCircle(accent,w*.055f,Offset(w*.50f,h*.21f))}
        else->{drawArc(accent,200f,140f,false,Offset(w*.30f,h*.20f),Size(w*.40f,h*.32f),style=Stroke(w*.08f,cap=StrokeCap.Round))}
    }
    drawCircle(Color(0xFF20212A),w*.018f,Offset(w*.43f,h*.50f));drawCircle(Color(0xFF20212A),w*.018f,Offset(w*.57f,h*.50f));drawArc(Color(0xFF9F5B62),20f,140f,false,Offset(w*.43f,h*.55f),Size(w*.14f,h*.10f),style=Stroke(w*.014f))
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawCosmos(index: Int, p: List<Color>) {
    val w=size.width;val h=size.height;val accent=p.last();val white=Color.White.copy(alpha=.90f)
    repeat(12){i->val x=w*(.12f+((i*37+index*11)%77)/100f);val y=h*(.12f+((i*53+index*7)%77)/100f);drawCircle(white.copy(alpha=.35f+(i%3)*.18f),w*(.007f+(i%2)*.006f),Offset(x,y))}
    when(index%5){
        0->{drawCircle(accent,w*.22f,Offset(w*.50f,h*.51f));drawOval(white.copy(alpha=.62f),Offset(w*.18f,h*.43f),Size(w*.64f,h*.17f),style=Stroke(w*.025f));drawCircle(p[1].copy(alpha=.7f),w*.07f,Offset(w*.44f,h*.44f))}
        1->{val star=Path();val cx=w*.5f;val cy=h*.5f;val outer=w*.27f;val inner=w*.11f;for(i in 0 until 10){val r=if(i%2==0)outer else inner;val a=-PI/2+i*PI/5;val x=cx+cos(a).toFloat()*r;val y=cy+sin(a).toFloat()*r;if(i==0)star.moveTo(x,y)else star.lineTo(x,y)};star.close();drawPath(star,accent);drawCircle(white,w*.05f,Offset(cx,cy))}
        2->{drawCircle(white,w*.24f,Offset(w*.47f,h*.50f));drawCircle(p[0],w*.24f,Offset(w*.57f,h*.43f));drawCircle(accent.copy(alpha=.6f),w*.045f,Offset(w*.39f,h*.48f))}
        3->{val path=Path().apply{moveTo(w*.18f,h*.61f);cubicTo(w*.33f,h*.17f,w*.70f,h*.80f,w*.83f,h*.30f)};drawPath(path,Brush.linearGradient(listOf(p[2],accent,Color.White)),style=Stroke(w*.10f,cap=StrokeCap.Round));drawCircle(white,w*.07f,Offset(w*.64f,h*.47f))}
        else->{drawCircle(accent,w*.10f,Offset(w*.66f,h*.37f));for(i in 0..5){val t=i/5f;drawLine(white.copy(alpha=.18f+t*.12f),Offset(w*(.10f+t*.52f),h*(.78f-t*.36f)),Offset(w*(.20f+t*.52f),h*(.72f-t*.36f)),w*(.025f+t*.01f),cap=StrokeCap.Round)}}
    }
    // Quatro acabamentos adicionais fazem os 20 avatares Diamante realmente distintos,
    // mantendo tudo vetorial e nítido em qualquer densidade de tela.
    when (index / 5) {
        1 -> {
            drawCircle(white.copy(alpha = .42f), w * .33f, Offset(w * .50f, h * .50f), style = Stroke(w * .012f))
            drawCircle(accent, w * .025f, Offset(w * .78f, h * .36f))
        }
        2 -> {
            drawArc(accent.copy(alpha = .75f), 205f, 250f, false, Offset(w * .19f, h * .20f), Size(w * .62f, h * .62f), style = Stroke(w * .022f, cap = StrokeCap.Round))
            drawCircle(white, w * .022f, Offset(w * .24f, h * .29f))
            drawCircle(white.copy(alpha = .65f), w * .015f, Offset(w * .74f, h * .70f))
        }
        3 -> {
            val diamond = Path().apply {
                moveTo(w * .50f, h * .10f); lineTo(w * .58f, h * .22f); lineTo(w * .50f, h * .34f); lineTo(w * .42f, h * .22f); close()
            }
            drawPath(diamond, white.copy(alpha = .78f))
            drawCircle(accent.copy(alpha = .35f), w * .37f, Offset(w * .50f, h * .50f), style = Stroke(w * .014f))
        }
    }
}
