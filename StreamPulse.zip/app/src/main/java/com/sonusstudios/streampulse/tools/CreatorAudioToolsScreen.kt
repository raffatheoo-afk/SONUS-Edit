package com.sonusstudios.streampulse.tools

import com.sonusstudios.streampulse.core.SonusAutoCreateDocument
import com.sonusstudios.streampulse.core.MembershipTier
import com.sonusstudios.streampulse.core.commercialTier
import com.sonusstudios.streampulse.core.SonusStorage
import com.sonusstudios.streampulse.notifications.SonusNotificationCenter
import android.content.Intent
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.roundToInt
import kotlin.math.pow

@Composable
internal fun VideoToAudioTool(
    onBack: () -> Unit,
    membershipTier: MembershipTier,
    unlimited: Boolean,
    coins: Int,
    proUnlocked: Boolean,
    onUnlock24h: (onUnlocked: () -> Unit, onUnavailable: (String) -> Unit) -> Unit,
    onSpend: suspend (Int) -> Boolean,
    onWatchAd: () -> Unit,
    onTrack: (String, Boolean?, Long?) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val commercial = commercialTier(membershipTier)
    val baseLimit = when (commercial) {
        MembershipTier.FREE -> 1
        MembershipTier.PRATA -> 5
        MembershipTier.OURO -> 10
        MembershipTier.DIAMANTE -> Int.MAX_VALUE
        else -> 5
    }
    val addStep = when (commercial) {
        MembershipTier.FREE, MembershipTier.PRATA -> 5
        MembershipTier.OURO -> 10
        MembershipTier.DIAMANTE -> Int.MAX_VALUE
        else -> 5
    }
    val selectionLimit = if (unlimited || commercial == MembershipTier.DIAMANTE) Int.MAX_VALUE else baseLimit + coins.coerceAtLeast(0) * addStep
    var inputs by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var format by remember { mutableStateOf("MP3") }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(0) }
    var message by remember { mutableStateOf<String?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { list ->
        if (list.isNotEmpty()) scope.launch {
            val allowed = if (selectionLimit == Int.MAX_VALUE) list else list.take(selectionLimit)
            val extra = (allowed.size - baseLimit).coerceAtLeast(0)
            val needed = if (extra <= 0 || unlimited || commercial == MembershipTier.DIAMANTE) 0 else (extra + addStep - 1) / addStep
            val paid = needed == 0 || onSpend(needed)
            val selected = if (paid) allowed else list.take(baseLimit)
            if (!paid && commercial == MembershipTier.FREE) onWatchAd()
            selected.forEach { uri -> runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } }
            inputs = selected
            message = when {
                !paid && commercial == MembershipTier.FREE -> "1 vídeo liberado. Assista ao anúncio para ganhar 1 moeda e adicionar +5 ao lote."
                !paid -> "Moedas SONUS insuficientes para ampliar o lote."
                needed > 0 -> "$needed Moeda(s) SONUS usada(s) para ampliar o lote."
                list.size > selected.size -> "${selected.size} vídeo(s) carregado(s). Amplie o lote com Moedas SONUS."
                else -> null
            }
        }
    }

    fun friendlyVideoAudioError(error: Throwable?): String {
        val detail = error?.message.orEmpty()
        return when {
            detail.contains("faixa de áudio", ignoreCase = true) -> detail
            detail.contains("acessar", ignoreCase = true) || detail.contains("permiss", ignoreCase = true) ->
                "O Android não permitiu acessar este vídeo. Selecione o arquivo novamente e tente de novo."
            detail.contains("salvar", ignoreCase = true) || detail.contains("MediaStore", ignoreCase = true) ->
                "Não foi possível salvar o áudio na pasta SONUS/Audio."
            detail.contains("formato", ignoreCase = true) || detail.contains("encoder", ignoreCase = true) ->
                detail.ifBlank { "Este formato de áudio não pôde ser gerado neste aparelho." }
            else -> "Não foi possível extrair o áudio deste vídeo. Tente outro vídeo ou formato de áudio."
        }
    }

    if (busy) SonusExportProgressDialog(progress, "Convertendo vídeo para áudio…", "Vídeo → Áudio")

    CreatorToolScaffold(onBack, "Vídeo → Áudio", "Extraia a faixa sonora de um ou vários vídeos sem alterar os originais.") {
        item {
            FeaturePassCard(
                unlocked = proUnlocked,
                title = "Formatos avançados",
                description = "Moedas SONUS ampliam o lote; a conversão em si não cobra outra moeda."
            ) { unlocked, unavailable -> onUnlock24h(unlocked, unavailable) }
        }
        item {
            CreatorCard("1. Vídeos de origem", Icons.Default.VideoFile) {
                OutlinedButton(onClick = { picker.launch(arrayOf("video/*", "application/octet-stream")) }, modifier = Modifier.fillMaxWidth(), enabled = !busy) {
                    Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(8.dp)); Text(if (inputs.isEmpty()) "Selecionar vídeo(s)" else "Trocar seleção")
                }
                Text(when(commercial) {
                    MembershipTier.FREE -> "1 vídeo • +5 por 1 moeda ou anúncio"
                    MembershipTier.PRATA -> "5 vídeos • +5 por 1 moeda"
                    MembershipTier.OURO -> "10 vídeos • +10 por 1 moeda"
                    MembershipTier.DIAMANTE -> "Lote ilimitado pelo plano"
                    else -> "5 vídeos • +5 por 1 moeda"
                }, style = MaterialTheme.typography.labelSmall)
                inputs.forEachIndexed { i, uri ->
                    Text("${i+1}. ${CreatorAudioEngine.displayName(context, uri)}", maxLines=1, overflow=TextOverflow.Ellipsis, style=MaterialTheme.typography.bodySmall)
                }
            }
        }
        item {
            CreatorCard("2. Formato de áudio", Icons.Default.AudioFile) {
                val basicFormats = listOf("MP3", "M4A", "AAC")
                CreatorFormatSelector(format, if (proUnlocked) CreatorAudioEngine.outputFormats else basicFormats) { format = it }
            }
        }
        item {
            Button(
                onClick = {
                    if (inputs.isEmpty()) return@Button
                    scope.launch {
                        busy = true; progress = 0; message = null
                        val started = System.currentTimeMillis()
                        var ok = 0; var failed = 0
                        inputs.forEachIndexed { index, source ->
                            val baseName = CreatorAudioEngine.displayName(context, source).substringBeforeLast('.', "video").ifBlank { "video" }
                            val displayName = "${baseName}_SONUS.${CreatorAudioEngine.extension(format)}"
                            val result = withContext(Dispatchers.IO) { CreatorAudioEngine.extractAudioToSonus(context, source, displayName, format) }
                            if (result.isSuccess) ok++ else failed++
                            progress = (((index + 1f) / inputs.size.coerceAtLeast(1)) * 100).roundToInt()
                        }
                        busy = false
                        message = when {
                            ok == 0 -> "Nenhum áudio foi extraído."
                            failed == 0 -> "✓ $ok áudio(s) salvo(s) em SONUS/Audio."
                            else -> "$ok concluído(s) • $failed falha(s)."
                        }
                        onTrack("Vídeo → Áudio: lote $ok/${inputs.size}", failed == 0, System.currentTimeMillis() - started)
                    }
                },
                modifier = Modifier.fillMaxWidth().height(50.dp), enabled = inputs.isNotEmpty() && !busy,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E9E55), contentColor = Color.White)
            ) {
                Icon(Icons.Default.Transform, null); Spacer(Modifier.width(8.dp)); Text(if (busy) "Convertendo…" else "Converter ${inputs.size} vídeo(s)")
            }
        }
        messageItem(message)
    }
}

@Composable
internal fun MergeAudioTool(
    onBack: () -> Unit,
    membershipTier: MembershipTier,
    coins: Int,
    unlimited: Boolean,
    onSpend: suspend (Int) -> Boolean,
    onWatchAd: () -> Unit,
    onTrack: (String, Boolean?, Long?) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val proUsage = remember { SonusProUsageStats(context) }
    val commercial = commercialTier(membershipTier)
    val batchUnlimited = unlimited || commercial == MembershipTier.DIAMANTE
    var unlockedBlocks by remember { mutableIntStateOf(if (batchUnlimited) Int.MAX_VALUE else 0) }
    var awaitingAdUnlock by remember { mutableStateOf(false) }
    var coinsBeforeAd by remember { mutableIntStateOf(coins) }
    var inputs by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var stagedInputs by remember { mutableStateOf<List<Pair<String,String>>>(emptyList()) }
    var format by remember { mutableStateOf("MP3") }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(0) }
    var message by remember { mutableStateOf<String?>(null) }
    var showCancel by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { list ->
        if (list.isNotEmpty()) scope.launch {
            val selected = list.take(100)
            selected.forEach { uri -> runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } }
            val staged = CreatorAudioEngine.stageMergeAudioInputs(context, selected)
            if (staged.isSuccess) {
                inputs = selected
                stagedInputs = staged.getOrThrow()
                message = if (batchUnlimited) "${selected.size} música(s) • acesso ilimitado." else "${selected.size} música(s) • libere 1 bloco a cada 5 arquivos."
            } else {
                inputs = emptyList(); stagedInputs = emptyList()
                message = "Falha: ${staged.exceptionOrNull()?.message ?: "não foi possível preparar as músicas"}"
            }
        }
    }
    val requiredBlocks = if (inputs.isEmpty()) 0 else (inputs.size + 4) / 5
    val accessReady = batchUnlimited || unlockedBlocks >= requiredBlocks
    LaunchedEffect(coins, awaitingAdUnlock) {
        if (awaitingAdUnlock && coins > coinsBeforeAd) {
            if (onSpend(1)) {
                unlockedBlocks += 1
                proUsage.recordUnlock("Mesclar Áudio", viaAd = true)
                message = "Anúncio concluído • +5 arquivos liberados para esta operação."
            }
            awaitingAdUnlock = false
        }
    }
    LaunchedEffect(awaitingAdUnlock) {
        if (awaitingAdUnlock) {
            delay(15_000L)
            if (awaitingAdUnlock) { awaitingAdUnlock = false; message = "Anúncio indisponível no momento. Tente novamente." }
        }
    }
    fun unlockNextBlock() {
        if (batchUnlimited || unlockedBlocks >= requiredBlocks) return
        if (coins > 0) {
            scope.launch {
                if (onSpend(1)) { unlockedBlocks += 1; proUsage.recordUnlock("Mesclar Áudio", viaAd = false); message = "1 Moeda SONUS • +5 arquivos liberados." }
                else message = "Não foi possível usar a Moeda SONUS."
            }
        } else {
            coinsBeforeAd = coins
            awaitingAdUnlock = true
            onWatchAd()
        }
    }
    val saver = rememberLauncherForActivityResult(SonusAutoCreateDocument("audio/mpeg")) { out ->
        if (out == null || stagedInputs.size < 2) return@rememberLauncherForActivityResult
        scope.launch {
            busy = true; progress = 1; message = null
            val started = System.currentTimeMillis()
            val result = withContext(Dispatchers.IO) {
                CreatorAudioEngine.mergeAudioStaged(context, stagedInputs.map { it.second }, out, format, onProgress = { p -> scope.launch { progress = p } })
            }
            busy = false
            if (result.isFailure) runCatching { SonusStorage.abort(context, out) }
            if (result.isSuccess) { SonusNotificationCenter.recordPremiumUse(context, "Mesclar Áudio"); proUsage.recordOperation("Mesclar Áudio", inputs.size) }
            message = if (result.isFailure) "Falha: ${result.exceptionOrNull()?.message ?: "não foi possível mesclar os arquivos"}" else "✓ Concluído • ${inputs.size} músicas mescladas."
            if (System.currentTimeMillis() - started >= 120_000L) {
                SonusNotificationCenter.add(context, "SONUS • Mesclagem concluída ✓", "Seu arquivo de áudio está pronto.", "FERRAMENTAS", importantExternal = true)
            }
            onTrack("Mesclar Áudio: ${inputs.size} arquivos", result.isSuccess, System.currentTimeMillis() - started)
            if (!batchUnlimited) unlockedBlocks = 0
        }
    }
    if (showCancel) {
        AlertDialog(
            onDismissRequest = { showCancel = false },
            title = { Text("Cancelar mesclagem?") },
            text = { Text("O processamento atual será interrompido e nenhum arquivo incompleto será mantido.") },
            confirmButton = {
                TextButton(onClick = { showCancel = false; CreatorAudioEngine.cancelActiveMerge() }) { Text("Cancelar", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { showCancel = false }) { Text("Continuar") } }
        )
    }
    if (busy) SonusExportProgressDialog(progress, "Mesclando ${inputs.size} músicas…", "Mesclar Áudio", onCancel = { CreatorAudioEngine.cancelActiveMerge() })

    CreatorToolScaffold(onBack, "Mesclar Áudio", "Junte músicas na ordem que você escolher.") {
        item {
            CreatorCard("Músicas", Icons.Default.QueueMusic) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button({ picker.launch(arrayOf("audio/*", "application/octet-stream")) }, enabled = !busy, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.LibraryAdd, null); Spacer(Modifier.width(6.dp)); Text("Adicionar músicas")
                    }
                    Spacer(Modifier.width(8.dp))
                    AssistChip(onClick = {}, label = { Text(if (batchUnlimited) "∞" else "${unlockedBlocks*5}/${requiredBlocks*5}") })
                }
                Text(if(batchUnlimited) "PRO • lote ilimitado pelo plano" else "PRO • cada bloco de até 5 músicas = 1 moeda; sem moedas, 1 anúncio recompensado.", style = MaterialTheme.typography.labelSmall)
                if (!batchUnlimited && inputs.isNotEmpty() && !accessReady) {
                    Button(onClick={unlockNextBlock()}, enabled=!awaitingAdUnlock, modifier=Modifier.fillMaxWidth()) {
                        Icon(if(coins>0) Icons.Default.MonetizationOn else Icons.Default.SmartDisplay,null);Spacer(Modifier.width(6.dp))
                        Text(if(coins>0) "Usar 1 moeda • liberar +5" else if(awaitingAdUnlock) "Aguardando anúncio…" else "Assistir anúncio • liberar +5")
                    }
                    Text("Liberados: $unlockedBlocks/$requiredBlocks bloco(s)",style=MaterialTheme.typography.labelSmall)
                }
                inputs.forEachIndexed { index, uri ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("${index+1}.", fontWeight=FontWeight.Bold)
                        Spacer(Modifier.width(6.dp))
                        Text(stagedInputs.getOrNull(index)?.first ?: "Música ${index+1}", Modifier.weight(1f), maxLines=1, overflow=TextOverflow.Ellipsis)
                        IconButton({ if(index>0) { inputs=inputs.toMutableList().also{val x=it.removeAt(index);it.add(index-1,x)}; stagedInputs=stagedInputs.toMutableList().also{val x=it.removeAt(index);it.add(index-1,x)} } }, enabled=index>0&&!busy){Icon(Icons.Default.KeyboardArrowUp,null)}
                        IconButton({ if(index<inputs.lastIndex) { inputs=inputs.toMutableList().also{val x=it.removeAt(index);it.add(index+1,x)}; stagedInputs=stagedInputs.toMutableList().also{val x=it.removeAt(index);it.add(index+1,x)} } }, enabled=index<inputs.lastIndex&&!busy){Icon(Icons.Default.KeyboardArrowDown,null)}
                    }
                }
            }
        }
        item { CreatorCard("Saída", Icons.Default.AudioFile) { CreatorFormatSelector(format) { format=it } } }
        item {
            Button(
                { saver.launch("Mesclado_SONUS.${CreatorAudioEngine.extension(format)}") },
                enabled=inputs.size>=2&&!busy&&accessReady,
                modifier=Modifier.fillMaxWidth().height(50.dp),
                colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF1E9E55),contentColor=Color.White)
            ){Icon(Icons.Default.MergeType,null);Spacer(Modifier.width(7.dp));Text("Mesclar")}
        }
        messageItem(message)
    }
}

@Composable
internal fun MergeVideoTool(
    onBack: () -> Unit,
    membershipTier: MembershipTier,
    coins: Int,
    unlimited: Boolean,
    onSpend: suspend (Int) -> Boolean,
    onWatchAd: () -> Unit,
    onTrack: (String, Boolean?, Long?) -> Unit
) {
    val context=LocalContext.current
    val scope=rememberCoroutineScope()
    val proUsage=remember{SonusProUsageStats(context)}
    val commercial= commercialTier(membershipTier)
    val batchUnlimited = unlimited || commercial == MembershipTier.DIAMANTE
    var unlockedBlocks by remember { mutableIntStateOf(if(batchUnlimited) Int.MAX_VALUE else 0) }
    var awaitingAdUnlock by remember { mutableStateOf(false) }
    var coinsBeforeAd by remember { mutableIntStateOf(coins) }
    var inputs by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var quality by remember { mutableStateOf("1080p") }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(0) }
    var message by remember { mutableStateOf<String?>(null) }
    var showCancel by remember { mutableStateOf(false) }
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()){ list->
        if(list.isNotEmpty()) {
            val selected=list.take(100)
            selected.forEach { uri -> runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } }
            inputs=selected
            message=if(batchUnlimited)"${selected.size} vídeo(s) • acesso ilimitado." else "${selected.size} vídeo(s) • libere 1 bloco a cada 5 arquivos."
        }
    }
    val requiredBlocks = if(inputs.isEmpty())0 else (inputs.size+4)/5
    val accessReady = batchUnlimited || unlockedBlocks>=requiredBlocks
    LaunchedEffect(coins,awaitingAdUnlock){
        if(awaitingAdUnlock && coins>coinsBeforeAd){
            if(onSpend(1)){unlockedBlocks+=1;proUsage.recordUnlock("Mesclar Vídeo",viaAd=true);message="Anúncio concluído • +5 arquivos liberados para esta operação."}
            awaitingAdUnlock=false
        }
    }
    LaunchedEffect(awaitingAdUnlock){if(awaitingAdUnlock){delay(15_000L);if(awaitingAdUnlock){awaitingAdUnlock=false;message="Anúncio indisponível no momento. Tente novamente."}}}
    fun unlockNextBlock(){
        if(batchUnlimited||unlockedBlocks>=requiredBlocks)return
        if(coins>0)scope.launch{if(onSpend(1)){unlockedBlocks+=1;proUsage.recordUnlock("Mesclar Vídeo",viaAd=false);message="1 Moeda SONUS • +5 arquivos liberados."}else message="Não foi possível usar a Moeda SONUS."}
        else{coinsBeforeAd=coins;awaitingAdUnlock=true;onWatchAd()}
    }
    if(showCancel){
        AlertDialog(
            onDismissRequest={showCancel=false},
            title={Text("Cancelar mesclagem?")},
            text={Text("O processamento atual será interrompido e nenhum vídeo incompleto será mantido.")},
            confirmButton={TextButton(onClick={showCancel=false;CreatorAudioEngine.cancelActiveMerge()}){Text("Cancelar",color=MaterialTheme.colorScheme.error)}},
            dismissButton={TextButton(onClick={showCancel=false}){Text("Continuar")}}
        )
    }

    if (busy) SonusExportProgressDialog(progress, "Mesclando ${inputs.size} vídeos…", "Mesclar Vídeo", onCancel = { CreatorAudioEngine.cancelActiveMerge() })

    CreatorToolScaffold(onBack,"Mesclar Vídeo","Vídeos em sequência • MP4 • sem configurações desnecessárias.") {
        item {
            CreatorCard("Vídeos",Icons.Default.VideoLibrary) {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Button({picker.launch(arrayOf("video/*"))},enabled=!busy,modifier=Modifier.weight(1f)){Icon(Icons.Default.VideoLibrary,null);Spacer(Modifier.width(6.dp));Text("Adicionar vídeos")}
                    Spacer(Modifier.width(8.dp));AssistChip(onClick={},label={Text(if(batchUnlimited)"∞" else "${unlockedBlocks*5}/${requiredBlocks*5}")})
                }
                Text(if(batchUnlimited)"PRO • lote ilimitado pelo plano" else "PRO • cada bloco de até 5 vídeos = 1 moeda; sem moedas, 1 anúncio recompensado.",style=MaterialTheme.typography.labelSmall)
                if(!batchUnlimited&&inputs.isNotEmpty()&&!accessReady){
                    Button(onClick={unlockNextBlock()},enabled=!awaitingAdUnlock,modifier=Modifier.fillMaxWidth()){
                        Icon(if(coins>0)Icons.Default.MonetizationOn else Icons.Default.SmartDisplay,null);Spacer(Modifier.width(6.dp));Text(if(coins>0)"Usar 1 moeda • liberar +5" else if(awaitingAdUnlock)"Aguardando anúncio…" else "Assistir anúncio • liberar +5")
                    }
                    Text("Liberados: $unlockedBlocks/$requiredBlocks bloco(s)",style=MaterialTheme.typography.labelSmall)
                }
                inputs.forEachIndexed { index,uri->
                    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
                        Text("${index+1}.",fontWeight=FontWeight.Bold);Spacer(Modifier.width(6.dp))
                        Text(CreatorAudioEngine.displayName(context,uri),Modifier.weight(1f),maxLines=1,overflow=TextOverflow.Ellipsis)
                        IconButton({if(index>0)inputs=inputs.toMutableList().also{val x=it.removeAt(index);it.add(index-1,x)}},enabled=index>0&&!busy){Icon(Icons.Default.KeyboardArrowUp,null)}
                        IconButton({if(index<inputs.lastIndex)inputs=inputs.toMutableList().also{val x=it.removeAt(index);it.add(index+1,x)}},enabled=index<inputs.lastIndex&&!busy){Icon(Icons.Default.KeyboardArrowDown,null)}
                    }
                }
            }
        }
        item {
            CreatorCard("Saída",Icons.Default.HighQuality) {
                Text("MP4",fontWeight=FontWeight.Bold)
                SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                    listOf("480p","720p","1080p","Original").forEachIndexed { i,q->
                        SegmentedButton(selected=quality==q,onClick={quality=q},shape=SegmentedButtonDefaults.itemShape(i,4)){Text(q,fontSize=11.sp)}
                    }
                }
                Text("Destino padrão: Filmes/SONUS",style=MaterialTheme.typography.labelSmall)
            }
        }
        item {
            Button(
                onClick={
                    if(inputs.size<2)return@Button
                    scope.launch {
                        busy=true;progress=1;message=null;val started=System.currentTimeMillis()
                        val result=withContext(Dispatchers.IO){CreatorAudioEngine.mergeVideoToSonus(context,inputs,"Mesclado_SONUS_${System.currentTimeMillis()}.mp4",quality){p->scope.launch{progress=p}}}
                        busy=false
                        val usageOk=true
                        if(result.isSuccess){SonusNotificationCenter.recordPremiumUse(context,"Mesclar Vídeo");proUsage.recordOperation("Mesclar Vídeo",inputs.size)}
                        message=if(result.isSuccess)"✓ Concluído • vídeo salvo em MP4." else "Falha: ${result.exceptionOrNull()?.message ?: "não foi possível mesclar os vídeos"}"
                        if(System.currentTimeMillis()-started>=120_000L)SonusNotificationCenter.add(context,"SONUS • Mesclagem concluída ✓","Seu vídeo está pronto.","FERRAMENTAS",importantExternal=true)
                        onTrack("Mesclar Vídeo: ${inputs.size} arquivos",result.isSuccess,System.currentTimeMillis()-started)
                        if(!batchUnlimited)unlockedBlocks=0
                    }
                },
                enabled=inputs.size>=2&&!busy&&accessReady,
                modifier=Modifier.fillMaxWidth().height(50.dp),
                colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF1E9E55),contentColor=Color.White)
            ){Icon(Icons.Default.MergeType,null);Spacer(Modifier.width(7.dp));Text("Mesclar")}
        }
        messageItem(message)
    }
}

private fun mergeLimit(tier: MembershipTier): Int = when(commercialTier(tier)){
    MembershipTier.FREE -> 5
    MembershipTier.PRATA -> 10
    MembershipTier.OURO -> 20
    MembershipTier.DIAMANTE -> Int.MAX_VALUE
    else -> 10
}

@Composable
private fun SonusProgressCard(progress:Int,label:String){
    val p=progress.coerceIn(0,100)
    Surface(shape=RoundedCornerShape(16.dp),color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.55f),border=BorderStroke(1.dp,MaterialTheme.colorScheme.primary.copy(alpha=.28f))){
        Column(Modifier.fillMaxWidth().padding(12.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(label,fontWeight=FontWeight.Bold);Text("$p%",fontWeight=FontWeight.Black,color=MaterialTheme.colorScheme.primary)}
            LinearProgressIndicator(progress={p/100f},modifier=Modifier.fillMaxWidth().height(9.dp),strokeCap=androidx.compose.ui.graphics.StrokeCap.Round)
        }
    }
}


@Composable
internal fun PitchShiftTool(
    onBack: () -> Unit,
    unlimited: Boolean,
    coins: Int,
    proUnlocked: Boolean,
    onUnlock24h: (onUnlocked: () -> Unit, onUnavailable: (String) -> Unit) -> Unit,
    onSpend: suspend (Int) -> Boolean,
    onTrack: (String, Boolean?, Long?) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("pulse_pitch_tool_v2", android.content.Context.MODE_PRIVATE) }
    var input by remember { mutableStateOf<Uri?>(null) }
    var semitones by remember { mutableIntStateOf(0) }
    var cents by remember { mutableIntStateOf(0) }
    var speed by remember { mutableFloatStateOf(1f) }
    var mode by remember { mutableStateOf("Natural") }
    var format by remember { mutableStateOf("MP3") }
    var busy by remember { mutableStateOf(false) }
    var previewBusy by remember { mutableStateOf(false) }
    var previewPlayer by remember { mutableStateOf<MediaPlayer?>(null) }
    var previewPlaying by remember { mutableStateOf(false) }
    var positionMs by remember { mutableLongStateOf(0L) }
    var durationMs by remember { mutableLongStateOf(0L) }
    var loopA by remember { mutableStateOf<Long?>(null) }
    var loopB by remember { mutableStateOf<Long?>(null) }
    var message by remember { mutableStateOf<String?>(null) }

    fun applyParams(player: MediaPlayer) {
        val total = (semitones + cents / 100.0).coerceIn(-12.0, 12.0)
        val factor = 2.0.pow(total / 12.0).toFloat()
        runCatching { player.playbackParams = PlaybackParams().setSpeed(speed).setPitch(factor) }
    }
    fun releasePreview() {
        runCatching { previewPlayer?.release() }
        previewPlayer = null; previewPlaying = false; positionMs = 0L; durationMs = 0L
    }
    DisposableEffect(Unit) { onDispose { releasePreview() } }
    LaunchedEffect(semitones, cents, speed, previewPlayer) { previewPlayer?.let(::applyParams) }
    LaunchedEffect(previewPlaying, loopA, loopB) {
        while (previewPlaying) {
            delay(120)
            previewPlayer?.let { p ->
                positionMs = runCatching { p.currentPosition.toLong() }.getOrDefault(positionMs)
                durationMs = runCatching { p.duration.toLong() }.getOrDefault(durationMs)
                val a = loopA; val b = loopB
                if (a != null && b != null && b > a && positionMs >= b) runCatching { p.seekTo(a.toInt()) }
            }
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            releasePreview(); input = it; message = null
            val key = CreatorAudioEngine.displayName(context,it)
            semitones = prefs.getInt("fav_${key.hashCode()}",0).coerceIn(-12,12)
        }
    }
    val saver = rememberLauncherForActivityResult(SonusAutoCreateDocument("audio/mpeg")) { out ->
        val source = input ?: return@rememberLauncherForActivityResult
        out ?: return@rememberLauncherForActivityResult
        scope.launch {
            busy = true; val started = System.currentTimeMillis()
            val result = withContext(Dispatchers.IO) { CreatorAudioEngine.shiftPitch(context, source, out, format, semitones, cents) }
            busy = false
            message = if (!result.isSuccess) "Falha: ${result.exceptionOrNull()?.message}"
            else "Nova versão salva • ${signed(semitones)} semitons."
            onTrack("Alterar tom: ${signed(semitones)} semitom(ns) ${signed(cents)} cent(s)", result.isSuccess, System.currentTimeMillis() - started)
        }
    }

    CreatorToolScaffold(onBack, "Alterar Tom Pro", "Pitch musical, cents, velocidade independente e A/B em uma interface SONUS.") {
        item {
            FeaturePassCard(
                unlocked = proUnlocked,
                title = "Alterar Tom Pro",
                description = "Semitons básicos permanecem livres. Cents, memória de tom e controles avançados seguem as regras do plano atual."
            ) { unlocked, unavailable -> onUnlock24h(unlocked, unavailable) }
        }
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF071C2C)),
                border = BorderStroke(1.dp, Color(0xFF27C7FF).copy(alpha=.42f))
            ) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.GraphicEq,null,tint=Color(0xFF42D9FF))
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Text(input?.let { CreatorAudioEngine.displayName(context,it) } ?: "Nenhuma música selecionada",fontWeight=FontWeight.Black,maxLines=1,overflow=TextOverflow.Ellipsis)
                            Text("${signed(semitones)} semitons • ${signed(cents)} cents • ${String.format("%.2fx",speed)}",style=MaterialTheme.typography.bodySmall,color=Color.White.copy(alpha=.65f))
                        }
                        IconButton(onClick={ picker.launch(arrayOf("audio/*")) }) { Icon(Icons.Default.FolderOpen,"Selecionar",tint=Color.White) }
                    }
                    if (input != null) {
                        LinearProgressIndicator(
                            progress = { if(durationMs>0) (positionMs.toFloat()/durationMs).coerceIn(0f,1f) else 0f },
                            modifier=Modifier.fillMaxWidth(),
                            color=Color(0xFF42D9FF),
                            trackColor=Color.White.copy(alpha=.10f)
                        )
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                            Text(formatCreatorClock(positionMs),style=MaterialTheme.typography.labelSmall)
                            Text(formatCreatorClock(durationMs),style=MaterialTheme.typography.labelSmall)
                        }
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly,verticalAlignment=Alignment.CenterVertically) {
                            IconButton(onClick={ previewPlayer?.let{runCatching{it.seekTo((it.currentPosition-10000).coerceAtLeast(0))}} }) { Icon(Icons.Default.Replay10,null) }
                            FilledIconButton(onClick={
                                val source=input ?: return@FilledIconButton
                                val p=previewPlayer
                                if(p!=null){
                                    runCatching{if(p.isPlaying){p.pause();previewPlaying=false}else{applyParams(p);p.start();previewPlaying=true}}
                                } else {
                                    previewBusy=true
                                    runCatching {
                                        MediaPlayer().also { mp ->
                                            previewPlayer=mp; mp.setDataSource(context,source)
                                            mp.setOnPreparedListener { ready -> durationMs=ready.duration.toLong();applyParams(ready);ready.start();previewBusy=false;previewPlaying=true }
                                            mp.setOnCompletionListener { previewPlaying=false;positionMs=durationMs }
                                            mp.setOnErrorListener { _,_,_->previewBusy=false;previewPlaying=false;true }
                                            mp.prepareAsync()
                                        }
                                    }.onFailure { previewBusy=false;message="Player: ${it.message}" }
                                }
                            }, enabled=!previewBusy) { Icon(if(previewPlaying)Icons.Default.Pause else Icons.Default.PlayArrow,null) }
                            IconButton(onClick={ previewPlayer?.let{runCatching{it.seekTo((it.currentPosition+10000).coerceAtMost(it.duration))}} }) { Icon(Icons.Default.Forward10,null) }
                        }
                    }
                }
            }
        }
        item { CreatorCard("Transposição musical", Icons.Default.Tune) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = { semitones = (semitones - 1).coerceAtLeast(-12) }) { Text("−1") }
                Text("${signed(semitones)} semitons", modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center, fontWeight = FontWeight.Black, fontSize = 20.sp)
                OutlinedButton(onClick = { semitones = (semitones + 1).coerceAtMost(12) }) { Text("+1") }
            }
            Slider(semitones.toFloat(), { semitones = it.roundToInt() }, valueRange = -12f..12f, steps = 23)
            LazyRow(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                items(listOf(-3,-2,-1,0,1,2,3)) { value -> AssistChip(onClick={semitones=value},label={Text(signed(value))}) }
            }
            Text("Ajuste fino: ${signed(cents)} cents", fontWeight = FontWeight.SemiBold)
            Slider(cents.toFloat(), { cents = it.roundToInt() }, valueRange = -100f..100f, steps = 39, enabled = proUnlocked)
            if(kotlin.math.abs(semitones)>=7) Text("⚠ Alterações grandes podem introduzir artefatos. Prefira exportação de qualidade alta.",style=MaterialTheme.typography.bodySmall,color=Color(0xFFFFB86B))
        } }
        item { CreatorCard("Performance e estudo", Icons.Default.Speed) {
            Text("Modo",fontWeight=FontWeight.Bold)
            Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                listOf("Natural","Vocal","Instrumental").forEach { m -> FilterChip(mode==m,{mode=m},{Text(m)}) }
            }
            Text("Velocidade ${String.format("%.2fx",speed)} • independente do tom",fontWeight=FontWeight.SemiBold)
            Slider(speed,{speed=it},valueRange=.5f..2f,steps=14,enabled=proUnlocked)
            Row(horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                OutlinedButton(onClick={ loopA=positionMs },enabled=previewPlayer!=null,modifier=Modifier.weight(1f)){Text("Marcar A")}
                OutlinedButton(onClick={ loopB=positionMs },enabled=loopA!=null&&previewPlayer!=null,modifier=Modifier.weight(1f)){Text("Marcar B")}
                IconButton(onClick={loopA=null;loopB=null}){Icon(Icons.Default.Clear,null)}
            }
            input?.let { uri ->
                Button(
                    onClick={ val key=CreatorAudioEngine.displayName(context,uri);prefs.edit().putInt("fav_${key.hashCode()}",semitones).apply();message="✓ Tom favorito salvo: ${signed(semitones)}" },
                    enabled=proUnlocked,
                    modifier=Modifier.fillMaxWidth()
                ){Icon(Icons.Default.Favorite,null);Spacer(Modifier.width(7.dp));Text("Salvar como meu tom")}
            }
        } }
        item { CreatorCard("Exportação", Icons.Default.SaveAlt) { CreatorFormatSelector(format) { format = it } } }
        item { Button(onClick = { saver.launch("Tom_${signedFile(semitones)}_${input?.let { CreatorAudioEngine.displayName(context, it).substringBeforeLast('.') } ?: "musica"}.${CreatorAudioEngine.extension(format)}") }, enabled = input != null && !busy, modifier = Modifier.fillMaxWidth().height(54.dp)) { Icon(Icons.Default.Save, null); Spacer(Modifier.width(8.dp)); Text(if (busy) "Processando…" else "Salvar nova versão") } }
        busyItem(busy); messageItem(message)
    }
}



@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun VocalRemoverTool(
    onBack: () -> Unit,
    unlimited: Boolean,
    coins: Int,
    proUnlocked: Boolean,
    onUnlock24h: (onUnlocked: () -> Unit, onUnavailable: (String) -> Unit) -> Unit,
    onSpend: suspend (Int) -> Boolean,
    onTrack: (String, Boolean?, Long?) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf<Uri?>(null) }
    var output by remember { mutableStateOf(VocalOutput.INSTRUMENTAL) }
    var separation by remember { mutableStateOf(VocalSeparationStrength.BALANCED) }
    var denoise by remember { mutableStateOf(DenoiseStrength.MEDIUM) }
    val pulseLift = false
    var format by remember { mutableStateOf("WAV") }
    var busy by remember { mutableStateOf(false) }
    var previewBusy by remember { mutableStateOf(false) }
    var previewFile by remember { mutableStateOf<File?>(null) }
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    var playing by remember { mutableStateOf(false) }
    var playerMode by remember { mutableStateOf("Original") }
    var positionMs by remember { mutableLongStateOf(0L) }
    var durationMs by remember { mutableLongStateOf(0L) }
    var message by remember { mutableStateOf<String?>(null) }

    fun releasePlayer() { runCatching { player?.release() }; player=null;playing=false }
    fun playSource(mode:String, keepPosition:Boolean=true) {
        val source=input ?: return
        val seek=if(keepPosition) positionMs else 0L
        releasePlayer()
        runCatching {
            MediaPlayer().also { mp ->
                player=mp
                if(mode=="Original") mp.setDataSource(context,source)
                else {
                    val f=previewFile ?: return@also
                    mp.setDataSource(f.absolutePath)
                }
                mp.setOnPreparedListener { ready ->
                    durationMs=ready.duration.toLong()
                    if(seek>0) ready.seekTo(seek.coerceAtMost(durationMs-1).toInt())
                    ready.start();playing=true;playerMode=mode
                }
                mp.setOnCompletionListener { playing=false;positionMs=durationMs }
                mp.prepareAsync()
            }
        }.onFailure { message="Player: ${it.message}" }
    }
    DisposableEffect(Unit) { onDispose { releasePlayer(); previewFile?.delete() } }
    LaunchedEffect(playing) {
        while(playing){delay(150);player?.let{positionMs=runCatching{it.currentPosition.toLong()}.getOrDefault(positionMs);durationMs=runCatching{it.duration.toLong()}.getOrDefault(durationMs)}}
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { releasePlayer(); previewFile?.delete(); previewFile=null; input=it;positionMs=0L;durationMs=0L;message=null }
    }
    val saver = rememberLauncherForActivityResult(SonusAutoCreateDocument("audio/mpeg")) { outUri ->
        val source = input ?: return@rememberLauncherForActivityResult
        outUri ?: return@rememberLauncherForActivityResult
        scope.launch {
            busy = true; val started = System.currentTimeMillis()
            val result = withContext(Dispatchers.IO) { CreatorAudioEngine.separateCenter(context, source, outUri, output, format, denoise, pulseLift, separation) }
            busy = false
            val label = if (output == VocalOutput.INSTRUMENTAL) "Instrumental" else "Voz"
            message = if (!result.isSuccess) "Falha: ${result.exceptionOrNull()?.message}"
            else if (unlimited) {
                SonusNotificationCenter.recordPremiumUse(context, "Removedor Vocal Pro")
                "$label salvo como nova cópia."
            } else if (onSpend(1)) {
                SonusNotificationCenter.recordPremiumUse(context, "Removedor Vocal Pro")
                "$label salvo como nova cópia."
            } else "$label salvo, mas não foi possível descontar a Moeda SONUS."
            SonusNotificationCenter.add(
                context,
                if (result.isSuccess) "Removedor Vocal concluído" else "Falha no Removedor Vocal",
                if (result.isSuccess) "$label salvo como uma nova cópia." else "O processamento não pôde ser concluído.",
                "FERRAMENTAS",
                importantExternal = false
            )
            onTrack("Removedor Vocal: $label • ${separation.name}", result.isSuccess, System.currentTimeMillis() - started)
        }
    }

    CreatorToolScaffold(onBack, "Removedor Vocal Pro", "Separação local, limpeza adaptativa e player A/B no padrão SONUS.") {
        item {
            FeaturePassCard(
                unlocked = proUnlocked,
                title = "Removedor Vocal",
                description = "Ouro ou superior. No FREE, os Moedas SONUS servem para testar o recurso."
            ) { unlocked, unavailable -> onUnlock24h(unlocked, unavailable) }
        }
        item {
            Card(
                colors=CardDefaults.cardColors(containerColor=Color(0xFF1D1029)),
                border=BorderStroke(1.dp,Color(0xFFC450E5).copy(alpha=.40f))
            ) {
                Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically){
                        Icon(Icons.Default.SpatialAudioOff,null,tint=Color(0xFFE47BFF))
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)){
                            Text(input?.let{CreatorAudioEngine.displayName(context,it)}?:"Selecione uma música",fontWeight=FontWeight.Black,maxLines=1,overflow=TextOverflow.Ellipsis)
                            Text("$playerMode • ${if(playing)"reproduzindo" else "pausado"}",style=MaterialTheme.typography.bodySmall,color=Color.White.copy(alpha=.65f))
                        }
                        IconButton(onClick={picker.launch(arrayOf("audio/*"))}){Icon(Icons.Default.FolderOpen,null)}
                    }
                    LinearProgressIndicator(
                        progress={if(durationMs>0)(positionMs.toFloat()/durationMs).coerceIn(0f,1f) else 0f},
                        modifier=Modifier.fillMaxWidth(),
                        color=Color(0xFFE47BFF),
                        trackColor=Color.White.copy(alpha=.10f)
                    )
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(formatCreatorClock(positionMs),style=MaterialTheme.typography.labelSmall);Text(formatCreatorClock(durationMs),style=MaterialTheme.typography.labelSmall)}
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly,verticalAlignment=Alignment.CenterVertically){
                        IconButton(onClick={player?.let{runCatching{it.seekTo((it.currentPosition-10000).coerceAtLeast(0))}}},enabled=player!=null){Icon(Icons.Default.Replay10,null)}
                        FilledIconButton(onClick={
                            val p=player
                            if(p==null) playSource(if(previewFile!=null)playerMode else "Original",false)
                            else runCatching{if(p.isPlaying){p.pause();playing=false}else{p.start();playing=true}}
                        },enabled=input!=null){Icon(if(playing)Icons.Default.Pause else Icons.Default.PlayArrow,null)}
                        IconButton(onClick={player?.let{runCatching{it.seekTo((it.currentPosition+10000).coerceAtMost(it.duration))}}},enabled=player!=null){Icon(Icons.Default.Forward10,null)}
                    }
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){
                        FilterChip(playerMode=="Original",{playerMode="Original";playSource("Original")},{Text("Original")},modifier=Modifier.weight(1f))
                        FilterChip(playerMode=="Processado",{if(previewFile!=null){playerMode="Processado";playSource("Processado")}},{Text("Processado")},enabled=previewFile!=null,modifier=Modifier.weight(1f))
                    }
                }
            }
        }
        item { CreatorCard("Separação", Icons.Default.CallSplit) {
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                listOf(VocalOutput.INSTRUMENTAL,VocalOutput.VOCAL).forEachIndexed{i,item->
                    SegmentedButton(output==item,{output=item},shape=SegmentedButtonDefaults.itemShape(i,2)){Text(if(item==VocalOutput.INSTRUMENTAL)"Instrumental" else "Voz")}
                }
            }
            Text("Intensidade",fontWeight=FontWeight.Bold)
            Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                listOf(
                    VocalSeparationStrength.NATURAL to "Natural",
                    VocalSeparationStrength.BALANCED to "Equilibrada",
                    VocalSeparationStrength.STRONG to "Forte"
                ).forEach{(value,label)->FilterChip(separation==value,{separation=value},{Text(label)})}
            }
            Text("O modo Natural preserva mais instrumentos; Forte prioriza reduzir a voz central.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.63f))
        } }
        item { CreatorCard("Limpeza e finalização", Icons.Default.AutoFixHigh) {
            Text("Redução de ruído / resíduos",fontWeight=FontWeight.Bold)
            Row(horizontalArrangement=Arrangement.spacedBy(5.dp),modifier=Modifier.fillMaxWidth()) {
                DenoiseStrength.entries.forEach{d->FilterChip(denoise==d,{denoise=d},{Text(denoiseLabel(d))})}
            }
            Button(onClick={
                val source=input ?: return@Button
                scope.launch{
                    previewBusy=true; releasePlayer(); previewFile?.delete()
                    val result=withContext(Dispatchers.IO){CreatorAudioEngine.buildVocalPreview(context,source,output,denoise,pulseLift,separation,seconds=0)}
                    previewBusy=false
                    result.onSuccess{f->previewFile=f;playerMode="Processado";positionMs=0L;playSource("Processado",false)}
                        .onFailure{message="Prévia completa: ${it.message}"}
                }
            },modifier=Modifier.fillMaxWidth(),enabled=input!=null&&!previewBusy&&proUnlocked){
                Icon(Icons.Default.PlayCircle,null);Spacer(Modifier.width(8.dp));Text(if(previewBusy)"Processando faixa completa…" else "Gerar e ouvir resultado completo")
            }
        } }
        item { CreatorCard("Saída", Icons.Default.AudioFile) { CreatorFormatSelector(format) { format=it } } }
        item { Button(onClick={saver.launch("${if(output==VocalOutput.INSTRUMENTAL)"Instrumental" else "Voz"}_SONUS.${CreatorAudioEngine.extension(format)}")},enabled=input!=null&&!busy&&proUnlocked&&(unlimited||coins>0),modifier=Modifier.fillMaxWidth().height(54.dp)){Icon(Icons.Default.SaveAlt,null);Spacer(Modifier.width(8.dp));Text(if(busy)"Processando…" else if(!proUnlocked)"Disponível no Ouro+" else if(!unlimited && coins<=0)"Sem Moedas SONUS" else if(unlimited)"Processar e salvar" else "Processar • 1 Moeda SONUS")} }
        busyItem(busy);messageItem(message)
    }
}

@Composable
private fun FeaturePassCard(
    unlocked: Boolean,
    title: String,
    description: String,
    onRequestUnlock: (onUnlocked: () -> Unit, onUnavailable: (String) -> Unit) -> Unit
) {
    val context = LocalContext.current
    if (unlocked) {
        Surface(
            shape = RoundedCornerShape(14.dp),
            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = .38f),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = .22f))
        ) {
            Row(Modifier.fillMaxWidth().padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CheckCircle, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(8.dp))
                Column {
                    Text("$title • liberado", fontWeight = FontWeight.ExtraBold)
                    Text("Seu perfil atual dá acesso a este recurso.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    } else {
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .5f)),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = .18f))
        ) {
            Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Lock, null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(8.dp))
                    Text(title, fontWeight = FontWeight.Black)
                }
                Text(description, style = MaterialTheme.typography.bodySmall)
                Text(
                    "Anúncios recompensados agora repõem +1 Moeda SONUS no FREE; não há desbloqueio de 24 horas.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = .58f)
                )
            }
        }
    }
}

@Composable
internal fun CreatorToolScaffold(onBack: () -> Unit, title: String, subtitle: String, content: androidx.compose.foundation.lazy.LazyListScope.() -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(11.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 32.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Voltar") }
                Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.Black, fontSize = 25.sp); Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .62f)) }
            }
        }
        content()
        item { Text("🔒 Processamento local • novas cópias • originais preservados", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .5f), modifier = Modifier.fillMaxWidth()) }
    }
}

@Composable
internal fun CreatorCard(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .46f)), border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .14f))) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = MaterialTheme.colorScheme.primary); Spacer(Modifier.width(8.dp)); Text(title, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp) }
            content()
        }
    }
}

@Composable
private fun CreatorFormatSelector(value: String, options: List<String> = CreatorAudioEngine.outputFormats, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(value, modifier = Modifier.weight(1f)); Icon(Icons.Default.ArrowDropDown, null) }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { f -> DropdownMenuItem(text = { Text(f) }, onClick = { expanded = false; onSelect(f) }, leadingIcon = { if (f == value) Icon(Icons.Default.Check, null) }) }
        }
    }
}

private fun androidx.compose.foundation.lazy.LazyListScope.busyItem(busy: Boolean) { if (busy) item { LinearProgressIndicator(Modifier.fillMaxWidth()) } }
internal fun androidx.compose.foundation.lazy.LazyListScope.messageItem(message: String?) { message?.let { text -> item {
    val failed = text.contains("falha", true) || text.contains("erro", true) || text.contains("não foi possível", true)
    val success = !failed && (text.contains("concluído", true) || text.contains("salvo", true) || text.startsWith("✓"))
    val bg = when { failed -> Color(0xFF4A1218); success -> Color(0xFF123D27); else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.72f) }
    val accent = when { failed -> Color(0xFFFF6675); success -> Color(0xFF59D98E); else -> MaterialTheme.colorScheme.primary }
    Surface(shape=RoundedCornerShape(14.dp), color=bg, border=BorderStroke(1.dp,accent.copy(alpha=.45f))) {
        Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.Top){
            Icon(if(failed) Icons.Default.ErrorOutline else if(success) Icons.Default.CheckCircle else Icons.Default.Info,null,tint=accent)
            Spacer(Modifier.width(9.dp))
            Column(Modifier.weight(1f)){
                Text(if(failed)"Falha" else if(success)"Sucesso" else "Informação",fontWeight=FontWeight.Black,color=Color.White)
                text.removePrefix("Falha:").removePrefix("✓").trim().split(" • ").filter{it.isNotBlank()}.forEach{ Text(it.trim(),style=MaterialTheme.typography.bodySmall,color=Color.White.copy(alpha=.86f)) }
            }
        }
    }
} } }
private fun transitionLabel(t: MergeTransition) = when (t) { MergeTransition.DIRECT -> "Direta"; MergeTransition.CROSSFADE -> "Crossfade"; MergeTransition.SILENCE -> "Intervalo" }
private fun transitionShort(t: MergeTransition) = when (t) { MergeTransition.DIRECT -> "Direto"; MergeTransition.CROSSFADE -> "Fade"; MergeTransition.SILENCE -> "Silêncio" }
private fun denoiseLabel(d: DenoiseStrength) = when (d) { DenoiseStrength.OFF -> "Off"; DenoiseStrength.LIGHT -> "Leve"; DenoiseStrength.MEDIUM -> "Média"; DenoiseStrength.STRONG -> "Forte" }
private fun formatCreatorClock(ms:Long):String{val total=(ms/1000).coerceAtLeast(0);return "%02d:%02d".format(total/60,total%60)}
private fun signed(v: Int): String = if (v > 0) "+$v" else v.toString()
private fun signedFile(v: Int): String = if (v >= 0) "plus$v" else "minus${-v}"
