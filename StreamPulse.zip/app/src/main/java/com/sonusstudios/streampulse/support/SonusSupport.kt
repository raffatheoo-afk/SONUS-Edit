package com.sonusstudios.streampulse.support

import android.content.Context
import android.net.Uri
import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.google.firebase.storage.FirebaseStorage
import com.sonusstudios.streampulse.BuildConfig
import com.sonusstudios.streampulse.auth.AccountRole
import com.sonusstudios.streampulse.auth.AuthUser
import com.sonusstudios.streampulse.cloud.CloudAccountManager
import com.sonusstudios.streampulse.cloud.SupportTeamMember
import com.sonusstudios.streampulse.core.sonusMusicPublicId
import com.sonusstudios.streampulse.core.MembershipTier
import com.sonusstudios.streampulse.stream.SonusStreamCreatorCenter
import com.sonusstudios.streampulse.stream.StreamCenterMode
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.suspendCancellableCoroutine
import java.security.MessageDigest
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject
import java.util.UUID
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

fun sonusPublicId(uid: String): String {
    val hex = MessageDigest.getInstance("SHA-256").digest(("SONUS:" + uid).toByteArray())
        .joinToString("") { "%02X".format(it) }.take(8)
    return "SNS-${hex.take(4)}-${hex.drop(4)}"
}

enum class SupportCategory(val title: String) {
    PAYMENT("Problema com Premium"),
    PREMIUM_NOT_UNLOCKED("Premium não liberado"),
    ADS("Problema com anúncio"),
    FUNCTION("Problema com função"),
    SUGGESTION("Sugestão ou ideia"),
    STREAM_SUBMISSION("Envio de música / SONUS Stream"),
    OTHER("Outro assunto")
}

enum class SupportStatus(val title: String) {
    NEW("Novo"), IN_SERVICE("Em atendimento"), WAITING_USER("Aguardando usuário"), RESOLVED("Resolvido")
}

data class SupportMessage(
    val id: String = "",
    val senderUid: String = "",
    val senderRole: String = "USER",
    val body: String = "",
    val createdAt: Long = 0L,
    val attachmentUrl: String? = null
)

data class SupportTicket(
    val id: String = "",
    val ownerUid: String = "",
    val publicUserId: String = "",
    val category: String = SupportCategory.OTHER.name,
    val status: String = SupportStatus.NEW.name,
    val subject: String = "",
    val lastMessage: String = "",
    val createdAt: Long = 0L,
    val updatedAt: Long = 0L,
    val assignedToUid: String? = null,
    val assignedToName: String? = null,
    val unreadForUser: Boolean = false,
    val unreadForTeam: Boolean = true,
    val rating: Int? = null,
    val ratingComment: String? = null,
    val technical: Map<String, String> = emptyMap()
)

data class SupportMusicLookup(
    val submissionId: String,
    val musicId: String,
    val ownerUid: String,
    val publicUserId: String,
    val title: String,
    val artist: String,
    val artistId: String,
    val genre: String,
    val status: String,
    val publishedFileId: Long?,
    val createdAt: Long
)

class SonusSupportRepository(context: Context) {
    private val db = FirebaseDatabase.getInstance()
    private val storage = FirebaseStorage.getInstance()
    private val auth = FirebaseAuth.getInstance()
    private val appContext = context.applicationContext

    suspend fun supportPermissions(uid: String): Map<String, Boolean> {
        if (uid.isBlank()) return emptyMap()
        return runCatching {
            db.getReference("supportTeam").child(uid).child("permissions").get().awaitSupportSnapshot().children
                .associate { it.key.orEmpty() to (it.getValue(Boolean::class.java) == true) }
        }.getOrDefault(emptyMap())
    }

    suspend fun findMusicByPublicId(agent: AuthUser, rawMusicId: String): Result<SupportMusicLookup?> = runCatching {
        require(agent.role == AccountRole.OWNER || agent.role == AccountRole.SUPPORT) { "Sem permissão." }
        val permissions = if (agent.role == AccountRole.OWNER) emptyMap() else supportPermissions(agent.uid)
        require(agent.role == AccountRole.OWNER || permissions["streamLookup"] == true || permissions["streamModeration"] == true) { "Sua função de suporte não possui acesso à consulta de músicas." }
        val wanted = rawMusicId.trim().lowercase()
        require(wanted.startsWith("sonusmusic") && wanted.length >= 16) { "Informe um Music ID SONUS válido." }
        val snap = db.getReference("streamSubmissions").get().awaitSupportSnapshot()
        val match = snap.children.firstOrNull { child ->
            val id = child.child("id").getValue(String::class.java) ?: child.key.orEmpty()
            val musicId = child.child("musicId").getValue(String::class.java).orEmpty().ifBlank { sonusMusicPublicId(id) }
            musicId.equals(wanted, ignoreCase = true)
        } ?: return@runCatching null
        val id = match.child("id").getValue(String::class.java) ?: match.key.orEmpty()
        SupportMusicLookup(
            submissionId = id,
            musicId = match.child("musicId").getValue(String::class.java).orEmpty().ifBlank { sonusMusicPublicId(id) },
            ownerUid = match.child("uid").getValue(String::class.java).orEmpty(),
            publicUserId = match.child("publicUserId").getValue(String::class.java).orEmpty(),
            title = match.child("title").getValue(String::class.java).orEmpty(),
            artist = match.child("artistName").getValue(String::class.java).orEmpty(),
            artistId = match.child("artistId").getValue(String::class.java).orEmpty(),
            genre = match.child("genre").getValue(String::class.java).orEmpty(),
            status = match.child("status").getValue(String::class.java).orEmpty(),
            publishedFileId = match.child("publishedFileId").getValue(Long::class.java),
            createdAt = match.child("createdAt").getValue(Long::class.java) ?: 0L
        )
    }

    suspend fun requestStreamTrackRemoval(agent: AuthUser, music: SupportMusicLookup, reason: String): Result<Unit> = runCatching {
        require(agent.role == AccountRole.OWNER || agent.role == AccountRole.SUPPORT) { "Sem permissão." }
        val permissions = if (agent.role == AccountRole.OWNER) emptyMap() else supportPermissions(agent.uid)
        require(agent.role == AccountRole.OWNER || permissions["streamRemoval"] == true) { "Sua função de suporte não possui permissão para remover músicas." }
        val cleanReason = reason.trim().take(1000)
        require(cleanReason.isNotBlank()) { "Informe o motivo da remoção." }
        val payload = mapOf(
            "musicId" to music.musicId,
            "submissionId" to music.submissionId,
            "fileId" to music.publishedFileId,
            "title" to music.title,
            "artist" to music.artist,
            "reason" to cleanReason
        )
        val remote = requestPrivilegedAction(
            ticketId = "MUSIC:${music.musicId}",
            targetUid = music.ownerUid,
            agent = agent,
            action = "REMOVE_STREAM_TRACK",
            payload = payload
        )
        if (remote.isFailure) {
            // Nunca damos credenciais de catálogo ao APK. Se o endpoint ainda não reconhecer
            // a ação, preservamos a solicitação numa fila auditável para processamento seguro.
            val id = UUID.randomUUID().toString()
            db.getReference("supportAdminActions").child(id).setValue(
                mapOf(
                    "id" to id, "ticketId" to "MUSIC:${music.musicId}", "targetUid" to music.ownerUid,
                    "actorUid" to agent.uid, "actorRole" to agent.role.name, "action" to "REMOVE_STREAM_TRACK",
                    "payload" to payload, "status" to "PENDING_BACKEND", "createdAt" to System.currentTimeMillis(),
                    "backendError" to remote.exceptionOrNull()?.message.orEmpty().take(240)
                )
            ).awaitCompletion()
        }
    }

    suspend fun createTicket(user: AuthUser, category: SupportCategory, text: String, technical: Map<String, String>): Result<String> = runCatching {
        require(user.uid.isNotBlank()) { "Entre na sua conta para falar com o suporte." }
        val ref = db.getReference("supportTickets").push()
        val id = ref.key ?: UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        val clean = text.trim().take(3000)
        require(clean.isNotBlank()) { "Escreva uma mensagem para o suporte." }
        val values = mapOf(
            "id" to id,
            "ownerUid" to user.uid,
            "publicUserId" to sonusPublicId(user.uid),
            "category" to category.name,
            "status" to SupportStatus.NEW.name,
            "subject" to category.title,
            "lastMessage" to clean.take(240),
            "createdAt" to now,
            "updatedAt" to now,
            "unreadForUser" to false,
            "unreadForTeam" to true,
            "technical" to technical.mapValues { it.value.take(240) }
        )
        ref.setValue(values).awaitCompletion()
        ref.child("messages").push().setValue(
            mapOf("senderUid" to user.uid, "senderRole" to "USER", "body" to clean, "createdAt" to now)
        ).awaitCompletion()
        id
    }

    suspend fun reply(ticketId: String, sender: AuthUser, body: String): Result<Unit> = runCatching {
        val clean = body.trim().take(3000)
        require(clean.isNotBlank()) { "Digite uma mensagem." }
        val now = System.currentTimeMillis()
        val team = sender.role == AccountRole.OWNER || sender.role == AccountRole.SUPPORT
        val ref = db.getReference("supportTickets").child(ticketId)
        ref.child("messages").push().setValue(
            mapOf("senderUid" to sender.uid, "senderRole" to sender.role.name, "body" to clean, "createdAt" to now)
        ).awaitCompletion()
        ref.updateChildren(
            mapOf(
                "lastMessage" to clean.take(240),
                "updatedAt" to now,
                "unreadForUser" to team,
                "unreadForTeam" to !team,
                "status" to if (team) SupportStatus.WAITING_USER.name else SupportStatus.IN_SERVICE.name
            )
        ).awaitCompletion()
        if (team) {
            val ownerUid = ref.child("ownerUid").get().awaitSupportSnapshot().getValue(String::class.java).orEmpty()
            if (ownerUid.isNotBlank()) db.getReference("streamUserNotifications").child(ownerUid).push().setValue(
                mapOf("type" to "SUPPORT_REPLY", "title" to "Nova mensagem do suporte", "message" to clean.take(240), "route" to "SUPPORT", "ticketId" to ticketId, "createdAt" to now, "read" to false)
            ).awaitCompletion()
        }
    }

    suspend fun uploadReceipt(ticketId: String, sender: AuthUser, uri: Uri): Result<Unit> = runCatching {
        val mime = appContext.contentResolver.getType(uri) ?: "image/jpeg"
        require(mime.startsWith("image/")) { "Envie uma imagem válida." }
        val path = "support_receipts/$ticketId/${sender.uid}/${UUID.randomUUID()}.jpg"
        val ref = storage.reference.child(path)
        ref.putFile(uri).awaitStorage()
        val url = ref.downloadUrl.awaitUri().toString()
        val now = System.currentTimeMillis()
        db.getReference("supportTickets").child(ticketId).child("messages").push().setValue(
            mapOf(
                "senderUid" to sender.uid,
                "senderRole" to sender.role.name,
                "body" to "Comprovante anexado",
                "attachmentUrl" to url,
                "attachmentStoragePath" to path,
                "createdAt" to now,
                "expiresAfterResolution" to true
            )
        ).awaitCompletion()
        db.getReference("supportTickets").child(ticketId).updateChildren(
            mapOf("updatedAt" to now, "unreadForTeam" to true, "lastMessage" to "Comprovante anexado")
        ).awaitCompletion()
    }

    suspend fun updateStatus(ticketId: String, status: SupportStatus, agent: AuthUser): Result<Unit> = runCatching {
        require(agent.role == AccountRole.OWNER || agent.role == AccountRole.SUPPORT) { "Sem permissão." }
        val ref = db.getReference("supportTickets").child(ticketId)
        val snapshot = ref.get().awaitSupportSnapshot()
        val assigned = snapshot.child("assignedToUid").getValue(String::class.java).orEmpty()
        if (agent.role != AccountRole.OWNER && assigned.isNotBlank() && assigned != agent.uid) {
            error("Este atendimento já está atribuído a outro membro da equipe.")
        }
        val now = System.currentTimeMillis()
        val updates = mutableMapOf<String, Any?>(
            "status" to status.name, "updatedAt" to now, "assignedToUid" to agent.uid,
            "assignedToName" to (agent.displayName ?: "Equipe SONUS"), "unreadForUser" to (status == SupportStatus.RESOLVED)
        )
        if (status == SupportStatus.RESOLVED) {
            updates["resolvedAt"] = now
            updates["resolvedByUid"] = agent.uid
            updates["resolvedByName"] = agent.displayName ?: "Equipe SONUS"
            updates["purgeAfter"] = now + 14L * 24 * 60 * 60 * 1000
        }
        ref.updateChildren(updates).awaitCompletion()
        if (status == SupportStatus.RESOLVED) {
            val ownerUid = ref.child("ownerUid").get().awaitSupportSnapshot().getValue(String::class.java).orEmpty()
            if (ownerUid.isNotBlank()) db.getReference("streamUserNotifications").child(ownerUid).push().setValue(
                mapOf("type" to "SUPPORT_RESOLVED", "title" to "Atendimento concluído", "message" to "Seu atendimento foi marcado como resolvido. Se quiser, avalie de 1 a 5 estrelas.", "route" to "SUPPORT", "ticketId" to ticketId, "createdAt" to now, "read" to false)
            ).awaitCompletion()
        }
    }

    suspend fun rate(ticketId: String, uid: String, stars: Int, comment: String): Result<Unit> = runCatching {
        db.getReference("supportTickets").child(ticketId).updateChildren(
            mapOf(
                "rating" to stars.coerceIn(1, 5),
                "ratingComment" to comment.trim().take(500),
                "ratedAt" to System.currentTimeMillis(),
                "purgeAfter" to (System.currentTimeMillis() + 7L * 24 * 60 * 60 * 1000)
            )
        ).awaitCompletion()
    }

    suspend fun requestPrivilegedAction(ticketId: String, targetUid: String, agent: AuthUser, action: String, payload: Map<String, Any?>): Result<Unit> = runCatching {
        require(agent.role == AccountRole.OWNER || agent.role == AccountRole.SUPPORT) { "Sem permissão." }
        val base = BuildConfig.SONUS_STREAM_PROXY_BASE.trim().trimEnd('/')
        if (base.isNotBlank()) {
            val token = auth.currentUser?.getIdToken(false)?.awaitSupportToken()?.token ?: error("Sessão expirada. Entre novamente.")
            val body = JSONObject().apply {
                put("ticketId", ticketId)
                put("targetUid", targetUid)
                put("action", action)
                put("payload", JSONObject(payload.filterValues { it != null }))
            }
            val response = withContext(Dispatchers.IO) {
                val c = (URL("$base/supportAction").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"; connectTimeout = 12_000; readTimeout = 20_000; doOutput = true
                    setRequestProperty("Authorization", "Bearer $token")
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                }
                try {
                    c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                    val code = c.responseCode
                    val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
                    if (code !in 200..299) error("Ação recusada pelo servidor ($code): ${text.take(180)}")
                    text
                } finally { c.disconnect() }
            }
            if (response.isNotBlank()) JSONObject(response)
        } else {
            // Fallback auditável para ambientes em que a Function ainda não foi publicada.
            val id = UUID.randomUUID().toString()
            db.getReference("supportAdminActions").child(id).setValue(
                mapOf(
                    "id" to id, "ticketId" to ticketId, "targetUid" to targetUid,
                    "actorUid" to agent.uid, "actorRole" to agent.role.name,
                    "action" to action, "payload" to payload, "status" to "PENDING_BACKEND",
                    "createdAt" to System.currentTimeMillis()
                )
            ).awaitCompletion()
        }
    }

    suspend fun approveArtistNameChange(ticket: SupportTicket, agent: AuthUser): Result<Unit> = runCatching {
        require(agent.role == AccountRole.OWNER || agent.role == AccountRole.SUPPORT) { "Sem permissão." }
        val requested = ticket.technical["requestedArtistName"].orEmpty().trim().take(120)
        require(requested.length >= 2) { "O chamado não possui um novo nome válido." }
        val now = System.currentTimeMillis()
        val profileRef = db.getReference("streamArtistProfiles").child(ticket.ownerUid)
        val profile = profileRef.get().awaitSupportSnapshot()
        require(profile.exists()) { "Perfil artístico da conta não encontrado." }
        val lastChanged = profile.child("lastNameChangeAt").getValue(Long::class.java) ?: 0L
        require(lastChanged <= 0L || now - lastChanged >= 30L * 86_400_000L) { "Este artista teve uma alteração aprovada nos últimos 30 dias." }
        profileRef.updateChildren(mapOf(
            "artistName" to requested,
            "updatedAt" to now,
            "lastNameChangeAt" to now,
            "lastNameChangeApprovedBy" to agent.uid,
            "lastNameChangeTicketId" to ticket.id
        )).awaitCompletion()

        // Mantém o vínculo das faixas publicadas no mesmo artistId, sem criar outro artista.
        val published = db.getReference("streamPublishedArtists").get().awaitSupportSnapshot()
        published.children.filter { it.child("uid").getValue(String::class.java) == ticket.ownerUid }.forEach { item ->
            item.ref.updateChildren(mapOf("artistName" to requested, "updatedAt" to now)).awaitCompletion()
        }
        reply(ticket.id, agent, "Nome artístico aprovado e atualizado para: $requested.").getOrThrow()
        updateStatus(ticket.id, SupportStatus.RESOLVED, agent).getOrThrow()
    }

    fun userTickets(uid: String): Flow<List<SupportTicket>> = ticketFlow(
        db.getReference("supportTickets").orderByChild("ownerUid").equalTo(uid)
    )

    fun teamTickets(): Flow<List<SupportTicket>> = ticketFlow(db.getReference("supportTickets"))

    fun messages(ticketId: String): Flow<List<SupportMessage>> = callbackFlow {
        val ref = db.getReference("supportTickets").child(ticketId).child("messages")
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                trySend(snapshot.children.mapNotNull { s ->
                    SupportMessage(
                        id = s.key.orEmpty(),
                        senderUid = s.child("senderUid").getValue(String::class.java).orEmpty(),
                        senderRole = s.child("senderRole").getValue(String::class.java).orEmpty(),
                        body = s.child("body").getValue(String::class.java).orEmpty(),
                        createdAt = s.child("createdAt").getValue(Long::class.java) ?: 0L,
                        attachmentUrl = s.child("attachmentUrl").getValue(String::class.java)
                    )
                }.sortedBy { it.createdAt })
            }
            override fun onCancelled(error: DatabaseError) { trySend(emptyList()) }
        }
        ref.addValueEventListener(listener)
        awaitClose { ref.removeEventListener(listener) }
    }

    private fun ticketFlow(query: Query): Flow<List<SupportTicket>> = callbackFlow {
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                trySend(snapshot.children.mapNotNull(::ticketFrom).sortedByDescending { it.updatedAt })
            }
            override fun onCancelled(error: DatabaseError) { trySend(emptyList()) }
        }
        query.addValueEventListener(listener)
        awaitClose { query.removeEventListener(listener) }
    }

    private fun ticketFrom(s: DataSnapshot): SupportTicket? {
        val id = s.child("id").getValue(String::class.java) ?: s.key ?: return null
        val tech = s.child("technical").children.associate { it.key.orEmpty() to (it.getValue(String::class.java) ?: "") }
        return SupportTicket(
            id = id,
            ownerUid = s.child("ownerUid").getValue(String::class.java).orEmpty(),
            publicUserId = s.child("publicUserId").getValue(String::class.java).orEmpty(),
            category = s.child("category").getValue(String::class.java) ?: SupportCategory.OTHER.name,
            status = s.child("status").getValue(String::class.java) ?: SupportStatus.NEW.name,
            subject = s.child("subject").getValue(String::class.java).orEmpty(),
            lastMessage = s.child("lastMessage").getValue(String::class.java).orEmpty(),
            createdAt = s.child("createdAt").getValue(Long::class.java) ?: 0L,
            updatedAt = s.child("updatedAt").getValue(Long::class.java) ?: 0L,
            assignedToUid = s.child("assignedToUid").getValue(String::class.java),
            assignedToName = s.child("assignedToName").getValue(String::class.java),
            unreadForUser = s.child("unreadForUser").getValue(Boolean::class.java) == true,
            unreadForTeam = s.child("unreadForTeam").getValue(Boolean::class.java) == true,
            rating = s.child("rating").getValue(Long::class.java)?.toInt(),
            ratingComment = s.child("ratingComment").getValue(String::class.java),
            technical = tech
        )
    }
}

@Composable
fun SonusSupportScreen(
    user: AuthUser,
    technicalContext: Map<String, String>,
    onBack: () -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val repo = remember { SonusSupportRepository(context) }
    val team = user.role == AccountRole.OWNER || user.role == AccountRole.SUPPORT
    val flow = remember(user.uid, team) { if (team) repo.teamTickets() else repo.userTickets(user.uid) }
    val tickets by flow.collectAsState(initial = emptyList())
    var selected by remember { mutableStateOf<SupportTicket?>(null) }
    var composeNew by remember { mutableStateOf(false) }
    var showTeamManager by remember { mutableStateOf(false) }
    var showStreamModeration by rememberSaveable { mutableStateOf(false) }
    var teamPermissions by remember(user.uid) { mutableStateOf<Map<String, Boolean>>(emptyMap()) }
    LaunchedEffect(user.uid, user.role) {
        if (user.role == AccountRole.SUPPORT) teamPermissions = repo.supportPermissions(user.uid)
    }
    val canModerateStream = user.role == AccountRole.OWNER || teamPermissions["streamModeration"] == true

    if (showStreamModeration && canModerateStream) {
        SonusStreamCreatorCenter(
            user = user,
            tier = MembershipTier.FREE,
            mode = StreamCenterMode.MODERATION,
            onBack = { showStreamModeration = false }
        )
        return
    }

    if (selected != null) {
        SonusSupportConversation(repo, selected!!, user, onBack = { selected = null })
        return
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 30.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Voltar") }
                Column(Modifier.weight(1f)) {
                    Text(if (team) "Suporte SONUS" else "Fale Conosco", fontSize = 24.sp, fontWeight = FontWeight.Black)
                    Text(if (team) "Atendimentos e diagnósticos" else "Ajuda humana dentro da sua conta", style = MaterialTheme.typography.bodySmall)
                }
                if (!team) FilledTonalIconButton(onClick = { composeNew = true }) { Icon(Icons.Default.Add, "Novo") }
                if (canModerateStream) FilledTonalIconButton(onClick = { showStreamModeration = true }) { Icon(Icons.Default.FactCheck, "Moderação Stream") }
                if (user.role == AccountRole.OWNER) FilledTonalIconButton(onClick = { showTeamManager = true }) { Icon(Icons.Default.Groups, "Equipe") }
            }
        }
        if (team) item { SonusSupportMusicPanel(repo = repo, user = user) }
        if (tickets.isEmpty()) item {
            Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .3f)) {
                Column(Modifier.padding(16.dp)) {
                    Text(if (team) "Nenhum chamado agora" else "Nenhum atendimento aberto", fontWeight = FontWeight.Bold)
                    Text(if (team) "Novas mensagens aparecerão aqui em tempo real." else "Quando precisar, abra um chamado. O SONUS envia somente o contexto técnico necessário.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        items(tickets, key = { it.id }) { ticket ->
            val unread = if (team) ticket.unreadForTeam else ticket.unreadForUser
            Surface(
                modifier = Modifier.fillMaxWidth().clickable { selected = ticket },
                shape = RoundedCornerShape(17.dp),
                color = if (unread) MaterialTheme.colorScheme.errorContainer.copy(alpha = .34f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .30f),
                border = BorderStroke(1.dp, if (unread) MaterialTheme.colorScheme.error.copy(alpha = .45f) else MaterialTheme.colorScheme.outline.copy(alpha = .10f))
            ) {
                Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (unread) Icons.Default.MarkEmailUnread else Icons.Default.SupportAgent, null, tint = if (unread) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(ticket.subject.ifBlank { "Atendimento SONUS" }, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                        Text(ticket.lastMessage, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (team) Text(ticket.publicUserId, style = MaterialTheme.typography.labelSmall)
                    }
                    Text(runCatching { SupportStatus.valueOf(ticket.status).title }.getOrDefault(ticket.status), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    if (composeNew) {
        var category by remember { mutableStateOf(SupportCategory.FUNCTION) }
        var text by remember { mutableStateOf("") }
        var expanded by remember { mutableStateOf(false) }
        var busy by remember { mutableStateOf(false) }
        var error by remember { mutableStateOf<String?>(null) }
        val scope = rememberCoroutineScope()
        AlertDialog(
            onDismissRequest = { if (!busy) composeNew = false },
            title = { Text("Novo atendimento") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box {
                        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(category.title, maxLines = 1) }
                        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            SupportCategory.entries
                                .filterNot { it == SupportCategory.PREMIUM_NOT_UNLOCKED }
                                .forEach { c -> DropdownMenuItem(text = { Text(c.title) }, onClick = { category = c; expanded = false }) }
                        }
                    }
                    OutlinedTextField(text, { text = it.take(3000) }, label = { Text("Conte o que aconteceu") }, minLines = 4, modifier = Modifier.fillMaxWidth())
                    Text("Ao enviar, o SONUS anexa versão do app, plano e o último contexto técnico relevante. Não enviamos sua biblioteca de mídia.", style = MaterialTheme.typography.labelSmall)
                    error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                }
            },
            confirmButton = {
                Button(enabled = !busy && text.isNotBlank(), onClick = {
                    busy = true; error = null
                    scope.launch {
                        val result = repo.createTicket(user, category, text, technicalContext + mapOf("appVersion" to BuildConfig.VERSION_NAME, "versionCode" to BuildConfig.VERSION_CODE.toString()))
                        busy = false
                        if (result.isSuccess) composeNew = false else error = result.exceptionOrNull()?.message
                    }
                }) { Text(if (busy) "Enviando…" else "Enviar") }
            },
            dismissButton = { TextButton(onClick = { composeNew = false }, enabled = !busy) { Text("Cancelar") } }
        )
    }
    if (showTeamManager && user.role == AccountRole.OWNER) {
        SonusSupportTeamDialog(onClose = { showTeamManager = false })
    }

}

@Composable
private fun SonusSupportMusicPanel(repo: SonusSupportRepository, user: AuthUser) {
    val scope = rememberCoroutineScope()
    var permissions by remember(user.uid) { mutableStateOf<Map<String, Boolean>>(emptyMap()) }
    var musicId by rememberSaveable { mutableStateOf("") }
    var music by remember { mutableStateOf<SupportMusicLookup?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var removalReason by remember { mutableStateOf("") }
    var showRemoval by remember { mutableStateOf(false) }
    LaunchedEffect(user.uid) { if (user.role == AccountRole.SUPPORT) permissions = repo.supportPermissions(user.uid) }
    val canLookup = user.role == AccountRole.OWNER || permissions["streamLookup"] == true || permissions["streamModeration"] == true
    val canRemove = user.role == AccountRole.OWNER || permissions["streamRemoval"] == true
    if (!canLookup) return
    Surface(shape=RoundedCornerShape(18.dp),color=Color(0xFF113447).copy(alpha=.42f),border=BorderStroke(1.dp,Color(0xFF58D7FF).copy(alpha=.25f))) {
        Column(Modifier.fillMaxWidth().padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.ManageSearch,null,tint=Color(0xFF58D7FF));Spacer(Modifier.width(8.dp));Column{Text("Localizar música",fontWeight=FontWeight.ExtraBold);Text("Cole o Music ID SONUS para encontrar a faixa exata.",style=MaterialTheme.typography.labelSmall)}}
            OutlinedTextField(musicId,{musicId=it.trim().lowercase().take(40)},label={Text("sonusmusic…")},singleLine=true,modifier=Modifier.fillMaxWidth())
            Button(onClick={scope.launch{busy=true;message=null;val r=repo.findMusicByPublicId(user,musicId);music=r.getOrNull();message=when{r.isFailure->r.exceptionOrNull()?.message;music==null->"Música não encontrada.";else->null};busy=false}},enabled=!busy&&musicId.isNotBlank(),modifier=Modifier.fillMaxWidth()){Text(if(busy)"Buscando…" else "Localizar") }
            music?.let { m ->
                HorizontalDivider()
                Text(m.title.ifBlank{"Sem título"},fontWeight=FontWeight.Black,fontSize=17.sp)
                Text("${m.artist} • ${m.genre}",style=MaterialTheme.typography.bodySmall)
                Text("${m.musicId} • ${m.status}",style=MaterialTheme.typography.labelSmall)
                Text("submissionId: ${m.submissionId}${m.publishedFileId?.let{" • fileId: $it"}.orEmpty()}",style=MaterialTheme.typography.labelSmall)
                if (canRemove) OutlinedButton(onClick={showRemoval=true},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.outlinedButtonColors(contentColor=MaterialTheme.colorScheme.error)){Icon(Icons.Default.DeleteOutline,null);Spacer(Modifier.width(6.dp));Text("Remover do catálogo") }
                else Text("Sua função possui consulta, mas não permissão de remoção.",style=MaterialTheme.typography.labelSmall)
            }
            message?.let{Text(it,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.primary)}
        }
    }
    if (showRemoval && music != null) {
        val current = music!!
        AlertDialog(onDismissRequest={if(!busy)showRemoval=false},title={Text("Remover música?",fontWeight=FontWeight.Black)},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Text("${current.title} • ${current.artist}");Text(current.musicId,style=MaterialTheme.typography.labelSmall);OutlinedTextField(removalReason,{removalReason=it.take(1000)},label={Text("Motivo obrigatório")},minLines=3,modifier=Modifier.fillMaxWidth());Text("A ação é auditável e passa pelo backend de suporte; o app não recebe credenciais de armazenamento.",style=MaterialTheme.typography.labelSmall)}},confirmButton={Button(onClick={scope.launch{busy=true;val r=repo.requestStreamTrackRemoval(user,current,removalReason);busy=false;message=if(r.isSuccess)"Ação de remoção enviada ao backend e registrada para auditoria." else r.exceptionOrNull()?.message;if(r.isSuccess){showRemoval=false;removalReason=""}}},enabled=!busy&&removalReason.isNotBlank(),colors=ButtonDefaults.buttonColors(containerColor=MaterialTheme.colorScheme.error)){Text("Confirmar remoção")}},dismissButton={TextButton(onClick={showRemoval=false},enabled=!busy){Text("Cancelar")}})
    }
}

@Composable
private fun SonusSupportTeamDialog(onClose:()->Unit) {
    val cloud=remember{CloudAccountManager()}
    val scope=rememberCoroutineScope()
    var publicId by remember{mutableStateOf("")}
    var member by remember{mutableStateOf<SupportTeamMember?>(null)}
    var searching by remember{mutableStateOf(false)}
    var message by remember{mutableStateOf<String?>(null)}
    val defaultPermissions=listOf(
        "tickets" to "Ver e responder chamados",
        "diagnostics" to "Ver diagnóstico técnico",
        "payments" to "Consultar situação Premium",
        "premium" to "Consultar e solicitar liberação Premium",
        "compensation" to "Solicitar dias de compensação",
        "promos" to "Gerar código promocional",
        "resolve" to "Resolver atendimentos",
        "adminActions" to "Solicitar ações administrativas do atendimento",
        "streamLookup" to "Localizar músicas pelo Music ID",
        "streamModeration" to "Analisar envios do SONUS Stream",
        "streamRemoval" to "Solicitar remoção de música publicada"
    )
    var permissions by remember{mutableStateOf(defaultPermissions.associate{(key,_)->key to (key != "streamRemoval")})}
    member?.let{found->LaunchedEffect(found.uid){permissions=defaultPermissions.associate{(key,_)->key to (found.permissions[key] ?: (key != "streamRemoval"))}}}
    AlertDialog(
        onDismissRequest=onClose,
        title={Text("Equipe de suporte",fontWeight=FontWeight.Black)},
        text={LazyColumn(verticalArrangement=Arrangement.spacedBy(9.dp),modifier=Modifier.heightIn(max=520.dp)){
            item{Text("Somente OWNER pode conceder ou revogar acesso. Pesquise pelo ID SONUS público do usuário.",style=MaterialTheme.typography.bodySmall)}
            item{OutlinedTextField(publicId,{publicId=it.uppercase().take(20)},label={Text("ID SONUS • ex. SNS-ABCD-1234")},modifier=Modifier.fillMaxWidth(),singleLine=true)}
            item{Button(enabled=!searching&&publicId.isNotBlank(),onClick={scope.launch{searching=true;message=null;val r=cloud.findAccountByPublicId(publicId);member=r.getOrNull();message=if(r.isFailure)r.exceptionOrNull()?.message else if(member==null)"Usuário não encontrado" else null;searching=false}},modifier=Modifier.fillMaxWidth()){Text(if(searching)"Buscando…" else "Localizar usuário")}}
            member?.let{m->
                item{Surface(shape=RoundedCornerShape(15.dp),color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.35f)){Column(Modifier.padding(12.dp)){Text(m.displayName?:"Usuário SONUS",fontWeight=FontWeight.ExtraBold);Text(m.email?:m.publicId,style=MaterialTheme.typography.labelSmall);Text(if(m.active)"SUPPORT ativo" else "Usuário comum",color=if(m.active)Color(0xFF49C879) else MaterialTheme.colorScheme.onSurface.copy(alpha=.6f),fontWeight=FontWeight.Bold)}}}
                item{Text("Permissões",fontWeight=FontWeight.Bold)}
                items(defaultPermissions){(key,label)->Row(verticalAlignment=Alignment.CenterVertically){Text(label,Modifier.weight(1f),style=MaterialTheme.typography.bodySmall);Switch(checked=permissions[key]==true,onCheckedChange={permissions=permissions.toMutableMap().also{map->map[key]=it}})}}
                item{Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick={scope.launch{val r=cloud.setSupportMember(m.uid,true,permissions);message=if(r.isSuccess)"Acesso SUPPORT atualizado." else r.exceptionOrNull()?.message;member=m.copy(active=r.isSuccess||m.active,permissions=permissions)}},modifier=Modifier.weight(1f)){Text(if(m.active)"Salvar" else "Adicionar")};OutlinedButton(onClick={scope.launch{val r=cloud.setSupportMember(m.uid,false,emptyMap());message=if(r.isSuccess)"Acesso revogado imediatamente." else r.exceptionOrNull()?.message;member=m.copy(active=false)}},modifier=Modifier.weight(1f),enabled=m.active){Text("Revogar")}}}
            }
            message?.let{item{Text(it,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.primary)}}
        }},
        confirmButton={TextButton(onClick=onClose){Text("Fechar")}}
    )
}

@Composable
private fun SonusSupportConversation(repo: SonusSupportRepository, ticket: SupportTicket, user: AuthUser, onBack: () -> Unit) {
    val messages by remember(ticket.id) { repo.messages(ticket.id) }.collectAsState(initial = emptyList())
    var text by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var showDiagnostics by remember { mutableStateOf(false) }
    var showPremiumAction by remember { mutableStateOf(false) }
    var rating by remember { mutableIntStateOf(ticket.rating ?: 0) }
    var ratingComment by remember { mutableStateOf(ticket.ratingComment.orEmpty()) }
    val scope = rememberCoroutineScope()
    val team = user.role == AccountRole.OWNER || user.role == AccountRole.SUPPORT
    val attachmentPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch { busy = true; repo.uploadReceipt(ticket.id, user, uri); busy = false }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Voltar") }
            Column(Modifier.weight(1f)) {
                Text(ticket.subject, fontWeight = FontWeight.Black, maxLines = 1)
                Text("${ticket.publicUserId} • ${runCatching { SupportStatus.valueOf(ticket.status).title }.getOrDefault(ticket.status)}", style = MaterialTheme.typography.labelSmall)
            }
            if (team && ticket.technical["requestType"] == "ARTIST_NAME_CHANGE") {
                FilledTonalButton(enabled=!busy,onClick={scope.launch{busy=true;repo.approveArtistNameChange(ticket,user);busy=false;onBack()}}) { Text("Aprovar nome",fontSize=9.sp) }
            }
            if (team) IconButton(onClick = { showDiagnostics = true }) { Icon(Icons.Default.Troubleshoot, "Diagnóstico") }
        }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 10.dp)) {
            items(messages, key = { it.id }) { msg ->
                val mine = msg.senderUid == user.uid
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
                    Surface(shape = RoundedCornerShape(16.dp), color = if (mine) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant) {
                        Column(Modifier.widthIn(max = 310.dp).padding(10.dp)) {
                            Text(if (msg.senderRole == "USER") "Usuário" else "Equipe SONUS", fontWeight = FontWeight.Bold, fontSize = 9.sp)
                            Text(msg.body, style = MaterialTheme.typography.bodySmall)
                            if (msg.attachmentUrl != null) { ReceiptPreview(msg.attachmentUrl); Text("Imagem temporária • sem opção de salvar/compartilhar", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary) }
                        }
                    }
                }
            }
            if (ticket.status == SupportStatus.RESOLVED.name && !team) item {
                Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .35f)) {
                    Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Como foi o atendimento?", fontWeight = FontWeight.ExtraBold)
                        Row { (1..5).forEach { n -> IconButton(onClick = { rating = n }) { Icon(if (n <= rating) Icons.Default.Star else Icons.Default.StarBorder, null, tint = if (n <= rating) Color(0xFFFFC857) else LocalContentColor.current.copy(alpha=.5f)) } } }
                        OutlinedTextField(ratingComment, { ratingComment = it.take(500) }, label = { Text("Comentário opcional") }, modifier = Modifier.fillMaxWidth())
                        Button(enabled = rating > 0, onClick = { scope.launch { repo.rate(ticket.id, user.uid, rating, ratingComment) } }, modifier = Modifier.fillMaxWidth()) { Text("Enviar avaliação") }
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            if (!team) IconButton(onClick = { attachmentPicker.launch("image/*") }, enabled = !busy) { Icon(Icons.Default.AttachFile, "Anexar imagem") }
            OutlinedTextField(text, { text = it.take(3000) }, placeholder = { Text("Mensagem") }, modifier = Modifier.weight(1f), maxLines = 4)
            IconButton(enabled = !busy && text.isNotBlank(), onClick = {
                val send = text; text = ""; busy = true
                scope.launch { repo.reply(ticket.id, user, send); busy = false }
            }) { Icon(Icons.Default.Send, "Enviar") }
            if (team) IconButton(onClick = { scope.launch { repo.updateStatus(ticket.id, SupportStatus.RESOLVED, user) } }) { Icon(Icons.Default.CheckCircle, "Resolver", tint = Color(0xFF43C98C)) }
        }
    }

    if (showDiagnostics) {
        AlertDialog(
            onDismissRequest = { showDiagnostics = false },
            title = { Text("Diagnóstico do atendimento") },
            text = {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    ticket.technical.toList().forEach { (k, v) -> item { Text("$k: $v", style = MaterialTheme.typography.bodySmall) } }
                    item { HorizontalDivider() }
                    item { Text("Ações sensíveis são registradas e devem ser processadas pelo backend com permissão da equipe.", style = MaterialTheme.typography.labelSmall) }
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            AssistChip(onClick = { scope.launch { repo.requestPrivilegedAction(ticket.id, ticket.ownerUid, user, "SYNC_PREMIUM", emptyMap()) } }, label = { Text("Sincronizar Premium") })
                            AssistChip(onClick = { scope.launch { repo.requestPrivilegedAction(ticket.id, ticket.ownerUid, user, "DELETE_RECEIPTS", emptyMap()) } }, label = { Text("Apagar comprovantes") })
                            AssistChip(onClick = { showPremiumAction = true; showDiagnostics = false }, label = { Text("Liberar/compensar") })
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showDiagnostics = false }) { Text("Fechar") } }
        )
    }
    if (showPremiumAction) {
        var plan by remember { mutableStateOf("OURO") }
        var paidDays by remember { mutableIntStateOf(30) }
        var bonusDays by remember { mutableIntStateOf(0) }
        var customPaidDays by remember { mutableStateOf("") }
        var customBonusDays by remember { mutableStateOf("") }
        var reason by remember { mutableStateOf("Atendimento de suporte") }
        AlertDialog(
            onDismissRequest={showPremiumAction=false},
            title={Text("Liberar Premium",fontWeight=FontWeight.Black)},
            text={Column(verticalArrangement=Arrangement.spacedBy(9.dp)){
                Text("O benefício fica vinculado à conta. Dias extras são registrados separadamente para auditoria.",style=MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){FilterChip(selected=plan=="OURO",onClick={plan="OURO"},label={Text("Ouro")});FilterChip(selected=plan=="DIAMANTE",onClick={plan="DIAMANTE"},label={Text("Diamante")})}
                Text("Período pago: $paidDays dias",fontWeight=FontWeight.Bold)
                Row(horizontalArrangement=Arrangement.spacedBy(5.dp)){listOf(30,60,90).forEach{d->FilterChip(selected=paidDays==d && customPaidDays.isBlank(),onClick={paidDays=d;customPaidDays=""},label={Text("$d")})}}
                OutlinedTextField(
                    customPaidDays,
                    { raw -> customPaidDays = raw.filter(Char::isDigit).take(4); customPaidDays.toIntOrNull()?.coerceIn(0,3650)?.let { paidDays = it } },
                    label={Text("Período pago personalizado (dias)")},
                    placeholder={Text("Ex.: 45")},
                    modifier=Modifier.fillMaxWidth(),
                    singleLine=true
                )
                Text("Compensação: +$bonusDays dias",fontWeight=FontWeight.Bold)
                LazyRow(horizontalArrangement=Arrangement.spacedBy(5.dp)){items(listOf(0,1,3,5,7,15,30)){d->FilterChip(selected=bonusDays==d && customBonusDays.isBlank(),onClick={bonusDays=d;customBonusDays=""},label={Text(if(d==0)"Sem bônus" else "+$d")})}}
                OutlinedTextField(
                    customBonusDays,
                    { raw -> customBonusDays = raw.filter(Char::isDigit).take(4); customBonusDays.toIntOrNull()?.coerceIn(0,3650)?.let { bonusDays = it } },
                    label={Text("Compensação personalizada (dias)")},
                    placeholder={Text("Ex.: 12")},
                    modifier=Modifier.fillMaxWidth(),
                    singleLine=true
                )
                OutlinedTextField(reason,{reason=it.take(240)},label={Text("Motivo")},modifier=Modifier.fillMaxWidth())
                Text("Total: ${paidDays+bonusDays} dias",fontWeight=FontWeight.ExtraBold,color=MaterialTheme.colorScheme.primary)
            }},
            confirmButton={Button(onClick={scope.launch{repo.requestPrivilegedAction(ticket.id,ticket.ownerUid,user,"GRANT_PREMIUM",mapOf("tier" to plan,"paidDays" to paidDays,"bonusDays" to bonusDays,"reason" to reason));showPremiumAction=false}}){Text("Confirmar")}},
            dismissButton={TextButton(onClick={showPremiumAction=false}){Text("Cancelar")}}
        )
    }

}

@Composable
private fun ReceiptPreview(url: String) {
    val bitmap by produceState<android.graphics.Bitmap?>(initialValue = null, url) {
        value = withContext(Dispatchers.IO) { runCatching { URL(url).openStream().use(BitmapFactory::decodeStream) }.getOrNull() }
    }
    bitmap?.let {
        androidx.compose.foundation.Image(
            bitmap = it.asImageBitmap(), contentDescription = "Comprovante temporário",
            modifier = Modifier.fillMaxWidth().heightIn(max = 180.dp).padding(top = 6.dp),
            contentScale = ContentScale.Fit
        )
    }
}

private suspend fun com.google.android.gms.tasks.Task<com.google.firebase.auth.GetTokenResult>.awaitSupportToken(): com.google.firebase.auth.GetTokenResult =
    suspendCancellableCoroutine { c -> addOnCompleteListener { if (!c.isActive) return@addOnCompleteListener; if (it.isSuccessful) c.resume(it.result) else c.resumeWithException(it.exception ?: IllegalStateException("Falha ao renovar sessão")) } }

private suspend fun com.google.android.gms.tasks.Task<DataSnapshot>.awaitSupportSnapshot(): DataSnapshot =
    suspendCancellableCoroutine { c -> addOnCompleteListener { if (!c.isActive) return@addOnCompleteListener; if (it.isSuccessful) c.resume(it.result) else c.resumeWithException(it.exception ?: IllegalStateException("Falha Firebase")) } }

private suspend fun com.google.android.gms.tasks.Task<Void>.awaitCompletion() {
    suspendCancellableCoroutine<Unit> { c -> addOnCompleteListener { if (!c.isActive) return@addOnCompleteListener; if (it.isSuccessful) c.resume(Unit) else c.resumeWithException(it.exception ?: IllegalStateException("Falha Firebase")) } }
}
private suspend fun com.google.android.gms.tasks.Task<com.google.firebase.storage.UploadTask.TaskSnapshot>.awaitStorage() {
    suspendCancellableCoroutine<Unit> { c -> addOnCompleteListener { if (!c.isActive) return@addOnCompleteListener; if (it.isSuccessful) c.resume(Unit) else c.resumeWithException(it.exception ?: IllegalStateException("Falha no envio")) } }
}
private suspend fun com.google.android.gms.tasks.Task<Uri>.awaitUri(): Uri = suspendCancellableCoroutine { c -> addOnCompleteListener { if (!c.isActive) return@addOnCompleteListener; if (it.isSuccessful) c.resume(it.result) else c.resumeWithException(it.exception ?: IllegalStateException("Falha ao obter anexo")) } }
