package com.sonusstudios.streampulse.tools

import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonusstudios.streampulse.core.MembershipTier
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

private data class LrcEditLine(val text: String, val timeMs: Long? = null)
private const val LRC_DRAFT_PREF = "sonus_lrc_editor_draft"
private const val LRC_DRAFT_KEY = "draft"

private fun lrcExportStem(raw: String): String {
    val invalid = setOf('\\', '/', ':', '*', '?', '"', '<', '>', '|')
    val base = raw.substringBeforeLast('.', raw).trim()
    val cleaned = base
        .map { c -> if (c.code < 32 || c in invalid) ' ' else c }
        .joinToString("")
        .replace(Regex("\\s+"), " ")
        .trim()
        .trimEnd('.', ' ')
    return cleaned.take(120).ifBlank { "letra" }
}


@Composable
internal fun LrcEditorTool(
    onBack: () -> Unit,
    ownerAccess: Boolean,
    membershipTier: MembershipTier,
    coins: Int,
    unlimited: Boolean,
    onSpendCoin: suspend () -> Boolean,
    onOwnerSaveLrc: suspend (Long, String) -> Result<Unit>,
    onOpenOwnerSonusMusic: (String) -> Unit,
    onTrack: (String, Boolean?, Long?) -> Unit
) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences(LRC_DRAFT_PREF, 0) }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    var audioUri by remember { mutableStateOf<String?>(null) }
    var audioName by remember { mutableStateOf("Nenhuma música selecionada") }
    var lines by remember { mutableStateOf(listOf<LrcEditLine>()) }
    var pasteText by remember { mutableStateOf("") }
    var currentMs by remember { mutableLongStateOf(0L) }
    var durationMs by remember { mutableLongStateOf(0L) }
    var playing by remember { mutableStateOf(false) }
    var selectedIndex by remember { mutableIntStateOf(0) }
    var message by remember { mutableStateOf<String?>(null) }
    var undo by remember { mutableStateOf<Pair<Int, Long?>?>(null) }
    var showLyricsDialog by remember { mutableStateOf(false) }
    var showOffsetDialog by remember { mutableStateOf(false) }
    var offsetText by remember { mutableStateOf("0") }
    var showDiscardDialog by remember { mutableStateOf(false) }
    var pendingAudioOpen by remember { mutableStateOf(false) }
    var showSaveDialog by remember { mutableStateOf(false) }
    var draftAvailable by remember { mutableStateOf(prefs.contains(LRC_DRAFT_KEY)) }
    var exportPaidThisSession by remember { mutableStateOf(unlimited) }
    var syncMode by remember { mutableStateOf(false) }

    fun buildTxt(): String = lines.filter { it.text.isNotBlank() }.joinToString("\n") { it.text.trim() }
    fun buildLrc(): String = lines.filter { it.text.isNotBlank() }.joinToString("\n") { line ->
        val t = line.timeMs ?: 0L
        val min = t / 60000
        val sec = (t % 60000) / 1000
        val cs = (t % 1000) / 10
        String.format(Locale.US, "[%02d:%02d.%02d]%s", min, sec, cs, line.text.trim())
    }
    fun withExportCoin(action: () -> Unit) {
        if (unlimited || exportPaidThisSession) { action(); return }
        if (coins <= 0) { message = "Você precisa de 1 Moeda SONUS para exportar TXT/LRC."; return }
        scope.launch {
            if (onSpendCoin()) {
                exportPaidThisSession = true
                action()
            } else message = "Não foi possível descontar 1 Moeda SONUS."
        }
    }
    fun saveDraft() {
        if (lines.isEmpty() && pasteText.isBlank()) return
        val obj = JSONObject().apply {
            put("audioUri", audioUri ?: "")
            put("audioName", audioName)
            put("pasteText", pasteText)
            put("selectedIndex", selectedIndex)
            put("syncMode", syncMode)
            put("lines", JSONArray().apply {
                lines.forEach { l -> put(JSONObject().apply { put("text", l.text); if (l.timeMs != null) put("timeMs", l.timeMs) }) }
            })
        }
        prefs.edit().putString(LRC_DRAFT_KEY, obj.toString()).apply()
    }
    fun clearDraft() { prefs.edit().remove(LRC_DRAFT_KEY).apply(); draftAvailable = false }
    fun seek(delta: Long) {
        val p = player ?: return
        val target = (p.currentPosition.toLong() + delta).coerceIn(0L, durationMs.coerceAtLeast(0L))
        p.seekTo(target.toInt()); currentMs = target
    }
    fun mark(index: Int) {
        if (index !in lines.indices) return
        val stamp = player?.currentPosition?.toLong() ?: currentMs
        undo = index to lines[index].timeMs
        lines = lines.toMutableList().also { it[index] = it[index].copy(timeMs = stamp) }
        selectedIndex = (index + 1).coerceAtMost((lines.size - 1).coerceAtLeast(0))
        scope.launch { if (lines.isNotEmpty()) listState.animateScrollToItem((selectedIndex - 2).coerceAtLeast(0)) }
    }
    fun adjustLine(index: Int, delta: Long) {
        if (index !in lines.indices) return
        val old = lines[index].timeMs ?: return
        undo = index to old
        lines = lines.toMutableList().also { it[index] = it[index].copy(timeMs = (old + delta).coerceAtLeast(0L)) }
    }
    fun insertAfter(index: Int) {
        val mutable = lines.toMutableList(); val at = (index + 1).coerceIn(0, mutable.size)
        mutable.add(at, LrcEditLine("")); lines = mutable; selectedIndex = at
        scope.launch { listState.animateScrollToItem(at) }
    }
    fun deleteSelected() {
        if (selectedIndex !in lines.indices) return
        val mutable = lines.toMutableList(); mutable.removeAt(selectedIndex); lines = mutable
        selectedIndex = selectedIndex.coerceAtMost((lines.size - 1).coerceAtLeast(0))
    }
    fun applyLyrics(text: String, announce: Boolean = true): Int {
        val newTexts = text.lines().map { it.trim() }.filter { it.isNotBlank() }
        val oldByText = lines.groupBy { it.text }.mapValues { it.value.toMutableList() }
        lines = newTexts.map { txt ->
            oldByText[txt]?.let { bucket -> if (bucket.isNotEmpty()) bucket.removeAt(0) else null } ?: LrcEditLine(txt)
        }
        pasteText = text
        selectedIndex = lines.indexOfFirst { it.timeMs == null }.let { if (it < 0) 0 else it }
        if (announce) message = "${lines.size} linhas preparadas automaticamente."
        return lines.size
    }
    fun openUri(uri: Uri) {
        runCatching {
            player?.release()
            MediaPlayer.create(context, uri).also { mp ->
                player = mp; durationMs = mp.duration.toLong(); currentMs = 0L; playing = false
                mp.setOnCompletionListener { playing = false; currentMs = durationMs }
            }
            audioUri = uri.toString()
            audioName = runCatching {
                context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(android.provider.OpenableColumns.DISPLAY_NAME)) else null
                }
            }.getOrNull()?.substringBeforeLast('.')?.takeIf { it.isNotBlank() } ?: uri.lastPathSegment?.substringAfterLast('/') ?: "Música selecionada"
        }.onFailure { message = "Não foi possível abrir a música." }
    }

    val openAudio = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri ?: return@rememberLauncherForActivityResult
        runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        openUri(uri)
    }
    fun requestAudio() {
        if (lines.any { it.timeMs != null } || pasteText.isNotBlank()) { pendingAudioOpen = true; showDiscardDialog = true }
        else openAudio.launch(arrayOf("audio/*"))
    }
    val exportLrc = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/x-lrc")) { uri: Uri? ->
        uri ?: return@rememberLauncherForActivityResult
        runCatching { context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(buildLrc()) } }
            .onSuccess { message = "LRC salvo com sucesso."; onTrack("Editor LRC", true, null) }
            .onFailure { message = "Não foi possível salvar o LRC."; onTrack("Editor LRC", false, null) }
    }
    val exportTxt = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri: Uri? ->
        uri ?: return@rememberLauncherForActivityResult
        runCatching { context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(buildTxt()) } }
            .onSuccess { message = "TXT salvo com sucesso."; onTrack("Editor LRC", true, null) }
            .onFailure { message = "Não foi possível salvar o TXT."; onTrack("Editor LRC", false, null) }
    }

    fun restoreDraft() {
        prefs.getString(LRC_DRAFT_KEY, null)?.let { raw ->
            runCatching {
                val obj = JSONObject(raw)
                audioUri = obj.optString("audioUri").ifBlank { null }
                audioName = obj.optString("audioName", audioName)
                pasteText = obj.optString("pasteText", "")
                selectedIndex = obj.optInt("selectedIndex", 0)
                val arr = obj.optJSONArray("lines") ?: JSONArray()
                lines = List(arr.length()) { i -> val x=arr.getJSONObject(i); LrcEditLine(x.optString("text"), if(x.has("timeMs")) x.getLong("timeMs") else null) }
                syncMode = if (obj.has("syncMode")) obj.optBoolean("syncMode", false) else lines.any { it.timeMs != null }
                audioUri?.let { openUri(Uri.parse(it)) }
                message = "Rascunho recuperado."
            }.onFailure { message = "Não foi possível restaurar o rascunho." }
        }
    }
    fun newProject() {
        player?.stop(); player?.release(); player=null; playing=false; currentMs=0L; durationMs=0L
        audioUri=null; audioName="Nenhuma música selecionada"; lines=emptyList(); pasteText=""; selectedIndex=0; syncMode=false; clearDraft(); message=null; exportPaidThisSession=unlimited
    }
    LaunchedEffect(lines, pasteText, audioUri, selectedIndex, syncMode) { delay(350); saveDraft() }
    DisposableEffect(Unit) { onDispose { saveDraft(); player?.release() } }
    LaunchedEffect(player, playing) {
        while (player != null) {
            currentMs = runCatching { player?.currentPosition?.toLong() ?: currentMs }.getOrDefault(currentMs)
            playing = runCatching { player?.isPlaying == true }.getOrDefault(false)
            delay(35)
        }
    }

    if (showLyricsDialog) AlertDialog(
        onDismissRequest = { showLyricsDialog = false },
        title = { Text("Editar / colar letra") },
        text = { OutlinedTextField(value = pasteText, onValueChange = { applyLyrics(it, announce = false) }, modifier = Modifier.fillMaxWidth().heightIn(min = 220.dp), label = { Text("Uma frase por linha") }) },
        confirmButton = { TextButton(onClick = { applyLyrics(pasteText); showLyricsDialog = false }) { Text("Aplicar linhas") } },
        dismissButton = { TextButton(onClick = { showLyricsDialog = false }) { Text("Cancelar") } }
    )
    if (showOffsetDialog) AlertDialog(
        onDismissRequest = { showOffsetDialog = false }, title = { Text("Offset global") },
        text = { OutlinedTextField(value=offsetText, onValueChange={ offsetText=it.filter { c -> c.isDigit() || c=='-' || c=='+' } }, label={Text("Milissegundos (ex.: -300 ou 250)")}, singleLine=true) },
        confirmButton = { TextButton(onClick = { val d=offsetText.toLongOrNull() ?: 0L; lines=lines.map{it.copy(timeMs=it.timeMs?.let{t->(t+d).coerceAtLeast(0L)})}; showOffsetDialog=false; message="Offset aplicado." }) { Text("Aplicar") } },
        dismissButton = { TextButton(onClick={showOffsetDialog=false}){Text("Cancelar")} }
    )
    if (showDiscardDialog) AlertDialog(
        onDismissRequest={showDiscardDialog=false; pendingAudioOpen=false}, title={Text("Há alterações não finalizadas")},
        text={Text("O rascunho atual está salvo. Deseja trocar a música e manter este trabalho, ou limpar o editor?")},
        confirmButton={TextButton(onClick={showDiscardDialog=false; if(pendingAudioOpen){pendingAudioOpen=false; openAudio.launch(arrayOf("audio/*"))}}){Text("Manter e trocar")}},
        dismissButton={Row{TextButton(onClick={clearDraft(); lines=emptyList(); pasteText=""; showDiscardDialog=false; if(pendingAudioOpen){pendingAudioOpen=false; openAudio.launch(arrayOf("audio/*"))}}){Text("Descartar")}; TextButton(onClick={showDiscardDialog=false; pendingAudioOpen=false}){Text("Cancelar")}}}
    )

    if (showSaveDialog) AlertDialog(
        onDismissRequest={showSaveDialog=false},
        title={Text("Salvar letra")},
        text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
            Text("Escolha o destino da letra.")
            Button(onClick={showSaveDialog=false; withExportCoin{exportLrc.launch("${lrcExportStem(audioName)}.lrc")}},modifier=Modifier.fillMaxWidth()){Text(if(unlimited||exportPaidThisSession)"Salvar como LRC" else "Salvar como LRC • 1 moeda")}
            OutlinedButton(onClick={showSaveDialog=false; withExportCoin{exportTxt.launch("${lrcExportStem(audioName)}.txt")}},modifier=Modifier.fillMaxWidth()){Text(if(unlimited||exportPaidThisSession)"Salvar como TXT" else "Salvar como TXT • 1 moeda")}
            if(ownerAccess) Button(onClick={showSaveDialog=false; saveDraft(); onOpenOwnerSonusMusic(buildLrc())},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF397B61))){Text("Adicionar ao SONUS Stream")}
        }},
        confirmButton={}, dismissButton={TextButton(onClick={showSaveDialog=false}){Text("Cancelar")}}
    )

    Scaffold(
        topBar = { Surface(tonalElevation=2.dp) { Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment=Alignment.CenterVertically) {
            Text("‹", style=MaterialTheme.typography.headlineMedium, modifier=Modifier.clickable{onBack()}.padding(end=12.dp))
            Column(Modifier.weight(1f)){Text("Editor LRC",fontWeight=FontWeight.Bold,style=MaterialTheme.typography.titleLarge);Text("Letra • tempo • sincronização",style=MaterialTheme.typography.bodySmall)}
            TextButton(onClick={showSaveDialog=true},enabled=syncMode && lines.isNotEmpty()){Text("SALVAR")}
        } } },
        bottomBar = { Surface(tonalElevation=6.dp) { Row(Modifier.fillMaxWidth().height(104.dp).padding(horizontal=9.dp,vertical=6.dp),verticalAlignment=Alignment.CenterVertically) {
            Box(Modifier.size(62.dp).background(Color(0xFF25272C),RoundedCornerShape(9.dp)),contentAlignment=Alignment.Center){Text("♫",fontSize=27.sp)}
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text(audioName,maxLines=1,style=MaterialTheme.typography.labelMedium,fontWeight=FontWeight.Bold)
                Text("${formatLrcClock(currentMs)} / ${formatLrcClock(durationMs)}",style=MaterialTheme.typography.labelSmall)
                Slider(value=currentMs.toFloat().coerceIn(0f,durationMs.coerceAtLeast(1).toFloat()),onValueChange={v->currentMs=v.toLong();player?.seekTo(v.toInt())},valueRange=0f..durationMs.coerceAtLeast(1).toFloat(),modifier=Modifier.height(28.dp))
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){
                    TextButton(onClick={seek(-1000)},contentPadding=PaddingValues(horizontal=5.dp)){Text("−1s")}
                    TextButton(onClick={seek(-100)},contentPadding=PaddingValues(horizontal=5.dp)){Text("−.1")}
                    FilledIconButton(onClick={player?.let{if(it.isPlaying)it.pause()else it.start();playing=it.isPlaying}},modifier=Modifier.size(38.dp)){Text(if(playing)"Ⅱ" else "▶")}
                    TextButton(onClick={seek(100)},contentPadding=PaddingValues(horizontal=5.dp)){Text("+.1")}
                    TextButton(onClick={seek(1000)},contentPadding=PaddingValues(horizontal=5.dp)){Text("+1s")}
                }
            }
        } } }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).imePadding().padding(horizontal=10.dp)) {
            if (!syncMode) {
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(
                        onClick = { restoreDraft() },
                        enabled = draftAvailable,
                        modifier = Modifier.weight(1f).height(44.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp)
                    ) { Text("Restaurar rascunho", fontSize = 11.sp, maxLines = 1) }
                    OutlinedButton(
                        onClick = { requestAudio() },
                        modifier = Modifier.weight(1f).height(44.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp)
                    ) { Text("Adicionar música", fontSize = 11.sp, maxLines = 1) }
                }
                // A ação principal fica fixa logo abaixo dos dois botões do topo.
                // O campo de letra cresce abaixo dela e nunca consegue encobrir o CTA.
                Button(
                    onClick = {
                        val prepared = applyLyrics(pasteText, announce = false)
                        when {
                            audioUri == null -> message = "Adicione uma música antes de iniciar a sincronização."
                            prepared <= 0 -> message = "Cole a letra antes de iniciar a sincronização."
                            else -> {
                                syncMode = true
                                message = "$prepared linhas prontas para sincronizar."
                            }
                        }
                    },
                    enabled = audioUri != null && lines.isNotEmpty(),
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp).height(50.dp),
                    shape = RoundedCornerShape(14.dp)
                ) { Text("INICIAR SINCRONIZAÇÃO", fontWeight = FontWeight.Black) }
                val detectedLines = lines.size
                OutlinedTextField(
                    value = pasteText,
                    onValueChange = {
                        applyLyrics(it, announce = false)
                        message = null
                    },
                    label = { Text("Cole a letra aqui") },
                    supportingText = {
                        Text(if (detectedLines > 0) "$detectedLines frase(s) separada(s) automaticamente" else "Uma frase por linha")
                    },
                    modifier = Modifier.fillMaxWidth().weight(1f).padding(top = 9.dp),
                    minLines = 5
                )
                message?.let { Text(it, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)) }
                Text("Ao iniciar, o SONUS separa automaticamente as linhas e abre os marcadores de sincronização.",style=MaterialTheme.typography.bodySmall,modifier=Modifier.padding(horizontal=8.dp,vertical=5.dp))
            } else {
                message?.let{Text(it,style=MaterialTheme.typography.labelSmall,modifier=Modifier.padding(vertical=4.dp))}
                Row(Modifier.fillMaxSize()) {
                    LazyColumn(state=listState,modifier=Modifier.weight(1f),contentPadding=PaddingValues(top=68.dp,bottom=120.dp)) {
                        itemsIndexed(lines) { index,line ->
                            val done=line.timeMs!=null; val selected=index==selectedIndex
                            val tint=if(done)Color(0xFF63C98B) else Color(0xFFE56C68)
                            val bg=if(selected) Color(0xFF6B86B8).copy(alpha=.18f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.25f)
                            Surface(modifier=Modifier.fillMaxWidth().padding(vertical=3.dp).then(if(selected)Modifier.border(1.4.dp,Color(0xFF8FAEFF),RoundedCornerShape(11.dp)) else Modifier),shape=RoundedCornerShape(11.dp),color=bg) {
                                Row(Modifier.fillMaxWidth().clickable{selectedIndex=index}.padding(horizontal=7.dp,vertical=8.dp),verticalAlignment=Alignment.CenterVertically) {
                                    Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.width(76.dp)){
                                        Text(line.timeMs?.let(::formatLrcClock)?:"00:00.000",style=MaterialTheme.typography.labelMedium,color=tint,fontWeight=FontWeight.Bold)
                                        Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){
                                            Surface(shape=RoundedCornerShape(8.dp),color=Color.White.copy(alpha=.06f),modifier=Modifier.size(32.dp).clickable(enabled=done){adjustLine(index,-100)}){Box(contentAlignment=Alignment.Center){Text("‹",fontSize=25.sp)}}
                                            Surface(shape=RoundedCornerShape(8.dp),color=Color.White.copy(alpha=.06f),modifier=Modifier.size(32.dp).clickable(enabled=done){adjustLine(index,100)}){Box(contentAlignment=Alignment.Center){Text("›",fontSize=25.sp)}}
                                        }
                                    }
                                    OutlinedTextField(value=line.text,onValueChange={txt->lines=lines.toMutableList().also{it[index]=it[index].copy(text=txt)}},modifier=Modifier.weight(1f),singleLine=false,textStyle=LocalTextStyle.current.copy(color=if(done)Color(0xFFB9E8C9) else MaterialTheme.colorScheme.onSurface),colors=OutlinedTextFieldDefaults.colors(unfocusedBorderColor=Color.Transparent,focusedBorderColor=Color.Transparent))
                                    Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.width(48.dp)){
                                        Text("＋",fontSize=24.sp,modifier=Modifier.size(42.dp).clickable{insertAfter(index)}.wrapContentSize(Alignment.Center))
                                        ClockMarkButton(tint=tint,size=42.dp){selectedIndex=index;mark(index)}
                                    }
                                }
                            }
                        }
                    }
                    Spacer(Modifier.width(6.dp))
                    Surface(modifier=Modifier.width(58.dp).fillMaxHeight().padding(vertical=4.dp),shape=RoundedCornerShape(18.dp),color=Color(0xFF292B31)) {
                        Column(Modifier.fillMaxSize().padding(vertical=7.dp),horizontalAlignment=Alignment.CenterHorizontally) {
                            SideTool("♫"){requestAudio()}
                            SideTool("✎"){showLyricsDialog=true}
                            SideTool("＋"){insertAfter(selectedIndex)}
                            SideTool("−"){deleteSelected()}
                            SideTool("±"){showOffsetDialog=true}
                            SideTool("⌫"){newProject()}
                            Spacer(Modifier.weight(1f))
                            ClockMarkButton(tint=Color(0xFF68C990),size=52.dp,filled=true,enabled=player!=null&&selectedIndex in lines.indices){if(selectedIndex in lines.indices)mark(selectedIndex)}
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ClockMarkButton(tint:Color,size:androidx.compose.ui.unit.Dp,filled:Boolean=false,enabled:Boolean=true,onClick:()->Unit){
    Surface(shape=RoundedCornerShape(if(filled)14.dp else 12.dp),color=if(filled)tint.copy(alpha=.28f) else Color.Transparent,modifier=Modifier.size(size).clickable(enabled=enabled,onClick=onClick)){
        Canvas(Modifier.fillMaxSize().padding(8.dp)){
            val c=Offset(this.size.width/2f,this.size.height/2f+1f);val r=minOf(this.size.width,this.size.height)*.34f
            drawCircle(if(enabled)tint else Color.Gray,r,c,style=Stroke(width=2.7f))
            drawLine(if(enabled)tint else Color.Gray,Offset(c.x,c.y-r),Offset(c.x,c.y-r-4f),strokeWidth=2.7f)
            drawLine(if(enabled)tint else Color.Gray,Offset(c.x-5f,c.y-r-4f),Offset(c.x+5f,c.y-r-4f),strokeWidth=2.7f)
            drawLine(if(enabled)tint else Color.Gray,c,Offset(c.x,c.y-r*.58f),strokeWidth=2.7f)
            drawLine(if(enabled)tint else Color.Gray,c,Offset(c.x+r*.52f,c.y+r*.18f),strokeWidth=2.7f)
            drawLine(if(enabled)tint else Color.Gray,Offset(c.x-r*.62f,c.y-r*.70f),Offset(c.x-r*.92f,c.y-r*.98f),strokeWidth=2.5f)
            drawLine(if(enabled)tint else Color.Gray,Offset(c.x+r*.62f,c.y-r*.70f),Offset(c.x+r*.92f,c.y-r*.98f),strokeWidth=2.5f)
        }
    }
}

@Composable
private fun SideTool(symbol:String, enabled:Boolean=true, action:()->Unit){
    Text(symbol,style=MaterialTheme.typography.titleLarge,color=if(enabled)Color.White else Color.Gray,modifier=Modifier.padding(vertical=5.dp).size(38.dp).clickable(enabled=enabled,onClick=action).wrapContentSize(Alignment.Center))
}

private fun formatLrcClock(ms:Long):String{val safe=ms.coerceAtLeast(0L);val m=safe/60000;val s=(safe%60000)/1000;val milli=safe%1000;return String.format(Locale.US,"%02d:%02d.%03d",m,s,milli)}
