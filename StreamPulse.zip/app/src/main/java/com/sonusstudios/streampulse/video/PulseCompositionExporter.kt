package com.sonusstudios.streampulse.video

import android.content.ContentValues
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import com.sonusstudios.streampulse.audio.AudioAnalysis
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.ChannelMixingAudioProcessor
import androidx.media3.common.audio.ChannelMixingMatrix
import androidx.media3.common.audio.DefaultGainProvider
import androidx.media3.common.audio.GainProcessor
import androidx.media3.common.audio.SpeedProvider
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.OverlaySettings
import androidx.media3.common.VideoCompositorSettings
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.common.util.Size
import androidx.media3.effect.AlphaScale
import androidx.media3.effect.Brightness
import androidx.media3.effect.CanvasOverlay
import androidx.media3.effect.GlEffect
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.effect.RgbFilter
import androidx.media3.effect.RgbAdjustment
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.effect.MatrixTransformation
import androidx.media3.effect.TextOverlay
import androidx.media3.effect.TimestampWrapper
import androidx.media3.effect.StaticOverlaySettings
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale
import kotlin.coroutines.resume
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/**
 * Exportador compartilhado de composição SONUS. A mesma configuração de projeto (canvas, fit,
 * cor, overlay, efeito e visualizer) é congelada antes do render. Nada aqui lê
 * estado visual de Compose durante a exportação.
 */
@UnstableApi
object PulseCompositionExporter {
    data class Visual(
        val uri: Uri,
        val isImage: Boolean,
        val durationMs: Long,
        val trimStartMs: Long,
        val trimEndMs: Long,
        val speed: Float = 1f,
        val rotation: Float = 0f,
        val scale: Float = 1f,
        val offsetX: Float = 0f,
        val offsetY: Float = 0f,
        val flipX: Boolean = false,
        val volume: Float = 1f,
        val effectName: String = "Nenhum",
        val filterName: String = "Original",
        val animationIn: String = "Nenhum",
        val animationOut: String = "Nenhum"
    )

    data class Audio(
        val uri: Uri,
        val trimStartMs: Long,
        val trimEndMs: Long,
        val timelineStartMs: Long = 0L,
        val volume: Float = 1f,
        val fadeInMs: Long = 0L,
        val fadeOutMs: Long = 0L
    )

    data class Grade(
        val brightness: Float = 0f,
        val exposure: Float = 0f,
        val saturation: Float = 0f,
        val contrast: Float = 0f,
        val temperature: Float = 0f,
        val tint: Float = 0f,
        val highlights: Float = 0f,
        val whites: Float = 0f,
        val blacks: Float = 0f,
        val shadows: Float = 0f,
        val sharpen: Float = 0f,
        val fade: Float = 0f,
        val vignette: Float = 0f,
        val grain: Float = 0f,
        val opacity: Float = 1f,
        val filter: String = "Original"
    )

    data class TextLayer(
        val text: String,
        val colorArgb: Int,
        val startMs: Long,
        val endMs: Long,
        val presetName: String = "SONUS Sans",
        val fontSize: Float = 48f,
        val scale: Float = 1f,
        val rotation: Float = 0f,
        val opacity: Float = 1f,
        val positionX: Float = 0f,
        val positionY: Float = 0f,
        val strokeWidth: Float = 0f,
        val strokeColorArgb: Int = Color.BLACK,
        val backgroundColorArgb: Int = Color.TRANSPARENT,
        val shadowEnabled: Boolean = true,
        val glowRadius: Float = 0f,
        val alignment: String = "CENTER",
        val fontFamilyName: String = "sans-serif",
        val fontWeight: Int = 400,
        val italic: Boolean = false,
        val letterSpacing: Float = 0f,
        val lineHeightScale: Float = 1.12f,
        val customFontPath: String = "",
        val autoFitSafeWidth: Boolean = false,
        val maxWidthFraction: Float = .90f,
        val entryAnimation: String = "Fade In",
        val exitAnimation: String = "Fade Out",
        val loopAnimation: String = "Nenhum"
    )

    data class MediaOverlay(
        val uri: Uri,
        val isImage: Boolean,
        val startMs: Long = 0L,
        val endMs: Long = Long.MAX_VALUE,
        val scale: Float = 1f,
        val rotation: Float = 0f,
        val opacity: Float = 1f,
        val positionX: Float = 0f,
        val positionY: Float = 0f,
        val effectName: String = "Nenhum",
        val loop: Boolean = false,
        val fullFrame: Boolean = false
    )

    data class VisualizerLayer(
        val enabled: Boolean,
        val style: String,
        val intensity: Float,
        val multicolor: Boolean,
        val analysis: AudioAnalysis?,
        val audioTimelineStartMs: Long,
        val audioTrimStartMs: Long,
        val audioEndMs: Long
    )

    data class ExportSummary(
        val uri: Uri,
        val width: Int,
        val height: Int,
        val durationMs: Long,
        val codec: String,
        val hdrRequested: Boolean,
        val fileBytes: Long
    )

    data class Progress(
        val percent: Int,
        val phase: String
    )

    suspend fun export(
        context: Context,
        visuals: List<Visual>,
        audios: List<Audio>,
        outputName: String,
        fps: Int,
        codec: String,
        keepHdr: Boolean,
        canvasWidth: Int,
        canvasHeight: Int,
        fillCrop: Boolean,
        bitrateMbps: Int,
        grade: Grade,
        selectedEffect: String,
        effectStartMs: Long = 0L,
        effectEndMs: Long = Long.MAX_VALUE,
        filterStartMs: Long = 0L,
        filterEndMs: Long = Long.MAX_VALUE,
        muteOriginalMedia: Boolean = false,
        textLayers: List<TextLayer>,
        mediaOverlay: MediaOverlay?,
        extraMediaOverlays: List<MediaOverlay> = emptyList(),
        visualizer: VisualizerLayer?,
        onProgress: (Progress) -> Unit = {}
    ): Result<ExportSummary> = withContext(Dispatchers.Main) {
        runCatching {
            require(visuals.isNotEmpty()) { "Adicione pelo menos uma foto ou vídeo" }
            require(canvasWidth > 0 && canvasHeight > 0) { "Canvas inválido" }

            onProgress(Progress(0, "Preparando"))
            val layout = if (fillCrop) Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP else Presentation.LAYOUT_SCALE_TO_FIT
            val presentation = Presentation.createForWidthAndHeight(canvasWidth, canvasHeight, layout)

            var visualTimelineStartMs = 0L
            val editedVisuals = visuals.map { visual ->
                val clipStartMs = visualTimelineStartMs
                visualTimelineStartMs += visual.durationMs.coerceAtLeast(1L)
                val mediaBuilder = MediaItem.Builder().setUri(visual.uri)
                if (visual.isImage) {
                    mediaBuilder.setImageDurationMs(visual.durationMs.coerceAtLeast(350L))
                } else if (visual.trimEndMs > visual.trimStartMs) {
                    mediaBuilder.setClippingConfiguration(
                        MediaItem.ClippingConfiguration.Builder()
                            .setStartPositionMs(visual.trimStartMs.coerceAtLeast(0L))
                            .setEndPositionMs(visual.trimEndMs)
                            .build()
                    )
                }
                EditedMediaItem.Builder(mediaBuilder.build()).apply {
                    if (visual.isImage) setFrameRate(fps.coerceIn(24, 120))
                    if (!visual.isImage && kotlin.math.abs(visual.speed - 1f) > 0.001f) {
                        setSpeed(ConstantSpeedProvider(visual.speed))
                    }
                    val clipEffects = mutableListOf<Effect>()
                    val sx = visual.scale.coerceIn(.1f, 6f) * if (visual.flipX) -1f else 1f
                    val sy = visual.scale.coerceIn(.1f, 6f)
                    if (sx != 1f || sy != 1f || visual.rotation != 0f) {
                        clipEffects += ScaleAndRotateTransformation.Builder().setScale(sx, sy).setRotationDegrees(visual.rotation).build()
                    }
                    if (visual.offsetX != 0f || visual.offsetY != 0f) {
                        clipEffects += MatrixTransformation {
                            android.graphics.Matrix().apply { postTranslate(visual.offsetX.coerceIn(-1.5f,1.5f), -visual.offsetY.coerceIn(-1.5f,1.5f)) }
                        }
                    }
                    // Per-clip visual treatment is the source of truth for both preview and export.
                    if (visual.filterName != "Original") {
                        clipEffects += SonusGradeFxFactory.filter(
                            visual.filterName,
                            runCatching { PulseVideoPresetCatalog.filter(context, visual.filterName) }.getOrNull()
                        )
                    }
                    clipEffects += SonusVideoFxFactory.effectStackFor(visual.effectName)
                    clipEffects += SonusVideoFxFactory.clipAnimationEffects(
                        visual.animationIn,
                        visual.animationOut,
                        visual.durationMs,
                        clipStartMs
                    )
                    clipEffects += presentation
                    val visualAudioProcessors = mutableListOf<AudioProcessor>()
                    val visualVolume = if (muteOriginalMedia) 0f else visual.volume.coerceIn(0f, 1.5f)
                    if (!visual.isImage && kotlin.math.abs(visualVolume - 1f) > 0.001f) {
                        val mixing = ChannelMixingAudioProcessor()
                        for (channelCount in 1..8) {
                            val coefficients = FloatArray(channelCount * channelCount)
                            for (channel in 0 until channelCount) {
                                coefficients[channel * channelCount + channel] = visualVolume
                            }
                            mixing.putChannelMixingMatrix(ChannelMixingMatrix(channelCount, channelCount, coefficients))
                        }
                        visualAudioProcessors += mixing
                    }
                    setEffects(Effects(visualAudioProcessors, clipEffects))
                }.build()
            }
            val visualSequence = EditedMediaItemSequence.withAudioAndVideoFrom(editedVisuals)
            val sequences = mutableListOf<EditedMediaItemSequence>()
            val projectDurationMs = visuals.sumOf { it.durationMs.coerceAtLeast(1L) }.coerceAtLeast(1L)
            val mediaOverlays = buildList {
                mediaOverlay?.let(::add)
                addAll(extraMediaOverlays)
            }.filter { it.endMs > it.startMs }
            mediaOverlays.forEach { overlay ->
                val overlayStart = overlay.startMs.coerceIn(0L, projectDurationMs)
                val overlayEnd = overlay.endMs.coerceIn(overlayStart + 1L, projectDurationMs)
                val overlayDuration = (overlayEnd - overlayStart).coerceAtLeast(1L)
                val overlayBuilder = MediaItem.Builder().setUri(overlay.uri)
                if (overlay.isImage) {
                    overlayBuilder.setImageDurationMs(overlayDuration)
                } else if (!overlay.loop) {
                    overlayBuilder.setClippingConfiguration(
                        MediaItem.ClippingConfiguration.Builder().setStartPositionMs(0L).setEndPositionMs(overlayDuration).build()
                    )
                }
                val overlayEffects = mutableListOf<Effect>()
                overlay.effectName.takeIf { it != "Nenhum" }?.let { SonusVideoFxFactory.effectFor(it) }?.let(overlayEffects::add)
                overlayEffects += presentation
                val overlayItem = EditedMediaItem.Builder(overlayBuilder.build()).apply {
                    setRemoveAudio(true)
                    if (overlay.isImage) setFrameRate(fps.coerceIn(24,120))
                    setEffects(Effects(emptyList(), overlayEffects))
                }.build()
                val overlaySequenceBuilder = EditedMediaItemSequence.Builder(setOf(C.TRACK_TYPE_VIDEO))
                if (overlayStart > 0L) overlaySequenceBuilder.addGap(overlayStart * 1000L)
                overlaySequenceBuilder.addItem(overlayItem)
                if (!overlay.loop && overlayEnd < projectDurationMs) overlaySequenceBuilder.addGap((projectDurationMs - overlayEnd) * 1000L)
                sequences += overlaySequenceBuilder.setIsLooping(overlay.loop).build()
            }
            sequences += visualSequence

            audios.forEach { a ->
                val audioItemBuilder = MediaItem.Builder().setUri(a.uri)
                if (a.trimEndMs > a.trimStartMs) {
                    audioItemBuilder.setClippingConfiguration(
                        MediaItem.ClippingConfiguration.Builder()
                            .setStartPositionMs(a.trimStartMs.coerceAtLeast(0L))
                            .setEndPositionMs(a.trimEndMs)
                            .build()
                    )
                }
                val audioProcessors = mutableListOf<AudioProcessor>()
                val volume = a.volume.coerceIn(0f, 1.5f)
                if (kotlin.math.abs(volume - 1f) > 0.001f) {
                    val mixing = ChannelMixingAudioProcessor()
                    for (channelCount in 1..8) {
                        // createForConstantGain() in Media3 1.11.0 only supports 1-2 channels.
                        // Build a diagonal matrix so volume scaling also works safely for multichannel audio.
                        val coefficients = FloatArray(channelCount * channelCount)
                        for (channel in 0 until channelCount) coefficients[channel * channelCount + channel] = volume
                        mixing.putChannelMixingMatrix(ChannelMixingMatrix(channelCount, channelCount, coefficients))
                    }
                    audioProcessors += mixing
                }
                val clipDurationMs = (a.trimEndMs - a.trimStartMs).coerceAtLeast(1L)
                val fadeIn = a.fadeInMs.coerceIn(0L, clipDurationMs / 2)
                val fadeOut = a.fadeOutMs.coerceIn(0L, clipDurationMs / 2)
                if (fadeIn > 0L || fadeOut > 0L) {
                    val gain = DefaultGainProvider.Builder(1f).apply {
                        if (fadeIn > 0L) addFadeAt(0L, fadeIn * 1000L, DefaultGainProvider.FADE_IN_LINEAR)
                        if (fadeOut > 0L) addFadeAt((clipDurationMs - fadeOut) * 1000L, fadeOut * 1000L, DefaultGainProvider.FADE_OUT_LINEAR)
                    }.build()
                    audioProcessors += GainProcessor(gain)
                }
                val editedAudio = EditedMediaItem.Builder(audioItemBuilder.build())
                    .setEffects(Effects(audioProcessors, emptyList()))
                    .build()
                val audioSequenceBuilder = EditedMediaItemSequence.Builder(setOf(C.TRACK_TYPE_AUDIO))
                if (a.timelineStartMs > 0L) audioSequenceBuilder.addGap(a.timelineStartMs * 1000L)
                audioSequenceBuilder.addItem(editedAudio).setIsLooping(false)
                sequences += audioSequenceBuilder.build()
            }

            val compositionEffects = buildCompositionEffects(
                grade = grade,
                filterPreset = PulseVideoPresetCatalog.filter(context, grade.filter),
                selectedEffect = selectedEffect,
                effectStartMs = effectStartMs, effectEndMs = effectEndMs,
                filterStartMs = filterStartMs, filterEndMs = filterEndMs,
                textLayers = textLayers,
                visualizer = visualizer
            )

            val compositionBuilder = Composition.Builder(sequences.toList())
                .setEffects(Effects(emptyList(), compositionEffects))
            if (mediaOverlays.isNotEmpty()) {
                compositionBuilder.setVideoCompositorSettings(
                    SonusMultiOverlayCompositorSettings(canvasWidth, canvasHeight, mediaOverlays)
                )
            }
            if (!keepHdr && Build.VERSION.SDK_INT >= 29) {
                compositionBuilder.setHdrMode(Composition.HDR_MODE_TONE_MAP_HDR_TO_SDR_USING_OPEN_GL)
            } else if (keepHdr) {
                compositionBuilder.setHdrMode(Composition.HDR_MODE_KEEP_HDR)
            }
            val composition = compositionBuilder.build()

            val temp = File(context.cacheDir, "pulse_export_${System.currentTimeMillis()}.mp4")
            if (temp.exists()) temp.delete()

            val rendered = suspendCancellableCoroutine<Result<File>> { cont ->
                val handler = Handler(Looper.getMainLooper())
                lateinit var transformer: Transformer
                val poll = object : Runnable {
                    override fun run() {
                        if (!cont.isActive) return
                        runCatching {
                            val holder = ProgressHolder()
                            val state = transformer.getProgress(holder)
                            if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                                onProgress(Progress(holder.progress.coerceIn(0, 99), "Renderizando"))
                            }
                        }
                        handler.postDelayed(this, 180L)
                    }
                }
                val listener = object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, result: ExportResult) {
                        handler.removeCallbacks(poll)
                        onProgress(Progress(99, "Finalizando"))
                        if (cont.isActive) cont.resume(Result.success(temp))
                    }
                    override fun onError(composition: Composition, result: ExportResult, exception: ExportException) {
                        handler.removeCallbacks(poll)
                        if (cont.isActive) cont.resume(Result.failure(exception))
                    }
                }
                val encoderFactory = DefaultEncoderFactory.Builder(context)
                    .setEnableFallback(true)
                    .setRequestedVideoEncoderSettings(
                        VideoEncoderSettings.Builder().setBitrate((bitrateMbps.coerceAtLeast(2) * 1_000_000)).build()
                    )
                    .build()
                val builder = Transformer.Builder(context)
                    .setAudioMimeType(MimeTypes.AUDIO_AAC)
                    .setEncoderFactory(encoderFactory)
                    .addListener(listener)
                when (codec.uppercase()) {
                    "HEVC", "H.265", "H265" -> builder.setVideoMimeType(MimeTypes.VIDEO_H265)
                    else -> builder.setVideoMimeType(MimeTypes.VIDEO_H264)
                }
                transformer = builder.build()
                cont.invokeOnCancellation {
                    handler.removeCallbacks(poll)
                    runCatching { transformer.cancel() }
                }
                transformer.start(composition, temp.absolutePath)
                handler.post(poll)
            }.getOrThrow()

            val inspected = inspectFile(rendered)
            if (inspected.first <= 0 || inspected.second <= 0) error("O arquivo foi criado, mas a resolução final não pôde ser validada")
            // A validação permanece ativa: não escondemos bug de orientação/tamanho.
            // O encoder pode arredondar no máximo dois pixels; qualquer desvio maior falha a exportação.
            val expectedRatio = canvasWidth.toDouble() / canvasHeight.toDouble()
            val actualRatio = inspected.first.toDouble() / inspected.second.toDouble()
            val sizeMismatch = abs(inspected.first - canvasWidth) > 2 || abs(inspected.second - canvasHeight) > 2
            if (sizeMismatch || abs(expectedRatio - actualRatio) > 0.01) {
                error("A exportação não respeitou o canvas ${canvasWidth}x${canvasHeight} (resultado ${inspected.first}x${inspected.second})")
            }

            val outUri = withContext(Dispatchers.IO) {
                val resolver = context.contentResolver
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, outputName.removeSuffix(".mp4") + ".mp4")
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    if (Build.VERSION.SDK_INT >= 29) {
                        put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/SONUS Edit")
                        put(MediaStore.Video.Media.IS_PENDING, 1)
                    }
                }
                val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                    ?: error("Não foi possível criar o arquivo final")
                try {
                    resolver.openOutputStream(uri, "w")!!.use { output -> rendered.inputStream().use { it.copyTo(output, 1024 * 1024) } }
                    if (Build.VERSION.SDK_INT >= 29) resolver.update(uri, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
                    uri
                } catch (t: Throwable) {
                    resolver.delete(uri, null, null)
                    throw t
                }
            }
            val bytes = rendered.length()
            rendered.delete()
            onProgress(Progress(100, "Concluído"))
            ExportSummary(outUri, inspected.first, inspected.second, inspected.third, codec, keepHdr, bytes)
        }
    }

    private fun buildCompositionEffects(
        grade: Grade,
        filterPreset: PulseVideoPresetCatalog.FilterPreset?,
        selectedEffect: String,
        effectStartMs: Long, effectEndMs: Long,
        filterStartMs: Long, filterEndMs: Long,
        textLayers: List<TextLayer>,
        visualizer: VisualizerLayer?
    ): List<Effect> {
        val effects = SonusGradeFxFactory.global(
            brightness = grade.brightness, exposure = grade.exposure, saturation = grade.saturation, contrast = grade.contrast,
            temperature = grade.temperature, tint = grade.tint, highlights = grade.highlights, whites = grade.whites, blacks = grade.blacks, shadows = grade.shadows,
            sharpen = grade.sharpen, fade = grade.fade, vignette = grade.vignette, grain = grade.grain, opacity = grade.opacity
        ).toMutableList()
        val filterEffects = SonusGradeFxFactory.filter(grade.filter, filterPreset)

        fun addTimed(list: List<Effect>, startMs: Long, endMs: Long) {
            if (list.isEmpty()) return
            val startUs = startMs.coerceAtLeast(0L) * 1000L
            val endUs = endMs.coerceAtLeast(startMs + 1L) * 1000L
            list.forEach { effect ->
                if (effect is GlEffect && endUs > startUs) effects += TimestampWrapper(effect, startUs, endUs)
                else effects += effect
            }
        }
        if (grade.filter != "Original") addTimed(filterEffects, filterStartMs, filterEndMs)

        if (selectedEffect != "Nenhum") {
            addTimed(SonusVideoFxFactory.effectStackFor(selectedEffect), effectStartMs, effectEndMs)
        }
        textLayers.filter { it.text.isNotBlank() && it.endMs > it.startMs }.forEach { layer ->
            val overlay = OverlayEffect(listOf(SonusTextCanvasOverlay(layer)))
            effects += TimestampWrapper(overlay, layer.startMs * 1000L, layer.endMs * 1000L)
        }
        visualizer?.takeIf { it.enabled && it.analysis?.frames?.isNotEmpty() == true }?.let { layer ->
            effects += OverlayEffect(listOf(PulseVisualizerOverlay(layer)))
        }
        return effects
    }


    private data class FilterTuning(
        val brightness: Float = 0f, val exposure: Float = 0f, val contrast: Float = 0f,
        val saturation: Float = 0f, val temperature: Float = 0f, val tint: Float = 0f,
        val shadows: Float = 0f, val highlights: Float = 0f, val sharpen: Float = 0f,
        val fade: Float = 0f, val vignette: Float = 0f, val grain: Float = 0f
    )

    private fun filterTuning(name: String): FilterTuning = when (name.lowercase()) {
        "warm tone", "warm" -> FilterTuning(temperature=.32f, saturation=.08f)
        "cool tone", "cool" -> FilterTuning(temperature=-.30f, saturation=.04f)
        "cyberpunk" -> FilterTuning(contrast=.18f, saturation=.26f, tint=.20f, shadows=-.08f)
        "noir" -> FilterTuning(contrast=.28f, shadows=-.18f, highlights=.08f, vignette=.28f)
        "sepia" -> FilterTuning(temperature=.18f, saturation=-.18f, contrast=.05f)
        "invert" -> FilterTuning()
        "posterize" -> FilterTuning(contrast=.08f, saturation=.12f)
        "faded" -> FilterTuning(contrast=-.16f, saturation=-.12f, fade=.45f)
        "teal & orange" -> FilterTuning(contrast=.16f, saturation=.14f, temperature=.12f, tint=-.10f)
        "golden" -> FilterTuning(exposure=.08f, temperature=.26f, saturation=.12f)
        "blue hour" -> FilterTuning(exposure=-.06f, temperature=-.35f, tint=.08f, saturation=-.05f)
        "moody" -> FilterTuning(exposure=-.10f, contrast=.22f, saturation=-.12f, shadows=-.18f, vignette=.20f)
        "clean" -> FilterTuning(exposure=.08f, contrast=.05f, saturation=.03f, sharpen=.12f)
        "bright" -> FilterTuning(exposure=.18f, brightness=.06f, saturation=.06f)
        "vintage" -> FilterTuning(contrast=-.08f, saturation=-.14f, temperature=.16f, fade=.25f, grain=.18f, vignette=.16f)
        "retro" -> FilterTuning(contrast=.04f, saturation=-.08f, temperature=.12f, grain=.22f)
        "cinema", "cinemático" -> FilterTuning(contrast=.20f, saturation=.06f, shadows=-.10f, highlights=-.08f, vignette=.16f)
        "night", "cidade noturna" -> FilterTuning(exposure=-.12f, contrast=.18f, temperature=-.24f, saturation=.08f, highlights=-.18f)
        "neon", "neon pop" -> FilterTuning(contrast=.16f, saturation=.32f, sharpen=.10f)
        else -> FilterTuning()
    }

    private class ConstantSpeedProvider(speed: Float) : SpeedProvider {
        private val value = speed.coerceIn(0.25f, 4f)
        override fun getSpeed(timeUs: Long): Float = value
        override fun getNextSpeedChangeTimeUs(timeUs: Long): Long = C.TIME_UNSET
    }

    private fun inspectFile(file: File): Triple<Int, Int, Long> {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(file.absolutePath)
            val rawW = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            val rawH = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rotation = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull()?.let { Math.floorMod(it,360) } ?: 0
            val (w,h) = if(rotation==90 || rotation==270) rawH to rawW else rawW to rawH
            val duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            Triple(w, h, duration)
        } finally { runCatching { retriever.release() } }
    }


    private class SonusMultiOverlayCompositorSettings(
        private val outputWidth: Int,
        private val outputHeight: Int,
        private val overlays: List<MediaOverlay>
    ) : VideoCompositorSettings {
        override fun getOutputSize(inputSizes: List<Size>): Size = Size(outputWidth, outputHeight)

        override fun getOverlaySettings(inputId: Int, presentationTimeUs: Long): OverlaySettings {
            val overlay = overlays.getOrNull(inputId) ?: return StaticOverlaySettings.Builder().build()
            val scale = if (overlay.fullFrame) 1f else (.35f * overlay.scale.coerceIn(.2f,5f)).coerceIn(.07f,1.75f)
            return StaticOverlaySettings.Builder()
                .setAlphaScale(overlay.opacity.coerceIn(0f,1f))
                .setScale(scale, scale)
                .setOverlayFrameAnchor(0f,0f)
                .setBackgroundFrameAnchor(overlay.positionX.coerceIn(-1f,1f), -overlay.positionY.coerceIn(-1f,1f))
                .setRotationDegrees(overlay.rotation)
                .build()
        }
    }

    private data class ExportTextAnimFrame(
        val alpha: Float = 1f,
        val scale: Float = 1f,
        val x: Float = 0f,
        val y: Float = 0f,
        val rotation: Float = 0f
    )

    /**
     * Renderizador de texto SONUS usado diretamente no pipeline Media3.
     * A mesma geometria/estilo salva no projeto é aplicada no arquivo final para
     * reduzir diferenças entre preview e exportação.
     */
    private class SonusTextCanvasOverlay(private val layer: TextLayer) : CanvasOverlay(true) {
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG)
        private val stroke = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG)
        private val background = Paint(Paint.ANTI_ALIAS_FLAG)
        private val resolvedTypeface by lazy { resolveTypeface(layer) }

        override fun onDraw(canvas: Canvas, presentationTimeUs: Long) {
            canvas.drawColor(Color.TRANSPARENT, android.graphics.PorterDuff.Mode.CLEAR)
            val globalMs = presentationTimeUs / 1000L
            val durationMs = (layer.endMs - layer.startMs).coerceAtLeast(1L)
            val localMs = (globalMs - layer.startMs).coerceIn(0L, durationMs)
            val frame = exportTextAnimationFrame(localMs, durationMs, layer.entryAnimation, layer.exitAnimation, layer.loopAnimation)
            val text = visibleText(layer.text, localMs, layer.entryAnimation)
            if (text.isBlank()) return

            val canvasW = canvas.width.toFloat().coerceAtLeast(1f)
            val canvasH = canvas.height.toFloat().coerceAtLeast(1f)
            var fontPx = layer.fontSize.coerceIn(12f, 160f) * (canvasH / 1080f).coerceIn(.55f, 3.2f)
            val alpha = (255f * layer.opacity.coerceIn(0f, 1f) * frame.alpha).toInt().coerceIn(0, 255)
            if (alpha <= 0) return

            fill.reset()
            fill.isAntiAlias = true
            fill.isSubpixelText = true
            fill.typeface = resolvedTypeface
            fill.textSize = fontPx
            fill.letterSpacing = (layer.letterSpacing / layer.fontSize.coerceAtLeast(1f)).coerceIn(-.20f, .50f)
            val lines = text.split('\n')
            if (layer.autoFitSafeWidth) {
                val allowed = canvasW * layer.maxWidthFraction.coerceIn(.55f,.96f)
                val measured = lines.maxOfOrNull { fill.measureText(it) } ?: 0f
                if (measured > allowed && measured > 0f) {
                    fontPx = (fontPx * (allowed / measured)).coerceAtLeast(10f * (canvasH / 1080f).coerceIn(.55f,3.2f))
                    fill.textSize = fontPx
                }
            }
            fill.textAlign = when (layer.alignment.uppercase(Locale.ROOT)) {
                "LEFT" -> Paint.Align.LEFT
                "RIGHT" -> Paint.Align.RIGHT
                else -> Paint.Align.CENTER
            }
            fill.style = Paint.Style.FILL
            fill.color = applyAlpha(layer.colorArgb, alpha)
            if (layer.shadowEnabled) {
                fill.setShadowLayer((fontPx * .075f).coerceAtLeast(2f), fontPx * .025f, fontPx * .035f, Color.argb((alpha * .72f).toInt().coerceIn(0,255), 0, 0, 0))
            } else fill.clearShadowLayer()

            stroke.set(fill)
            stroke.style = Paint.Style.STROKE
            stroke.strokeJoin = Paint.Join.ROUND
            stroke.strokeCap = Paint.Cap.ROUND
            stroke.strokeWidth = layer.strokeWidth.coerceIn(0f, 12f) * (canvasH / 1080f).coerceIn(.55f, 3.2f)
            stroke.color = applyAlpha(layer.strokeColorArgb, alpha)
            stroke.clearShadowLayer()

            val fm = fill.fontMetrics
            val lineHeight = (fm.descent - fm.ascent) * layer.lineHeightScale.coerceIn(.8f, 2f)
            val maxWidth = lines.maxOfOrNull { fill.measureText(it) } ?: 0f
            val totalHeight = lineHeight * lines.size
            // The editor intentionally allows a small off-canvas range (±1.5) for animated/title layouts.
            // Export must preserve the same coordinates instead of silently clamping to ±1.0.
            val centerX = canvasW * (.5f + layer.positionX.coerceIn(-1.5f,1.5f) * .5f) + frame.x * canvasW / 1080f
            val centerY = canvasH * (.5f + layer.positionY.coerceIn(-1.5f,1.5f) * .5f) + frame.y * canvasH / 1080f

            canvas.save()
            canvas.translate(centerX, centerY)
            canvas.rotate(layer.rotation.coerceIn(-180f,180f) + frame.rotation)
            val totalScale = layer.scale.coerceIn(.2f,5f) * frame.scale.coerceAtLeast(.05f)
            canvas.scale(totalScale, totalScale)

            val bg = layer.backgroundColorArgb
            if (Color.alpha(bg) > 0) {
                val horizontalPad = fontPx * .28f
                val verticalPad = fontPx * .18f
                background.style = Paint.Style.FILL
                background.color = applyAlpha(bg, ((Color.alpha(bg) / 255f) * alpha).toInt().coerceIn(0,255))
                val left = -maxWidth / 2f - horizontalPad
                val top = -totalHeight / 2f - verticalPad
                val right = maxWidth / 2f + horizontalPad
                val bottom = totalHeight / 2f + verticalPad
                canvas.drawRoundRect(left, top, right, bottom, fontPx*.16f, fontPx*.16f, background)
            }

            val glowPaint = if (layer.glowRadius > .01f) Paint(fill).apply {
                clearShadowLayer()
                color = applyAlpha(layer.colorArgb, (alpha * (.34f + layer.glowRadius.coerceIn(0f,1f) * .42f)).toInt().coerceIn(0,255))
                setShadowLayer(
                    (fontPx * (.08f + layer.glowRadius.coerceIn(0f,1f) * .32f)).coerceAtLeast(2f),
                    0f, 0f,
                    applyAlpha(layer.colorArgb, (alpha * .88f).toInt().coerceIn(0,255))
                )
            } else null
            val drawX = when (fill.textAlign) {
                Paint.Align.LEFT -> -maxWidth / 2f
                Paint.Align.RIGHT -> maxWidth / 2f
                else -> 0f
            }
            var baseline = -totalHeight / 2f - fm.ascent + (lineHeight - (fm.descent - fm.ascent)) / 2f
            lines.forEach { line ->
                glowPaint?.let { canvas.drawText(line, drawX, baseline, it) }
                if (stroke.strokeWidth > .01f) canvas.drawText(line, drawX, baseline, stroke)
                canvas.drawText(line, drawX, baseline, fill)
                baseline += lineHeight
            }
            canvas.restore()
        }

        private fun resolveTypeface(layer: TextLayer): android.graphics.Typeface {
            if (layer.customFontPath.isNotBlank()) {
                runCatching { android.graphics.Typeface.createFromFile(layer.customFontPath) }.getOrNull()?.let { return it }
            }
            val name = layer.presetName.lowercase()
            val family = layer.fontFamilyName.ifBlank {
                when {
                    name.contains("serif") -> "serif"
                    name.contains("mono") || name.contains("tech") -> "monospace"
                    name.contains("script") || name.contains("cursive") -> "cursive"
                    else -> "sans-serif"
                }
            }
            val wantsBold = layer.fontWeight >= 600 || name.contains("bold") || name.contains("black") || name.contains("semibold") || name.contains("extrabold")
            val wantsItalic = layer.italic || name.contains("italic")
            val style = when {
                wantsBold && wantsItalic -> android.graphics.Typeface.BOLD_ITALIC
                wantsItalic -> android.graphics.Typeface.ITALIC
                wantsBold -> android.graphics.Typeface.BOLD
                else -> android.graphics.Typeface.NORMAL
            }
            return android.graphics.Typeface.create(family, style)
        }

        private fun visibleText(text: String, localMs: Long, entry: String): String {
            val p = (localMs / 800f).coerceIn(0f,1f)
            return when (entry) {
                "Typewriter" -> text.take((text.length * p).toInt().coerceIn(0,text.length))
                "Word Reveal" -> {
                    val words = text.trim().split(Regex("\\s+"))
                    if (words.isEmpty()) text else words.take((words.size * p).toInt().coerceIn(1,words.size)).joinToString(" ")
                }
                else -> text
            }
        }

        private fun applyAlpha(argb: Int, alpha: Int): Int = (argb and 0x00FFFFFF) or (alpha.coerceIn(0,255) shl 24)
    }

    private fun exportTextAnimationFrame(posMs: Long, durationMs: Long, entry: String, exit: String, loop: String): ExportTextAnimFrame {
        val entryP = (posMs / 800f).coerceIn(0f,1f)
        val exitP = ((durationMs - posMs) / 800f).coerceIn(0f,1f)
        var alpha=1f; var scale=1f; var x=0f; var y=0f; var rotation=0f
        val e=1f-entryP
        when(entry){
            "Fade In"->alpha*=entryP; "Slide Left"->x-=220f*e; "Slide Right"->x+=220f*e
            "Slide Up","Rise"->y-=150f*e; "Slide Down","Drop"->y+=150f*e
            "Zoom In"->scale*=.35f+.65f*entryP; "Pop"->scale*=.7f+.38f*entryP-.08f*sin(entryP*PI.toFloat())
            "Bounce"->y+=90f*e*abs(sin(entryP*PI.toFloat()*3f)); "Blur In"->{alpha*=entryP;scale*=.88f+.12f*entryP}
            "Typewriter"->alpha*=if(entryP>.12f)1f else entryP/.12f; "Word Reveal"->{alpha*=entryP;y+=35f*e}
            "Tracking In"->{alpha*=entryP;scale*=.86f+.14f*entryP}; "Rotate In"->rotation-=50f*e
            "Flip"->scale*=.25f+.75f*entryP; "Stretch"->scale*=.6f+.4f*entryP
            "Swing"->rotation+=25f*e*sin(entryP*PI.toFloat()*3f); "Glitch In"->{x+=if(entryP<.8f)14f*sin(entryP*80f) else 0f;alpha*=.55f+.45f*entryP}
            "Neon Reveal"->{alpha*=entryP;scale*=.9f+.1f*entryP}
        }
        val o=1f-exitP
        when(exit){
            "Fade Out","Dissolve"->alpha*=exitP; "Slide Left"->x-=220f*o; "Slide Right"->x+=220f*o
            "Slide Up","Rise Out"->y-=150f*o; "Slide Down","Drop Out"->y+=150f*o
            "Zoom Out","Shrink","Collapse"->scale*=.35f+.65f*exitP; "Blur Out"->{alpha*=exitP;scale*=.9f+.1f*exitP}
            "Glitch Out","Scatter"->{x+=16f*o*sin(o*90f);alpha*=exitP}; "Rotate Out"->rotation+=55f*o
            "Flip Out"->scale*=.3f+.7f*exitP; "Swing Out"->rotation+=28f*o*sin(exitP*PI.toFloat()*3f)
            "Stretch Out"->{scale*=1f+.25f*o;alpha*=exitP}; "Flash Out","Neon Out"->alpha*=(.25f+.75f*exitP)*(.75f+.25f*abs(sin(o*35f)))
        }
        val phase=(posMs%1600L)/1600f*(2f*PI.toFloat())
        when(loop){
            "Pulse","Breathing","Scale Pulse"->scale*=1f+.08f*sin(phase); "Bounce","Jump"->y-=12f*abs(sin(phase))
            "Float","Drift"->y+=9f*sin(phase); "Shake","Vibrate"->x+=5f*sin(phase*7f); "Wobble","Swing"->rotation+=4f*sin(phase)
            "Rotation"->rotation+=(posMs%4000L)/4000f*360f; "Heartbeat"->scale*=1f+.11f*abs(sin(phase*2f))
            "Flash","Neon Flicker"->alpha*=.72f+.28f*abs(sin(phase*4f)); "Glitch"->{x+=4f*sin(phase*13f);y+=2f*cos(phase*9f)}
            "Wave"->{y+=7f*sin(phase*2f);rotation+=2f*sin(phase)}; "Tracking Pulse"->scale*=1f+.035f*sin(phase); "Blur Pulse"->alpha*=.86f+.14f*abs(sin(phase))
        }
        return ExportTextAnimFrame(alpha.coerceIn(0f,1f),scale.coerceAtLeast(.05f),x,y,rotation)
    }

    private class PulseVisualizerOverlay(private val layer: VisualizerLayer) : CanvasOverlay(true) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(canvas: Canvas, presentationTimeUs: Long) {
            canvas.drawColor(Color.TRANSPARENT, android.graphics.PorterDuff.Mode.CLEAR)
            val globalMs = presentationTimeUs / 1000L
            if (globalMs < layer.audioTimelineStartMs || globalMs >= layer.audioEndMs) return
            val analysisMs = layer.audioTrimStartMs + (globalMs - layer.audioTimelineStartMs)
            val frames = layer.analysis?.frames.orEmpty(); if (frames.isEmpty()) return
            val frame = frames.binarySearch { it.timeMs.compareTo(analysisMs) }.let { idx ->
                when { idx >= 0 -> frames[idx]; else -> frames[(-idx-1).coerceIn(0,frames.lastIndex)] }
            }
            val values = frame.values; if (values.isEmpty() || frame.rms < .02f) return
            val w=canvas.width.toFloat(); val h=canvas.height.toFloat(); val cx=w/2f; val cy=h/2f
            val minSide=minOf(w,h); val base=minSide*.20f; val style=layer.style.lowercase()
            fun spectrumColor(i:Int,n:Int):Int {
                if(!layer.multicolor) return Color.rgb(57,231,255)
                val mix=i.toFloat()/max(1,n-1)
                return Color.rgb((57+(255-57)*mix).toInt(),(231+(79-231)*mix).toInt(),(255+(203-255)*mix).toInt())
            }
            fun radialBars(count:Int, innerRadius:Float=base, maxLen:Float=minSide*.22f) {
                repeat(count){i->
                    val a=(2*PI*i/count-PI/2).toFloat(); val v=values[(i*values.size/count).coerceIn(0,values.lastIndex)].coerceIn(0f,1f)
                    val len=(minSide*.012f+v*maxLen*layer.intensity).coerceAtMost(minSide*.30f)
                    paint.style=Paint.Style.STROKE; paint.strokeCap=Paint.Cap.ROUND; paint.strokeWidth=max(2f,w/500f); paint.alpha=225; paint.color=spectrumColor(i,count)
                    canvas.drawLine(cx+cos(a)*innerRadius,cy+sin(a)*innerRadius,cx+cos(a)*(innerRadius+len),cy+sin(a)*(innerRadius+len),paint)
                }
            }
            when {
                style.contains("barras") && !style.contains("espelh") -> {
                    val n=64; val gap=w*.005f; val usable=w*.72f; val x0=(w-usable)/2f; val barW=(usable-gap*(n-1))/n
                    repeat(n){i-> val v=values[(i*values.size/n).coerceIn(0,values.lastIndex)].coerceIn(0f,1f); val bh=(h*.03f+v*h*.28f*layer.intensity).coerceAtMost(h*.38f); paint.style=Paint.Style.FILL;paint.color=spectrumColor(i,n);paint.alpha=225;canvas.drawRect(x0+i*(barW+gap),cy-bh/2,x0+i*(barW+gap)+barW,cy+bh/2,paint)}
                }
                style.contains("espelh") -> {
                    val n=48; val usable=w*.62f; val x0=(w-usable)/2f; val step=usable/n
                    repeat(n){i->val v=values[(i*values.size/n).coerceIn(0,values.lastIndex)];val bh=(h*.02f+v*h*.22f*layer.intensity);paint.color=spectrumColor(i,n);paint.alpha=225;paint.strokeWidth=max(2f,w/600f);val x=x0+(i+.5f)*step;canvas.drawLine(x,cy-bh,x,cy+bh,paint)}
                }
                style.contains("onda") || style.contains("waveform") -> {
                    paint.style=Paint.Style.STROKE;paint.strokeWidth=max(3f,w/450f);paint.strokeCap=Paint.Cap.ROUND;paint.alpha=230;paint.color=Color.rgb(139,233,255)
                    for(i in 0 until values.lastIndex){val x1=w*i/values.lastIndex;val x2=w*(i+1)/values.lastIndex;val y1=cy+(values[i]-.5f)*h*.28f*layer.intensity;val y2=cy+(values[i+1]-.5f)*h*.28f*layer.intensity;canvas.drawLine(x1,y1,x2,y2,paint)}
                }
                style.contains("halo") -> {
                    val pulse=(1f+frame.rms*.45f*layer.intensity); repeat(4){r->paint.style=Paint.Style.STROKE;paint.strokeWidth=max(3f,w/500f)+r*2f;paint.color=Color.rgb(193,140,255);paint.alpha=55-r*8;canvas.drawCircle(cx,cy,base*pulse*(1f+r*.12f),paint)}
                }
                style.contains("orbital") -> {
                    val speed=.35f+frame.bass*2.5f; repeat(28){i->val a=(2*PI*i/28 + presentationTimeUs/1_000_000.0*speed).toFloat();val orbit=base*(1.1f+(i%2)*.35f);paint.style=Paint.Style.FILL;paint.color=spectrumColor(i,28);paint.alpha=(120+frame.treble*100).toInt().coerceIn(0,255);canvas.drawCircle(cx+cos(a)*orbit,cy+sin(a)*orbit,2.5f+frame.treble*5f,paint)}
                }
                style.contains("disco") || style.contains("cd") || style.contains("vinil") -> {
                    paint.style=Paint.Style.FILL;paint.color=Color.rgb(18,20,30);paint.alpha=235;canvas.drawCircle(cx,cy,base*.92f,paint); radialBars(64,base*.98f,minSide*.18f)
                    paint.style=Paint.Style.STROKE;paint.strokeWidth=max(2f,w/700f);paint.color=Color.WHITE;paint.alpha=50;repeat(4){r->canvas.drawCircle(cx,cy,base*(.25f+r*.16f),paint)}
                }
                style.contains("3d") -> {
                    val n=32; val usable=w*.72f; val x0=(w-usable)/2f; val step=usable/n
                    repeat(n){i->val v=values[(i*values.size/n).coerceIn(0,values.lastIndex)];val bh=(h*.02f+v*h*.27f*layer.intensity);val depth=(i-n/2).toFloat()/n*h*.10f;paint.style=Paint.Style.FILL;paint.color=spectrumColor(i,n);paint.alpha=205;canvas.drawRect(x0+i*step,cy+depth-bh,x0+(i+.7f)*step,cy+depth,paint)}
                }
                style.contains("wave ring") -> {
                    val n=96; paint.style=Paint.Style.STROKE;paint.strokeWidth=max(3f,w/500f);paint.alpha=225
                    repeat(n){i->val a=(2*PI*i/n-PI/2).toFloat();val v=values[(i*values.size/n).coerceIn(0,values.lastIndex)];val r=base*(1f+frame.rms*.22f)+v*minSide*.06f*layer.intensity;paint.color=spectrumColor(i,n);val a2=(2*PI*(i+1)/n-PI/2).toFloat();val v2=values[((i+1)*values.size/n).coerceIn(0,values.lastIndex)];val r2=base*(1f+frame.rms*.22f)+v2*minSide*.06f*layer.intensity;canvas.drawLine(cx+cos(a)*r,cy+sin(a)*r,cx+cos(a2)*r2,cy+sin(a2)*r2,paint)}
                }
                else -> radialBars(64)
            }
        }
    }}
