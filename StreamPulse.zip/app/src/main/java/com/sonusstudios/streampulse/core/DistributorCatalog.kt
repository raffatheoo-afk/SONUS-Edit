package com.sonusstudios.streampulse.core

object DistributorCatalog {
    val all: List<DistributorInfo> = listOf(
        DistributorInfo(
            distributor = DistributorId.SOUNDON,
            frequency = "Mensal",
            payoutWindow = "Por volta do dia 25",
            notes = "O extrato mensal costuma sair por volta do dia 25. O dinheiro pode refletir reportes de lojas com atraso de meses.",
            streamSelectionGuide = "No SONUS, use como referência o período do dia 26 do mês anterior até a data atual.",
            helpUrl = "https://www.soundon.global/knowledge/article/payment-soundon-when-pay?lang=en"
        ),
        DistributorInfo(
            distributor = DistributorId.DITTO,
            frequency = "Mensal",
            payoutWindow = "Sem dia fixo",
            notes = "A Ditto credita conforme recebe os relatórios das lojas; o saque pode levar alguns dias úteis.",
            streamSelectionGuide = "Informe a data do último crédito/pagamento. O período recomendado começa no dia seguinte e vai até hoje.",
            helpUrl = "https://support.dittomusic.com/en/articles/4283452-when-will-royalties-be-paid-into-my-account"
        ),
        DistributorInfo(
            distributor = DistributorId.DISTROKID,
            frequency = "Saques processados 2x por semana",
            payoutWindow = "Terças e quintas (PT)",
            notes = "Os pedidos de saque são processados em dias específicos e o valor pode levar vários dias para aparecer.",
            streamSelectionGuide = "Use a última data real de crédito/saque como referência; o SONUS começa a consulta no dia seguinte.",
            helpUrl = "https://support.distrokid.com/hc/en-us/articles/16501620089747-Where-is-My-Withdrawal"
        ),
        DistributorInfo(
            distributor = DistributorId.TUNECORE,
            frequency = "Publishing trimestral; distribuição com reportes próprios",
            payoutWindow = "Publishing: meados de mai/ago/nov/fev",
            notes = "O calendário do Publishing é trimestral. Os relatórios de distribuição de DSPs seguem outra dinâmica e não devem ser confundidos com o Publishing.",
            streamSelectionGuide = "Use a última data real de crédito/pagamento da modalidade que você acompanha e consulte do dia seguinte até hoje.",
            helpUrl = "https://support.tunecore.com/hc/en-us/articles/115006502487-When-do-I-get-paid"
        ),
        DistributorInfo(
            distributor = DistributorId.FRESHTUNES,
            frequency = "Mensal",
            payoutWindow = "Dias 15 a 20",
            notes = "Os créditos costumam entrar na carteira entre os dias 15 e 20; saques são processados em dias específicos da semana.",
            streamSelectionGuide = "Use como referência o dia 21 do mês anterior até a data atual.",
            helpUrl = "https://helpcenter.freshtunes.com/hc/en-us/articles/17257292663196-How-Are-Royalties-Calculated-and-Paid"
        ),
        DistributorInfo(
            distributor = DistributorId.ROUTENOTE,
            frequency = "Mensal",
            payoutWindow = "Dias 15 a 20",
            notes = "O pagamento automático costuma ocorrer entre os dias 15 e 20 quando os requisitos de pagamento são atendidos.",
            streamSelectionGuide = "Use como referência o dia 21 do mês anterior até a data atual.",
            helpUrl = "https://routenote.com/blog/when-do-i-receive-payment-from-routenote-for-my-music-sales-and-streaming-royalties/"
        ),
        DistributorInfo(
            distributor = DistributorId.CDBABY,
            frequency = "Semanal",
            payoutWindow = "Início da semana",
            notes = "O payout pode ser gerado no início da semana quando o Pay Point configurado é atingido.",
            streamSelectionGuide = "Informe a data do último pagamento. O SONUS usa o dia seguinte como início do período recomendado.",
            helpUrl = "https://support.cdbaby.com/hc/en-us/articles/211074743-How-do-I-get-paid-from-CD-Baby"
        ),
        DistributorInfo(
            distributor = DistributorId.ONERPM,
            frequency = "Mensal / sob demanda",
            payoutWindow = "Sem dia fixo",
            notes = "O saldo é disponibilizado conforme a ONErpm recebe os valores das plataformas; o saque pode ser solicitado quando disponível.",
            streamSelectionGuide = "Informe a última data real de crédito/pagamento e consulte do dia seguinte até hoje.",
            helpUrl = "https://onerpm.com/onerpm-answers-common-questions/"
        ),
        DistributorInfo(
            distributor = DistributorId.UNITEDMASTERS,
            frequency = "Mensal; recursos diários em planos elegíveis",
            payoutWindow = "Normalmente nas 2 últimas semanas do mês",
            notes = "Alguns planos SELECT/PARTNER têm recursos de royalties em tempo real/diários, enquanto o fluxo padrão é mensal.",
            streamSelectionGuide = "Para o fluxo mensal, use a última data real de crédito como referência. Planos com royalties em tempo real devem ser tratados como acompanhamento manual.",
            helpUrl = "https://unitedmasters.com/en/real-time-royalties"
        ),
        DistributorInfo(
            distributor = DistributorId.AMUSE,
            frequency = "Mensal / assíncrona",
            payoutWindow = "Sem dia fixo",
            notes = "Os royalties entram quando as lojas enviam seus relatórios, normalmente com atraso em relação ao mês em que os streams aconteceram.",
            streamSelectionGuide = "Informe a data do último crédito/pagamento. O período recomendado começa no dia seguinte.",
            helpUrl = "https://support.amuse.io/en/articles/208218-where-are-my-royalties"
        ),
        DistributorInfo(
            distributor = DistributorId.LANDR,
            frequency = "Mensal",
            payoutWindow = "Primeira semana (dias 1 a 7)",
            notes = "A renda líquida costuma ficar disponível na conta durante a primeira semana de cada mês.",
            streamSelectionGuide = "Use como referência o dia 8 do mês anterior até a data atual.",
            helpUrl = "https://support.landr.com/hc/en-us/articles/115009761288-When-do-I-get-my-money-when-releasing-through-LANDR"
        ),
        DistributorInfo(
            distributor = DistributorId.SYMPHONIC,
            frequency = "Mensal",
            payoutWindow = "Dias 1 a 5",
            notes = "Relatório e saldo costumam ser postados entre os dias 1 e 5; o saque segue a janela operacional da empresa.",
            streamSelectionGuide = "Use como referência o dia 6 do mês anterior até a data atual.",
            helpUrl = "https://support.symdistro.com/hc/en-us/articles/207489176-Monthly-Reporting-Payment-Schedule"
        ),
        DistributorInfo(
            distributor = DistributorId.TOOLOST,
            frequency = "Mensal / sob demanda",
            payoutWindow = "Sem dia fixo",
            notes = "Os royalties são contabilizados mensalmente e o saque é solicitado sob demanda, com prazo próprio de processamento.",
            streamSelectionGuide = "Informe a última data real de crédito/pagamento e consulte do dia seguinte até hoje.",
            helpUrl = "https://toolost.com/terms"
        )
    )

    fun info(distributor: DistributorId): DistributorInfo? = all.firstOrNull { it.distributor == distributor }
}
