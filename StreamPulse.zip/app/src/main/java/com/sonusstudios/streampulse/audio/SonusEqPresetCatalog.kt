package com.sonusstudios.streampulse.audio

/** Catálogo único de presets manuais do SONUS. Curvas em dB para 32 Hz..16 kHz. */
internal object SonusEqPresetCatalog {
    val bandsHz = listOf(32, 64, 125, 250, 500, 1000, 2000, 4000, 8000, 16000)
    val curves: LinkedHashMap<String, List<Double>> = linkedMapOf(
        // Os sete perfis legados do Player são preservados exatamente.
        "Neutro" to listOf(0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0),
        "Rock" to listOf(1.1,1.2,.7,-.3,-.6,-.2,.6,1.1,.9,.4),
        "Pop" to listOf(.4,.6,.3,-.2,-.4,-.1,.5,.9,.6,.2),
        "Clássico" to listOf(.2,.3,.2,0.0,-.1,.1,.4,.6,.5,.3),
        "Hip-Hop" to listOf(1.4,1.5,1.0,.2,-.4,-.3,.2,.5,.3,0.0),
        "Eletrônica" to listOf(1.2,1.3,.8,0.0,-.4,-.2,.4,.9,1.0,.7),
        "Vocal" to listOf(-.5,-.4,-.2,0.0,.3,.7,1.0,.8,.1,-.2),
        // Perfis adicionais. Todos possuem vetor próprio, sem aliases de curva.
        "Rock Clássico" to listOf(1.0,1.2,.8,.2,-.2,-.1,.5,.9,.7,.3),
        "Hard Rock" to listOf(1.7,1.8,1.2,.1,-.7,-.5,.6,1.2,1.0,.5),
        "Metal" to listOf(1.2,1.5,1.1,-.5,-1.0,-.3,.9,1.4,.9,.3),
        "Punk Rock" to listOf(1.1,1.3,.8,.0,-.5,.0,.7,1.0,.5,.0),
        "Indie Rock" to listOf(.6,.8,.5,-.2,-.4,.1,.7,.9,.6,.25),
        "Alternativo" to listOf(.7,.9,.6,-.3,-.6,.0,.8,1.0,.65,.2),
        "Sertanejo" to listOf(.7,.8,.5,.0,-.2,.2,.7,.8,.4,.1),
        "Country" to listOf(.5,.7,.45,.1,-.1,.25,.75,.85,.5,.15),
        "MPB" to listOf(.2,.35,.25,.0,.15,.4,.65,.6,.25,.05),
        "Samba" to listOf(.45,.6,.35,-.1,.05,.35,.7,.75,.35,.1),
        "Pagode" to listOf(.55,.7,.4,.0,.1,.4,.7,.65,.3,.05),
        "Forró" to listOf(.65,.8,.5,.05,-.15,.3,.75,.8,.35,.05),
        "Piseiro" to listOf(.9,1.0,.65,.0,-.25,.2,.65,.75,.35,.05),
        "Funk Brasileiro" to listOf(1.5,1.6,1.1,.2,-.4,-.2,.25,.55,.35,.05),
        "Trap" to listOf(1.8,1.9,1.3,.15,-.55,-.35,.3,.65,.45,.1),
        "Rap / Boom Bap" to listOf(1.2,1.35,.9,.15,-.25,.0,.45,.7,.5,.15),
        "R&B" to listOf(.85,1.0,.65,.1,-.15,.15,.55,.7,.3,.05),
        "Soul" to listOf(.65,.8,.5,.15,.15,.45,.75,.65,.25,.0),
        "Gospel" to listOf(.45,.6,.35,.0,.2,.65,.9,.7,.25,.0),
        "Reggae" to listOf(1.0,1.1,.7,.15,-.2,.1,.45,.55,.25,.05),
        "Reggaeton" to listOf(1.25,1.4,.9,.1,-.35,-.15,.35,.7,.4,.05),
        "Latin / Salsa" to listOf(.75,.85,.55,.05,-.1,.35,.8,.9,.5,.15),
        "Bossa Nova" to listOf(.1,.25,.2,.0,.2,.45,.6,.55,.3,.1),
        "Blues" to listOf(.55,.7,.4,.1,.15,.45,.65,.7,.35,.1),
        "Acústico" to listOf(.2,.35,.2,.0,.25,.55,.75,.65,.25,.0),
        "Folk" to listOf(.3,.45,.3,.05,.1,.35,.7,.65,.3,.05),
        "Orquestral" to listOf(-.3,-.1,.1,.2,.35,.45,.55,.45,.25,.15),
        "Piano" to listOf(-.2,.0,.15,.25,.4,.5,.6,.5,.25,.05),
        "Ambient" to listOf(.15,.25,.2,.15,.1,.2,.35,.5,.55,.35),
        "Lo-fi" to listOf(.65,.55,.2,-.4,-.7,-.5,-.1,.2,-.35,-.8),
        "Dance / House" to listOf(1.1,1.25,.8,.0,-.35,-.1,.45,.85,.8,.45),
        "Techno / Trance" to listOf(1.25,1.35,.9,-.1,-.45,-.1,.55,1.0,1.0,.65),
        "Drum & Bass / Breakbeat" to listOf(1.6,1.7,1.1,-.1,-.45,-.15,.45,.9,.7,.25),
        "Trilha Sonora / Cinema" to listOf(.35,.45,.25,.15,.1,.25,.55,.75,.55,.3),
        "Podcast / Voz" to listOf(-1.5,-1.0,-.6,.0,.8,1.4,1.6,1.0,-.2,-1.0),
        "Jazz" to listOf(-3.826,-3.670,-3.263,-2.812,-3.525,-4.614,-4.027,-2.569,-1.162,0.0),
        // Quatro curvas distintas do painel compartilhado da CODE09 são mantidas
        // com sufixo ASR, para não sobrescrever os sete perfis legados do Player.
        "Rock (ASR)" to listOf(0.0,-.530,-2.259,-4.281,-5.493,-6.564,-4.752,-2.716,-.901,-.337),
        "Pop (ASR)" to listOf(-7.213,-6.232,-4.382,-2.258,0.0,-.040,-2.265,-4.077,-5.822,-7.363),
        "Clássico (ASR)" to listOf(0.0,-.872,-2.197,-4.184,-6.156,-5.733,-4.510,-2.850,-1.410,-.964),
        "Hip-Hop (ASR)" to listOf(0.0,-.235,-1.203,-3.799,-6.432,-6.994,-5.662,-4.968,-4.003,-1.329)
    )
    // A biblioteca pública possui exatamente 43 presets. As quatro curvas ASR
    // permanecem internas somente para preservar configurações antigas já salvas
    // no Conversor PRO e no SONUS VIDEO; não aparecem como opções duplicadas.
    val manualPresetNames: List<String> = curves.keys.filterNot { it.endsWith(" (ASR)") }

    val categories = linkedMapOf(
        "Todos" to manualPresetNames,
        "Básicos" to listOf("Neutro","Rock","Pop","Clássico","Hip-Hop","Eletrônica","Vocal"),
        "Rock" to listOf("Rock Clássico","Hard Rock","Metal","Punk Rock","Indie Rock","Alternativo"),
        "Brasil" to listOf("Sertanejo","Country","MPB","Samba","Pagode","Forró","Piseiro","Funk Brasileiro"),
        "Urbano" to listOf("Trap","Rap / Boom Bap","R&B","Soul"),
        "Mundo" to listOf("Gospel","Reggae","Reggaeton","Latin / Salsa","Bossa Nova","Blues"),
        "Acústico" to listOf("Acústico","Folk","Orquestral","Piano"),
        "Eletrônica" to listOf("Ambient","Lo-fi","Dance / House","Techno / Trance","Drum & Bass / Breakbeat"),
        "Especial" to listOf("Trilha Sonora / Cinema","Podcast / Voz","Jazz")
    )
}
