package com.sonusstudios.streampulse.tools

import android.app.*
import android.graphics.BitmapFactory
import android.content.Intent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.media.AudioManager
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.MediaMetadata
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Visualizer
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.util.Log
import kotlinx.coroutines.*
import com.sonusstudios.streampulse.audio.LocalSpectrumAnalyzer
import com.sonusstudios.streampulse.audio.SpectrumFrame
import com.sonusstudios.streampulse.widgets.SonusWidgetCenter
import com.sonusstudios.streampulse.stream.SonusStreamPlatformRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.abs

enum class PulseQueueKind { NORMAL, RADIO_MUSIC, RADIO_VOICE }

/** Item de fila do SONUS PLAYER. O Uri permanece sob permissão SAF persistente. */
data class PulsePlayerQueueItem(
    val uri: String,
    val title: String,
    val artist: String = "",
    val album: String = "",
    val genre: String = "",
    val durationMs: Long = 0L,
    val source: String = "Local",
    val kind: PulseQueueKind = PulseQueueKind.NORMAL,
    val radioStationId: String? = null
)

data class PulsePlayerPlaybackState(
    val queue: List<PulsePlayerQueueItem> = emptyList(),
    val index: Int = -1,
    val playing: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val repeatMode: Int = 0, // 0 off, 1 all, 2 one
    val shuffle: Boolean = false,
    val crossfadeSeconds: Int = 0,
    val fadeInSeconds: Int = 0,
    val fadeOutSeconds: Int = 0,
    val preloadNextEnabled: Boolean = true,
    val playbackSpeed: Float = 1f,
    val loopStartMs: Long? = null,
    val loopEndMs: Long? = null,
    val pulseLift: Boolean = false,
    val pulseLiftProfile: String = "Boost",
    val normalization: Boolean = false,
    val spectrum: List<Float> = List(24) { 0f },
    val spectrumEngine: String = "PCM Media3",
    val orbitMode: PulseOrbitMode = PulseOrbitMode.OFF,
    val orbitIntensity: Int = 55,
    val orbitPreset: String = "Manual",
    val orbitFrequencyHz: Double = 0.115,
    val sleepEndEpochMs: Long? = null,
    val stopAfterCurrent: Boolean = false,
    val sessionListeningMs: Long = 0L,
    val sessionTrackCount: Int = 0,
    val errorMessage: String? = null
) {
    val current: PulsePlayerQueueItem? get() = queue.getOrNull(index)
}

enum class PulseOrbitMode { OFF, THREE_D, EIGHT_D }

/**
 * Serviço local de reprodução. Não baixa música nem envia a biblioteca para a nuvem.
 * Usa MediaPlayer + efeitos AudioEffect nativos para preservar compatibilidade desde API 26.
 */
class PulsePlayerService : Service() {
    inner class LocalBinder : Binder() { fun service(): PulsePlayerService = this@PulsePlayerService }
    private val binder = LocalBinder()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val _state = MutableStateFlow(PulsePlayerPlaybackState())
    val state: StateFlow<PulsePlayerPlaybackState> = _state.asStateFlow()
    // Fluxo separado para o áudio visual: evita recompor toda a tela do player a cada frame PCM.
    private val _spectrum = MutableStateFlow<List<Float>>(List(24) { 0f })
    val spectrum: StateFlow<List<Float>> = _spectrum.asStateFlow()

    private var player: MediaPlayer? = null
    private var incomingPlayer: MediaPlayer? = null
    private var gaplessPlayer: MediaPlayer? = null
    private var gaplessNextIndex: Int? = null
    private var onlineDataSource: SonusPCloudMediaDataSource? = null
    private var onlinePlayer: ExoPlayer? = null
    private var onlinePlayerListener: Player.Listener? = null
    private var onlineResolveJob: Job? = null
    private var onlineGeneration: Long = 0L
    private var progressJob: Job? = null
    private var crossfadeJob: Job? = null
    private var orbitJob: Job? = null
    private var sleepJob: Job? = null
    private var compatSpectrumJob: Job? = null
    private var compatSpectrumAnalysisJob: Job? = null
    private var spectrumHealthJob: Job? = null
    private var compatSpectrumFrames: List<SpectrumFrame> = emptyList()
    private var compatSpectrumUri: String? = null
    private var compatSpectrumStartMs: Long = 0L
    private var compatSpectrumEndMs: Long = 0L
    private var compatSpectrumRetryAfterMs: Long = 0L
    private var compatSpectrumFailures: Int = 0
    private val compatSpectrumCache = linkedMapOf<String, List<SpectrumFrame>>()
    @Volatile private var lastNativeSpectrumAt: Long = 0L
    @Volatile private var nativeHealthyEvents: Int = 0
    @Volatile private var lastNativeSignature: Float = Float.NaN
    @Volatile private var lastMedia3SpectrumAt: Long = 0L
    @Volatile private var media3HealthyEvents: Int = 0
    private var lastMedia3RestartAt: Long = 0L
    private val media3Spectrum by lazy {
        Media3SpectrumEngine(applicationContext, scope) { bins ->
            if (bins.isEmpty()) return@Media3SpectrumEngine
            val energy = bins.average().toFloat()
            // Silêncio também é um frame válido: envie zeros para não congelar a última batida.
            if (energy <= .0012f) {
                setSpectrumEngine("PCM Media3", List(bins.size.coerceAtLeast(24)) { 0f })
                return@Media3SpectrumEngine
            }
            lastMedia3SpectrumAt = android.os.SystemClock.elapsedRealtime()
            media3HealthyEvents = (media3HealthyEvents + 1).coerceAtMost(1000)
            setSpectrumEngine("PCM Media3", bins)
        }
    }
    private var startedAtPositionMs: Long = 0L
    private var startedAtRealtimeMs: Long = 0L
    private var currentListenedMs: Long = 0L
    // Garante integridade das estatísticas: uma reprodução real só pode gerar
    // um único desfecho (conclusão OU pulo). Erros técnicos não viram "pulos".
    private var statsPlayRegistered: Boolean = false
    // Fonte única de verdade para a intenção de reprodução.
    // Só fica true depois de uma ação explícita de reprodução ou avanço contínuo de uma faixa já tocando.
    private var playbackRequested: Boolean = false
    // code108: invalida callbacks auxiliares assíncronos (gapless/crossfade) quando o
    // estado de transporte muda. Navegação/rebind nunca pode ressuscitar áudio pausado.
    private var auxiliaryGeneration: Long = 0L
    private var startedForPlayback: Boolean = false
    private var resumeAfterFocusGain: Boolean = false
    private var consecutivePlaybackFailures: Int = 0
    private var consecutiveRadioMusicFailures: Int = 0
    private var radioSuccessfulMusicSinceVoice: Int = 0
    private var lastRadioStartedIndex: Int = -1
    private val audioManager by lazy { getSystemService(AUDIO_SERVICE) as AudioManager }
    private val mediaAudioAttributes by lazy {
        AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
    }
    private val audioFocusListener = AudioManager.OnAudioFocusChangeListener { change ->
        when (change) {
            AudioManager.AUDIOFOCUS_LOSS -> { resumeAfterFocusGain = false; if (_state.value.playing) pause() }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> { resumeAfterFocusGain = _state.value.playing; if (_state.value.playing) pause(releaseFocus = false) }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                runCatching { player?.setVolume(.25f, .25f) }
                onlinePlayer?.volume = .25f
            }
            AudioManager.AUDIOFOCUS_GAIN -> {
                runCatching { player?.setVolume(1f, 1f) }
                onlinePlayer?.volume = 1f
                if (resumeAfterFocusGain) { resumeAfterFocusGain = false; play() }
            }
        }
    }
    private val audioFocusRequest by lazy {
        AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(mediaAudioAttributes)
            .setAcceptsDelayedFocusGain(true)
            .setOnAudioFocusChangeListener(audioFocusListener)
            .build()
    }

    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var loudness: LoudnessEnhancer? = null
    private var visualizer: Visualizer? = null
    private var eqTenBands: List<Float> = List(10) { 0f }
    private var pulseLiftAllowed: Boolean = false

    private lateinit var mediaSession: MediaSession
    private val stats by lazy { PulsePlayerStatsStore(applicationContext) }
    private val streamLocalAnalytics by lazy { SonusStreamLocalAnalyticsStore(applicationContext) }
    private val streamPlatform by lazy { SonusStreamPlatformRepository(applicationContext) }
    private val onlineRepository by lazy { SonusOnlineMusicRepository(applicationContext) }
    private val onlineHttpFactory by lazy {
        DefaultHttpDataSource.Factory()
            .setUserAgent("SONUS/${com.sonusstudios.streampulse.BuildConfig.VERSION_NAME}")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(6_000)
            .setReadTimeoutMs(15_000)
    }
    private var onlinePrefetchJob: Job? = null
    private var streamPlayFileId: Long = 0L
    private var streamPlaySessionId: String = ""
    private var streamPlayListenedMs: Long = 0L
    private var streamPlayLastTickMs: Long = 0L
    private var streamPlayCounted: Boolean = false // view remota contabilizada nesta sessão
    private var streamPlayClaimResolved: Boolean = false // evita repetir transação quando a sessão caiu no cooldown
    private var streamLocalPlayCounted: Boolean = false // view pessoal contabilizada nesta sessão
    private var streamPlayQualified: Boolean = false // atingiu o limiar, mesmo se estiver em cooldown
    private var streamLocalCheckpointedMs: Long = 0L // tempo já persistido no Analytics Você
    private var streamPlaySuppressQualification: Boolean = false
    private var suppressNextStreamPlayQualification: Boolean = false
    @Volatile private var streamPlaySessionStarted: Boolean = false
    @Volatile private var streamPlayLastStartAttemptMs: Long = 0L
    @Volatile private var streamPlayClaimInFlight: Boolean = false
    @Volatile private var streamPlayThresholdInFlight: Boolean = false
    @Volatile private var streamPlayThresholdResolved: Boolean = false
    @Volatile private var streamPlayRequiredMs: Long = Long.MAX_VALUE
    private val noisyReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == AudioManager.ACTION_AUDIO_BECOMING_NOISY && _state.value.playing) pause()
        }
    }
    private var noisyReceiverRegistered = false

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        // code112: preferências de transição são carregadas uma única vez pelo serviço.
        // Trocar de aba/composable não pode reconfigurar a engine de áudio audível.
        val streamExperience = SonusStreamExperiencePreferences(applicationContext)
        _state.value = _state.value.copy(
            crossfadeSeconds = streamExperience.crossfadeSeconds.coerceIn(0, 12),
            fadeInSeconds = streamExperience.fadeInSeconds.coerceIn(0, 10),
            fadeOutSeconds = streamExperience.fadeOutSeconds.coerceIn(0, 10),
            preloadNextEnabled = streamExperience.preloadNext
        )
        // O serviço de mídia só é ativado quando houver pedido real de reprodução.
        // Isso mantém a criação do serviço leve durante a abertura do app.
        createChannel()
        // Pausa antes que Bluetooth/fone desconectado redirecione a música para o alto-falante.
        runCatching {
            val filter = IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY)
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(noisyReceiver, filter, RECEIVER_NOT_EXPORTED) else @Suppress("DEPRECATION") registerReceiver(noisyReceiver, filter)
            noisyReceiverRegistered = true
        }
        mediaSession = MediaSession(this, "PulsePlayer").apply {
            setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS or MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS)
            packageManager.getLaunchIntentForPackage(packageName)?.let { launch ->
                setSessionActivity(PendingIntent.getActivity(this@PulsePlayerService, 77, launch, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            }
            setCallback(object : MediaSession.Callback() {
                override fun onPlay() = play()
                override fun onPause() = pause()
                override fun onSkipToNext() = next(userInitiated = true)
                override fun onSkipToPrevious() = previous()
                override fun onSeekTo(pos: Long) = seekTo(pos)
            })
            isActive = true
        }
        scope.launch { _state.collect { SonusWidgetCenter.publishPlayer(applicationContext, it) } }
        progressJob = scope.launch {
            while (isActive) {
                delay(500)
                val exo = onlinePlayer
                val p = player
                if (exo != null) {
                    if (!playbackRequested && exo.isPlaying) exo.pause()
                    val pos = exo.currentPosition.coerceAtLeast(0L)
                    val dur = exo.duration.takeIf { it > 0L } ?: _state.value.durationMs
                    val loopStart = _state.value.loopStartMs
                    val loopEnd = _state.value.loopEndMs
                    if (loopStart != null && loopEnd != null && loopEnd > loopStart && pos >= loopEnd) {
                        exo.seekTo(loopStart)
                        _state.value = _state.value.copy(positionMs = loopStart, durationMs = dur.coerceAtLeast(0L), playing = exo.isPlaying)
                    } else {
                        _state.value = _state.value.copy(positionMs = pos, durationMs = dur.coerceAtLeast(0L), playing = exo.isPlaying)
                    }
                    accountListening(pos)
                    accountStreamValidPlay(exo.isPlaying)
                    applyStreamEdgeFade(pos,dur)
                    updateSessionState()
                } else if (p != null) {
                    if (!playbackRequested && p.isPlayingSafe()) runCatching { p.pause() }
                    val pos = runCatching { p.currentPosition.toLong() }.getOrDefault(0L)
                    val dur = runCatching { p.duration.toLong() }.getOrDefault(0L)
                    val loopStart = _state.value.loopStartMs
                    val loopEnd = _state.value.loopEndMs
                    if (loopStart != null && loopEnd != null && loopEnd > loopStart && pos >= loopEnd) {
                        runCatching { p.seekTo(loopStart.toInt()) }
                        _state.value = _state.value.copy(positionMs = loopStart, durationMs = dur.coerceAtLeast(0L), playing = p.isPlayingSafe())
                    } else {
                        _state.value = _state.value.copy(positionMs = pos.coerceAtLeast(0L), durationMs = dur.coerceAtLeast(0L), playing = p.isPlayingSafe())
                    }
                    resetStreamPlayClock()
                    accountListening(pos)
                    applyStreamEdgeFade(pos,dur)
                    updateSessionState()
                    maybeStartCrossfade(pos, dur)
                    _state.value.current?.let { current ->
                        if (!isCloudItem(current)) {
                            runCatching { media3Spectrum.sync(current.uri, pos, p.isPlayingSafe(), _state.value.playbackSpeed) }
                        }
                    }
                }
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onUnbind(intent: Intent?): Boolean {
        // Navegar para outra aba não altera o transporte.
        return super.onUnbind(intent)
    }

    /** Reanexar a tela nunca pode transformar Pause em Play. */
    fun reconcileTransportState() {
        val exo = onlinePlayer
        val p = player
        if (!playbackRequested) {
            if (exo?.isPlaying == true) exo.pause()
            if (p.isPlayingSafe()) runCatching { p?.pause() }
            silenceAuxiliaryPlayersForPause()
        }
        _state.value = _state.value.copy(playing = exo?.isPlaying ?: p.isPlayingSafe())
        updateSessionState()
    }

    private fun keepServiceAliveForPlayback() {
        if (startedForPlayback) return
        startedForPlayback = true
        runCatching { startService(Intent(this, PulsePlayerService::class.java).setAction(ACTION_KEEP_ALIVE)) }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_KEEP_ALIVE -> startedForPlayback = true
            ACTION_TOGGLE -> toggle()
            ACTION_PAUSE -> pause()
            ACTION_NEXT -> next(userInitiated = true)
            ACTION_PREVIOUS -> previous()
            ACTION_PULSE_LIFT -> {
                if (_state.value.pulseLift) setPulseLift(false)
                else setPulseLift(true)
            }
            ACTION_PULSE_ORBIT -> setPulseOrbit(PulseOrbitMode.OFF, 0)
            ACTION_EQ_BASS_BOOST_TOGGLE -> {
                val prefs = getSharedPreferences("sonus_eq_v2", Context.MODE_PRIVATE)
                val next = !prefs.getBoolean("bass_boost", false)
                prefs.edit().putBoolean("bass_boost", next).apply()
                setSonusBassBoost(next)
                SonusWidgetCenter.refreshAll(applicationContext)
            }
            ACTION_STOP -> stopPlayback()
        }
        return START_NOT_STICKY
    }

    fun setQueue(queue: List<PulsePlayerQueueItem>, startIndex: Int = 0, autoPlay: Boolean = false, startPositionMs: Long = 0L) {
        val hasRadioItems = queue.any(::isRadioItem)
        val requestedUri = queue.getOrNull(startIndex)?.uri
        // Filas comuns continuam deduplicadas. A Rádio, porém, repete legitimamente a mesma
        // música em estações pequenas para manter a cadência Música -> Música -> Locução.
        // Deduplicar por URI aqui quebrava essa programação e podia aproximar locuções.
        val clean = if (hasRadioItems) queue else queue.distinctBy { it.uri }
        val resolvedIndex = when {
            clean.isEmpty() -> -1
            hasRadioItems -> startIndex.coerceIn(0, clean.lastIndex)
            requestedUri != null -> clean.indexOfFirst { it.uri == requestedUri }.takeIf { it >= 0 } ?: startIndex.coerceIn(0, clean.lastIndex)
            else -> startIndex.coerceIn(0, clean.lastIndex)
        }
        consecutiveRadioMusicFailures = 0
        lastRadioStartedIndex = -1
        radioSuccessfulMusicSinceVoice = if (hasRadioItems && resolvedIndex >= 0) {
            radioMusicCountBeforeIndex(clean, resolvedIndex)
        } else 0
        zeroSpectrum()
        _state.value = _state.value.copy(queue = clean, index = resolvedIndex, positionMs = startPositionMs.coerceAtLeast(0L), loopStartMs = null, loopEndMs = null, errorMessage = null)
        playbackRequested = autoPlay
        if (autoPlay && clean.isNotEmpty()) playIndex(_state.value.index, shouldPlay = true, startPositionMs = startPositionMs)
    }

    private fun activePositionMs(): Long = onlinePlayer?.currentPosition?.takeIf { it >= 0L }
        ?: runCatching { player?.currentPosition?.toLong() }.getOrNull()
        ?: _state.value.positionMs

    private fun activeDurationMs(): Long = onlinePlayer?.duration?.takeIf { it > 0L }
        ?: runCatching { player?.duration?.toLong() }.getOrNull()?.takeIf { it > 0L }
        ?: _state.value.durationMs

    private fun activeIsPlaying(): Boolean = onlinePlayer?.isPlaying ?: player.isPlayingSafe()

    fun playIndex(index: Int, shouldPlay: Boolean = true, startPositionMs: Long = 0L) {
        playbackRequested = shouldPlay
        if (shouldPlay) keepServiceAliveForPlayback()
        val item = _state.value.queue.getOrNull(index) ?: return
        if (isRadioVoice(item) && radioSuccessfulMusicSinceVoice < 2) {
            val nextMusic = nextRadioMusicIndex(index)
            if (nextMusic != null && nextMusic != index) {
                playIndex(nextMusic, shouldPlay = shouldPlay, startPositionMs = 0L)
            } else {
                playbackRequested = false
                _state.value = _state.value.copy(playing = false, errorMessage = "SONUS Rádio aguardando músicas reproduzíveis.")
                updateSessionState()
            }
            return
        }
        val sameTrackResume = statsPlayRegistered && _state.value.index == index && !_state.value.playing
        if (!sameTrackResume && (startedAtRealtimeMs > 0L || currentListenedMs > 0L || statsPlayRegistered)) {
            finishCurrentTrack(completed = false, skipped = _state.value.index >= 0 && _state.value.index != index)
        }
        zeroSpectrum("PCM Media3")
        _state.value = _state.value.copy(index = index, playing = false, positionMs = startPositionMs.coerceAtLeast(0L), errorMessage = null)

        val onlineRef = SonusOnlineRef.parse(item.uri)
        if (onlineRef != null) {
            prepareForOnlineTrackSwitch()
            playOnlineIndex(index, item, onlineRef, shouldPlay, startPositionMs)
            return
        }

        releasePlayers()
        val p = MediaPlayer()
        player = p

        fun failCurrent(message: String = "Não foi possível iniciar a reprodução") {
            if (player !== p) {
                runCatching { p.release() }
                return
            }
            val continueSequence = playbackRequested && _state.value.queue.size > 1
            runCatching { p.release() }
            player = null
            finishCurrentTrack(completed = false, skipped = false)
            if (continueSequence && consecutivePlaybackFailures < minOf(_state.value.queue.size, 5)) {
                consecutivePlaybackFailures++
                _state.value = _state.value.copy(playing = false, errorMessage = null)
                updateSessionState()
                scope.launch {
                    delay(120L)
                    if (playbackRequested) advanceAfterCompletion()
                }
            } else {
                playbackRequested = false
                consecutivePlaybackFailures = 0
                _state.value = _state.value.copy(playing = false, errorMessage = message)
                updateSessionState()
            }
        }

        try {
            p.setAudioAttributes(mediaAudioAttributes)
            p.setOnPreparedListener { prepared ->
                if (player !== prepared || _state.value.queue.getOrNull(index)?.uri != item.uri) {
                    runCatching { prepared.release() }
                    return@setOnPreparedListener
                }
                val initialPosition = startPositionMs.coerceIn(0L, prepared.duration.toLong().coerceAtLeast(0L))
                if (initialPosition > 0L) runCatching { prepared.seekTo(initialPosition.toInt()) }
                runCatching { media3Spectrum.load(item.uri, initialPosition, playbackRequested, _state.value.playbackSpeed) }
                scheduleSpectrumHealthCheck(item)
                attachEffects(prepared.audioSessionId)
                applyPlaybackSpeed(prepared, _state.value.playbackSpeed)
                if (playbackRequested && requestPlaybackFocus()) {
                    prepared.start()
                    markTrackStarted()
                    if (!statsPlayRegistered && !isRadioVoice(item)) {
                        stats.recordPlay(item)
                        statsPlayRegistered = true
                        _state.value = _state.value.copy(sessionTrackCount = _state.value.sessionTrackCount + 1)
                    }
                    ensureForeground()
                    startOrbitIfNeeded()
                }
                _state.value = _state.value.copy(index = index, playing = prepared.isPlayingSafe(), durationMs = prepared.duration.toLong(), positionMs = initialPosition)
                updateSessionMetadata(item, prepared.duration.toLong())
                updateSessionState()
            }
            attachLocalCompletionListener(p, index)
            p.setOnErrorListener { _, what, extra ->
                if (player === p) failCurrent("Falha na reprodução ($what/$extra)")
                true
            }
            p.setDataSource(this, Uri.parse(item.uri))
            p.prepareAsync()
        } catch (t: Throwable) {
            failCurrent(t.message ?: "Não foi possível abrir a faixa")
        }
    }

    private fun prepareForOnlineTrackSwitch() {
        crossfadeJob?.cancel(); crossfadeJob = null
        orbitJob?.cancel(); orbitJob = null
        onlineResolveJob?.cancel(); onlineResolveJob = null
        onlinePrefetchJob?.cancel(); onlinePrefetchJob = null

        val reusable = onlinePlayer
        if (reusable != null) {
            onlinePlayerListener?.let { listener -> runCatching { reusable.removeListener(listener) } }
            onlinePlayerListener = null
            runCatching { reusable.stop() }
            runCatching { reusable.clearMediaItems() }
        } else {
            // Vindo de player local: efeitos serão ligados ao novo audioSessionId do ExoPlayer.
            releaseEffects()
        }
        runCatching { player?.setNextMediaPlayer(null) }
        runCatching { player?.release() }; player = null
        runCatching { incomingPlayer?.release() }; incomingPlayer = null
        runCatching { gaplessPlayer?.release() }; gaplessPlayer = null
        gaplessNextIndex = null
        runCatching { onlineDataSource?.close() }; onlineDataSource = null
        runCatching { media3Spectrum.stop() }
    }

    private fun playOnlineIndex(
        index: Int,
        item: PulsePlayerQueueItem,
        ref: SonusOnlineRef,
        shouldPlay: Boolean,
        startPositionMs: Long,
        forceFreshDescriptor: Boolean = false,
        preserveStreamSession: Boolean = false
    ) {
        val generation = ++onlineGeneration
        val tapStartedAt = SystemClock.elapsedRealtime()
        playbackRequested = shouldPlay
        zeroSpectrum("SONUS Stream")
        if (!preserveStreamSession) {
            val suppressQualification = suppressNextStreamPlayQualification
            suppressNextStreamPlayQualification = false
            beginStreamPlaySession(ref.fileId, suppressQualification)
        }
        _state.value = _state.value.copy(index = index, playing = false, positionMs = startPositionMs.coerceAtLeast(0L), durationMs = item.durationMs.coerceAtLeast(0L), errorMessage = null)

        onlineResolveJob?.cancel()
        onlineResolveJob = scope.launch {
            val resolved = withContext(Dispatchers.IO) {
                runCatching { onlineRepository.resolvePlaybackStreamFast(ref.fileId, forceRefresh = forceFreshDescriptor) }
            }
            Log.d("SONUS_STREAM_PERF", "file=${ref.fileId} tap->url=${SystemClock.elapsedRealtime() - tapStartedAt}ms fresh=$forceFreshDescriptor")
            if (generation != onlineGeneration || _state.value.queue.getOrNull(index)?.uri != item.uri) return@launch
            val stream = resolved.getOrElse { error ->
                if (!forceFreshDescriptor && playbackRequested) {
                    onlineRepository.invalidatePlaybackDescriptor(ref.fileId)
                    delay(80L)
                    if (generation == onlineGeneration && playbackRequested) {
                        playOnlineIndex(index, item, ref, true, startPositionMs, forceFreshDescriptor = true, preserveStreamSession = true)
                    }
                    return@launch
                }
                if (handleRadioMusicFailure(item, generation, "SONUS Rádio não conseguiu carregar a próxima música.")) return@launch
                val continueSequence = playbackRequested && _state.value.queue.size > 1 && consecutivePlaybackFailures < minOf(_state.value.queue.size, 5)
                if (continueSequence) {
                    consecutivePlaybackFailures++
                    _state.value = _state.value.copy(playing = false, errorMessage = null)
                    updateSessionState()
                    delay(120L)
                    if (generation == onlineGeneration && playbackRequested) advanceAfterCompletion()
                } else {
                    playbackRequested = false
                    consecutivePlaybackFailures = 0
                    _state.value = _state.value.copy(playing = false, errorMessage = "Não foi possível reproduzir esta música. Tente novamente.")
                    updateSessionState()
                }
                return@launch
            }

            onlineHttpFactory.setDefaultRequestProperties(stream.headers)
            media3Spectrum.resetFreshness()
            val exo = onlinePlayer ?: ExoPlayer.Builder(applicationContext, media3Spectrum.createLiveRenderersFactory())
                .setMediaSourceFactory(DefaultMediaSourceFactory(onlineHttpFactory))
                .build()
                .also { onlinePlayer = it }
            onlinePlayerListener?.let { previous -> runCatching { exo.removeListener(previous) } }
            var counted = false
            var requestedSeekApplied = false
            var firstAudioLogged = false
            var readyHandled = false
            val listener = object : Player.Listener {
                override fun onAudioSessionIdChanged(audioSessionId: Int) {
                    if (generation == onlineGeneration && onlinePlayer === exo && audioSessionId > 0) {
                        attachEffects(audioSessionId)
                    }
                }

                override fun onPlaybackStateChanged(playbackState: Int) {
                    if (generation != onlineGeneration || onlinePlayer !== exo) return
                    when (playbackState) {
                        Player.STATE_BUFFERING -> {
                            _state.value = _state.value.copy(playing = false, errorMessage = null)
                            updateSessionState()
                        }
                        Player.STATE_READY -> {
                            val duration = exo.duration.takeIf { it > 0L } ?: item.durationMs
                            if (!requestedSeekApplied && startPositionMs > 0L) {
                                requestedSeekApplied = true
                                exo.seekTo(startPositionMs.coerceAtMost(duration.takeIf { it > 0L } ?: startPositionMs))
                            }
                            if (playbackRequested && requestPlaybackFocus()) exo.play()
                            _state.value = _state.value.copy(
                                index = index,
                                playing = exo.isPlaying,
                                durationMs = duration.coerceAtLeast(0L),
                                positionMs = exo.currentPosition.coerceAtLeast(0L),
                                errorMessage = null
                            )
                            updateSessionMetadata(item, duration.coerceAtLeast(0L))
                            if (!readyHandled) {
                                readyHandled = true
                                if (duration > 0L) onlineRepository.rememberResolvedDurationMs(ref.fileId, duration)
                                Log.d("SONUS_STREAM_PERF", "file=${ref.fileId} tap->ready=${SystemClock.elapsedRealtime() - tapStartedAt}ms")
                                prefetchNextOnlineDescriptor(index)
                            }
                            scheduleSpectrumHealthCheck(item)
                            updateSessionState()
                        }
                        Player.STATE_ENDED -> {
                            if (generation != onlineGeneration || onlinePlayer !== exo) return
                            finishCurrentTrack(completed = true, skipped = false)
                            if (_state.value.stopAfterCurrent) {
                                _state.value = _state.value.copy(stopAfterCurrent = false)
                                stopPlayback(recordCurrent = false)
                            } else if (shouldRepeatCurrent()) {
                                // Repetir 1 faixa continua tocando normalmente, mas voltas automáticas não geram
                                // novo tempo qualificado/retensão. Replay manual por seek continua válido.
                                suppressNextStreamPlayQualification = true
                                playIndex(index, shouldPlay = true)
                            } else {
                                advanceAfterCompletion()
                            }
                        }
                    }
                }

                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    if (generation != onlineGeneration || onlinePlayer !== exo) return
                    if (isPlaying && !counted) {
                        counted = true
                        if (!statsPlayRegistered) {
                            markTrackStarted()
                            if (!isRadioVoice(item)) {
                                stats.recordPlay(item)
                                statsPlayRegistered = true
                                onlineRepository.recordPlayedFileId(ref.fileId)
                                _state.value = _state.value.copy(sessionTrackCount = _state.value.sessionTrackCount + 1)
                            }
                        } else if (startedAtRealtimeMs <= 0L) {
                            startedAtRealtimeMs = SystemClock.elapsedRealtime()
                            startedAtPositionMs = exo.currentPosition.coerceAtLeast(0L)
                        }
                    }
                    if (isPlaying && !firstAudioLogged) {
                        firstAudioLogged = true
                        Log.d("SONUS_STREAM_PERF", "file=${ref.fileId} tap->audio=${SystemClock.elapsedRealtime() - tapStartedAt}ms")
                    }
                    _state.value = _state.value.copy(playing = isPlaying, positionMs = exo.currentPosition.coerceAtLeast(0L))
                    if (isPlaying) ensureForeground()
                    updateSessionState()
                }

                override fun onPlayerError(error: PlaybackException) {
                    if (generation != onlineGeneration || onlinePlayer !== exo) return
                    val message = error.errorCodeName.ifBlank { error.message ?: "erro desconhecido" }
                    val resumeAt = exo.currentPosition.coerceAtLeast(startPositionMs)
                    runCatching { exo.stop() }
                    runCatching { exo.release() }
                    if (onlinePlayer === exo) { onlinePlayer = null; onlinePlayerListener = null }

                    // Primeira falha normalmente é link temporário expirado/rota ruim. Renova uma
                    // única vez e volta da mesma posição, sem criar uma nova sessão analítica.
                    if (!forceFreshDescriptor && playbackRequested) {
                        onlineRepository.invalidatePlaybackDescriptor(ref.fileId)
                        _state.value = _state.value.copy(playing = false, errorMessage = null, positionMs = resumeAt)
                        updateSessionState()
                        scope.launch {
                            delay(90L)
                            if (generation == onlineGeneration && playbackRequested) {
                                playOnlineIndex(index, item, ref, true, resumeAt, forceFreshDescriptor = true, preserveStreamSession = true)
                            }
                        }
                        return
                    }

                        if (handleRadioMusicFailure(item, generation, "Falha no stream da SONUS Rádio: $message")) return

                val continueSequence = playbackRequested && _state.value.queue.size > 1 && consecutivePlaybackFailures < minOf(_state.value.queue.size, 5)
                    if (continueSequence) {
                        consecutivePlaybackFailures++
                        _state.value = _state.value.copy(playing = false, errorMessage = null)
                        updateSessionState()
                        scope.launch {
                            delay(120L)
                            if (generation == onlineGeneration && playbackRequested) advanceAfterCompletion()
                        }
                    } else {
                        playbackRequested = false
                        consecutivePlaybackFailures = 0
                        _state.value = _state.value.copy(playing = false, errorMessage = "Falha no stream: $message")
                        updateSessionState()
                    }
                }
            }
            onlinePlayerListener = listener
            exo.addListener(listener)
            exo.playWhenReady = false
            exo.setMediaItem(MediaItem.fromUri(stream.url))
            exo.prepare()
        }
    }

    private fun prefetchNextOnlineDescriptor(currentIndex: Int) {
        if (!_state.value.preloadNextEnabled) return
        val queue = _state.value.queue
        if (queue.size < 2) return
        val nextIndex = (currentIndex + 1).let { if (it <= queue.lastIndex) it else if (_state.value.repeatMode == 1) 0 else -1 }
        if (nextIndex !in queue.indices) return
        val ref = SonusOnlineRef.parse(queue[nextIndex].uri) ?: return
        onlinePrefetchJob?.cancel()
        onlinePrefetchJob = scope.launch(Dispatchers.IO) { onlineRepository.prefetchPlaybackDescriptor(ref.fileId) }
    }

    fun play() {
        // A intenção precisa existir antes do pedido de foco para que foco atrasado
        // consiga retomar a reprodução corretamente.
        playbackRequested = true
        if (!requestPlaybackFocus()) {
            _state.value = _state.value.copy(playing = false, errorMessage = null)
            updateSessionState()
            return
        }
        _state.value = _state.value.copy(errorMessage = null)
        keepServiceAliveForPlayback()
        val exo = onlinePlayer
        if (exo != null) {
            exo.play()
            if (exo.isPlaying) markTrackStarted()
            _state.value = _state.value.copy(playing = exo.isPlaying, positionMs = exo.currentPosition.coerceAtLeast(0L))
            ensureForeground(); updateSessionState()
            return
        }
        val p = player
        if (p == null) {
            val i = _state.value.index.takeIf { it >= 0 } ?: 0
            if (_state.value.queue.isNotEmpty()) {
                val resumeAt = _state.value.positionMs.coerceAtLeast(0L)
                playIndex(i, shouldPlay = true, startPositionMs = resumeAt)
            }
            return
        }
        runCatching { p.start() }
        runCatching { media3Spectrum.play() }
        markTrackStarted()
        _state.value = _state.value.copy(playing = p.isPlayingSafe())
        ensureForeground(); updateSessionState(); startOrbitIfNeeded()
    }

    fun pause(releaseFocus: Boolean = true) {
        playbackRequested = false
        val pausedAt = activePositionMs()
        accountListening(pausedAt)
        onlinePlayer?.pause()
        runCatching { player?.pause() }
        runCatching { media3Spectrum.pause() }
        silenceAuxiliaryPlayersForPause()
        // Online: libere imediatamente o ExoPlayer remoto ao pausar. Ao retomar,
        // o SONUS resolve novamente a URL temporária e volta da posição salva.
        if (isCloudItem(_state.value.current)) releasePlayers()
        zeroSpectrum()
        _state.value = _state.value.copy(playing = false, positionMs = pausedAt)
        if (releaseFocus) abandonPlaybackFocus()
        updateNotification(); updateSessionState()
    }

    fun toggle() { if (_state.value.playing) pause() else play() }

    fun next(userInitiated: Boolean) {
        if (userInitiated) finishCurrentTrack(completed = false, skipped = true)
        val next = chooseNextIndex() ?: run { if (_state.value.repeatMode == 1 && _state.value.queue.isNotEmpty()) 0 else null }
        val shouldPlay = userInitiated || playbackRequested
        if (next != null) playIndex(next, shouldPlay = shouldPlay) else stopPlayback()
    }

    fun previous() {
        val pos = activePositionMs().toInt()
        if (pos > 5_000) { seekTo(0); return }
        val s = _state.value
        val target = if (s.index > 0) s.index - 1 else if (s.repeatMode == 1 && s.queue.isNotEmpty()) s.queue.lastIndex else 0
        playIndex(target)
    }

    fun seekTo(ms: Long) {
        val safe = ms.coerceAtLeast(0L)
        onlinePlayer?.seekTo(safe)
        runCatching { player?.seekTo(safe.toInt()) }
        runCatching { media3Spectrum.seekTo(safe) }
        _state.value = _state.value.copy(positionMs = safe)
    }

    fun setRepeatMode(mode: Int) {
        val safe = mode.coerceIn(0, 2)
        if (_state.value.repeatMode == safe) return
        _state.value = _state.value.copy(repeatMode = safe)
        if (playbackRequested) refreshGaplessPreload()
        updateSessionState()
    }
    fun setShuffle(enabled: Boolean) {
        if (_state.value.shuffle == enabled) return
        _state.value = _state.value.copy(shuffle = enabled)
        if (playbackRequested) refreshGaplessPreload()
    }
    fun setCrossfade(seconds: Int) {
        val safe = seconds.coerceIn(0, 12)
        if (_state.value.crossfadeSeconds == safe) return
        _state.value = _state.value.copy(crossfadeSeconds = safe)
        if (playbackRequested) refreshGaplessPreload() else silenceAuxiliaryPlayersForPause()
    }
    fun setStreamFade(fadeInSeconds:Int, fadeOutSeconds:Int){
        val fi=fadeInSeconds.coerceIn(0,10); val fo=fadeOutSeconds.coerceIn(0,10)
        if (_state.value.fadeInSeconds==fi && _state.value.fadeOutSeconds==fo) return
        _state.value=_state.value.copy(fadeInSeconds=fi,fadeOutSeconds=fo)
    }
    fun setPreloadNextEnabled(enabled:Boolean){
        if (_state.value.preloadNextEnabled==enabled) return
        _state.value=_state.value.copy(preloadNextEnabled=enabled)
        if (playbackRequested) refreshGaplessPreload() else silenceAuxiliaryPlayersForPause()
    }

    fun setPlaybackSpeed(speed: Float) {
        val safe = speed.coerceIn(0.5f, 2.0f)
        // Navegar entre abas não pode reconfigurar o pipeline audível.
        // Reaplicar playbackParams com o mesmo valor pode produzir um clique/pop em alguns aparelhos.
        if (abs(_state.value.playbackSpeed - safe) < 0.0001f) return
        _state.value = _state.value.copy(playbackSpeed = safe)
        onlinePlayer?.setPlaybackSpeed(safe)
        player?.let { applyPlaybackSpeed(it, safe) }
        incomingPlayer?.let { applyPlaybackSpeed(it, safe) }
        gaplessPlayer?.let { applyPlaybackSpeed(it, safe) }
        runCatching { media3Spectrum.setSpeed(safe) }
        updateSessionState()
    }

    private fun applyPlaybackSpeed(target: MediaPlayer, speed: Float) {
        runCatching {
            val params = target.playbackParams.setSpeed(speed).setPitch(1f)
            target.playbackParams = params
        }
    }

    fun setLoopStartAtCurrent() {
        val start = activePositionMs().coerceAtLeast(0L)
        val oldEnd = _state.value.loopEndMs?.takeIf { it > start + 250L }
        _state.value = _state.value.copy(loopStartMs = start, loopEndMs = oldEnd)
    }

    fun setLoopEndAtCurrent() {
        val end = activePositionMs().coerceAtLeast(0L)
        val start = _state.value.loopStartMs
        if (start != null && end > start + 250L) _state.value = _state.value.copy(loopEndMs = end)
    }

    fun clearLoop() {
        _state.value = _state.value.copy(loopStartMs = null, loopEndMs = null)
    }


    fun moveQueue(from: Int, to: Int) {
        val s = _state.value
        if (from !in s.queue.indices || to !in s.queue.indices || from == to) return
        val currentUri = s.current?.uri
        val list = s.queue.toMutableList()
        val item = list.removeAt(from)
        list.add(to, item)
        val newIndex = currentUri?.let { uri -> list.indexOfFirst { it.uri == uri } }?.takeIf { it >= 0 } ?: s.index.coerceIn(0, list.lastIndex)
        _state.value = s.copy(queue = list, index = newIndex)
    }

    fun playNextFromQueue(index: Int) {
        val s = _state.value
        if (index !in s.queue.indices || s.queue.isEmpty()) return
        val currentUri = s.current?.uri ?: return
        if (s.queue[index].uri == currentUri) return
        val list = s.queue.toMutableList()
        val item = list.removeAt(index)
        val currentIndex = list.indexOfFirst { it.uri == currentUri }.coerceAtLeast(0)
        val target = (currentIndex + 1).coerceAtMost(list.size)
        list.add(target, item)
        _state.value = s.copy(queue = list, index = currentIndex)
    }

    fun clearQueue() {
        stopPlayback()
        _state.value = _state.value.copy(queue = emptyList(), index = -1, positionMs = 0L, durationMs = 0L, playing = false)
    }

    fun removeQueueAt(index: Int) {
        val s = _state.value
        if (index !in s.queue.indices) return
        val removingCurrent = index == s.index
        val list = s.queue.toMutableList().also { it.removeAt(index) }
        if (list.isEmpty()) {
            stopPlayback()
            _state.value = _state.value.copy(queue = emptyList(), index = -1)
            return
        }
        if (removingCurrent) {
            releasePlayers()
            val next = index.coerceAtMost(list.lastIndex)
            _state.value = s.copy(queue = list, index = next, positionMs = 0L, playing = false)
            playIndex(next)
        } else {
            val currentUri = s.current?.uri
            val newIndex = currentUri?.let { uri -> list.indexOfFirst { it.uri == uri } }?.takeIf { it >= 0 } ?: 0
            _state.value = s.copy(queue = list, index = newIndex)
        }
    }

    fun setSleepTimerMinutes(minutes: Int) {
        sleepJob?.cancel()
        if (minutes <= 0) {
            _state.value = _state.value.copy(sleepEndEpochMs = null)
            return
        }
        val end = System.currentTimeMillis() + minutes * 60_000L
        _state.value = _state.value.copy(sleepEndEpochMs = end)
        sleepJob = scope.launch {
            delay(minutes * 60_000L)
            stopPlayback()
            _state.value = _state.value.copy(sleepEndEpochMs = null)
        }
    }

    fun clearSleepTimer() = setSleepTimerMinutes(0)

    fun setStopAfterCurrent(enabled: Boolean) {
        _state.value = _state.value.copy(stopAfterCurrent = enabled)
        if (enabled) clearSleepTimer()
    }

    fun setEqualizerTenBands(values: List<Float>) {
        eqTenBands = values.take(10).toMutableList().apply { while (size < 10) add(0f) }
        applyEqualizer()
    }

    fun setSonusBassBoost(enabled: Boolean) {
        val strength = if (enabled) 140 else 0
        runCatching { bassBoost?.setStrength(strength.toShort()); bassBoost?.enabled = enabled }
    }

    fun setPremiumFeatureAccess(pulseLift: Boolean, orbit3d: Boolean, orbit8d: Boolean) {
        // Processamento extra desativado: preservar áudio limpo por padrão.
        pulseLiftAllowed = false
        updateNotification()
    }

    fun setPulseLift(enabled: Boolean) {
        _state.value = _state.value.copy(pulseLift = false)
        applyLoudness()
        applyPulseLiftHardware()
        applyEqualizer()
    }

    fun setPulseLiftProfile(profile: String) {
        val normalized = when(profile) { "Natural", "Max" -> profile; else -> "Boost" }
        _state.value = _state.value.copy(pulseLiftProfile = normalized)
        applyLoudness()
        applyPulseLiftHardware()
        applyEqualizer()
    }

    private fun applyPulseLiftHardware() {
        val s = _state.value
        val strength = if (!s.pulseLift) 0 else when(s.pulseLiftProfile) {
            "Natural" -> 70
            "Max" -> 170
            else -> 110
        }
        runCatching { bassBoost?.setStrength(strength.toShort()); bassBoost?.enabled = s.pulseLift }
    }

    fun setNormalization(enabled: Boolean) {
        _state.value = _state.value.copy(normalization = enabled)
        applyLoudness()
    }

    private fun applyLoudness() {
        val s = _state.value
        val gain = when {
            s.pulseLift -> when(s.pulseLiftProfile) {
                "Natural" -> 60
                "Max" -> 160
                else -> 100
            }
            s.normalization -> 0
            else -> 0
        }
        runCatching { loudness?.setTargetGain(gain); loudness?.enabled = gain > 0 }
    }

    /** Compatibilidade com preferências antigas: SONUS SPATIAL foi descontinuado na 0.8.13. */
    fun setPulseOrbit(mode: PulseOrbitMode, intensity: Int) {
        orbitJob?.cancel()
        runCatching { player?.setVolume(1f, 1f) }
        _state.value = _state.value.copy(orbitMode = PulseOrbitMode.OFF, orbitIntensity = 0, orbitPreset = "Off")
    }

    fun setPulseOrbitPreset(name: String, mode: PulseOrbitMode, intensity: Int, frequencyHz: Double = 0.115) =
        setPulseOrbit(PulseOrbitMode.OFF, 0)

    private fun applyPulseOrbitEffect() {
        orbitJob?.cancel()
        if (_state.value.orbitMode != PulseOrbitMode.OFF) _state.value = _state.value.copy(orbitMode = PulseOrbitMode.OFF, orbitIntensity = 0, orbitPreset = "Off")
        applyEqualizer() // reaplica o headroom; SPATIAL não pode sobrescrever o ganho limpo.
    }

    fun stopPlayback(recordCurrent: Boolean = true) {
        playbackRequested = false
        startedForPlayback = false
        abandonPlaybackFocus()
        sleepJob?.cancel(); sleepJob = null
        if (recordCurrent) finishCurrentTrack(completed = false, skipped = false)
        releasePlayers()
        zeroSpectrum()
        _state.value = _state.value.copy(playing = false, positionMs = 0L, sleepEndEpochMs = null, stopAfterCurrent = false)
        stopForeground(STOP_FOREGROUND_REMOVE)
        runCatching { (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).cancel(NOTIFICATION_ID) }
        mediaSession.isActive = false
        stopSelf()
    }

    private fun requestPlaybackFocus(): Boolean = runCatching {
        when (audioManager.requestAudioFocus(audioFocusRequest)) {
            AudioManager.AUDIOFOCUS_REQUEST_GRANTED -> {
                resumeAfterFocusGain = false
                true
            }
            AudioManager.AUDIOFOCUS_REQUEST_DELAYED -> {
                // Mantém a intenção de PLAY. Assim que o Android devolver o foco,
                // AUDIOFOCUS_GAIN retoma a faixa em vez de deixá-la preparada e pausada.
                resumeAfterFocusGain = playbackRequested
                false
            }
            else -> false
        }
    }.getOrDefault(false)

    private fun abandonPlaybackFocus() {
        runCatching { audioManager.abandonAudioFocusRequest(audioFocusRequest) }
    }

    private fun isCloudItem(item: PulsePlayerQueueItem?): Boolean {
        if (SonusOnlineRef.parse(item?.uri) != null) return true
        val source = item?.source?.trim()?.lowercase().orEmpty()
        // Compatibilidade defensiva com filas antigas. A UI de nuvem pessoal foi removida.
        return source in setOf("google drive", "onedrive", "dropbox", "pcloud", "mega", "sonus music", "sonus stream")
    }

    private fun isRadioItem(item: PulsePlayerQueueItem?): Boolean {
        if (item == null) return false
        if (item.kind == PulseQueueKind.RADIO_MUSIC || item.kind == PulseQueueKind.RADIO_VOICE) return true
        val source = item.source
        return source.contains("rádio", ignoreCase = true) || source.contains("radio", ignoreCase = true)
    }

    private fun isRadioVoice(item: PulsePlayerQueueItem?): Boolean =
        item?.kind == PulseQueueKind.RADIO_VOICE || item?.source?.contains("Locução", ignoreCase = true) == true

    private fun isRadioMusic(item: PulsePlayerQueueItem?): Boolean =
        item?.kind == PulseQueueKind.RADIO_MUSIC || (isRadioItem(item) && !isRadioVoice(item))

    private fun nextRadioMusicIndex(fromIndex: Int): Int? {
        val q = _state.value.queue
        if (q.isEmpty()) return null
        for (step in 1..q.size) {
            val idx = Math.floorMod(fromIndex + step, q.size)
            if (isRadioMusic(q[idx])) return idx
        }
        return null
    }

    private fun radioMusicCountBeforeIndex(queue: List<PulsePlayerQueueItem>, index: Int): Int {
        if (queue.isEmpty() || index !in queue.indices) return 0
        // Se a sessão começa exatamente numa locução (ex.: retomada do "ao vivo"), ela foi
        // colocada ali pelo motor após duas músicas; permitir a fala sem furar a proteção.
        if (isRadioVoice(queue[index])) return 2
        var count = 0
        var cursor = Math.floorMod(index - 1, queue.size)
        repeat(queue.size) {
            val previous = queue[cursor]
            if (isRadioVoice(previous)) return count.coerceAtMost(2)
            if (isRadioMusic(previous)) count++
            if (count >= 2) return 2
            cursor = Math.floorMod(cursor - 1, queue.size)
        }
        return count.coerceAtMost(2)
    }

    private fun handleRadioMusicFailure(item: PulsePlayerQueueItem, generation: Long, message: String): Boolean {
        if (!isRadioMusic(item)) return false
        consecutiveRadioMusicFailures++
        if (consecutiveRadioMusicFailures >= 3) {
            playbackRequested = false
            _state.value = _state.value.copy(playing = false, errorMessage = "SONUS Rádio sem músicas reproduzíveis no momento. Verifique a conexão e tente novamente.")
            updateSessionState()
            return true
        }
        _state.value = _state.value.copy(playing = false, errorMessage = null)
        updateSessionState()
        scope.launch {
            delay(160L)
            if (generation == onlineGeneration && playbackRequested) {
                val nextMusic = nextRadioMusicIndex(_state.value.index)
                if (nextMusic != null) playIndex(nextMusic, shouldPlay = true)
                else {
                    playbackRequested = false
                    _state.value = _state.value.copy(playing = false, errorMessage = message)
                    updateSessionState()
                }
            }
        }
        return true
    }

    private fun shouldRepeatCurrent(): Boolean = _state.value.repeatMode == 2 && !isRadioItem(_state.value.current)

    private fun attachLocalCompletionListener(target: MediaPlayer, index: Int) {
        target.setOnCompletionListener {
            if (crossfadeJob?.isActive == true) return@setOnCompletionListener
            finishCurrentTrack(completed = true, skipped = false)
            if (_state.value.stopAfterCurrent) {
                _state.value = _state.value.copy(stopAfterCurrent = false)
                stopPlayback(recordCurrent = false)
                return@setOnCompletionListener
            }
            if (shouldRepeatCurrent()) playIndex(index) else advanceAfterCompletion()
        }
    }

    /**
     * Regra code103: PAUSADO significa silêncio absoluto em todos os motores auxiliares.
     * Cancela crossfade/gapless sem alterar fila, posição ou contador.
     */
    private fun silenceAuxiliaryPlayersForPause() {
        auxiliaryGeneration++
        val hadCrossfade = crossfadeJob?.isActive == true || incomingPlayer != null
        crossfadeJob?.cancel(); crossfadeJob = null
        runCatching { incomingPlayer?.pause() }
        runCatching { incomingPlayer?.release() }
        incomingPlayer = null
        runCatching { player?.setNextMediaPlayer(null) }
        runCatching { gaplessPlayer?.pause() }
        runCatching { gaplessPlayer?.release() }
        gaplessPlayer = null
        gaplessNextIndex = null
        // O analisador Media3 usa um ExoPlayer independente. Mesmo mudo, ele deve
        // respeitar PAUSE para eliminar qualquer janela de reprodução durante rebind.
        runCatching { media3Spectrum.pause() }
        if (hadCrossfade) {
            player?.let { active ->
                runCatching { active.setVolume(1f, 1f) }
                val idx = _state.value.index
                if (idx >= 0) runCatching { attachLocalCompletionListener(active, idx) }
            }
        }
    }

    private fun chooseNextIndex(): Int? {
        val s = _state.value
        if (s.queue.isEmpty()) return null
        // A programação da Rádio já vem intercalada pelo SonusRadioEngine. Nunca embaralhar locuções.
        if (isRadioItem(s.current)) return if (s.index < s.queue.lastIndex) s.index + 1 else 0
        if (s.shuffle && s.queue.size > 1) return s.queue.indices.filter { it != s.index }.random()
        return (s.index + 1).takeIf { it <= s.queue.lastIndex }
    }

    private fun advanceAfterCompletion() {
        if (!playbackRequested) {
            _state.value = _state.value.copy(playing = false)
            updateNotification(); updateSessionState()
            return
        }
        val next = chooseNextIndex() ?: if (_state.value.repeatMode == 1 && _state.value.queue.isNotEmpty()) 0 else null
        if (next != null) playIndex(next, shouldPlay = true) else stopPlayback()
    }

    /**
     * Prepara a próxima faixa quando o crossfade está desligado e a encadeia com
     * MediaPlayer.setNextMediaPlayer. Isso reduz a lacuna entre arquivos compatíveis
     * sem aplicar sobreposição ou alterar os originais.
     */
    private fun prepareGaplessNext(current: MediaPlayer) {
        if (!playbackRequested) return
        if (isRadioItem(_state.value.current)) return
        if (_state.value.crossfadeSeconds > 0 || gaplessPlayer != null) return
        val generation = auxiliaryGeneration
        val next = when (_state.value.repeatMode) {
            2 -> _state.value.index.takeIf { it >= 0 }
            else -> chooseNextIndex() ?: if (_state.value.repeatMode == 1 && _state.value.queue.isNotEmpty()) 0 else null
        } ?: return
        val item = _state.value.queue.getOrNull(next) ?: return
        val fresh = MediaPlayer()
        try {
            fresh.setAudioAttributes(mediaAudioAttributes)
            fresh.setDataSource(this, Uri.parse(item.uri))
            fresh.setOnPreparedListener { prepared ->
                if (!playbackRequested || generation != auxiliaryGeneration || player !== current || _state.value.crossfadeSeconds > 0) {
                    runCatching { prepared.pause() }
                    runCatching { prepared.release() }
                    return@setOnPreparedListener
                }
                applyPlaybackSpeed(prepared, _state.value.playbackSpeed)
                gaplessPlayer = prepared
                gaplessNextIndex = next
                runCatching { current.setNextMediaPlayer(prepared) }.onFailure {
                    gaplessPlayer = null
                    gaplessNextIndex = null
                    runCatching { prepared.release() }
                }
            }
            fresh.setOnErrorListener { _, _, _ ->
                if (gaplessPlayer === fresh) { gaplessPlayer = null; gaplessNextIndex = null }
                runCatching { fresh.release() }
                true
            }
            fresh.prepareAsync()
        } catch (_: Throwable) {
            runCatching { fresh.release() }
        }
    }

    private fun promoteGaplessIfReady(): Boolean {
        val prepared = gaplessPlayer ?: return false
        val nextIndex = gaplessNextIndex ?: return false
        val nextItem = _state.value.queue.getOrNull(nextIndex) ?: return false
        val old = player
        gaplessPlayer = null
        gaplessNextIndex = null
        runCatching { old?.setNextMediaPlayer(null) }
        runCatching { old?.release() }
        player = prepared
        prepared.setOnCompletionListener {
            finishCurrentTrack(completed = true, skipped = false)
            if (_state.value.stopAfterCurrent) {
                _state.value = _state.value.copy(stopAfterCurrent = false)
                stopPlayback(recordCurrent = false)
                return@setOnCompletionListener
            }
            if (promoteGaplessIfReady()) return@setOnCompletionListener
            if (shouldRepeatCurrent()) playIndex(_state.value.index) else advanceAfterCompletion()
        }
        prepared.setOnErrorListener { _, _, _ ->
            // Falha técnica não representa uma decisão do usuário de pular a faixa.
            finishCurrentTrack(completed = false, skipped = false)
            next(userInitiated = false)
            true
        }
        if (playbackRequested && !prepared.isPlayingSafe()) runCatching { prepared.start() }
        _state.value = _state.value.copy(
            index = nextIndex,
            playing = prepared.isPlayingSafe(),
            positionMs = runCatching { prepared.currentPosition.toLong() }.getOrDefault(0L),
            durationMs = runCatching { prepared.duration.toLong() }.getOrDefault(nextItem.durationMs)
        )
        if (!statsPlayRegistered && !isRadioVoice(nextItem)) {
            stats.recordPlay(nextItem)
            statsPlayRegistered = true
            _state.value = _state.value.copy(sessionTrackCount = _state.value.sessionTrackCount + 1)
        }
        markTrackStarted()
        if (isCloudItem(nextItem)) {
            zeroSpectrum("SONUS Stream")
        } else {
            runCatching { media3Spectrum.load(nextItem.uri, _state.value.positionMs, playbackRequested, _state.value.playbackSpeed) }
            scheduleSpectrumHealthCheck(nextItem)
        }
        attachEffects(prepared.audioSessionId)
        updateSessionMetadata(nextItem, _state.value.durationMs)
        ensureForeground()
        updateSessionState()
        startOrbitIfNeeded()
        return true
    }

    private fun refreshGaplessPreload() {
        if (!playbackRequested) {
            silenceAuxiliaryPlayersForPause()
            return
        }
        runCatching { player?.setNextMediaPlayer(null) }
        runCatching { gaplessPlayer?.release() }
        gaplessPlayer = null
        gaplessNextIndex = null
        if (!_state.value.preloadNextEnabled) return
        // MediaPlayer local: prepara de verdade a próxima faixa e a encadeia.
        // No SONUS Stream, ExoPlayer mantém buffer progressivo da faixa atual e a fila
        // online é trocada sem bloquear a UI; não criamos um segundo player só para preload.
        val current = player ?: return
        if (isCloudItem(_state.value.current)) return
        prepareGaplessNext(current)
    }

    private fun beginStreamPlaySession(fileId: Long, suppressQualification: Boolean = false) {
        streamPlayFileId = fileId
        streamPlaySessionId = "${fileId}_${java.util.UUID.randomUUID()}"
        streamPlayListenedMs = 0L
        streamPlayLastTickMs = System.currentTimeMillis()
        streamPlayCounted = false
        streamPlayClaimResolved = false
        streamLocalPlayCounted = false
        streamPlayQualified = false
        streamLocalCheckpointedMs = 0L
        streamPlaySuppressQualification = suppressQualification
        streamPlaySessionStarted = !suppressQualification
        streamPlayLastStartAttemptMs = 0L
        streamPlayClaimInFlight = false
        streamPlayThresholdInFlight = false
        streamPlayThresholdResolved = false
        streamPlayRequiredMs = Long.MAX_VALUE
        if (!suppressQualification) {
            // code108: startPlaySession é local/direto e não depende mais de Function HTTP.
            scope.launch(Dispatchers.IO) { streamPlatform.startPlaySession(fileId, streamPlaySessionId) }
        }
    }

    private fun tryResolveStreamThreshold() {
        if (streamPlaySuppressQualification || streamPlayFileId <= 0L || streamPlayThresholdResolved) return
        val duration = activeDurationMs().coerceAtLeast(_state.value.current?.durationMs ?: 0L)
        if (duration <= 0L) return
        // code121: o Player arma o monitor no clique e resolve o limiar localmente.
        // 50% de tempo realmente ouvido; seek não acrescenta tempo ao acumulador.
        streamPlayRequiredMs = ((duration + 1L) / 2L).coerceIn(1_000L, duration)
        streamPlayThresholdResolved = true
        streamPlayThresholdInFlight = false
    }

    private fun resetStreamPlayClock() {
        streamPlayLastTickMs = 0L
    }

    /**
     * Conta somente tempo real em PLAY. Seek e pausa não avançam o relógio válido.
     * code121: a fonte de verdade é currentListenedMs. A sessão nasce no clique,
     * aguarda 50% de tempo real em PLAY e então dispara uma única contabilização.
     */
    private fun accountStreamValidPlay(isPlaying: Boolean) {
        if (streamPlayFileId <= 0L || streamPlaySessionId.isBlank() || streamPlaySuppressQualification) return
        streamPlayLastTickMs = System.currentTimeMillis()
        if (!isPlaying) return

        // accountListening() roda imediatamente antes deste método no loop de 500 ms.
        // Assim eliminamos um segundo relógio independente que podia deixar o Stream em zero.
        streamPlayListenedMs = currentListenedMs.coerceAtLeast(0L)
        val currentItem = _state.value.current
        if (currentItem != null && streamPlayListenedMs - streamLocalCheckpointedMs >= 5_000L) {
            val delta = (streamPlayListenedMs - streamLocalCheckpointedMs).coerceAtLeast(0L)
            streamLocalAnalytics.recordListeningDelta(currentItem, streamPlayFileId, delta)
            streamLocalCheckpointedMs = streamPlayListenedMs
        }
        if (!streamPlayThresholdResolved || streamPlayRequiredMs == Long.MAX_VALUE) tryResolveStreamThreshold()
        val required = streamPlayRequiredMs
        if (required != Long.MAX_VALUE && streamPlayListenedMs >= required) {
            streamPlayQualified = true
            val fileId = streamPlayFileId
            val sessionId = streamPlaySessionId
            val listened = streamPlayListenedMs
            val duration = activeDurationMs().coerceAtLeast(_state.value.current?.durationMs ?: 0L)
            val source = _state.value.current?.source.orEmpty().ifBlank { "SONUS Stream" }
            val item = _state.value.current

            // Analytics pessoal é local-first e usa exatamente o mesmo motor de tempo do Player.
            if (!streamLocalPlayCounted && item != null) {
                streamLocalPlayCounted = streamLocalAnalytics.recordValidPlayIfEligible(
                    item, fileId, required, com.sonusstudios.streampulse.stream.SONUS_STREAM_VIEW_COOLDOWN_MS
                )
            }

            if (!streamPlayClaimResolved && !streamPlayClaimInFlight) {
                streamPlayClaimInFlight = true
                scope.launch(Dispatchers.IO) {
                    val claim = streamPlatform.claimValidPlay(fileId, sessionId, listened, duration, source)
                    if (streamPlayFileId == fileId && streamPlaySessionId == sessionId) {
                        streamPlayClaimInFlight = false
                        if (claim.isSuccess) {
                            streamPlayClaimResolved = true
                            if (claim.getOrDefault(false)) streamPlayCounted = true
                        }
                    }
                }
            }
        }
    }

    private fun applyStreamEdgeFade(position:Long,duration:Long){
        if(duration<=0L||!_state.value.playing)return
        val source = _state.value.current?.source.orEmpty()
        if (source.contains("rádio", ignoreCase = true) || source.contains("radio", ignoreCase = true)) {
            runCatching { player?.setVolume(1f,1f) }
            onlinePlayer?.volume = 1f
            return
        }
        val cross=_state.value.crossfadeSeconds
        val fi=if(cross>0)0 else _state.value.fadeInSeconds
        val fo=if(cross>0)0 else _state.value.fadeOutSeconds
        var gain=1f
        if(fi>0 && position < fi*1000L) gain=(position.toFloat()/(fi*1000f)).coerceIn(.04f,1f)
        val rem=duration-position
        if(fo>0 && rem in 0..fo*1000L) gain=minOf(gain,(rem.toFloat()/(fo*1000f)).coerceIn(.04f,1f))
        runCatching{player?.setVolume(gain,gain)}
        onlinePlayer?.volume=gain
    }

    private fun maybeStartCrossfade(position: Long, duration: Long) {
        if (!playbackRequested) return
        if (isCloudItem(_state.value.current) || isRadioItem(_state.value.current)) return
        if (_state.value.loopStartMs != null && _state.value.loopEndMs != null) return
        if (_state.value.stopAfterCurrent) return
        val seconds = _state.value.crossfadeSeconds
        if (seconds <= 0 || duration <= 0 || crossfadeJob?.isActive == true || incomingPlayer != null) return
        val remaining = duration - position
        if (remaining in 1..seconds * 1000L) {
            val next = chooseNextIndex() ?: if (_state.value.repeatMode == 1 && _state.value.queue.isNotEmpty()) 0 else return
            startCrossfade(next, seconds)
        }
    }

    private fun startCrossfade(nextIndex: Int, seconds: Int) {
        if (!playbackRequested) return
        val nextItem = _state.value.queue.getOrNull(nextIndex) ?: return
        if (isCloudItem(nextItem) || isRadioItem(_state.value.current) || isRadioItem(nextItem)) return
        val old = player ?: return
        val generation = auxiliaryGeneration
        val fresh = MediaPlayer()
        incomingPlayer = fresh
        try {
            fresh.setAudioAttributes(mediaAudioAttributes)
            fresh.setDataSource(this, Uri.parse(nextItem.uri))
            fresh.setOnPreparedListener { prepared ->
                if (!playbackRequested || generation != auxiliaryGeneration || incomingPlayer !== fresh || player !== old) {
                    if (incomingPlayer === fresh) incomingPlayer = null
                    runCatching { prepared.pause() }
                    runCatching { prepared.release() }
                    return@setOnPreparedListener
                }
                applyPlaybackSpeed(prepared, _state.value.playbackSpeed)
                prepared.setVolume(0f, 0f)
                // Durante o crossfade, a próxima faixa já É o player que será promovido.
                // O listener antigo é removido para impedir uma segunda promoção/reinício no fim da faixa A.
                runCatching { old.setOnCompletionListener(null) }
                if (!playbackRequested || generation != auxiliaryGeneration) {
                    if (incomingPlayer === fresh) incomingPlayer = null
                    runCatching { prepared.release() }
                    return@setOnPreparedListener
                }
                prepared.start()
                crossfadeJob = scope.launch {
                    orbitJob?.cancel()
                    val steps = (seconds * 20).coerceAtLeast(10)
                    repeat(steps) { i ->
                        if (!playbackRequested || generation != auxiliaryGeneration || incomingPlayer !== prepared) {
                            runCatching { prepared.pause() }
                            runCatching { prepared.release() }
                            if (incomingPlayer === prepared) incomingPlayer = null
                            runCatching { old.setVolume(1f, 1f) }
                            val activeIndex = _state.value.index
                            if (player === old && activeIndex >= 0) runCatching { attachLocalCompletionListener(old, activeIndex) }
                            return@launch
                        }
                        val t = (i + 1f) / steps
                        // Equal-power: evita a queda perceptível de volume no centro da transição.
                        val outGain = kotlin.math.cos(t * Math.PI / 2.0).toFloat()
                        val inGain = kotlin.math.sin(t * Math.PI / 2.0).toFloat()
                        runCatching { old.setVolume(outGain, outGain) }
                        runCatching { prepared.setVolume(inGain, inGain) }
                        delay((seconds * 1000L) / steps)
                    }
                    finishCurrentTrack(completed = true, skipped = false)
                    runCatching { old.release() }
                    player = prepared
                    incomingPlayer = null
                    prepared.setOnCompletionListener {
                        finishCurrentTrack(completed = true, skipped = false)
                        if (_state.value.stopAfterCurrent) {
                            _state.value = _state.value.copy(stopAfterCurrent = false)
                            stopPlayback(recordCurrent = false)
                            return@setOnCompletionListener
                        }
                        if (shouldRepeatCurrent()) playIndex(_state.value.index) else advanceAfterCompletion()
                    }
                    prepared.setOnErrorListener { _, _, _ ->
                        // Falha técnica do crossfade não pode inflar o contador de pulos.
                        finishCurrentTrack(completed = false, skipped = false)
                        next(userInitiated = false)
                        true
                    }
                    _state.value = _state.value.copy(index = nextIndex, playing = true, positionMs = prepared.currentPosition.toLong(), durationMs = prepared.duration.toLong())
                    if (!statsPlayRegistered && !isRadioVoice(nextItem)) {
                        stats.recordPlay(nextItem)
                        statsPlayRegistered = true
                        _state.value = _state.value.copy(sessionTrackCount = _state.value.sessionTrackCount + 1)
                    }
                    markTrackStarted()
                    if (isCloudItem(nextItem)) {
                        zeroSpectrum("SONUS Stream")
                    } else {
                        runCatching { media3Spectrum.load(nextItem.uri, prepared.currentPosition.toLong(), true, _state.value.playbackSpeed) }
                        scheduleSpectrumHealthCheck(nextItem)
                    }
                    attachEffects(prepared.audioSessionId)
                    updateSessionMetadata(nextItem, prepared.duration.toLong())
                    ensureForeground(); startOrbitIfNeeded()
                }
            }
            fresh.setOnErrorListener { _, _, _ -> incomingPlayer = null; runCatching { fresh.release() }; true }
            fresh.prepareAsync()
        } catch (_: Throwable) { incomingPlayer = null; runCatching { fresh.release() } }
    }

    private fun setSpectrumEngine(engine: String, spectrum: List<Float>? = null) {
        lastSpectrumEngine = engine
        if (spectrum != null) _spectrum.value = spectrum
        // spectrumEngine muda raramente; mantenha-o no estado principal apenas para diagnóstico OWNER.
        if (_state.value.spectrumEngine != engine) _state.value = _state.value.copy(spectrumEngine = engine)
    }

    private fun zeroSpectrum(engine: String = _state.value.spectrumEngine) {
        _spectrum.value = List(24) { 0f }
        if (_state.value.spectrumEngine != engine) _state.value = _state.value.copy(spectrumEngine = engine)
    }

    /**
     * Spectro em camadas:
     * 1) PCM Media3 (independente do Visualizer/DSP do fabricante);
     * 2) Visualizer nativo quando continua entregando dados reais;
     * 3) PCM Compat por decodificação de pequenos trechos;
     * 4) fallback estático somente se todos os caminhos falharem.
     */
    private fun scheduleSpectrumHealthCheck(item: PulsePlayerQueueItem?) {
        val target = item ?: return
        if (isCloudItem(target)) {
            spectrumHealthJob?.cancel()
            compatSpectrumAnalysisJob?.cancel(); compatSpectrumAnalysisJob = null
            compatSpectrumJob?.cancel(); compatSpectrumJob = null
            media3HealthyEvents = 0
            lastMedia3SpectrumAt = 0L
            nativeHealthyEvents = 0
            lastNativeSignature = Float.NaN
            setSpectrumEngine("PCM Media3", List(24) { 0f })
            spectrumHealthJob = scope.launch {
                delay(650L)
                while (isActive && _state.value.current?.uri == target.uri) {
                    if (_state.value.playing) {
                        val now = android.os.SystemClock.elapsedRealtime()
                        val media3Fresh = media3Spectrum.isFresh(now, 1_800L) ||
                            (media3HealthyEvents >= 2 && now - lastMedia3SpectrumAt <= 1_800L)
                        if (media3Fresh) {
                            if (_state.value.spectrumEngine != "PCM Media3") setSpectrumEngine("PCM Media3")
                        } else {
                            val nativeFresh = nativeHealthyEvents >= 2 && now - lastNativeSpectrumAt <= 1_300L
                            if (nativeFresh) {
                                if (_state.value.spectrumEngine != "Native") setSpectrumEngine("Native")
                            } else if (_state.value.spectrumEngine != "PCM Media3") {
                                // Aguarda o próximo buffer PCM sem fabricar animação falsa.
                                setSpectrumEngine("PCM Media3", List(24) { 0f })
                            }
                        }
                    }
                    delay(850L)
                }
            }
            return
        }
        spectrumHealthJob?.cancel()
        compatSpectrumAnalysisJob?.cancel()
        compatSpectrumJob?.cancel()
        compatSpectrumUri = target.uri
        compatSpectrumFrames = emptyList()
        compatSpectrumStartMs = 0L
        compatSpectrumEndMs = 0L
        compatSpectrumRetryAfterMs = 0L
        compatSpectrumFailures = 0
        nativeHealthyEvents = 0
        lastNativeSignature = Float.NaN
        media3HealthyEvents = 0
        lastMedia3SpectrumAt = 0L
        setSpectrumEngine("PCM Media3", List(24) { 0f })

        runCatching {
            val pos = runCatching { player?.currentPosition?.toLong() ?: _state.value.positionMs }.getOrDefault(_state.value.positionMs)
            media3Spectrum.sync(target.uri, pos, _state.value.playing || playbackRequested, _state.value.playbackSpeed)
        }

        spectrumHealthJob = scope.launch {
            delay(900L)
            while (isActive && _state.value.current?.uri == target.uri) {
                val now = android.os.SystemClock.elapsedRealtime()
                val pos = runCatching { player?.currentPosition?.toLong() ?: _state.value.positionMs }
                    .getOrDefault(_state.value.positionMs).coerceAtLeast(0L)

                if (_state.value.playing) {
                    runCatching { media3Spectrum.sync(target.uri, pos, true, _state.value.playbackSpeed) }
                    val media3Fresh = media3Spectrum.isFresh(now, 1_800L) ||
                        (media3HealthyEvents >= 2 && now - lastMedia3SpectrumAt <= 1_800L)

                    if (media3Fresh) {
                        compatSpectrumAnalysisJob?.cancel(); compatSpectrumAnalysisJob = null
                        compatSpectrumJob?.cancel(); compatSpectrumJob = null
                        if (_state.value.spectrumEngine != "PCM Media3") setSpectrumEngine("PCM Media3")
                    } else {
                        if (now - lastMedia3RestartAt >= 3_500L) {
                            lastMedia3RestartAt = now
                            runCatching { media3Spectrum.restartIfStale(pos, now) }
                        }
                        val nativeFresh = nativeHealthyEvents >= 2 && now - lastNativeSpectrumAt <= 1_300L
                        if (nativeFresh) {
                            if (_state.value.spectrumEngine != "Native") setSpectrumEngine("Native")
                        } else {
                            ensureCompatibilitySpectrum(target)
                            startCompatibilitySpectrumLoop(target.uri)
                        }
                    }
                }
                delay(1_050L)
            }
        }
    }

    private fun ensureCompatibilitySpectrum(target: PulsePlayerQueueItem, forceReload: Boolean = false, requestedPositionMs: Long? = null) {
        val now = android.os.SystemClock.elapsedRealtime()
        if (!forceReload && now < compatSpectrumRetryAfterMs) return
        val position = (requestedPositionMs ?: runCatching { player?.currentPosition?.toLong() }.getOrNull() ?: _state.value.positionMs).coerceAtLeast(0L)
        val segmentStart = (position - 1_000L).coerceAtLeast(0L)
        val bucket = segmentStart / 30_000L
        val cacheKey = "${target.uri}|$bucket"
        val cached = compatSpectrumCache[cacheKey]
        if (!forceReload && cached != null && cached.isNotEmpty() && position in cached.first().timeMs..cached.last().timeMs) {
            compatSpectrumUri = target.uri
            compatSpectrumFrames = cached
            compatSpectrumStartMs = cached.first().timeMs
            compatSpectrumEndMs = cached.last().timeMs
            setSpectrumEngine("PCM Compat")
            return
        }
        if (!forceReload && compatSpectrumAnalysisJob?.isActive == true) return
        if (!forceReload && compatSpectrumUri == target.uri && position in compatSpectrumStartMs..compatSpectrumEndMs && compatSpectrumFrames.isNotEmpty()) return

        compatSpectrumAnalysisJob?.cancel()
        compatSpectrumUri = target.uri
        compatSpectrumAnalysisJob = scope.launch(Dispatchers.IO) {
            // ~37 s em 44,1 kHz: suficiente para acompanhar a reprodução sem decodificar a faixa inteira.
            val result = LocalSpectrumAnalyzer.analyze(
                this@PulsePlayerService,
                Uri.parse(target.uri),
                maxFrames = 1_600,
                startMs = segmentStart
            ).getOrNull()
            if (!isActive) return@launch
            if (result == null || result.frames.isEmpty()) {
                withContext(Dispatchers.Main.immediate) {
                    if (_state.value.current?.uri == target.uri) {
                        compatSpectrumFailures = (compatSpectrumFailures + 1).coerceAtMost(6)
                        val retryDelay = when (compatSpectrumFailures) {
                            1 -> 5_000L
                            2 -> 12_000L
                            else -> 30_000L
                        }
                        compatSpectrumRetryAfterMs = android.os.SystemClock.elapsedRealtime() + retryDelay
                        setSpectrumEngine("Fallback", List(24) { 0f })
                    }
                }
                return@launch
            }
            withContext(Dispatchers.Main.immediate) {
                if (_state.value.current?.uri != target.uri) return@withContext
                compatSpectrumFrames = result.frames
                compatSpectrumStartMs = result.frames.first().timeMs
                compatSpectrumEndMs = result.frames.last().timeMs
                compatSpectrumFailures = 0
                compatSpectrumRetryAfterMs = 0L
                compatSpectrumCache[cacheKey] = result.frames
                while (compatSpectrumCache.size > 4) {
                    val firstKey = compatSpectrumCache.keys.firstOrNull() ?: break
                    compatSpectrumCache.remove(firstKey)
                }
                setSpectrumEngine("PCM Compat")
            }
        }
    }

    private fun startCompatibilitySpectrumLoop(uri: String) {
        if (compatSpectrumJob?.isActive == true && compatSpectrumUri == uri) return
        compatSpectrumJob?.cancel()
        compatSpectrumJob = scope.launch {
            while (isActive && compatSpectrumUri == uri && _state.value.current?.uri == uri) {
                delay(70L)
                if (!_state.value.playing) continue
                val now = android.os.SystemClock.elapsedRealtime()
                val media3Fresh = media3Spectrum.isFresh(now, 1_800L) ||
                    (media3HealthyEvents >= 2 && now - lastMedia3SpectrumAt <= 1_800L)
                if (media3Fresh) {
                    if (_state.value.spectrumEngine != "PCM Media3") setSpectrumEngine("PCM Media3")
                    continue
                }
                val nativeFresh = nativeHealthyEvents >= 2 && now - lastNativeSpectrumAt <= 900L
                if (nativeFresh) {
                    if (_state.value.spectrumEngine != "Native") setSpectrumEngine("Native")
                    continue
                }

                val pos = runCatching { player?.currentPosition?.toLong() ?: _state.value.positionMs }.getOrDefault(_state.value.positionMs).coerceAtLeast(0L)
                val frames = compatSpectrumFrames
                if (frames.isEmpty() || pos < compatSpectrumStartMs || pos > compatSpectrumEndMs - 900L) {
                    _state.value.current?.let { ensureCompatibilitySpectrum(it, requestedPositionMs = pos) }
                    continue
                }
                val idx = frames.binarySearchBy(pos) { it.timeMs }.let { found ->
                    if (found >= 0) found else (-found - 1).coerceIn(0, frames.lastIndex)
                }
                val values = frames[idx].values
                setSpectrumEngine("PCM Compat", values.map { (it * 1.18f).coerceIn(0f, 1f) })
            }
        }
    }

    private fun markNativeSpectrumHealthy(bins: List<Float>) {
        if (bins.isEmpty()) return
        val energy = bins.average().toFloat()
        if (energy <= .004f) return
        val signature = bins.foldIndexed(0f) { index, acc, value -> acc + value * (index + 1) }
        val changed = lastNativeSignature.isNaN() || kotlin.math.abs(signature - lastNativeSignature) > .004f
        if (!changed) return
        lastNativeSignature = signature
        nativeHealthyEvents = (nativeHealthyEvents + 1).coerceAtMost(1000)
        val now = android.os.SystemClock.elapsedRealtime()
        lastNativeSpectrumAt = now
        // Native permanece aquecido como fallback, mas nunca atropela PCM Media3 saudável.
        val media3Fresh = media3Spectrum.isFresh(now, 1_800L) ||
            (media3HealthyEvents >= 2 && now - lastMedia3SpectrumAt <= 1_800L)
        if (!media3Fresh) setSpectrumEngine("Native", bins)
    }

    private fun attachEffects(sessionId: Int) {
        releaseEffects()
        // Nova faixa = nova sessão. Não deixe timestamp de uma sessão anterior bloquear o fallback.
        lastNativeSpectrumAt = 0L
        nativeHealthyEvents = 0
        lastNativeSignature = Float.NaN
        // PCM Media3 é a fonte principal; o Visualizer abaixo fica preparado como fallback.
        if (_state.value.spectrumEngine != "PCM Media3") setSpectrumEngine("PCM Media3", List(24) { 0f })
        // O EQ nasce desligado. Em alguns firmwares, manter AudioEffect ativo mesmo em 0 dB
        // colore/distorce o caminho. Só habilitamos quando existe ajuste real.
        equalizer = runCatching { Equalizer(0, sessionId).apply { enabled = false } }.getOrNull()
        bassBoost = runCatching { BassBoost(0, sessionId) }.getOrNull()
        loudness = runCatching { LoudnessEnhancer(sessionId) }.getOrNull()
        visualizer = runCatching {
            val range = Visualizer.getCaptureSizeRange()
            val supported = listOf(1024, 512, 256, range[0], range[1])
                .map { it.coerceIn(range[0], range[1]) }
                .distinct()
                .firstOrNull { size -> size > 0 && (size and (size - 1)) == 0 }
                ?: range[0]
            var lastFftAt = 0L
            var lastFftEnergy = 0f
            Visualizer(sessionId).apply {
                runCatching { captureSize = supported }
                runCatching { scalingMode = Visualizer.SCALING_MODE_NORMALIZED }
                setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                    override fun onWaveFormDataCapture(v: Visualizer?, waveform: ByteArray?, samplingRate: Int) {
                        if (waveform == null || waveform.size < 16) return
                        val now = android.os.SystemClock.elapsedRealtime()
                        // Alguns firmwares Samsung/Motorola retornam FFT zerado, mas waveform válido.
                        // Nesses aparelhos o waveform vira fallback automático para manter o visualizador vivo.
                        if (now - lastFftAt < 650L && lastFftEnergy > .015f) return
                        val bins = MutableList(24) { 0f }
                        val chunk = (waveform.size / 24).coerceAtLeast(1)
                        for (b in 0 until 24) {
                            val start = b * chunk
                            val end = if (b == 23) waveform.size else ((b + 1) * chunk).coerceAtMost(waveform.size)
                            var sum = 0.0
                            var count = 0
                            for (i in start until end) {
                                val centered = (waveform[i].toInt() and 0xFF) - 128
                                sum += centered * centered.toDouble()
                                count++
                            }
                            val rms = if (count == 0) 0f else kotlin.math.sqrt(sum / count).toFloat() / 128f
                            bins[b] = (rms * 1.35f).coerceIn(0f, 1f)
                        }
                        markNativeSpectrumHealthy(bins)
                    }

                    override fun onFftDataCapture(v: Visualizer?, fft: ByteArray?, samplingRate: Int) {
                        if (fft == null || fft.size < 4) return
                        val bins = MutableList(24) { 0f }
                        val counts = IntArray(24)
                        var i = 2
                        while (i + 1 < fft.size) {
                            val re = fft[i].toInt(); val im = fft[i + 1].toInt()
                            val mag = kotlin.math.sqrt((re * re + im * im).toDouble()).toFloat()
                            // Mapeamento logarítmico dá movimento útil também nas bandas médias/agudas.
                            val normalized = (i / 2f) / (fft.size / 2f)
                            val warped = kotlin.math.sqrt(normalized.coerceIn(0f, 1f))
                            val band = (warped * 24).toInt().coerceIn(0, 23)
                            bins[band] += mag; counts[band]++
                            i += 2
                        }
                        for (b in bins.indices) {
                            bins[b] = if (counts[b] == 0) 0f else (bins[b] / counts[b] / 72f).coerceIn(0f, 1f)
                        }
                        lastFftEnergy = bins.average().toFloat()
                        if (lastFftEnergy > .003f) {
                            lastFftAt = android.os.SystemClock.elapsedRealtime()
                            markNativeSpectrumHealthy(bins)
                        }
                    }
                }, (Visualizer.getMaxCaptureRate() * .60f).toInt().coerceAtLeast(1000), true, true)
                enabled = true
            }
        }.getOrNull()
        applyEqualizer()
        setPulseLift(_state.value.pulseLift)
        // Reaplica o perfil atual sem apagar o nome/frequência do preset escolhido.
        applyPulseOrbitEffect()
    }

    private fun applyEqualizer() {
        val eq = equalizer ?: return
        val targetHz = listOf(32, 64, 125, 250, 500, 1000, 2000, 4000, 8000, 16000)
        val range = runCatching { eq.bandLevelRange }.getOrNull() ?: return
        var maxPositiveDb = 0f
        var anyAdjustment = false
        for (band in 0 until eq.numberOfBands.toInt()) {
            val centerHz = eq.getCenterFreq(band.toShort()) / 1000
            val idx = targetHz.indices.minByOrNull { kotlin.math.abs(targetHz[it] - centerHz) } ?: 0
            val userDb = eqTenBands.getOrElse(idx) { 0f }
            val liftDb = if (_state.value.pulseLift) {
                when(_state.value.pulseLiftProfile) {
                    "Natural" -> listOf(.4f,.5f,.3f,-.2f,-.3f,0f,.2f,.3f,.1f,0f)[idx]
                    "Max" -> listOf(.8f,1.0f,.7f,-.3f,-.4f,0f,.3f,.5f,.2f,0f)[idx]
                    else -> listOf(.6f,.7f,.5f,-.2f,-.3f,0f,.2f,.4f,.2f,0f)[idx]
                }
            } else 0f
            val totalDb = (userDb + liftDb).coerceIn(-10f, 10f)
            if (kotlin.math.abs(totalDb) >= .05f) anyAdjustment = true
            if (totalDb > maxPositiveDb) maxPositiveDb = totalDb
            val milliBel = (totalDb * 100f).toInt().coerceIn(range[0].toInt(), range[1].toInt())
            runCatching { eq.setBandLevel(band.toShort(), milliBel.toShort()) }
        }
        runCatching { eq.enabled = anyAdjustment }
        // Reserva de headroom antes de qualquer boost. Flat + BOOST desligado permanece 1.0/bit-transparent
        // dentro do caminho MediaPlayer, evitando o som áspero observado em alguns aparelhos.
        val reserveDb = if (maxPositiveDb > 0f) maxPositiveDb + .8f else 0f
        val gain = if (reserveDb <= 0f) 1f else Math.pow(10.0, (-reserveDb / 20.0).toDouble()).toFloat().coerceIn(.58f, 1f)
        runCatching { player?.setVolume(gain, gain) }
    }

    private fun startOrbitIfNeeded() {
        orbitJob?.cancel()
        applyEqualizer()
    }

    private fun accountListening(currentPosition: Long) {
        if (!_state.value.playing || startedAtRealtimeMs <= 0L) return
        val now = android.os.SystemClock.elapsedRealtime()
        val elapsed = (now - startedAtRealtimeMs).coerceAtLeast(0L)
        if (elapsed >= 500L) {
            val add = elapsed.coerceAtMost(2_000L)
            currentListenedMs += add
            _state.value = _state.value.copy(sessionListeningMs = _state.value.sessionListeningMs + add)
            _state.value.current?.takeUnless(::isRadioVoice)?.let { stats.addListening(it, add) }
            startedAtRealtimeMs = now
            startedAtPositionMs = currentPosition
        }
    }

    private fun markTrackStarted() {
        val item = _state.value.current
        if (!isRadioVoice(item)) consecutivePlaybackFailures = 0
        if (isRadioMusic(item)) {
            consecutiveRadioMusicFailures = 0
            if (_state.value.index != lastRadioStartedIndex) {
                radioSuccessfulMusicSinceVoice = (radioSuccessfulMusicSinceVoice + 1).coerceAtMost(2)
                lastRadioStartedIndex = _state.value.index
            }
        } else if (isRadioVoice(item)) {
            radioSuccessfulMusicSinceVoice = 0
            lastRadioStartedIndex = _state.value.index
            item?.let { SonusRadioEngine.recordVoicePlayed(applicationContext, it.radioStationId, it.uri) }
        } else {
            consecutiveRadioMusicFailures = 0
            radioSuccessfulMusicSinceVoice = 0
            lastRadioStartedIndex = -1
        }
        startedAtRealtimeMs = android.os.SystemClock.elapsedRealtime()
        startedAtPositionMs = activePositionMs().coerceAtLeast(0L)
        currentListenedMs = 0L
    }

    private fun finishCurrentTrack(completed: Boolean, skipped: Boolean) {
        val item = _state.value.current ?: return
        accountListening(activePositionMs().coerceAtLeast(0L))
        val hadRegisteredPlay = statsPlayRegistered
        if (hadRegisteredPlay && completed) stats.recordCompleted(item)
        if (hadRegisteredPlay && skipped && !completed && currentListenedMs < ((_state.value.durationMs * .65).toLong().coerceAtLeast(15_000L))) {
            stats.recordSkip(item)
        }
        val fileId = streamPlayFileId
        val sessionId = streamPlaySessionId
        val listened = maxOf(streamPlayListenedMs, currentListenedMs).coerceAtLeast(0L)
        val duration = _state.value.durationMs
        if (fileId > 0L && sessionId.isNotBlank()) {
            // code120: tempo é salvo mesmo quando a view cai no cooldown. Só a contagem de
            // visualização é bloqueada; ouvir continua sendo uma sessão real de Analytics.
            val remainingLocal = (listened - streamLocalCheckpointedMs).coerceAtLeast(0L)
            if (remainingLocal > 0L) {
                streamLocalAnalytics.recordListeningDelta(item, fileId, remainingLocal)
                streamLocalCheckpointedMs = listened
            }
            if (streamPlayQualified) {
                streamLocalAnalytics.recordFinish(item, fileId, 0L, completed, skipped && !completed)
                scope.launch(Dispatchers.IO) {
                    streamPlatform.finishValidPlay(fileId, sessionId, listened, duration, completed, skipped && !completed)
                }
            }
        }
        startedAtRealtimeMs = 0L
        currentListenedMs = 0L
        statsPlayRegistered = false
        // Fecha a sessão do Stream de forma atômica para impedir que stop/onDestroy
        // finalize a mesma audição uma segunda vez no Analytics local.
        streamPlayCounted = false
        streamPlayClaimResolved = false
        streamLocalPlayCounted = false
        streamPlayQualified = false
        streamLocalCheckpointedMs = 0L
        streamPlaySessionStarted = false
        streamPlayClaimInFlight = false
        streamPlayThresholdInFlight = false
        streamPlayThresholdResolved = false
        streamPlayRequiredMs = Long.MAX_VALUE
        streamPlayListenedMs = 0L
        streamPlayLastTickMs = 0L
        streamPlayFileId = 0L
        streamPlaySessionId = ""
    }

    private fun updateSessionMetadata(item: PulsePlayerQueueItem, duration: Long) {
        val metadata = MediaMetadata.Builder()
            .putString(MediaMetadata.METADATA_KEY_TITLE, item.title)
            .putString(MediaMetadata.METADATA_KEY_ARTIST, item.artist)
            .putString(MediaMetadata.METADATA_KEY_ALBUM, item.album)
            .putString(MediaMetadata.METADATA_KEY_GENRE, item.genre)
            .putLong(MediaMetadata.METADATA_KEY_DURATION, duration)
        val art = if (!isCloudItem(item)) loadEmbeddedArtwork(item.uri) else null
        art?.let { bitmap ->
            metadata.putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, bitmap)
            metadata.putBitmap(MediaMetadata.METADATA_KEY_ART, bitmap)
        }
        mediaSession.setMetadata(metadata.build())
    }

    private fun loadEmbeddedArtwork(uri: String?): android.graphics.Bitmap? {
        if (uri.isNullOrBlank()) return null
        return runCatching {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(this, Uri.parse(uri))
                retriever.embeddedPicture?.let { BitmapFactory.decodeByteArray(it, 0, it.size) }
            } finally {
                runCatching { retriever.release() }
            }
        }.getOrNull()
    }

    private fun updateSessionState() {
        val s = _state.value
        val actions = PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS or PlaybackState.ACTION_SEEK_TO
        mediaSession.setPlaybackState(
            PlaybackState.Builder().setActions(actions)
                .setState(if (s.playing) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED, s.positionMs, if (s.playing) 1f else 0f)
                .build()
        )
        updateNotification()
    }

    private fun ensureForeground() {
        mediaSession.isActive = true
        startForeground(NOTIFICATION_ID, buildNotification())
    }

    private fun updateNotification() {
        if (_state.value.current != null) runCatching { (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIFICATION_ID, buildNotification()) }
    }

    private fun buildNotification(): Notification {
        val s = _state.value
        val item = s.current
        val launch = packageManager.getLaunchIntentForPackage(packageName)?.let {
            PendingIntent.getActivity(this, 0, it, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        }
        fun actionIntent(action: String, code: Int) = PendingIntent.getService(
            this,
            code,
            Intent(this, PulsePlayerService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = actionIntent(ACTION_STOP, 6)
        val artwork = if (isCloudItem(item)) null else loadEmbeddedArtwork(item?.uri)
        val builder = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(com.sonusstudios.streampulse.R.drawable.ic_sonus_notification)
            .setContentTitle(item?.title ?: "SONUS PLAYER")
            .setContentText(item?.artist?.ifBlank { "SONUS" } ?: "SONUS")
            .setLargeIcon(artwork)
            .setContentIntent(launch)
            .setOnlyAlertOnce(true)
            .setOngoing(s.playing)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setCategory(Notification.CATEGORY_TRANSPORT)
            .setStyle(
                Notification.MediaStyle()
                    .setMediaSession(mediaSession.sessionToken)
                    .setShowActionsInCompactView(0, 1, 2)
            )
            .addAction(android.R.drawable.ic_media_previous, "Anterior", actionIntent(ACTION_PREVIOUS, 1))
            .addAction(
                if (s.playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,
                if (s.playing) "Pausar" else "Reproduzir",
                actionIntent(ACTION_TOGGLE, 2)
            )
            .addAction(android.R.drawable.ic_media_next, "Próxima", actionIntent(ACTION_NEXT, 3))

        if (s.playing) {
            
        } else {
            // Pausado: a notificação deixa de ser persistente e oferece fechamento explícito.
            builder.setDeleteIntent(stopIntent)
            builder.addAction(android.R.drawable.ic_menu_close_clear_cancel, "Fechar", stopIntent)
        }
        return builder.build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "SONUS PLAYER", NotificationManager.IMPORTANCE_LOW).apply { description = "Controles de reprodução do SONUS PLAYER" })
        }
    }

    private fun releasePlayers() {
        crossfadeJob?.cancel(); crossfadeJob = null
        orbitJob?.cancel(); orbitJob = null
        onlineResolveJob?.cancel(); onlineResolveJob = null
        onlinePrefetchJob?.cancel(); onlinePrefetchJob = null
        onlineGeneration++
        onlinePlayer?.let { exo -> onlinePlayerListener?.let { listener -> runCatching { exo.removeListener(listener) } } }
        onlinePlayerListener = null
        runCatching { onlinePlayer?.stop() }
        runCatching { onlinePlayer?.release() }; onlinePlayer = null
        runCatching { player?.setNextMediaPlayer(null) }
        runCatching { player?.release() }; player = null
        runCatching { incomingPlayer?.release() }; incomingPlayer = null
        runCatching { gaplessPlayer?.release() }; gaplessPlayer = null
        gaplessNextIndex = null
        runCatching { onlineDataSource?.close() }; onlineDataSource = null
        runCatching { media3Spectrum.stop() }
        releaseEffects()
    }

    private fun releaseEffects() {
        spectrumHealthJob?.cancel(); spectrumHealthJob = null
        compatSpectrumAnalysisJob?.cancel(); compatSpectrumAnalysisJob = null
        compatSpectrumJob?.cancel(); compatSpectrumJob = null
        compatSpectrumFrames = emptyList()
        compatSpectrumUri = null
        compatSpectrumStartMs = 0L
        compatSpectrumEndMs = 0L
        compatSpectrumRetryAfterMs = 0L
        compatSpectrumFailures = 0
        nativeHealthyEvents = 0
        lastNativeSpectrumAt = 0L
        lastNativeSignature = Float.NaN
        runCatching { equalizer?.release() }; equalizer = null
        runCatching { bassBoost?.release() }; bassBoost = null
        runCatching { visualizer?.enabled = false; visualizer?.release() }; visualizer = null
        runCatching { loudness?.release() }; loudness = null
    }

    override fun onDestroy() {
        finishCurrentTrack(completed = false, skipped = false)
        if (noisyReceiverRegistered) runCatching { unregisterReceiver(noisyReceiver) }
        noisyReceiverRegistered = false
        sleepJob?.cancel()
        releasePlayers()
        runCatching { media3Spectrum.release() }
        runCatching { mediaSession.release() }
        scope.cancel()
        isRunning = false
        super.onDestroy()
    }

    private fun MediaPlayer?.isPlayingSafe(): Boolean = runCatching { this?.isPlaying == true }.getOrDefault(false)

    companion object {
        @Volatile var isRunning: Boolean = false
            private set
        @Volatile var lastSpectrumEngine: String = "PCM Media3"
            private set

        const val CHANNEL_ID = "pulse_player"
        const val NOTIFICATION_ID = 1915
        const val ACTION_KEEP_ALIVE = "com.sonusstudios.streampulse.player.KEEP_ALIVE"
        const val ACTION_TOGGLE = "com.sonusstudios.streampulse.player.TOGGLE"
        const val ACTION_PAUSE = "com.sonusstudios.streampulse.player.PAUSE"
        const val ACTION_NEXT = "com.sonusstudios.streampulse.player.NEXT"
        const val ACTION_PREVIOUS = "com.sonusstudios.streampulse.player.PREVIOUS"
        const val ACTION_PULSE_LIFT = "com.sonusstudios.streampulse.player.PULSE_LIFT"
        const val ACTION_PULSE_ORBIT = "com.sonusstudios.streampulse.player.PULSE_ORBIT"
        const val ACTION_EQ_BASS_BOOST_TOGGLE = "com.sonusstudios.streampulse.player.EQ_BASS_BOOST_TOGGLE"
        const val ACTION_STOP = "com.sonusstudios.streampulse.player.STOP"

    }
}
