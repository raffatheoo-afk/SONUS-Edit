package com.sonusstudios.streampulse.tools

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Color as AndroidColor
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Typeface
import android.media.ExifInterface
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonusstudios.streampulse.core.SonusStorage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Leitura/gravação de imagens compartilhada pelas ferramentas em lote (respeita a rotação EXIF). */
internal object SonusImageIo {
    fun displayName(context: Context, uri: Uri): String = runCatching {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    }.getOrNull().orEmpty().ifBlank { uri.lastPathSegment?.substringAfterLast('/') ?: "imagem" }

    fun isPng(context: Context, uri: Uri): Boolean =
        context.contentResolver.getType(uri)?.contains("png", true) == true || displayName(context, uri).endsWith(".png", true)

    /** Decodifica respeitando a rotação do EXIF; reduz só imagens gigantes (> [maxPixels]) para não estourar a memória. */
    fun decode(context: Context, uri: Uri, maxPixels: Long = 40_000_000L): Bitmap? = runCatching {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return@runCatching null
        var sample = 1
        while (bounds.outWidth.toLong() / sample * (bounds.outHeight.toLong() / sample) > maxPixels) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val raw = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return@runCatching null
        val orientation = context.contentResolver.openInputStream(uri)?.use {
            ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        } ?: ExifInterface.ORIENTATION_NORMAL
        val m = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(270f); m.postScale(-1f, 1f) }
            else -> return@runCatching raw
        }
        Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true).also { if (it !== raw) raw.recycle() }
    }.getOrNull()

    fun save(context: Context, bitmap: Bitmap, baseName: String, suffix: String, png: Boolean): Boolean = runCatching {
        val ext = if (png) "png" else "jpg"
        val name = "${baseName.substringBeforeLast('.').ifBlank { "imagem" }}_$suffix.$ext"
        val uri = SonusStorage.createImage(context, name, if (png) "image/png" else "image/jpeg", SonusStorage.Bucket.IMAGES) ?: return@runCatching false
        try {
            SonusStorage.openOutput(context, uri)?.use { out ->
                bitmap.compress(if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, 95, out)
            } ?: error("sem saída")
            SonusStorage.finish(context, uri)
            true
        } catch (t: Throwable) { SonusStorage.abort(context, uri); false }
    }.getOrDefault(false)
}

// ───────────────────────── Recorte em lote ─────────────────────────

private data class CropRatio(val label: String, val w: Int, val h: Int) { val value: Float get() = w.toFloat() / h.toFloat() }
private val cropRatios = listOf(
    CropRatio("1:1", 1, 1), CropRatio("4:5", 4, 5), CropRatio("9:16", 9, 16), CropRatio("16:9", 16, 9),
    CropRatio("3:4", 3, 4), CropRatio("4:3", 4, 3), CropRatio("2:3", 2, 3), CropRatio("3:2", 3, 2), CropRatio("21:9", 21, 9)
)

/** Retângulo de recorte (só corta: nunca expande nem estica). [pos] 0..1 desliza pelo lado que sobra. */
internal fun cropRect(width: Int, height: Int, ratio: Float, pos: Float): android.graphics.Rect {
    val current = width.toFloat() / height.toFloat()
    return if (current > ratio) {
        val w = (height * ratio).roundToInt().coerceIn(1, width)
        val x = ((width - w) * pos.coerceIn(0f, 1f)).roundToInt()
        android.graphics.Rect(x, 0, x + w, height)
    } else {
        val h = (width / ratio).roundToInt().coerceIn(1, height)
        val y = ((height - h) * pos.coerceIn(0f, 1f)).roundToInt()
        android.graphics.Rect(0, y, width, y + h)
    }
}

@Composable
internal fun ImageCropBatchTool(onBack: () -> Unit, onTrack: (String, Boolean?, Long?) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var uris by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var ratioIndex by remember { mutableIntStateOf(2) }
    var pos by remember { mutableFloatStateOf(0.5f) }
    var preview by remember { mutableStateOf<Bitmap?>(null) }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(0) }
    var message by remember { mutableStateOf<String?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { list ->
        if (list.isNotEmpty()) { uris = list; message = null }
    }
    LaunchedEffect(uris) {
        preview = uris.firstOrNull()?.let { u -> withContext(Dispatchers.IO) { SonusImageIo.decode(context, u, 3_000_000L) } }
    }
    if (busy) SonusExportProgressDialog(percent = progress, phase = "Recortando imagens…", title = "Recorte em lote")

    CreatorToolScaffold(onBack, "Recortar em lote", "Recorta várias imagens na proporção escolhida. Só corta: não estica e não expande.") {
        item {
            CreatorCard("1. Imagens", Icons.Default.AddPhotoAlternate) {
                OutlinedButton(onClick = { picker.launch(arrayOf("image/*")) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.AddPhotoAlternate, null); Spacer(Modifier.width(8.dp)); Text(if (uris.isEmpty()) "Selecionar imagens" else "Trocar seleção")
                }
                if (uris.isNotEmpty()) Text("${uris.size} imagem(ns) selecionada(s).", style = MaterialTheme.typography.bodySmall)
            }
        }
        item {
            CreatorCard("2. Proporção", Icons.Default.Crop) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(cropRatios.size) { i -> FilterChip(selected = ratioIndex == i, onClick = { ratioIndex = i }, label = { Text(cropRatios[i].label) }) }
                }
                Text("Posição do recorte", style = MaterialTheme.typography.labelMedium)
                Slider(value = pos, onValueChange = { pos = it }, valueRange = 0f..1f)
                Text("Começo ← → fim da imagem (vale para o lado que sobra de cada foto).", style = MaterialTheme.typography.labelSmall)
                val bmp = preview
                if (bmp != null) {
                    val r = cropRect(bmp.width, bmp.height, cropRatios[ratioIndex].value, pos)
                    val cropped = remember(bmp, r.left, r.top, r.right, r.bottom) { Bitmap.createBitmap(bmp, r.left, r.top, r.width(), r.height()) }
                    Text("Prévia da primeira imagem", style = MaterialTheme.typography.labelMedium)
                    Box(Modifier.fillMaxWidth().height(260.dp).clip(RoundedCornerShape(14.dp)).background(Color.Black), contentAlignment = Alignment.Center) {
                        Image(bitmap = cropped.asImageBitmap(), contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxWidth().height(260.dp))
                    }
                }
            }
        }
        item {
            Button(
                enabled = uris.isNotEmpty() && !busy, modifier = Modifier.fillMaxWidth().height(52.dp),
                onClick = {
                    val started = System.currentTimeMillis()
                    val ratio = cropRatios[ratioIndex]
                    scope.launch {
                        busy = true; progress = 1; message = null
                        var ok = 0; var failed = 0
                        withContext(Dispatchers.IO) {
                            uris.forEachIndexed { index, uri ->
                                val bmp = SonusImageIo.decode(context, uri)
                                if (bmp == null) failed++ else {
                                    val saved = runCatching {
                                        val r = cropRect(bmp.width, bmp.height, ratio.value, pos)
                                        val out = Bitmap.createBitmap(bmp, r.left, r.top, r.width(), r.height())
                                        SonusImageIo.save(context, out, SonusImageIo.displayName(context, uri), "crop_${ratio.w}x${ratio.h}", SonusImageIo.isPng(context, uri))
                                    }.getOrDefault(false)
                                    if (saved) ok++ else failed++
                                    bmp.recycle()
                                }
                                progress = ((index + 1) * 100f / uris.size).roundToInt()
                            }
                        }
                        busy = false
                        message = if (failed == 0) "✓ $ok imagem(ns) recortada(s) em ${ratio.label} e salva(s) na pasta SONUS." else "$ok concluída(s) • $failed falha(s)."
                        onTrack("Recortar em lote ${ratio.label}: $ok/${uris.size}", failed == 0, System.currentTimeMillis() - started)
                    }
                }
            ) { Icon(Icons.Default.Crop, null); Spacer(Modifier.width(8.dp)); Text("Recortar ${uris.size} imagem(ns)") }
        }
        messageItem(message)
    }
}

// ───────────────────────── Marca d'água em lote ─────────────────────────

private enum class WmPosition(val label: String) { TL("↖ Em cima à esquerda"), TR("↗ Em cima à direita"), CENTER("● Meio"), BL("↙ Embaixo à esquerda"), BR("↘ Embaixo à direita") }
private enum class WmSize(val label: String, val fraction: Float) { TINY("Minúsculo", 0.06f), SMALL("Pequeno", 0.12f), MEDIUM("Médio", 0.22f), LARGE("Grande", 0.36f) }
private val wmColors = listOf("Branco" to AndroidColor.WHITE, "Preto" to AndroidColor.BLACK, "Dourado" to AndroidColor.rgb(255, 196, 61), "Ciano" to AndroidColor.rgb(70, 220, 255))

/** Desenha a marca sobre uma CÓPIA do bitmap (mesma função para o preview e para o lote: o que você vê é o que sai). */
private fun drawWatermark(
    base: Bitmap, text: String, logo: Bitmap?, useLogo: Boolean, size: WmSize, opacity: Float, position: WmPosition, color: Int
): Bitmap {
    val out = base.copy(Bitmap.Config.ARGB_8888, true)
    val canvas = AndroidCanvas(out)
    val margin = out.width * 0.035f
    val alpha = (opacity.coerceIn(0.05f, 1f) * 255).roundToInt()
    val markW: Float; val markH: Float
    val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    var textBaseline = 0f
    if (useLogo && logo != null) {
        markW = out.width * size.fraction
        markH = markW * logo.height / logo.width.toFloat()
    } else {
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = out.width * size.fraction * 0.30f
        markW = paint.measureText(text.ifBlank { " " })
        val fm = paint.fontMetrics
        markH = fm.descent - fm.ascent
        textBaseline = -fm.ascent
    }
    val x = when (position) { WmPosition.TL, WmPosition.BL -> margin; WmPosition.TR, WmPosition.BR -> out.width - margin - markW; WmPosition.CENTER -> (out.width - markW) / 2f }
    val y = when (position) { WmPosition.TL, WmPosition.TR -> margin; WmPosition.BL, WmPosition.BR -> out.height - margin - markH; WmPosition.CENTER -> (out.height - markH) / 2f }
    if (useLogo && logo != null) {
        paint.alpha = alpha
        canvas.drawBitmap(logo, null, android.graphics.RectF(x, y, x + markW, y + markH), paint)
    } else {
        // Sombra suave para a marca continuar legível em fundos claros e escuros.
        paint.color = color; paint.alpha = alpha
        paint.setShadowLayer(paint.textSize * 0.08f, 0f, paint.textSize * 0.04f, AndroidColor.argb((alpha * 0.6f).roundToInt(), 0, 0, 0))
        canvas.drawText(text, x, y + textBaseline, paint)
    }
    return out
}

@Composable
internal fun WatermarkBatchTool(onBack: () -> Unit, onTrack: (String, Boolean?, Long?) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var uris by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var useLogo by remember { mutableStateOf(false) }
    var text by remember { mutableStateOf("") }
    var colorIndex by remember { mutableIntStateOf(0) }
    var logoUri by remember { mutableStateOf<Uri?>(null) }
    var logo by remember { mutableStateOf<Bitmap?>(null) }
    var size by remember { mutableStateOf(WmSize.SMALL) }
    var position by remember { mutableStateOf(WmPosition.BR) }
    var opacity by remember { mutableFloatStateOf(0.7f) }
    var base by remember { mutableStateOf<Bitmap?>(null) }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(0) }
    var message by remember { mutableStateOf<String?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { list -> if (list.isNotEmpty()) { uris = list; message = null } }
    val logoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) { logoUri = u; useLogo = true } }
    LaunchedEffect(uris) { base = uris.firstOrNull()?.let { u -> withContext(Dispatchers.IO) { SonusImageIo.decode(context, u, 1_600_000L) } } }
    LaunchedEffect(logoUri) { logo = logoUri?.let { u -> withContext(Dispatchers.IO) { SonusImageIo.decode(context, u, 4_000_000L) } } }
    if (busy) SonusExportProgressDialog(percent = progress, phase = "Aplicando marca d'água…", title = "Marca d'água em lote")

    val canRun = uris.isNotEmpty() && !busy && (if (useLogo) logo != null else text.isNotBlank())
    CreatorToolScaffold(onBack, "Marca d'água em lote", "Aplique texto ou uma imagem PNG em várias fotos de uma vez, com preview.") {
        item {
            CreatorCard("1. Imagens", Icons.Default.AddPhotoAlternate) {
                OutlinedButton(onClick = { picker.launch(arrayOf("image/*")) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.AddPhotoAlternate, null); Spacer(Modifier.width(8.dp)); Text(if (uris.isEmpty()) "Selecionar imagens" else "Trocar seleção")
                }
                if (uris.isNotEmpty()) Text("${uris.size} imagem(ns) selecionada(s).", style = MaterialTheme.typography.bodySmall)
            }
        }
        item {
            CreatorCard("2. Marca", Icons.Default.WaterDrop) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = !useLogo, onClick = { useLogo = false }, label = { Text("Texto") })
                    FilterChip(selected = useLogo, onClick = { if (logoUri == null) logoPicker.launch(arrayOf("image/*")) else useLogo = true }, label = { Text("Imagem") })
                }
                if (!useLogo) {
                    OutlinedTextField(value = text, onValueChange = { text = it.take(60) }, singleLine = true, modifier = Modifier.fillMaxWidth(), label = { Text("Texto da marca (ex.: @meucanal)") })
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(wmColors.size) { i -> FilterChip(selected = colorIndex == i, onClick = { colorIndex = i }, label = { Text(wmColors[i].first) }) }
                    }
                } else {
                    OutlinedButton(onClick = { logoPicker.launch(arrayOf("image/*")) }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.AddPhotoAlternate, null); Spacer(Modifier.width(8.dp)); Text(if (logoUri == null) "Escolher a imagem da marca" else "Trocar imagem da marca")
                    }
                    Text("⚠️ PNG com fundo transparente dá o melhor resultado.", style = MaterialTheme.typography.labelSmall, fontSize = 10.sp)
                }
            }
        }
        item {
            CreatorCard("3. Tamanho, opacidade e posição", Icons.Default.WaterDrop) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(WmSize.entries.toList()) { s -> FilterChip(selected = size == s, onClick = { size = s }, label = { Text(s.label) }) }
                }
                Text("Opacidade: ${(opacity * 100).roundToInt()}%", style = MaterialTheme.typography.labelMedium)
                Slider(value = opacity, onValueChange = { opacity = it }, valueRange = 0.1f..1f)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(WmPosition.entries.toList()) { p -> FilterChip(selected = position == p, onClick = { position = p }, label = { Text(p.label) }) }
                }
            }
        }
        item {
            val b = base
            if (b != null) {
                val shown = remember(b, text, logo, useLogo, size, opacity, position, colorIndex) { drawWatermark(b, text, logo, useLogo, size, opacity, position, wmColors[colorIndex].second) }
                CreatorCard("Prévia", Icons.Default.WaterDrop) {
                    Box(Modifier.fillMaxWidth().height(280.dp).clip(RoundedCornerShape(14.dp)).background(Color.Black), contentAlignment = Alignment.Center) {
                        Image(bitmap = shown.asImageBitmap(), contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxWidth().height(280.dp))
                    }
                }
            }
        }
        item {
            Button(
                enabled = canRun, modifier = Modifier.fillMaxWidth().height(52.dp),
                onClick = {
                    val started = System.currentTimeMillis()
                    val markText = text; val markLogo = logo; val logoMode = useLogo
                    scope.launch {
                        busy = true; progress = 1; message = null
                        var ok = 0; var failed = 0
                        withContext(Dispatchers.IO) {
                            uris.forEachIndexed { index, uri ->
                                val bmp = SonusImageIo.decode(context, uri)
                                if (bmp == null) failed++ else {
                                    val saved = runCatching {
                                        val marked = drawWatermark(bmp, markText, markLogo, logoMode, size, opacity, position, wmColors[colorIndex].second)
                                        SonusImageIo.save(context, marked, SonusImageIo.displayName(context, uri), "marca", SonusImageIo.isPng(context, uri))
                                    }.getOrDefault(false)
                                    if (saved) ok++ else failed++
                                    bmp.recycle()
                                }
                                progress = ((index + 1) * 100f / uris.size).roundToInt()
                            }
                        }
                        busy = false
                        message = if (failed == 0) "✓ $ok imagem(ns) com marca d'água salva(s) na pasta SONUS." else "$ok concluída(s) • $failed falha(s)."
                        onTrack("Marca d'água em lote: $ok/${uris.size}", failed == 0, System.currentTimeMillis() - started)
                    }
                }
            ) { Icon(Icons.Default.WaterDrop, null); Spacer(Modifier.width(8.dp)); Text("Aplicar em ${uris.size} imagem(ns)") }
        }
        messageItem(message)
    }
}
