package com.sonusstudios.streampulse.ads

import android.app.Activity
import android.content.Context
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import com.sonusstudios.streampulse.BuildConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/** Resumo local para o dashboard OWNER. Não contém IDs nem dados pessoais. */
data class SonusAdMetrics(
    val rewardedRequests: Long = 0,
    val rewardedImpressions: Long = 0,
    val rewardsGranted: Long = 0,
    val failures: Long = 0,
    val lastError: String? = null,
    val lastErrorCode: Int? = null,
    val lastErrorDomain: String? = null,
    val lastErrorMessage: String? = null,
    val lastResponseInfo: String? = null
)

/**
 * Central AdMob do SONUS 1.0.0 / code103.
 *
 * - UMP é consultado antes da inicialização dos anúncios.
 * - Rewarded libera exatamente um uso no FREE somente após callback oficial.
 * - code103: publicidade fica fora do Player/Stream; somente Rewarded é carregado para ferramentas PRO.
 * - builds comuns continuam usando IDs oficiais de teste; produção exige SONUS_REAL_ADS=true.
 */
class StreamPulseAdManager(private val context: Context) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val _sdkReady = MutableStateFlow(false)
    val ready: StateFlow<Boolean> = _sdkReady.asStateFlow()

    private val _rewardedReady = MutableStateFlow(false)
    val rewardedReady: StateFlow<Boolean> = _rewardedReady.asStateFlow()

    private val _rewardedLoading = MutableStateFlow(false)
    val rewardedLoading: StateFlow<Boolean> = _rewardedLoading.asStateFlow()

    private val _metrics = MutableStateFlow(SonusAdMetrics())
    val metrics: StateFlow<SonusAdMetrics> = _metrics.asStateFlow()

    private val _canRequestAds = MutableStateFlow(false)
    val canRequestAds: StateFlow<Boolean> = _canRequestAds.asStateFlow()

    private val _umpStatus = MutableStateFlow("NÃO CONSULTADO")
    val umpStatus: StateFlow<String> = _umpStatus.asStateFlow()

    val productionMode: Boolean get() = BuildConfig.REAL_ADS_ENABLED
    val environmentLabel: String get() = if (productionMode) "PRODUÇÃO" else "TESTE"

    private var rewardedAd: RewardedAd? = null
    private var consentStarted = false
    private var sdkInitializing = false
    private var rewardedRetryJob: Job? = null
    private var rewardedRetryDelayMs = 2_500L
    private var pendingRewarded: PendingRewarded? = null
    private var pendingRewardedTimeout: Job? = null

    private data class PendingRewarded(
        val activity: Activity,
        val onReward: () -> Unit,
        val onUnavailable: (String) -> Unit
    )

    private val officialRewardedTestUnitId = "ca-app-pub-3940256099942544/5224354917"

    private val rewardedUnitId: String
        get() = if (productionMode) {
            "ca-app-pub-5946939083187128/6300361567"
        } else {
            officialRewardedTestUnitId
        }


    fun initialize(activity: Activity) {
        if (_sdkReady.value) {
            loadRewarded()
            return
        }
        val consentInfo = UserMessagingPlatform.getConsentInformation(context)
        _canRequestAds.value = consentInfo.canRequestAds()
        _umpStatus.value = runCatching { "${consentInfo.consentStatus} • privacidade ${consentInfo.privacyOptionsRequirementStatus}" }.getOrDefault("CONSULTANDO")

        // Usuário recorrente com consentimento válido: não espere nova consulta de rede.
        if (consentInfo.canRequestAds()) initializeAds()
        if (consentStarted) return
        consentStarted = true

        val params = ConsentRequestParameters.Builder().build()
        consentInfo.requestConsentInfoUpdate(
            activity,
            params,
            {
                _canRequestAds.value = consentInfo.canRequestAds()
                _umpStatus.value = runCatching { "${consentInfo.consentStatus} • privacidade ${consentInfo.privacyOptionsRequirementStatus}" }.getOrDefault("ATUALIZADA")
                UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) {
                    _canRequestAds.value = consentInfo.canRequestAds()
                    _umpStatus.value = runCatching { "${consentInfo.consentStatus} • privacidade ${consentInfo.privacyOptionsRequirementStatus}" }.getOrDefault("FORMULÁRIO CONCLUÍDO")
                    if (consentInfo.canRequestAds()) initializeAds()
                }
                if (consentInfo.canRequestAds()) initializeAds()
            },
            { error ->
                _canRequestAds.value = consentInfo.canRequestAds()
                _umpStatus.value = "ERRO UMP"
                _metrics.value = _metrics.value.copy(lastError = "UMP: ${error.message}")
                // Falha da UMP nunca bloqueia a UI; anúncios só são solicitados se a própria UMP autorizar.
                if (consentInfo.canRequestAds()) initializeAds()
            }
        )
    }

    private fun initializeAds() {
        if (_sdkReady.value || sdkInitializing) return
        sdkInitializing = true
        MobileAds.initialize(context) {
            sdkInitializing = false
            _sdkReady.value = true
            loadRewarded()
        }
    }

    /** Pré-carrega exatamente um Rewarded. Chamadas duplicadas são ignoradas. */
    fun loadRewarded(force: Boolean = false) {
        if (!_sdkReady.value) return
        if (!force && (rewardedAd != null || _rewardedLoading.value)) return
        rewardedRetryJob?.cancel(); rewardedRetryJob = null
        _rewardedLoading.value = true
        _rewardedReady.value = false
        _metrics.value = _metrics.value.copy(rewardedRequests = _metrics.value.rewardedRequests + 1)

        RewardedAd.load(
            context,
            rewardedUnitId,
            AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    _rewardedLoading.value = false
                    rewardedAd = ad
                    _rewardedReady.value = true
                    rewardedRetryDelayMs = 2_500L
                    val pending = pendingRewarded
                    if (pending != null) {
                        pendingRewarded = null
                        pendingRewardedTimeout?.cancel(); pendingRewardedTimeout = null
                        showLoadedRewarded(pending.activity, pending.onReward, pending.onUnavailable)
                    }
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    _rewardedLoading.value = false
                    rewardedAd = null
                    _rewardedReady.value = false
                    recordLoadFailure("Rewarded load", error)
                    pendingRewarded?.let { pending ->
                        pendingRewarded = null
                        pendingRewardedTimeout?.cancel(); pendingRewardedTimeout = null
                        pending.onUnavailable("Anúncio indisponível no momento. Tente novamente.")
                    }
                    scheduleRewardedRetry()
                }
            }
        )
    }

    private fun scheduleRewardedRetry() {
        if (!_sdkReady.value || rewardedRetryJob?.isActive == true) return
        val wait = rewardedRetryDelayMs
        rewardedRetryDelayMs = (rewardedRetryDelayMs * 2L).coerceAtMost(30_000L)
        rewardedRetryJob = scope.launch { delay(wait); rewardedRetryJob = null; loadRewarded() }
    }

    fun showRewarded(
        activity: Activity,
        ownerOrAdFree: Boolean,
        forceTestUnit: Boolean = false,
        onReward: () -> Unit,
        onUnavailable: (String) -> Unit = {}
    ) {
        if (forceTestUnit) {
            showOfficialTestRewarded(activity, onReward, onUnavailable)
            return
        }
        if (ownerOrAdFree) {
            onUnavailable("Sua conta não precisa assistir anúncios.")
            return
        }
        if (rewardedAd != null) {
            showLoadedRewarded(activity, onReward, onUnavailable)
            return
        }

        // code103: um toque vira uma solicitação pendente. Quando o SDK terminar o
        // carregamento, o anúncio abre sozinho; não é necessário tocar novamente.
        pendingRewarded = PendingRewarded(activity, onReward, onUnavailable)
        loadRewarded()
        pendingRewardedTimeout?.cancel()
        pendingRewardedTimeout = scope.launch {
            delay(12_000L)
            val pending = pendingRewarded ?: return@launch
            pendingRewarded = null
            pending.onUnavailable("Anúncio indisponível no momento. Tente novamente.")
        }
    }

    /** OWNER e painel de diagnóstico usam sempre a unidade oficial de teste do Google. */
    private fun showOfficialTestRewarded(
        activity: Activity,
        onReward: () -> Unit,
        onUnavailable: (String) -> Unit
    ) {
        if (!_sdkReady.value) {
            onUnavailable("Anúncio de teste ainda não está pronto. Tente novamente em instantes.")
            return
        }
        _metrics.value = _metrics.value.copy(rewardedRequests = _metrics.value.rewardedRequests + 1)
        RewardedAd.load(
            context,
            officialRewardedTestUnitId,
            AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    var earned = false
                    ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                        override fun onAdImpression() {
                            _metrics.value = _metrics.value.copy(rewardedImpressions = _metrics.value.rewardedImpressions + 1)
                        }
                        override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                            if (!earned) onUnavailable("Anúncio de teste indisponível no momento.")
                            recordFailure("Rewarded teste show ${adError.code}: ${adError.message}", adError.code, adError.domain, adError.message, null)
                        }
                    }
                    ad.show(activity) {
                        if (!earned) {
                            earned = true
                            _metrics.value = _metrics.value.copy(rewardsGranted = _metrics.value.rewardsGranted + 1)
                            onReward()
                        }
                    }
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    recordLoadFailure("Rewarded teste load", error)
                    onUnavailable("Anúncio de teste indisponível no momento. Verifique internet/consentimento.")
                }
            }
        )
    }

    private fun showLoadedRewarded(
        activity: Activity,
        onReward: () -> Unit,
        onUnavailable: (String) -> Unit
    ) {
        val ad = rewardedAd ?: run {
            onUnavailable("Anúncio indisponível no momento. Tente novamente.")
            return
        }
        pendingRewarded = null
        pendingRewardedTimeout?.cancel(); pendingRewardedTimeout = null
        rewardedAd = null
        _rewardedReady.value = false
        var earned = false
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdImpression() {
                _metrics.value = _metrics.value.copy(rewardedImpressions = _metrics.value.rewardedImpressions + 1)
            }

            override fun onAdDismissedFullScreenContent() {
                scope.launch { delay(250); loadRewarded() }
            }

            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                if (!earned) onUnavailable("Anúncio indisponível no momento. Tente novamente.")
                recordFailure("Rewarded show ${adError.code}: ${adError.message}", adError.code, adError.domain, adError.message, null)
                scope.launch { delay(250); loadRewarded(force = true) }
            }
        }
        ad.show(activity) {
            if (!earned) {
                earned = true
                _metrics.value = _metrics.value.copy(rewardsGranted = _metrics.value.rewardsGranted + 1)
                onReward()
            }
        }
    }

    fun showPrivacyOptions(activity: Activity, onDone: (String?) -> Unit = {}) {
        UserMessagingPlatform.showPrivacyOptionsForm(activity) { error ->
            val info = UserMessagingPlatform.getConsentInformation(context)
            _canRequestAds.value = info.canRequestAds()
            _umpStatus.value = runCatching { "${info.consentStatus} • privacidade ${info.privacyOptionsRequirementStatus}" }.getOrDefault(if (error == null) "ATUALIZADA" else "ERRO UMP")
            onDone(error?.message)
            // Mudanças de consentimento podem permitir anúncios imediatamente.
            initialize(activity)
        }
    }

    fun refreshAds() {
        if (_sdkReady.value) loadRewarded(force = true)
    }

    private fun recordLoadFailure(prefix: String, error: LoadAdError) {
        recordFailure(
            message = "$prefix ${error.code}: ${error.message}",
            code = error.code,
            domain = error.domain,
            detail = error.message,
            responseInfo = runCatching { error.responseInfo?.toString() }.getOrNull()
        )
    }

    private fun recordFailure(
        message: String,
        code: Int? = null,
        domain: String? = null,
        detail: String? = null,
        responseInfo: String? = null
    ) {
        _metrics.value = _metrics.value.copy(
            failures = _metrics.value.failures + 1,
            lastError = message.take(220),
            lastErrorCode = code,
            lastErrorDomain = domain?.take(120),
            lastErrorMessage = detail?.take(220),
            lastResponseInfo = responseInfo?.take(700)
        )
    }
}
