package com.sonusstudios.streampulse.cloud

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.TrafficStats
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.sonusstudios.streampulse.auth.AuthManager
import com.sonusstudios.streampulse.auth.AuthUser
import com.sonusstudios.streampulse.core.AppState
import com.sonusstudios.streampulse.core.MembershipTier
import com.sonusstudios.streampulse.core.commercialTier
import com.sonusstudios.streampulse.data.AppRepository
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun CloudBackupSettings(
    state: AppState,
    authUser: AuthUser,
    membershipTier: MembershipTier,
    isOwner: Boolean,
    onStateRestored: (AppState) -> Unit,
    embedded: Boolean = false
) {
    val cloud = remember { CloudAccountManager() }
    val scope = rememberCoroutineScope()
    var lastBackupAt by remember { mutableStateOf<Long?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val onlineAllowed = isOwner || commercialTier(membershipTier).ordinal >= MembershipTier.PRATA.ordinal

    LaunchedEffect(authUser.uid) {
        val remote = withContext(Dispatchers.IO) { cloud.downloadBackup(authUser.uid).getOrNull() }
        lastBackupAt = remote?.second
    }

    val controls: @Composable ColumnScope.() -> Unit = {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(if (onlineAllowed) Icons.Default.CloudDone else Icons.Default.Lock, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(9.dp))
            Column(Modifier.weight(1f)) {
                Text("Backup online", fontWeight = FontWeight.Bold)
                Text(
                    if (!onlineAllowed) "Disponível no Ouro ou Diamante"
                    else lastBackupAt?.let { "Último backup: ${formatDateTime(it)}" } ?: "Nenhum backup online encontrado",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            if (!onlineAllowed) {
                Surface(shape = RoundedCornerShape(999.dp), color = MaterialTheme.colorScheme.primary.copy(alpha = .12f)) {
                    Text("OURO+", modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Black)
                }
            }
        }
        Button(
            onClick = {
                scope.launch {
                    busy = true; message = "Enviando backup..."
                    val result = withContext(Dispatchers.IO) { cloud.uploadBackup(authUser.uid, state) }
                    if (result.isSuccess) { lastBackupAt = result.getOrNull(); message = "✓ Backup online atualizado" }
                    else message = "Falha no backup online."
                    busy = false
                }
            },
            enabled = onlineAllowed && !busy,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Default.CloudUpload, null); Spacer(Modifier.width(7.dp)); Text("Fazer backup online")
        }
        OutlinedButton(
            onClick = {
                scope.launch {
                    busy = true; message = "Restaurando backup..."
                    val result = withContext(Dispatchers.IO) { cloud.downloadBackup(authUser.uid) }
                    val pair = result.getOrNull()
                    if (pair != null) {
                        val restored = mergeAuthority(state, pair.first)
                        onStateRestored(restored)
                        lastBackupAt = pair.second
                        message = "✓ Seus dados foram restaurados"
                    } else message = "Nenhum backup online disponível."
                    busy = false
                }
            },
            enabled = onlineAllowed && !busy,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Default.CloudDownload, null); Spacer(Modifier.width(7.dp)); Text("Restaurar backup online")
        }
        Text(
            "O ZIP local continua disponível no Free. O backup online sincroniza os dados da conta sem enviar áudios e imagens grandes automaticamente.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = .56f)
        )
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        message?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary) }
    }

    if (embedded) {
        Column(Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = controls)
    } else {
        Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.6f)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = controls)
        }
    }
}

@Composable
fun CloudCouponSettings(
    state: AppState,
    authUser: AuthUser,
    repository: AppRepository
) {
    val cloud = remember { CloudAccountManager() }
    val scope = rememberCoroutineScope()
    var coupon by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    Surface(
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.62f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha=.16f))
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.primary.copy(alpha=.12f)) {
                    Icon(Icons.Default.ConfirmationNumber, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(8.dp).size(20.dp))
                }
                Spacer(Modifier.width(9.dp))
                Column {
                    Text("Código promocional", fontWeight = FontWeight.ExtraBold)
                    Text("Resgate benefícios vinculados à sua conta SONUS", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha=.58f))
                }
            }
            OutlinedTextField(coupon, { coupon = it.uppercase().take(32) }, label={Text("Digite seu código")}, singleLine=true, modifier=Modifier.fillMaxWidth())
            Button(onClick = {
                scope.launch {
                    busy = true; message = "Validando código..."
                    val result = withContext(Dispatchers.IO) { cloud.redeemCoupon(authUser.uid, coupon) }
                    if (result.isSuccess) {
                        val redemption = result.getOrThrow()
                        applyCouponBenefit(repository, authUser.uid, state, redemption)
                        coupon = ""
                        message = "✓ ${redemption.message}"
                    } else {
                        val raw = result.exceptionOrNull()?.message.orEmpty()
                        message = when {
                            "Este código já foi resgatado" in raw -> "Este código já foi resgatado nesta conta."
                            "temporariamente pausados" in raw -> "Os códigos promocionais estão temporariamente pausados."
                            else -> "Código inválido, expirado ou indisponível."
                        }
                    }
                    busy = false
                }
            }, enabled = coupon.isNotBlank() && !busy, modifier=Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Redeem, null); Spacer(Modifier.width(7.dp)); Text("Resgatar código")
            }
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            message?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary) }
        }
    }
}

@Composable
fun AccountSecuritySettings(
    authUser: AuthUser,
    repository: AppRepository,
    authManager: AuthManager,
    onAfterAccountDeleted: () -> Unit
) {
    val context = LocalContext.current
    val cloud = remember { CloudAccountManager() }
    val scope = rememberCoroutineScope()
    var message by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var showResetConfirm by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    if (showResetConfirm) {
        ConfirmWordDialog(
            title = "Apagar todos os dados?",
            text = "Artistas, histórico, configurações locais e o backup online serão apagados. Sua conta continuará existindo.",
            requiredWord = "APAGAR",
            destructiveLabel = "Apagar dados",
            onDismiss = { showResetConfirm = false },
            onConfirm = {
                showResetConfirm = false
                scope.launch {
                    busy = true
                    val cloudDelete = withContext(Dispatchers.IO) { runCatching { cloud.deleteBackup(authUser.uid) } }
                    if (cloudDelete.isFailure) {
                        message = "Não foi possível apagar o backup online. Tente novamente com conexão."
                        busy = false
                        return@launch
                    }
                    repository.resetAllPreservingAuthority()
                    message = "Dados e configurações apagados. Benefícios válidos da conta foram preservados."
                    busy = false
                }
            }
        )
    }

    if (showDeleteConfirm) {
        DeleteAccountDialog(
            usesPassword = authManager.currentAccountUsesPassword(),
            onDismiss = { showDeleteConfirm = false },
            onConfirm = { password ->
                showDeleteConfirm = false
                scope.launch {
                    busy = true
                    message = "Confirmando sua identidade..."
                    val reauth = authManager.reauthenticate(context, password)
                    if (reauth.isFailure) {
                        message = reauth.exceptionOrNull()?.message ?: "Não foi possível confirmar sua identidade."
                        busy = false
                        return@launch
                    }
                    message = "Excluindo seus dados..."
                    val cloudDelete = withContext(Dispatchers.IO) { cloud.deleteAllUserCloudData(authUser.uid) }
                    if (cloudDelete.isFailure) {
                        message = "Não foi possível remover os dados online. Tente novamente."
                        busy = false
                        return@launch
                    }
                    repository.resetAll()
                    val deletion = authManager.deleteAccountAfterReauth(context)
                    if (deletion.isSuccess) {
                        message = null
                        onAfterAccountDeleted()
                    } else {
                        message = deletion.exceptionOrNull()?.message ?: "Falha ao excluir a conta."
                    }
                    busy = false
                }
            }
        )
    }

    Surface(shape=RoundedCornerShape(20.dp), color=MaterialTheme.colorScheme.errorContainer.copy(alpha=.18f), border=BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha=.24f))) {
        Column(Modifier.padding(14.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Security, null, tint = MaterialTheme.colorScheme.error)
                Spacer(Modifier.width(8.dp))
                Text("Zona de segurança da conta", fontWeight=FontWeight.ExtraBold, color=MaterialTheme.colorScheme.error)
            }
            OutlinedButton(onClick={showResetConfirm=true}, enabled=!busy, modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.DeleteSweep,null); Spacer(Modifier.width(7.dp)); Text("Apagar todos os dados") }
            Button(onClick={showDeleteConfirm=true}, enabled=!busy, modifier=Modifier.fillMaxWidth(), colors=ButtonDefaults.buttonColors(containerColor=MaterialTheme.colorScheme.error)) { Icon(Icons.Default.PersonRemove,null); Spacer(Modifier.width(7.dp)); Text("Excluir minha conta") }
            Text("Se houver assinatura ativa por uma loja ou serviço de cobrança, excluir a conta SONUS não cancela automaticamente essa assinatura. Premium promocional e dados da conta são removidos.", style=MaterialTheme.typography.bodySmall)
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            message?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error) }
        }
    }
}

@Composable
private fun CloudDataUsageChip(state: AppState) {
    val context = LocalContext.current
    val uid = android.os.Process.myUid()
    val startRx = remember { TrafficStats.getUidRxBytes(uid).coerceAtLeast(0L) }
    val startTx = remember { TrafficStats.getUidTxBytes(uid).coerceAtLeast(0L) }
    var rx by remember { mutableLongStateOf(startRx) }
    var tx by remember { mutableLongStateOf(startTx) }
    var speed by remember { mutableLongStateOf(0L) }
    var cellular by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        var lastRx=startRx; var lastTx=startTx
        while (true) {
            val nr=TrafficStats.getUidRxBytes(uid).coerceAtLeast(startRx); val nt=TrafficStats.getUidTxBytes(uid).coerceAtLeast(startTx)
            speed=((nr-lastRx)+(nt-lastTx)).coerceAtLeast(0L)
            rx=nr; tx=nt; lastRx=nr; lastTx=nt
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            val caps = cm?.activeNetwork?.let(cm::getNetworkCapabilities)
            cellular = caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true
            delay(1500)
        }
    }
    val bytes = ((rx-startRx)+(tx-startTx)).coerceAtLeast(0L)
    val mb = bytes / (1024.0*1024.0)
    val warn = cellular && state.preferences.warnOnMobileData && mb >= state.preferences.mobileDataWarningMb
    Surface(shape=RoundedCornerShape(50),color=(if(warn) Color(0xFFFF9800) else MaterialTheme.colorScheme.primary).copy(alpha=.12f)) {
        Text(
            if(warn) "⚠ ≈${String.format(java.util.Locale.US,"%.1f MB",mb)} • ${cloudRate(speed)}" else "📶 ≈${String.format(java.util.Locale.US,"%.1f MB",mb)} • ${cloudRate(speed)}",
            modifier=Modifier.padding(horizontal=8.dp,vertical=5.dp),
            style=MaterialTheme.typography.labelSmall,
            fontWeight=FontWeight.Bold
        )
    }
}

private fun cloudRate(bytes:Long):String = if(bytes>=1024L*1024L) String.format(java.util.Locale.US,"%.1f MB/s",bytes/(1024.0*1024.0)) else String.format(java.util.Locale.US,"%.0f KB/s",bytes/1024.0)

private suspend fun applyCouponBenefit(repository: AppRepository, uid: String, state: AppState, result: CouponRedemptionResult) {
    val c = result.coupon
    val now = result.redeemedAtEpochMillis
    when(c.type) {
        CouponType.COINS -> repository.addPulseBonusCoins(uid, c.amount)
        CouponType.PREMIUM -> {
            val currentUntil = state.preferences.premiumExpiresAtEpochMillis ?: 0L
            val base = maxOf(now, currentUntil)
            repository.applyPromotion(tierName = c.tierName, premiumUntil = base + c.durationHours * 3_600_000L)
        }
        CouponType.REMOVE_ADS -> {
            val current = state.preferences.adFreeUntilEpochMillis ?: 0L
            repository.applyPromotion(adFreeUntil = maxOf(now, current) + c.durationHours * 3_600_000L)
        }
        CouponType.AD_REWARD_2X -> {
            val current = state.preferences.adRewardMultiplierUntilEpochMillis ?: 0L
            repository.applyPromotion(adMultiplier = 2, adMultiplierUntil = maxOf(now, current) + c.durationHours * 3_600_000L)
        }
        CouponType.DISCOUNT -> repository.applyPromotion(
            discountPercent = c.discountPercent,
            discountTierName = c.tierName,
            discountUntil = now + maxOf(24, c.durationHours) * 3_600_000L
        )
    }
}

private fun mergeAuthority(current: AppState, restored: AppState): AppState {
    val cp = current.preferences
    val rp = restored.preferences
    return restored.copy(preferences = rp.copy(
        promotionalTierName = cp.promotionalTierName,
        premiumExpiresAtEpochMillis = cp.premiumExpiresAtEpochMillis,
        adFreeUntilEpochMillis = cp.adFreeUntilEpochMillis,
        adRewardMultiplier = cp.adRewardMultiplier,
        adRewardMultiplierUntilEpochMillis = cp.adRewardMultiplierUntilEpochMillis,
        discountPercent = cp.discountPercent,
        discountTierName = cp.discountTierName,
        discountUntilEpochMillis = cp.discountUntilEpochMillis,
        pulseMonthlyCoins = cp.pulseMonthlyCoins,
        pulseBonusCoins = cp.pulseBonusCoins,
        pulseCoinsPeriod = cp.pulseCoinsPeriod,
        pulseCoinsOwnerUid = cp.pulseCoinsOwnerUid,
        pulseUsageTierName = cp.pulseUsageTierName
    ))
}

@Composable
private fun ConfirmWordDialog(title:String,text:String,requiredWord:String,destructiveLabel:String,onDismiss:()->Unit,onConfirm:()->Unit) {
    var typed by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest=onDismiss,title={Text(title)},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Text(text);Text("Digite $requiredWord para confirmar.",fontWeight=FontWeight.Bold);OutlinedTextField(typed,{typed=it.uppercase()},singleLine=true)}},confirmButton={Button(onClick=onConfirm,enabled=typed==requiredWord,colors=ButtonDefaults.buttonColors(containerColor=MaterialTheme.colorScheme.error)){Text(destructiveLabel)}},dismissButton={TextButton(onClick=onDismiss){Text("Cancelar")}})
}

@Composable
private fun DeleteAccountDialog(usesPassword:Boolean,onDismiss:()->Unit,onConfirm:(String?)->Unit){
    var typed by remember{mutableStateOf("")};var password by remember{mutableStateOf("")}
    AlertDialog(onDismissRequest=onDismiss,title={Text("Excluir conta permanentemente?")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Text("Perfil, backup, dados, presença e benefícios promocionais serão removidos. Ao criar uma nova conta depois, ela começa Free.");Text("Digite EXCLUIR para confirmar.",fontWeight=FontWeight.Bold);OutlinedTextField(typed,{typed=it.uppercase()},singleLine=true);if(usesPassword)OutlinedTextField(password,{password=it},label={Text("Senha atual")},singleLine=true);else Text("Você confirmará novamente sua conta Google no próximo passo.",style=MaterialTheme.typography.bodySmall)}},confirmButton={Button(onClick={onConfirm(password.takeIf{usesPassword})},enabled=typed=="EXCLUIR"&&(!usesPassword||password.isNotBlank()),colors=ButtonDefaults.buttonColors(containerColor=MaterialTheme.colorScheme.error)){Text("Excluir conta")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancelar")}})
}

private fun formatDateTime(epoch:Long):String=runCatching{LocalDateTime.ofInstant(Instant.ofEpochMilli(epoch),ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("dd/MM/yyyy 'às' HH:mm"))}.getOrDefault("—")
