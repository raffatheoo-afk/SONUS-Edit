package com.sonusstudios.streampulse.core

import android.content.Context

/** Preferências pequenas compartilhadas por editores/conversores de mídia do SONUS. */
object SonusMediaPreferences {
    private const val PREFS = "sonus_media_standards_v1"
    private const val KEY_LAST_GENRE = "last_genre"

    fun lastGenre(context: Context, fallback: String = "Piseiro"): String {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_LAST_GENRE, fallback)
            .orEmpty()
        val canonical = SonusMediaStandards.canonicalGenre(raw)
        return canonical.takeIf { it in SonusMediaStandards.genres } ?: fallback
    }

    fun saveLastGenre(context: Context, genre: String) {
        val canonical = SonusMediaStandards.canonicalGenre(genre)
        if (canonical in SonusMediaStandards.genres) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_LAST_GENRE, canonical)
                .apply()
        }
    }

    fun initialGenre(context: Context, current: String?): String {
        val canonical = SonusMediaStandards.canonicalGenre(current.orEmpty())
        return if (canonical in SonusMediaStandards.genres) canonical else lastGenre(context)
    }
}
