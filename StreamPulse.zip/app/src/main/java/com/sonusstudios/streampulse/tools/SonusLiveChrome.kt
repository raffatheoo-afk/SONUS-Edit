package com.sonusstudios.streampulse.tools

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

/**
 * 0.0.1: estado compartilhado entre o Studio ao vivo e a MainActivity.
 * Live no ar = barra inferior do SONUS escondida (reaparece por alguns segundos ao tocar na tela).
 */
internal object SonusLiveChrome {
    var onAir by mutableStateOf(false)
    var barRevealed by mutableStateOf(false)
    val hideBottomBar: Boolean get() = onAir && !barRevealed
}

internal fun Context.findHostActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

/**
 * Enquanto [active]: esconde a barra de status e a de navegação do Android (modo imersivo) e libera a rotação
 * (retrato/paisagem). Ao sair, devolve as barras e a orientação anterior (o app é retrato por padrão).
 */
@Composable
internal fun SonusLiveImmersiveEffect(active: Boolean) {
    val view = LocalView.current
    DisposableEffect(active) {
        val activity = view.context.findHostActivity()
        val window = activity?.window
        val controller = window?.let { WindowCompat.getInsetsController(it, view) }
        val previousOrientation = activity?.requestedOrientation
        if (active) {
            controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller?.hide(WindowInsetsCompat.Type.systemBars())
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
        }
        onDispose {
            if (active) {
                controller?.show(WindowInsetsCompat.Type.systemBars())
                if (activity != null && previousOrientation != null) activity.requestedOrientation = previousOrientation
            }
        }
    }
}
