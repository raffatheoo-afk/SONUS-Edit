package com.sonusstudios.streampulse.tools

import android.Manifest
import android.app.Activity
import android.app.PictureInPictureParams
import android.content.Context
import android.content.ContextWrapper
import android.content.ContentUris
import android.content.pm.PackageManager
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.net.Uri
import android.media.AudioManager
import android.media.MediaMetadataRetriever
import android.media.MediaExtractor
import android.media.MediaFormat
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Rational
import android.util.TypedValue
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.documentfile.provider.DocumentFile
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.PlayerView
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs
import java.net.URL
import java.net.HttpURLConnection

private enum class VideoHubSection { LOCAL, YOUTUBE, LINK, KARAOKE, SETTINGS }

private data class VideoResumeTarget(
    val uri: String,
    val providerId: String,
    val title: String,
    val positionMs: Long,
    val durationMs: Long,
    val youtubeId: String? = null
)

private data class LocalVideoItem(
    val uri: String,
    val title: String,
    val durationMs: Long,
    val dateModified: Long
)

private data class VideoTechnicalInfo(
    val resolution: String = "—",
    val videoCodec: String = "—",
    val fps: String = "—",
    val bitrate: String = "—",
    val audioCodec: String = "—",
    val audioChannels: String = "—",
    val duration: String = "—",
    val size: String = "—"
)

@OptIn(androidx.media3.common.util.UnstableApi::class)
@Composable
internal fun SonusVideoPlayerScreen(
    preferences: com.sonusstudios.streampulse.core.UserPreferences,
    onFullscreenChange: (Boolean) -> Unit = {},
    externalVideoUri: String? = null,
    onExternalVideoConsumed: () -> Unit = {},
    onTrack: (String, Boolean?, Long?) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val store = remember { SonusCloudMediaStore(context) }
    val videoSettings = remember { SonusVideoSettingsStore(context) }
    var settingsRefresh by remember { mutableIntStateOf(0) }
    var section by remember { mutableStateOf(VideoHubSection.LOCAL) }
    var activeUri by remember { mutableStateOf<Uri?>(null) }
    var activeTitle by remember { mutableStateOf("") }
    var activeProvider by remember { mutableStateOf("local") }
    var playbackSpeed by remember { mutableFloatStateOf(videoSettings.playbackSpeed) }
    var subtitleUri by remember { mutableStateOf<Uri?>(null) }
    var refresh by remember { mutableIntStateOf(0) }
    var favoriteVideos by remember { mutableStateOf(store.favoriteUris("video")) }
    var resizeMode by remember { mutableIntStateOf(AspectRatioFrameLayout.RESIZE_MODE_FIT) }
    var isFullscreen by remember { mutableStateOf(false) }
    var pendingYoutubeResume by remember { mutableStateOf<SonusCloudRecent?>(null) }
    var gestureHint by remember { mutableStateOf<String?>(null) }
    var controlsLocked by remember { mutableStateOf(false) }
    var currentAudioSessionId by remember { mutableIntStateOf(0) }
    var timerDeadline by remember { mutableStateOf<Long?>(null) }
    var showTechnicalInfo by remember { mutableStateOf(false) }
    val videoEqController = remember { SonusVideoEqualizerController() }
    var liveCaptionEnabled by remember { mutableStateOf(false) }
    var liveCaptionLine by remember { mutableStateOf("") }
    var liveCaptionStatus by remember { mutableStateOf("") }
    var liveCaptionGeneration by remember { mutableIntStateOf(0) }
    var liveCaptionTranscript by remember { mutableStateOf<List<SonusTranscriptLine>>(emptyList()) }
    var showLiveCaptionMenu by remember { mutableStateOf(false) }
    var liveCaptionTranscriber by remember { mutableStateOf<PulseSpeechTranscriber?>(null) }
    val audioManager = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    var galleryRefresh by remember { mutableIntStateOf(0) }
    var localVideos by remember { mutableStateOf<List<LocalVideoItem>>(emptyList()) }
    var galleryPermissionGranted by remember { mutableStateOf(hasVideoLibraryPermission(context)) }
    val galleryPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        galleryPermissionGranted = hasVideoLibraryPermission(context)
        galleryRefresh++
    }
    val saveLiveCaptionTxt = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { out ->
        if (out != null) scope.launch(Dispatchers.IO) { runCatching { context.contentResolver.openOutputStream(out,"w")?.bufferedWriter()?.use { it.write(liveCaptionTranscript.joinToString("\n") { line -> line.text }) } } }
    }
    val saveLiveCaptionLrc = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { out ->
        if (out != null) scope.launch(Dispatchers.IO) { runCatching { context.contentResolver.openOutputStream(out,"w")?.bufferedWriter()?.use { it.write(transcriptToLrc(liveCaptionTranscript)) } } }
    }

    LaunchedEffect(Unit) {
        if (!galleryPermissionGranted) {
            val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE
            galleryPermissionLauncher.launch(permission)
        }
    }
    LaunchedEffect(galleryPermissionGranted, galleryRefresh, settingsRefresh) {
        localVideos = if (galleryPermissionGranted) queryDeviceVideos(context, videoSettings) else emptyList()
        store.pruneMissingLocalVideoRecents(context)
        refresh++
    }

    val trackSelector = remember { DefaultTrackSelector(context) }
    val player = remember {
        ExoPlayer.Builder(context).setTrackSelector(trackSelector).build().apply { playWhenReady = true }
    }
    DisposableEffect(Unit) { onDispose {
        context.findActivityForVideo()?.let { act ->
            act.window.decorView.systemUiVisibility = android.view.View.SYSTEM_UI_FLAG_VISIBLE
            act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        }
        onFullscreenChange(false)
        videoEqController.release()
        liveCaptionTranscriber?.destroy()
        player.release()
    } }

    LaunchedEffect(activeUri) { liveCaptionTranscript = emptyList(); liveCaptionLine = "" }

    LaunchedEffect(liveCaptionEnabled, liveCaptionGeneration, activeUri) {
        if (!liveCaptionEnabled) { liveCaptionLine=""; liveCaptionStatus=""; liveCaptionTranscriber?.destroy(); liveCaptionTranscriber=null; return@LaunchedEffect }
        val source = activeUri?.toString() ?: return@LaunchedEffect
        liveCaptionStatus = "Preparando legenda…"
        val startMs = player.currentPosition.coerceAtLeast(0L)
        val pcm = withContext(Dispatchers.IO) { prepareSpeechPcmSegment(context, source, startMs, 18) }
        if (pcm == null) { liveCaptionStatus="Não foi possível ler o áudio deste vídeo"; return@LaunchedEffect }
        liveCaptionStatus = "Legenda ao vivo"
        val tr = PulseSpeechTranscriber(
            context,
            onPartial = { text -> liveCaptionLine=text.lineSequence().lastOrNull{it.isNotBlank()}.orEmpty() },
            onFinal = { text ->
                val finalLine=text.lineSequence().lastOrNull{it.isNotBlank()}.orEmpty()
                liveCaptionLine=finalLine
                if(finalLine.isNotBlank()) liveCaptionTranscript = liveCaptionTranscript + SonusTranscriptLine(startMs, finalLine)
                pcm.delete()
                if (liveCaptionEnabled) scope.launch { delay(1200); liveCaptionGeneration++ }
            },
            onError = { msg -> liveCaptionStatus=msg; pcm.delete() }
        )
        liveCaptionTranscriber?.destroy(); liveCaptionTranscriber=tr; tr.transcribePcmFile(pcm,videoSettings.liveCaptionLanguage)
    }

    fun loadVideo(uri: Uri, title: String, provider: String, positionMs: Long = 0L) {
        persistCloudUri(context, uri)
        activeUri = uri
        activeTitle = title
        activeProvider = provider
        val mediaBuilder = MediaItem.Builder().setUri(uri).setMediaId(title)
        subtitleUri?.let { sub ->
            val prepared = prepareSubtitleUri(context, sub, videoSettings.subtitleOffsetMs)
            val subtitleName = DocumentFile.fromSingleUri(context, sub)?.name.orEmpty().lowercase()
            val subtitleMime = if (subtitleName.endsWith(".vtt")) MimeTypes.TEXT_VTT else MimeTypes.APPLICATION_SUBRIP
            mediaBuilder.setSubtitleConfigurations(
                listOf(
                    MediaItem.SubtitleConfiguration.Builder(prepared)
                        .setMimeType(subtitleMime)
                        .setLanguage("pt")
                        .setSelectionFlags(androidx.media3.common.C.SELECTION_FLAG_DEFAULT)
                        .build()
                )
            )
        }
        player.shuffleModeEnabled = false
        player.repeatMode = if (videoSettings.playbackMode == "Repetir vídeo") Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
        playbackSpeed = videoSettings.playbackSpeed
        player.playbackParameters = PlaybackParameters(playbackSpeed)
        player.setMediaItem(mediaBuilder.build(), positionMs.coerceAtLeast(0L))
        player.prepare()
        player.playWhenReady = true
        timerDeadline = videoSettings.timerMinutes.takeIf { it > 0 }?.let { System.currentTimeMillis() + it * 60_000L }
        store.addRecent(SonusCloudRecent(uri.toString(), provider, title, "video", positionMs, 0L))
        refresh++
        onTrack("SONUS VIDEO: $title", true, null)
    }

    LaunchedEffect(externalVideoUri) {
        val raw = externalVideoUri ?: return@LaunchedEffect
        val uri = runCatching { Uri.parse(raw) }.getOrNull() ?: run { onExternalVideoConsumed(); return@LaunchedEffect }
        val title = DocumentFile.fromSingleUri(context, uri)?.name?.substringBeforeLast('.')?.ifBlank { "Vídeo" } ?: "Vídeo"
        val position = if (videoSettings.rememberExternalPosition) videoSettings.externalPosition(raw) else 0L
        loadVideo(uri, title, "external", position)
        section = VideoHubSection.LOCAL
        onExternalVideoConsumed()
    }

    fun loadLocalVideo(item: LocalVideoItem, positionMs: Long = 0L) {
        val mode = videoSettings.playbackMode
        if (mode == "Repetir vídeo" || localVideos.size <= 1) {
            loadVideo(Uri.parse(item.uri), item.title, "local", positionMs)
            return
        }
        activeUri = Uri.parse(item.uri)
        activeTitle = item.title
        activeProvider = "local"
        val queue = localVideos.map { local -> MediaItem.Builder().setUri(local.uri).setMediaId(local.title).build() }
        val startIndex = localVideos.indexOfFirst { it.uri == item.uri }.coerceAtLeast(0)
        player.shuffleModeEnabled = mode == "Aleatório"
        player.repeatMode = if (mode == "Repetir todos") Player.REPEAT_MODE_ALL else Player.REPEAT_MODE_OFF
        playbackSpeed = videoSettings.playbackSpeed
        player.playbackParameters = PlaybackParameters(playbackSpeed)
        player.setMediaItems(queue, startIndex, positionMs.coerceAtLeast(0L))
        player.prepare()
        player.playWhenReady = true
        timerDeadline = videoSettings.timerMinutes.takeIf { it > 0 }?.let { System.currentTimeMillis() + it * 60_000L }
        store.addRecent(SonusCloudRecent(item.uri, "local", item.title, "video", positionMs, item.durationMs))
        refresh++
        onTrack("SONUS VIDEO: ${item.title}", true, null)
    }

    val localPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        persistCloudUri(context, uri)
        val title = DocumentFile.fromSingleUri(context, uri)?.name?.substringBeforeLast('.') ?: "Vídeo"
        loadVideo(uri, title, "local")
        section = VideoHubSection.LOCAL
    }
    val subtitlePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        persistCloudUri(context, uri)
        subtitleUri = uri
        activeUri?.let { loadVideo(it, activeTitle, activeProvider, player.currentPosition) }
    }

    LaunchedEffect(activeUri, player) {
        while (activeUri != null) {
            delay(2_000L)
            val fallbackUri = activeUri ?: break
            val currentItem = player.currentMediaItem
            val uri = currentItem?.localConfiguration?.uri ?: fallbackUri
            if (activeProvider == "local" && currentItem != null) {
                if (currentItem.mediaId.isNotBlank() && currentItem.mediaId != activeTitle) activeTitle = currentItem.mediaId
                if (uri != activeUri) activeUri = uri
            }
            currentAudioSessionId = player.audioSessionId
            val duration = player.duration.takeIf { it > 0 } ?: 0L
            val pos = player.currentPosition.coerceAtLeast(0L)
            store.updateProgress(uri.toString(), "video", pos, duration)
            if (activeProvider == "external" && videoSettings.rememberExternalPosition) {
                videoSettings.saveExternalPosition(uri.toString(), pos)
            }
            if (player.isPlaying) videoSettings.addPlayback(2_000L)
            timerDeadline?.let { deadline ->
                if (System.currentTimeMillis() >= deadline) {
                    player.pause()
                    timerDeadline = null
                    gestureHint = "Temporizador concluído"
                }
            }
            if (duration > 0 && pos >= duration - 12_000L) {
                store.updateProgress(uri.toString(), "video", duration, duration)
                if (videoSettings.stopAtEnd) player.pause()
            }
            refresh++
        }
    }

    val activeCategory = remember(activeTitle, activeUri, settingsRefresh) {
        val uri = activeUri?.toString().orEmpty()
        videoSettings.categoryOverride(uri)
            ?: if (videoSettings.autoEq) classifySonusVideoTitle(activeTitle) else videoSettings.manualCategory
    }
    LaunchedEffect(currentAudioSessionId, activeCategory, settingsRefresh) {
        videoEqController.apply(currentAudioSessionId, videoSettings.eqEnabled, videoEqCurve(activeCategory))
        val trackParams = trackSelector.buildUponParameters()
        when (videoSettings.performanceProfile) {
            "Econômico" -> trackParams.setMaxVideoSize(1280, 720)
            "Máxima qualidade" -> trackParams.setMaxVideoSize(Int.MAX_VALUE, Int.MAX_VALUE)
            else -> trackParams.setMaxVideoSize(1920, 1080)
        }
        trackSelector.parameters = trackParams.build()
        playbackSpeed = videoSettings.playbackSpeed
        player.playbackParameters = PlaybackParameters(playbackSpeed)
        player.repeatMode = if (videoSettings.playbackMode == "Repetir vídeo") Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
    }
    LaunchedEffect(section) {
        while (true) {
            delay(5_000L)
            videoSettings.addUsage(section.name.lowercase(), 5_000L)
        }
    }

    fun setFullscreen(enabled: Boolean) {
        isFullscreen = enabled
        onFullscreenChange(enabled)
        context.findActivityForVideo()?.let { act ->
            act.window.decorView.systemUiVisibility = if (enabled) {
                android.view.View.SYSTEM_UI_FLAG_FULLSCREEN or android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            } else android.view.View.SYSTEM_UI_FLAG_VISIBLE
            act.requestedOrientation = if (enabled) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        }
    }

    BackHandler(enabled = isFullscreen || section != VideoHubSection.LOCAL) {
        if (isFullscreen) setFullscreen(false) else section = VideoHubSection.LOCAL
    }

    if (showTechnicalInfo && activeUri != null) {
        val info by produceState(initialValue = VideoTechnicalInfo(), activeUri) {
            value = withContext(Dispatchers.IO) { readVideoTechnicalInfo(context, activeUri!!) }
        }
        AlertDialog(
            onDismissRequest = { showTechnicalInfo = false },
            title = { Text("Informações do vídeo", fontWeight=FontWeight.ExtraBold) },
            text = { Column(verticalArrangement=Arrangement.spacedBy(6.dp)) {
                listOf(
                    "Resolução" to info.resolution, "Codec de vídeo" to info.videoCodec, "FPS" to info.fps,
                    "Bitrate" to info.bitrate, "Áudio" to info.audioCodec, "Canais" to info.audioChannels,
                    "Duração" to info.duration, "Tamanho" to info.size
                ).forEach { (label,value) -> Row(Modifier.fillMaxWidth()) { Text(label,Modifier.weight(1f),fontWeight=FontWeight.SemiBold);Text(value) } }
            } },
            confirmButton = { TextButton(onClick={showTechnicalInfo=false}){Text("Fechar")} }
        )
    }

    val playerTheme = remember(settingsRefresh) { videoSettings.theme }
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(playerTheme.colors))) {
        Column(Modifier.fillMaxSize()) {
            if (!isFullscreen) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("SONUS VIDEO", color = Color.White, fontWeight = FontWeight.Black, fontSize = 23.sp)
                        Text("Vídeos • YouTube • Link • Karaokê", color = Color.White.copy(alpha = .58f), fontSize = 11.sp)
                    }
                    if (activeUri != null) {
                        IconButton(onClick = {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                context.findActivityForVideo()?.enterPictureInPictureMode(
                                    PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build()
                                )
                            }
                        }) { Icon(Icons.Default.PictureInPictureAlt, "Picture in Picture", tint = Color(0xFF70D8FF)) }
                    }
                }
            }

            if (activeUri != null && section != VideoHubSection.YOUTUBE && section != VideoHubSection.LINK && section != VideoHubSection.KARAOKE) {
                Surface(
                    modifier = if (isFullscreen) Modifier.fillMaxSize() else Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                    shape = if (isFullscreen) RoundedCornerShape(0.dp) else RoundedCornerShape(18.dp),
                    color = Color.Black,
                    border = if (isFullscreen) null else BorderStroke(1.dp, Color(0xFF4FBCE8).copy(alpha = .35f))
                ) {
                    Column {
                        Box(
                            modifier = (if (isFullscreen) Modifier.fillMaxWidth().weight(1f) else Modifier.fillMaxWidth().aspectRatio(16f / 9f))
                                .pointerInput(player, controlsLocked) {
                                    detectTapGestures(onDoubleTap = { pos ->
                                        if (!controlsLocked) {
                                            val delta = if (pos.x < size.width / 2f) -10_000L else 10_000L
                                            val duration = player.duration.takeIf { it > 0 } ?: Long.MAX_VALUE
                                            val next = (player.currentPosition + delta).coerceIn(0L, duration)
                                            player.seekTo(next)
                                            gestureHint = if (delta < 0) "-10 s" else "+10 s"
                                        }
                                    })
                                }
                                .pointerInput(player, controlsLocked) {
                                var startX = 0f
                                var mode = 0 // 1 brilho, 2 volume, 3 seek
                                detectDragGestures(
                                    onDragStart = { pos -> startX = pos.x; mode = 0 },
                                    onDragEnd = { gestureHint = null; mode = 0 },
                                    onDragCancel = { gestureHint = null; mode = 0 },
                                    onDrag = { _, drag ->
                                        if (!controlsLocked) {
                                            if (mode == 0) {
                                                mode = if (abs(drag.x) > abs(drag.y)) 3 else if (startX < size.width * .34f) 1 else if (startX > size.width * .66f) 2 else 0
                                            }
                                            when (mode) {
                                            1 -> {
                                                context.findActivityForVideo()?.let { act ->
                                                    val lp = act.window.attributes
                                                    val current = if (lp.screenBrightness < 0f) .5f else lp.screenBrightness
                                                    val next = (current - drag.y / size.height.toFloat()).coerceIn(.02f, 1f)
                                                    lp.screenBrightness = next
                                                    act.window.attributes = lp
                                                    gestureHint = "Brilho ${(next * 100).toInt()}%"
                                                }
                                            }
                                            2 -> {
                                                val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                                                val current = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                                                val delta = (-drag.y / size.height.toFloat() * max).toInt()
                                                val next = (current + delta).coerceIn(0, max)
                                                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, next, 0)
                                                gestureHint = "Volume ${(next * 100 / max)}%"
                                            }
                                            3 -> {
                                                val duration = player.duration
                                                if (duration > 0) {
                                                    val deltaMs = (drag.x / size.width.toFloat() * duration * .75f).toLong()
                                                    val next = (player.currentPosition + deltaMs).coerceIn(0L, duration)
                                                    player.seekTo(next)
                                                    gestureHint = "${formatVideoClock(next)} / ${formatVideoClock(duration)}"
                                                }
                                            }
                                        }
                                        }
                                    }
                                )
                            }
                        ) {
                            AndroidView(
                                modifier = Modifier.matchParentSize(),
                                factory = { ctx -> PlayerView(ctx).apply { useController = !controlsLocked; this.player = player; this.resizeMode = resizeMode } },
                                update = {
                                    it.player = player; it.resizeMode = resizeMode; it.useController = !controlsLocked
                                    val foreground = when(videoSettings.subtitleColor) { "Amarelo" -> android.graphics.Color.YELLOW; "Ciano" -> android.graphics.Color.CYAN; else -> android.graphics.Color.WHITE }
                                    val background = if(videoSettings.subtitleBackground) android.graphics.Color.argb(150,0,0,0) else android.graphics.Color.TRANSPARENT
                                    it.subtitleView?.setFixedTextSize(TypedValue.COMPLEX_UNIT_SP, videoSettings.subtitleSizeSp)
                                    it.subtitleView?.setStyle(CaptionStyleCompat(foreground, background, android.graphics.Color.TRANSPARENT, CaptionStyleCompat.EDGE_TYPE_DROP_SHADOW, android.graphics.Color.BLACK, null))
                                }
                            )
                            gestureHint?.let { hint ->
                                Surface(
                                    modifier = Modifier.align(Alignment.Center),
                                    shape = RoundedCornerShape(14.dp),
                                    color = Color.Black.copy(alpha = .72f)
                                ) { Text(hint, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.padding(horizontal=12.dp,vertical=8.dp)) }
                            }
                            if (liveCaptionEnabled && liveCaptionLine.isNotBlank()) {
                                val captionColor = when(videoSettings.subtitleColor) { "Ciano" -> Color.Cyan; "Branco" -> Color.White; else -> Color.Yellow }
                                val captionAlignment = when(videoSettings.subtitlePosition) { "Superior" -> Alignment.TopCenter; "Centro" -> Alignment.Center; else -> Alignment.BottomCenter }
                                Surface(
                                    modifier=Modifier.align(captionAlignment).padding(horizontal=18.dp,vertical=22.dp),
                                    shape=RoundedCornerShape(7.dp),
                                    color=if(videoSettings.subtitleBackground) Color.Black.copy(alpha=.68f) else Color.Transparent
                                ){
                                    Text(liveCaptionLine,color=captionColor,fontSize=videoSettings.subtitleSizeSp.sp,fontWeight=FontWeight.SemiBold,modifier=Modifier.padding(horizontal=7.dp,vertical=3.dp),maxLines=2,overflow=TextOverflow.Ellipsis)
                                }
                            }
                            if (isFullscreen) {
                                Surface(
                                    modifier = Modifier.align(Alignment.TopStart).padding(12.dp),
                                    shape = RoundedCornerShape(14.dp),
                                    color = Color.Black.copy(alpha = .62f),
                                    border = BorderStroke(1.dp, Color.White.copy(alpha = .16f))
                                ) {
                                    IconButton(onClick = { controlsLocked = !controlsLocked }, modifier = Modifier.size(40.dp)) {
                                        Icon(if (controlsLocked) Icons.Default.Lock else Icons.Default.LockOpen, if (controlsLocked) "Desbloquear controles" else "Bloquear controles", tint = Color.White)
                                    }
                                }
                                Surface(
                                    modifier = Modifier.align(Alignment.TopEnd).padding(12.dp),
                                    shape = RoundedCornerShape(14.dp),
                                    color = Color.Black.copy(alpha = .62f),
                                    border = BorderStroke(1.dp, Color.White.copy(alpha = .16f))
                                ) {
                                    IconButton(onClick = { setFullscreen(false) }, modifier = Modifier.size(40.dp)) {
                                        Icon(Icons.Default.FullscreenExit, "Sair da tela cheia", tint = Color.White)
                                    }
                                }
                            }
                        }
                        if (!isFullscreen) Row(Modifier.fillMaxWidth().padding(horizontal = 9.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(activeTitle, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                            var eqMenu by remember(activeUri) { mutableStateOf(false) }
                            Box {
                                TextButton(onClick = { eqMenu = true }, contentPadding = PaddingValues(horizontal = 5.dp, vertical = 0.dp)) {
                                    Text("EQ • ${activeCategory.label.substringBefore(" /")}", fontSize = 8.sp, color = playerTheme.accent)
                                }
                                DropdownMenu(expanded = eqMenu, onDismissRequest = { eqMenu = false }) {
                                    DropdownMenuItem(text = { Text("Automático") }, onClick = {
                                        activeUri?.toString()?.let { videoSettings.setCategoryOverride(it, null) }
                                        settingsRefresh++; eqMenu = false
                                    })
                                    SonusVideoCategory.entries.forEach { category ->
                                        DropdownMenuItem(text = { Text(category.label) }, onClick = {
                                            activeUri?.toString()?.let { videoSettings.setCategoryOverride(it, category) }
                                            settingsRefresh++; eqMenu = false
                                        })
                                    }
                                }
                            }
                            listOf(.5f, 1f, 1.5f, 2f, 3f).forEach { speed ->
                                TextButton(onClick = { playbackSpeed = speed; player.playbackParameters = PlaybackParameters(speed) }, contentPadding = PaddingValues(horizontal = 5.dp, vertical = 0.dp)) {
                                    Text(if (speed == 1f) "1x" else "${speed}x", fontSize = 9.sp, color = if (playbackSpeed == speed) Color(0xFF70D8FF) else Color.White.copy(alpha = .60f))
                                }
                            }
                            IconButton(onClick = { showTechnicalInfo = true }, modifier = Modifier.size(32.dp)) {
                                Icon(Icons.Default.Info, "Informações do vídeo", tint = Color.White.copy(alpha=.82f), modifier=Modifier.size(18.dp))
                            }
                            Box {
                                IconButton(onClick = {
                                    if(!liveCaptionEnabled){liveCaptionEnabled=true;liveCaptionGeneration++} else showLiveCaptionMenu=true
                                }, modifier = Modifier.size(32.dp)) {
                                    Icon(Icons.Default.ClosedCaption, if(liveCaptionEnabled) "Opções da legenda ao vivo" else "Legenda ao vivo", tint = if(liveCaptionEnabled) Color.Yellow else Color.White.copy(alpha=.82f), modifier=Modifier.size(18.dp))
                                }
                                DropdownMenu(expanded=showLiveCaptionMenu,onDismissRequest={showLiveCaptionMenu=false}) {
                                    DropdownMenuItem(text={Text("Desativar Legenda ao vivo")},onClick={showLiveCaptionMenu=false;liveCaptionEnabled=false;liveCaptionLine="";liveCaptionTranscriber?.destroy()})
                                    DropdownMenuItem(text={Text("Salvar transcrição TXT")},enabled=liveCaptionTranscript.isNotEmpty(),onClick={showLiveCaptionMenu=false;saveLiveCaptionTxt.launch("SONUS_Video_Transcricao_${System.currentTimeMillis()}.txt")})
                                    DropdownMenuItem(text={Text("Salvar legenda LRC")},enabled=liveCaptionTranscript.isNotEmpty(),onClick={showLiveCaptionMenu=false;saveLiveCaptionLrc.launch("SONUS_Video_Legenda_${System.currentTimeMillis()}.lrc")})
                                }
                            }
                            IconButton(onClick = { subtitlePicker.launch(arrayOf("application/x-subrip", "text/vtt", "text/*")) }, modifier = Modifier.size(32.dp)) {
                                Icon(Icons.Default.Subtitles, "Legenda externa", tint = Color.White.copy(alpha = .82f), modifier = Modifier.size(18.dp))
                            }
                            IconButton(onClick = {
                                resizeMode = when(resizeMode){
                                    AspectRatioFrameLayout.RESIZE_MODE_FIT -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                                    AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                                    else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                                }
                            }, modifier=Modifier.size(32.dp)) { Icon(Icons.Default.AspectRatio,"Proporção",tint=Color.White.copy(alpha=.82f),modifier=Modifier.size(18.dp)) }
                            IconButton(onClick = { setFullscreen(!isFullscreen) }, modifier=Modifier.size(32.dp)) {
                                Icon(Icons.Default.ScreenRotation, "Tela cheia / girar vídeo", tint=Color.White.copy(alpha=.82f), modifier=Modifier.size(19.dp))
                            }
                        }
                    }
                }
            }

            if (!isFullscreen) VideoSectionBar(section) { section = it }

            if (!isFullscreen) when (section) {
                VideoHubSection.LOCAL -> VideoHome(
                    recents = remember(refresh) { store.recents("video").filter { it.providerId == "local" || it.providerId == "youtube" } },
                    localVideos = localVideos,
                    thumbnailSize = remember(settingsRefresh) { videoSettings.thumbnailSize },
                    galleryPermissionGranted = galleryPermissionGranted,
                    onRequestGalleryPermission = {
                        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE
                        galleryPermissionLauncher.launch(permission)
                    },
                    onPickFile = { localPicker.launch(arrayOf("video/*")) },
                    onOpenLocal = { item -> loadLocalVideo(item, store.recents("video").firstOrNull { it.uri == item.uri }?.positionMs ?: 0L) },
                    onResume = { recent ->
                        if (recent.providerId == "youtube" && recent.uri.startsWith("youtube:")) {
                            pendingYoutubeResume = recent
                            section = VideoHubSection.YOUTUBE
                        } else loadVideo(Uri.parse(recent.uri), recent.title, recent.providerId, recent.positionMs)
                    },
                    onRemoveRecent = { recent -> store.removeRecent("video", recent.uri); refresh++ }
                )
                VideoHubSection.YOUTUBE -> SonusYouTubeVideoPanel(
                    store = store,
                    resumeTarget = pendingYoutubeResume,
                    onResumeConsumed = { pendingYoutubeResume = null }
                )
                VideoHubSection.LINK -> SonusExternalVideoLinkPanel(onOpenDirect = { uri, title -> loadVideo(uri, title, "link", 0L) })
                VideoHubSection.KARAOKE -> KaraokeTool(onBack = { section = VideoHubSection.LOCAL }, onTrack = onTrack, preferences = preferences)
                VideoHubSection.SETTINGS -> SonusVideoSettingsScreen(videoSettings) { settingsRefresh++; galleryRefresh++ }
            }
        }
    }
}

@Composable
private fun VideoSectionBar(section: VideoHubSection, onSelect: (VideoHubSection) -> Unit) {
    val entries = listOf(
        Triple(VideoHubSection.LOCAL, Icons.Default.VideoLibrary, "Vídeos"),
        Triple(VideoHubSection.YOUTUBE, Icons.Default.SmartDisplay, "YouTube"),
        Triple(VideoHubSection.LINK, Icons.Default.Language, "Link"),
        Triple(VideoHubSection.KARAOKE, Icons.Default.MicExternalOn, "Karaokê"),
        Triple(VideoHubSection.SETTINGS, Icons.Default.Settings, "Ajustes")
    )
    Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        entries.forEach { (id, icon, label) ->
            val selected = section == id
            val accent = when (id) {
                VideoHubSection.LOCAL -> Color(0xFF9B6CFF)
                VideoHubSection.YOUTUBE -> Color(0xFFFF4F5E)
                VideoHubSection.LINK -> Color(0xFF58B8FF)
                VideoHubSection.KARAOKE -> Color(0xFF65E6C4)
                VideoHubSection.SETTINGS -> Color(0xFFB9C6D8)
            }
            val selectedBrush = when (id) {
                VideoHubSection.KARAOKE -> Brush.linearGradient(listOf(Color(0xFF22C98A).copy(alpha=.34f), Color(0xFF318DFF).copy(alpha=.34f), Color(0xFF9D56FF).copy(alpha=.34f)))
                else -> Brush.linearGradient(listOf(accent.copy(alpha=.30f), accent.copy(alpha=.14f)))
            }
            Box(
                modifier = Modifier.weight(1f).clip(RoundedCornerShape(14.dp))
                    .background(if (selected) selectedBrush else Brush.linearGradient(listOf(Color.White.copy(alpha=.055f), Color.White.copy(alpha=.035f))))
                    .border(1.dp, if (selected) accent.copy(alpha=.62f) else Color.White.copy(alpha=.08f), RoundedCornerShape(14.dp))
                    .clickable { onSelect(id) }
            ) {
                Column(Modifier.fillMaxWidth().padding(vertical = 7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(icon, null, tint = if (selected) accent else Color.White.copy(alpha=.70f), modifier = Modifier.size(17.dp))
                    Text(label, fontSize = 8.sp, color = Color.White.copy(alpha = if (selected) .96f else .62f), maxLines = 1)
                }
            }
        }
    }
}

@Composable
private fun VideoHome(
    recents: List<SonusCloudRecent>,
    localVideos: List<LocalVideoItem>,
    thumbnailSize: SonusVideoThumbnailSize,
    galleryPermissionGranted: Boolean,
    onRequestGalleryPermission: () -> Unit,
    onPickFile: () -> Unit,
    onOpenLocal: (LocalVideoItem) -> Unit,
    onResume: (SonusCloudRecent) -> Unit,
    onRemoveRecent: (SonusCloudRecent) -> Unit
) {
    // O mesmo vídeo aparece uma única vez no Continuar assistindo, usando sempre
    // o registro mais recente, e apenas enquanto ainda há algo relevante para assistir.
    val continueItems = recents
        .distinctBy { it.uri }
        .filter { it.durationMs <= 0L || (it.positionMs in 8_000 until (it.durationMs - 12_000).coerceAtLeast(9_000)) }
        .take(3)

    val horizontalPadding = when (thumbnailSize) { SonusVideoThumbnailSize.SMALL -> 18.dp; SonusVideoThumbnailSize.MEDIUM -> 16.dp; SonusVideoThumbnailSize.LARGE -> 12.dp }
    val columns = when (thumbnailSize) { SonusVideoThumbnailSize.SMALL -> 3; SonusVideoThumbnailSize.MEDIUM -> 2; SonusVideoThumbnailSize.LARGE -> 1 }
    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = horizontalPadding),
        verticalArrangement = Arrangement.spacedBy(11.dp),
        contentPadding = PaddingValues(bottom = 30.dp)
    ) {
        if (continueItems.isNotEmpty()) {
            item { Text("Continuar assistindo", color = Color.White, fontWeight = FontWeight.Black, fontSize = 18.sp) }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    continueItems.forEach { item ->
                        ContinueWatchingCompactCard(item, onResume, onRemoveRecent, Modifier.weight(1f))
                    }
                    repeat((3 - continueItems.size).coerceAtLeast(0)) { Spacer(Modifier.weight(1f)) }
                }
            }
        }

        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Meus vídeos", color = Color.White, fontWeight = FontWeight.Black, fontSize = 18.sp)
                    Text(
                        if (galleryPermissionGranted) "${localVideos.size} vídeos encontrados na galeria" else "Permita o acesso para mostrar sua galeria automaticamente",
                        color = Color.White.copy(alpha = .52f),
                        fontSize = 9.sp
                    )
                }
                if (!galleryPermissionGranted) {
                    TextButton(onClick = onRequestGalleryPermission) { Text("Permitir") }
                }
            }
        }

        if (!galleryPermissionGranted) {
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    color = Color.White.copy(alpha=.05f),
                    border = BorderStroke(1.dp, Color.White.copy(alpha=.08f))
                ) {
                    Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.VideoLibrary, null, tint = Color(0xFF69D7FF))
                        Spacer(Modifier.height(6.dp))
                        Text("O SONUS precisa de acesso aos vídeos para montar sua biblioteca.", color=Color.White.copy(alpha=.72f), fontSize=10.sp)
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(onClick = onPickFile) { Text("Escolher um vídeo") }
                    }
                }
            }
        } else if (localVideos.isEmpty()) {
            item {
                Surface(Modifier.fillMaxWidth(), shape=RoundedCornerShape(16.dp), color=Color.White.copy(alpha=.045f)) {
                    Column(Modifier.padding(14.dp)) {
                        Text("Nenhum vídeo encontrado na galeria.", color=Color.White.copy(alpha=.65f), fontSize=10.sp)
                        Spacer(Modifier.height(6.dp))
                        OutlinedButton(onClick = onPickFile) { Text("Escolher arquivo") }
                    }
                }
            }
        } else {
            items(localVideos.chunked(columns)) { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { item -> LocalVideoCard(item, onOpenLocal, Modifier.weight(1f), compact = columns >= 3) }
                    repeat((columns - row.size).coerceAtLeast(0)) { Spacer(Modifier.weight(1f)) }
                }
            }
            item {
                OutlinedButton(onClick = onPickFile, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(6.dp)); Text("Escolher outro vídeo")
                }
            }
        }

    }
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
private fun ContinueWatchingCompactCard(item: SonusCloudRecent, onClick: (SonusCloudRecent) -> Unit, onRemove: (SonusCloudRecent) -> Unit, modifier: Modifier = Modifier) {
    val progress = if (item.durationMs > 0) (item.positionMs.toFloat() / item.durationMs.toFloat()).coerceIn(0f,1f) else 0f
    val remaining = (item.durationMs - item.positionMs).coerceAtLeast(0L)
    Surface(
        modifier = modifier.combinedClickable(onClick = { onClick(item) }, onLongClick = { onRemove(item) }),
        shape = RoundedCornerShape(15.dp),
        color = Color.White.copy(alpha=.055f),
        border = BorderStroke(1.dp, Color.White.copy(alpha=.085f))
    ) {
        Column {
            VideoPreviewImage(item.uri, item.providerId, Modifier.fillMaxWidth().aspectRatio(16f/10f))
            Column(Modifier.padding(horizontal=7.dp, vertical=6.dp), verticalArrangement=Arrangement.spacedBy(4.dp)) {
                Text(item.title, color=Color.White, fontSize=8.6.sp, fontWeight=FontWeight.SemiBold, maxLines=1, overflow=TextOverflow.Ellipsis)
                if (item.durationMs > 0) {
                    LinearProgressIndicator(progress={progress}, modifier=Modifier.fillMaxWidth().height(2.5.dp), color=Color(0xFF5ED7FF), trackColor=Color.White.copy(alpha=.08f))
                    Text("${(progress*100).toInt()}% • ${formatVideoClock(remaining)} restantes", color=Color.White.copy(alpha=.48f), fontSize=7.2.sp, maxLines=1)
                }
            }
        }
    }
}

@Composable
private fun LocalVideoCard(item: LocalVideoItem, onClick: (LocalVideoItem) -> Unit, modifier: Modifier = Modifier, compact: Boolean = false) {
    Surface(
        modifier = modifier.clickable { onClick(item) },
        shape = RoundedCornerShape(16.dp),
        color = Color.White.copy(alpha=.052f),
        border = BorderStroke(1.dp, Color.White.copy(alpha=.075f))
    ) {
        Column {
            VideoPreviewImage(item.uri, "local", Modifier.fillMaxWidth().aspectRatio(if (compact) 16f/10f else 16f/9.4f))
            Row(Modifier.padding(horizontal=8.dp, vertical=7.dp), verticalAlignment=Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(item.title, color=Color.White, fontWeight=FontWeight.SemiBold, fontSize=if(compact)7.8.sp else 8.7.sp, maxLines=1, overflow=TextOverflow.Ellipsis)
                    Text(formatVideoClock(item.durationMs), color=Color.White.copy(alpha=.48f), fontSize=if(compact)6.7.sp else 7.2.sp)
                }
                Icon(Icons.Default.PlayArrow, null, tint=Color(0xFF69D7FF), modifier=Modifier.size(17.dp))
            }
        }
    }
}

@Composable
private fun VideoPreviewImage(uri: String, providerId: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val bitmap by produceState<Bitmap?>(initialValue = null, uri, providerId) {
        value = withContext(Dispatchers.IO) { loadVideoPreviewBitmap(context, uri, providerId) }
    }
    Box(modifier.background(Brush.linearGradient(listOf(Color(0xFF132230), Color(0xFF090D14)))), contentAlignment=Alignment.Center) {
        bitmap?.let { bmp ->
            Image(bmp.asImageBitmap(), null, modifier=Modifier.matchParentSize(), contentScale=ContentScale.Crop)
            Box(Modifier.matchParentSize().background(Color.Black.copy(alpha=.10f)))
        } ?: run {
            val provider = SonusCloudProviders.firstOrNull { it.id == providerId }
            Icon(
                if (providerId == "youtube") Icons.Default.SmartDisplay else provider?.icon ?: Icons.Default.Movie,
                null,
                tint = provider?.accent ?: Color(0xFF69D7FF),
                modifier = Modifier.size(26.dp)
            )
        }
        Surface(shape=RoundedCornerShape(50), color=Color.Black.copy(alpha=.42f)) {
            Icon(Icons.Default.PlayArrow, null, tint=Color.White, modifier=Modifier.padding(4.dp).size(15.dp))
        }
    }
}

@Composable
private fun ContinueWatchingCard(item: SonusCloudRecent, onClick: (SonusCloudRecent) -> Unit, showProgress: Boolean = true, favorite: Boolean = false, onFavorite: (() -> Unit)? = null) {
    val progress = if (item.durationMs > 0) (item.positionMs.toFloat() / item.durationMs.toFloat()).coerceIn(0f, 1f) else 0f
    val provider = SonusCloudProviders.firstOrNull { it.id == item.providerId }
    Surface(modifier = Modifier.fillMaxWidth().clickable { onClick(item) }, shape = RoundedCornerShape(16.dp), color = Color.White.copy(alpha = .055f), border = BorderStroke(1.dp, Color.White.copy(alpha = .08f))) {
        Column(Modifier.padding(11.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(provider?.icon ?: if (item.providerId == "youtube") Icons.Default.SmartDisplay else Icons.Default.Movie, null, tint = provider?.accent ?: Color(0xFF69D7FF))
                Spacer(Modifier.width(9.dp))
                Column(Modifier.weight(1f)) {
                    Text(item.title, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(provider?.name ?: if (item.providerId == "youtube") "YouTube" else "Local", color = Color.White.copy(alpha = .52f), fontSize = 9.sp)
                }
                onFavorite?.let { fav -> IconButton(onClick=fav,modifier=Modifier.size(30.dp)){Icon(if(favorite)Icons.Default.Favorite else Icons.Default.FavoriteBorder,"Favorito",tint=if(favorite)Color(0xFFFF5D7A) else Color.White.copy(alpha=.62f),modifier=Modifier.size(17.dp))} }
                Icon(Icons.Default.PlayArrow, null, tint = Color.White)
            }
            if (showProgress && item.durationMs > 0) {
                LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().height(3.dp), color = Color(0xFF5ED7FF), trackColor = Color.White.copy(alpha = .08f))
            }
        }
    }
}

@Composable
private fun VideoLocalSection(
    localVideos: List<LocalVideoItem>,
    galleryPermissionGranted: Boolean,
    onRequestGalleryPermission: () -> Unit,
    onPick: () -> Unit,
    onOpen: (LocalVideoItem) -> Unit
) {
    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(9.dp),
        contentPadding = PaddingValues(bottom = 28.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Vídeos da galeria", color=Color.White, fontWeight=FontWeight.Black, fontSize=18.sp)
                    Text(if (galleryPermissionGranted) "${localVideos.size} encontrados" else "Acesso à galeria necessário", color=Color.White.copy(alpha=.5f), fontSize=9.sp)
                }
                if (!galleryPermissionGranted) TextButton(onClick=onRequestGalleryPermission) { Text("Permitir") }
            }
        }
        if (galleryPermissionGranted) {
            if (localVideos.isEmpty()) item { Text("Nenhum vídeo encontrado.", color = Color.White.copy(alpha = .60f)) }
            items(localVideos.chunked(2)) { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(9.dp)) {
                    row.forEach { item -> LocalVideoCard(item,onOpen,Modifier.weight(1f)) }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
        item {
            OutlinedButton(onClick = onPick, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(6.dp)); Text("Escolher vídeo")
            }
        }
    }
}


@Composable
private fun SonusExternalVideoLinkPanel(onOpenDirect: (Uri, String) -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("sonus_video_links_v1", Context.MODE_PRIVATE) }
    var link by remember { mutableStateOf("") }
    var browserUrl by remember { mutableStateOf<String?>(null) }
    var status by remember { mutableStateOf("Cole um link direto de vídeo ou uma página da web.") }
    var refresh by remember { mutableIntStateOf(0) }
    val history = remember(refresh) { prefs.getStringSet("history", emptySet()).orEmpty().toList().takeLast(12).reversed() }

    fun saveHistory(url: String) {
        val current = prefs.getStringSet("history", emptySet()).orEmpty().toMutableList()
        current.remove(url); current.add(url)
        while (current.size > 20) current.removeAt(0)
        prefs.edit().putStringSet("history", current.toSet()).apply(); refresh++
    }
    fun open(raw: String) {
        val url = raw.trim()
        val uri = runCatching { Uri.parse(url) }.getOrNull()
        if (uri == null || uri.scheme !in listOf("http", "https")) { status = "Link inválido"; return }
        saveHistory(url)
        val path = uri.path.orEmpty().lowercase()
        val direct = path.endsWith(".mp4") || path.endsWith(".webm") || path.endsWith(".m3u8") || path.endsWith(".m4v") || path.endsWith(".mov")
        if (direct) {
            onOpenDirect(uri, uri.lastPathSegment?.substringBefore('?')?.ifBlank { "Vídeo online" } ?: "Vídeo online")
            status = "Abrindo no SONUS VIDEO…"
        } else {
            browserUrl = url
            status = "Página aberta no navegador interno"
        }
    }

    LazyColumn(Modifier.fillMaxSize().padding(horizontal=14.dp),verticalArrangement=Arrangement.spacedBy(10.dp),contentPadding=PaddingValues(bottom=28.dp)) {
        item {
            Text("Link / Online",color=Color.White,fontWeight=FontWeight.Black,fontSize=20.sp)
            Text("Links diretos usam o SONUS VIDEO. Sites como Dailymotion ou TikTok abrem no navegador interno quando necessário.",color=Color.White.copy(alpha=.55f),fontSize=10.sp)
        }
        item {
            Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                OutlinedTextField(link,{link=it},modifier=Modifier.weight(1f),singleLine=true,label={Text("Cole o link do vídeo")})
                Button(onClick={open(link)}) { Icon(Icons.Default.PlayArrow,null) }
            }
            Text(status,color=Color.White.copy(alpha=.58f),fontSize=9.sp)
        }
        browserUrl?.let { url ->
            item {
                AndroidView(
                    modifier=Modifier.fillMaxWidth().height(360.dp).clip(RoundedCornerShape(14.dp)).background(Color.Black),
                    factory={ctx-> WebView(ctx).apply { settings.javaScriptEnabled=true;settings.domStorageEnabled=true;settings.mediaPlaybackRequiresUserGesture=false;webChromeClient=WebChromeClient();webViewClient=WebViewClient();loadUrl(url) }},
                    update={wv-> if(wv.url!=url)wv.loadUrl(url)}
                )
            }
            item {
                OutlinedButton(onClick={runCatching{context.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(url))) }},modifier=Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.OpenInNew,null);Spacer(Modifier.width(6.dp));Text("Abrir no navegador externo")
                }
            }
        }
        if(history.isNotEmpty()) {
            item { Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text("Links recentes",color=Color.White,fontWeight=FontWeight.Black,modifier=Modifier.weight(1f));TextButton(onClick={prefs.edit().remove("history").apply();refresh++}){Text("Limpar")}} }
            items(history) { recent ->
                Surface(Modifier.fillMaxWidth().clickable{link=recent;open(recent)},shape=RoundedCornerShape(13.dp),color=Color.White.copy(alpha=.05f),border=BorderStroke(1.dp,Color.White.copy(alpha=.07f))) {
                    Row(Modifier.padding(10.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Link,null,tint=Color(0xFF58B8FF));Spacer(Modifier.width(8.dp));Text(recent,color=Color.White.copy(alpha=.80f),fontSize=10.sp,maxLines=1,overflow=TextOverflow.Ellipsis,modifier=Modifier.weight(1f));Icon(Icons.Default.ChevronRight,null,tint=Color.White.copy(alpha=.45f))}
                }
            }
        }
    }
}

@Composable
private fun SonusYouTubeVideoPanel(
    store: SonusCloudMediaStore,
    resumeTarget: SonusCloudRecent? = null,
    onResumeConsumed: () -> Unit = {}
) {
    val context = LocalContext.current
    var link by remember { mutableStateOf("") }
    var currentId by remember { mutableStateOf<String?>(null) }
    var currentTitle by remember { mutableStateOf("YouTube") }
    var currentPos by remember { mutableLongStateOf(0L) }
    var currentDuration by remember { mutableLongStateOf(0L) }
    var webView by remember { mutableStateOf<WebView?>(null) }
    var refresh by remember { mutableIntStateOf(0) }
    val recentYoutube = remember(refresh) { store.recents("video").filter { it.providerId == "youtube" } }

    LaunchedEffect(currentId, webView) {
        while (currentId != null && webView != null) {
            delay(1_500L)
            webView?.evaluateJavascript("(typeof player !== 'undefined' && player.getCurrentTime) ? player.getCurrentTime() : 0") { raw ->
                raw.trim('"').toDoubleOrNull()?.let { sec ->
                    currentPos = (sec * 1000).toLong()
                    val id = currentId ?: return@let
                    store.addRecent(SonusCloudRecent("youtube:$id", "youtube", currentTitle, "video", currentPos, currentDuration))
                    refresh++
                }
            }
            webView?.evaluateJavascript("(typeof player !== 'undefined' && player.getDuration) ? player.getDuration() : 0") { raw ->
                raw.trim('"').toDoubleOrNull()?.let { sec -> currentDuration = (sec * 1000).toLong().coerceAtLeast(0L) }
            }
            webView?.evaluateJavascript("(typeof player !== 'undefined' && player.getVideoData) ? player.getVideoData().title : ''") { raw ->
                val t = raw.trim('"').replace("\\u0026", "&").replace("\\\"", "\"")
                if (t.isNotBlank() && t != "null") currentTitle = t
            }
        }
    }

    fun openYoutube(id: String, startMs: Long = 0L) {
        val sameVideo = currentId == id
        currentId = id
        currentPos = startMs
        if (!sameVideo) currentDuration = 0L
        currentTitle = "YouTube"
        if (sameVideo && webView != null) {
            val sec = (startMs / 1000.0).coerceAtLeast(0.0)
            webView?.evaluateJavascript("if(typeof player !== 'undefined' && player.seekTo){player.seekTo($sec,true);player.playVideo();}", null)
        }
    }

    LaunchedEffect(resumeTarget?.uri, resumeTarget?.positionMs) {
        val item = resumeTarget ?: return@LaunchedEffect
        val id = item.uri.removePrefix("youtube:").takeIf { it.isNotBlank() } ?: return@LaunchedEffect
        openYoutube(id, item.positionMs)
        onResumeConsumed()
    }

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 28.dp)) {
        item {
            Text("YouTube", color = Color.White, fontWeight = FontWeight.Black, fontSize = 20.sp)
            Text("Cole um link. O vídeo usa o player incorporado oficial do YouTube.", color = Color.White.copy(alpha = .55f), fontSize = 10.sp)
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(link, { link = it }, modifier = Modifier.weight(1f), singleLine = true, label = { Text("Link do YouTube") })
                Spacer(Modifier.width(7.dp))
                Button(onClick = { extractYoutubeId(link)?.let { openYoutube(it) } }) { Icon(Icons.Default.PlayArrow, null) }
            }
        }
        currentId?.let { id ->
            item {
                val startSec = (currentPos / 1000L).coerceAtLeast(0L)
                key(id) {
                    AndroidView(
                        modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f).background(Color.Black),
                        factory = { ctx ->
                            WebView(ctx).apply {
                                settings.javaScriptEnabled = true
                                settings.domStorageEnabled = true
                                webChromeClient = WebChromeClient()
                                webViewClient = WebViewClient()
                                webView = this
                                loadDataWithBaseURL(
                                    "https://www.youtube.com",
                                    youtubeHtml(id, startSec),
                                    "text/html",
                                    "UTF-8",
                                    null
                                )
                            }
                        },
                        update = { wv -> webView = wv }
                    )
                }
            }
        }
        currentId?.let { id ->
            item {
                OutlinedButton(
                    onClick = {
                        runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=$id"))) }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.OpenInNew, null); Spacer(Modifier.width(6.dp)); Text("Abrir no YouTube")
                }
            }
        }
        if (recentYoutube.isNotEmpty()) {
            item { Text("Continuar no YouTube", color = Color.White, fontWeight = FontWeight.Black) }
            items(recentYoutube.take(10), key = { it.uri }) { r ->
                ContinueWatchingCard(r, { item ->
                    item.uri.removePrefix("youtube:").takeIf { it.isNotBlank() }?.let { openYoutube(it, item.positionMs) }
                })
            }
        }
    }
}

private fun extractYoutubeId(input: String): String? {
    val raw = input.trim()
    if (raw.matches(Regex("^[A-Za-z0-9_-]{11}$"))) return raw
    return runCatching {
        val uri = Uri.parse(raw)
        when {
            uri.host?.contains("youtu.be") == true -> uri.lastPathSegment
            uri.getQueryParameter("v")?.isNotBlank() == true -> uri.getQueryParameter("v")
            uri.pathSegments.contains("shorts") -> uri.pathSegments.getOrNull(uri.pathSegments.indexOf("shorts") + 1)
            uri.pathSegments.contains("embed") -> uri.pathSegments.getOrNull(uri.pathSegments.indexOf("embed") + 1)
            else -> null
        }
    }.getOrNull()?.takeIf { it.length >= 6 }
}

private fun youtubeHtml(videoId: String, startSec: Long): String = """
<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1,maximum-scale=1'></head>
<body style='margin:0;background:#000;overflow:hidden'><div id='player'></div>
<script src='https://www.youtube.com/iframe_api'></script>
<script>
var player;
function onYouTubeIframeAPIReady(){
 player=new YT.Player('player',{width:'100%',height:'100%',videoId:'$videoId',playerVars:{autoplay:1,playsinline:1,start:$startSec,rel:0,modestbranding:1}});
}
</script></body></html>
""".trimIndent()

private fun prepareSubtitleUri(context: Context, source: Uri, offsetMs: Int): Uri {
    if (offsetMs == 0) return source
    return runCatching {
        val text = context.contentResolver.openInputStream(source)?.bufferedReader()?.use { it.readText() } ?: return source
        val regex = Regex("(\\d{2}):(\\d{2}):(\\d{2})[,.](\\d{3})")
        fun shift(match: MatchResult): String {
            val h = match.groupValues[1].toLong(); val m = match.groupValues[2].toLong(); val s = match.groupValues[3].toLong(); val ms = match.groupValues[4].toLong()
            val total = (h*3600000L + m*60000L + s*1000L + ms + offsetMs).coerceAtLeast(0L)
            val nh=total/3600000L; val nm=(total%3600000L)/60000L; val ns=(total%60000L)/1000L; val nms=total%1000L
            val separator = if (match.value.contains(',')) ',' else '.'
            return "%02d:%02d:%02d%c%03d".format(nh,nm,ns,separator,nms)
        }
        val shifted = regex.replace(text) { shift(it) }
        val ext = if (DocumentFile.fromSingleUri(context, source)?.name.orEmpty().lowercase().endsWith(".vtt")) "vtt" else "srt"
        val file = java.io.File(context.cacheDir, "sonus_subtitle_shifted.$ext")
        file.writeText(shifted)
        Uri.fromFile(file)
    }.getOrDefault(source)
}

private fun readVideoTechnicalInfo(context: Context, uri: Uri): VideoTechnicalInfo {
    var videoCodec = "—"; var audioCodec = "—"; var resolution = "—"; var fps = "—"; var bitrate = "—"; var channels = "—"
    runCatching {
        val extractor = MediaExtractor()
        extractor.setDataSource(context, uri, null)
        repeat(extractor.trackCount) { index ->
            val format = extractor.getTrackFormat(index)
            val mime = format.getString(MediaFormat.KEY_MIME).orEmpty()
            if (mime.startsWith("video/") && videoCodec == "—") {
                videoCodec = mime.removePrefix("video/").uppercase()
                val width = if(format.containsKey(MediaFormat.KEY_WIDTH)) format.getInteger(MediaFormat.KEY_WIDTH) else 0
                val height = if(format.containsKey(MediaFormat.KEY_HEIGHT)) format.getInteger(MediaFormat.KEY_HEIGHT) else 0
                if(width>0 && height>0) resolution = "${width}×${height}"
                if(format.containsKey(MediaFormat.KEY_FRAME_RATE)) fps = "${format.getInteger(MediaFormat.KEY_FRAME_RATE)} fps"
                if(format.containsKey(MediaFormat.KEY_BIT_RATE)) bitrate = "${format.getInteger(MediaFormat.KEY_BIT_RATE)/1000} kbps"
            }
            if (mime.startsWith("audio/") && audioCodec == "—") {
                audioCodec = mime.removePrefix("audio/").uppercase()
                if(format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT).toString()
            }
        }
        extractor.release()
    }
    var duration = "—"
    runCatching {
        val mmr=MediaMetadataRetriever(); mmr.setDataSource(context,uri)
        val ms=mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        if(ms>0) duration=formatVideoClock(ms)
        mmr.release()
    }
    var sizeText = "—"
    runCatching {
        context.contentResolver.query(uri,arrayOf(OpenableColumns.SIZE),null,null,null)?.use { c ->
            if(c.moveToFirst()) { val bytes=c.getLong(0); if(bytes>0) sizeText=if(bytes>=1024L*1024L*1024L) String.format(java.util.Locale.US,"%.2f GB",bytes/(1024.0*1024.0*1024.0)) else String.format(java.util.Locale.US,"%.1f MB",bytes/(1024.0*1024.0)) }
        }
    }
    return VideoTechnicalInfo(resolution,videoCodec,fps,bitrate,audioCodec,channels,duration,sizeText)
}

private fun hasVideoLibraryPermission(context: Context): Boolean {
    return when {
        Build.VERSION.SDK_INT >= 34 -> {
            ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) == PackageManager.PERMISSION_GRANTED
        }
        Build.VERSION.SDK_INT >= 33 -> ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED
        else -> ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
    }
}

private suspend fun queryDeviceVideos(context: Context, settings: SonusVideoSettingsStore): List<LocalVideoItem> = withContext(Dispatchers.IO) {
    val result = mutableListOf<LocalVideoItem>()
    val selectedFolderUris = settings.videoFolders()

    if (!settings.selectedFoldersOnly) {
        val uri = if (Build.VERSION.SDK_INT >= 29) MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL) else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val projection = mutableListOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.DATE_MODIFIED
        ).apply { if (Build.VERSION.SDK_INT >= 29) add(MediaStore.Video.Media.RELATIVE_PATH) }.toTypedArray()
        runCatching {
            context.contentResolver.query(uri, projection, null, null, "${MediaStore.Video.Media.DATE_MODIFIED} DESC")?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val modifiedCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_MODIFIED)
                val pathCol = if (Build.VERSION.SDK_INT >= 29) cursor.getColumnIndex(MediaStore.Video.Media.RELATIVE_PATH) else -1
                while (cursor.moveToNext()) {
                    val rawName = cursor.getString(nameCol).orEmpty()
                    val path = if (pathCol >= 0) cursor.getString(pathCol).orEmpty().lowercase() else ""
                    val nameLower = rawName.lowercase()
                    if (settings.ignoreWhatsApp && (path.contains("whatsapp") || nameLower.contains("whatsapp"))) continue
                    if (settings.ignoreScreenRecordings && (path.contains("screen") || nameLower.contains("screen_record") || nameLower.contains("screenrecord"))) continue
                    val id = cursor.getLong(idCol)
                    val title = rawName.substringBeforeLast('.').takeIf { it.isNotBlank() } ?: "Vídeo"
                    val duration = cursor.getLong(durationCol).coerceAtLeast(0L)
                    val modified = cursor.getLong(modifiedCol).coerceAtLeast(0L)
                    result += LocalVideoItem(ContentUris.withAppendedId(uri, id).toString(), title, duration, modified)
                }
            }
        }
    }

    selectedFolderUris.forEach { raw ->
        val tree = runCatching { Uri.parse(raw) }.getOrNull() ?: return@forEach
        scanCloudTree(context, tree, "video/").forEach { file ->
            if (result.any { it.uri == file.uri }) return@forEach
            var duration = 0L
            runCatching {
                val retriever = MediaMetadataRetriever()
                retriever.setDataSource(context, Uri.parse(file.uri))
                duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                retriever.release()
            }
            result += LocalVideoItem(file.uri, file.title, duration, 0L)
        }
    }
    result.distinctBy { it.uri }
}
private fun loadVideoPreviewBitmap(context: Context, uri: String, providerId: String): Bitmap? {
    return runCatching {
        if (providerId == "youtube" && uri.startsWith("youtube:")) {
            val id = uri.removePrefix("youtube:")
            val connection = (URL("https://img.youtube.com/vi/$id/mqdefault.jpg").openConnection() as HttpURLConnection).apply {
                connectTimeout = 2_500
                readTimeout = 2_500
                instanceFollowRedirects = true
            }
            connection.inputStream.use { BitmapFactory.decodeStream(it) }.also { connection.disconnect() }
        } else {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(context, Uri.parse(uri))
                retriever.getFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
            } finally {
                runCatching { retriever.release() }
            }
        }
    }.getOrNull()?.let { source ->
        if (source.width <= 420) source else {
            val targetW = 420
            val targetH = (source.height.toFloat() / source.width.toFloat() * targetW).toInt().coerceAtLeast(1)
            Bitmap.createScaledBitmap(source, targetW, targetH, true)
        }
    }
}

private fun formatVideoClock(ms: Long): String {
    val total = (ms / 1000L).coerceAtLeast(0L)
    val h = total / 3600L
    val m = (total % 3600L) / 60L
    val s = total % 60L
    return if (h > 0) "%d:%02d:%02d".format(h,m,s) else "%d:%02d".format(m,s)
}

private tailrec fun Context.findActivityForVideo(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivityForVideo()
    else -> null
}
