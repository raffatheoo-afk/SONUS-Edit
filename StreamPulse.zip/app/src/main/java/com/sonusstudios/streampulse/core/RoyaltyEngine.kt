package com.sonusstudios.streampulse.core

import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToLong

object RoyaltyEngine {
    // Não existe uma tarifa universal por stream. O motor trabalha com rendimento
    // efetivo observado por ciclo + histórico do próprio usuário.
    const val MIN_VISIBLE_BRL = 0.02

    // Referência real confirmada pelo usuário para a SoundOn: R$ 329,50 em um ciclo
    // acompanhado com 29.500 streams. Não é uma tarifa oficial por stream: funciona como
    // âncora prática do StreamPulse e é recalibrada pelos pagamentos reais cadastrados.
    const val SOUNDON_REFERENCE_STREAMS = 29_500L
    const val SOUNDON_REFERENCE_PAYMENT_BRL = 329.50
    const val SOUNDON_OBSERVED_BASE_RPM_BRL = SOUNDON_REFERENCE_PAYMENT_BRL / SOUNDON_REFERENCE_STREAMS * 1_000.0

    fun baseRpm(artist: Artist): Double = RoyaltyReferenceCatalog.referenceRpm(artist)

    private fun calibrationBaselineRpm(artist: Artist): Double {
        // A cloud reference is aggregate-only and is used as the initial population prior.
        // Require more than one sample so a single cycle never becomes a "global" truth.
        artist.globalReferenceRpmBrl
            ?.takeIf { artist.globalReferenceSampleCount >= 2 && it > 0.0 }
            ?.let { return it }
        return when (artist.distributor) {
            DistributorId.SOUNDON -> SOUNDON_OBSERVED_BASE_RPM_BRL
            else -> baseRpm(artist)
        }
    }

    /**
     * "Rendimento efetivo" e não tarifa contratual por reprodução.
     *
     * SoundOn: a âncora inicial é o ciclo real de R$329,50 / 29.500 streams. Pagamentos
     * retroativos sem contagem de streams refinam a faixa mensal típica; pagamentos com
     * streams do próprio ciclo continuam tendo prioridade porque são a calibração mais forte.
     */
    fun personalizedRpm(artist: Artist, payments: List<RoyaltyPayment>): Double {
        val validAmounts = payments
            .filter { it.amountBrl > 0.0 }
            .sortedByDescending(::paymentSortKey)
        val direct = validAmounts.filter { it.cycleStreams > 0 }
        val baseline = calibrationBaselineRpm(artist)

        fun rpm(p: RoyaltyPayment) = p.amountBrl / p.cycleStreams.toDouble() * 1_000.0
        fun weightedDirectRpm(): Double? {
            if (direct.isEmpty()) return null
            val values = direct.take(3).map(::rpm)
            val weights = listOf(.50, .30, .20).take(values.size)
            return values.indices.sumOf { values[it] * weights[it] } / weights.sum()
        }

        if (artist.distributor == DistributorId.SOUNDON) {
            val directRpm = weightedDirectRpm()
            val paymentAverage = averagePaymentBrl(validAmounts)
            val amountHistoryRpm = paymentAverage
                ?.let { it / SOUNDON_REFERENCE_STREAMS.toDouble() * 1_000.0 }

            return when {
                directRpm != null && validAmounts.size >= 2 && amountHistoryRpm != null ->
                    directRpm * .70 + amountHistoryRpm * .30
                directRpm != null -> directRpm
                amountHistoryRpm != null -> amountHistoryRpm
                else -> baseline
            }.coerceAtLeast(0.0)
        }

        if (direct.isEmpty()) return baseline
        val latest = rpm(direct.first())
        val longTerm = direct.sumOf { it.amountBrl } / direct.sumOf { it.cycleStreams }.toDouble() * 1_000.0
        val recent = weightedDirectRpm() ?: latest
        return when (direct.size) {
            1 -> latest * .85 + baseline * .15
            2 -> recent * .75 + longTerm * .20 + baseline * .05
            else -> recent * .80 + longTerm * .20
        }.coerceAtLeast(0.0)
    }

    fun averagePaymentBrl(payments: List<RoyaltyPayment>): Double? {
        val values = payments.mapNotNull { it.amountBrl.takeIf { value -> value > 0.0 } }
        return values.takeIf { it.isNotEmpty() }?.average()
    }

    fun calibrationPaymentCount(payments: List<RoyaltyPayment>): Int =
        payments.count { it.amountBrl > 0.0 }

    private fun paymentSortKey(payment: RoyaltyPayment): String =
        payment.referenceMonthIso ?: payment.paidDateIso.take(7)

    fun estimateBrl(streams: Long, rpm: Double): Double {
        if (streams <= 0 || rpm <= 0.0) return 0.0
        val value = streams / 1_000.0 * rpm
        // Desde o primeiro registro o usuário vê uma estimativa. Valores positivos muito
        // pequenos usam R$ 0,02 como piso visual, conforme a regra do SONUS.
        return value.coerceAtLeast(MIN_VISIBLE_BRL)
    }

    fun confidenceLabel(payments: List<RoyaltyPayment>): String = when (calibrationPaymentCount(payments)) {
        0, 1 -> "Baixa"
        in 2..4 -> "Média"
        else -> "Alta"
    }

    fun forecast(
        snapshots: List<StreamSnapshot>,
        dailyRecords: List<DailyStreamRecord>,
        cycleStart: LocalDate,
        cycleEnd: LocalDate,
        referenceDate: LocalDate,
        rpm: Double,
        entryMode: String = "AUTO",
        cycleId: String? = null
    ): ForecastResult {
        val metrics = StreamMetricsEngine.cycleMetrics(
            snapshots = snapshots,
            dailyRecords = dailyRecords,
            cycleStart = cycleStart,
            cycleEnd = cycleEnd,
            referenceDate = referenceDate,
            entryMode = entryMode,
            cycleId = cycleId
        )
        return ForecastResult(
            currentStreams = metrics.currentStreams,
            estimatedCurrentBrl = estimateBrl(metrics.currentStreams, rpm),
            projectedStreams = metrics.projectedStreams,
            projectedBrl = estimateBrl(metrics.projectedStreams, rpm),
            conservativeStreams = metrics.conservativeStreams,
            conservativeBrl = estimateBrl(metrics.conservativeStreams, rpm),
            optimisticStreams = metrics.optimisticStreams,
            optimisticBrl = estimateBrl(metrics.optimisticStreams, rpm),
            cycleDailyAverage = metrics.cycleDailyAverage,
            recentDailyAverage = metrics.recentDailyAverage,
            projectedDailyRate = metrics.projectedDailyRate,
            confidence = metrics.confidence
        )
    }

    fun forecast(snapshots: List<StreamSnapshot>, cycleEnd: LocalDate, rpm: Double): ForecastResult {
        val sorted = latestPerDate(snapshots)
        if (sorted.isEmpty()) {
            return ForecastResult(0, 0.0, 0, 0.0, 0, 0.0, 0, 0.0, 0.0, 0.0, 0.0, "Baixa")
        }

        val last = sorted.last()
        val lastDate = LocalDate.parse(last.dateIso)
        val allRates = sorted.zipWithNext().mapNotNull { (a, b) ->
            val aDate = LocalDate.parse(a.dateIso)
            val bDate = LocalDate.parse(b.dateIso)
            val days = ChronoUnit.DAYS.between(aDate, bDate)
            val delta = b.cumulativeStreams - a.cumulativeStreams
            if (days > 0 && delta >= 0) delta.toDouble() / days else null
        }
        val cycleAvg = allRates.takeIf { it.isNotEmpty() }?.average() ?: 0.0
        val recentRates = allRates.takeLast(7)
        val recentAvg = recentRates.takeIf { it.isNotEmpty() }?.let {
            // Recência progressiva: os dias mais novos pesam mais.
            val weights = it.indices.map { index -> (index + 1).toDouble() }
            it.indices.sumOf { index -> it[index] * weights[index] } / weights.sum()
        } ?: cycleAvg
        val projectedRate = recentAvg.coerceAtLeast(0.0)
        val remainingDays = max(0L, ChronoUnit.DAYS.between(lastDate, cycleEnd))
        val projectedStreams = max(last.cumulativeStreams, (last.cumulativeStreams + projectedRate * remainingDays).roundToLong())

        val variability = if (recentRates.size >= 2) {
            val mean = recentRates.average()
            val averageDeviation = recentRates.sumOf { abs(it - mean) } / recentRates.size
            (averageDeviation / max(1.0, mean)).coerceIn(0.05, 0.30)
        } else 0.15

        val conservativeStreams = max(last.cumulativeStreams, (last.cumulativeStreams + projectedRate * (1.0 - variability) * remainingDays).roundToLong())
        val optimisticStreams = max(projectedStreams, (last.cumulativeStreams + projectedRate * (1.0 + variability) * remainingDays).roundToLong())
        val confidence = when {
            sorted.size >= 8 && recentRates.size >= 4 -> "Alta"
            sorted.size >= 3 -> "Média"
            else -> "Baixa"
        }

        return ForecastResult(
            currentStreams = last.cumulativeStreams,
            estimatedCurrentBrl = estimateBrl(last.cumulativeStreams, rpm),
            projectedStreams = projectedStreams,
            projectedBrl = estimateBrl(projectedStreams, rpm),
            conservativeStreams = conservativeStreams,
            conservativeBrl = estimateBrl(conservativeStreams, rpm),
            optimisticStreams = optimisticStreams,
            optimisticBrl = estimateBrl(optimisticStreams, rpm),
            cycleDailyAverage = cycleAvg,
            recentDailyAverage = recentAvg,
            projectedDailyRate = projectedRate,
            confidence = confidence
        )
    }

    private fun latestPerDate(snapshots: List<StreamSnapshot>): List<StreamSnapshot> {
        val ordered = snapshots.sortedWith(compareBy<StreamSnapshot> { it.dateIso }.thenBy { it.recordedAtEpochMillis })
        val map = linkedMapOf<String, StreamSnapshot>()
        ordered.forEach { map[it.dateIso] = it }
        return map.values.sortedBy { it.dateIso }
    }

    fun accuracy(payments: List<RoyaltyPayment>): AccuracyResult {
        val usable = payments.mapNotNull { payment ->
            val estimate = payment.estimatedBrlBeforeCalibration
            if (estimate != null && estimate > 0.0 && payment.amountBrl > 0.0) {
                abs(payment.amountBrl - estimate) / payment.amountBrl * 100.0
            } else null
        }
        if (usable.isEmpty()) return AccuracyResult(0, null, null, "Inicial")
        val error = usable.average()
        val accuracy = (100.0 - error).coerceIn(0.0, 100.0)
        val label = when {
            usable.size >= 6 && accuracy >= 90.0 -> "Personalizada"
            usable.size >= 3 -> "Calibrada"
            else -> "Aprendendo"
        }
        return AccuracyResult(usable.size, error, accuracy, label)
    }
}
