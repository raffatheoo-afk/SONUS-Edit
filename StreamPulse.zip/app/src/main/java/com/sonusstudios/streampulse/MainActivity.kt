package com.sonusstudios.streampulse

import com.sonusstudios.streampulse.core.SonusAutoCreateDocument
import android.Manifest

import android.os.Bundle
import android.os.Build
import android.graphics.BitmapFactory
import android.net.Uri
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.TrafficStats
import android.media.MediaCodecList
import android.content.Intent
import android.content.Context
import android.content.ContextWrapper
import android.content.ClipData
import android.content.ClipboardManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.BackHandler
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonusstudios.streampulse.core.*
import com.sonusstudios.streampulse.audio.AudioConversionEngine
import com.sonusstudios.streampulse.audio.AudioConverterProScreen
import com.sonusstudios.streampulse.auth.AuthManager
import com.sonusstudios.streampulse.auth.AuthUser
import com.sonusstudios.streampulse.auth.AccountRole
import com.sonusstudios.streampulse.auth.StreamPulseAuthScreen
import com.sonusstudios.streampulse.ads.StreamPulseAdManager
import com.sonusstudios.streampulse.cloud.CloudAccountManager
import com.sonusstudios.streampulse.cloud.CloudBackupSettings
import com.sonusstudios.streampulse.cloud.DistributionTrialState
import com.sonusstudios.streampulse.cloud.CloudCouponSettings
import com.sonusstudios.streampulse.cloud.AccountSecuritySettings
import com.sonusstudios.streampulse.cloud.DeveloperRemotePanel
import com.sonusstudios.streampulse.cloud.DeveloperRemoteSection
import com.sonusstudios.streampulse.cloud.AnalyticsEvent
import com.sonusstudios.streampulse.cloud.SonusUpdateManager
import com.sonusstudios.streampulse.cloud.SonusUpdateDecision
import com.sonusstudios.streampulse.cloud.SonusUpdateInfo
import com.sonusstudios.streampulse.cloud.SonusUpdateDialog
import com.sonusstudios.streampulse.cloud.SonusOwnerUpdatePanel
import com.sonusstudios.streampulse.cloud.SONUS_CURRENT_VERSION_SUMMARY
import com.sonusstudios.streampulse.tools.ToolSuiteScreen
import com.sonusstudios.streampulse.tools.ToolHubVariant
import com.sonusstudios.streampulse.tools.ToolId
import com.sonusstudios.streampulse.tools.PulsePlayerScreen
import com.sonusstudios.streampulse.tools.PulsePlayerService
import com.sonusstudios.streampulse.tools.PulsePlayerStatsStore
import com.sonusstudios.streampulse.tools.SonusProUsageStats
import com.sonusstudios.streampulse.tools.PulseCreatorAction
import com.sonusstudios.streampulse.tools.SonusVideoPlayerScreen
import com.sonusstudios.streampulse.tools.SonusBlackBoxScreen
import com.sonusstudios.streampulse.tools.SonusMusicDeveloperPanel
import com.sonusstudios.streampulse.tools.SonusOnlineMusicRepository
import com.sonusstudios.streampulse.tools.SonusUnifiedLrcEntry
import com.sonusstudios.streampulse.insights.LivePulseCard
import com.sonusstudios.streampulse.insights.WhatChangedCard
import com.sonusstudios.streampulse.insights.HistoryRecordHighlights
import com.sonusstudios.streampulse.insights.DistributorIntelligenceSection
import com.sonusstudios.streampulse.insights.FinanceReconciliationInsights
import com.sonusstudios.streampulse.audio.AudioSourceInfo
import com.sonusstudios.streampulse.audio.AudioTrackTags
import com.sonusstudios.streampulse.data.AppRepository
import com.sonusstudios.streampulse.data.BackupManager
import com.sonusstudios.streampulse.data.BackupPreview
import com.sonusstudios.streampulse.export.ReportPdfManager
import com.sonusstudios.streampulse.export.ReportPeriod
import com.sonusstudios.streampulse.online.CommunityPresenceState
import com.sonusstudios.streampulse.online.PresenceManager
import com.sonusstudios.streampulse.notifications.SonusNotificationCenter
import com.sonusstudios.streampulse.notifications.SonusNotificationItem
import com.sonusstudios.streampulse.notifications.SonusRemoteNotificationBridge
import com.sonusstudios.streampulse.notifications.PremiumUsageEvent
import com.sonusstudios.streampulse.navigation.SonusMainTab
import com.sonusstudios.streampulse.navigation.SonusMainTabConfig
import com.sonusstudios.streampulse.navigation.SonusMainTabPreferences
import com.sonusstudios.streampulse.navigation.SonusMainTabsOrganizerScreen
import com.sonusstudios.streampulse.support.SonusSupportScreen
import com.sonusstudios.streampulse.support.sonusPublicId
import com.sonusstudios.streampulse.stream.SonusStreamCreatorCenter
import com.sonusstudios.streampulse.stream.StreamCenterMode
import com.sonusstudios.streampulse.stream.SonusStreamPlatformRepository
import com.sonusstudios.streampulse.ui.theme.*
import com.sonusstudios.streampulse.ui.avatar.SonusAvatarArtwork
import com.sonusstudios.streampulse.ui.avatar.SonusAvatarCatalog
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import java.text.NumberFormat
import java.io.File
import java.net.URL
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import java.util.UUID
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.roundToLong
import kotlin.math.sin
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

private object AppSessionClock {
    var startedAtMillis: Long = 0L
}

class MainActivity : ComponentActivity() {
    private lateinit var presenceManager: PresenceManager
    private lateinit var repository: AppRepository
    private lateinit var authManager: AuthManager
    private lateinit var cloudManager: CloudAccountManager
    private lateinit var adManager: StreamPulseAdManager
    private var sessionStartedAtMillis: Long = 0L
    private var sessionRxStart: Long = 0L
    private var sessionTxStart: Long = 0L
    private val notificationRouteState = mutableStateOf<String?>(null)
    private val externalAudioUriState = mutableStateOf<String?>(null)
    private val externalVideoUriState = mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        authManager = AuthManager(applicationContext)
        presenceManager = PresenceManager(applicationContext)
        repository = AppRepository(applicationContext)
        cloudManager = CloudAccountManager()
        adManager = StreamPulseAdManager(applicationContext)
        notificationRouteState.value = intent?.getStringExtra("sonus_notification_route")
        externalAudioUriState.value = intent?.takeIf { it.action == Intent.ACTION_VIEW && it.type?.startsWith("audio/") == true }?.data?.toString()
        externalVideoUriState.value = intent?.getStringExtra("sonus_external_video_uri")
            ?: intent?.takeIf { it.action == Intent.ACTION_VIEW && (it.type?.startsWith("video/") == true || it.type == "application/x-matroska") }?.data?.toString()
        setContent {
            StreamPulseRoot(
                presenceManager, repository, authManager, cloudManager, adManager,
                notificationRoute = notificationRouteState.value,
                onNotificationRouteConsumed = { notificationRouteState.value = null },
                externalAudioUri = externalAudioUriState.value,
                onExternalAudioConsumed = { externalAudioUriState.value = null },
                externalVideoUri = externalVideoUriState.value,
                onExternalVideoConsumed = { externalVideoUriState.value = null }
            )
        }
        // Não segura o primeiro frame/splash esperando UMP/AdMob. A monetização inicia
        // depois que a interface já teve tempo de aparecer.
        lifecycleScope.launch {
            delay(3_000L)
            if (!isFinishing && !isDestroyed) adManager.initialize(this@MainActivity)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        notificationRouteState.value = intent.getStringExtra("sonus_notification_route")
        if (intent.action == Intent.ACTION_VIEW && intent.type?.startsWith("audio/") == true) externalAudioUriState.value = intent.data?.toString()
        val routedVideo = intent.getStringExtra("sonus_external_video_uri")
            ?: intent.takeIf { it.action == Intent.ACTION_VIEW && (it.type?.startsWith("video/") == true || it.type == "application/x-matroska") }?.data?.toString()
        if (routedVideo != null) externalVideoUriState.value = routedVideo
    }

    override fun onStart() {
        super.onStart()
        sessionStartedAtMillis = System.currentTimeMillis()
        sessionRxStart = TrafficStats.getUidRxBytes(android.os.Process.myUid()).coerceAtLeast(0L)
        sessionTxStart = TrafficStats.getUidTxBytes(android.os.Process.myUid()).coerceAtLeast(0L)
        AppSessionClock.startedAtMillis = sessionStartedAtMillis
        presenceManager.setAppActive(true)
        lifecycleScope.launch {
            // Deixa o primeiro frame e a autenticação terminarem antes de gravar telemetria local.
            delay(2_000L)
            repository.recordAppOpen(LocalDate.now().toString(), Instant.now().toString())
            // Pull only aggregate/anonymized financial calibration. Failure is non-blocking;
            // the built-in historical reference remains the immediate fallback.
            runCatching { repository.refreshGlobalFinancialLearning() }
        }
    }

    override fun onStop() {
        val now = System.currentTimeMillis()
        val duration = (now - sessionStartedAtMillis).coerceAtLeast(0L)
        presenceManager.setAppActive(false)
        AppSessionClock.startedAtMillis = 0L
        val rxNow = TrafficStats.getUidRxBytes(android.os.Process.myUid()).coerceAtLeast(sessionRxStart)
        val txNow = TrafficStats.getUidTxBytes(android.os.Process.myUid()).coerceAtLeast(sessionTxStart)
        lifecycleScope.launch {
            val day = LocalDate.now().toString()
            repository.recordAppUsage(duration, day, Instant.now().toString())
            repository.recordDataUsage((rxNow-sessionRxStart).coerceAtLeast(0L), (txNow-sessionTxStart).coerceAtLeast(0L), day)
        }
        super.onStop()
    }
}

private enum class AppPage {
    PLAYER,
    HIGHLIGHTS,
    TOOLS,
    STREAM,
    DISTRIBUTION,
    BLACK_BOX,
    SETTINGS,
    DEVELOPER,
    PREMIUM,
    SUPPORT,
    STREAM_CREATOR,
    TAB_ORGANIZER,
    NOTIFICATIONS,
    NOTIFICATION_SETTINGS,
    UPDATE,
    PAYMENT,
    ADD_ARTIST,
    EDIT_ARTIST,
    DISTRIBUTORS,
    USAGE,
    AUDIO_CONVERTER,
    GUIDE
}

private fun activityPageTitle(page: AppPage): String = when (page) {
    AppPage.PLAYER -> "Abriu SONUS PLAYER"
    AppPage.HIGHLIGHTS -> "Abriu DESTAQUES SONUS"
    AppPage.DISTRIBUTION -> "Abriu Ganhos e Distribuição"
    AppPage.BLACK_BOX -> "Abriu Caixa Preta SONUS"
    AppPage.TOOLS -> "Abriu SONUS VIDEO"
    AppPage.STREAM -> "Abriu SONUS Stream"
    AppPage.SUPPORT -> "Abriu Suporte SONUS"
    AppPage.STREAM_CREATOR -> "Abriu Para artistas do SONUS Stream"
    AppPage.TAB_ORGANIZER -> "Abriu organização das abas"
    AppPage.SETTINGS -> "Abriu Ajustes"
    AppPage.DEVELOPER -> "Abriu o Painel do Desenvolvedor"
    AppPage.PREMIUM -> "Abriu SONUS Premium"
    AppPage.NOTIFICATIONS -> "Abriu Central de Notificações"
    AppPage.NOTIFICATION_SETTINGS -> "Abriu Ajustes de notificações"
    AppPage.UPDATE -> "Abriu Atualizar streams"
    AppPage.PAYMENT -> "Abriu Registrar pagamento"
    AppPage.ADD_ARTIST -> "Abriu Adicionar artista"
    AppPage.EDIT_ARTIST -> "Abriu Editar artista"
    AppPage.DISTRIBUTORS -> "Abriu Central das distribuidoras"
    AppPage.USAGE -> "Abriu Uso do SONUS"
    AppPage.AUDIO_CONVERTER -> "Abriu Conversor de áudio"
    AppPage.GUIDE -> "Abriu Guia do SONUS"
}

private enum class OwnerTestMode {
    OWNER,
    FREE,
    PRATA,
    OURO,
    DIAMANTE
}


private enum class GuestAuthTarget {
    ACCOUNT,
    PREMIUM,
    ADD_ARTIST,
    DISTRIBUTORS
}

@Composable
private fun StreamPulseRoot(
    presenceManager: PresenceManager,
    repository: AppRepository,
    authManager: AuthManager,
    cloudManager: CloudAccountManager,
    adManager: StreamPulseAdManager,
    notificationRoute: String? = null,
    onNotificationRouteConsumed: () -> Unit = {},
    externalAudioUri: String? = null,
    onExternalAudioConsumed: () -> Unit = {},
    externalVideoUri: String? = null,
    onExternalVideoConsumed: () -> Unit = {}
) {
    // Não bloqueia a abertura esperando desserialização completa do DataStore.
    // A UI nasce com um estado seguro e recebe o estado real assim que estiver pronto.
    val state by produceState(initialValue = AppState(), repository) {
        repository.state.collect { value = it }
    }
    val appState = state
    val context = LocalContext.current
    val communityPresence by presenceManager.state.collectAsState()
    val authState by authManager.state.collectAsState()
    val guestPrefs = remember(context) { context.getSharedPreferences("sonus_guest_session_v1", Context.MODE_PRIVATE) }
    var guestMode by rememberSaveable { mutableStateOf(guestPrefs.getBoolean("guest_mode", false)) }
    var pendingGuestTargetName by rememberSaveable { mutableStateOf<String?>(null) }
    var pendingPremiumTierName by rememberSaveable { mutableStateOf<String?>(null) }
    var pendingPremiumPeriod by rememberSaveable { mutableStateOf<String?>(null) }
    var splashFinished by remember { mutableStateOf(false) }
    var cloudReadyUid by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        // Se autoplay estiver desligado, a entrada do app cancela qualquer pedido
        // residual de reprodução antes da splash.
        val autoPlay = context.getSharedPreferences("pulse_player_library_v1", Context.MODE_PRIVATE)
            .getBoolean("autoplay", false)
        if (!autoPlay && PulsePlayerService.isRunning) {
            runCatching {
                context.startService(
                    Intent(context, PulsePlayerService::class.java).setAction(PulsePlayerService.ACTION_PAUSE)
                )
            }
        }
        // Mantém a splash visível até a troca real de conteúdo; evita o quadro preto entre animação e app.
        delay(2425)
        splashFinished = true
    }

    LaunchedEffect(authState.user?.uid) {
        if (authState.user != null) {
            guestMode = false
            guestPrefs.edit().putBoolean("guest_mode", false).apply()
        }
    }

    StreamPulseTheme(
        themeMode = appState.preferences.themeMode,
        appFont = appState.preferences.appFont,
        textAppearance = appState.preferences.textAppearance
    ) {
        if (!splashFinished || !authState.ready) {
            StreamPulseSplashScreen()
        } else {
            val signedUser = authState.user
            if (signedUser == null && !guestMode) {
                StreamPulseAuthScreen(
                    authManager = authManager,
                    onContinueAsGuest = {
                        pendingGuestTargetName = null
                        pendingPremiumTierName = null
                        pendingPremiumPeriod = null
                        guestMode = true
                        guestPrefs.edit().putBoolean("guest_mode", true).apply()
                    },
                    showGuestOption = pendingGuestTargetName == null
                )
            } else {
                val isGuest = signedUser == null
                val user = signedUser ?: AuthUser(
                    uid = "guest-local",
                    displayName = "Convidado",
                    email = null,
                    photoUrl = null,
                    role = AccountRole.USER
                )

                if (!isGuest) {
                    val remoteNotificationBridge = remember(user.uid) { SonusRemoteNotificationBridge(context) }
                    DisposableEffect(user.uid) {
                        remoteNotificationBridge.attach(user.uid)
                        onDispose { remoteNotificationBridge.detach() }
                    }
                    LaunchedEffect(user.uid) {
                        try {
                            withContext(Dispatchers.IO) {
                                runCatching { cloudManager.ensureAccount(user.uid, user.displayName, user.email) }
                            }
                            if (!appState.onboardingComplete) {
                                val remote = withContext(Dispatchers.IO) { cloudManager.downloadBackup(user.uid).getOrNull() }
                                if (remote != null) {
                                    try { repository.replaceState(remote.first) } catch (_: Throwable) { }
                                }
                                try { repository.markAppSetupComplete() } catch (_: Throwable) { }
                            }
                            val remotePromotions = withContext(Dispatchers.IO) { cloudManager.loadRemotePromotions(user.uid).getOrNull() }
                            if (remotePromotions != null) {
                                try {
                                    repository.syncRemotePromotions(
                                        tierName = remotePromotions.tierName,
                                        premiumUntil = remotePromotions.premiumUntil,
                                        adFreeUntil = remotePromotions.adFreeUntil,
                                        adMultiplier = remotePromotions.adMultiplier,
                                        adMultiplierUntil = remotePromotions.adMultiplierUntil,
                                        discountPercent = remotePromotions.discountPercent,
                                        discountTierName = remotePromotions.discountTierName,
                                        discountUntil = remotePromotions.discountUntil
                                    )
                                } catch (_: Throwable) { }
                            }
                        } finally {
                            cloudReadyUid = user.uid
                        }
                    }
                    val promoTier = effectivePromotionalTier(appState.preferences)
                    val walletTier = if (user.role == AccountRole.OWNER) MembershipTier.DIAMANTE else promoTier
                    LaunchedEffect(user.uid, appState, cloudReadyUid) {
                        if (cloudReadyUid == user.uid) {
                            delay(1400)
                            withContext(Dispatchers.IO) { cloudManager.uploadBackup(user.uid, appState) }
                        }
                    }
                }

                val pendingTarget = pendingGuestTargetName?.let { runCatching { GuestAuthTarget.valueOf(it) }.getOrNull() }
                val initialPage = when (pendingTarget) {
                    GuestAuthTarget.ACCOUNT -> AppPage.SETTINGS
                    GuestAuthTarget.PREMIUM -> AppPage.PREMIUM
                    GuestAuthTarget.ADD_ARTIST -> AppPage.ADD_ARTIST
                    GuestAuthTarget.DISTRIBUTORS -> AppPage.DISTRIBUTORS
                    null -> AppPage.PLAYER
                }

                StreamPulseBackground(
                    themeMode = appState.preferences.themeMode,
                    backgroundPhotoPath = appState.preferences.backgroundPhotoPath
                ) {
                    StreamPulseApp(
                        repository = repository,
                        state = appState,
                        communityPresence = communityPresence,
                        authUser = user,
                        authManager = authManager,
                        cloudManager = cloudManager,
                        adManager = adManager,
                        isGuest = isGuest,
                        initialPage = initialPage,
                        notificationRoute = notificationRoute,
                        onNotificationRouteConsumed = onNotificationRouteConsumed,
                        externalAudioUri = externalAudioUri,
                        onExternalAudioConsumed = onExternalAudioConsumed,
                        externalVideoUri = externalVideoUri,
                        onExternalVideoConsumed = onExternalVideoConsumed,
                        resumePremiumTier = pendingPremiumTierName?.let { runCatching { MembershipTier.valueOf(it) }.getOrNull() },
                        resumePremiumPeriod = pendingPremiumPeriod,
                        onGuestAuthRequired = { target ->
                            pendingGuestTargetName = target.name
                            pendingPremiumTierName = null
                            pendingPremiumPeriod = null
                            guestMode = false
                            guestPrefs.edit().putBoolean("guest_mode", false).apply()
                        },
                        onGuestPremiumPurchase = { tier, period ->
                            pendingGuestTargetName = GuestAuthTarget.PREMIUM.name
                            pendingPremiumTierName = tier.name
                            pendingPremiumPeriod = period
                            guestMode = false
                            guestPrefs.edit().putBoolean("guest_mode", false).apply()
                        }
                    )
                }

                if (!isGuest && pendingGuestTargetName != null) {
                    LaunchedEffect(user.uid, pendingGuestTargetName) {
                        // O destino já foi entregue ao StreamPulseApp acima. Limpa somente
                        // depois da primeira composição para não perder o retorno pós-login.
                        delay(120)
                        pendingGuestTargetName = null
                        pendingPremiumTierName = null
                        pendingPremiumPeriod = null
                    }
                }
            }
        }
    }
}

@Composable
private fun StreamPulseApp(
    repository: AppRepository,
    state: AppState,
    communityPresence: CommunityPresenceState,
    authUser: AuthUser,
    authManager: AuthManager,
    cloudManager: CloudAccountManager,
    adManager: StreamPulseAdManager,
    isGuest: Boolean = false,
    initialPage: AppPage = AppPage.PLAYER,
    notificationRoute: String? = null,
    onNotificationRouteConsumed: () -> Unit = {},
    externalAudioUri: String? = null,
    onExternalAudioConsumed: () -> Unit = {},
    externalVideoUri: String? = null,
    onExternalVideoConsumed: () -> Unit = {},
    resumePremiumTier: MembershipTier? = null,
    resumePremiumPeriod: String? = null,
    onGuestAuthRequired: (GuestAuthTarget) -> Unit = {},
    onGuestPremiumPurchase: (MembershipTier, String) -> Unit = { _, _ -> }
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val online = rememberNetworkAvailable()
    var busyMessage by remember { mutableStateOf<String?>(null) }

    // code122: atualização integrada. A consulta automática é silenciosa e usa cache local;
    // somente uma versão realmente superior e publicada abre o diálogo.
    val updateManager = remember(context) { SonusUpdateManager(context) }
    var offeredUpdate by remember { mutableStateOf<SonusUpdateInfo?>(null) }
    var checkingUpdate by remember { mutableStateOf(false) }

    fun checkSonusUpdate(force: Boolean, showFeedback: Boolean) {
        if (checkingUpdate) return
        checkingUpdate = true
        scope.launch {
            val result = updateManager.checkForUpdate(force)
            checkingUpdate = false
            result.onSuccess { decision ->
                when (decision) {
                    is SonusUpdateDecision.Available -> offeredUpdate = decision.info
                    SonusUpdateDecision.UpToDate -> if (showFeedback) Toast.makeText(context, "Seu SONUS está atualizado.", Toast.LENGTH_SHORT).show()
                    SonusUpdateDecision.Deferred -> if (showFeedback) Toast.makeText(context, "Atualização já verificada. Você adiou esta versão recentemente.", Toast.LENGTH_SHORT).show()
                    SonusUpdateDecision.SkippedByCache -> if (showFeedback) Toast.makeText(context, "Verificação recente em cache. Use novamente para forçar a consulta.", Toast.LENGTH_SHORT).show()
                }
            }.onFailure { error ->
                if (showFeedback) Toast.makeText(context, error.message ?: "Não foi possível checar atualizações agora.", Toast.LENGTH_LONG).show()
            }
        }
    }

    LaunchedEffect(Unit) {
        delay(900)
        checkSonusUpdate(force = false, showFeedback = false)
    }

    DisposableEffect(authUser.uid, context) {
        val activity = context.findComponentActivityForApp()
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME && !isGuest) {
                scope.launch(Dispatchers.IO) { cloudManager.touchActivity(authUser.uid) }
            }
        }
        activity?.lifecycle?.addObserver(observer)
        onDispose { activity?.lifecycle?.removeObserver(observer) }
    }

    // O SONUS é uma suíte de criação: o usuário pode usar Player e Ferramentas
    // sem cadastrar distribuidora. A área Ganhos pede um perfil apenas quando necessária.
    val hasDistributionProfile = !isGuest && state.artists.isNotEmpty()
    val creatorFallbackArtist = remember(state.preferences.creatorAudioPreset) {
        Artist(
            id = "pulse-studio-local",
            name = "Criador",
            distributor = DistributorId.OTHER,
            customDistributorName = "Sem distribuidora",
            createdAtIso = LocalDate.now().toString(),
            audioPreset = state.preferences.creatorAudioPreset
        )
    }

    var page by rememberSaveable(authUser.uid) { mutableStateOf(initialPage) }
    LaunchedEffect(externalVideoUri) {
        if (externalVideoUri != null) page = AppPage.TOOLS
    }
    var videoFullscreen by rememberSaveable { mutableStateOf(false) }
    var planDialogMinTier by remember { mutableStateOf<MembershipTier?>(null) }
    var selectedPlanFromGate by remember { mutableStateOf<MembershipTier?>(null) }
    val mainTabsPrefs = remember(context) { SonusMainTabPreferences(context) }
    var mainTabsConfig by remember { mutableStateOf(mainTabsPrefs.load()) }
    var editingArtistId by rememberSaveable { mutableStateOf<String?>(null) }
    var requestedToolName by rememberSaveable { mutableStateOf<String?>(null) }
    var requestedDeveloperModule by rememberSaveable { mutableStateOf<String?>(null) }
    var pendingOwnerLrc by rememberSaveable { mutableStateOf<String?>(null) }
    val roleCache = remember { context.getSharedPreferences("sonus_authority_cache_v1", Context.MODE_PRIVATE) }
    LaunchedEffect(authUser.uid, authUser.role, online) {
        if (!isGuest && online && authUser.uid.isNotBlank()) roleCache.edit().putString("uid", authUser.uid).putString("role", authUser.role.name).apply()
    }
    val cachedOwner = !online && roleCache.getString("uid", null) == authUser.uid && roleCache.getString("role", null) == AccountRole.OWNER.name
    val isOwner = authUser.role == AccountRole.OWNER || cachedOwner
    val isSupport = authUser.role == AccountRole.SUPPORT
    val ownerTestPrefs = remember(authUser.uid) { context.getSharedPreferences("sonus_owner_test_mode_v2", Context.MODE_PRIVATE) }
    var ownerTestModeName by remember(authUser.uid) {
        mutableStateOf(ownerTestPrefs.getString("mode_${authUser.uid}", OwnerTestMode.OWNER.name) ?: OwnerTestMode.OWNER.name)
    }
    val ownerTestMode = if (isOwner) runCatching { OwnerTestMode.valueOf(ownerTestModeName) }.getOrDefault(OwnerTestMode.OWNER) else OwnerTestMode.FREE
    val membershipTier = if (isGuest) MembershipTier.FREE else if (isOwner) {
        when (ownerTestMode) {
            OwnerTestMode.OWNER -> MembershipTier.DIAMANTE
            OwnerTestMode.FREE -> MembershipTier.FREE
            OwnerTestMode.PRATA -> MembershipTier.PRATA
            OwnerTestMode.OURO -> MembershipTier.OURO
            OwnerTestMode.DIAMANTE -> MembershipTier.DIAMANTE
        }
    } else effectivePromotionalTier(state.preferences)
    val ownerUnlimited = isOwner && ownerTestMode == OwnerTestMode.OWNER
    var distributionTrialState by remember(authUser.uid) { mutableStateOf<DistributionTrialState?>(null) }
    var distributionTrialChecking by remember(authUser.uid) { mutableStateOf(false) }
    LaunchedEffect(page, authUser.uid, membershipTier, isOwner, isGuest) {
        if (page == AppPage.DISTRIBUTION && membershipTier == MembershipTier.FREE && !isOwner && !isGuest && !distributionTrialChecking) {
            distributionTrialChecking = true
            busyMessage = "Validando seu teste de 7 dias..."
            val trial = withContext(Dispatchers.IO) { cloudManager.activateDistributionTrial().getOrNull() }
            distributionTrialState = trial
            context.getSharedPreferences("sonus_distribution_trial_cache_v1", Context.MODE_PRIVATE).edit()
                .putBoolean("active", trial?.active == true)
                .putLong("expires_at", trial?.expiresAt ?: 0L)
                .apply()
            busyMessage = null
            distributionTrialChecking = false
            if (trial?.active == true) {
                val days = kotlin.math.ceil((trial.expiresAt - System.currentTimeMillis()).coerceAtLeast(0L) / 86_400_000.0).toInt().coerceAtLeast(1)
                SonusNotificationCenter.add(context, "Teste Premium ativo", "Distribuição & Pagamentos está liberado por mais $days dia(s).", "PREMIUM", "DISTRIBUTION", false)
            } else {
                Toast.makeText(context, "Seu teste de 7 dias terminou. Escolha um plano para continuar em Distribuição & Pagamentos.", Toast.LENGTH_LONG).show()
                page = AppPage.PREMIUM
                planDialogMinTier = MembershipTier.PRATA
            }
        }
    }
    val pulseCoins = state.preferences.pulseMonthlyCoins + state.preferences.pulseBonusCoins
    val notificationItems by SonusNotificationCenter.items.collectAsState()
    val premiumUsageEvents by SonusNotificationCenter.usageEvents.collectAsState()
    val unreadNotifications = notificationItems.count { !it.read }
    LaunchedEffect(authUser.uid, membershipTier, state.preferences.pulseCoinsPeriod, state.preferences.pulseUsageTierName) {
        repository.ensurePulseWallet(
            uid = authUser.uid,
            monthlyAllowance = pulseMonthlyCoinAllowance(membershipTier),
            tierName = membershipTier.name
        )
    }
    val adFree = ownerUnlimited || membershipTier != MembershipTier.FREE ||
        ((state.preferences.adFreeUntilEpochMillis ?: 0L) > System.currentTimeMillis())

    val watchFreeUseRewarded: () -> Unit = {
        val commercial = commercialTier(membershipTier)
        val paidEligible = commercial == MembershipTier.PRATA || commercial == MembershipTier.OURO
        val quotaExhausted = state.preferences.pulseMonthlyCoins <= 0
        when {
            ownerUnlimited || commercial == MembershipTier.DIAMANTE ->
                Toast.makeText(context, "Seu plano já possui ferramentas ilimitadas.", Toast.LENGTH_SHORT).show()
            paidEligible && !quotaExhausted ->
                Toast.makeText(context, "Use primeiro suas Moedas SONUS mensais. Anúncios extras ficam disponíveis quando a cota acabar.", Toast.LENGTH_LONG).show()
            state.preferences.pulseBonusCoins >= 10 ->
                Toast.makeText(context, "Limite mensal de +10 Moedas SONUS por anúncios atingido.", Toast.LENGTH_SHORT).show()
            else -> {
                val activity = context.findComponentActivityForApp()
                if (activity == null) {
                    Toast.makeText(context, "Não foi possível abrir o anúncio agora.", Toast.LENGTH_SHORT).show()
                } else {
                    adManager.showRewarded(
                        activity = activity,
                        ownerOrAdFree = false,
                        forceTestUnit = isOwner,
                        onReward = {
                            scope.launch {
                                repository.addPulseBonusCoins(authUser.uid, 1)
                                SonusNotificationCenter.add(
                                    context,
                                    title = "+1 Moeda SONUS liberada",
                                    body = "Anúncio concluído. Sua carteira recebeu +1 moeda.",
                                    category = "PREMIUM",
                                    route = "PREMIUM",
                                    importantExternal = false
                                )
                                if (!isGuest) cloudManager.track(authUser.uid, AnalyticsEvent("Rewarded Ad • +1 Moeda SONUS", "ads", membershipTier.name, success = true))
                            }
                        },
                        onUnavailable = { message -> Toast.makeText(context, message, Toast.LENGTH_SHORT).show() }
                    )
                }
            }
        }
    }

    // Compatibilidade de assinatura com telas antigas. O Passe SONUS 24h foi retirado
    // do modelo comercial atual: anúncios recompensados agora servem apenas para
    // liberar +1 Moeda SONUS. No Prata/Ouro, anúncios extras só ficam disponíveis após esgotar a cota e respeitam o teto mensal.
    val requestFeaturePass24h: (PulseFeaturePass, () -> Unit, (String) -> Unit) -> Unit = { _, _, onUnavailable ->
        onUnavailable("O Passe SONUS 24h foi descontinuado. Use suas Moedas SONUS ou o benefício do seu plano.")
    }

    val artist = if (isGuest) creatorFallbackArtist
    else state.artists.firstOrNull { it.id == state.selectedArtistId } ?: state.artists.firstOrNull() ?: creatorFallbackArtist
    val topLevelOrder = buildList {
        add(AppPage.PLAYER)
        mainTabsConfig.order.filter { it in mainTabsConfig.enabled }.forEach { tab ->
            when (tab) {
                SonusMainTab.HIGHLIGHTS -> add(AppPage.HIGHLIGHTS)
                SonusMainTab.VIDEO -> add(AppPage.TOOLS)
                SonusMainTab.STREAM -> add(AppPage.STREAM)
                SonusMainTab.DISTRIBUTION -> if (!isGuest || isOwner) add(AppPage.DISTRIBUTION)
            }
        }
        add(AppPage.SETTINGS)
    }.distinct()
    val topLevelPages = topLevelOrder.toSet()
    val backStack = remember { mutableStateListOf<AppPage>() }
    
    val navigate: (AppPage) -> Unit = { target ->
        if (page != target) {
            backStack.add(page)
            page = target
            scope.launch {
                busyMessage = "Carregando dados..."
                delay(180)
                busyMessage = null
            }
        }
    }
    val navigateTopLevel: (AppPage) -> Unit = { target ->
        if (page != target) {
            backStack.clear()
            page = target
        }
    }
    LaunchedEffect(notificationRoute, authUser.uid) {
        if (notificationRoute == "PRO_GATE") {
            planDialogMinTier = MembershipTier.PRATA
            onNotificationRouteConsumed()
            return@LaunchedEffect
        }
        val target = when (notificationRoute) {
            "PREMIUM" -> AppPage.PREMIUM
            "DISTRIBUTION" -> AppPage.DISTRIBUTION
            "PLAYER" -> AppPage.PLAYER
            "HIGHLIGHTS" -> AppPage.HIGHLIGHTS
            "TOOLS" -> AppPage.TOOLS
            "BLACK_BOX" -> AppPage.BLACK_BOX
            "NOTIFICATIONS" -> AppPage.NOTIFICATIONS
            "SUPPORT" -> AppPage.SUPPORT
            "STREAM" -> AppPage.STREAM
            "STREAM_CREATOR" -> AppPage.STREAM_CREATOR
            else -> null
        }
        if (target != null) navigateTopLevel(target)
        if (notificationRoute != null) onNotificationRouteConsumed()
    }
    val requestAddArtist: () -> Unit = {
        if (isGuest) {
            Toast.makeText(context, "Entre para salvar e proteger seus dados de distribuição.", Toast.LENGTH_LONG).show()
            onGuestAuthRequired(GuestAuthTarget.ADD_ARTIST)
        } else {
            val limit = artistLimitForTier(membershipTier)
            val allowed = ownerUnlimited || limit == null || state.artists.size < limit
            if (allowed) {
                navigate(AppPage.ADD_ARTIST)
            } else {
                Toast.makeText(
                    context,
                    "Seu plano ${membershipLabel(membershipTier)} permite até $limit artista${if (limit == 1) "" else "s"}. Seus perfis atuais são preservados.",
                    Toast.LENGTH_LONG
                ).show()
                navigate(AppPage.PREMIUM)
            }
        }
    }
    val goBack: () -> Unit = {
        page = if (backStack.isNotEmpty()) backStack.removeAt(backStack.lastIndex)
        else if (page != AppPage.PLAYER) AppPage.PLAYER
        else page
    }


    planDialogMinTier?.let { minimumTier ->
        ProPlanChoiceDialog(
            minimumTier = minimumTier,
            onDismiss = { planDialogMinTier = null },
            onChoose = { tier ->
                selectedPlanFromGate = tier
                planDialogMinTier = null
                navigate(AppPage.PREMIUM)
            }
        )
    }

    BackHandler(enabled = (page != AppPage.PLAYER || backStack.isNotEmpty())) {
        goBack()
    }

    LaunchedEffect(page, authUser.uid, membershipTier, artist.id) {
        withContext(Dispatchers.IO) {
            if (!isGuest) cloudManager.track(authUser.uid, AnalyticsEvent("Página: ${page.name}", "page", membershipTier.name))
            repository.addActivity(
                UserActivityRecord(
                    id = UUID.randomUUID().toString(),
                    artistId = artist.id.takeIf { hasDistributionProfile },
                    title = activityPageTitle(page),
                    category = "page"
                )
            )
        }
    }

    DisposableEffect(page) {
        val feature = when (page) {
            AppPage.PLAYER -> "SONUS PLAYER"
            AppPage.TOOLS -> "SONUS VIDEO"
            AppPage.STREAM -> "SONUS Stream"
            AppPage.HIGHLIGHTS -> "DESTAQUES SONUS"
            AppPage.BLACK_BOX -> "Caixa Preta SONUS"
            AppPage.SETTINGS, AppPage.USAGE, AppPage.DEVELOPER, AppPage.PREMIUM, AppPage.SUPPORT, AppPage.STREAM_CREATOR, AppPage.TAB_ORGANIZER, AppPage.NOTIFICATIONS -> "Ajustes"
            else -> "Outros"
        }
        val started = System.currentTimeMillis()
        onDispose {
            val elapsed = (System.currentTimeMillis()-started).coerceAtLeast(0L)
            scope.launch { repository.recordFeatureUsage(feature, elapsed, LocalDate.now().toString()) }
        }
    }

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            containerColor = Color.Transparent,
            bottomBar = {
                // O SONUS PLAYER é a Home de música do SONUS, mas a navegação principal
                // permanece visível para que nenhuma área do app fique escondida.
                if (page in topLevelPages && !(page == AppPage.TOOLS && videoFullscreen)) {
                    val navBarColor = when(mainTabsConfig.barStyle) {
                        "SONUS" -> Color(0xFF071A35); "NIGHT" -> Color(0xFF061224); "GRAPHITE" -> Color(0xFF202126); "PURPLE" -> Color(0xFF17102E); "DYNAMIC" -> MaterialTheme.colorScheme.surface; else -> Color.Black
                    }
                    NavigationBar(containerColor = navBarColor, tonalElevation = 0.dp, modifier = Modifier.height(68.dp)) {
                        topLevelOrder.forEach { navPage ->
                            val (label, icon) = when (navPage) {
                                AppPage.PLAYER -> "Música" to Icons.Default.Headphones
                                AppPage.HIGHLIGHTS -> "Destaques" to Icons.Default.AutoAwesome
                                AppPage.TOOLS -> "Vídeo" to Icons.Default.VideoLibrary
                                AppPage.STREAM -> "Stream" to Icons.Default.GraphicEq
                                AppPage.DISTRIBUTION -> "Distribuição" to Icons.Default.Payments
                                AppPage.SETTINGS -> "Ajustes" to Icons.Default.Settings
                                else -> "SONUS" to Icons.Default.Apps
                            }
                            BottomNavItem(page, navPage, label, icon, navigateTopLevel, if(navPage==AppPage.SETTINGS) unreadNotifications else 0)
                        }
                    }
                }
            }
        ) { padding ->
            AnimatedContent(
                targetState = page,
                transitionSpec = {
                    val forward = targetState.ordinal >= initialState.ordinal
                    val enter = slideInHorizontally(tween(220)) { full -> if (forward) full / 5 else -full / 5 } + fadeIn(tween(180))
                    val exit = slideOutHorizontally(tween(180)) { full -> if (forward) -full / 6 else full / 6 } + fadeOut(tween(140))
                    enter togetherWith exit
                },
                label = "page-transition",
                modifier = Modifier
                    .padding(padding)
                    .fillMaxSize()
            ) { targetPage ->
                when (targetPage) {
                    AppPage.PLAYER -> PulsePlayerScreen(
                        membershipTier = membershipTier,
                        preferences = state.preferences,
                        ownerUnlimited = ownerUnlimited,
                        onBack = { (context as? android.app.Activity)?.finish() },
                        externalAudioUri = externalAudioUri,
                        onExternalAudioConsumed = onExternalAudioConsumed,
                        onUnlockFeature24h = requestFeaturePass24h,
                        onRequestPlan = { tier -> planDialogMinTier = tier },
                        onStreamCreator = { if (!isGuest) navigate(AppPage.STREAM_CREATOR) else onGuestAuthRequired(GuestAuthTarget.ACCOUNT) },
                        onTrack = { name, success, duration ->
                            scope.launch {
                                withContext(Dispatchers.IO) {
                                    if (!isGuest) cloudManager.track(authUser.uid, AnalyticsEvent(name, "player", membershipTier.name, success, duration))
                                    repository.addActivity(
                                        UserActivityRecord(
                                            id = UUID.randomUUID().toString(),
                                            artistId = artist.id.takeIf { hasDistributionProfile },
                                            title = name,
                                            category = "player",
                                            success = success,
                                            durationMs = duration
                                        )
                                    )
                                }
                            }
                        },
                        onCreatorAction = { action ->
                            // O antigo Studio foi descontinuado. Atalhos do Creator Mode
                            // agora desembocam nas ferramentas preservadas de DESTAQUES SONUS.
                            requestedToolName = when (action) {
                                PulseCreatorAction.ANALYZER -> ToolId.SONUS_LAB.name
                                PulseCreatorAction.CUTTER -> ToolId.CUTTER.name
                                PulseCreatorAction.CONVERTER -> null
                                PulseCreatorAction.PITCH -> ToolId.PULSE_TUNE.name
                                PulseCreatorAction.VOCAL -> ToolId.VOICE_CLEANER.name
                                PulseCreatorAction.METADATA -> ToolId.METADATA.name
                                PulseCreatorAction.MERGE -> ToolId.MERGE.name
                                PulseCreatorAction.VIDEO_AUDIO -> ToolId.VIDEO_AUDIO.name
                            }
                            if (action == PulseCreatorAction.CONVERTER) navigate(AppPage.AUDIO_CONVERTER)
                            else navigateTopLevel(AppPage.HIGHLIGHTS)
                        },
                        adManager = adManager
                    )

                    AppPage.STREAM -> PulsePlayerScreen(
                        membershipTier = membershipTier,
                        preferences = state.preferences,
                        ownerUnlimited = ownerUnlimited,
                        onBack = goBack,
                        onUnlockFeature24h = requestFeaturePass24h,
                        onRequestPlan = { tier -> planDialogMinTier = tier },
                        onStreamCreator = { if (!isGuest) navigate(AppPage.STREAM_CREATOR) else onGuestAuthRequired(GuestAuthTarget.ACCOUNT) },
                        onOpenFullPlayerFromStream = { navigateTopLevel(AppPage.PLAYER) },
                        onTrack = { name, success, duration -> scope.launch { if (!isGuest) cloudManager.track(authUser.uid, AnalyticsEvent(name, "stream", membershipTier.name, success, duration)) } },
                        onCreatorAction = { },
                        initialSection = "ONLINE",
                        adManager = adManager
                    )


                    AppPage.HIGHLIGHTS -> ToolSuiteScreen(
                        state = state,
                        artist = artist,
                        pulseCoins = pulseCoins,
                        unlimited = ownerUnlimited || membershipTier == MembershipTier.DIAMANTE,
                        membershipTier = membershipTier,
                        preferences = state.preferences,
                        onAudioConverter = { navigate(AppPage.AUDIO_CONVERTER) },
                        onOpenBlackBox = { navigate(AppPage.BLACK_BOX) },
                        onSpendCoins = { amount ->
                            if (ownerUnlimited || membershipTier == MembershipTier.DIAMANTE) true
                            else repository.consumePulseCoins(authUser.uid, amount)
                        },
                        onWatchRewardedAd = watchFreeUseRewarded,
                        onUnlockFeature24h = requestFeaturePass24h,
                        onTrack = { name, success, duration ->
                            scope.launch {
                                withContext(Dispatchers.IO) {
                                    if (!isGuest) cloudManager.track(authUser.uid, AnalyticsEvent(name, "tool", membershipTier.name, success, duration))
                                    repository.addActivity(UserActivityRecord(id = UUID.randomUUID().toString(), artistId = artist.id.takeIf { hasDistributionProfile }, title = name, category = "tool", success = success, durationMs = duration))
                                }
                            }
                        },
                        hubVariant = ToolHubVariant.HIGHLIGHTS,
                        initialTool = requestedToolName?.let { name -> runCatching { ToolId.valueOf(name) }.getOrDefault(ToolId.HUB) } ?: ToolId.HUB,
                        onInitialToolConsumed = { requestedToolName = null },
                        unreadNotifications = unreadNotifications,
                        onNotifications = { navigate(AppPage.NOTIFICATIONS) },
                        onPremiumUseRecorded = { name -> SonusNotificationCenter.recordPremiumUse(context, name) },
                        onRequestPlan = { tier -> planDialogMinTier = tier },
                        ownerAccess = isOwner,
                        onOwnerSaveLrc = { fileId, lrc -> cloudManager.saveSonusMusicTrackOverride(fileId, mapOf("lyrics" to lrc, "lyricsFormat" to "LRC")) },
                        onOpenOwnerSonusMusic = { lrc ->
                            if (isOwner) {
                                pendingOwnerLrc = lrc
                                requestedDeveloperModule = DeveloperModule.SONUS_MUSIC.name
                                navigate(AppPage.DEVELOPER)
                            }
                        }
                    )


                    AppPage.DISTRIBUTION -> DistributionHubScreen(
                        state = state,
                        artist = artist,
                        hasDistributionProfile = hasDistributionProfile,
                        membershipTier = if (membershipTier == MembershipTier.FREE && distributionTrialState?.active == true) MembershipTier.PRATA else membershipTier,
                        isOwner = isOwner,
                        communityPresence = communityPresence,
                        onUpdate = { navigate(AppPage.UPDATE) },
                        onPayment = { navigate(AppPage.PAYMENT) },
                        onGoalChange = { goalBrl, goalStreams ->
                            if (hasDistributionProfile) scope.launch { repository.updateArtist(artist.copy(goalBrl = goalBrl, goalStreams = goalStreams)) }
                        },
                        onSelectArtist = { id -> scope.launch { repository.selectArtist(id) } },
                        onDeleteActivity = { id -> scope.launch { repository.deleteActivity(id) } },
                        onClearActivities = { if (hasDistributionProfile) scope.launch { repository.clearActivityHistory(artist.id) } },
                        onReplaceSnapshot = { snapshot -> scope.launch { repository.replaceSnapshotsForDate(snapshot) } },
                        onDeleteSnapshot = { dateIso, cycleId -> scope.launch { repository.deleteSnapshotsForDate(artist.id, dateIso, cycleId) } },
                        onUpsertDaily = { record -> scope.launch { repository.upsertDailyStreamRecord(record) } },
                        onDeleteDaily = { dateIso, cycleId -> scope.launch { repository.deleteDailyStreamRecord(artist.id, dateIso, cycleId) } },
                        onGuide = { navigate(AppPage.GUIDE) },
                        onArtistUpdate = { updated -> scope.launch { repository.updateArtist(updated) } },
                        onPreferencesChange = { prefs -> scope.launch { repository.updatePreferences(prefs) } },
                        onAddHistoricalPayment = { payment -> scope.launch { repository.addPayment(payment) } },
                        onAddArtist = requestAddArtist,
                        onEditArtist = { id -> editingArtistId = id; navigate(AppPage.EDIT_ARTIST) },
                        onDistributors = { if (isGuest) onGuestAuthRequired(GuestAuthTarget.DISTRIBUTORS) else navigate(AppPage.DISTRIBUTORS) },
                        onPremium = { planDialogMinTier = MembershipTier.PRATA }
                    )


                    AppPage.TOOLS -> SonusVideoPlayerScreen(
                        preferences = state.preferences,
                        onFullscreenChange = { videoFullscreen = it },
                        externalVideoUri = externalVideoUri,
                        onExternalVideoConsumed = onExternalVideoConsumed,
                        onTrack = { name, success, duration ->
                            scope.launch {
                                withContext(Dispatchers.IO) {
                                    if (!isGuest) cloudManager.track(authUser.uid, AnalyticsEvent(name, "video", membershipTier.name, success, duration))
                                    repository.addActivity(
                                        UserActivityRecord(
                                            id = UUID.randomUUID().toString(),
                                            artistId = artist.id.takeIf { hasDistributionProfile },
                                            title = name,
                                            category = "video",
                                            success = success,
                                            durationMs = duration
                                        )
                                    )
                                }
                            }
                        }
                    )

                    AppPage.BLACK_BOX -> {
                        val blackBoxAllowed = isOwner || commercialTier(membershipTier).ordinal >= MembershipTier.PRATA.ordinal
                        if (blackBoxAllowed) {
                            SonusBlackBoxScreen(onBack = goBack)
                        } else {
                            Column(
                                modifier = Modifier.fillMaxSize().padding(24.dp),
                                verticalArrangement = Arrangement.Center,
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(Icons.Default.Security, null, modifier = Modifier.size(56.dp), tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.height(14.dp))
                                Text("Caixa Preta SONUS", fontSize = 24.sp, fontWeight = FontWeight.Black)
                                Spacer(Modifier.height(8.dp))
                                Text("Recurso PRO disponível a partir do plano Prata.", textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .68f))
                                Spacer(Modifier.height(18.dp))
                                Button(onClick = { planDialogMinTier = MembershipTier.PRATA; navigate(AppPage.PREMIUM) }) {
                                    Icon(Icons.Default.WorkspacePremium, null)
                                    Spacer(Modifier.width(7.dp))
                                    Text("Conhecer o Prata")
                                }
                            }
                        }
                    }

                    AppPage.SETTINGS -> SettingsScreen(
                        state = state,
                        selectedArtist = artist,
                        membershipTier = membershipTier,
                        authUser = authUser,
                        isGuest = isGuest,
                        isOwner = isOwner,
                        isSupport = isSupport,
                        ownerTestMode = ownerTestMode,
                        repository = repository,
                        authManager = authManager,
                        cloudManager = cloudManager,
                        adManager = adManager,
                        onGuestLogin = { onGuestAuthRequired(GuestAuthTarget.ACCOUNT) },
                        onDeveloper = { if (isOwner) navigate(AppPage.DEVELOPER) },
                        onSupport = { if (!isGuest) navigate(AppPage.SUPPORT) else onGuestAuthRequired(GuestAuthTarget.ACCOUNT) },
                        onStreamCreator = { if (!isGuest) navigate(AppPage.STREAM_CREATOR) else onGuestAuthRequired(GuestAuthTarget.ACCOUNT) },
                        onOrganizeTabs = { navigate(AppPage.TAB_ORGANIZER) },
                        onSelect = { scope.launch { repository.selectArtist(it) } },
                        onAddArtist = requestAddArtist,
                        onEditArtist = { id -> editingArtistId = id; navigate(AppPage.EDIT_ARTIST) },
                        onArtistUpdate = { updated -> scope.launch { repository.updateArtist(updated) } },
                        onDeleteArtist = { id -> scope.launch { repository.deleteArtist(id) } },
                        onRestoreState = { restored -> scope.launch { repository.replaceState(restored) } },
                        onPreferencesChange = { prefs -> scope.launch { repository.updatePreferences(prefs) } },
                        onDistributors = { if (isGuest) onGuestAuthRequired(GuestAuthTarget.DISTRIBUTORS) else navigate(AppPage.DISTRIBUTORS) },
                        onDistributionHub = { if (isGuest) onGuestAuthRequired(GuestAuthTarget.ACCOUNT) else navigate(AppPage.DISTRIBUTION) },
                        onPremium = { planDialogMinTier = MembershipTier.PRATA },
                        onUsage = { navigate(AppPage.USAGE) },
                        onNotificationCenter = { navigate(AppPage.NOTIFICATIONS) },
                        onNotificationSettings = { navigate(AppPage.NOTIFICATION_SETTINGS) },
                        onCheckUpdate = { checkSonusUpdate(force = true, showFeedback = true) },
                        unreadNotifications = unreadNotifications,
                        onSignOut = { scope.launch { authManager.signOut(context) } },
                        onReset = {
                            scope.launch {
                                busyMessage = "Apagando dados locais..."
                                delay(300)
                                repository.resetAll()
                                delay(180)
                                busyMessage = null
                            }
                        }
                    )

                    AppPage.SUPPORT -> SonusSupportScreen(
                        user = authUser,
                        technicalContext = mapOf(
                            "appVersion" to "${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})",
                            "plan" to membershipTier.name,
                            "android" to Build.VERSION.RELEASE,
                            "device" to "${Build.MANUFACTURER} ${Build.MODEL}",
                            "page" to page.name
                        ),
                        onBack = goBack
                    )

                    AppPage.STREAM_CREATOR -> SonusStreamCreatorCenter(
                        user = authUser,
                        tier = membershipTier,
                        suggestedArtistName = state.artists.firstOrNull()?.name.orEmpty(),
                        onBack = goBack
                    )

                    AppPage.TAB_ORGANIZER -> SonusMainTabsOrganizerScreen(
                        initial = mainTabsConfig,
                        onSave = { config -> mainTabsConfig = config; mainTabsPrefs.save(config) },
                        onBack = goBack
                    )

                    AppPage.DEVELOPER -> {
                        if (isOwner) {
                            DeveloperPanelScreen(
                                authUser = authUser,
                                testMode = ownerTestMode,
                                onTestModeChange = { mode ->
                                    ownerTestModeName = mode.name
                                    if (isOwner && authUser.uid.isNotBlank()) {
                                        ownerTestPrefs.edit().putString("mode_${authUser.uid}", mode.name).apply()
                                    }
                                },
                                onRefreshRole = { authManager.refreshRole() },
                                adManager = adManager,
                                initialModuleName = requestedDeveloperModule,
                                pendingLrc = pendingOwnerLrc,
                                onPendingLrcConsumed = { pendingOwnerLrc = null },
                                onInitialModuleConsumed = { requestedDeveloperModule = null },
                                onOpenLrcEditor = {
                                    requestedToolName = ToolId.LRC_EDITOR.name
                                    navigate(AppPage.HIGHLIGHTS)
                                },
                                onBack = goBack
                            )
                        } else {
                            LaunchedEffect(Unit) { goBack() }
                        }
                    }

                    AppPage.PREMIUM -> PremiumScreen(
                        membershipTier = membershipTier,
                        premiumExpiresAt = state.preferences.premiumExpiresAtEpochMillis,
                        premiumUsesRemaining = pulseCoins,
                        usageEvents = premiumUsageEvents,
                        onBack = { selectedPlanFromGate = null; goBack() }
                    )

                    AppPage.NOTIFICATIONS -> SonusNotificationCenterScreen(
                        items = notificationItems,
                        onBack = goBack,
                        onOpenRoute = { route ->
                            when (route) {
                                "PREMIUM" -> navigate(AppPage.PREMIUM)
                                "DISTRIBUTION" -> navigateTopLevel(AppPage.DISTRIBUTION)
                                "SUPPORT" -> navigate(AppPage.SUPPORT)
                                "STREAM_CREATOR" -> navigate(AppPage.STREAM_CREATOR)
                                else -> Unit
                            }
                        }
                    )

                    AppPage.NOTIFICATION_SETTINGS -> SonusNotificationSettingsScreen(onBack = goBack)

                    AppPage.UPDATE -> UpdateStreamsScreen(
                        state = state,
                        artist = artist,
                        onBack = goBack,
                        onDistributorInfo = { navigate(AppPage.DISTRIBUTORS) },
                        onSaveRetroactive = { record ->
                            scope.launch {
                                busyMessage = "Salvando registro..."
                                delay(260)
                                repository.upsertDailyStreamRecord(record)
                                delay(160)
                                busyMessage = null
                            }
                        },
                        onArtistUpdate = { updated -> scope.launch { repository.updateArtist(updated) } }
                    ) { snapshot ->
                        scope.launch {
                            val cycleWindow = CycleWindow(snapshot.cycleStartIso, snapshot.cycleEndIso, "Ciclo atual")
                            val currentDailyDates = buildSet {
                                state.snapshots
                                    .filter { it.artistId == artist.id && snapshotInCycle(it, cycleWindow) }
                                    .forEach { add(it.dateIso) }
                                state.dailyStreamRecords
                                    .filter { it.artistId == artist.id && snapshotDateInCycle(it.dateIso, cycleWindow) }
                                    .forEach { add(it.dateIso) }
                                add(snapshot.dateIso)
                            }
                            val recordCount = currentDailyDates.size.coerceAtLeast(1)
                            val totalDelay = when (recordCount) {
                                in 1..5 -> 1500L
                                in 6..10 -> 2000L
                                in 11..20 -> 3000L
                                else -> 4000L
                            }
                            repository.replaceSnapshotsForDate(snapshot)
                            val step = (totalDelay / 4L).coerceAtLeast(250L)
                            busyMessage = "Analisando seus dados..."
                            delay(step)
                            busyMessage = "Atualizando projeções..."
                            delay(step)
                            busyMessage = "Verificando metas e saúde..."
                            delay(step)
                            busyMessage = "Dados atualizados ✓"
                            delay((totalDelay - step * 3L).coerceAtLeast(220L))
                            backStack.clear()
                            page = AppPage.DISTRIBUTION
                            busyMessage = null
                        }
                    }

                    AppPage.PAYMENT -> PaymentScreen(
                        state = state,
                        artist = artist,
                        onBack = goBack
                    ) { payment ->
                        scope.launch {
                            busyMessage = "Calibrando estimativa..."
                            delay(380)
                            repository.addPayment(payment)
                            backStack.clear()
                            page = AppPage.DISTRIBUTION
                            delay(220)
                            busyMessage = null
                        }
                    }

                    AppPage.ADD_ARTIST -> AddArtistScreen(
                        membershipTier = membershipTier,
                        isOwner = ownerUnlimited,
                        onPremium = { navigate(AppPage.PREMIUM) },
                        onBack = goBack,
                        onCreate = { name, distributor, customDistributorName, lastPayoutIso, scenarioId, photoPath, avatarId ->
                            scope.launch {
                                busyMessage = "Adicionando artista..."
                                delay(300)
                                repository.addArtist(
                                    Artist(
                                        id = UUID.randomUUID().toString(),
                                        name = name.trim(),
                                        distributor = distributor,
                                        customDistributorName = customDistributorName,
                                        lastPayoutDateIso = lastPayoutIso,
                                        createdAtIso = LocalDate.now().toString(),
                                        royaltyScenarioId = scenarioId,
                                        photoPath = photoPath,
                                        avatarId = avatarId
                                    )
                                )
                                backStack.clear()
                                page = AppPage.DISTRIBUTION
                                delay(180)
                                busyMessage = null
                            }
                        }
                    )

                    AppPage.EDIT_ARTIST -> EditArtistScreen(
                        artist = state.artists.firstOrNull { it.id == editingArtistId } ?: artist,
                        membershipTier = membershipTier,
                        isOwner = ownerUnlimited,
                        onPremium = { navigate(AppPage.PREMIUM) },
                        onBack = goBack,
                        onSave = { updated ->
                            scope.launch {
                                busyMessage = "Salvando artista..."
                                delay(260)
                                repository.updateArtist(updated)
                                backStack.clear()
                                page = AppPage.DISTRIBUTION
                                delay(160)
                                busyMessage = null
                            }
                        },
                        onDelete = {
                            scope.launch {
                                busyMessage = "Removendo artista..."
                                delay(260)
                                repository.deleteArtist(editingArtistId ?: artist.id)
                                backStack.clear()
                                page = AppPage.DISTRIBUTION
                                delay(160)
                                busyMessage = null
                            }
                        }
                    )

                    AppPage.DISTRIBUTORS -> DistributorInfoScreen(
                        selectedDistributor = artist.distributor,
                        onBack = goBack
                    )

                    AppPage.USAGE -> AppUsageScreen(
                        preferences = state.preferences,
                        membershipTier = membershipTier,
                        isOwner = isOwner && ownerTestMode == OwnerTestMode.OWNER,
                        authUser = authUser,
                        usageEvents = premiumUsageEvents,
                        onBack = goBack,
                        onClearUsage = { scope.launch { repository.clearAppUsageStats() } }
                    )



                    AppPage.AUDIO_CONVERTER -> AudioConverterProScreen(
                        artist = artist,
                        hasDistributionProfile = hasDistributionProfile,
                        pulseCoins = pulseCoins,
                        membershipTier = membershipTier,
                        coinUnlimited = ownerUnlimited || membershipTier == MembershipTier.DIAMANTE,
                        pulseLiftUnlocked = true,
                        pulseOrbit3dUnlocked = true,
                        pulseOrbit8dUnlocked = true,
                        onBack = goBack,
                        onSavePreset = { preset ->
                            scope.launch {
                                if (hasDistributionProfile && state.artists.any { it.id == artist.id }) {
                                    repository.updateArtist(artist.copy(audioPreset = preset))
                                } else {
                                    repository.updatePreferences(state.preferences.copy(creatorAudioPreset = preset))
                                }
                            }
                        },
                        onWatchRewardedAdForCoin = watchFreeUseRewarded,
                        onUnlockFeature24h = requestFeaturePass24h,
                        onSpendCoins = { amount ->
                            if (ownerUnlimited || membershipTier == MembershipTier.DIAMANTE) true
                            else repository.consumePulseCoins(authUser.uid, amount.coerceAtLeast(1))
                        },
                        onTrack = { name, success, duration ->
                            scope.launch {
                                repository.addActivity(
                                    UserActivityRecord(
                                        id = UUID.randomUUID().toString(),
                                        artistId = artist.id.takeIf { hasDistributionProfile },
                                        title = name,
                                        category = "tool",
                                        success = success,
                                        durationMs = duration
                                    )
                                )
                            }
                        }
                    )

                    AppPage.GUIDE -> StreamPulseGuideScreen(onBack = goBack)
                }
            }
        }
        var showOfflineNotice by remember { mutableStateOf(false) }
        LaunchedEffect(online) {
            if (!online) {
                showOfflineNotice = true
                delay(3000)
                showOfflineNotice = false
            } else { showOfflineNotice = false }
        }
        AnimatedVisibility(
            visible = !online && showOfflineNotice,
            modifier = Modifier.align(Alignment.TopCenter).padding(top = 8.dp)
        ) {
            Surface(
                color = MaterialTheme.colorScheme.errorContainer,
                shape = RoundedCornerShape(50),
                tonalElevation = 4.dp
            ) {
                Row(
                    Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.CloudOff, null, modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Offline • recursos locais continuam disponíveis", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
        offeredUpdate?.let { info ->
            SonusUpdateDialog(
                info = info,
                manager = updateManager,
                onDismiss = { offeredUpdate = null }
            )
        }
        BusyOverlay(busyMessage)
    }
}

@Composable
private fun RowScope.BottomNavItem(
    current: AppPage,
    target: AppPage,
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    navigate: (AppPage) -> Unit,
    badgeCount: Int = 0
) {
    val accent = when (target) {
        AppPage.PLAYER -> Color(0xFF63E2C2)
        AppPage.HIGHLIGHTS -> Color(0xFFFFD76A)
        AppPage.TOOLS -> Color(0xFFFF7B8A)
        AppPage.STREAM -> Color(0xFF67C8FF)
        AppPage.DISTRIBUTION -> Color(0xFFFFB65C)
        AppPage.SETTINGS -> Color(0xFFAEB8C7)
        else -> MaterialTheme.colorScheme.primary
    }
    NavigationBarItem(
        selected = current == target,
        onClick = { navigate(target) },
        icon = {
            BadgedBox(badge = {
                if (badgeCount > 0) Badge(containerColor = Color(0xFFD6A72F), modifier = Modifier.size(8.dp))
            }) { Icon(icon, contentDescription = label, modifier = Modifier.size(23.dp)) }
        },
        label = { Text(label, maxLines = 1, fontSize = 8.sp) },
        alwaysShowLabel = current == target,
        colors = NavigationBarItemDefaults.colors(
            selectedIconColor = accent,
            selectedTextColor = accent,
            indicatorColor = accent.copy(alpha = .16f),
            unselectedIconColor = accent.copy(alpha = .62f),
            unselectedTextColor = Color.White.copy(alpha = .62f)
        )
    )
}

@Composable
private fun StreamPulseSplashScreen() {
    val context = LocalContext.current
    val iconId = remember { AppIconCatalog.selectedId(context) }
    val splashColors = remember(iconId) { AppIconCatalog.splashColors(iconId) }
    val scriptFont = remember { runCatching { FontFamily(Font(R.font.pulsefont_amalfi_coast_08)) }.getOrElse { FontFamily.Cursive } }
    val progress = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        runCatching { progress.animateTo(1f, tween(2350, easing = LinearOutSlowInEasing)) }
    }

    val symbolP = (progress.value / .30f).coerceIn(0f, 1f)
    val wordP = ((progress.value - .26f) / .34f).coerceIn(0f, 1f)
    val waveP = ((progress.value - .58f) / .22f).coerceIn(0f, 1f)
    val taglineP = ((progress.value - .76f) / .18f).coerceIn(0f, 1f)

    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF020713), splashColors.first.copy(alpha = .18f), Color.Black))
        ),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            // Símbolo SONUS desenhado como traço de lápis: barras de áudio + sorriso/onda.
            Canvas(Modifier.size(width = 132.dp, height = 112.dp)) {
                val c = Offset(size.width / 2f, size.height * .48f)
                val barX = listOf(.28f,.40f,.50f,.60f,.72f).map { size.width * it }
                val barH = listOf(.34f,.58f,.82f,.58f,.34f).map { size.height * it }
                val strokeBase = 5.2f
                fun pencilLine(a: Offset, b: Offset, alpha: Float) {
                    if (alpha <= 0f) return
                    drawLine(Color.White.copy(alpha=.72f*alpha), a, b, strokeBase, StrokeCap.Round)
                    drawLine(Color.White.copy(alpha=.30f*alpha), a+Offset(1.2f,-.8f), b+Offset(.6f,1f), 2.2f, StrokeCap.Round)
                    drawLine(Color.White.copy(alpha=.18f*alpha), a+Offset(-1.1f,.7f), b+Offset(-.5f,-.7f), 1.3f, StrokeCap.Round)
                }
                barX.forEachIndexed { i,x ->
                    val local=((symbolP*1.45f)-(i*.10f)).coerceIn(0f,1f)
                    val h=barH[i]
                    pencilLine(Offset(x,c.y-h/2),Offset(x,c.y+h/2),local)
                }
                val arcP=((symbolP-.42f)/.58f).coerceIn(0f,1f)
                if (arcP>0f) {
                    val path=Path()
                    val left=size.width*.18f; val right=size.width*.82f; val y=size.height*.60f
                    path.moveTo(left,y-size.height*.10f)
                    path.cubicTo(left+size.width*.03f,y+size.height*.22f,right-size.width*.03f,y+size.height*.22f,right,y-size.height*.10f)
                    drawPath(path,Color.White.copy(alpha=.76f*arcP),style=Stroke(width=5.2f,cap=StrokeCap.Round))
                    drawPath(path,Color.White.copy(alpha=.20f*arcP),style=Stroke(width=2.0f,cap=StrokeCap.Round,pathEffect=PathEffect.dashPathEffect(floatArrayOf(3f,2.5f),0f)))
                }
            }

            Spacer(Modifier.height(0.dp))
            // O lettering cursivo possui caudas que ultrapassam a caixa tipográfica normal.
            // Reservamos uma área larga e animamos apenas alpha/escala, sem clipRect.
            Box(
                Modifier
                    .width(330.dp)
                    .height(92.dp)
                    .offset(y = (-12).dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Sonus",
                    modifier = Modifier
                        .width(300.dp)
                        .padding(horizontal = 26.dp)
                        .graphicsLayer {
                            alpha = wordP.coerceIn(0f, 1f)
                            scaleX = .985f + (.015f * wordP.coerceIn(0f, 1f))
                            scaleY = .985f + (.015f * wordP.coerceIn(0f, 1f))
                        },
                    color = Color.White.copy(alpha = .96f),
                    fontFamily = scriptFont,
                    fontSize = 45.sp,
                    lineHeight = 74.sp,
                    fontWeight = FontWeight.Normal,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    softWrap = false,
                    overflow = TextOverflow.Visible,
                    style = TextStyle(
                        shadow = Shadow(Color.White.copy(alpha=.08f), Offset(0f,1f), 2f)
                    )
                )
            }

            Canvas(Modifier.width(218.dp).height(38.dp)) {
                val centerY=size.height*.45f
                val maxX=size.width*waveP
                val path=Path()
                var x=0f
                while(x<=maxX){
                    val n=if(size.width==0f)0f else x/size.width
                    val env=(1f-kotlin.math.abs(n-.5f)*1.6f).coerceIn(.12f,1f)
                    val y=centerY+kotlin.math.sin(n*kotlin.math.PI.toFloat()*5.0f)*size.height*.18f*env
                    if(x==0f)path.moveTo(x,y) else path.lineTo(x,y)
                    x+=3f
                }
                if(waveP>0f) drawPath(path, brush=Brush.horizontalGradient(listOf(Color.White.copy(alpha=.75f), splashColors.second.copy(alpha=.88f), splashColors.first.copy(alpha=.82f))), style=Stroke(width=2.7f,cap=StrokeCap.Round))
            }

            Text(
                text = "Sua música. Seu som.",
                color = Color.White.copy(alpha = .72f * taglineP),
                fontSize = 13.sp,
                letterSpacing = .9.sp,
                modifier = Modifier.graphicsLayer {
                    alpha = taglineP
                    translationY = 6f * (1f - taglineP)
                }
            )
        }
        Text(
            "by SONUS STUDIOS - RΛFΛ亗",
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 18.dp),
            color = Color.White.copy(alpha = .72f),
            fontSize = 10.sp,
            fontWeight = FontWeight.Medium
        )

    }
}
@Composable
private fun ToolsScreen(
    artist: Artist,
    onAudioConverter: () -> Unit
) {
    val profile = AudioDistributorCatalog.profile(artist.distributor)
    val orangeTop = Color(0xFFFFAA5C)
    val orangeBottom = Color(0xFFE97724)
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 18.dp, bottom = 30.dp)
    ) {
        item {
            Text("Ferramentas", fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text(
                "Utilitários práticos para preparar e conferir seus arquivos antes da distribuição.",
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = .64f)
            )
        }
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(Brush.linearGradient(listOf(orangeTop, orangeBottom)))
                    .clickable(onClick = onAudioConverter)
                    .padding(horizontal = 16.dp, vertical = 15.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = Color.White.copy(alpha = .18f),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = .26f))
                    ) {
                        Icon(
                            Icons.Default.Transform,
                            contentDescription = null,
                            modifier = Modifier.padding(12.dp).size(30.dp),
                            tint = Color.White
                        )
                    }
                    Spacer(Modifier.width(13.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(
                            "Conversor de áudio",
                            style = TextStyle(
                                color = Color.White,
                                fontSize = 19.sp,
                                fontWeight = FontWeight.ExtraBold,
                                shadow = Shadow(Color.Black.copy(alpha = .45f), Offset(0f, 2f), 4f)
                            )
                        )
                        Text(
                            "${DistributorRules.displayName(artist.distributor, artist.customDistributorName)} • ${profile.formats.joinToString(" / ")}",
                            style = TextStyle(
                                color = Color.White.copy(alpha = .92f),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                shadow = Shadow(Color.Black.copy(alpha = .35f), Offset(0f, 1f), 3f)
                            )
                        )
                    }
                    Icon(Icons.Default.ChevronRight, null, tint = Color.White, modifier = Modifier.size(25.dp))
                }
            }
        }
        item {
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("Conversão local e privada", fontWeight = FontWeight.Bold)
                    Text("A música é processada no próprio aparelho. O SONUS não envia o áudio para Firebase ou qualquer servidor.", style = MaterialTheme.typography.bodySmall)
                    Text("Cada exportação parte do arquivo original para evitar conversões em cascata.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
private fun AudioConverterScreen(
    artist: Artist,
    converterCoins: Int,
    ownerUnlimited: Boolean,
    onBack: () -> Unit,
    onSavePreset: (AudioConversionPreset) -> Unit,
    onWatchRewardedAd: () -> Unit,
    onSpendCoin: suspend () -> Boolean
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val profile = remember(artist.distributor) { AudioDistributorCatalog.profile(artist.distributor) }
    var preset by remember(artist.id) { mutableStateOf(artist.audioPreset ?: AudioDistributorCatalog.defaultPreset(artist.distributor)) }
    var inputUri by remember { mutableStateOf<Uri?>(null) }
    var sourceInfo by remember { mutableStateOf<AudioSourceInfo?>(null) }
    var isConverting by remember { mutableStateOf(false) }
    var rawProgress by remember { mutableFloatStateOf(0f) }
    var conversionPhase by remember { mutableStateOf("Preparando arquivo...") }
    var resultMessage by remember { mutableStateOf<String?>(null) }
    var resultSuccess by remember { mutableStateOf(false) }

    val animatedProgress by animateFloatAsState(
        targetValue = rawProgress.coerceIn(0f, 1f),
        animationSpec = tween(durationMillis = 320),
        label = "audio-conversion-progress"
    )

    LaunchedEffect(profile, artist.audioPreset) {
        val candidate = artist.audioPreset ?: AudioDistributorCatalog.defaultPreset(artist.distributor)
        preset = candidate.copy(
            format = candidate.format.takeIf { it in profile.formats } ?: profile.recommendedFormat,
            sampleRateHz = candidate.sampleRateHz.takeIf { it in profile.allowedSampleRates } ?: profile.allowedSampleRates.first(),
            bitDepth = candidate.bitDepth.takeIf { it in profile.allowedBitDepths } ?: profile.allowedBitDepths.first(),
            channels = if (profile.stereoOnly) 2 else candidate.channels.coerceIn(1, 2)
        )
    }

    val inputPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            inputUri = uri
            resultMessage = null
            resultSuccess = false
            rawProgress = 0f
            sourceInfo = runCatching { AudioConversionEngine.inspect(context, uri) }.getOrNull()
        }
    }

    val autoTitle = sourceInfo?.displayName
        ?.substringBeforeLast('.')
        ?.trim()
        ?.take(160)
        .orEmpty()
    val currentYear = LocalDate.now().year.toString()

    val outputMime = when (preset.format) {
        "WAV" -> "audio/wav"
        "FLAC" -> "audio/flac"
        "MP3" -> "audio/mpeg"
        else -> "application/octet-stream"
    }
    val outputPicker = rememberLauncherForActivityResult(SonusAutoCreateDocument(outputMime)) { uri ->
        val source = inputUri
        if (uri != null && source != null) {
            scope.launch {
                isConverting = true
                resultMessage = null
                resultSuccess = false
                rawProgress = 0f
                conversionPhase = "Preparando arquivo..."
                val startedAt = System.currentTimeMillis()
                val tags = AudioTrackTags(
                    title = autoTitle,
                    artist = artist.name,
                    album = preset.album.trim(),
                    genre = preset.genre.trim(),
                    composer = preset.composer.trim(),
                    year = currentYear
                )
                val result = withContext(Dispatchers.IO) {
                    AudioConversionEngine.convert(context, source, uri, preset, tags, onProgress = { progress ->
                        scope.launch {
                            val safe = progress.coerceIn(0f, .98f)
                            if (safe > rawProgress) rawProgress = safe
                            conversionPhase = when {
                                safe < .05f -> "Preparando arquivo..."
                                safe < .78f -> "Convertendo áudio..."
                                safe < .94f -> "Aplicando configurações..."
                                else -> "Finalizando arquivo..."
                            }
                        }
                    })
                }

                if (result.success) {
                    conversionPhase = "Finalizando arquivo..."
                    rawProgress = max(rawProgress, .98f)
                    val elapsed = System.currentTimeMillis() - startedAt
                    val remaining = (5_000L - elapsed).coerceAtLeast(0L)
                    if (remaining > 0L) delay(remaining)
                    rawProgress = 1f
                    conversionPhase = "✓ Conversão concluída"
                    resultSuccess = true
                    resultMessage = "Seu arquivo está pronto para distribuição."
                } else {
                    resultSuccess = false
                    resultMessage = "Falha: ${result.message}"
                }
                isConverting = false
            }
        }
    }

    val sampleRates = profile.allowedSampleRates.distinct().sorted()
    val bitDepths = profile.allowedBitDepths.distinct().sorted()
    val sourceSizeMb = sourceInfo?.sizeBytes?.let { it / 1024.0 / 1024.0 }
    val sizeOk = profile.maxFileSizeMb?.let { max -> sourceSizeMb == null || sourceSizeMb < max } ?: true
    val durationOk = profile.maxDurationMinutes?.let { max -> sourceInfo?.durationMs == null || sourceInfo!!.durationMs!! <= max * 60_000L } ?: true
    val minDurationOk = profile.minDurationSeconds?.let { min -> sourceInfo?.durationMs == null || sourceInfo!!.durationMs!! >= min * 1000L } ?: true
    val configOk = preset.format in profile.formats && preset.sampleRateHz in sampleRates && preset.bitDepth in bitDepths && (!profile.stereoOnly || preset.channels == 2)
    val ready = inputUri != null && configOk && sizeOk && durationOk && minDurationOk
    val canConvert = ready
    val suggestedName = buildString {
        append(autoTitle.ifBlank { sourceInfo?.displayName?.substringBeforeLast('.') ?: artist.name })
        append("_SONUS.")
        append(preset.format.lowercase(Locale.US))
    }.replace(Regex("[\\/:*?\"<>|]+"), "_")

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 18.dp, bottom = 32.dp)
    ) {
        item { PageHeader("Conversor de áudio", onBack) }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = .75f))) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(DistributorRules.displayName(artist.distributor, artist.customDistributorName), fontWeight = FontWeight.ExtraBold, fontSize = 19.sp)
                            Text("Recomendado: ${profile.recommendedFormat}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                        }
                        Surface(shape = RoundedCornerShape(15.dp), color = SignalGreen.copy(alpha = .16f)) {
                            Text("FREE", modifier = Modifier.padding(horizontal = 11.dp, vertical = 7.dp), fontWeight = FontWeight.ExtraBold, color = SignalGreen)
                        }
                    }
                    Text("Formatos aceitos no perfil: ${profile.formats.joinToString(" • ")}", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item {
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("1. Arquivo original", fontWeight = FontWeight.Bold)
                    Button(onClick = { inputPicker.launch(arrayOf("audio/*", "application/octet-stream")) }, modifier = Modifier.fillMaxWidth(), enabled = !isConverting) {
                        Icon(Icons.Default.FolderOpen, null)
                        Spacer(Modifier.width(8.dp))
                        Text(if (inputUri == null) "Selecionar música" else "Trocar arquivo")
                    }
                    sourceInfo?.let { info ->
                        Text(info.displayName, fontWeight = FontWeight.SemiBold)
                        val detail = buildList {
                            info.sampleRateHz?.let { add(formatSampleRate(it)) }
                            info.channels?.let { add(if (it == 1) "mono" else "$it canais") }
                            info.bitrate?.let { add("${it / 1000} kbps") }
                            info.durationMs?.let { add(formatAudioDurationShort(it)) }
                            info.sizeBytes?.let { add(String.format(Locale("pt", "BR"), "%.1f MB", it / 1024.0 / 1024.0)) }
                        }
                        Text(detail.joinToString(" • "), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .66f))
                    }
                }
            }
        }
        item {
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
                    Text("2. Perfil de saída", fontWeight = FontWeight.Bold)
                    SimpleChoiceField("Formato", preset.format, profile.formats) { preset = preset.copy(format = it) }
                    SimpleChoiceField("Taxa de amostragem", formatSampleRate(preset.sampleRateHz), sampleRates.map(::formatSampleRate)) { label ->
                        sampleRates.firstOrNull { formatSampleRate(it) == label }?.let { preset = preset.copy(sampleRateHz = it) }
                    }
                    SimpleChoiceField("Profundidade", "${preset.bitDepth}-bit", bitDepths.map { "$it-bit" }) { label ->
                        label.substringBefore("-").toIntOrNull()?.let { preset = preset.copy(bitDepth = it) }
                    }
                    if (!profile.stereoOnly) {
                        SimpleChoiceField("Canais", if (preset.channels == 1) "Mono" else "Estéreo", listOf("Estéreo", "Mono")) {
                            preset = preset.copy(channels = if (it == "Mono") 1 else 2)
                        }
                    } else {
                        ReadOnlySpecRow("Canais", "Estéreo")
                    }
                    if (preset.format == "MP3") {
                        val bitrateOptions = SonusMediaStandards.mp3Bitrates
                        val normalizedBitrate = SonusMediaStandards.nearestBitrate("MP3", preset.bitrateKbps)
                        SimpleChoiceField("Taxa de bits", "$normalizedBitrate kbps", bitrateOptions.map { "$it kbps" }) { label ->
                            label.substringBefore(" ").toIntOrNull()?.let { preset = preset.copy(bitrateKbps = it) }
                        }
                    } else {
                        ReadOnlySpecRow("Taxa de bits", "PCM/lossless • calculada pelo perfil")
                    }
                }
            }
        }
        item {
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text("3. Tags do arquivo", fontWeight = FontWeight.Bold)
                    OutlinedTextField(autoTitle, {}, label = { Text("Título") }, readOnly = true, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(artist.name, {}, label = { Text("Artista") }, readOnly = true, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(preset.album, { preset = preset.copy(album = it.take(160)) }, label = { Text("Álbum padrão") }, singleLine = true, modifier = Modifier.fillMaxWidth(), enabled = !isConverting)
                    SimpleChoiceField("Gênero", SonusMediaPreferences.initialGenre(context, preset.genre), SonusMediaStandards.genres) { selected ->
                        SonusMediaPreferences.saveLastGenre(context, selected)
                        preset = preset.copy(genre = selected)
                    }
                    OutlinedTextField(preset.composer, { preset = preset.copy(composer = it.take(160)) }, label = { Text("Compositor") }, singleLine = true, modifier = Modifier.fillMaxWidth(), enabled = !isConverting)
                    OutlinedTextField(currentYear, {}, label = { Text("Ano") }, readOnly = true, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedButton(onClick = { onSavePreset(preset) }, modifier = Modifier.fillMaxWidth(), enabled = !isConverting) {
                        Icon(Icons.Default.Save, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Salvar perfil para ${artist.name}")
                    }
                    Text("Título, artista e ano são preenchidos automaticamente. Álbum, gênero e compositor podem ficar salvos no preset do artista.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .58f))
                }
            }
        }
        item {
            Card(border = BorderStroke(1.dp, if (ready) SignalGreen.copy(alpha = .55f) else SignalOrange.copy(alpha = .55f))) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("Verificação antes do envio", fontWeight = FontWeight.Bold)
                    CompatibilityLine(configOk, "Formato e parâmetros compatíveis com o perfil")
                    CompatibilityLine(sizeOk, profile.maxFileSizeMb?.let { "Tamanho abaixo de $it MB" } ?: "Sem limite de tamanho publicado")
                    CompatibilityLine(durationOk && minDurationOk, "Duração dentro das regras documentadas")
                    CompatibilityLine(true, "Master original será preservado")
                    Row(verticalAlignment = Alignment.Top) {
                        Icon(Icons.Default.Info, null, modifier = Modifier.size(17.dp), tint = SignalYellow)
                        Spacer(Modifier.width(6.dp))
                        Text("Clipping não é corrigido automaticamente: o conversor preserva o áudio e recomenda validar o master antes do envio.", style = MaterialTheme.typography.bodySmall)
                    }
                    profile.notes.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f)) }
                    Text(
                        if (ready) "🟢 Arquivo e perfil prontos para conversão" else "🟠 Selecione um arquivo e revise os itens destacados",
                        fontWeight = FontWeight.ExtraBold,
                        color = if (ready) SignalGreen else SignalOrange
                    )
                }
            }
        }
        if (isConverting || rawProgress > 0f && resultSuccess) {
            item {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .82f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = .24f))
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(conversionPhase, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                            Text("${(animatedProgress * 100f).roundToInt()}%", fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                        }
                        LinearProgressIndicator(
                            progress = { animatedProgress },
                            modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(10.dp)),
                            strokeCap = androidx.compose.ui.graphics.StrokeCap.Round
                        )
                    }
                }
            }
        }
        resultMessage?.let { message ->
            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = (if (resultSuccess) SignalGreen else SignalOrange).copy(alpha = .12f),
                    border = BorderStroke(1.dp, (if (resultSuccess) SignalGreen else SignalOrange).copy(alpha = .40f))
                ) { Text(message, modifier = Modifier.padding(13.dp), fontWeight = FontWeight.SemiBold) }
            }
        }
        item {
            Button(
                onClick = { outputPicker.launch(suggestedName) },
                enabled = canConvert && !isConverting,
                modifier = Modifier.fillMaxWidth().height(56.dp)
            ) {
                if (isConverting) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                else Icon(Icons.Default.Transform, null)
                Spacer(Modifier.width(8.dp))
                Text(if (isConverting) "Convertendo..." else "Converter e salvar em SONUS/Audio")
            }
        }
        item {
            Text(
                "Conversão gratuita. O arquivo é salvo automaticamente em SONUS/Audio.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = .55f)
            )
        }
    }
}

@Composable
private fun SimpleChoiceField(label: String, value: String, options: List<String>, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxWidth()) {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.Start) {
                Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .58f))
                Text(value, fontWeight = FontWeight.Bold)
            }
            Icon(Icons.Default.ArrowDropDown, null)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.distinct().forEach { option ->
                DropdownMenuItem(
                    text = { Text(option) },
                    onClick = { expanded = false; onSelect(option) },
                    leadingIcon = { if (option == value) Icon(Icons.Default.Check, null) }
                )
            }
        }
    }
}

@Composable
private fun ReadOnlySpecRow(label: String, value: String) {
    Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .55f)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(label, modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurface.copy(alpha = .62f))
            Text(value, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun CompatibilityLine(ok: Boolean, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(if (ok) Icons.Default.CheckCircle else Icons.Default.Warning, null, tint = if (ok) SignalGreen else SignalOrange, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(7.dp))
        Text(text, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
    }
}

private fun formatSampleRate(hz: Int): String = when {
    hz % 1000 == 0 -> "${hz / 1000} kHz"
    else -> String.format(Locale.US, "%.1f kHz", hz / 1000.0).replace('.', ',')
}

private fun formatAudioDurationShort(ms: Long): String {
    val totalSeconds = (ms / 1000L).coerceAtLeast(0L)
    val minutes = totalSeconds / 60L
    val seconds = totalSeconds % 60L
    return "%d:%02d".format(Locale.US, minutes, seconds)
}

@Composable
private fun EligibilitySwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun StreamPulseGuideEntryCard(onClick: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.primary.copy(alpha = .13f),
        border = BorderStroke(1.4.dp, MaterialTheme.colorScheme.primary.copy(alpha = .55f))
    ) {
        Row(Modifier.padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary.copy(alpha = .20f)) {
                Icon(Icons.Default.MenuBook, null, modifier = Modifier.padding(10.dp).size(24.dp), tint = MaterialTheme.colorScheme.primary)
            }
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text("Guia do SONUS", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                Text("Entenda funções, indicadores e como interpretar seus dados.", style = MaterialTheme.typography.bodySmall)
            }
            Icon(Icons.Default.ChevronRight, null)
        }
    }
}

private data class GuideItem(val category: String, val title: String, val body: String)

@Composable
private fun StreamPulseGuideScreen(onBack: () -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    val guideItems = remember {
        listOf(
            GuideItem("Ganhos", "Saúde do Projeto", "Mostra a consistência do artista dentro do ciclo atual. A pontuação recomeça quando a distribuidora inicia um novo ciclo. O número grande representa o acumulado do ciclo e o status considera o desempenho possível até o momento."),
            GuideItem("Ganhos", "Previsão do ciclo", "Estima onde o ciclo pode terminar se o comportamento observado continuar. É uma projeção de planejamento e tende a ganhar contexto conforme novos registros entram."),
            GuideItem("Ganhos", "Tendência", "Indica se os registros recentes estão acelerando, estabilizando ou desacelerando. Use junto com Média diária e Ritmo recente."),
            GuideItem("Ganhos", "Média diária", "Resume quantos streams por dia aparecem, em média, na base registrada."),
            GuideItem("Ganhos", "Ritmo recente", "Destaca a velocidade mais atual do projeto para facilitar a comparação com a média e com a meta."),
            GuideItem("Ganhos", "Próximo fechamento", "Mostra quanto falta para o encerramento do ciclo da distribuidora e a data de referência usada pelo SONUS."),
            GuideItem("Ganhos", "Velocímetro de atividade", "O mostrador esquerdo ajuda a ler a mudança recente; o direito mostra o ritmo em relação à meta ou ao próprio ciclo. Cores quentes pedem atenção e verde indica desempenho forte."),
            GuideItem("Ganhos", "Resumo inteligente", "Transforma vários indicadores em uma leitura curta do momento do projeto. Não substitui as telas de análise detalhada."),
            GuideItem("Ganhos", "Próxima ação e alertas", "Destacam o que merece atenção agora, como atualização pendente, fechamento próximo, queda de ritmo ou meta em risco."),
            GuideItem("Premium", "Raio-X do Projeto", "Cruza diversos sinais do projeto e entrega um diagnóstico resumido. Disponível no Prata ou superior e durante o teste de 7 dias de Distribuição & Pagamentos."),
            GuideItem("Ganhos", "Histórico • 7 / 14 / 30 dias / Ciclo", "Permitem observar a evolução em janelas diferentes. A visualização Ciclo acompanha o período real da distribuidora e mostra todos os registros daquele ciclo."),
            GuideItem("Ganhos", "Ciclos anteriores", "Ao terminar um ciclo, os registros permanecem arquivados por período e podem ser reabertos a qualquer momento."),
            GuideItem("Ganhos", "Análises • comparação por janelas", "Compara grupos de registros para mostrar mudanças de ritmo em curto e médio prazo."),
            GuideItem("Ganhos", "Simulador de Meta", "Permite testar um ritmo hipotético de streams por dia e visualizar como o ciclo poderia terminar."),
            GuideItem("Ganhos", "Auditoria e anomalias", "Ajuda a identificar lacunas, registros incomuns e qualidade geral da base sem alterar automaticamente seus dados."),
            GuideItem("Ganhos", "Financeiro • estimado × recebido", "Compara o que o SONUS previa com pagamentos reais registrados pelo usuário."),
            GuideItem("Ganhos", "Precisão histórica", "Mostra como as previsões anteriores se aproximaram dos pagamentos reais e melhora a leitura conforme mais pagamentos são registrados."),
            GuideItem("Ganhos", "Projeções financeiras", "Apresentam cenários futuros baseados na base existente. Horizontes longos têm mais incerteza e não representam promessa de receita."),
            GuideItem("Ganhos", "Meta anual de ganhos", "Permite acompanhar uma meta financeira anual separando valores realmente recebidos de estimativas ainda em formação."),
            GuideItem("Ganhos", "Relatórios PDF", "Exportam um resumo do período para consulta e arquivo pessoal."),
            GuideItem("Ferramentas", "Conversor de Áudio", "Funciona normalmente sem distribuidora, com configurações livres do SONUS. Se houver artista/distribuidora cadastrados em Ganhos, o Conversor mostra automaticamente um perfil recomendado, sem bloquear outros formatos."),
            GuideItem("Ganhos", "Artistas e distribuidoras", "Cadastre e selecione artistas no topo da área Ganhos. Perfis de distribuidora são opcionais para Player e Ferramentas, mas ativam recomendações e análises específicas de distribuição."),
            GuideItem("Ajustes", "Temas, fontes e ícones", "Personalizam a aparência do SONUS. Alguns estilos são identificados pelos selos dos planos Premium."),
            GuideItem("Ajustes", "Backup", "Cria uma cópia local dos dados do SONUS para restauração futura. Guarde o arquivo em local seguro."),
            GuideItem("Ajustes", "Uso do SONUS", "Mostra estatísticas locais como tempo de uso, entradas, média diária e maior sessão. Esses dados pertencem ao próprio usuário."),
            GuideItem("Premium", "Planos Grátis, Prata, Ouro e Diamante", "O Grátis mantém Player e Stream completos e permite desbloqueios pontuais por anúncio/moeda. Prata abre o pacote PRO, Ouro amplia limites e recursos avançados, e Diamante oferece o nível mais completo.")
        )
    }
    val filtered = guideItems.filter {
        query.isBlank() || it.title.contains(query, ignoreCase = true) || it.category.contains(query, ignoreCase = true) || it.body.contains(query, ignoreCase = true)
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(top = 18.dp, bottom = 32.dp)
    ) {
        item { PageHeader("Guia do SONUS", onBack) }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = .72f))) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Como interpretar o app", fontWeight = FontWeight.ExtraBold)
                    Text("Este guia explica o que cada recurso faz e como ler os resultados. Fórmulas internas, pesos e critérios proprietários do motor não são exibidos.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it.take(80) },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Buscar uma função") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                singleLine = true
            )
        }
        items(filtered, key = { "${it.category}|${it.title}" }) { item ->
            GuideAccordionItem(item)
        }
    }
}

@Composable
private fun GuideAccordionItem(item: GuideItem) {
    var expanded by rememberSaveable(item.title) { mutableStateOf(false) }
    Card(modifier = Modifier.fillMaxWidth().clickable { expanded = !expanded }) {
        Column(Modifier.padding(horizontal = 15.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(item.category, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Text(item.title, fontWeight = FontWeight.Bold)
                }
                Icon(if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null)
            }
            AnimatedVisibility(expanded) {
                Text(item.body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .72f))
            }
        }
    }
}


@Composable
private fun AppLoadingScreen(message: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Image(
                painter = painterResource(R.drawable.sonus_symbol_official),
                contentDescription = null,
                modifier = Modifier.size(88.dp)
            )
            CircularProgressIndicator(strokeWidth = 3.dp)
            Text(message, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun BusyOverlay(message: String?) {
    AnimatedVisibility(visible = message != null, enter = fadeIn(tween(120)), exit = fadeOut(tween(140))) {
        Box(
            Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background.copy(alpha = .42f)),
            contentAlignment = Alignment.Center
        ) {
            Surface(shape = RoundedCornerShape(18.dp), tonalElevation = 8.dp) {
                Row(
                    Modifier.padding(horizontal = 20.dp, vertical = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 3.dp)
                    Text(message.orEmpty(), fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
private fun OnboardingScreen(onCreate: (String, DistributorId, String?, String?, String?) -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 14.dp, bottom = 28.dp)
    ) {
        item {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Image(
                    painter = painterResource(R.drawable.sonus_logo_official),
                    contentDescription = "SONUS",
                    modifier = Modifier.size(150.dp),
                    contentScale = ContentScale.Fit
                )
            }
            Spacer(Modifier.height(4.dp))
            Text("Sua central de música e criação", fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text("Use o SONUS PLAYER e as ferramentas livremente. Cadastre um artista apenas se quiser acompanhar distribuição, streams e ganhos.")
        }
        item { ArtistForm(submitLabel = "Começar", onSubmit = onCreate) }
    }
}

@Composable
private fun AddArtistScreen(
    membershipTier: MembershipTier,
    isOwner: Boolean,
    onPremium: () -> Unit,
    onBack: () -> Unit,
    onCreate: (String, DistributorId, String?, String?, String?, String?, String?) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val draftKey = rememberSaveable { "draft_${UUID.randomUUID()}" }
    var photoPath by rememberSaveable { mutableStateOf<String?>(null) }
    var avatarId by rememberSaveable { mutableStateOf<String?>(null) }
    var showSourceDialog by remember { mutableStateOf(false) }
    var showAvatarDialog by remember { mutableStateOf(false) }
    var identityMessage by remember { mutableStateOf<String?>(null) }

    val photoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            scope.launch {
                identityMessage = "Preparando foto..."
                val path = withContext(Dispatchers.IO) { saveArtistPhoto(context, uri, draftKey, photoPath) }
                if (path != null) {
                    photoPath = path
                    avatarId = null
                    identityMessage = "Foto pronta"
                } else identityMessage = "Não foi possível abrir a imagem"
                delay(900)
                identityMessage = null
            }
        }
    }

    if (showSourceDialog) {
        ArtistImageSourceDialog(
            onDismiss = { showSourceDialog = false },
            onGallery = { showSourceDialog = false; photoLauncher.launch("image/*") },
            onAvatar = { showSourceDialog = false; showAvatarDialog = true }
        )
    }
    if (showAvatarDialog) {
        SonusAvatarPickerDialog(
            currentAvatarId = avatarId,
            membershipTier = membershipTier,
            isOwner = isOwner,
            onDismiss = { showAvatarDialog = false },
            onApply = { selected ->
                deleteArtistPhoto(photoPath)
                photoPath = null
                avatarId = selected
                showAvatarDialog = false
            },
            onLocked = {
                showAvatarDialog = false
                onPremium()
            }
        )
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item {
            PageHeader("Adicionar artista") {
                deleteArtistPhoto(photoPath)
                onBack()
            }
        }
        item {
            ArtistIdentityCard(
                photoPath = photoPath,
                avatarId = avatarId,
                message = identityMessage,
                onChoose = { showSourceDialog = true },
                onRemove = {
                    deleteArtistPhoto(photoPath)
                    photoPath = null
                    avatarId = null
                }
            )
        }
        item {
            ArtistForm(
                submitLabel = "Adicionar artista",
                onSubmit = { name, distributor, customDistributorName, lastPayoutIso, scenarioId ->
                    onCreate(name, distributor, customDistributorName, lastPayoutIso, scenarioId, photoPath, avatarId)
                }
            )
        }
    }
}

@Composable
private fun EditArtistScreen(
    artist: Artist,
    membershipTier: MembershipTier,
    isOwner: Boolean,
    onPremium: () -> Unit,
    onBack: () -> Unit,
    onSave: (Artist) -> Unit,
    onDelete: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var confirmDelete by remember { mutableStateOf(false) }
    val originalPhotoPath = artist.photoPath
    var photoPath by rememberSaveable(artist.id) { mutableStateOf(artist.photoPath) }
    var avatarId by rememberSaveable(artist.id) { mutableStateOf(artist.avatarId) }
    var showSourceDialog by remember { mutableStateOf(false) }
    var showAvatarDialog by remember { mutableStateOf(false) }
    var identityMessage by remember { mutableStateOf<String?>(null) }

    val photoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            scope.launch {
                identityMessage = "Preparando foto..."
                val previousDraft = photoPath?.takeIf { it != originalPhotoPath }
                val path = withContext(Dispatchers.IO) { saveArtistPhoto(context, uri, artist.id, previousDraft) }
                if (path != null) {
                    photoPath = path
                    avatarId = null
                    identityMessage = "Foto atualizada"
                } else identityMessage = "Não foi possível abrir a imagem"
                delay(900)
                identityMessage = null
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Excluir ${artist.name}?") },
            text = { Text("As atualizações e pagamentos desse artista também serão removidos deste aparelho.") },
            confirmButton = { TextButton(onClick = {
                confirmDelete = false
                photoPath?.takeIf { it != originalPhotoPath }?.let(::deleteArtistPhoto)
                deleteArtistPhoto(originalPhotoPath)
                onDelete()
            }) { Text("Excluir") } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancelar") } }
        )
    }
    if (showSourceDialog) {
        ArtistImageSourceDialog(
            onDismiss = { showSourceDialog = false },
            onGallery = { showSourceDialog = false; photoLauncher.launch("image/*") },
            onAvatar = { showSourceDialog = false; showAvatarDialog = true }
        )
    }
    if (showAvatarDialog) {
        SonusAvatarPickerDialog(
            currentAvatarId = avatarId,
            membershipTier = membershipTier,
            isOwner = isOwner,
            onDismiss = { showAvatarDialog = false },
            onApply = { selected ->
                photoPath?.takeIf { it != originalPhotoPath }?.let(::deleteArtistPhoto)
                photoPath = null
                avatarId = selected
                showAvatarDialog = false
            },
            onLocked = {
                showAvatarDialog = false
                onPremium()
            }
        )
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 28.dp)
    ) {
        item {
            PageHeader("Editar artista") {
                photoPath?.takeIf { it != originalPhotoPath }?.let(::deleteArtistPhoto)
                onBack()
            }
        }
        item {
            ArtistIdentityCard(
                photoPath = photoPath,
                avatarId = avatarId,
                message = identityMessage,
                onChoose = { showSourceDialog = true },
                onRemove = {
                    photoPath?.takeIf { it != originalPhotoPath }?.let(::deleteArtistPhoto)
                    photoPath = null
                    avatarId = null
                }
            )
        }
        item {
            ArtistForm(
                submitLabel = "Salvar alterações",
                initialArtist = artist,
                onSubmit = { name, distributor, customName, payout, scenarioId ->
                    if (photoPath != originalPhotoPath) deleteArtistPhoto(originalPhotoPath)
                    onSave(
                        artist.copy(
                            name = name,
                            distributor = distributor,
                            customDistributorName = customName,
                            lastPayoutDateIso = payout,
                            royaltyScenarioId = scenarioId,
                            photoPath = photoPath,
                            avatarId = avatarId
                        )
                    )
                }
            )
        }
        item {
            OutlinedButton(onClick = { confirmDelete = true }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Delete, null)
                Spacer(Modifier.width(8.dp))
                Text("Excluir artista")
            }
        }
    }
}

@Composable
private fun ArtistIdentityCard(
    photoPath: String?,
    avatarId: String?,
    message: String?,
    onChoose: () -> Unit,
    onRemove: () -> Unit
) {
    Card {
        Row(
            Modifier.fillMaxWidth().padding(15.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(contentAlignment = Alignment.BottomEnd) {
                ArtistAvatar(photoPath = photoPath, avatarId = avatarId, size = 82.dp, fallbackToLogo = true)
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(28.dp).clickable(onClick = onChoose)
                ) { Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.PhotoCamera, null, tint = Color.White, modifier = Modifier.size(16.dp)) } }
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("Imagem do artista", fontWeight = FontWeight.ExtraBold)
                Text(
                    when {
                        photoPath != null -> "Foto da galeria"
                        avatarId != null -> "Avatar SONUS • ${SonusAvatarCatalog.byId(avatarId)?.title.orEmpty()}"
                        else -> "Use uma foto ou escolha um Avatar SONUS."
                    },
                    style = MaterialTheme.typography.bodySmall
                )
                message?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary) }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TextButton(onClick = onChoose, contentPadding = PaddingValues(horizontal = 0.dp)) { Text(if (photoPath == null && avatarId == null) "Adicionar" else "Alterar") }
                    if (photoPath != null || avatarId != null) TextButton(onClick = onRemove) { Text("Remover") }
                }
            }
        }
    }
}

@Composable
private fun ArtistImageSourceDialog(
    onDismiss: () -> Unit,
    onGallery: () -> Unit,
    onAvatar: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Imagem do artista", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                OutlinedButton(onClick = onGallery, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                    Icon(Icons.Default.PhotoLibrary, null); Spacer(Modifier.width(8.dp)); Text("Escolher da galeria")
                }
                OutlinedButton(onClick = onAvatar, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                    Icon(Icons.Default.Face, null); Spacer(Modifier.width(8.dp)); Text("Avatar SONUS")
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun SonusAvatarPickerDialog(
    currentAvatarId: String?,
    membershipTier: MembershipTier,
    isOwner: Boolean,
    onDismiss: () -> Unit,
    onApply: (String) -> Unit,
    onLocked: (MembershipTier) -> Unit
) {
    var previewId by remember(currentAvatarId) { mutableStateOf(currentAvatarId ?: SonusAvatarCatalog.instruments.first().id) }
    val previewSpec = SonusAvatarCatalog.byId(previewId)
    val groups = remember { SonusAvatarCatalog.all.groupBy { it.collection }.toList() }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Avatar SONUS", fontWeight = FontWeight.ExtraBold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    SonusAvatarArtwork(previewId, Modifier.size(76.dp).clip(CircleShape))
                    Column(Modifier.weight(1f)) {
                        Text(previewSpec?.title ?: "Avatar SONUS", fontWeight = FontWeight.Bold)
                        Text(previewSpec?.collection ?: "", style = MaterialTheme.typography.bodySmall)
                        Text("Trocas de avatar não consomem Moedas SONUS.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .58f))
                    }
                }
                HorizontalDivider()
                LazyColumn(
                    modifier = Modifier.heightIn(max = 430.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    groups.forEach { (collection, specs) ->
                        item(key = "header_$collection") {
                            val tier = specs.first().tier
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(collection, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                                Text(tier.name, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                        items(specs.chunked(4), key = { row -> row.joinToString("_") { it.id } }) { row ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                                row.forEach { spec ->
                                    val unlocked = SonusAvatarCatalog.unlocked(spec, membershipTier, isOwner)
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        modifier = Modifier.width(68.dp).clickable {
                                            if (unlocked) previewId = spec.id else onLocked(spec.tier)
                                        }
                                    ) {
                                        val selected = previewId == spec.id
                                        Box(
                                            Modifier
                                                .size(58.dp)
                                                .then(if (selected) Modifier.border(2.dp, MaterialTheme.colorScheme.primary, CircleShape) else Modifier)
                                                .padding(if (selected) 3.dp else 0.dp)
                                        ) {
                                            SonusAvatarArtwork(spec.id, Modifier.fillMaxSize().clip(CircleShape), locked = !unlocked)
                                        }
                                        Text(spec.title, fontSize = 8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text(
                                            if (spec.tier == MembershipTier.FREE) "FREE" else spec.tier.name,
                                            fontSize = 7.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (unlocked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = .42f)
                                        )
                                    }
                                }
                                repeat(4 - row.size) { Spacer(Modifier.width(68.dp)) }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            val unlocked = previewSpec?.let { SonusAvatarCatalog.unlocked(it, membershipTier, isOwner) } == true
            Button(onClick = { onApply(previewId) }, enabled = unlocked) { Text("Aplicar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun ArtistForm(
    submitLabel: String,
    initialArtist: Artist? = null,
    onSubmit: (String, DistributorId, String?, String?, String?) -> Unit
) {
    var name by rememberSaveable(initialArtist?.id) { mutableStateOf(initialArtist?.name.orEmpty()) }
    var distributor by rememberSaveable(initialArtist?.id) { mutableStateOf(initialArtist?.distributor ?: DistributorId.SOUNDON) }
    var customDistributorName by rememberSaveable(initialArtist?.id) { mutableStateOf(initialArtist?.customDistributorName.orEmpty()) }
    var lastPayoutInput by rememberSaveable(initialArtist?.id) {
        mutableStateOf(initialArtist?.lastPayoutDateIso?.let(::formatDate).orEmpty())
    }
    var scenarioId by rememberSaveable(initialArtist?.id) {
        mutableStateOf(
            initialArtist?.royaltyScenarioId
                ?: RoyaltyReferenceCatalog.defaultScenario(initialArtist?.distributor ?: DistributorId.SOUNDON)?.id
        )
    }
    var distributorExpanded by remember { mutableStateOf(false) }
    var scenarioExpanded by remember { mutableStateOf(false) }

    val manual = DistributorRules.needsManualPayoutDate(distributor)
    val parsedPayout = if (manual) parseDateInput(lastPayoutInput) else null
    val today = LocalDate.now()
    val payoutIsReasonable = parsedPayout != null && !parsedPayout.isAfter(today) && !parsedPayout.isBefore(today.minusDays(366))
    val payoutIsValid = !manual || payoutIsReasonable
    val customNameValid = distributor != DistributorId.OTHER || customDistributorName.isNotBlank()
    val scenarios = RoyaltyReferenceCatalog.scenariosFor(distributor)
    val selectedScenario = RoyaltyReferenceCatalog.resolve(distributor, scenarioId)
    val scenarioValid = scenarios.isEmpty() || selectedScenario != null
    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedTextColor = MaterialTheme.colorScheme.onSurface,
        unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
        focusedContainerColor = MaterialTheme.colorScheme.surface,
        unfocusedContainerColor = MaterialTheme.colorScheme.surface,
        cursorColor = MaterialTheme.colorScheme.primary
    )

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Nome do artista") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            colors = fieldColors,
            textStyle = TextStyle(color = MaterialTheme.colorScheme.onSurface)
        )

        Text("Distribuidora", fontWeight = FontWeight.SemiBold)
        Box {
            OutlinedButton(onClick = { distributorExpanded = true }, modifier = Modifier.fillMaxWidth()) {
                Text(DistributorRules.displayName(distributor, customDistributorName))
                Spacer(Modifier.weight(1f))
                Icon(Icons.Default.ArrowDropDown, null)
            }
            DropdownMenu(expanded = distributorExpanded, onDismissRequest = { distributorExpanded = false }) {
                DistributorId.entries.forEach { item ->
                    DropdownMenuItem(
                        text = { Text(DistributorRules.displayName(item)) },
                        onClick = {
                            distributor = item
                            scenarioId = RoyaltyReferenceCatalog.defaultScenario(item)?.id
                            distributorExpanded = false
                            if (!DistributorRules.needsManualPayoutDate(item)) lastPayoutInput = ""
                        }
                    )
                }
            }
        }

        if (distributor == DistributorId.OTHER) {
            OutlinedTextField(
                value = customDistributorName,
                onValueChange = { customDistributorName = it },
                label = { Text("Nome da distribuidora") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                colors = fieldColors,
                textStyle = TextStyle(color = MaterialTheme.colorScheme.onSurface)
            )
        }

        if (scenarios.isNotEmpty()) {
            Text("Plano / modalidade", fontWeight = FontWeight.SemiBold)
            Box {
                OutlinedButton(onClick = { scenarioExpanded = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(selectedScenario?.label ?: "Selecionar")
                    Spacer(Modifier.weight(1f))
                    Icon(Icons.Default.ArrowDropDown, null)
                }
                DropdownMenu(expanded = scenarioExpanded, onDismissRequest = { scenarioExpanded = false }) {
                    scenarios.forEach { scenario ->
                        DropdownMenuItem(
                            text = {
                                Column {
                                    Text(scenario.label, fontWeight = FontWeight.SemiBold)
                                    Text(
                                        "Artista mantém ${(scenario.artistShare * 100).roundToInt()}% • referência ${scenario.confidence.lowercase()}",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            },
                            onClick = {
                                scenarioId = scenario.id
                                scenarioExpanded = false
                            }
                        )
                    }
                }
            }
            selectedScenario?.let { scenario ->
                Text(
                    scenario.notes,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = .70f)
                )
            }
        } else if (distributor == DistributorId.OTHER) {
            Text(
                "Uma distribuidora personalizada começa com uma referência genérica de mercado e melhora quando você registra pagamentos reais.",
                style = MaterialTheme.typography.bodySmall
            )
        }

        if (manual) {
            OutlinedTextField(
                value = lastPayoutInput,
                onValueChange = { lastPayoutInput = it },
                label = { Text("Data do último pagamento/crédito") },
                placeholder = { Text("25/07/2026") },
                supportingText = {
                    Text(
                        when {
                            lastPayoutInput.isBlank() -> "Informe a referência mais recente para calcular o período recomendado."
                            parsedPayout == null -> "Use DD/MM/AAAA."
                            !payoutIsReasonable -> "Use uma data válida dos últimos 12 meses e que não esteja no futuro."
                            else -> "O período recomendado começará no dia seguinte."
                        }
                    )
                },
                isError = lastPayoutInput.isNotBlank() && !payoutIsReasonable,
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                colors = fieldColors,
                textStyle = TextStyle(color = MaterialTheme.colorScheme.onSurface)
            )
        }

        Button(
            onClick = {
                onSubmit(
                    name.trim(),
                    distributor,
                    customDistributorName.trim().takeIf { distributor == DistributorId.OTHER && it.isNotBlank() },
                    parsedPayout?.toString(),
                    scenarioId
                )
            },
            enabled = name.isNotBlank() && payoutIsValid && customNameValid && scenarioValid,
            modifier = Modifier.fillMaxWidth().height(54.dp)
        ) { Text(submitLabel) }
    }
}

@Composable
private fun CommunityPresenceBadge(state: CommunityPresenceState) {
    val borderColor = when {
        state.connected -> SignalGreen
        state.connecting -> SignalYellow
        else -> MaterialTheme.colorScheme.onSurface.copy(alpha = .28f)
    }
    val total = state.totalUsers
    val text = when {
        state.connected && state.publicCounterEnabled && total != null && total >= state.publicCounterMinimum -> {
            val rounded = when {
                total >= 1000L -> (total / 100L) * 100L
                total >= 100L -> (total / 50L) * 50L
                else -> total
            }
            "👥 +$rounded  •  🟢 ${state.onlineUsers ?: "…"}"
        }
        state.connected -> "🚀 Comunidade em crescimento"
        state.connecting -> "👥 conectando…"
        else -> "👥 —"
    }
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = .78f),
        border = BorderStroke(1.dp, borderColor.copy(alpha = .65f))
    ) {
        Text(
            text,
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 7.dp),
            fontSize = 10.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1
        )
    }
}

private enum class DistributionSection(val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    OVERVIEW("Visão geral", Icons.Default.Dashboard),
    HISTORY("Histórico", Icons.Default.History),
    ANALYTICS("Análises", Icons.Default.Assessment),
    FINANCE("Financeiro", Icons.Default.AccountBalanceWallet)
}

@Composable
private fun DistributionHubScreen(
    state: AppState,
    artist: Artist,
    hasDistributionProfile: Boolean,
    membershipTier: MembershipTier,
    isOwner: Boolean,
    communityPresence: CommunityPresenceState,
    onUpdate: () -> Unit,
    onPayment: () -> Unit,
    onGoalChange: (Double?, Long?) -> Unit,
    onSelectArtist: (String) -> Unit,
    onDeleteActivity: (String) -> Unit,
    onClearActivities: () -> Unit,
    onReplaceSnapshot: (StreamSnapshot) -> Unit,
    onDeleteSnapshot: (String, String?) -> Unit,
    onUpsertDaily: (DailyStreamRecord) -> Unit,
    onDeleteDaily: (String, String?) -> Unit,
    onGuide: () -> Unit,
    onArtistUpdate: (Artist) -> Unit,
    onPreferencesChange: (UserPreferences) -> Unit,
    onAddHistoricalPayment: (RoyaltyPayment) -> Unit,
    onAddArtist: () -> Unit,
    onEditArtist: (String) -> Unit,
    onDistributors: () -> Unit,
    onPremium: () -> Unit
) {
    var sectionName by rememberSaveable { mutableStateOf(DistributionSection.OVERVIEW.name) }
    val section = runCatching { DistributionSection.valueOf(sectionName) }.getOrDefault(DistributionSection.OVERVIEW)
    var showHeaderArtistSwitcher by remember(artist.id) { mutableStateOf(false) }

    if (!hasDistributionProfile) {
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(top = 18.dp, bottom = 32.dp)
        ) {
            item {
                Text("Distribuição & Pagamentos", fontSize = 29.sp, fontWeight = FontWeight.ExtraBold)
                Text("Seu painel de distribuição, streams, ganhos e desempenho — agora como um módulo opcional do SONUS.", color = MaterialTheme.colorScheme.onSurface.copy(alpha = .62f))
            }
            item {
                Surface(
                    shape = RoundedCornerShape(26.dp),
                    color = Color.Transparent,
                    border = BorderStroke(1.dp, PulseCyan.copy(alpha = .38f))
                ) {
                    Column(
                        Modifier.background(Brush.linearGradient(listOf(Color(0xFF071A31), Color(0xFF13284A), Color(0xFF25143D)))).padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(11.dp)
                    ) {
                        Icon(Icons.Default.Assessment, null, tint = PulseCyan, modifier = Modifier.size(36.dp))
                        Text("Use distribuidoras? Ative seu painel.", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold)
                        Text("Cadastre um artista apenas se quiser acompanhar streams, pagamentos, metas, projeções e relatórios. SONUS PLAYER e STUDIO SONUS funcionam sem isso.", color = Color.White.copy(alpha = .78f))
                        Button(onClick = onAddArtist, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.PersonAdd, null)
                            Spacer(Modifier.width(8.dp))
                            Text("Cadastrar artista e distribuidora")
                        }
                        OutlinedButton(onClick = onDistributors, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.LibraryBooks, null)
                            Spacer(Modifier.width(8.dp))
                            Text("Conhecer distribuidoras")
                        }
                    }
                }
            }
            item {
                Text("Esta área é totalmente opcional. O SONUS não exige distribuição musical para usar a suíte de criação.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .52f), textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }
        }
        return
    }

    Column(Modifier.fillMaxSize()) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.surface.copy(alpha = .74f),
            tonalElevation = 2.dp
        ) {
            Column(Modifier.padding(horizontal = 12.dp, vertical = 7.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ProfileAvatarWithTier(artist.photoPath, artist.avatarId, membershipTier, owner = isOwner, size = 40.dp)
                    Column(Modifier.weight(1f)) {
                        Text("Distribuição & Pagamentos", fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
                        Row(Modifier.clip(RoundedCornerShape(10.dp)).clickable { if (state.artists.size > 1) showHeaderArtistSwitcher = !showHeaderArtistSwitcher }.padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("${artist.name} • ${DistributorRules.displayName(artist.distributor)}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .66f), maxLines = 1)
                            if (state.artists.size > 1) Icon(Icons.Default.KeyboardArrowDown, null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurface)
                        }
                    }
                    IconButton(onClick = { onEditArtist(artist.id) }) { Icon(Icons.Default.Edit, "Editar artista", tint = MaterialTheme.colorScheme.onSurface) }
                    IconButton(onClick = onAddArtist) { Icon(Icons.Default.PersonAdd, "Adicionar artista", tint = MaterialTheme.colorScheme.onSurface) }
                    IconButton(onClick = onDistributors) { Icon(Icons.Default.LibraryBooks, "Distribuidoras", tint = MaterialTheme.colorScheme.onSurface) }
                }
                AnimatedVisibility(visible = showHeaderArtistSwitcher && state.artists.size > 1) {
                    QuickArtistSwitcher(artists = state.artists, selectedArtistId = artist.id, onSelect = { id -> onSelectArtist(id); showHeaderArtistSwitcher = false })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.fillMaxWidth()) {
                    DistributionSection.entries.forEach { item ->
                        val selected = section == item
                        Surface(Modifier.weight(1f).clickable { sectionName = item.name }, shape = RoundedCornerShape(11.dp), color = if(selected) MaterialTheme.colorScheme.primary.copy(alpha=.28f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.30f), border=BorderStroke(1.dp, if(selected) MaterialTheme.colorScheme.primary.copy(alpha=.55f) else MaterialTheme.colorScheme.outline.copy(alpha=.28f))) {
                            Column(Modifier.padding(vertical=7.dp, horizontal=2.dp), horizontalAlignment=Alignment.CenterHorizontally) { Icon(item.icon,null,modifier=Modifier.size(14.dp), tint = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha=.88f)); Text(item.title,fontSize=9.sp,maxLines=1, color = MaterialTheme.colorScheme.onSurface) }
                        }
                    }
                }
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (section) {
                DistributionSection.OVERVIEW -> DashboardScreen(
                    state = state,
                    artist = artist,
                    membershipTier = membershipTier,
                    isOwner = isOwner,
                    onUpdate = onUpdate,
                    onPayment = onPayment,
                    onAnalytics = { sectionName = DistributionSection.ANALYTICS.name },
                    onGoalChange = onGoalChange,
                    onSelectArtist = onSelectArtist,
                    communityPresence = communityPresence
                )
                DistributionSection.HISTORY -> HistoryScreen(
                    state, artist, onReplaceSnapshot, onDeleteSnapshot, onUpsertDaily, onDeleteDaily
                )
                DistributionSection.ANALYTICS -> AnalyticsScreen(state, artist, membershipTier, isOwner, onGuide)
                DistributionSection.FINANCE -> {
                    val financeAllowed = isOwner || commercialTier(membershipTier).ordinal >= MembershipTier.PRATA.ordinal
                    if (financeAllowed) {
                        FinanceScreen(state, artist, membershipTier, isOwner, onArtistUpdate, onPreferencesChange, onAddHistoricalPayment)
                    } else {
                        Box(Modifier.fillMaxSize().padding(18.dp), contentAlignment = Alignment.Center) {
                            Surface(
                                shape = RoundedCornerShape(24.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .72f),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = .24f))
                            ) {
                                Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Icon(Icons.Default.Lock, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(34.dp))
                                    Text("Financeiro e projeções", fontWeight = FontWeight.ExtraBold, fontSize = 19.sp)
                                    Text("Disponível no plano Prata ou superior.", textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .64f))
                                    Button(onClick = onPremium, modifier = Modifier.fillMaxWidth()) { Text("Conhecer planos") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DashboardScreen(
    state: AppState,
    artist: Artist,
    membershipTier: MembershipTier,
    isOwner: Boolean,
    onUpdate: () -> Unit,
    onPayment: () -> Unit,
    onAnalytics: () -> Unit,
    onGoalChange: (Double?, Long?) -> Unit,
    onSelectArtist: (String) -> Unit,
    communityPresence: CommunityPresenceState
) {
    val today = LocalDate.now()
    val cycle = DistributorRules.cycleFor(artist, today)
    val allArtistSnapshots = state.snapshots.filter { it.artistId == artist.id }
    val cycleSnapshots = allArtistSnapshots.filter { snapshotInCycle(it, cycle) }
    val payments = state.payments.filter { it.artistId == artist.id }
    val latestRealPayment = payments.filterNot { it.isRetroactive }.maxByOrNull { it.recordedAtEpochMillis }
    val rpm = RoyaltyEngine.personalizedRpm(artist, payments)
    val manualDailyRecords = state.dailyStreamRecords.filter { it.artistId == artist.id }
    val cycleDailyRecords = manualDailyRecords.filter { record ->
        runCatching {
            val d = LocalDate.parse(record.dateIso)
            !d.isBefore(LocalDate.parse(cycle.startIso)) && !d.isAfter(LocalDate.parse(cycle.endIso))
        }.getOrDefault(false)
    }
    val forecast = RoyaltyEngine.forecast(
        cycleSnapshots,
        cycleDailyRecords,
        LocalDate.parse(cycle.startIso),
        LocalDate.parse(cycle.endIso),
        today,
        rpm,
        entryMode = resolvedStreamEntryMode(artist),
        cycleId = artist.financialCycleId
    )
    val health = HealthEngine.calculateFromSnapshots(
        allArtistSnapshots, manualDailyRecords, cycle = cycle, referenceDate = today,
        entryMode = resolvedStreamEntryMode(artist), cycleId = artist.financialCycleId
    )
    val accuracy = RoyaltyEngine.accuracy(payments)
    val analyticsDailyEntries = StreamMetricsEngine.cycleMetrics(
        cycleSnapshots,
        cycleDailyRecords,
        LocalDate.parse(cycle.startIso),
        LocalDate.parse(cycle.endIso),
        today,
        entryMode = resolvedStreamEntryMode(artist),
        cycleId = artist.financialCycleId
    ).dailyEntries
    val trend = AnalyticsEngine.trendFromDailyEntries(analyticsDailyEntries, state.preferences.trendWindowDays)
    val cycleStartDate = LocalDate.parse(cycle.startIso)
    val cycleNotStarted = today.isBefore(cycleStartDate)
    val daysRemaining = ChronoUnit.DAYS.between(today, LocalDate.parse(cycle.endIso)).coerceAtLeast(0)
    val latestSnapshot = allArtistSnapshots.maxWithOrNull(snapshotComparator())
    val latestDailyRecord = manualDailyRecords.maxWithOrNull(compareBy<DailyStreamRecord> { it.dateIso }.thenBy { it.recordedAtEpochMillis })
    val latestDataDate = listOfNotNull(
        latestSnapshot?.dateIso?.let { runCatching { LocalDate.parse(it) }.getOrNull() },
        latestDailyRecord?.dateIso?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
    ).maxOrNull()
    val latestSnapshotByRegistration = allArtistSnapshots.maxByOrNull { it.recordedAtEpochMillis }
    val latestDailyByRegistration = manualDailyRecords.maxByOrNull { it.recordedAtEpochMillis }
    val latestUpdateEpoch = maxOf(
        latestSnapshotByRegistration?.recordedAtEpochMillis ?: 0L,
        latestDailyByRegistration?.recordedAtEpochMillis ?: 0L
    )
    val latestUpdateDateIso = when {
        latestUpdateEpoch <= 0L -> latestDataDate?.toString()
        (latestDailyByRegistration?.recordedAtEpochMillis ?: Long.MIN_VALUE) >= (latestSnapshotByRegistration?.recordedAtEpochMillis ?: Long.MIN_VALUE) -> latestDailyByRegistration?.dateIso
        else -> latestSnapshotByRegistration?.dateIso
    }
    val dailyEntries = analyticsDailyEntries.takeLast(7)
    val observedDailyAverage = analyticsDailyEntries.takeIf { it.isNotEmpty() }?.map { it.streams.toDouble() }?.average()
        ?: forecast.cycleDailyAverage
    val observedRecentAverage = analyticsDailyEntries.takeLast(3).takeIf { it.isNotEmpty() }?.map { it.streams.toDouble() }?.average()
        ?: forecast.recentDailyAverage
    val confidence = when {
        accuracy.accuracyPercent != null -> "${accuracy.label} • ${formatPercent(accuracy.accuracyPercent)}"
        else -> "${forecast.confidence} • ref. ${RoyaltyReferenceCatalog.referenceConfidence(artist)}"
    }
    val todayStreams = analyticsDailyEntries.lastOrNull { it.dateIso == today.toString() }?.streams ?: 0L
    val goalDays = (daysRemaining + 1L).coerceAtLeast(1L)
    val dailyGoalStreams = artist.goalStreams?.takeIf { it > forecast.currentStreams }?.let {
        kotlin.math.ceil((it - forecast.currentStreams).toDouble() / goalDays.toDouble()).toLong()
    }
    val daysSinceUpdate = latestDataDate?.let { ChronoUnit.DAYS.between(it, today).coerceAtLeast(0) }
    val homeAlerts = buildList {
        if (latestDataDate == null) add("Ainda não há uma atualização de streams neste artista.")
        else if ((daysSinceUpdate ?: 0L) >= 2L) add("${daysSinceUpdate} dias sem atualização de streams.")
        if (health.missingDays >= 2) add("${health.missingDays} dias sem dados no histórico recente.")
        if (daysRemaining <= 1L) add("Fechamento do ciclo muito próximo: ${formatDate(cycle.endIso)}.")
        if ((trend.percentChange ?: 0.0) <= -20.0) add("Queda forte de ${formatSignedPercent(trend.percentChange ?: 0.0)} no ritmo recente.")
        val moneyBehind = artist.goalBrl?.takeIf { it > 0.0 }?.let { forecast.projectedBrl / it < .80 } ?: false
        val streamsBehind = artist.goalStreams?.takeIf { it > 0L }?.let { forecast.projectedStreams.toDouble() / it < .80 } ?: false
        if (moneyBehind || streamsBehind) add("A projeção atual está abaixo de 80% de uma das metas do ciclo.")
    }
    val nextAction = when {
        latestDataDate == null -> "Registre os streams atuais para iniciar o acompanhamento deste artista."
        (daysSinceUpdate ?: 0L) >= 1L -> "Atualize os streams de hoje para recalcular previsão, saúde e ritmo."
        dailyGoalStreams != null && todayStreams < dailyGoalStreams ->
            "Faltam ${formatNumber((dailyGoalStreams - todayStreams).coerceAtLeast(0L))} streams para cumprir a meta de hoje."
        dailyGoalStreams != null -> "Meta diária no ritmo certo. Mantenha o desempenho de hoje. ✅"
        artist.goalStreams == null -> "Defina uma meta de streams para o SONUS calcular sua meta diária."
        else -> "Mantenha os registros atualizados para melhorar as projeções do ciclo."
    }
    var showGoalDialog by remember { mutableStateOf(false) }
    var showArtistSwitcher by remember(artist.id) { mutableStateOf(false) }

    if (showGoalDialog) {
        GoalDialog(
            currentGoalBrl = artist.goalBrl,
            currentGoalStreams = artist.goalStreams,
            onDismiss = { showGoalDialog = false },
            onSave = { goalBrl, goalStreams ->
                onGoalChange(goalBrl, goalStreams)
                showGoalDialog = false
            }
        )
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(13.dp),
        contentPadding = PaddingValues(top = 18.dp, bottom = 32.dp)
    ) {

        item { LivePulseCard(state = state, artist = artist, tier = membershipTier, owner = isOwner) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Button(onClick = onUpdate, modifier = Modifier.weight(1f).height(42.dp)) { Icon(Icons.Default.AddChart,null,Modifier.size(17.dp)); Spacer(Modifier.width(5.dp)); Text("Atualizar dados",fontSize=12.sp) }
                OutlinedButton(onClick = onPayment, modifier = Modifier.weight(1f).height(42.dp)) { Icon(Icons.Default.Paid,null,Modifier.size(17.dp)); Spacer(Modifier.width(5.dp)); Text("Recebi pagamento",fontSize=12.sp) }
            }
        }

        latestRealPayment?.let { payment ->
            item {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.primary.copy(alpha = .07f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = .14f))
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Paid, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(9.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                "Recebido ${money(payment.amountBrl)} em ${formatDate(payment.paidDateIso)}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                            Text(
                                "Ciclo atual iniciado em ${formatDate(payment.newCycleStartIso ?: artist.financialCycleStartIso ?: payment.paidDateIso)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = .62f)
                            )
                        }
                    }
                }
            }
        }

        item {
            BalanceHeroCard(
                forecast = forecast,
                goalBrl = artist.goalBrl,
                goalStreams = artist.goalStreams,
                daysRemaining = daysRemaining,
                todayStreams = todayStreams,
                dailyGoalStreams = dailyGoalStreams,
                onGoalClick = { showGoalDialog = true },
                onUpdate = onUpdate,
                onPayment = onPayment
            )
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OrbMetricCard(
                    modifier = Modifier.weight(1f),
                    title = "Previsão do ciclo",
                    value = money(forecast.projectedBrl),
                    subtitle = "${formatNumber(forecast.projectedStreams)} streams",
                    signalColor = forecastSignalColor(forecast.projectedBrl, artist.goalBrl),
                    icon = Icons.Default.AutoGraph,
                    animatedNumber = forecast.projectedBrl,
                    numberFormatter = { money(it) }
                )
                HealthOrbCard(Modifier.weight(1f), health)
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                TrendOrbCard(Modifier.weight(1f), trend)
                OrbMetricCard(
                    modifier = Modifier.weight(1f),
                    title = "Próximo fechamento",
                    value = "$daysRemaining dia(s)",
                    subtitle = if (cycle.isEstimatedRule) "Referência estimada" else formatDate(cycle.endIso),
                    signalColor = closingSignalColor(daysRemaining),
                    icon = Icons.Default.Event,
                    animatedNumber = daysRemaining.toDouble(),
                    numberFormatter = { "${it.roundToInt()} dia(s)" }
                )
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OrbMetricCard(
                    modifier = Modifier.weight(1f),
                    title = "Média diária",
                    value = formatNumber(observedDailyAverage.roundToLongSafe()),
                    subtitle = "streams/dia",
                    signalColor = movementSignalColor(trend.direction),
                    icon = Icons.Default.Speed,
                    animatedNumber = observedDailyAverage,
                    numberFormatter = { formatNumber(it.roundToLongSafe()) }
                )
                OrbMetricCard(
                    modifier = Modifier.weight(1f),
                    title = "Ritmo recente",
                    value = formatNumber(observedRecentAverage.roundToLongSafe()),
                    subtitle = "streams/dia",
                    signalColor = movementSignalColor(trend.direction),
                    icon = Icons.Default.Bolt,
                    animatedNumber = observedRecentAverage,
                    numberFormatter = { formatNumber(it.roundToLongSafe()) }
                )
            }
        }

        if (dailyEntries.isNotEmpty()) {
        }

        item { WhatChangedCard(state, artist) }

        if (state.preferences.showSmartSummary) {
            item {
                SmartSummaryCard(
                    AnalyticsEngine.smartSummary(trend, forecast, health, daysRemaining),
                    onAnalytics = onAnalytics
                )
            }
        }

        if (state.preferences.showAdvancedForecast && forecast.currentStreams > 0 && !state.preferences.dashboardCompact) {
            item { ForecastRangeCard(forecast, daysRemaining, artist.goalBrl) }
        }

        item { NextActionCard(nextAction) }

        if (homeAlerts.isNotEmpty()) {
            item { HomeAlertsCard(homeAlerts) }
        }

        item {
            ProjectXRayCard(
                health = health,
                trend = trend,
                forecast = forecast,
                goalBrl = artist.goalBrl,
                goalStreams = artist.goalStreams,
                daysRemaining = daysRemaining
            )
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard(
                    modifier = Modifier.weight(1f),
                    title = "Última atualização",
                    value = formatRecordedTime(latestUpdateEpoch),
                    subtitle = latestUpdateDateIso?.let(::formatDate) ?: "Ainda sem dados"
                )
                MetricCard(
                    modifier = Modifier.weight(1f),
                    title = "Precisão",
                    value = confidence,
                    subtitle = if (payments.isEmpty()) "Aprende com pagamentos reais" else "${payments.size} pagamento(s)"
                )
            }
        }

        item { RecommendedPeriodNotice(cycle = cycle, today = today, cycleNotStarted = cycleNotStarted) }
    }
}

@Composable
private fun GoalDialog(
    currentGoalBrl: Double?,
    currentGoalStreams: Long?,
    onDismiss: () -> Unit,
    onSave: (Double?, Long?) -> Unit
) {
    var moneyInput by remember(currentGoalBrl) {
        mutableStateOf(currentGoalBrl?.let { String.format(Locale("pt", "BR"), "%.2f", it) }.orEmpty())
    }
    var streamsInput by remember(currentGoalStreams) { mutableStateOf(currentGoalStreams?.toString().orEmpty()) }
    val parsedMoney = moneyInput.takeIf { it.isNotBlank() }?.let(::parseMoneyInput)
    val parsedStreams = streamsInput.filter(Char::isDigit).toLongOrNull()
    val invalidMoney = moneyInput.isNotBlank() && (parsedMoney == null || parsedMoney <= 0.0)
    val invalidStreams = streamsInput.isNotBlank() && (parsedStreams == null || parsedStreams <= 0L)
    val hasGoal = (parsedMoney != null && parsedMoney > 0.0) || (parsedStreams != null && parsedStreams > 0L)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (currentGoalBrl == null && currentGoalStreams == null) "Adicionar metas" else "Editar metas") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Use uma meta financeira, de streams, ou as duas para acompanhar o ritmo até o fechamento.")
                OutlinedTextField(
                    value = moneyInput,
                    onValueChange = { moneyInput = it },
                    label = { Text("Meta financeira") },
                    prefix = { Text("R$ ") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    isError = invalidMoney
                )
                OutlinedTextField(
                    value = streamsInput,
                    onValueChange = { streamsInput = it.filter(Char::isDigit) },
                    label = { Text("Meta de streams") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    isError = invalidStreams
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onSave(parsedMoney?.takeIf { it > 0.0 }, parsedStreams?.takeIf { it > 0L }) },
                enabled = hasGoal && !invalidMoney && !invalidStreams
            ) { Text("Salvar") }
        },
        dismissButton = {
            Row {
                if (currentGoalBrl != null || currentGoalStreams != null) {
                    TextButton(onClick = { onSave(null, null) }) { Text("Remover metas") }
                }
                TextButton(onClick = onDismiss) { Text("Cancelar") }
            }
        }
    )
}

@Composable
private fun BalanceHeroCard(
    forecast: ForecastResult,
    goalBrl: Double?,
    goalStreams: Long?,
    daysRemaining: Long,
    todayStreams: Long,
    dailyGoalStreams: Long?,
    onGoalClick: () -> Unit,
    onUpdate: () -> Unit,
    onPayment: () -> Unit
) {
    // Pulso ao Vivo: acrescenta ao saldo apenas uma estimativa intradiária visual.
    // Ao entrar um registro real, o forecast é recalculado e a parcela ao vivo se reconcilia naturalmente.
    val liveNow by produceState(System.currentTimeMillis()) { while(true){ value=System.currentTimeMillis(); delay(30_000) } }
    val secondsToday = java.time.LocalTime.now().toSecondOfDay().coerceAtLeast(0) + (liveNow * 0L).toInt()
    val dayFraction = (secondsToday / 86400.0).coerceIn(0.0,1.0)
    val perStreamBrl = if(forecast.currentStreams>0) forecast.estimatedCurrentBrl / forecast.currentStreams.toDouble() else 0.0
    val pulseEstimatedBrl = forecast.recentDailyAverage.coerceAtLeast(0.0) * dayFraction * perStreamBrl
    val liveEstimatedBalance = forecast.estimatedCurrentBrl + pulseEstimatedBrl
    val moneyProgressPercent = goalBrl?.takeIf { it > 0.0 }?.let { liveEstimatedBalance / it * 100.0 }
    val streamProgressPercent = goalStreams?.takeIf { it > 0L }?.let { forecast.currentStreams.toDouble() / it * 100.0 }
    val moneyStatus = goalBrl?.takeIf { it > 0.0 }?.let {
        val projectedRatio = forecast.projectedBrl / it
        when {
            projectedRatio >= 1.0 -> "Meta financeira no caminho certo"
            projectedRatio >= .85 -> "Perto da meta • vale acelerar"
            else -> "Ritmo financeiro abaixo da meta"
        }
    }
    val streamStatus = goalStreams?.takeIf { it > 0L }?.let {
        val projectedRatio = forecast.projectedStreams.toDouble() / it
        when {
            projectedRatio >= 1.0 -> "Meta de streams no caminho certo"
            projectedRatio >= .85 -> "Perto da meta • vale acelerar"
            else -> "Ritmo de streams abaixo da meta"
        }
    }
    val goalDays = (daysRemaining + 1L).coerceAtLeast(1L)
    val moneyPerDayNeeded = goalBrl?.takeIf { it > forecast.estimatedCurrentBrl }?.let {
        (it - liveEstimatedBalance) / goalDays.toDouble()
    }
    val streamsPerDayNeeded = goalStreams?.takeIf { it > forecast.currentStreams }?.let {
        kotlin.math.ceil((it - forecast.currentStreams).toDouble() / goalDays.toDouble()).toLong()
    }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .44f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = .18f))
    ) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            HeroGoalSection(
                title = "Saldo estimado",
                icon = Icons.Default.Paid,
                primaryValue = money(liveEstimatedBalance),
                primaryValueNumber = liveEstimatedBalance,
                moneyValue = true,
                goalLabel = goalBrl?.let { "Meta ${money(it)}" } ?: "Meta financeira não definida",
                progressPercent = moneyProgressPercent,
                missingLabel = goalBrl?.let { "Faltam ${money((it - liveEstimatedBalance).coerceAtLeast(0.0))}" },
                paceLabel = moneyPerDayNeeded?.let { "${money(it)}/dia necessários" },
                status = moneyStatus,
                onGoalClick = onGoalClick,
                emphasized = true
            )

            HeroGoalSection(
                title = "Meta de streams",
                icon = Icons.Default.GraphicEq,
                primaryValue = "${formatNumber(forecast.currentStreams)} streams",
                primaryValueNumber = forecast.currentStreams.toDouble(),
                moneyValue = false,
                goalLabel = goalStreams?.let { "Meta ${formatNumber(it)} streams" } ?: "Meta de streams não definida",
                progressPercent = streamProgressPercent,
                missingLabel = goalStreams?.let { "Faltam ${formatNumber((it - forecast.currentStreams).coerceAtLeast(0L))}" },
                paceLabel = streamsPerDayNeeded?.let { "${formatNumber(it)}/dia necessários" },
                status = streamStatus,
                dailyGoalLabel = dailyGoalStreams?.let { "Meta de hoje ${formatNumber(it)} • feito ${formatNumber(todayStreams)}" },
                dailyProgressPercent = dailyGoalStreams?.takeIf { it > 0L }?.let { todayStreams.toDouble() / it * 100.0 },
                onGoalClick = onGoalClick,
                emphasized = false
            )

        }
    }
}

@Composable
private fun HeroGoalSection(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    primaryValue: String,
    primaryValueNumber: Double,
    moneyValue: Boolean,
    goalLabel: String,
    progressPercent: Double?,
    missingLabel: String?,
    paceLabel: String?,
    status: String?,
    dailyGoalLabel: String? = null,
    dailyProgressPercent: Double? = null,
    onGoalClick: () -> Unit,
    emphasized: Boolean
) {
    val targetColor = homeGoalProgressColor(progressPercent ?: 0.0, progressPercent != null)
    // Transição curta apenas quando o estágio da meta muda; nada de gradiente animando sem parar.
    val baseColor by animateColorAsState(targetColor, tween(420), label = "hero-color")
    val topGlow = lerp(baseColor, Color.White, .13f)
    val lowerTone = lerp(baseColor, Color(0xFF11141C), .38f)
    val bottomTone = lerp(baseColor, Color(0xFF090C13), .54f)
    val heroBrush = Brush.linearGradient(listOf(topGlow, baseColor, lowerTone, bottomTone))
    val progress by animateFloatAsState(((progressPercent ?: 0.0) / 100.0).coerceIn(0.0, 1.0).toFloat(), tween(520), label = "hero-bar")
    val dailyProgress by animateFloatAsState(((dailyProgressPercent ?: 0.0) / 100.0).coerceIn(0.0, 1.0).toFloat(), tween(720), label = "hero-daily-bar")
    val shape = RoundedCornerShape(22.dp)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(heroBrush)
            .border(1.dp, Color.White.copy(alpha = .14f), shape)
            .clickable(onClick = onGoalClick)
    ) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, tint = Color.White.copy(alpha = .94f), modifier = Modifier.size(19.dp))
                Spacer(Modifier.width(7.dp))
                Text(title, color = Color.White.copy(alpha = .90f), fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.weight(1f))
                HeroInfoChip(goalLabel)
            }

            if (moneyValue) {
                AnimatedMoneyText(primaryValueNumber, Color.White, if (emphasized) 43.sp else 30.sp)
            } else {
                val animated by animateFloatAsState(primaryValueNumber.toFloat(), tween(760), label = "hero-stream-counter")
                Text("${formatNumber(animated.roundToLong())} streams", style = digitalValueStyle(Color.White, if (emphasized) 34.sp else 31.sp))
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                HeroInfoChip(missingLabel ?: "Toque para adicionar uma meta")
                Spacer(Modifier.weight(1f))
                if (progressPercent != null) AnimatedPercentText(progressPercent, Color.White)
            }

            GoalProgressBar(progress = progress, foreground = Color.White.copy(alpha = .92f))

            if (status != null || paceLabel != null) {
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    status?.let { HeroInfoChip(it, Modifier.weight(1f)) }
                    paceLabel?.let { HeroInfoChip(it) }
                }
            }

            if (dailyGoalLabel != null) {
                HorizontalDivider(color = Color.White.copy(alpha = .16f))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Today, null, tint = Color.White.copy(alpha = .90f), modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Meta de hoje", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.weight(1f))
                    Text("${(dailyProgressPercent ?: 0.0).coerceAtLeast(0.0).roundToInt()}%", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                }
                Text(dailyGoalLabel.removePrefix("Meta de hoje "), color = Color.White.copy(alpha = .90f), style = MaterialTheme.typography.bodySmall)
                GoalProgressBar(progress = dailyProgress, foreground = Color.White.copy(alpha = .82f), height = 6.dp)
            }
        }
    }
}

@Composable
private fun GoalProgressBar(progress: Float, foreground: Color, height: androidx.compose.ui.unit.Dp = 8.dp) {
    Box(
        Modifier.fillMaxWidth().height(height).clip(RoundedCornerShape(50)).background(Color.Black.copy(alpha = .24f))
    ) {
        if (progress > 0f) {
            Box(
                Modifier.fillMaxHeight().fillMaxWidth(progress).clip(RoundedCornerShape(50)).background(foreground)
            )
        }
    }
}

@Composable
private fun HeroInfoChip(text: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(9.dp),
        color = Color.Black.copy(alpha = .22f),
        border = BorderStroke(1.dp, Color.White.copy(alpha = .12f))
    ) {
        Text(
            text,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
            color = Color.White.copy(alpha = .96f),
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.SemiBold,
            maxLines = 2
        )
    }
}

@Composable
private fun QuickArtistSwitcher(
    artists: List<Artist>,
    selectedArtistId: String,
    onSelect: (String) -> Unit
) {
    val ordered = artists.sortedBy { it.name.lowercase(Locale.getDefault()) }
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .55f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = .18f))
    ) {
        LazyRow(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 9.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(ordered, key = { it.id }) { item ->
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.widthIn(min = 66.dp, max = 82.dp).clickable { onSelect(item.id) }
                ) {
                    Surface(
                        shape = CircleShape,
                        border = BorderStroke(
                            if (item.id == selectedArtistId) 2.dp else 1.dp,
                            if (item.id == selectedArtistId) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = .18f)
                        )
                    ) {
                        ArtistAvatar(photoPath = item.photoPath, avatarId = item.avatarId, size = 46.dp, fallbackToLogo = true)
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        item.name,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = if (item.id == selectedArtistId) FontWeight.Bold else FontWeight.Medium,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
private fun NextActionCard(message: String) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(17.dp),
        color = MaterialTheme.colorScheme.primary.copy(alpha = .10f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = .28f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 13.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary.copy(alpha = .18f)) {
                Icon(Icons.Default.Flag, null, modifier = Modifier.padding(7.dp).size(18.dp), tint = MaterialTheme.colorScheme.primary)
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("Próxima ação", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                Text(message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .72f))
            }
        }
    }
}

@Composable
private fun HomeAlertsCard(alerts: List<String>) {
    var expanded by remember { mutableStateOf(false) }
    Surface(
        modifier = Modifier.fillMaxWidth().clickable { expanded = !expanded },
        shape = RoundedCornerShape(17.dp),
        color = SignalOrange.copy(alpha = .10f),
        border = BorderStroke(1.dp, SignalOrange.copy(alpha = .34f))
    ) {
        Column(Modifier.padding(horizontal = 13.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Warning, null, tint = SignalOrange, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(7.dp))
                Text("${alerts.size} alerta(s)", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text(if (expanded) "Ocultar" else "Ver", color = SignalOrange, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
            }
            if (!expanded) {
                Text(alerts.first(), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .70f), maxLines = 1)
            }
            AnimatedVisibility(expanded) {
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    alerts.forEach { alert ->
                        Row(verticalAlignment = Alignment.Top) {
                            Text("•", color = SignalOrange, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.width(6.dp))
                            Text(alert, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProjectXRayCard(
    health: HealthResult,
    trend: TrendResult,
    forecast: ForecastResult,
    goalBrl: Double?,
    goalStreams: Long?,
    daysRemaining: Long
) {
    val statusColor = when {
        health.scoredDays == 0 -> SignalBlack
        trend.direction > 0 && health.performancePercent >= 55.0 -> SignalGreen
        trend.direction < 0 || health.performancePercent < 40.0 -> SignalOrange
        else -> SignalBlue
    }
    val headline = when {
        health.scoredDays == 0 -> "Base em formação"
        trend.direction > 0 && health.performancePercent >= 70.0 -> "Projeto acelerando"
        trend.direction > 0 -> "Ritmo em evolução"
        trend.direction < 0 -> "Atenção ao ritmo"
        else -> "Projeto estável"
    }
    val moneyGoalText = goalBrl?.takeIf { it > 0.0 }?.let { goal ->
        val pct = (forecast.projectedBrl / goal * 100.0).coerceAtLeast(0.0)
        "Meta financeira projetada em ${pct.roundToInt()}%"
    }
    val streamGoalText = goalStreams?.takeIf { it > 0L }?.let { goal ->
        val pct = (forecast.projectedStreams.toDouble() / goal.toDouble() * 100.0).coerceAtLeast(0.0)
        "Meta de streams projetada em ${pct.roundToInt()}%"
    }
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        color = statusColor.copy(alpha = .10f),
        border = BorderStroke(1.dp, statusColor.copy(alpha = .34f))
    ) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Radar, null, tint = statusColor)
                Spacer(Modifier.width(8.dp))
                Text("Raio-X do Projeto", fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                PremiumFeatureMark(MembershipTier.PRATA)
            }
            Text(headline, color = statusColor, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(
                buildString {
                    append("Saúde ${health.score} • ${trend.label}")
                    trend.percentChange?.let { append(" ${formatSignedPercent(it)}") }
                    append(" • $daysRemaining dia(s) restantes")
                },
                style = MaterialTheme.typography.bodySmall
            )
            moneyGoalText?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .72f)) }
            streamGoalText?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .72f)) }
            Text("Disponível no Prata+ • incluído durante o teste de 7 dias", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .46f))
        }
    }
}

@Composable
private fun AnimatedMoneyText(value: Double, color: Color, fontSize: androidx.compose.ui.unit.TextUnit) {
    val animated by animateFloatAsState(value.toFloat(), tween(760), label = "money-counter")
    Text(money(animated.toDouble()), style = digitalValueStyle(color, fontSize))
}

@Composable
private fun AnimatedLongText(
    value: Long,
    suffix: String = "",
    color: Color,
    fontSize: androidx.compose.ui.unit.TextUnit
) {
    val animated by animateFloatAsState(value.toFloat(), tween(700), label = "long-counter")
    Text("${formatNumber(animated.roundToLong())}$suffix", style = digitalValueStyle(color, fontSize))
}

@Composable
private fun AnimatedPercentText(value: Double, color: Color) {
    val animated by animateFloatAsState(value.toFloat(), tween(720), label = "percent-counter")
    Text("${animated.roundToInt()}%", style = digitalValueStyle(color, 17.sp))
}

@Composable
private fun OrbMetricCard(
    modifier: Modifier,
    title: String,
    value: String,
    subtitle: String,
    signalColor: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    animatedNumber: Double? = null,
    numberFormatter: ((Double) -> String)? = null
) {
    val organicShape = RoundedCornerShape(topStart = 46.dp, topEnd = 70.dp, bottomEnd = 50.dp, bottomStart = 64.dp)
    // A cor só anima quando o dado muda. Não existe mais animação infinita durante a rolagem.
    val animatedSignal by animateColorAsState(signalColor, tween(420), label = "orb-color")
    val highlight = lerp(animatedSignal, Color.White, .10f)
    val deep = lerp(animatedSignal, Color(0xFF10141E), .58f)
    val animatedMetric = if (animatedNumber != null) {
        animateFloatAsState(animatedNumber.toFloat(), tween(720), label = "orb-number").value.toDouble()
    } else null

    Box(
        modifier = modifier
            .aspectRatio(1.56f)
            .clip(organicShape)
            .background(Brush.linearGradient(listOf(highlight.copy(alpha = .96f), animatedSignal.copy(alpha = .91f), deep, Color(0xFF11141C))))
            .border(1.dp, Color.Black.copy(alpha = .34f), organicShape)
            .padding(horizontal = 13.dp, vertical = 12.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                Icon(icon, null, tint = Color.White.copy(alpha = .95f), modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(5.dp))
                Text(
                    title,
                    color = Color.White.copy(alpha = .92f),
                    style = MaterialTheme.typography.labelSmall,
                    textAlign = TextAlign.Center,
                    maxLines = 2
                )
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    animatedMetric?.let { numberFormatter?.invoke(it) } ?: value,
                    style = digitalValueStyle(Color.White, 18.sp),
                    textAlign = TextAlign.Center,
                    maxLines = 2
                )
                Text(
                    subtitle,
                    color = Color.White.copy(alpha = .84f),
                    style = MaterialTheme.typography.labelSmall,
                    textAlign = TextAlign.Center,
                    maxLines = 2
                )
            }
        }
    }
}

@Composable
private fun HealthOrbCard(modifier: Modifier, health: HealthResult) {
    val targetAccent = healthPerformanceColor(health.performancePercent, health.scoredDays == 0)
    val accent by animateColorAsState(targetAccent, tween(850), label = "health-color")
    val progress by animateFloatAsState((health.performancePercent / 100.0).toFloat().coerceIn(0f, 1f), tween(850), label = "health-progress")
    val animatedScore by animateFloatAsState(health.score.toFloat(), tween(760), label = "health-score")
    Box(modifier = modifier.aspectRatio(1.56f), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxHeight(.89f).aspectRatio(1f)) {
            val width = 9.dp.toPx()
            drawCircle(color = accent.copy(alpha = .18f), style = androidx.compose.ui.graphics.drawscope.Stroke(width = width))
            drawArc(
                color = accent,
                startAngle = -90f,
                sweepAngle = 360f * progress,
                useCenter = false,
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = width, cap = androidx.compose.ui.graphics.StrokeCap.Round)
            )
        }
        Surface(
            modifier = Modifier.fillMaxHeight(.71f).aspectRatio(1f),
            shape = CircleShape,
            color = accent.copy(alpha = .17f),
            border = BorderStroke(1.dp, Color.Black.copy(alpha = .26f))
        ) {
            Column(
                Modifier.padding(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("Saúde", color = MaterialTheme.colorScheme.onSurface.copy(alpha = .72f), style = MaterialTheme.typography.labelSmall)
                Text(animatedScore.roundToInt().toString(), style = digitalValueStyle(MaterialTheme.colorScheme.onSurface, 24.sp))
                Text(health.label, style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center, maxLines = 1)
                Text("${health.score}/${health.possiblePoints} possíveis", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .55f), textAlign = TextAlign.Center, maxLines = 1)
            }
        }
    }
}

@Composable
private fun TrendOrbCard(modifier: Modifier, trend: TrendResult) {
    val color = movementSignalColor(trend.direction)
    val icon = when (trend.direction) {
        1 -> Icons.Default.TrendingUp
        -1 -> Icons.Default.TrendingDown
        else -> Icons.Default.TrendingFlat
    }
    val value = trend.percentChange?.let(::formatSignedPercent) ?: if (trend.sampleCount > 0) "Coletando" else "Sem dados"
    OrbMetricCard(
        modifier = modifier,
        title = "Tendência",
        value = value,
        subtitle = trend.label,
        signalColor = color,
        icon = icon,
        animatedNumber = trend.percentChange,
        numberFormatter = { formatSignedPercent(it) }
    )
}

@Composable
private fun ForecastRangeCard(forecast: ForecastResult, daysRemaining: Long, goalBrl: Double? = null) {
    Card {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Faixa da previsão", fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ForecastSegment(Modifier.weight(1f), "Conservadora", forecast.conservativeBrl, goalBrl, SignalOrange)
                ForecastSegment(Modifier.weight(1f), "Principal", forecast.projectedBrl, goalBrl, SignalBlue)
                ForecastSegment(Modifier.weight(1f), "Otimista", forecast.optimisticBrl, goalBrl, SignalGreen)
            }
            Text(
                "Confiança: ${forecast.confidence} • faltam $daysRemaining dia(s)",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = .68f)
            )
        }
    }
}

@Composable
private fun ForecastSegment(
    modifier: Modifier,
    title: String,
    amount: Double,
    goalBrl: Double?,
    fallbackColor: Color
) {
    val color = if (goalBrl != null && goalBrl > 0.0) goalProgressColor(amount / goalBrl * 100.0) else fallbackColor
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = color.copy(alpha = .22f),
        border = BorderStroke(1.dp, color.copy(alpha = .75f))
    ) {
        Column(
            Modifier.padding(horizontal = 8.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Text(title, style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center)
            Text(money(amount), style = digitalValueStyle(MaterialTheme.colorScheme.onSurface, 15.sp), textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun SmartSummaryCard(text: String, onAnalytics: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AutoAwesome, null)
                Spacer(Modifier.width(8.dp))
                Text("Resumo inteligente", fontWeight = FontWeight.Bold)
            }
            Text(text)
            TextButton(onClick = onAnalytics, contentPadding = PaddingValues(0.dp)) {
                Text("Ver análises completas")
                Spacer(Modifier.width(4.dp))
                Icon(Icons.Default.ArrowForward, null, modifier = Modifier.size(17.dp))
            }
        }
    }
}

@Composable
private fun ActivityDashboardCluster(
    entries: List<DailyStreamEntry>,
    forecast: ForecastResult,
    goalStreams: Long?,
    goalBrl: Double?,
    rpm: Double,
    daysRemaining: Long
) {
    val latest = entries.lastOrNull()
    val previous = entries.getOrNull(entries.lastIndex - 1)
    val percentChange = when {
        latest == null || previous == null -> 0.0
        previous.streams <= 0L && latest.streams > 0L -> 50.0
        previous.streams > 0L -> (latest.streams - previous.streams).toDouble() / previous.streams.toDouble() * 100.0
        else -> 0.0
    }

    val observedRecentAverage = entries.takeLast(3).takeIf { it.isNotEmpty() }?.map { it.streams.toDouble() }?.average()
        ?: forecast.recentDailyAverage
    val observedCycleAverage = entries.takeIf { it.isNotEmpty() }?.map { it.streams.toDouble() }?.average()
        ?: forecast.cycleDailyAverage

    val hasGoal = (goalStreams != null && goalStreams > 0L) || (goalBrl != null && goalBrl > 0.0)
    val requiredDaily = when {
        daysRemaining <= 0L -> 0.0
        goalStreams != null && goalStreams > forecast.currentStreams ->
            (goalStreams - forecast.currentStreams).toDouble() / daysRemaining.toDouble()
        goalBrl != null && goalBrl > forecast.estimatedCurrentBrl && rpm > 0.0 ->
            ((goalBrl - forecast.estimatedCurrentBrl) / rpm * 1_000.0) / daysRemaining.toDouble()
        else -> 0.0
    }
    val pacePercent = when {
        hasGoal && requiredDaily <= 0.0 -> 120.0
        hasGoal && requiredDaily > 0.0 -> observedRecentAverage / requiredDaily * 100.0
        observedCycleAverage > 0.0 -> observedRecentAverage / observedCycleAverage * 100.0
        else -> 0.0
    }.coerceIn(0.0, 140.0)

    val activityNormalized = ((percentChange.coerceIn(-50.0, 50.0) + 50.0) / 100.0).toFloat()
    val paceNormalized = (pacePercent / 120.0).coerceIn(0.0, 1.0).toFloat()
    val activityTargetAngle = 150f + 240f * activityNormalized
    val paceTargetAngle = 150f + 240f * paceNormalized
    val activityAngle by animateFloatAsState(activityTargetAngle, tween(950, easing = FastOutSlowInEasing), label = "cluster-activity-needle")
    val paceAngle by animateFloatAsState(paceTargetAngle, tween(1050, easing = FastOutSlowInEasing), label = "cluster-pace-needle")
    val animatedPercent by animateFloatAsState(percentChange.toFloat(), tween(900), label = "cluster-activity-value")
    val animatedPace by animateFloatAsState(pacePercent.toFloat(), tween(1000), label = "cluster-pace-value")

    val activityColor by animateColorAsState(
        when {
            percentChange < -10.0 -> SignalRed
            percentChange < 0.0 -> SignalOrange
            percentChange <= 5.0 -> SignalPurple
            else -> SignalGreen
        },
        tween(700),
        label = "cluster-activity-color"
    )
    val paceColor by animateColorAsState(
        when {
            pacePercent < 60.0 -> SignalRed
            pacePercent < 85.0 -> SignalOrange
            pacePercent < 100.0 -> SignalPurple
            else -> SignalGreen
        },
        tween(700),
        label = "cluster-pace-color"
    )

    val clock by produceState(initialValue = java.time.LocalTime.now()) {
        while (true) {
            value = java.time.LocalTime.now()
            delay(30_000)
        }
    }
    val today = LocalDate.now()
    val centerTime = clock.format(DateTimeFormatter.ofPattern("HH:mm"))
    val centerDate = today.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))
    val paceTitle = if (hasGoal) "Ritmo da meta" else "Ritmo do ciclo"
    val paceNumber = when {
        hasGoal && requiredDaily > 0.0 -> formatNumber(requiredDaily.roundToLongSafe())
        hasGoal -> "✓"
        else -> formatNumber(observedRecentAverage.roundToLongSafe())
    }
    val paceUnit = when {
        hasGoal && requiredDaily > 0.0 -> "streams/dia necessários"
        hasGoal -> "Meta atingida"
        else -> "streams/dia recentes"
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF07152E)),
        border = BorderStroke(1.dp, PulseCyan.copy(alpha = .22f))
    ) {
        Column(Modifier.padding(horizontal = 10.dp, vertical = 14.dp)) {
            Text(
                "Atividade recente",
                fontWeight = FontWeight.Bold,
                color = Color.White.copy(alpha = .92f),
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
            )

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(208.dp)
            ) {
                Canvas(Modifier.fillMaxSize()) {
                    val leftCenter = Offset(size.width * .20f, size.height * .53f)
                    val rightCenter = Offset(size.width * .80f, size.height * .53f)
                    val radius = minOf(size.width * .195f, size.height * .37f)
                    val arcStroke = 8.dp.toPx()
                    val outerStroke = 2.dp.toPx()
                    val innerStroke = 1.2.dp.toPx()

                    fun dialRect(center: Offset) = androidx.compose.ui.geometry.Rect(
                        left = center.x - radius,
                        top = center.y - radius,
                        right = center.x + radius,
                        bottom = center.y + radius
                    )

                    fun drawDial(center: Offset, needleAngle: Float, needleColor: Color) {
                        val rect = dialRect(center)
                        drawCircle(Color(0xFF0A244C), radius = radius * 1.03f, center = center)
                        drawCircle(Color(0xFF061327), radius = radius * .91f, center = center)
                        drawCircle(PulseCyan.copy(alpha = .92f), radius = radius, center = center, style = androidx.compose.ui.graphics.drawscope.Stroke(outerStroke))
                        drawCircle(PulseBlue.copy(alpha = .36f), radius = radius * .90f, center = center, style = androidx.compose.ui.graphics.drawscope.Stroke(innerStroke))

                        // Escala ampliada do velocímetro: aqui o amarelo permanece como nível intermediário.
                        drawArc(SignalBlack.copy(alpha = .96f), 150f, 30f, false, style = androidx.compose.ui.graphics.drawscope.Stroke(arcStroke, cap = androidx.compose.ui.graphics.StrokeCap.Butt), topLeft = rect.topLeft, size = rect.size)
                        drawArc(SignalRed.copy(alpha = .95f), 180f, 34f, false, style = androidx.compose.ui.graphics.drawscope.Stroke(arcStroke, cap = androidx.compose.ui.graphics.StrokeCap.Butt), topLeft = rect.topLeft, size = rect.size)
                        drawArc(SignalPurple.copy(alpha = .95f), 214f, 34f, false, style = androidx.compose.ui.graphics.drawscope.Stroke(arcStroke, cap = androidx.compose.ui.graphics.StrokeCap.Butt), topLeft = rect.topLeft, size = rect.size)
                        drawArc(SignalOrange.copy(alpha = .95f), 248f, 34f, false, style = androidx.compose.ui.graphics.drawscope.Stroke(arcStroke, cap = androidx.compose.ui.graphics.StrokeCap.Butt), topLeft = rect.topLeft, size = rect.size)
                        drawArc(SignalYellow.copy(alpha = .94f), 282f, 34f, false, style = androidx.compose.ui.graphics.drawscope.Stroke(arcStroke, cap = androidx.compose.ui.graphics.StrokeCap.Butt), topLeft = rect.topLeft, size = rect.size)
                        drawArc(SignalGreen.copy(alpha = .96f), 316f, 34f, false, style = androidx.compose.ui.graphics.drawscope.Stroke(arcStroke, cap = androidx.compose.ui.graphics.StrokeCap.Butt), topLeft = rect.topLeft, size = rect.size)
                        drawArc(SignalBlue.copy(alpha = .96f), 350f, 40f, false, style = androidx.compose.ui.graphics.drawscope.Stroke(arcStroke, cap = androidx.compose.ui.graphics.StrokeCap.Butt), topLeft = rect.topLeft, size = rect.size)

                        for (i in 0..24) {
                            val tickAngle = 150f + (240f / 24f) * i
                            val r = tickAngle / 180f * PI.toFloat()
                            val major = i % 4 == 0
                            val outer = radius * .83f
                            val inner = if (major) radius * .72f else radius * .76f
                            val start = Offset(
                                center.x + cos(r.toDouble()).toFloat() * inner,
                                center.y + sin(r.toDouble()).toFloat() * inner
                            )
                            val finish = Offset(
                                center.x + cos(r.toDouble()).toFloat() * outer,
                                center.y + sin(r.toDouble()).toFloat() * outer
                            )
                            drawLine(
                                color = if (major) Color.White.copy(alpha = .92f) else PulseCyan.copy(alpha = .55f),
                                start = start,
                                end = finish,
                                strokeWidth = if (major) 2.dp.toPx() else 1.dp.toPx(),
                                cap = androidx.compose.ui.graphics.StrokeCap.Round
                            )
                        }

                        val radians = needleAngle / 180f * PI.toFloat()
                        val tail = Offset(
                            center.x - cos(radians.toDouble()).toFloat() * radius * .13f,
                            center.y - sin(radians.toDouble()).toFloat() * radius * .13f
                        )
                        val needleEnd = Offset(
                            center.x + cos(radians.toDouble()).toFloat() * radius * .66f,
                            center.y + sin(radians.toDouble()).toFloat() * radius * .66f
                        )
                        drawLine(Color.Black.copy(alpha = .48f), tail + Offset(2.dp.toPx(), 2.dp.toPx()), needleEnd + Offset(2.dp.toPx(), 2.dp.toPx()), strokeWidth = 5.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round)
                        drawLine(Color.White.copy(alpha = .97f), tail, needleEnd, strokeWidth = 3.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round)
                        drawCircle(needleColor, radius = 8.dp.toPx(), center = center)
                        drawCircle(Color.White, radius = 3.2.dp.toPx(), center = center)
                    }

                    drawDial(leftCenter, activityAngle, activityColor)
                    drawDial(rightCenter, paceAngle, paceColor)
                }

                Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.weight(1f).fillMaxHeight()) {
                        Text(
                            formatSignedPercent(animatedPercent.toDouble()),
                            modifier = Modifier.align(Alignment.TopCenter).padding(top = 2.dp),
                            style = digitalValueStyle(activityColor, 14.sp),
                            textAlign = TextAlign.Center,
                            maxLines = 1
                        )
                        Column(
                            modifier = Modifier.align(Alignment.Center).padding(top = 44.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(1.dp)
                        ) {
                            Text(
                                if (latest != null) "streams" else "sem dados",
                                fontSize = 8.5.sp,
                                color = Color.White.copy(alpha = .70f),
                                textAlign = TextAlign.Center,
                                maxLines = 1
                            )
                            Text(
                                latest?.let { formatNumber(it.streams) } ?: "—",
                                style = digitalValueStyle(Color.White.copy(alpha = .94f), 12.sp),
                                textAlign = TextAlign.Center,
                                maxLines = 1
                            )
                        }
                        Text(
                            "Atividade",
                            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 2.dp),
                            fontSize = 10.sp,
                            color = PulseCyan.copy(alpha = .90f),
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                    }

                    Box(
                        modifier = Modifier
                            .width(72.dp)
                            .padding(top = 35.dp)
                            .background(Color(0xFF09244B).copy(alpha = .96f), RoundedCornerShape(10.dp))
                            .border(1.dp, PulseCyan.copy(alpha = .38f), RoundedCornerShape(10.dp))
                            .padding(horizontal = 6.dp, vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(centerTime, style = digitalValueStyle(PulseCyan, 16.sp), maxLines = 1)
                            Text(centerDate, fontSize = 9.sp, color = Color.White.copy(alpha = .76f), maxLines = 1)
                            HorizontalDivider(color = PulseCyan.copy(alpha = .24f))
                            Text("$daysRemaining", style = digitalValueStyle(Color.White, 20.sp))
                            Text("DIAS", style = MaterialTheme.typography.labelSmall, color = SignalOrange)
                        }
                    }

                    Box(Modifier.weight(1f).fillMaxHeight()) {
                        Text(
                            "${animatedPace.roundToInt()}%",
                            modifier = Modifier.align(Alignment.TopCenter).padding(top = 2.dp),
                            style = digitalValueStyle(paceColor, 14.sp),
                            textAlign = TextAlign.Center,
                            maxLines = 1
                        )
                        Column(
                            modifier = Modifier.align(Alignment.Center).padding(top = 44.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(1.dp)
                        ) {
                            Text(
                                paceUnit,
                                fontSize = 8.sp,
                                color = Color.White.copy(alpha = .70f),
                                textAlign = TextAlign.Center,
                                maxLines = 2,
                                lineHeight = 8.8.sp,
                                modifier = Modifier.widthIn(max = 80.dp)
                            )
                            Text(
                                paceNumber,
                                style = digitalValueStyle(Color.White.copy(alpha = .94f), 12.sp),
                                textAlign = TextAlign.Center,
                                maxLines = 1
                            )
                        }
                        Text(
                            paceTitle,
                            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 2.dp),
                            fontSize = 10.sp,
                            color = PulseCyan.copy(alpha = .90f),
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            maxLines = 1
                        )
                    }
                }
            }
        }
    }
}
@Composable
private fun RecommendedPeriodNotice(cycle: CycleWindow, today: LocalDate, cycleNotStarted: Boolean) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = SignalOrange.copy(alpha = .10f),
        border = BorderStroke(1.dp, SignalOrange.copy(alpha = .45f))
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text("⚠️ Período recomendado", fontWeight = FontWeight.SemiBold)
            Text(
                if (cycleNotStarted) "Novo período começa em ${formatDate(cycle.startIso)}"
                else "${formatDate(cycle.startIso)} → ${formatDate(today.toString())}",
                fontWeight = FontWeight.Bold
            )
            Text(cycle.description, style = MaterialTheme.typography.bodySmall)
        }
    }
}

private val SignalBlack = Color(0xFF101216)
private val SignalRed = Color(0xFF9E2A2B)
private val SignalPurple = Color(0xFF5B357D)
private val SignalBrown = SignalPurple
private val SignalOrange = Color(0xFFA95818)
private val SignalYellow = Color(0xFFB08A16) // reservado a avisos/velocímetro
private val SignalGreen = Color(0xFF226A43)
private val SignalBlue = Color(0xFF16558B)

private fun goalProgressColor(percent: Double): Color = when {
    percent <= 0.0 -> SignalBlack
    percent < 20.0 -> SignalRed
    percent < 40.0 -> SignalPurple
    percent < 60.0 -> SignalOrange
    percent < 85.0 -> SignalGreen
    else -> SignalBlue
}

private fun homeGoalProgressColor(percent: Double, hasGoal: Boolean): Color {
    if (!hasGoal) return Color(0xFF2B65B8)
    // Bases mais ricas para o degradê suave: luz no topo/esquerda e profundidade embaixo/direita.
    return when {
        percent <= 0.0 -> Color(0xFF111318)
        percent < 20.0 -> Color(0xFF8E2B31)
        percent < 45.0 -> Color(0xFF593573)
        percent < 70.0 -> Color(0xFF95501E)
        percent < 90.0 -> Color(0xFF23613F)
        else -> Color(0xFF194F7C)
    }
}

private fun forecastSignalColor(amount: Double, goalBrl: Double?): Color =
    if (goalBrl != null && goalBrl > 0.0) goalProgressColor(amount / goalBrl * 100.0) else SignalBlue

private fun movementSignalColor(direction: Int): Color = when {
    direction > 0 -> SignalGreen
    direction < 0 -> SignalRed
    else -> SignalPurple
}

private fun closingSignalColor(daysRemaining: Long): Color = when {
    daysRemaining >= 24 -> SignalBlue
    daysRemaining >= 18 -> SignalGreen
    daysRemaining >= 12 -> SignalOrange
    daysRemaining >= 7 -> SignalPurple
    daysRemaining >= 4 -> SignalRed
    else -> SignalBlack
}

private fun digitalValueStyle(color: Color, fontSize: androidx.compose.ui.unit.TextUnit): TextStyle = TextStyle(
    color = color,
    fontSize = fontSize,
    fontFamily = FontFamily.Monospace,
    fontWeight = FontWeight.Black,
    letterSpacing = 0.2.sp,
    shadow = Shadow(color = Color.Black.copy(alpha = .58f), offset = Offset(1.2f, 1.8f), blurRadius = 3.2f)
)

@Composable
private fun UpdateStreamsScreen(
    state: AppState,
    artist: Artist,
    onBack: () -> Unit,
    onDistributorInfo: () -> Unit,
    onSaveRetroactive: (DailyStreamRecord) -> Unit,
    onArtistUpdate: (Artist) -> Unit,
    onSave: (StreamSnapshot) -> Unit
) {
    val today = LocalDate.now()
    val cycle = DistributorRules.cycleFor(artist, today)
    val cycleStartDate = LocalDate.parse(cycle.startIso)
    val cycleNotStarted = today.isBefore(cycleStartDate)
    val context = LocalContext.current
    val streamPrefs = remember(artist.id) { context.getSharedPreferences("sonus_stream_entry_${artist.id}", android.content.Context.MODE_PRIVATE) }
    val distributorFinancialProfile = DistributorRules.financialProfile(artist)
    var entryMode by rememberSaveable(artist.id) {
        mutableStateOf(artist.streamEntryMode ?: streamPrefs.getString("mode", distributorFinancialProfile.entryMode) ?: distributorFinancialProfile.entryMode)
    }
    var dataDelayDays by rememberSaveable(artist.id) { mutableIntStateOf(streamPrefs.getInt("delay", distributorFinancialProfile.dataDelayDays).coerceIn(0,14)) }
    val dataDate = today.minusDays(dataDelayDays.toLong())
    // O atraso descreve a data real do painel. Se ela cair no ciclo anterior, o registro
    // pertence àquele ciclo em vez de ser forçado indevidamente para o ciclo de hoje.
    val dataCycle = DistributorRules.cycleFor(artist, dataDate)
    val dataCycleSnapshots = state.snapshots.filter {
        it.artistId == artist.id && snapshotInCycle(it, dataCycle) && recordBelongsToCurrentCycle(it.cycleId, artist)
    }.sortedWith(snapshotComparator())
    LaunchedEffect(entryMode, dataDelayDays) {
        streamPrefs.edit().putString("mode", entryMode).putInt("delay", dataDelayDays).apply()
        if (artist.streamEntryMode != entryMode) onArtistUpdate(artist.copy(streamEntryMode = entryMode))
    }
    val prior = dataCycleSnapshots.filter { LocalDate.parse(it.dateIso).isBefore(dataDate) }.maxWithOrNull(snapshotComparator())
    val existingToday = dataCycleSnapshots.filter { it.dateIso == dataDate.toString() }.maxWithOrNull(snapshotComparator())
    val existingDailyForDate = state.dailyStreamRecords
        .filter { it.artistId == artist.id && it.dateIso == dataDate.toString() && recordBelongsToCurrentCycle(it.cycleId, artist) }
        .maxByOrNull { it.recordedAtEpochMillis }
    val payments = state.payments.filter { it.artistId == artist.id }
    val rpm = RoyaltyEngine.personalizedRpm(artist, payments)

    var streamsText by rememberSaveable(entryMode,dataDelayDays) { mutableStateOf(if(entryMode=="TOTAL") existingToday?.cumulativeStreams?.toString() ?: "" else existingDailyForDate?.streams?.toString() ?: "") }
    val streams = streamsText.filter(Char::isDigit).toLongOrNull()
    val lowerThanPrior = entryMode=="TOTAL" && streams != null && prior != null && streams < prior.cumulativeStreams
    val todayStreams = when {
        streams == null -> null
        entryMode=="DIA" -> streams
        prior != null -> (streams - prior.cumulativeStreams).takeIf { it >= 0 }
        else -> streams
    }
    val gapDays = prior?.let { ChronoUnit.DAYS.between(LocalDate.parse(it.dateIso), dataDate).coerceAtLeast(1) } ?: 1L

    var showRetroactiveDialog by rememberSaveable { mutableStateOf(false) }
    val retroMinDate = cycleStartDate
    val retroMaxDate = minOf(today.minusDays(1), LocalDate.parse(cycle.endIso))
    val filledRetroDates = state.dailyStreamRecords
        .filter { it.artistId == artist.id && recordBelongsToCurrentCycle(it.cycleId, artist) }
        .mapNotNull { runCatching { LocalDate.parse(it.dateIso) }.getOrNull() }
        .filter { !it.isBefore(retroMinDate) && !it.isAfter(retroMaxDate) }
        .toSet()
    val retroCandidates = if (retroMaxDate.isBefore(retroMinDate)) emptyList() else generateSequence(retroMaxDate) { current ->
        current.minusDays(1).takeIf { !it.isBefore(retroMinDate) }
    }.toList()
    val nextRetroDate = retroCandidates.firstOrNull { it !in filledRetroDates }
    var retroDateText by rememberSaveable(artist.id, cycle.startIso) { mutableStateOf(formatDate((nextRetroDate ?: retroMaxDate).toString())) }
    var retroStreamsText by rememberSaveable { mutableStateOf("") }
    val retroDate = parseDateInput(retroDateText)
    val retroStreams = retroStreamsText.filter(Char::isDigit).toLongOrNull()
    val retroDateValid = retroDate != null && !retroDate.isBefore(retroMinDate) && !retroDate.isAfter(retroMaxDate)
    val existingRetro = retroDate?.let { date ->
        state.dailyStreamRecords.firstOrNull { it.artistId == artist.id && it.dateIso == date.toString() && recordBelongsToCurrentCycle(it.cycleId, artist) }
    }

    var showResetCycleDialog by rememberSaveable { mutableStateOf(false) }
    var resetCycleMode by rememberSaveable { mutableStateOf("DAY26") }
    var manualResetDateIso by rememberSaveable(artist.id) { mutableStateOf(today.toString()) }
    val day26Start = remember(today) {
        val thisMonth26 = java.time.YearMonth.from(today).atDay(26.coerceAtMost(java.time.YearMonth.from(today).lengthOfMonth()))
        if (!today.isBefore(thisMonth26)) thisMonth26 else java.time.YearMonth.from(today).minusMonths(1).atDay(26)
    }
    val actualPaymentStart = artist.lastActualPayoutDateIso?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
    val manualResetDate = runCatching { LocalDate.parse(manualResetDateIso) }.getOrNull()
    val selectedResetDate = when (resetCycleMode) {
        "PAYMENT" -> actualPaymentStart
        "MANUAL" -> manualResetDate
        else -> day26Start
    }

    if (showResetCycleDialog) {
        AlertDialog(
            onDismissRequest = { showResetCycleDialog = false },
            title = { Text("Reiniciar ciclo e gráfico") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        "Cria um novo ponto de partida sem apagar pagamentos, ciclos fechados ou histórico anterior. Os cálculos passam a considerar a nova janela.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    FilterChip(
                        selected = resetCycleMode == "DAY26",
                        onClick = { resetCycleMode = "DAY26" },
                        label = { Text("Padrão • dia 26") }
                    )
                    FilterChip(
                        selected = resetCycleMode == "PAYMENT",
                        onClick = { if (actualPaymentStart != null) resetCycleMode = "PAYMENT" },
                        enabled = actualPaymentStart != null,
                        label = { Text(actualPaymentStart?.let { "Recebimento • ${formatDate(it.toString())}" } ?: "Recebimento • ainda não registrado") }
                    )
                    FilterChip(
                        selected = resetCycleMode == "MANUAL",
                        onClick = { resetCycleMode = "MANUAL" },
                        label = { Text("Data manual") }
                    )
                    if (resetCycleMode == "MANUAL") {
                        OutlinedButton(
                            onClick = {
                                val initial = manualResetDate ?: today
                                android.app.DatePickerDialog(
                                    context,
                                    { _, y, m, d -> manualResetDateIso = LocalDate.of(y, m + 1, d).toString() },
                                    initial.year,
                                    initial.monthValue - 1,
                                    initial.dayOfMonth
                                ).apply { datePicker.maxDate = System.currentTimeMillis() }.show()
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Event, null)
                            Spacer(Modifier.width(8.dp))
                            Text("Início: ${manualResetDate?.let { formatDate(it.toString()) } ?: "Escolher data"}")
                        }
                    }
                    selectedResetDate?.let {
                        Text("Novo início: ${formatDate(it.toString())}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                    Text(
                        "O reset arquiva a janela anterior e abre um novo ciclo independente. Pagamentos e histórico antigos são preservados, sem contaminar o novo gráfico.",
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            },
            confirmButton = {
                TextButton(
                    enabled = selectedResetDate != null && !selectedResetDate.isAfter(today),
                    onClick = {
                        val start = selectedResetDate ?: return@TextButton
                        onArtistUpdate(
                            artist.copy(
                                financialCycleStartIso = start.toString(),
                                financialCycleId = UUID.randomUUID().toString(),
                                streamEntryMode = entryMode,
                                lastCountedDataDateIso = start.minusDays(1).toString(),
                                nextUnconsumedDataDateIso = start.toString()
                            )
                        )
                        showResetCycleDialog = false
                    }
                ) { Text("Reiniciar") }
            },
            dismissButton = { TextButton(onClick = { showResetCycleDialog = false }) { Text("Cancelar") } }
        )
    }

    if (showRetroactiveDialog) {
        AlertDialog(
            onDismissRequest = { showRetroactiveDialog = false },
            title = { Text("Adicionar registro retroativo") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        "Escolha um dia anterior dentro do ciclo e informe os streams daquele dia. O registro passa a alimentar Histórico, Saúde, Pulso, Saldo, Tendência e projeções.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(
                        value = retroDateText,
                        onValueChange = {},
                        label = { Text("Data do registro") },
                        placeholder = { Text("DD/MM/AAAA") },
                        supportingText = {
                            Text(
                                if (retroDateText.isBlank() || retroDateValid)
                                    "Permitido neste ciclo: ${formatDate(retroMinDate.toString())} até ${formatDate(retroMaxDate.toString())}"
                                else "Escolha uma data dentro do ciclo atual e anterior a hoje."
                            )
                        },
                        trailingIcon = {
                            IconButton(onClick = {
                                val initial = retroDate ?: nextRetroDate ?: retroMaxDate
                                val dialog = android.app.DatePickerDialog(
                                    context,
                                    { _, y, m, d -> retroDateText = formatDate(LocalDate.of(y, m + 1, d).toString()) },
                                    initial.year,
                                    initial.monthValue - 1,
                                    initial.dayOfMonth
                                )
                                dialog.datePicker.minDate = retroMinDate.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
                                dialog.datePicker.maxDate = retroMaxDate.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
                                dialog.show()
                            }) { Icon(Icons.Default.CalendarMonth, "Escolher data") }
                        },
                        readOnly = true,
                        isError = retroDateText.isNotBlank() && !retroDateValid,
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().clickable {
                            val initial = retroDate ?: nextRetroDate ?: retroMaxDate
                            val dialog = android.app.DatePickerDialog(
                                context,
                                { _, y, m, d -> retroDateText = formatDate(LocalDate.of(y, m + 1, d).toString()) },
                                initial.year,
                                initial.monthValue - 1,
                                initial.dayOfMonth
                            )
                            dialog.datePicker.minDate = retroMinDate.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
                            dialog.datePicker.maxDate = retroMaxDate.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
                            dialog.show()
                        }
                    )
                    OutlinedTextField(
                        value = retroStreamsText,
                        onValueChange = { retroStreamsText = it.filter(Char::isDigit) },
                        label = { Text("Streams daquele dia") },
                        placeholder = { Text("Ex.: 536") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (existingRetro != null) {
                        Text(
                            "Já existe um registro de ${formatNumber(existingRetro.streams)} streams nessa data. Salvar substituirá apenas esse dia.",
                            color = SignalOrange,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val date = retroDate ?: return@TextButton
                        val value = retroStreams ?: return@TextButton
                        onSaveRetroactive(
                            DailyStreamRecord(
                                id = existingRetro?.id ?: UUID.randomUUID().toString(),
                                artistId = artist.id,
                                dateIso = date.toString(),
                                streams = value,
                                recordedAtEpochMillis = System.currentTimeMillis(),
                                cycleId = artist.financialCycleId
                            )
                        )
                        showRetroactiveDialog = false
                        retroStreamsText = ""
                    },
                    enabled = retroDateValid && retroStreams != null && retroStreams >= 0L
                ) { Text(if (existingRetro != null) "Substituir" else "Salvar") }
            },
            dismissButton = {
                TextButton(onClick = { showRetroactiveDialog = false }) { Text("Cancelar") }
            }
        )
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item { PageHeader("Atualizar streams", onBack) }

        item {
            Card {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(DistributorRules.displayName(artist.distributor, artist.customDistributorName), fontWeight = FontWeight.Bold)
                    Text(if (cycleNotStarted) "O novo período ainda não começou." else "Na distribuidora, consulte o período recomendado:")
                    Text(
                        if (cycleNotStarted) "Começa em ${formatDate(cycle.startIso)}"
                        else "${formatDate(cycle.startIso)} até ${formatDate(today.toString())}",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(cycle.description, style = MaterialTheme.typography.bodySmall)
                    artist.financialCycleStartIso?.let { financialStart ->
                        Text("Novo ciclo iniciado em ${formatDate(financialStart)}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                    }
                    artist.nextUnconsumedDataDateIso?.let { nextData ->
                        Text("Dados deste ciclo a partir de ${formatDate(nextData)}", style = MaterialTheme.typography.labelMedium)
                    }
                    artist.nextExpectedPayoutDateIso?.let { expected ->
                        Text("Próximo pagamento esperado: ${formatDate(expected)}", style = MaterialTheme.typography.labelSmall)
                    }
                    artist.lastActualPayoutDateIso?.let { actual ->
                        Text("Último pagamento real: ${formatDate(actual)}", style = MaterialTheme.typography.labelSmall)
                    }
                    TextButton(onClick = onDistributorInfo, contentPadding = PaddingValues(0.dp)) {
                        Icon(Icons.Default.Info, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Entenda esta distribuidora")
                    }
                    OutlinedButton(
                        onClick = { showResetCycleDialog = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.RestartAlt, null)
                        Spacer(Modifier.width(7.dp))
                        Text("Reiniciar ciclo e gráfico")
                    }
                }
            }
        }

        item {
            Card { Column(Modifier.padding(16.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
                Text("Como a distribuidora mostra os dados?", fontWeight=FontWeight.ExtraBold)
                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    FilterChip(entryMode=="TOTAL", {entryMode="TOTAL";streamsText=""}, {Text("Total do período")}, modifier=Modifier.weight(1f))
                    FilterChip(entryMode=="DIA", {entryMode="DIA";streamsText=""}, {Text("Valor do dia")}, modifier=Modifier.weight(1f))
                }
                Text(if(entryMode=="TOTAL") "Use quando o painel mostra um total acumulado. O SONUS calcula apenas o crescimento." else "Use quando o painel mostra quantos streams aconteceram em cada dia. O SONUS soma os dias.", style=MaterialTheme.typography.bodySmall)
                Text("Atraso dos dados: $dataDelayDays dia(s)", fontWeight=FontWeight.Bold)
                Slider(dataDelayDays.toFloat(), {dataDelayDays=it.roundToInt().coerceIn(0,14)}, valueRange=0f..14f, steps=13)
                Text("Dados disponíveis até: ${formatDate(dataDate.toString())} • atraso configurado: $dataDelayDays dia(s).", style=MaterialTheme.typography.bodySmall, color=MaterialTheme.colorScheme.primary)
                Text("Próximo dado esperado: ${formatDate(dataDate.plusDays(1).toString())}.", style=MaterialTheme.typography.labelSmall)
            }}
        }

        item {
            OutlinedTextField(
                value = streamsText,
                onValueChange = { streamsText = it.filter(Char::isDigit) },
                label = { Text(if(entryMode=="TOTAL") "Total acumulado • ${formatDate(dataDate.toString())}" else "Streams do dia • ${formatDate(dataDate.toString())}") },
                supportingText = {
                    when {
                        lowerThanPrior -> Text("O total não pode ser menor que a leitura anterior (${formatNumber(prior!!.cumulativeStreams)}).")
                        (entryMode == "TOTAL" && existingToday != null) || (entryMode == "DIA" && existingDailyForDate != null) -> Text("Já existe uma leitura referente a ${formatDate(dataDate.toString())}; o SONUS atualizará esse dia.")
                        prior != null -> Text("Referente a ${formatDate(dataDate.toString())} • leitura anterior: ${formatNumber(prior.cumulativeStreams)} em ${formatDate(prior.dateIso)}")
                        else -> Text(if(entryMode=="TOTAL") "Total acumulado referente a ${formatDate(dataDate.toString())}." else "Digite somente os streams de ${formatDate(dataDate.toString())}.")
                    }
                },
                isError = lowerThanPrior,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
        }

        if (streams != null && !lowerThanPrior) {
            item {
                val estimate = RoyaltyEngine.estimateBrl(streams, rpm)
                MetricCard(
                    modifier = Modifier.fillMaxWidth(),
                    title = "Estimativa rápida",
                    value = money(estimate),
                    subtitle = "Estimativa atual do SONUS"
                )
            }
        }

        if (todayStreams != null) {
            item {
                val points = HealthEngine.pointsForDate(
                    LocalDate.parse(dataCycle.startIso),
                    LocalDate.parse(dataCycle.endIso),
                    dataDate,
                    todayStreams
                )
                MetricCard(
                    modifier = Modifier.fillMaxWidth(),
                    title = if ((entryMode == "TOTAL" && existingToday != null) || (entryMode == "DIA" && existingDailyForDate != null)) "Saúde do registro • atualização" else "Impacto na Saúde do Projeto",
                    value = if (points > 0) "+$points pontos" else "$points ponto${if (points != -1) "s" else ""}",
                    subtitle = when {
                        (entryMode == "TOTAL" && existingToday != null) || (entryMode == "DIA" && existingDailyForDate != null) -> "Esta leitura atualiza o registro já existente dessa data; ela não cria um dia extra."
                        gapDays > 1 -> "${formatNumber(todayStreams)} streams desde a última leitura • ${gapDays - 1} dia(s) sem atualização não serão pontuados"
                        else -> "${formatNumber(todayStreams)} streams desde a leitura anterior"
                    }
                )
            }
        }

        item {
            Button(
                onClick = {
                    val value=streams ?: 0
                    if(entryMode=="DIA") {
                        onSaveRetroactive(DailyStreamRecord(id=existingDailyForDate?.id ?: UUID.randomUUID().toString(),artistId=artist.id,dateIso=dataDate.toString(),streams=value,recordedAtEpochMillis=System.currentTimeMillis(),cycleId=artist.financialCycleId))
                        streamsText=""
                    } else {
                        val estimate = RoyaltyEngine.estimateBrl(value, rpm)
                        onSave(StreamSnapshot(id=existingToday?.id ?: UUID.randomUUID().toString(),artistId=artist.id,dateIso=dataDate.toString(),cumulativeStreams=value,cycleStartIso=dataCycle.startIso,cycleEndIso=dataCycle.endIso,recordedAtEpochMillis=System.currentTimeMillis(),estimatedBrlAtSave=estimate,cycleId=artist.financialCycleId))
                    }
                },
                enabled = !cycleNotStarted && streams != null && streams >= 0 && !lowerThanPrior,
                modifier = Modifier.fillMaxWidth().height(54.dp)
            ) { Text("Salvar atualização") }
        }

        item {
            OutlinedButton(
                onClick = {
                    nextRetroDate?.let { retroDateText = formatDate(it.toString()) }
                    retroStreamsText = ""
                    showRetroactiveDialog = nextRetroDate != null
                },
                enabled = nextRetroDate != null && entryMode == "DIA",
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Icon(if (nextRetroDate == null) Icons.Default.CheckCircle else Icons.Default.Restore, null)
                Spacer(Modifier.width(8.dp))
                Text(if (nextRetroDate == null) "✓ Registros retroativos do ciclo preenchidos" else "Adicionar registro retroativo • ${formatDate(nextRetroDate.toString())}")
            }
        }

        item {
            Text(
                "${filledRetroDates.size}/${retroCandidates.size} dia(s) retroativos preenchidos neste ciclo. O SONUS sugere o dia vazio mais recente e permite substituir conscientemente uma data já registrada.",
                style = MaterialTheme.typography.bodySmall
            )
        }

        item {
            Text(
                "A Saúde acompanha a consistência do artista dentro do ciclo atual. Dias sem registro não são tratados como zero e podem ser preenchidos depois pelo registro retroativo.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun PaymentScreen(
    state: AppState,
    artist: Artist,
    onBack: () -> Unit,
    onSave: (RoyaltyPayment) -> Unit
) {
    val context = LocalContext.current
    val today = LocalDate.now()
    val cycle = DistributorRules.cycleFor(artist, today)
    val oldPayments = state.payments.filter { it.artistId == artist.id }
    val rpmBefore = RoyaltyEngine.personalizedRpm(artist, oldPayments)
    val paymentCycleSnapshots = state.snapshots.filter { it.artistId == artist.id && snapshotInCycle(it, cycle) }
    val paymentCycleDaily = state.dailyStreamRecords.filter { it.artistId == artist.id && snapshotDateInCycle(it.dateIso, cycle) }
    val paymentCycleMetrics = StreamMetricsEngine.cycleMetrics(
        paymentCycleSnapshots,
        paymentCycleDaily,
        LocalDate.parse(cycle.startIso),
        LocalDate.parse(cycle.endIso),
        today,
        entryMode = resolvedStreamEntryMode(artist),
        cycleId = artist.financialCycleId
    )
    val latestCycleStreams = paymentCycleMetrics.currentStreams.takeIf { it > 0L }
    val expectedPayoutDate = DistributorRules.expectedPayoutDateForCurrentCycle(artist, today)

    var amountText by rememberSaveable { mutableStateOf("") }
    var streamsText by rememberSaveable { mutableStateOf(latestCycleStreams?.toString() ?: "") }
    var actualPaidDateIso by rememberSaveable { mutableStateOf(today.toString()) }
    var newCycleStartIso by rememberSaveable { mutableStateOf(today.toString()) }
    var cycleStartTouched by rememberSaveable { mutableStateOf(false) }
    var adoptActualDayAsPattern by rememberSaveable { mutableStateOf(false) }

    val actualPaidDate = runCatching { LocalDate.parse(actualPaidDateIso) }.getOrDefault(today)
    val newCycleStart = runCatching { LocalDate.parse(newCycleStartIso) }.getOrDefault(actualPaidDate)
    val previousCycleLastDay = newCycleStart.minusDays(1)
    val amount = parseMoneyInput(amountText)
    val streams = streamsText.filter(Char::isDigit).toLongOrNull()
    val estimatedBefore = if (streams != null) RoyaltyEngine.estimateBrl(streams, rpmBefore) else 0.0

    fun openDatePicker(initial: LocalDate, onPicked: (LocalDate) -> Unit) {
        android.app.DatePickerDialog(
            context,
            { _, year, month, day -> onPicked(LocalDate.of(year, month + 1, day)) },
            initial.year,
            initial.monthValue - 1,
            initial.dayOfMonth
        ).apply {
            datePicker.maxDate = System.currentTimeMillis()
        }.show()
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item { PageHeader("Recebi meus royalties", onBack) }
        item { Text("Registre o valor e a data em que o dinheiro realmente chegou. O início do novo ciclo pode ser ajustado separadamente.") }

        item {
            OutlinedTextField(
                value = amountText,
                onValueChange = { amountText = it },
                label = { Text("Valor recebido (R$)") },
                placeholder = { Text("329,50") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
        }

        item {
            OutlinedTextField(
                value = streamsText,
                onValueChange = { streamsText = it.filter(Char::isDigit) },
                label = { Text("Streams correspondentes ao pagamento") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
        }

        item {
            Card {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Datas do fechamento", fontWeight = FontWeight.ExtraBold)
                    OutlinedButton(
                        onClick = {
                            openDatePicker(actualPaidDate) { picked ->
                                actualPaidDateIso = picked.toString()
                                if (!cycleStartTouched) newCycleStartIso = picked.toString()
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Event, null)
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.Start) {
                            Text("Data em que recebi", style = MaterialTheme.typography.labelSmall)
                            Text(formatDate(actualPaidDateIso), fontWeight = FontWeight.Bold)
                        }
                    }
                    OutlinedButton(
                        onClick = {
                            openDatePicker(newCycleStart) { picked ->
                                cycleStartTouched = true
                                newCycleStartIso = picked.toString()
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.RestartAlt, null)
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.Start) {
                            Text("Início do novo ciclo", style = MaterialTheme.typography.labelSmall)
                            Text(formatDate(newCycleStartIso), fontWeight = FontWeight.Bold)
                        }
                    }
                    Text("Data esperada da distribuidora: ${formatDate(expectedPayoutDate.toString())}", style = MaterialTheme.typography.bodySmall)
                    Text("Ciclo anterior será considerado até ${formatDate(previousCycleLastDay.toString())}. Dados a partir de ${formatDate(newCycleStartIso)} entram no novo ciclo e os gráficos são recalculados pela janela corrigida.", style = MaterialTheme.typography.bodySmall)

                    if (actualPaidDate.dayOfMonth != expectedPayoutDate.dayOfMonth) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = adoptActualDayAsPattern, onCheckedChange = { adoptActualDayAsPattern = it })
                            Column {
                                Text("Usar este dia como novo padrão de pagamento", fontWeight = FontWeight.SemiBold)
                                Text("Deixe desmarcado se foi apenas um adiantamento ou atraso deste mês.", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        }

        if (streams != null && streams > 0) {
            item {
                MetricCard(
                    Modifier.fillMaxWidth(),
                    "Estimativa antes do pagamento",
                    money(estimatedBefore),
                    "Esse valor será usado internamente para medir a precisão do SONUS."
                )
            }
        }

        if (amount != null && streams != null && streams > 0) {
            val diff = amount - estimatedBefore
            val errorPercent = if (amount > 0) abs(diff) / amount * 100.0 else 0.0
            item {
                MetricCard(
                    Modifier.fillMaxWidth(),
                    "Resultado da calibração",
                    signedMoney(diff),
                    "Diferença da previsão • erro aproximado ${formatPercent(errorPercent)}"
                )
            }
        }

        item {
            Button(
                onClick = {
                    onSave(
                        RoyaltyPayment(
                            id = UUID.randomUUID().toString(),
                            artistId = artist.id,
                            paidDateIso = actualPaidDate.toString(),
                            amountBrl = amount ?: 0.0,
                            cycleStreams = streams ?: 0,
                            cycleStartIso = cycle.startIso,
                            cycleEndIso = previousCycleLastDay.toString(),
                            estimatedBrlBeforeCalibration = estimatedBefore,
                            rpmBeforeCalibration = rpmBefore,
                            referenceMonthIso = YearMonth.from(actualPaidDate).toString(),
                            expectedPayoutDateIso = expectedPayoutDate.toString(),
                            lastCountedDataDateIso = previousCycleLastDay.toString(),
                            newCycleStartIso = newCycleStart.toString(),
                            effectiveRpmBrlPerThousand = if ((streams ?: 0L) > 0L) (amount ?: 0.0) / (streams ?: 1L).toDouble() * 1000.0 else null,
                            adoptActualPayoutDayAsPattern = adoptActualDayAsPattern,
                            isRetroactive = false,
                            recordedAtEpochMillis = System.currentTimeMillis()
                        )
                    )
                },
                enabled = amount != null && amount > 0 && streams != null && streams > 0 && !newCycleStart.isAfter(today) && !actualPaidDate.isAfter(today),
                modifier = Modifier.fillMaxWidth().height(54.dp)
            ) { Text("Salvar pagamento e iniciar ciclo") }
        }

        item {
            Text(
                "A data real do pagamento e o início do ciclo são independentes da previsão da distribuidora. Corrigir o início do ciclo não apaga registros: o SONUS volta a incluir no cálculo os dados existentes dentro da nova janela.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

private data class HistoryCycleGroup(
    val start: LocalDate,
    val end: LocalDate,
    val entries: List<DailyStreamEntry>,
    val current: Boolean
)

@Composable
private fun HistoryScreen(
    state: AppState,
    artist: Artist,
    onReplaceSnapshot: (StreamSnapshot) -> Unit,
    onDeleteSnapshot: (String, String?) -> Unit,
    onUpsertDaily: (DailyStreamRecord) -> Unit,
    onDeleteDaily: (String, String?) -> Unit
) {
    val mode = resolvedStreamEntryMode(artist)
    val today = LocalDate.now()
    val currentCycle = DistributorRules.cycleFor(artist, today)
    val snapshots = state.snapshots.filter { it.artistId == artist.id }
    val dailyRecords = state.dailyStreamRecords.filter { it.artistId == artist.id }

    val latestSnapshots = snapshots.groupBy { it.dateIso }.mapNotNull { (_, sameDay) ->
        sameDay.maxWithOrNull(snapshotComparator())
    }.sortedBy { it.dateIso }
    val latestDaily = dailyRecords.groupBy { it.dateIso }.mapNotNull { (_, sameDay) ->
        sameDay.maxWithOrNull(compareBy<DailyStreamRecord> { it.recordedAtEpochMillis }.thenBy { it.id })
    }.sortedBy { it.dateIso }

    // O Histórico exibe a semântica real da distribuidora. TOTAL mostra leituras acumuladas;
    // DIA mostra incrementos diários. As duas fontes nunca são somadas entre si.
    val allEntries = if (mode == "TOTAL") {
        latestSnapshots.map { DailyStreamEntry(it.dateIso, it.cumulativeStreams.coerceAtLeast(0L), 0) }
    } else {
        latestDaily.map { DailyStreamEntry(it.dateIso, it.streams.coerceAtLeast(0L), HealthEngine.pointsForStreams(it.streams, 3)) }
    }

    val knownWindows = buildList {
        add(currentCycle)
        latestSnapshots.forEach { snap ->
            runCatching {
                val st = LocalDate.parse(snap.cycleStartIso)
                val en = LocalDate.parse(snap.cycleEndIso)
                if (!en.isBefore(st)) add(CycleWindow(st.toString(), en.toString(), "Histórico"))
            }
        }
    }.distinctBy { "${it.startIso}|${it.endIso}" }

    val groupedCycles = buildMap<String, MutableList<DailyStreamEntry>> {
        allEntries.forEach { entry ->
            val date = runCatching { LocalDate.parse(entry.dateIso) }.getOrNull() ?: return@forEach
            val known = knownWindows.firstOrNull { window ->
                val st = runCatching { LocalDate.parse(window.startIso) }.getOrNull()
                val en = runCatching { LocalDate.parse(window.endIso) }.getOrNull()
                st != null && en != null && !date.isBefore(st) && !date.isAfter(en)
            }
            val resolved = known ?: DistributorRules.cycleFor(artist, date)
            getOrPut("${resolved.startIso}|${resolved.endIso}") { mutableListOf() }.add(entry)
        }
    }

    val cycleGroups = buildList {
        groupedCycles.forEach { (key, entries) ->
            val parts = key.split("|")
            if (parts.size == 2) {
                val st = runCatching { LocalDate.parse(parts[0]) }.getOrNull()
                val en = runCatching { LocalDate.parse(parts[1]) }.getOrNull()
                if (st != null && en != null) add(
                    HistoryCycleGroup(
                        start = st,
                        end = en,
                        entries = entries.sortedBy { it.dateIso },
                        current = st.toString() == currentCycle.startIso && en.toString() == currentCycle.endIso
                    )
                )
            }
        }
        if (none { it.current }) {
            add(HistoryCycleGroup(LocalDate.parse(currentCycle.startIso), LocalDate.parse(currentCycle.endIso), emptyList(), true))
        }
    }.sortedByDescending { it.start }

    val cycleCumulativeByDate = remember(cycleGroups, mode) {
        buildMap<String, Long> {
            cycleGroups.forEach { group ->
                var running = 0L
                group.entries.sortedBy { it.dateIso }.forEach { entry ->
                    if (mode == "TOTAL") put(entry.dateIso, entry.streams.coerceAtLeast(0L))
                    else {
                        running += entry.streams.coerceAtLeast(0L)
                        put(entry.dateIso, running)
                    }
                }
            }
        }
    }

    var windowDays by rememberSaveable(artist.id) { mutableStateOf(0) }
    var selectedCycleKey by rememberSaveable(artist.id) { mutableStateOf("${currentCycle.startIso}|${currentCycle.endIso}") }
    var selectedDate by remember(artist.id, windowDays, selectedCycleKey) { mutableStateOf<String?>(null) }
    var detailDate by remember { mutableStateOf<String?>(null) }
    var editDate by remember { mutableStateOf<String?>(null) }
    var deleteDate by remember { mutableStateOf<String?>(null) }

    val selectedCycle = cycleGroups.firstOrNull { "${it.start}|${it.end}" == selectedCycleKey }
        ?: cycleGroups.firstOrNull { it.current }
        ?: cycleGroups.first()
    val latestDate = allEntries.lastOrNull()?.let { runCatching { LocalDate.parse(it.dateIso) }.getOrNull() } ?: today
    val windowStart = if (windowDays == 0) selectedCycle.start else latestDate.minusDays((windowDays - 1).toLong())
    val windowEnd = if (windowDays == 0) selectedCycle.end else latestDate
    val visible = if (windowDays == 0) selectedCycle.entries else allEntries.filter { entry ->
        val d = runCatching { LocalDate.parse(entry.dateIso) }.getOrNull() ?: return@filter false
        !d.isBefore(windowStart) && !d.isAfter(windowEnd)
    }
    val totalDays = if (windowDays == 0) (ChronoUnit.DAYS.between(windowStart, windowEnd) + 1L).toInt().coerceAtLeast(1) else windowDays
    val registeredDays = visible.map { it.dateIso }.distinct().size
    val missingDays = (totalDays - registeredDays).coerceAtLeast(0)
    val selectedEntry = selectedDate?.let { date -> visible.firstOrNull { it.dateIso == date } }
    val detailEntry = detailDate?.let { date -> allEntries.firstOrNull { it.dateIso == date } }
    val indexByDate = allEntries.mapIndexed { index, entry -> entry.dateIso to index }.toMap()

    fun previousFor(entry: DailyStreamEntry): DailyStreamEntry? = indexByDate[entry.dateIso]?.let { allEntries.getOrNull(it - 1) }
    fun percentChange(entry: DailyStreamEntry): Double? {
        val previous = previousFor(entry) ?: return null
        if (previous.streams <= 0L) return null
        return (entry.streams - previous.streams).toDouble() / previous.streams.toDouble() * 100.0
    }

    if (detailEntry != null) {
        val previous = previousFor(detailEntry)
        val delta = if (mode == "TOTAL") (detailEntry.streams - (previous?.streams ?: detailEntry.streams)).coerceAtLeast(0L) else detailEntry.streams
        AlertDialog(
            onDismissRequest = { detailDate = null },
            confirmButton = { TextButton(onClick = { detailDate = null }) { Text("Fechar") } },
            title = { Text(formatDate(detailEntry.dateIso)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        if (mode == "TOTAL") "${formatNumber(detailEntry.streams)} acumulados" else "+${formatNumber(detailEntry.streams)} no dia",
                        fontWeight = FontWeight.Bold, fontSize = 22.sp
                    )
                    if (mode == "TOTAL") Text(if (previous == null) "Primeira leitura do ciclo" else "+${formatNumber(delta)} desde a leitura anterior")
                    Text("Variação: ${percentChange(detailEntry)?.let(::formatSignedPercent) ?: "Sem comparação anterior"}")
                    Text(if (mode == "TOTAL") "Leitura acumulada oficial" else "Valor diário oficial")
                }
            }
        )
    }

    editDate?.let { dateIso ->
        val entry = allEntries.firstOrNull { it.dateIso == dateIso }
        if (entry != null) {
            var editText by remember(dateIso) { mutableStateOf(entry.streams.toString()) }
            val newValue = editText.filter(Char::isDigit).toLongOrNull()
            val index = indexByDate[dateIso] ?: -1
            val prev = allEntries.getOrNull(index - 1)?.streams
            val next = allEntries.getOrNull(index + 1)?.streams
            val invalidTotal = mode == "TOTAL" && newValue != null && ((prev != null && newValue < prev) || (next != null && newValue > next))
            AlertDialog(
                onDismissRequest = { editDate = null },
                title = { Text(if (mode == "TOTAL") "Editar total acumulado" else "Editar valor do dia") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(formatDate(dateIso), fontWeight = FontWeight.Bold)
                        OutlinedTextField(
                            value = editText,
                            onValueChange = { editText = it.filter(Char::isDigit) },
                            label = { Text(if (mode == "TOTAL") "Total acumulado" else "Streams do dia") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            isError = invalidTotal
                        )
                        if (invalidTotal) Text(
                            "No modo acumulado, o valor precisa ficar entre a leitura anterior${prev?.let { " (${formatNumber(it)})" }.orEmpty()} e a próxima${next?.let { " (${formatNumber(it)})" }.orEmpty()}.",
                            color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall
                        )
                    }
                },
                confirmButton = {
                    TextButton(
                        enabled = newValue != null && !invalidTotal,
                        onClick = {
                            val value = newValue ?: return@TextButton
                            if (mode == "TOTAL") {
                                val existing = latestSnapshots.firstOrNull { it.dateIso == dateIso }
                                val window = existing?.let { CycleWindow(it.cycleStartIso, it.cycleEndIso, "") } ?: DistributorRules.cycleFor(artist, LocalDate.parse(dateIso))
                                onReplaceSnapshot(
                                    StreamSnapshot(
                                        id = existing?.id ?: UUID.randomUUID().toString(),
                                        artistId = artist.id,
                                        dateIso = dateIso,
                                        cumulativeStreams = value,
                                        cycleStartIso = window.startIso,
                                        cycleEndIso = window.endIso,
                                        recordedAtEpochMillis = System.currentTimeMillis(),
                                        estimatedBrlAtSave = existing?.estimatedBrlAtSave,
                                        cycleId = existing?.cycleId ?: if (window.startIso == artist.financialCycleStartIso) artist.financialCycleId else null
                                    )
                                )
                            } else {
                                val existing = latestDaily.firstOrNull { it.dateIso == dateIso }
                                onUpsertDaily(
                                    DailyStreamRecord(
                                        id = existing?.id ?: UUID.randomUUID().toString(),
                                        artistId = artist.id,
                                        dateIso = dateIso,
                                        streams = value,
                                        recordedAtEpochMillis = System.currentTimeMillis(),
                                        cycleId = existing?.cycleId ?: if (!LocalDate.parse(dateIso).isBefore(LocalDate.parse(currentCycle.startIso)) && !LocalDate.parse(dateIso).isAfter(LocalDate.parse(currentCycle.endIso))) artist.financialCycleId else null
                                    )
                                )
                            }
                            editDate = null
                            detailDate = null
                        }
                    ) { Text("Salvar") }
                },
                dismissButton = { TextButton(onClick = { editDate = null }) { Text("Cancelar") } }
            )
        }
    }

    deleteDate?.let { dateIso ->
        val entry = allEntries.firstOrNull { it.dateIso == dateIso }
        if (entry != null) {
            AlertDialog(
                onDismissRequest = { deleteDate = null },
                title = { Text("Remover registro?") },
                text = {
                    val isLatest = allEntries.lastOrNull()?.dateIso == dateIso
                    Text(
                        if (mode == "TOTAL" && isLatest) "Ao remover a última leitura oficial, o total voltará para a leitura acumulada anterior. Todos os cálculos serão refeitos automaticamente."
                        else "O registro de ${formatDate(dateIso)} será removido e gráfico, médias, projeções e financeiro serão recalculados."
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        if (mode == "TOTAL") {
                            val existing = latestSnapshots.firstOrNull { it.dateIso == dateIso }
                            onDeleteSnapshot(dateIso, existing?.cycleId)
                        } else {
                            val existing = latestDaily.firstOrNull { it.dateIso == dateIso }
                            onDeleteDaily(dateIso, existing?.cycleId)
                        }
                        deleteDate = null
                        detailDate = null
                    }) { Text("Remover", color = MaterialTheme.colorScheme.error) }
                },
                dismissButton = { TextButton(onClick = { deleteDate = null }) { Text("Cancelar") } }
            )
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp),
        contentPadding = PaddingValues(top = 18.dp, bottom = 30.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { HistoryRecordHighlights(state, artist) }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                ArtistAvatar(artist.photoPath, 58.dp, fallbackToLogo = true, avatarId = artist.avatarId)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("Histórico", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Text(
                        (if (mode == "TOTAL") "Total acumulado" else "Valor diário") + " • " +
                            if (windowDays == 0) "ciclo ${formatCompactDate(windowStart.toString())} → ${formatCompactDate(windowEnd.toString())}" else "últimos $windowDays dias",
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = .62f)
                    )
                }
            }
        }
        item {
            HistoryWindowSelector(windowDays) { newWindow ->
                windowDays = newWindow
                if (newWindow == 0) selectedCycleKey = "${currentCycle.startIso}|${currentCycle.endIso}"
                selectedDate = null
            }
        }
        if (windowDays == 0) {
            item {
                HistoryCycleHeaderCard(
                    artist = artist,
                    group = selectedCycle,
                    registeredDays = registeredDays,
                    totalStreams = if (mode == "TOTAL") visible.lastOrNull()?.streams ?: 0L else visible.sumOf { it.streams }
                )
            }
        }
        item {
            HistoryStreamsChartCard(entries = visible, selectedEntry = selectedEntry, percentFor = ::percentChange, onSelect = { selectedDate = it.dateIso })
        }
        item { HistoryQualityStrip(registeredDays, totalDays, missingDays, windowStart, windowEnd) }
        item {
            HistoryRecentRecordsCard(
                allEntries = allEntries,
                visibleEntries = visible,
                cycleCumulativeByDate = cycleCumulativeByDate,
                percentFor = ::percentChange,
                entryMode = mode,
                onOpen = { detailDate = it.dateIso },
                onEdit = { editDate = it.dateIso },
                onDelete = { deleteDate = it.dateIso }
            )
        }
        val archived = cycleGroups.filterNot { it.current }
        if (archived.isNotEmpty()) {
            item { Text("Ciclos anteriores", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold) }
            items(archived, key = { "${it.start}|${it.end}" }) { group ->
                HistoryCycleFolderCard(group) {
                    selectedCycleKey = "${group.start}|${group.end}"
                    windowDays = 0
                    selectedDate = null
                }
            }
        }
        item { Text("Histórico dedicado aos streams • edite ou remova leituras sem misturar TOTAL e DIA.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha=.58f)) }
    }
}

@Composable
private fun ActivitySummaryCard(records: List<UserActivityRecord>) {
    val karaoke = records.count { it.title.contains("Karaokê", true) }
    val tools = records.count { it.category == "tool" && it.success != false }
    val completed = records.count { it.success == true }
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .52f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = .16f))
    ) {
        Row(
            Modifier.fillMaxWidth().padding(13.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ActivityMiniStat("Atividades", records.size.toString(), Modifier.weight(1f))
            ActivityMiniStat("Ferramentas", tools.toString(), Modifier.weight(1f))
            ActivityMiniStat("Karaokê", karaoke.toString(), Modifier.weight(1f))
            ActivityMiniStat("Concluídas", completed.toString(), Modifier.weight(1f))
        }
    }
}

@Composable
private fun ActivityMiniStat(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontWeight = FontWeight.Black, fontSize = 18.sp, color = MaterialTheme.colorScheme.primary)
        Text(label, style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center, maxLines = 1)
    }
}

@Composable
private fun ActivityHeatmap(records: List<UserActivityRecord>) {
    val today = LocalDate.now()
    val counts = remember(records) {
        records.groupingBy {
            Instant.ofEpochMilli(it.createdAtEpochMillis).atZone(ZoneId.systemDefault()).toLocalDate()
        }.eachCount()
    }
    val sevenDays = (0..6).sumOf { counts[today.minusDays(it.toLong())] ?: 0 }
    val activeDays7 = (0..6).count { (counts[today.minusDays(it.toLong())] ?: 0) > 0 }
    Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surface.copy(alpha = .62f)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Últimos 28 dias", fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                Text("7d: $sevenDays atividades • $activeDays7 dias ativos", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                (27 downTo 0).forEach { ago ->
                    val count = counts[today.minusDays(ago.toLong())] ?: 0
                    val alpha = when {
                        count == 0 -> .10f
                        count <= 2 -> .28f
                        count <= 5 -> .48f
                        count <= 9 -> .68f
                        else -> .92f
                    }
                    Box(
                        Modifier.weight(1f).height(18.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = alpha))
                    )
                }
            }
            Text("Quanto mais forte o bloco, mais atividades naquele dia.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .52f))
        }
    }
}

@Composable
private fun ActivityTimelineRow(record: UserActivityRecord, onDelete: () -> Unit) {
    val date = remember(record.createdAtEpochMillis) {
        Instant.ofEpochMilli(record.createdAtEpochMillis)
            .atZone(ZoneId.systemDefault())
            .format(DateTimeFormatter.ofPattern("dd/MM • HH:mm"))
    }
    val icon = when {
        record.title.contains("Karaokê", true) -> Icons.Default.Mic
        record.title.contains("Conversor", true) -> Icons.Default.GraphicEq
        record.category == "Financeiro" -> Icons.Default.Payments
        record.category == "page" -> Icons.Default.Visibility
        record.success == false -> Icons.Default.ErrorOutline
        else -> Icons.Default.CheckCircleOutline
    }
    Surface(
        shape = RoundedCornerShape(17.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .38f)
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 11.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary.copy(alpha = .13f)) {
                Icon(icon, null, modifier = Modifier.padding(8.dp).size(18.dp), tint = if (record.success == false) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
            }
            Spacer(Modifier.width(9.dp))
            Column(Modifier.weight(1f)) {
                Text(record.title, fontWeight = FontWeight.Bold)
                val detail = buildList {
                    record.detail?.takeIf { it.isNotBlank() }?.let(::add)
                    record.durationMs?.takeIf { it > 0 }?.let { add(formatDurationShort(it)) }
                    add(date)
                }.joinToString(" • ")
                Text(detail, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .58f), maxLines = 2)
            }
            IconButton(onClick = onDelete) { Icon(Icons.Default.Close, "Excluir atividade", modifier = Modifier.size(18.dp)) }
        }
    }
}

@Composable
private fun HistoryWindowSelector(selected: Int, onSelect: (Int) -> Unit) {
    Surface(
        shape = RoundedCornerShape(22.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = .72f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = .22f))
    ) {
        Row(Modifier.fillMaxWidth().height(52.dp)) {
            listOf(7 to "7 dias", 14 to "14 dias", 30 to "30 dias", 0 to "Ciclo").forEach { (days, label) ->
                val active = selected == days
                Box(
                    modifier = Modifier.weight(1f).fillMaxHeight()
                        .padding(3.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(
                            if (active) Brush.horizontalGradient(
                                listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.secondary)
                            ) else Brush.linearGradient(listOf(Color.Transparent, Color.Transparent))
                        )
                        .clickable { onSelect(days) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        label,
                        fontSize = 11.sp,
                        fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
                        color = if (active) Color.White else MaterialTheme.colorScheme.onSurface.copy(alpha = .68f)
                    )
                }
            }
        }
    }
}

@Composable
private fun HistoryCycleHeaderCard(
    artist: Artist,
    group: HistoryCycleGroup,
    registeredDays: Int,
    totalStreams: Long
) {
    val health = HealthEngine.calculate(
        entries = group.entries,
        cycleStartIso = group.start.toString(),
        cycleEndIso = group.end.toString(),
        referenceDateIso = if (group.current) LocalDate.now().toString() else group.end.toString()
    )
    val accent = if (group.current) SignalBlue else SignalOrange
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = accent.copy(alpha = .10f),
        border = BorderStroke(1.dp, accent.copy(alpha = .32f))
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(if (group.current) Icons.Default.FolderOpen else Icons.Default.Folder, null, tint = accent)
                Spacer(Modifier.width(8.dp))
                Text(
                    if (group.current) "Ciclo atual — ${DistributorRules.displayName(artist.distributor, artist.customDistributorName)}"
                    else "Ciclo arquivado",
                    fontWeight = FontWeight.ExtraBold,
                    modifier = Modifier.weight(1f)
                )
            }
            Text("${formatDate(group.start.toString())} → ${formatDate(group.end.toString())}", fontWeight = FontWeight.SemiBold)
            Text("$registeredDays registro(s) • ${formatNumber(totalStreams)} streams no período", style = MaterialTheme.typography.bodySmall)
            Text(
                if (group.current) "Saúde atual: ${health.score} • ${health.label}" else "Saúde final: ${health.score}/100 • ${health.label}",
                style = MaterialTheme.typography.bodySmall,
                color = healthPerformanceColor(health.performancePercent, health.scoredDays == 0),
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
private fun HistoryCycleFolderCard(group: HistoryCycleGroup, onOpen: () -> Unit) {
    val health = HealthEngine.calculate(
        entries = group.entries,
        cycleStartIso = group.start.toString(),
        cycleEndIso = group.end.toString(),
        referenceDateIso = group.end.toString()
    )
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onOpen),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = .78f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = .14f))
    ) {
        Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = RoundedCornerShape(12.dp), color = SignalOrange.copy(alpha = .16f)) {
                Icon(Icons.Default.Folder, null, tint = SignalOrange, modifier = Modifier.padding(9.dp).size(22.dp))
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("${formatCompactDate(group.start.toString())} → ${formatCompactDate(group.end.toString())}", fontWeight = FontWeight.Bold)
                Text("${group.entries.size} registro(s) • ${formatNumber(group.entries.sumOf { it.streams })} streams", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .58f))
                Text("Saúde final: ${health.score}/100 • ${health.label}", style = MaterialTheme.typography.labelSmall, color = healthPerformanceColor(health.performancePercent, health.scoredDays == 0), fontWeight = FontWeight.SemiBold)
            }
            Icon(Icons.Default.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurface.copy(alpha = .35f))
        }
    }
}

@Composable
private fun HistoryStreamsChartCard(
    entries: List<DailyStreamEntry>,
    selectedEntry: DailyStreamEntry?,
    percentFor: (DailyStreamEntry) -> Double?,
    onSelect: (DailyStreamEntry) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = .88f)),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = .20f))
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Streams por dia", fontWeight = FontWeight.Bold, fontSize = 20.sp)
            if (entries.isEmpty()) {
                Box(Modifier.fillMaxWidth().height(230.dp), contentAlignment = Alignment.Center) {
                    Text("Ainda não há registros neste período.", color = MaterialTheme.colorScheme.onSurface.copy(alpha = .60f))
                }
                return@Column
            }

            val minValue = entries.minOf { it.streams }.toDouble()
            val maxValue = entries.maxOf { it.streams }.toDouble()
            val average = entries.map { it.streams.toDouble() }.average()
            val spread = (maxValue - minValue).takeIf { it > 0.0 } ?: maxOf(1.0, maxValue * .20)
            val chartMin = (minValue - spread * .14).coerceAtLeast(0.0)
            val chartMax = maxValue + spread * .14
            val chartOnSurface = MaterialTheme.colorScheme.onSurface
            val chartPrimary = MaterialTheme.colorScheme.primary
            val chartSecondary = MaterialTheme.colorScheme.secondary
            var chartWidthPx by remember(entries) { mutableFloatStateOf(1f) }

            Canvas(
                Modifier.fillMaxWidth().height(238.dp)
                    .onSizeChanged { chartWidthPx = it.width.toFloat().coerceAtLeast(1f) }
                    .pointerInput(entries) {
                        detectTapGestures { offset ->
                            val ratio = (offset.x / chartWidthPx).coerceIn(0f, 1f)
                            val index = (ratio * entries.lastIndex.coerceAtLeast(0)).roundToInt().coerceIn(0, entries.lastIndex)
                            onSelect(entries[index])
                        }
                    }
            ) {
                val left = 8.dp.toPx()
                val right = size.width - 8.dp.toPx()
                val top = 10.dp.toPx()
                val bottom = size.height - 12.dp.toPx()
                val width = (right - left).coerceAtLeast(1f)
                val height = (bottom - top).coerceAtLeast(1f)

                fun xAt(index: Int): Float = if (entries.size <= 1) left + width / 2f else left + width * index / entries.lastIndex.toFloat()
                fun yAt(value: Double): Float {
                    val fraction = ((value - chartMin) / (chartMax - chartMin)).coerceIn(0.0, 1.0)
                    return bottom - (height * fraction).toFloat()
                }

                repeat(5) { grid ->
                    val y = top + height * grid / 4f
                    drawLine(
                        color = chartOnSurface.copy(alpha = .08f),
                        start = Offset(left, y),
                        end = Offset(right, y),
                        strokeWidth = 1.dp.toPx()
                    )
                }

                val linePath = Path()
                entries.forEachIndexed { index, entry ->
                    val x = xAt(index)
                    val y = yAt(entry.streams.toDouble())
                    if (index == 0) linePath.moveTo(x, y) else linePath.lineTo(x, y)
                }

                val fillPath = Path().apply {
                    entries.forEachIndexed { index, entry ->
                        val x = xAt(index)
                        val y = yAt(entry.streams.toDouble())
                        if (index == 0) moveTo(x, y) else lineTo(x, y)
                    }
                    lineTo(xAt(entries.lastIndex), bottom)
                    lineTo(xAt(0), bottom)
                    close()
                }

                drawPath(
                    path = fillPath,
                    brush = Brush.verticalGradient(
                        listOf(
                            chartSecondary.copy(alpha = .38f),
                            chartPrimary.copy(alpha = .10f),
                            Color.Transparent
                        ),
                        startY = top,
                        endY = bottom
                    )
                )
                drawPath(
                    path = linePath,
                    brush = Brush.horizontalGradient(
                        listOf(Color(0xFF1EDCFF), chartPrimary, Color(0xFFD680FF)),
                        startX = left,
                        endX = right
                    ),
                    style = Stroke(width = 3.2.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round)
                )

                val averageY = yAt(average)
                drawLine(
                    color = chartOnSurface.copy(alpha = .36f),
                    start = Offset(left, averageY),
                    end = Offset(right, averageY),
                    strokeWidth = 1.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(8.dp.toPx(), 6.dp.toPx()))
                )

                entries.forEachIndexed { index, entry ->
                    val x = xAt(index)
                    val y = yAt(entry.streams.toDouble())
                    val selected = selectedEntry?.dateIso == entry.dateIso
                    if (selected) drawCircle(chartPrimary.copy(alpha = .26f), 10.dp.toPx(), Offset(x, y))
                    drawCircle(if (selected) Color.White else chartSecondary, if (selected) 5.dp.toPx() else 3.dp.toPx(), Offset(x, y))
                }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                val first = entries.firstOrNull()?.dateIso?.let(::formatCompactDate).orEmpty()
                val middle = entries.getOrNull(entries.size / 2)?.dateIso?.let(::formatCompactDate).orEmpty()
                val last = entries.lastOrNull()?.dateIso?.let(::formatCompactDate).orEmpty()
                Text(first, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .55f))
                Text(middle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .55f))
                Text(last, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .55f))
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.width(30.dp).height(1.dp).background(MaterialTheme.colorScheme.onSurface.copy(alpha = .35f)))
                Spacer(Modifier.width(6.dp))
                Text("média do período: ${formatNumber(average.roundToLong())}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .58f))
            }

            selectedEntry?.let { entry ->
                val change = percentFor(entry)
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.primary.copy(alpha = .13f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = .34f))
                ) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(formatDate(entry.dateIso), Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                        Text("${formatNumber(entry.streams)} streams", fontWeight = FontWeight.Bold)
                        Spacer(Modifier.width(10.dp))
                        Text(change?.let(::formatSignedPercent) ?: "—", color = historyMovementColor(change), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun HistoryQualityStrip(
    registeredDays: Int,
    totalDays: Int,
    missingDays: Int,
    startDate: LocalDate,
    endDate: LocalDate
) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = .80f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = .16f))
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 13.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            HistoryQualityCell(Modifier.weight(1f), "$registeredDays/$totalDays", "dias registrados", SignalGreen)
            HistoryQualityCell(Modifier.weight(1f), missingDays.toString(), "sem dados", if (missingDays == 0) SignalGreen else SignalOrange)
            HistoryQualityCell(
                Modifier.weight(1.25f),
                "${startDate.format(DateTimeFormatter.ofPattern("dd/MM"))} → ${endDate.format(DateTimeFormatter.ofPattern("dd/MM"))}",
                "intervalo",
                MaterialTheme.colorScheme.primary
            )
        }
    }
}

@Composable
private fun HistoryQualityCell(modifier: Modifier, value: String, label: String, accent: Color) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(value, fontWeight = FontWeight.ExtraBold, fontFamily = FontFamily.Monospace, color = accent, textAlign = TextAlign.Center, maxLines = 1)
        Text(label, style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .60f), maxLines = 2)
    }
}

@Composable
private fun HistoryRecentRecordsCard(
    allEntries: List<DailyStreamEntry>,
    visibleEntries: List<DailyStreamEntry>,
    cycleCumulativeByDate: Map<String, Long>,
    percentFor: (DailyStreamEntry) -> Double?,
    entryMode: String,
    onOpen: (DailyStreamEntry) -> Unit,
    onEdit: (DailyStreamEntry) -> Unit,
    onDelete: (DailyStreamEntry) -> Unit
) {
    val orderedVisible = visibleEntries.sortedBy { it.dateIso }
    val recent = orderedVisible.asReversed()
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = .88f)),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = .18f))
    ) {
        Column {
            Text("Todos os registros do período", modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp), fontSize = 20.sp, fontWeight = FontWeight.Bold)
            if (recent.isEmpty()) {
                Text("Nenhum registro neste período.", modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp), color = MaterialTheme.colorScheme.onSurface.copy(alpha = .60f))
            } else {
                recent.forEachIndexed { rowIndex, entry ->
                    val allIndex = allEntries.indexOfFirst { it.dateIso == entry.dateIso }
                    val miniValues = if (allIndex >= 0) allEntries.take(allIndex + 1).takeLast(8).map { it.streams } else listOf(entry.streams)
                    val change = percentFor(entry)
                    Row(
                        Modifier.fillMaxWidth().clickable { onOpen(entry) }.padding(horizontal = 14.dp, vertical = 11.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(formatCompactDate(entry.dateIso), modifier = Modifier.width(54.dp), color = MaterialTheme.colorScheme.onSurface.copy(alpha = .72f))
                        HistoryMiniBars(miniValues, Modifier.weight(1f))
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.widthIn(min = 116.dp), horizontalAlignment = Alignment.End) {
                            if (entryMode == "TOTAL") {
                                val previousIndex = allEntries.indexOfFirst { it.dateIso == entry.dateIso } - 1
                                val previous = allEntries.getOrNull(previousIndex)?.streams
                                val delta = if (previous == null) null else (entry.streams - previous).coerceAtLeast(0L)
                                Text(
                                    delta?.let { if (it == 0L) "sem crescimento" else "+${formatNumber(it)} desde anterior" } ?: "primeira leitura",
                                    color = if (delta == 0L) MaterialTheme.colorScheme.onSurface.copy(alpha = .55f) else SignalOrange,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text("${formatNumber(entry.streams)} acumulados", fontWeight = FontWeight.ExtraBold, fontFamily = FontFamily.Monospace, textAlign = TextAlign.End)
                            } else {
                                Text("+${formatNumber(entry.streams)} no dia", color = SignalOrange, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold)
                                Text("${formatNumber(cycleCumulativeByDate[entry.dateIso] ?: entry.streams)} acumulados", fontWeight = FontWeight.ExtraBold, fontFamily = FontFamily.Monospace, textAlign = TextAlign.End)
                            }
                            Text(change?.let(::formatSignedPercent) ?: "—", color = historyMovementColor(change), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            IconButton(onClick = { onEdit(entry) }, modifier = Modifier.size(30.dp)) {
                                Icon(Icons.Default.Edit, "Editar", modifier = Modifier.size(16.dp))
                            }
                            IconButton(onClick = { onDelete(entry) }, modifier = Modifier.size(30.dp)) {
                                Icon(Icons.Default.DeleteOutline, "Remover", modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                    if (rowIndex != recent.lastIndex) HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = .07f))
                }
            }
        }
    }
}

@Composable
private fun HistoryMiniBars(values: List<Long>, modifier: Modifier = Modifier) {
    val maxValue = values.maxOrNull()?.coerceAtLeast(1L) ?: 1L
    Row(modifier.height(28.dp), horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.Bottom) {
        values.forEach { value ->
            val ratio = value.toFloat() / maxValue.toFloat()
            Box(
                Modifier.width(3.dp)
                    .height((5 + 21 * ratio).dp)
                    .background(
                        Brush.verticalGradient(listOf(MaterialTheme.colorScheme.secondary, MaterialTheme.colorScheme.primary)),
                        RoundedCornerShape(2.dp)
                    )
            )
        }
    }
}

@Composable
private fun historyMovementColor(percent: Double?): Color = when {
    percent == null -> MaterialTheme.colorScheme.onSurface.copy(alpha = .50f)
    percent >= 2.0 -> SignalGreen
    percent <= -2.0 -> SignalRed
    else -> SignalPurple
}

private fun formatCompactDate(dateIso: String): String = runCatching {
    LocalDate.parse(dateIso).format(DateTimeFormatter.ofPattern("dd/MM"))
}.getOrDefault(dateIso.takeLast(5))


@Composable
private fun AnalyticsScreen(state: AppState, artist: Artist, membershipTier: MembershipTier, isOwner: Boolean, onGuide: () -> Unit) {
    val snapshots = state.snapshots.filter { it.artistId == artist.id }
    val manualDailyRecords = state.dailyStreamRecords.filter { it.artistId == artist.id }
    val analyticsCycle = DistributorRules.cycleFor(artist, LocalDate.now())
    val health = HealthEngine.calculateFromSnapshots(snapshots, manualDailyRecords, cycle = analyticsCycle, referenceDate = LocalDate.now())
    val daily = unifiedAnalyticsEntries(state, artist)
    val trend3 = AnalyticsEngine.trendFromDailyEntries(daily, 3)
    val trend7 = AnalyticsEngine.trendFromDailyEntries(daily, 7)
    val trend14 = AnalyticsEngine.trendFromDailyEntries(daily, 14)
    val best = daily.maxByOrNull { it.streams }
    val weakest = daily.minByOrNull { it.streams }
    val average = daily.takeIf { it.isNotEmpty() }?.map { it.streams.toDouble() }?.average() ?: 0.0
    val aboveAverage = daily.count { it.streams.toDouble() > average }
    val belowAverage = daily.count { it.streams.toDouble() < average }
    val changes = daily.zipWithNext().mapNotNull { (a, b) ->
        if (a.streams <= 0L) null
        else Triple(b.dateIso, (b.streams - a.streams).toDouble() / a.streams.toDouble() * 100.0, b.streams - a.streams)
    }
    val biggestRise = changes.filter { it.second > 0.0 }.maxByOrNull { it.second }
    val biggestDrop = changes.filter { it.second < 0.0 }.minByOrNull { it.second }
    val volatility = changes.takeIf { it.isNotEmpty() }?.map { abs(it.second) }?.average()
    var positiveStreak = 0
    var negativeStreak = 0
    for (change in changes.asReversed()) {
        if (change.second > 0.0 && negativeStreak == 0) positiveStreak++
        else if (change.second < 0.0 && positiveStreak == 0) negativeStreak++
        else break
    }
    val stabilityLabel = when {
        volatility == null -> "Formando base"
        volatility < 10.0 -> "Muito estável"
        volatility < 25.0 -> "Estável"
        volatility < 50.0 -> "Variável"
        else -> "Volátil"
    }
    val diagnosis = when {
        daily.size < 4 -> "Ainda estamos formando uma base. Preencha mais dias para comparar janelas e identificar padrões com segurança."
        trend7.percentChange != null && trend7.direction > 0 -> "Os últimos registros mostram avanço. ${aboveAverage} de ${daily.size} dia(s) ficaram acima da média e a janela de 7 registros está em aceleração."
        trend7.percentChange != null && trend7.direction < 0 -> "A janela de 7 registros está em desaceleração. Vale observar os próximos dias para confirmar se a queda é pontual ou uma mudança de ritmo."
        else -> "O comportamento recente está relativamente estável. A leitura melhora conforme novos registros diários entram na base."
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(13.dp),
        contentPadding = PaddingValues(top = 18.dp, bottom = 30.dp)
    ) {
        item { Text("Análises", fontSize = 27.sp, fontWeight = FontWeight.Bold) }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Comparação por janelas", fontWeight = FontWeight.Bold)
                    Text("Entenda se o desempenho está mudando sem repetir os indicadores rápidos da tela Início.", style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(3.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AnalysisWindowCard(Modifier.weight(1f), "3 registros", trend3)
                        AnalysisWindowCard(Modifier.weight(1f), "7 registros", trend7)
                        AnalysisWindowCard(Modifier.weight(1f), "14 registros", trend14)
                    }
                }
            }
        }

        if (daily.isNotEmpty()) item { AnalysisEvolutionCard(daily.takeLast(14)) }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MetricCard(
                    Modifier.weight(1f),
                    "Melhor registro",
                    best?.let { formatNumber(it.streams) } ?: "—",
                    best?.let { formatDate(it.dateIso) } ?: "Sem dados"
                )
                MetricCard(
                    Modifier.weight(1f),
                    "Menor registro",
                    weakest?.let { formatNumber(it.streams) } ?: "—",
                    weakest?.let { formatDate(it.dateIso) } ?: "Sem dados"
                )
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MetricCard(
                    Modifier.weight(1f),
                    "Maior alta diária",
                    biggestRise?.let { formatSignedPercent(it.second) } ?: "—",
                    biggestRise?.let { formatDate(it.first) } ?: "Sem comparação"
                )
                MetricCard(
                    Modifier.weight(1f),
                    "Maior queda diária",
                    biggestDrop?.let { formatSignedPercent(it.second) } ?: "—",
                    biggestDrop?.let { formatDate(it.first) } ?: "Sem comparação"
                )
            }
        }

        item {
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Comportamento da base", fontWeight = FontWeight.Bold)
                    AnalysisStatRow("Média dos dias registrados", if (daily.isNotEmpty()) "${formatNumber(average.roundToLong())} streams" else "—")
                    AnalysisStatRow("Dias acima da média", "$aboveAverage")
                    AnalysisStatRow("Dias abaixo da média", "$belowAverage")
                    AnalysisStatRow("Sequência positiva atual", "$positiveStreak dia(s)")
                    AnalysisStatRow("Sequência negativa atual", "$negativeStreak dia(s)")
                    AnalysisStatRow("Oscilação média", volatility?.let { "${String.format(Locale("pt", "BR"), "%.1f", it)}% • $stabilityLabel" } ?: stabilityLabel)
                }
            }
        }

        item {
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Qualidade da base", fontWeight = FontWeight.Bold)
                    Text("${daily.size} dia(s) com informação diária disponível")
                    Text("${health.scoredDays} dia(s) considerados na Saúde do Projeto")
                    Text(
                        if (health.missingDays > 0) "${health.missingDays} lacuna(s) detectada(s) entre registros."
                        else "Nenhuma lacuna detectada entre os dias calculáveis.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        if (state.preferences.showSmartSummary) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AutoGraph, null)
                            Spacer(Modifier.width(8.dp))
                            Text("Diagnóstico da análise", fontWeight = FontWeight.Bold)
                        }
                        Text(diagnosis)
                    }
                }
            }
        }

        item { DistributorIntelligenceSection(state, artist, membershipTier, isOwner) }
        item { AnalyticsPremiumTools(state = state, artist = artist, daily = daily, health = health, changes = changes) }
        item { StreamPulseGuideEntryCard(onClick = onGuide) }
    }
}

@Composable
private fun AnalyticsPremiumTools(
    state: AppState,
    artist: Artist,
    daily: List<DailyStreamEntry>,
    health: HealthResult,
    changes: List<Triple<String, Double, Long>>
) {
    var showSimulator by remember { mutableStateOf(false) }
    var simulatorInput by rememberSaveable { mutableStateOf("") }
    var detailTitle by remember { mutableStateOf<String?>(null) }
    var detailBody by remember { mutableStateOf<String?>(null) }

    val anomalies = changes.filter { abs(it.second) >= 75.0 }
    val qualityScore = (100 - health.missingDays * 8 - anomalies.size * 5).coerceIn(0, 100)
    val auditSummary = when {
        daily.size < 4 -> "Base pequena • qualidade $qualityScore/100"
        qualityScore >= 90 -> "Base muito confiável • $qualityScore/100"
        qualityScore >= 70 -> "Boa base • $qualityScore/100"
        else -> "Base pede atenção • $qualityScore/100"
    }

    val artistAverages = state.artists.map { candidate ->
        val entries = unifiedAnalyticsEntries(state, candidate).takeLast(14)
        candidate to (entries.takeIf { it.isNotEmpty() }?.map { it.streams.toDouble() }?.average() ?: 0.0)
    }.sortedByDescending { it.second }
    val leader = artistAverages.firstOrNull()

    if (showSimulator) {
        val cycle = DistributorRules.cycleFor(artist, LocalDate.now())
        val cycleSnapshots = state.snapshots.filter { it.artistId == artist.id && snapshotInCycle(it, cycle) }
        val rpm = RoyaltyEngine.personalizedRpm(artist, state.payments.filter { it.artistId == artist.id })
        val cycleDailyRecords = state.dailyStreamRecords.filter { it.artistId == artist.id && snapshotDateInCycle(it.dateIso, cycle) }
        val forecast = RoyaltyEngine.forecast(
            cycleSnapshots,
            cycleDailyRecords,
            LocalDate.parse(cycle.startIso),
            LocalDate.parse(cycle.endIso),
            LocalDate.now(),
            rpm
        )
        val daysRemaining = ChronoUnit.DAYS.between(LocalDate.now(), LocalDate.parse(cycle.endIso)).coerceAtLeast(0) + 1L
        val pace = simulatorInput.filter { it.isDigit() }.toLongOrNull()
        val projectedStreams = pace?.let { forecast.currentStreams + it * daysRemaining }
        val projectedBrl = projectedStreams?.let { RoyaltyEngine.estimateBrl(it, rpm) }
        AlertDialog(
            onDismissRequest = { showSimulator = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PremiumFeatureMark(MembershipTier.PRATA)
                    Text("Simulador de Meta", fontWeight = FontWeight.ExtraBold)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Teste um ritmo diário e veja como o ciclo terminaria se esse desempenho fosse mantido.")
                    OutlinedTextField(
                        value = simulatorInput,
                        onValueChange = { simulatorInput = it.filter(Char::isDigit).take(9) },
                        label = { Text("Streams por dia") },
                        placeholder = { Text("Ex.: 3000") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (projectedStreams != null && projectedBrl != null) {
                        Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = .62f)) {
                            Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                Text("Fechamento simulado", fontWeight = FontWeight.Bold)
                                Text("${formatNumber(projectedStreams)} streams", fontSize = 21.sp, fontWeight = FontWeight.ExtraBold)
                                Text("≈ ${money(projectedBrl)}", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                artist.goalStreams?.let { goal ->
                                    val diff = projectedStreams - goal
                                    Text(if (diff >= 0) "Meta superada em ${formatNumber(diff)} streams" else "Faltariam ${formatNumber(-diff)} streams")
                                }
                            }
                        }
                    }
                    Text("Simulação para planejamento; não é garantia de resultado.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .55f))
                }
            },
            confirmButton = { TextButton(onClick = { showSimulator = false }) { Text("Fechar") } }
        )
    }

    if (detailTitle != null && detailBody != null) {
        AlertDialog(
            onDismissRequest = { detailTitle = null; detailBody = null },
            title = { Text(detailTitle ?: "Detalhes", fontWeight = FontWeight.ExtraBold) },
            text = { Text(detailBody ?: "") },
            confirmButton = { TextButton(onClick = { detailTitle = null; detailBody = null }) { Text("Fechar") } }
        )
    }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Ferramentas Premium", fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, modifier = Modifier.weight(1f))
            PremiumFeatureMark(MembershipTier.PRATA)
        }
        Text("Ferramentas do plano Prata+ • incluídas durante o teste de 7 dias", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .5f))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            PremiumAnalysisToolCard(
                modifier = Modifier.weight(1f),
                title = "Simulador de Meta",
                value = "E se...?",
                subtitle = "Teste ritmos diários",
                icon = Icons.Default.Calculate,
                onClick = { showSimulator = true }
            )
            PremiumAnalysisToolCard(
                modifier = Modifier.weight(1f),
                title = "Auditoria do Ciclo",
                value = "$qualityScore/100",
                subtitle = auditSummary,
                icon = Icons.Default.FactCheck,
                onClick = {
                    detailTitle = "Auditoria do Ciclo"
                    detailBody = buildString {
                        append("Qualidade dos dados: $qualityScore/100.\n\n")
                        append("Dias com informação: ${daily.size}.\n")
                        append("Lacunas detectadas: ${health.missingDays}.\n")
                        append("Movimentos muito fora do padrão: ${anomalies.size}.\n\n")
                        append(if (qualityScore >= 80) "A base está adequada para análises e projeções." else "Preencha lacunas e revise registros fora do padrão para melhorar a confiança.")
                    }
                }
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            PremiumAnalysisToolCard(
                modifier = Modifier.weight(1f),
                title = "Detector de Anomalias",
                value = "${anomalies.size}",
                subtitle = if (anomalies.isEmpty()) "Nenhum pico extremo" else "Movimento(s) para revisar",
                icon = Icons.Default.Troubleshoot,
                onClick = {
                    detailTitle = "Detector de Anomalias"
                    detailBody = if (anomalies.isEmpty()) {
                        "Nenhuma variação diária acima de 75% foi encontrada na base disponível."
                    } else {
                        anomalies.take(8).joinToString("\n") { "${formatDate(it.first)} • ${formatSignedPercent(it.second)} • ${formatNumber(it.third)} streams" }
                    }
                }
            )
            PremiumAnalysisToolCard(
                modifier = Modifier.weight(1f),
                title = "Comparador de Artistas",
                value = leader?.first?.name ?: "—",
                subtitle = if (state.artists.size <= 1) "Cadastre outro artista" else "Maior média recente",
                icon = Icons.Default.CompareArrows,
                onClick = {
                    detailTitle = "Comparador de Artistas"
                    detailBody = if (state.artists.size <= 1) {
                        "Cadastre pelo menos dois artistas para comparar a média dos últimos 14 registros disponíveis."
                    } else {
                        artistAverages.joinToString("\n") { (candidate, avg) -> "${candidate.name}: ${formatNumber(avg.roundToLong())} streams/dia" }
                    }
                }
            )
        }
    }
}

@Composable
private fun PremiumAnalysisToolCard(
    modifier: Modifier,
    title: String,
    value: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier.clip(RoundedCornerShape(20.dp)).clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = .88f),
        border = BorderStroke(1.dp, membershipGradient(MembershipTier.PRATA).first().copy(alpha = .38f))
    ) {
        Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, tint = SignalYellow, modifier = Modifier.size(19.dp))
                Spacer(Modifier.width(6.dp))
                PremiumFeatureMark(MembershipTier.PRATA)
            }
            Text(title, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text(value, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, maxLines = 1)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .6f), maxLines = 2)
        }
    }
}

@Composable
private fun AnalysisWindowCard(modifier: Modifier, label: String, trend: TrendResult) {
    val color = movementSignalColor(trend.direction)
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        color = color.copy(alpha = .14f),
        border = BorderStroke(1.dp, color.copy(alpha = .52f))
    ) {
        Column(Modifier.padding(horizontal = 8.dp, vertical = 11.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, fontSize = 10.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(4.dp))
            Text(trend.percentChange?.let(::formatSignedPercent) ?: "—", fontWeight = FontWeight.ExtraBold, fontFamily = FontFamily.Monospace, fontSize = 15.sp, textAlign = TextAlign.Center)
            Text(if (trend.percentChange == null) "base insuficiente" else trend.label, fontSize = 8.sp, textAlign = TextAlign.Center, maxLines = 2)
        }
    }
}

@Composable
private fun AnalysisEvolutionCard(entries: List<DailyStreamEntry>) {
    val maxValue = entries.maxOfOrNull { it.streams }?.coerceAtLeast(1L) ?: 1L
    Card {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Evolução diária", fontWeight = FontWeight.Bold)
            Text("Últimos ${entries.size} registro(s) • escala relativa", style = MaterialTheme.typography.bodySmall)
            Row(
                modifier = Modifier.fillMaxWidth().height(150.dp),
                horizontalArrangement = Arrangement.spacedBy(5.dp),
                verticalAlignment = Alignment.Bottom
            ) {
                entries.forEach { entry ->
                    val ratio = entry.streams.toDouble() / maxValue.toDouble()
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                        Text(formatNumber(entry.streams), fontSize = 7.sp, maxLines = 1)
                        Spacer(Modifier.height(3.dp))
                        Box(
                            Modifier.fillMaxWidth(.76f)
                                .height((14 + 92 * ratio).dp)
                                .background(
                                    Brush.verticalGradient(listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.secondary)),
                                    RoundedCornerShape(topStart = 7.dp, topEnd = 7.dp)
                                )
                        )
                        Spacer(Modifier.height(3.dp))
                        Text(runCatching { LocalDate.parse(entry.dateIso).dayOfMonth.toString() }.getOrDefault(""), fontSize = 8.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun AnalysisStatRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurface.copy(alpha = .72f))
        Text(value, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.End)
    }
}

private data class FinanceArtistSummary(
    val artist: Artist,
    val forecast: ForecastResult,
    val currentEstimate: Double,
    val totalReceived: Double,
    val cycleGrowthPercent: Double?,
    val accuracyPercent: Double?,
    val bestCycleBrl: Double,
    val bestCycleLabel: String,
    val daysRemaining: Long,
    val cycle: CycleWindow,
    val rpm: Double
)

private fun financeArtistSummary(state: AppState, artist: Artist, today: LocalDate = LocalDate.now()): FinanceArtistSummary {
    val cycle = DistributorRules.cycleFor(artist, today)
    val snapshots = state.snapshots.filter { it.artistId == artist.id }
    val payments = state.payments.filter { it.artistId == artist.id }
    val rpm = RoyaltyEngine.personalizedRpm(artist, payments)
    val currentSnapshots = snapshots.filter { it.cycleStartIso == cycle.startIso }
    val currentDaily = state.dailyStreamRecords.filter { it.artistId == artist.id && snapshotDateInCycle(it.dateIso, cycle) }
    val forecast = RoyaltyEngine.forecast(
        currentSnapshots,
        currentDaily,
        LocalDate.parse(cycle.startIso),
        LocalDate.parse(cycle.endIso),
        today,
        rpm
    )
    // Histórico financeiro usa a mesma fonte única do ciclo atual. Assim ciclos que foram
    // preenchidos somente por "Valor do dia" também entram em crescimento e melhor ciclo.
    val allDaily = state.dailyStreamRecords.filter { it.artistId == artist.id }
    val cycleBounds = linkedMapOf<String, String>()
    snapshots.forEach { snap -> cycleBounds[snap.cycleStartIso] = snap.cycleEndIso }
    cycleBounds[cycle.startIso] = cycle.endIso
    allDaily.forEach { record ->
        val date = runCatching { LocalDate.parse(record.dateIso) }.getOrNull() ?: return@forEach
        val alreadyCovered = cycleBounds.any { (startIso, endIso) ->
            val start = runCatching { LocalDate.parse(startIso) }.getOrNull()
            val end = runCatching { LocalDate.parse(endIso) }.getOrNull()
            start != null && end != null && !date.isBefore(start) && !date.isAfter(end)
        }
        if (!alreadyCovered) {
            val derived = DistributorRules.cycleFor(artist, date)
            cycleBounds[derived.startIso] = derived.endIso
        }
    }
    val cycleValues = cycleBounds.entries.sortedBy { it.key }.mapNotNull { (cycleStart, cycleEnd) ->
        val start = runCatching { LocalDate.parse(cycleStart) }.getOrNull() ?: return@mapNotNull null
        val end = runCatching { LocalDate.parse(cycleEnd) }.getOrNull() ?: return@mapNotNull null
        val cycleSnapshots = snapshots.filter { snapshotInCycle(it, CycleWindow(cycleStart, cycleEnd, "")) }
        val cycleDaily = allDaily.filter { snapshotDateInCycle(it.dateIso, CycleWindow(cycleStart, cycleEnd, "")) }
        val reference = minOf(today, end)
        val metrics = StreamMetricsEngine.cycleMetrics(
            cycleSnapshots, cycleDaily, start, end, reference,
            entryMode = resolvedStreamEntryMode(artist),
            cycleId = if (cycleStart == artist.financialCycleStartIso) artist.financialCycleId else null
        )
        cycleStart to RoyaltyEngine.estimateBrl(metrics.currentStreams, rpm)
    }
    val currentIndex = cycleValues.indexOfFirst { it.first == cycle.startIso }
    val previousValue = when {
        currentIndex > 0 -> cycleValues[currentIndex - 1].second
        cycleValues.size >= 2 -> cycleValues[cycleValues.lastIndex - 1].second
        else -> null
    }
    val growth = previousValue?.takeIf { it > 0.0 }?.let { (forecast.estimatedCurrentBrl - it) / it * 100.0 }
    val best = cycleValues.maxByOrNull { it.second }
    val accuracy = RoyaltyEngine.accuracy(payments)
    return FinanceArtistSummary(
        artist = artist,
        forecast = forecast,
        currentEstimate = forecast.estimatedCurrentBrl,
        totalReceived = payments.sumOf { it.amountBrl },
        cycleGrowthPercent = growth,
        accuracyPercent = accuracy.accuracyPercent,
        bestCycleBrl = best?.second ?: 0.0,
        bestCycleLabel = best?.first?.let(::formatDate) ?: "—",
        daysRemaining = ChronoUnit.DAYS.between(today, LocalDate.parse(cycle.endIso)).coerceAtLeast(0),
        cycle = cycle,
        rpm = rpm
    )
}

@Composable
private fun FinanceScreen(
    state: AppState,
    artist: Artist,
    membershipTier: MembershipTier,
    isOwner: Boolean,
    onArtistUpdate: (Artist) -> Unit,
    onPreferencesChange: (UserPreferences) -> Unit,
    onAddHistoricalPayment: (RoyaltyPayment) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val today = LocalDate.now()
    val selected = remember(state, artist.id) { financeArtistSummary(state, artist, today) }
    val allSummaries = remember(state) { state.artists.sortedBy { it.name.lowercase(Locale.getDefault()) }.map { financeArtistSummary(state, it, today) } }
    val totalCurrent = allSummaries.sumOf { it.currentEstimate }
    val totalReceivedAll = state.payments.sumOf { it.amountBrl }
    val selectedPayments = state.payments
        .filter { it.artistId == artist.id }
        .sortedByDescending { it.referenceMonthIso ?: it.paidDateIso.take(7) }
    val latestDirectPayment = selectedPayments.firstOrNull { !it.isRetroactive && it.cycleStreams > 0 }
    val latestPayment = latestDirectPayment ?: selectedPayments.firstOrNull()
    val registeredPaymentMonths = selectedPayments.map { it.referenceMonthIso ?: it.paidDateIso.take(7) }.toSet()
    val nextRetroMonth = remember(selectedPayments, today) {
        var candidate = YearMonth.from(today).minusMonths(1)
        var guard = 0
        while (candidate.toString() in registeredPaymentMonths && guard < 240) {
            candidate = candidate.minusMonths(1)
            guard++
        }
        candidate
    }
    var retroPaymentText by rememberSaveable(artist.id) { mutableStateOf("") }
    var retroPaymentMessage by rememberSaveable(artist.id) { mutableStateOf<String?>(null) }
    val retroPaymentAmount = parseMoneyInput(retroPaymentText)
    val calibrationPaymentCount = RoyaltyEngine.calibrationPaymentCount(selectedPayments)
    val averagePaymentBrl = RoyaltyEngine.averagePaymentBrl(selectedPayments)
    val estimateBeforeLatestPayment = latestDirectPayment?.estimatedBrlBeforeCalibration
    val differenceBrl = if (latestDirectPayment != null && estimateBeforeLatestPayment != null) latestDirectPayment.amountBrl - estimateBeforeLatestPayment else null
    val differencePercent = if (latestDirectPayment != null && estimateBeforeLatestPayment != null && estimateBeforeLatestPayment > 0.0) {
        (latestDirectPayment.amountBrl - estimateBeforeLatestPayment) / estimateBeforeLatestPayment * 100.0
    } else null
    val latestObservedRpm = latestDirectPayment?.effectiveRpmBrlPerThousand
        ?: latestDirectPayment?.takeIf { it.cycleStreams > 0L }?.let { it.amountBrl / it.cycleStreams.toDouble() * 1000.0 }
    val goalProgress = artist.goalBrl?.takeIf { it > 0.0 }?.let { selected.currentEstimate / it * 100.0 }
    val remainingToGoal = artist.goalBrl?.takeIf { it > 0.0 }?.let { (it - selected.currentEstimate).coerceAtLeast(0.0) }
    val dailyNeededBrl = if (remainingToGoal != null && selected.daysRemaining > 0) remainingToGoal / selected.daysRemaining.toDouble() else null
    val projectedGoalPercent = artist.goalBrl?.takeIf { it > 0.0 }?.let { selected.forecast.projectedBrl / it * 100.0 }
    val projection30Streams = (selected.forecast.projectedDailyRate.coerceAtLeast(0.0) * 30.0).roundToLong()
    val projection90Streams = (selected.forecast.projectedDailyRate.coerceAtLeast(0.0) * 90.0).roundToLong()
    val projection30 = RoyaltyEngine.estimateBrl(projection30Streams, selected.rpm)
    val projection90 = RoyaltyEngine.estimateBrl(projection90Streams, selected.rpm)
    val allArtistsMonthlyProjection = allSummaries.sumOf { summary ->
        val monthlyStreams = (summary.forecast.projectedDailyRate.coerceAtLeast(0.0) * 30.0).roundToLong()
        RoyaltyEngine.estimateBrl(monthlyStreams, summary.rpm)
    }

    val portfolioGoal = state.preferences.portfolioAnnualGoalBrl?.takeIf { it > 0.0 }
    val portfolioStart = state.preferences.portfolioAnnualGoalStartIso?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
    val portfolioEnd = portfolioStart?.plusDays(364)
    val portfolioConfirmed = if (portfolioStart != null) {
        state.payments.filter { payment ->
            val date = runCatching { LocalDate.parse(payment.paidDateIso) }.getOrNull()
            date != null && !date.isBefore(portfolioStart) && (portfolioEnd == null || !date.isAfter(portfolioEnd))
        }.sumOf { it.amountBrl }
    } else 0.0
    val portfolioEstimatedUnpaid = if (portfolioStart != null) {
        state.artists.sumOf { candidate ->
            val summary = allSummaries.firstOrNull { it.artist.id == candidate.id }
            val candidateRpm = summary?.rpm ?: RoyaltyEngine.personalizedRpm(candidate, state.payments.filter { it.artistId == candidate.id })
            val latestCandidatePaymentDate = state.payments.filter { it.artistId == candidate.id }
                .maxByOrNull { it.paidDateIso }?.paidDateIso?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
            val fromDate = listOfNotNull(portfolioStart, latestCandidatePaymentDate).maxOrNull() ?: portfolioStart
            val streams = unifiedAnalyticsEntries(state, candidate, today).filter { entry ->
                val date = runCatching { LocalDate.parse(entry.dateIso) }.getOrNull()
                date != null && date.isAfter(fromDate) && !date.isAfter(today)
            }.sumOf { it.streams }
            RoyaltyEngine.estimateBrl(streams, candidateRpm)
        }
    } else 0.0
    val portfolioEstimatedTotal = portfolioConfirmed + portfolioEstimatedUnpaid
    val portfolioDaysRemaining = portfolioEnd?.let { ChronoUnit.DAYS.between(today, it).coerceAtLeast(0L) } ?: 0L

    val annualGoalStart = artist.annualGoalStartIso?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
    val annualGoalEnd = annualGoalStart?.plusDays(364)
    val annualGoal = artist.annualGoalBrl?.takeIf { it > 0.0 }
    val confirmedAnnual = if (annualGoalStart != null) {
        selectedPayments.filter { payment ->
            val date = runCatching { LocalDate.parse(payment.paidDateIso) }.getOrNull()
            date != null && !date.isBefore(annualGoalStart) && (annualGoalEnd == null || !date.isAfter(annualGoalEnd))
        }.sumOf { it.amountBrl }
    } else 0.0
    val lastPaymentDate = latestPayment?.paidDateIso?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
    val estimateFromDate = listOfNotNull(annualGoalStart, lastPaymentDate).maxOrNull()
    val unpaidDailyStreams = if (estimateFromDate != null) {
        unifiedAnalyticsEntries(state, artist, today).filter { entry ->
            val date = runCatching { LocalDate.parse(entry.dateIso) }.getOrNull()
            date != null && date.isAfter(estimateFromDate) && !date.isAfter(today)
        }.sumOf { it.streams }
    } else 0L
    val estimatedUnpaidAnnual = RoyaltyEngine.estimateBrl(unpaidDailyStreams, selected.rpm)
    val annualEstimatedTotal = confirmedAnnual + estimatedUnpaidAnnual
    val annualDaysElapsed = annualGoalStart?.let { ChronoUnit.DAYS.between(it, today).coerceAtLeast(0L) + 1L } ?: 0L
    val annualDaysRemaining = annualGoalEnd?.let { ChronoUnit.DAYS.between(today, it).coerceAtLeast(0L) } ?: 0L
    val annualPacePerDay = if (annualDaysElapsed > 0) annualEstimatedTotal / annualDaysElapsed.toDouble() else 0.0
    val annualRemainingValue = annualGoal?.let { (it - annualEstimatedTotal).coerceAtLeast(0.0) } ?: 0.0
    val annualNeededPerDay = if (annualGoal != null && annualDaysRemaining > 0) annualRemainingValue / annualDaysRemaining.toDouble() else null
    val predictedDaysToGoal = if (annualGoal != null && annualPacePerDay > 0.0) kotlin.math.ceil(annualRemainingValue / annualPacePerDay).toLong() else null


    var showPortfolioGoalDialog by remember { mutableStateOf(false) }
    var portfolioGoalInput by rememberSaveable(state.preferences.portfolioAnnualGoalBrl) {
        mutableStateOf(state.preferences.portfolioAnnualGoalBrl?.let { String.format(Locale("pt", "BR"), "%.2f", it) } ?: "")
    }

    if (showPortfolioGoalDialog) {
        val parsed = parseMoneyInput(portfolioGoalInput)
        AlertDialog(
            onDismissRequest = { showPortfolioGoalDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PremiumFeatureMark(MembershipTier.PRATA)
                    Text("Meta geral da carteira", fontWeight = FontWeight.ExtraBold)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Defina uma meta anual somando todos os artistas cadastrados. Ela não substitui as metas individuais.")
                    OutlinedTextField(
                        value = portfolioGoalInput,
                        onValueChange = { portfolioGoalInput = it.take(18) },
                        label = { Text("Meta consolidada em R$") },
                        placeholder = { Text("Ex.: 50.000,00") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val value = parsed
                        if (value != null && value > 0.0) {
                            val oldStart = state.preferences.portfolioAnnualGoalStartIso?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
                            val newStart = if (oldStart == null || today.isAfter(oldStart.plusDays(364))) today else oldStart
                            onPreferencesChange(
                                state.preferences.copy(
                                    portfolioAnnualGoalBrl = value,
                                    portfolioAnnualGoalStartIso = newStart.toString()
                                )
                            )
                            showPortfolioGoalDialog = false
                        }
                    },
                    enabled = parsed != null && parsed > 0.0
                ) { Text("Salvar") }
            },
            dismissButton = { TextButton(onClick = { showPortfolioGoalDialog = false }) { Text("Cancelar") } }
        )
    }

    var showAnnualGoalDialog by remember { mutableStateOf(false) }
    var annualGoalInput by rememberSaveable(artist.id, artist.annualGoalBrl) { mutableStateOf(artist.annualGoalBrl?.let { String.format(Locale("pt", "BR"), "%.2f", it) } ?: "") }

    if (showAnnualGoalDialog) {
        val parsed = parseMoneyInput(annualGoalInput)
        AlertDialog(
            onDismissRequest = { showAnnualGoalDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PremiumFeatureMark(MembershipTier.PRATA)
                    Text("Meta anual de ganhos", fontWeight = FontWeight.ExtraBold)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Defina quanto deseja acumular nos próximos 12 meses. Pagamentos reais ficam separados das estimativas diárias.")
                    OutlinedTextField(
                        value = annualGoalInput,
                        onValueChange = { annualGoalInput = it.take(18) },
                        label = { Text("Meta em R$") },
                        placeholder = { Text("Ex.: 10.000,00") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text("O período começa no dia em que a meta é salva e dura 365 dias.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .58f))
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val value = parsed
                        if (value != null && value > 0.0) {
                            val oldStart = artist.annualGoalStartIso?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
                            val newStart = if (oldStart == null || today.isAfter(oldStart.plusDays(364))) today else oldStart
                            onArtistUpdate(artist.copy(annualGoalBrl = value, annualGoalStartIso = newStart.toString()))
                            showAnnualGoalDialog = false
                        }
                    },
                    enabled = parsed != null && parsed > 0.0
                ) { Text("Salvar") }
            },
            dismissButton = { TextButton(onClick = { showAnnualGoalDialog = false }) { Text("Cancelar") } }
        )
    }

    var pendingReport by remember { mutableStateOf<ReportPeriod?>(null) }
    var reportMessage by remember { mutableStateOf<String?>(null) }
    val reportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val period = pendingReport
        if (uri != null && period != null) {
            scope.launch {
                reportMessage = "Gerando PDF..."
                val result = withContext(Dispatchers.IO) { ReportPdfManager.writeReport(context, uri, state, artist, period) }
                reportMessage = if (result.isSuccess) "PDF salvo com sucesso" else "Não foi possível gerar o PDF"
                delay(1500)
                reportMessage = null
            }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 18.dp, bottom = 34.dp)
    ) {
        item { FinanceReconciliationInsights(state, artist) }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                ArtistAvatar(photoPath = artist.photoPath, avatarId = artist.avatarId, size = 52.dp, fallbackToLogo = true)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("Financeiro", fontSize = 27.sp, fontWeight = FontWeight.Bold)
                    Text("${artist.name} • visão financeira", color = MaterialTheme.colorScheme.onSurface.copy(alpha = .68f))
                }
            }
        }

        item {
            FinanceHeroCard(
                current = selected.currentEstimate,
                totalAll = totalCurrent,
                totalReceived = selected.totalReceived,
                projected = selected.forecast.projectedBrl,
                goal = artist.goalBrl,
                progressPercent = goalProgress,
                daysRemaining = selected.daysRemaining
            )
        }

        item {
            Card(
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = .24f))
            ) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.History, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Calibração por pagamentos anteriores", fontWeight = FontWeight.ExtraBold)
                            Text("Histórico usado para calibrar as estimativas.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .58f))
                        }
                    }

                    if (artist.globalReferenceSampleCount > 0 && artist.globalReferenceRpmBrl != null) {
                        Text(
                            "Referência global anônima: ${money(artist.globalReferenceRpmBrl)} / 1.000 • ${artist.globalReferenceSampleCount} ciclo(s) agregado(s)" +
                                (artist.globalReferenceMedianRpmBrl?.let { " • mediana ${money(it)}" } ?: "") +
                                (artist.globalReferenceAccuracyPercent?.let { " • precisão ${"%.0f".format(Locale.US, it)}%" } ?: ""),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = .62f)
                        )
                    } else {
                        Text(
                            "Referência global inicial: base histórica agregada do SONUS; nenhum pagamento individual de outro usuário é exibido.",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = .58f)
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        FinanceComparisonBox(
                            Modifier.weight(1f),
                            "Base",
                            "$calibrationPaymentCount pagamento${if (calibrationPaymentCount == 1) "" else "s"}",
                            SignalBlue
                        )
                        FinanceComparisonBox(
                            Modifier.weight(1f),
                            "Média",
                            averagePaymentBrl?.let(::money) ?: "—",
                            SignalGreen
                        )
                        FinanceComparisonBox(
                            Modifier.weight(1f),
                            "Confiança",
                            RoyaltyEngine.confidenceLabel(selectedPayments),
                            SignalPurple
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = .25f)
                    ) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text("Próximo mês retroativo", style = MaterialTheme.typography.labelSmall)
                            Text(formatYearMonth(nextRetroMonth), fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                            Text(
                                if (calibrationPaymentCount >= 5)
                                    "Base histórica forte: novos pagamentos continuam refinando a média."
                                else
                                    "Adicione pelo menos 5 pagamentos para formar uma média histórica mais confiável.",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = .58f)
                            )
                        }
                    }

                    OutlinedTextField(
                        value = retroPaymentText,
                        onValueChange = { retroPaymentText = it; retroPaymentMessage = null },
                        label = { Text("Saldo recebido em ${formatYearMonth(nextRetroMonth)}") },
                        placeholder = { Text("329,50") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = {
                            val value = retroPaymentAmount
                            if (value != null && value > 0.0) {
                                onAddHistoricalPayment(
                                    RoyaltyPayment(
                                        id = UUID.randomUUID().toString(),
                                        artistId = artist.id,
                                        paidDateIso = nextRetroMonth.atEndOfMonth().toString(),
                                        amountBrl = value,
                                        cycleStreams = 0L,
                                        referenceMonthIso = nextRetroMonth.toString(),
                                        isRetroactive = true,
                                        recordedAtEpochMillis = System.currentTimeMillis()
                                    )
                                )
                                retroPaymentMessage = "${formatYearMonth(nextRetroMonth)} adicionado ao histórico financeiro."
                                retroPaymentText = ""
                            }
                        },
                        enabled = retroPaymentAmount != null && retroPaymentAmount > 0.0,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Add, null)
                        Spacer(Modifier.width(6.dp))
                        Text("Adicionar pagamento anterior")
                    }
                    retroPaymentMessage?.let {
                        Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                    }
                    Text(
                        "Pagamentos retroativos são acrescentados ao Histórico; nenhum registro antigo é substituído. Quando houver streams reais do mesmo ciclo, essa calibração recebe prioridade no motor.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = .52f)
                    )
                    Text(
                        "Use o pagamento principal de cada ciclo. Não inclua saques, transferências avulsas ou pequenos ajustes separados do royalty mensal.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.tertiary
                    )
                }
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OrbMetricCard(
                    modifier = Modifier.weight(1f),
                    title = "Total recebido",
                    value = money(selected.totalReceived),
                    subtitle = "pagamentos reais",
                    signalColor = SignalGreen,
                    icon = Icons.Default.Payments,
                    animatedNumber = selected.totalReceived,
                    numberFormatter = { money(it) }
                )
                OrbMetricCard(
                    modifier = Modifier.weight(1f),
                    title = "Crescimento financeiro",
                    value = selected.cycleGrowthPercent?.let(::formatSignedPercent) ?: "Formando base",
                    subtitle = "ciclo atual × anterior",
                    signalColor = movementSignalColor(when { (selected.cycleGrowthPercent ?: 0.0) >= 5 -> 1; (selected.cycleGrowthPercent ?: 0.0) <= -5 -> -1; else -> 0 }),
                    icon = Icons.Default.TrendingUp,
                    animatedNumber = selected.cycleGrowthPercent ?: 0.0,
                    numberFormatter = { if (selected.cycleGrowthPercent == null) "Formando base" else formatSignedPercent(it) }
                )
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OrbMetricCard(
                    modifier = Modifier.weight(1f),
                    title = "Precisão histórica",
                    value = selected.accuracyPercent?.let { "${it.roundToInt()}%" } ?: "Inicial",
                    subtitle = if (selected.accuracyPercent == null) "aguardando pagamentos" else "estimado × recebido",
                    signalColor = selected.accuracyPercent?.let(::goalProgressColor) ?: SignalPurple,
                    icon = Icons.Default.Verified,
                    animatedNumber = selected.accuracyPercent ?: 0.0,
                    numberFormatter = { if (selected.accuracyPercent == null) "Inicial" else "${it.roundToInt()}%" }
                )
                OrbMetricCard(
                    modifier = Modifier.weight(1f),
                    title = "Melhor ciclo",
                    value = money(selected.bestCycleBrl),
                    subtitle = selected.bestCycleLabel,
                    signalColor = SignalBlue,
                    icon = Icons.Default.EmojiEvents,
                    animatedNumber = selected.bestCycleBrl,
                    numberFormatter = { money(it) }
                )
            }
        }

        item {
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Desempenho por artista", fontWeight = FontWeight.Bold)
                    Text("Participação na estimativa total atual", style = MaterialTheme.typography.bodySmall)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(allSummaries, key = { it.artist.id }) { summary ->
                            val share = if (totalCurrent > 0.0) summary.currentEstimate / totalCurrent * 100.0 else 0.0
                            FinanceArtistOrb(summary, share)
                        }
                    }
                    Text("Total estimado em todos os artistas: ${money(totalCurrent)}", fontWeight = FontWeight.SemiBold)
                    Text("Total já recebido em todos os artistas: ${money(totalReceivedAll)}", style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        if (artist.goalBrl != null && artist.goalBrl > 0.0) {
            item {
                FinanceGoalDetailCard(
                    goal = artist.goalBrl,
                    current = selected.currentEstimate,
                    progress = goalProgress ?: 0.0,
                    remaining = remainingToGoal ?: 0.0,
                    dailyNeeded = dailyNeededBrl,
                    projectedPercent = projectedGoalPercent
                )
            }
        }

        item {
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Estimado × recebido", fontWeight = FontWeight.Bold)
                    if (latestDirectPayment != null) {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            FinanceComparisonBox(Modifier.weight(1f), "Estimado", estimateBeforeLatestPayment?.let(::money) ?: "—", SignalBlue)
                            FinanceComparisonBox(Modifier.weight(1f), "Recebido", money(latestDirectPayment.amountBrl), SignalGreen)
                            FinanceComparisonBox(Modifier.weight(1f), "Diferença", differencePercent?.let(::formatSignedPercent) ?: "—", differencePercent?.let { movementSignalColor(if (it >= 0) 1 else -1) } ?: SignalPurple)
                        }
                        Text("Diferença: ${differenceBrl?.let(::signedMoney) ?: "—"}${differencePercent?.let { " (${formatSignedPercent(it)})" }.orEmpty()}", style = MaterialTheme.typography.bodySmall)
                        latestObservedRpm?.let { Text("Rendimento observado neste ciclo: ${money(it)} / 1.000 streams", style = MaterialTheme.typography.bodySmall) }
                        Text("Pagamento esperado: ${latestDirectPayment.expectedPayoutDateIso?.let(::formatDate) ?: "—"} • real: ${formatDate(latestDirectPayment.paidDateIso)}", style = MaterialTheme.typography.bodySmall)
                        latestDirectPayment.lastCountedDataDateIso?.let { Text("Dados consumidos até: ${formatDate(it)}", style = MaterialTheme.typography.labelSmall) }
                    } else if (selectedPayments.isNotEmpty()) {
                        Text("Os pagamentos anteriores já estão refinando a média. O comparativo estimado × recebido aparece após registrar um ciclo completo com streams.")
                    } else {
                        Text("Cadastre um pagamento real em ‘Recebi’ para comparar a previsão com o valor que chegou.")
                    }
                }
            }
        }

        item {
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Pagamentos reais", fontWeight = FontWeight.Bold)
                    if (selectedPayments.isEmpty()) Text("Nenhum pagamento cadastrado ainda.")
                    selectedPayments.take(12).forEach { payment ->
                        Row {
                            Text(
                                payment.referenceMonthIso?.let { runCatching { formatYearMonth(YearMonth.parse(it)) }.getOrDefault(it) }
                                    ?: formatDate(payment.paidDateIso),
                                Modifier.weight(1f)
                            )
                            Column(horizontalAlignment = Alignment.End) {
                                Text(money(payment.amountBrl), fontWeight = FontWeight.Bold)
                                if (payment.isRetroactive) Text("retroativo", style = MaterialTheme.typography.labelSmall)
                                else {
                                    payment.effectiveRpmBrlPerThousand?.let { Text("${money(it)} / 1.000", style = MaterialTheme.typography.labelSmall) }
                                    payment.expectedPayoutDateIso?.let { Text("esp. ${formatCompactDate(it)} • real ${formatCompactDate(payment.paidDateIso)}", style = MaterialTheme.typography.labelSmall) }
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            val byDistributor = allSummaries.groupBy { DistributorRules.displayName(it.artist.distributor, it.artist.customDistributorName) }
                .mapValues { (_, values) -> values.sumOf { it.currentEstimate } }
                .toList().sortedByDescending { it.second }
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text("Participação por distribuidora", fontWeight = FontWeight.Bold)
                    if (byDistributor.isEmpty()) Text("Ainda sem dados")
                    byDistributor.forEach { (name, value) ->
                        val share = if (totalCurrent > 0.0) value / totalCurrent else 0.0
                        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Row {
                                Text(name, Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                                Text("${(share * 100).roundToInt()}% • ${money(value)}")
                            }
                            LinearProgressIndicator(progress = { share.toFloat().coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                        }
                    }
                }
            }
        }

        item {
            Text("Projeções financeiras", fontWeight = FontWeight.ExtraBold, fontSize = 19.sp)
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OrbMetricCard(
                    modifier = Modifier.weight(1f),
                    title = "Projeção 30 dias",
                    value = money(projection30),
                    subtitle = "mantendo o ritmo",
                    signalColor = SignalBlue,
                    icon = Icons.Default.CalendarMonth,
                    animatedNumber = projection30,
                    numberFormatter = { money(it) }
                )
                OrbMetricCard(
                    modifier = Modifier.weight(1f),
                    title = "Projeção 90 dias",
                    value = money(projection90),
                    subtitle = "estimativa",
                    signalColor = SignalGreen,
                    icon = Icons.Default.AutoGraph,
                    animatedNumber = projection90,
                    numberFormatter = { money(it) }
                )
            }
        }

        item {
            PremiumProjectionSection(
                selectedArtistName = artist.name,
                monthlySelected = projection30,
                monthlyAll = allArtistsMonthlyProjection,
                goldAllowed = isOwner || commercialTier(membershipTier).ordinal >= MembershipTier.OURO.ordinal
            )
        }

        item {
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Próximos fechamentos", fontWeight = FontWeight.Bold)
                    allSummaries.sortedBy { it.daysRemaining }.forEach { summary ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            ArtistAvatar(summary.artist.photoPath, 34.dp, avatarId = summary.artist.avatarId)
                            Spacer(Modifier.width(9.dp))
                            Column(Modifier.weight(1f)) {
                                Text(summary.artist.name, fontWeight = FontWeight.SemiBold)
                                Text(formatDate(summary.cycle.endIso), style = MaterialTheme.typography.bodySmall)
                            }
                            Text("${summary.daysRemaining} dia(s)", color = closingSignalColor(summary.daysRemaining), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        item {
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Relatórios", fontWeight = FontWeight.Bold)
                    Text("Gere um extrato em PDF do artista selecionado.", style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        listOf(ReportPeriod.CYCLE, ReportPeriod.DAYS_30, ReportPeriod.DAYS_90).forEach { period ->
                            OutlinedButton(
                                onClick = {
                                    pendingReport = period
                                    reportLauncher.launch(ReportPdfManager.suggestedName(artist, period))
                                },
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(horizontal = 5.dp)
                            ) {
                                Text(
                                    when (period) {
                                        ReportPeriod.CYCLE -> "Ciclo"
                                        ReportPeriod.DAYS_30 -> "30 dias"
                                        ReportPeriod.DAYS_90 -> "90 dias"
                                        ReportPeriod.YEAR_1 -> "1 ano"
                                    },
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                    OutlinedButton(
                        onClick = {
                            pendingReport = ReportPeriod.YEAR_1
                            reportLauncher.launch(ReportPdfManager.suggestedName(artist, ReportPeriod.YEAR_1))
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        PremiumFeatureMark(MembershipTier.PRATA)
                        Spacer(Modifier.width(8.dp))
                        Text("Relatório PDF de 1 ano")
                    }
                    reportMessage?.let { Text(it, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall) }
                }
            }
        }

        item {
            AnnualGoalPremiumCard(
                goal = annualGoal,
                confirmed = confirmedAnnual,
                estimatedUnpaid = estimatedUnpaidAnnual,
                estimatedTotal = annualEstimatedTotal,
                daysRemaining = annualDaysRemaining,
                neededPerDay = annualNeededPerDay,
                currentPacePerDay = annualPacePerDay,
                predictedDaysToGoal = predictedDaysToGoal,
                onEdit = { showAnnualGoalDialog = true }
            )
        }

        item {
            PortfolioGoalPremiumCard(
                goal = portfolioGoal,
                confirmed = portfolioConfirmed,
                estimatedUnpaid = portfolioEstimatedUnpaid,
                estimatedTotal = portfolioEstimatedTotal,
                daysRemaining = portfolioDaysRemaining,
                artistCount = state.artists.size,
                onEdit = { showPortfolioGoalDialog = true }
            )
        }
    }
}

@Composable
private fun AnnualGoalPremiumCard(
    goal: Double?,
    confirmed: Double,
    estimatedUnpaid: Double,
    estimatedTotal: Double,
    daysRemaining: Long,
    neededPerDay: Double?,
    currentPacePerDay: Double,
    predictedDaysToGoal: Long?,
    onEdit: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    val progress = goal?.takeIf { it > 0.0 }?.let { (estimatedTotal / it).coerceIn(0.0, 1.0) } ?: 0.0
    val color = when {
        goal == null -> SignalBlue
        progress >= 1.0 -> SignalGreen
        neededPerDay != null && currentPacePerDay >= neededPerDay -> SignalGreen
        progress >= .45 -> SignalPurple
        else -> SignalOrange
    }
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        color = color.copy(alpha = .10f),
        border = BorderStroke(1.dp, color.copy(alpha = .35f))
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Savings, null, tint = color)
                Spacer(Modifier.width(8.dp))
                Text("Meta anual de ganhos", fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                PremiumFeatureMark(MembershipTier.PRATA)
            }
            if (goal == null) {
                Text("Defina quanto deseja acumular em 12 meses e acompanhe confirmado + estimado.")
                FilledTonalButton(onClick = onEdit) { Text("Criar meta anual") }
            } else {
                Row(verticalAlignment = Alignment.Bottom) {
                    Column(Modifier.weight(1f)) {
                        Text("Meta ${money(goal)}", fontWeight = FontWeight.ExtraBold, fontSize = 19.sp)
                        Text("Confirmado ${money(confirmed)} • Acompanhado ${money(estimatedTotal)}", style = MaterialTheme.typography.bodySmall)
                    }
                    Text("${(progress * 100).roundToInt()}%", color = color, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                }
                LinearProgressIndicator(
                    progress = { progress.toFloat() },
                    modifier = Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(50)),
                    color = color,
                    trackColor = color.copy(alpha = .13f)
                )
                Text("$daysRemaining dias restantes", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                Row {
                    TextButton(onClick = { expanded = !expanded }, contentPadding = PaddingValues(horizontal = 0.dp)) {
                        Text(if (expanded) "Ocultar detalhes" else "Ver detalhes")
                    }
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = onEdit) { Text("Editar") }
                }
                AnimatedVisibility(expanded) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            AnnualGoalMiniBox(Modifier.weight(1f), "Estimado diário", money(estimatedUnpaid), "ainda não recebido")
                            AnnualGoalMiniBox(Modifier.weight(1f), "Necessário/dia", neededPerDay?.let(::money) ?: "—", "para atingir a meta")
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            AnnualGoalMiniBox(Modifier.weight(1f), "Ritmo atual", money(currentPacePerDay), "média/dia")
                            AnnualGoalMiniBox(Modifier.weight(1f), "Previsão", predictedDaysToGoal?.let { "$it dias" } ?: "—", "para atingir")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PortfolioGoalPremiumCard(
    goal: Double?,
    confirmed: Double,
    estimatedUnpaid: Double,
    estimatedTotal: Double,
    daysRemaining: Long,
    artistCount: Int,
    onEdit: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    val progress = goal?.takeIf { it > 0.0 }?.let { (estimatedTotal / it).coerceIn(0.0, 1.0) } ?: 0.0
    val accent = membershipGradient(MembershipTier.PRATA).first()
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        color = accent.copy(alpha = .08f),
        border = BorderStroke(1.dp, accent.copy(alpha = .30f))
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Groups, null, tint = accent)
                Spacer(Modifier.width(8.dp))
                Text("Meta geral da carteira", fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                PremiumFeatureMark(MembershipTier.PRATA)
            }
            if (goal == null) {
                Text("Crie uma meta anual somando os $artistCount artista(s), sem substituir metas individuais.")
                FilledTonalButton(onClick = onEdit) { Text("Criar meta consolidada") }
            } else {
                Row(verticalAlignment = Alignment.Bottom) {
                    Column(Modifier.weight(1f)) {
                        Text("Meta ${money(goal)}", fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
                        Text("Recebido ${money(confirmed)} • Acompanhado ${money(estimatedTotal)}", style = MaterialTheme.typography.bodySmall)
                    }
                    Text("${(progress * 100).roundToInt()}%", color = accent, fontWeight = FontWeight.ExtraBold)
                }
                LinearProgressIndicator(
                    progress = { progress.toFloat() },
                    modifier = Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(50)),
                    color = accent,
                    trackColor = accent.copy(alpha = .13f)
                )
                Text("$daysRemaining dias restantes", style = MaterialTheme.typography.bodySmall)
                Row {
                    TextButton(onClick = { expanded = !expanded }, contentPadding = PaddingValues(horizontal = 0.dp)) {
                        Text(if (expanded) "Ocultar detalhes" else "Ver detalhes")
                    }
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = onEdit) { Text("Editar") }
                }
                AnimatedVisibility(expanded) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AnnualGoalMiniBox(Modifier.weight(1f), "Recebido", money(confirmed), "todas as contas")
                        AnnualGoalMiniBox(Modifier.weight(1f), "Estimado", money(estimatedUnpaid), "ainda não recebido")
                    }
                }
            }
        }
    }
}

@Composable
private fun AnnualGoalMiniBox(modifier: Modifier, title: String, value: String, subtitle: String) {
    Surface(modifier = modifier, shape = RoundedCornerShape(15.dp), color = MaterialTheme.colorScheme.surface.copy(alpha = .55f)) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .6f))
            Text(value, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, maxLines = 1)
            Text(subtitle, fontSize = 8.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .48f), maxLines = 2)
        }
    }
}

@Composable
private fun PremiumProjectionSection(
    selectedArtistName: String,
    monthlySelected: Double,
    monthlyAll: Double,
    goldAllowed: Boolean
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        PremiumProjectionGroup(
            tier = MembershipTier.PRATA,
            title = "Projeções de médio prazo",
            subtitle = "$selectedArtistName e todos os artistas cadastrados",
            horizons = listOf("6 meses" to 6, "1 ano" to 12),
            monthlySelected = monthlySelected,
            monthlyAll = monthlyAll
        )
        if (goldAllowed) {
            PremiumProjectionGroup(
                tier = MembershipTier.OURO,
                title = "Projeções de longo prazo",
                subtitle = "Planejamento com margem de incerteza crescente",
                horizons = listOf("2 anos" to 24, "5 anos" to 60, "10 anos" to 120),
                monthlySelected = monthlySelected,
                monthlyAll = monthlyAll
            )
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = MaterialTheme.colorScheme.surface.copy(alpha = .86f),
                border = BorderStroke(1.dp, membershipGradient(MembershipTier.OURO).first().copy(alpha = .35f))
            ) {
                Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AccountBalance, null, tint = MaterialTheme.colorScheme.secondary)
                        Spacer(Modifier.width(8.dp))
                        Text("Planejamento Financeiro", fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                        PremiumFeatureMark(MembershipTier.OURO)
                    }
                    Text("Ritmo mensal provável: ${money(monthlySelected)} no artista • ${money(monthlyAll)} em todas as contas.")
                    Text("Use as projeções acima como cenários de planejamento, não como promessa de rendimento.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .56f))
                }
            }
        } else {
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .58f),
                border = BorderStroke(1.dp, membershipGradient(MembershipTier.OURO).first().copy(alpha = .30f))
            ) {
                Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Lock, null, tint = membershipGradient(MembershipTier.OURO).first())
                    Spacer(Modifier.width(9.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Projeções de 2, 5 e 10 anos", fontWeight = FontWeight.ExtraBold)
                        Text("Planejamento financeiro avançado disponível no plano Ouro ou superior.", style = MaterialTheme.typography.bodySmall)
                    }
                    PremiumFeatureMark(MembershipTier.OURO)
                }
            }
        }
    }
}

@Composable
private fun PremiumProjectionGroup(
    tier: MembershipTier,
    title: String,
    subtitle: String,
    horizons: List<Pair<String, Int>>,
    monthlySelected: Double,
    monthlyAll: Double
) {
    val accent = membershipGradient(tier).first()
    Surface(
        shape = RoundedCornerShape(24.dp),
        color = accent.copy(alpha = .08f),
        border = BorderStroke(1.dp, accent.copy(alpha = .32f))
    ) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Timeline, null, tint = accent)
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text(title, fontWeight = FontWeight.ExtraBold)
                    Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .58f))
                }
                PremiumFeatureMark(tier)
            }
            horizons.forEach { (label, months) ->
                ProjectionHorizonRow(
                    label = label,
                    months = months,
                    monthlySelected = monthlySelected,
                    monthlyAll = monthlyAll,
                    accent = accent
                )
            }
            Text("Cenários: conservador 80% • provável 100% • otimista 120%", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .48f))
        }
    }
}

@Composable
private fun ProjectionHorizonRow(
    label: String,
    months: Int,
    monthlySelected: Double,
    monthlyAll: Double,
    accent: Color
) {
    val selectedLikely = monthlySelected * months
    val allLikely = monthlyAll * months
    val low = selectedLikely * .8
    val high = selectedLikely * 1.2
    val confidence = when {
        months <= 6 -> "Média"
        months <= 12 -> "Média-baixa"
        months <= 24 -> "Baixa"
        else -> "Muito baixa"
    }
    Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surface.copy(alpha = .58f)) {
        Column(Modifier.padding(11.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row {
                Text(label, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                Text(money(selectedLikely), color = accent, fontWeight = FontWeight.ExtraBold)
            }
            Text("Artista: ${money(low)} — ${money(selectedLikely)} — ${money(high)}", style = MaterialTheme.typography.bodySmall)
            Text("Todas as contas: provável ${money(allLikely)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .62f))
            Text("Confiança: $confidence", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .46f))
        }
    }
}

@Composable
private fun FinanceHeroCard(
    current: Double,
    totalAll: Double,
    totalReceived: Double,
    projected: Double,
    goal: Double?,
    progressPercent: Double?,
    daysRemaining: Long
) {
    val progress = progressPercent?.coerceIn(0.0, 100.0) ?: 0.0
    val statusColor = goalProgressColor(progress)
    // Gradiente estático: mantém profundidade visual sem gastar frames continuamente.
    val start = lerp(statusColor, Color.White, .08f)
    val end = lerp(statusColor, Color(0xFF111421), .60f)
    Card(colors = CardDefaults.cardColors(containerColor = Color.Transparent), shape = RoundedCornerShape(26.dp)) {
        Column(
            Modifier.background(Brush.linearGradient(listOf(start, end)), RoundedCornerShape(26.dp)).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Resumo financeiro", color = Color.White.copy(alpha = .9f), fontWeight = FontWeight.SemiBold)
            Text(money(current), style = digitalValueStyle(Color.White, 31.sp))
            Text("estimado neste ciclo", color = Color.White.copy(alpha = .78f), style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FinanceHeroMini(Modifier.weight(1f), "Recebido", money(totalReceived))
                FinanceHeroMini(Modifier.weight(1f), "Fechamento", money(projected))
                FinanceHeroMini(Modifier.weight(1f), "Todos", money(totalAll))
            }
            if (goal != null && goal > 0.0) {
                Row { Text("Meta: ${money(goal)}", color = Color.White, modifier = Modifier.weight(1f)); Text("${progress.roundToInt()}%", color = Color.White, fontWeight = FontWeight.Bold) }
                LinearProgressIndicator(progress = { (progress / 100.0).toFloat() }, modifier = Modifier.fillMaxWidth(), color = Color.White, trackColor = Color.Black.copy(alpha = .22f))
            }
            Text("$daysRemaining dia(s) até o fechamento de referência", color = Color.White.copy(alpha = .82f), style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun FinanceHeroMini(modifier: Modifier, label: String, value: String) {
    Surface(modifier = modifier, color = Color.Black.copy(alpha = .16f), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(horizontal = 8.dp, vertical = 7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, color = Color.White.copy(alpha = .72f), fontSize = 9.sp)
            Text(value, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
        }
    }
}

@Composable
private fun FinanceGoalDetailCard(
    goal: Double,
    current: Double,
    progress: Double,
    remaining: Double,
    dailyNeeded: Double?,
    projectedPercent: Double?
) {
    val color = goalProgressColor(progress.coerceIn(0.0, 100.0))
    Card {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Flag, null, tint = color)
                Spacer(Modifier.width(8.dp))
                Text("Análise da meta", fontWeight = FontWeight.Bold)
            }
            Row {
                Text("Meta", Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurface.copy(alpha = .7f))
                Text(money(goal), fontWeight = FontWeight.SemiBold)
            }
            Row {
                Text("Atingido", Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurface.copy(alpha = .7f))
                Text("${progress.coerceAtLeast(0.0).roundToInt()}% • ${money(current)}", fontWeight = FontWeight.SemiBold)
            }
            Row {
                Text("Falta", Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurface.copy(alpha = .7f))
                Text(money(remaining), fontWeight = FontWeight.SemiBold)
            }
            dailyNeeded?.let {
                Row {
                    Text("Ritmo financeiro necessário", Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurface.copy(alpha = .7f))
                    Text("${money(it)}/dia", fontWeight = FontWeight.SemiBold)
                }
            }
            projectedPercent?.let {
                Row {
                    Text("Previsão da meta", Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurface.copy(alpha = .7f))
                    Text("${it.coerceAtLeast(0.0).roundToInt()}% no fechamento", fontWeight = FontWeight.SemiBold)
                }
            }
            LinearProgressIndicator(progress = { (progress / 100.0).toFloat().coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth(), color = color)
        }
    }
}

@Composable
private fun FinanceComparisonBox(modifier: Modifier, label: String, value: String, color: Color) {
    Surface(modifier = modifier, shape = RoundedCornerShape(18.dp), color = color.copy(alpha = .16f), border = BorderStroke(1.dp, color.copy(alpha = .65f))) {
        Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, style = MaterialTheme.typography.labelSmall)
            Text(value, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, maxLines = 2)
        }
    }
}

@Composable
private fun FinanceArtistOrb(summary: FinanceArtistSummary, sharePercent: Double) {
    Surface(
        modifier = Modifier.size(126.dp),
        shape = CircleShape,
        color = goalProgressColor(sharePercent.coerceIn(0.0, 100.0)).copy(alpha = .22f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = .45f))
    ) {
        Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            ArtistAvatar(summary.artist.photoPath, 38.dp, avatarId = summary.artist.avatarId)
            Spacer(Modifier.height(5.dp))
            Text(summary.artist.name, fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, maxLines = 1)
            Text(money(summary.currentEstimate), fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
            Text("${sharePercent.roundToInt()}% do total", fontSize = 9.sp, textAlign = TextAlign.Center)
        }
    }
}


@Composable
private fun PremiumSettingsBanner(membershipTier: MembershipTier, onClick: () -> Unit) {
    val transition = rememberInfiniteTransition(label = "premium-settings-glow")
    val glow by transition.animateFloat(
        initialValue = .28f,
        targetValue = .72f,
        animationSpec = infiniteRepeatable(tween(1700), RepeatMode.Reverse),
        label = "premium-glow-alpha"
    )
    val shape = RoundedCornerShape(22.dp)
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .clickable(onClick = onClick)
            .border(1.dp, Color(0xFFFFD66B).copy(alpha = .45f + glow * .35f), shape),
        color = Color.Transparent
    ) {
        Row(
            Modifier
                .background(
                    Brush.linearGradient(
                        listOf(
                            Color(0xFF5B4210).copy(alpha = .72f),
                            Color(0xFFB77A14).copy(alpha = .42f + glow * .14f),
                            Color(0xFF3A2A0C).copy(alpha = .82f)
                        )
                    )
                )
                .padding(horizontal = 15.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFFFD66B).copy(alpha = .16f + glow * .12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.WorkspacePremium, null, tint = Color(0xFFFFD66B), modifier = Modifier.size(25.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("SONUS Premium", color = Color(0xFFFFE9A8), fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                Text("Planos, temas e recursos avançados • toque para conhecer", color = Color.White.copy(alpha = .78f), style = MaterialTheme.typography.bodySmall)
            }
            PlanStatusPill(membershipTier)
            Spacer(Modifier.width(5.dp))
            Icon(Icons.Default.ChevronRight, null, tint = Color(0xFFFFD66B))
        }
    }
}

@Composable
private fun SonusNotificationCenterScreen(
    items: List<SonusNotificationItem>,
    onBack: () -> Unit,
    onOpenRoute: (String?) -> Unit
) {
    val context = LocalContext.current
    val zone = remember { ZoneId.systemDefault() }
    val grouped = remember(items, zone) {
        items.groupBy { Instant.ofEpochMilli(it.createdAtEpochMillis).atZone(zone).toLocalDate() }
            .toSortedMap(compareByDescending { it })
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 34.dp)
    ) {
        item { PageHeader("Notificações", onBack) }
        if (items.isNotEmpty()) {
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { SonusNotificationCenter.markAllRead(context) }, modifier = Modifier.weight(1f)) { Text("Marcar como lidas") }
                    TextButton(onClick = { SonusNotificationCenter.clear(context) }, modifier = Modifier.weight(1f)) { Text("Limpar histórico") }
                }
            }
        }
        if (items.isEmpty()) {
            item {
                Column(
                    Modifier.fillMaxWidth().padding(vertical = 44.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.NotificationsNone, null, modifier = Modifier.size(40.dp), tint = Color(0xFFFFD76A))
                    Text("Tudo tranquilo por aqui", fontWeight = FontWeight.ExtraBold)
                    Text(
                        "Avisos importantes do SONUS vão aparecer nesta central.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = .62f),
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            grouped.forEach { (day, dayItems) ->
                item(key = "day-$day") {
                    Text(
                        when (day) {
                            LocalDate.now() -> "Hoje"
                            LocalDate.now().minusDays(1) -> "Ontem"
                            else -> day.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))
                        },
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = .78f)
                    )
                }
                dayItems.forEach { notification ->
                    item(key = notification.id) {
                        SonusNotificationCard(
                            notification = notification,
                            onOpen = {
                                SonusNotificationCenter.markRead(context, notification.id)
                                onOpenRoute(notification.route)
                            },
                            onDelete = { SonusNotificationCenter.delete(context, notification.id) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SonusNotificationSettingsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var prefs by remember { mutableStateOf(SonusNotificationCenter.preferences(context)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        SonusNotificationCenter.setExternalEnabled(context, granted); prefs = SonusNotificationCenter.preferences(context)
    }
    fun requestExternal() {
        if (Build.VERSION.SDK_INT >= 33 && androidx.core.content.ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
        else { SonusNotificationCenter.setExternalEnabled(context, true); prefs = SonusNotificationCenter.preferences(context) }
    }
    fun cat(key:String,value:Boolean){ SonusNotificationCenter.setCategory(context,key,value); prefs=SonusNotificationCenter.preferences(context) }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal=16.dp),verticalArrangement=Arrangement.spacedBy(12.dp),contentPadding=PaddingValues(top=12.dp,bottom=34.dp)) {
        item { PageHeader("Notificações", onBack) }
        item {
            Surface(shape=RoundedCornerShape(22.dp),color=Color(0xFF12344A).copy(alpha=.55f),border=BorderStroke(1.dp,Color(0xFF66D7FF).copy(alpha=.25f))) {
                Row(Modifier.fillMaxWidth().padding(16.dp),verticalAlignment=Alignment.CenterVertically) {
                    Surface(shape=RoundedCornerShape(15.dp),color=Color(0xFF66D7FF).copy(alpha=.14f)){Icon(Icons.Default.NotificationsActive,null,tint=Color(0xFF8DD7FF),modifier=Modifier.padding(11.dp).size(25.dp))}
                    Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text("Central SONUS",fontWeight=FontWeight.Black,fontSize=19.sp);Text("Suporte, Stream, segurança e acontecimentos importantes.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.66f))}
                }
            }
        }
        item { NotificationSectionTitle("SEMPRE IMPORTANTES") }
        item { SonusLockedNotificationRow(Icons.Default.SupportAgent,"Mensagens do suporte","Respostas e solicitações da equipe SONUS") }
        item { SonusLockedNotificationRow(Icons.Default.VerifiedUser,"Conta e segurança","Alertas importantes relacionados à sua conta") }
        item {
            if(!prefs.externalEnabled) OutlinedButton(onClick=::requestExternal,modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.PhoneAndroid,null);Spacer(Modifier.width(7.dp));Text("Permitir avisos importantes no celular")}
            else Text("Avisos externos permitidos neste aparelho.",style=MaterialTheme.typography.labelSmall,color=Color(0xFF63E2C2))
        }
        item { NotificationSectionTitle("SONUS STREAM E ARTISTAS") }
        item { SonusSoftNotificationRow(Icons.Default.GraphicEq,"Stream e artistas","Envio recebido, música aprovada/recusada, correções e foto do artista",prefs.streamArtists){cat("cat_stream",it)} }
        item { NotificationSectionTitle("OUTRAS CATEGORIAS") }
        item { SonusSoftNotificationRow(Icons.Default.Diamond,"Premium e benefícios","Saldo, vencimento e benefícios importantes",prefs.premiumUsage){cat("cat_premium",it)} }
        item { SonusSoftNotificationRow(Icons.Default.Build,"Ferramentas e processos","Conclusões e falhas relevantes",prefs.tools){cat("cat_tools",it)} }
        item { SonusSoftNotificationRow(Icons.Default.AccountBalanceWallet,"Distribuição e financeiro","Marcos financeiros e informações de distribuição",prefs.financial){cat("cat_financial",it)} }
        item { SonusSoftNotificationRow(Icons.Default.Backup,"Backup e segurança","Falhas de backup e avisos que exigem atenção",prefs.backupSafety){cat("cat_backup",it)} }
        item { SonusSoftNotificationRow(Icons.Default.AutoAwesome,"Novidades SONUS","Novos recursos e comunicados gerais",prefs.sonusUpdates){cat("cat_updates",it)} }
        item { NotificationSectionTitle("RESUMO DIÁRIO") }
        item {
            Surface(shape=RoundedCornerShape(18.dp),color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.30f)) {
                Column(Modifier.fillMaxWidth().padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                    SonusSoftNotificationRow(Icons.Default.Schedule,"Resumo financeiro diário","No máximo uma vez por dia",prefs.forecasts){cat("cat_forecasts",it)}
                    if(prefs.forecasts){HorizontalDivider();Row(verticalAlignment=Alignment.CenterVertically){Text("Horário",Modifier.weight(1f),fontWeight=FontWeight.Bold);IconButton(onClick={SonusNotificationCenter.setForecastHour(context,(prefs.forecastHour-1).coerceAtLeast(18));prefs=SonusNotificationCenter.preferences(context)}){Icon(Icons.Default.Remove,null)};Text("%02d:00".format(prefs.forecastHour),fontWeight=FontWeight.Black,color=MaterialTheme.colorScheme.primary);IconButton(onClick={SonusNotificationCenter.setForecastHour(context,(prefs.forecastHour+1).coerceAtMost(23));prefs=SonusNotificationCenter.preferences(context)}){Icon(Icons.Default.Add,null)}}}
                }
            }
        }
        item { NotificationSectionTitle("NÃO PERTURBE") }
        item { Surface(shape=RoundedCornerShape(18.dp),color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.30f)){Column(Modifier.fillMaxWidth().padding(13.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){SonusSoftNotificationRow(Icons.Default.Bedtime,"Não perturbe","Silencia avisos comuns; suporte e segurança continuam prioritários",prefs.quietHours){SonusNotificationCenter.setQuietHours(context,it,prefs.quietStart,prefs.quietEnd);prefs=SonusNotificationCenter.preferences(context)};if(prefs.quietHours)Row(verticalAlignment=Alignment.CenterVertically){Text("${prefs.quietStart}:00 — ${prefs.quietEnd}:00",Modifier.weight(1f),fontWeight=FontWeight.Bold);TextButton(onClick={SonusNotificationCenter.setQuietHours(context,true,23,8);prefs=SonusNotificationCenter.preferences(context)}){Text("23h–08h")};TextButton(onClick={SonusNotificationCenter.setQuietHours(context,true,22,7);prefs=SonusNotificationCenter.preferences(context)}){Text("22h–07h")}}}} }
        item { Text("Mensagens de suporte e segurança permanecem registradas na Central SONUS. Se o Android bloquear notificações do aplicativo, o SONUS não consegue ignorar essa escolha do sistema.",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.55f)) }
    }
}

@Composable private fun NotificationSectionTitle(text:String){Text(text,fontSize=10.sp,fontWeight=FontWeight.Black,color=MaterialTheme.colorScheme.primary,modifier=Modifier.padding(top=4.dp,start=3.dp))}
@Composable private fun SonusLockedNotificationRow(icon:ImageVector,title:String,subtitle:String){Surface(shape=RoundedCornerShape(18.dp),color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.28f)){Row(Modifier.fillMaxWidth().padding(13.dp),verticalAlignment=Alignment.CenterVertically){Surface(shape=RoundedCornerShape(12.dp),color=MaterialTheme.colorScheme.primary.copy(alpha=.12f)){Icon(icon,null,tint=MaterialTheme.colorScheme.primary,modifier=Modifier.padding(9.dp).size(21.dp))};Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(title,fontWeight=FontWeight.ExtraBold);Text(subtitle,style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.58f))};Surface(shape=RoundedCornerShape(50),color=Color(0xFF63E2C2).copy(alpha=.14f)){Row(Modifier.padding(horizontal=9.dp,vertical=5.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Lock,null,modifier=Modifier.size(12.dp),tint=Color(0xFF63E2C2));Spacer(Modifier.width(4.dp));Text("Ativo",fontSize=9.sp,fontWeight=FontWeight.Bold,color=Color(0xFF63E2C2))}}}}}
@Composable private fun SonusSoftNotificationRow(icon:ImageVector,title:String,subtitle:String,checked:Boolean,onChange:(Boolean)->Unit){Surface(shape=RoundedCornerShape(18.dp),color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.28f)){Row(Modifier.fillMaxWidth().padding(horizontal=13.dp,vertical=11.dp),verticalAlignment=Alignment.CenterVertically){Icon(icon,null,tint=MaterialTheme.colorScheme.primary,modifier=Modifier.size(22.dp));Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(title,fontWeight=FontWeight.Bold);Text(subtitle,style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.55f))};Switch(checked,onChange,modifier=Modifier.scale(.82f))}}}

@Composable
private fun NotificationCategoryToggle(title: String, subtitle: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .56f))
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun SonusNotificationCard(notification: SonusNotificationItem, onOpen: () -> Unit, onDelete: () -> Unit) {
    val time = remember(notification.createdAtEpochMillis) {
        Instant.ofEpochMilli(notification.createdAtEpochMillis).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("HH:mm"))
    }
    val icon = when (notification.category) {
        "FINANCEIRO" -> Icons.Default.Payments
        "PREVISAO" -> Icons.Default.TrendingUp
        "PREMIUM" -> Icons.Default.WorkspacePremium
        "BACKUP" -> Icons.Default.Cloud
        else -> Icons.Default.Notifications
    }
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onOpen),
        shape = RoundedCornerShape(18.dp),
        color = if (notification.read) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .36f) else MaterialTheme.colorScheme.primaryContainer.copy(alpha = .34f),
        border = BorderStroke(1.dp, if (notification.read) MaterialTheme.colorScheme.outline.copy(alpha = .10f) else MaterialTheme.colorScheme.primary.copy(alpha = .16f))
    ) {
        Row(Modifier.padding(13.dp), verticalAlignment = Alignment.Top) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 2.dp))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(notification.title, fontWeight = if (notification.read) FontWeight.Bold else FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                    Text(time, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .48f))
                }
                Text(notification.body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .67f))
            }
            IconButton(onClick = onDelete, modifier = Modifier.size(34.dp)) { Icon(Icons.Default.Close, "Excluir", modifier = Modifier.size(17.dp)) }
        }
    }
}

@Composable
private fun ProPlanChoiceDialog(
    minimumTier: MembershipTier,
    onDismiss: () -> Unit,
    onChoose: (MembershipTier) -> Unit
) {
    val plans = PremiumCatalog.plans.filter { it.tier.ordinal >= minimumTier.ordinal }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.WorkspacePremium, null, tint = Color(0xFFFFC84B))
                    Spacer(Modifier.width(8.dp))
                    Text("Escolha um plano", fontWeight = FontWeight.ExtraBold)
                }
                Text("Este recurso faz parte do SONUS PRO.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f))
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                plans.forEach { plan ->
                    Surface(
                        modifier = Modifier.fillMaxWidth().clickable { onChoose(plan.tier) },
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = .30f)),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .45f)
                    ) {
                        Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(plan.title, fontWeight = FontWeight.ExtraBold)
                                Text(plan.monthlyPrice, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                            }
                            plan.highlight?.let {
                                Surface(shape = RoundedCornerShape(999.dp), color = Color(0xFFFFC84B).copy(alpha = .14f)) {
                                    Text(it, modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp), fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFFC84B))
                                }
                                Spacer(Modifier.width(6.dp))
                            }
                            Icon(Icons.Default.ChevronRight, null)
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Agora não") } }
    )
}

@Composable
private fun PremiumScreen(
    membershipTier: MembershipTier,
    premiumExpiresAt: Long?,
    premiumUsesRemaining: Int,
    usageEvents: List<PremiumUsageEvent>,
    onBack: () -> Unit
) {
    var selected by remember { mutableStateOf<PremiumPlanInfo?>(null) }
    val plans=PremiumCatalog.plans
    selected?.let { plan ->
        AlertDialog(
            onDismissRequest = { selected = null },
            title = { Text(plan.title, fontWeight = FontWeight.Black) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Planos SONUS Premium", fontWeight = FontWeight.Bold)
                    Text(plan.monthlyPrice, fontSize = 24.sp, fontWeight = FontWeight.Black)
                    plan.annualPrice?.let { Text("Anual: $it", style = MaterialTheme.typography.bodySmall) }
                    plan.benefits.take(6).forEach { benefit ->
                        Row {
                            Icon(Icons.Default.CheckCircle, null, tint = SignalGreen, modifier = Modifier.size(17.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(benefit, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = .45f)
                    ) {
                        Text(
                            "A contratação por Pix será liberada em uma próxima versão. Nesta atualização, a tela Premium já mostra os planos e benefícios sem iniciar cobrança.",
                            modifier = Modifier.padding(10.dp),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            },
            confirmButton = { TextButton(onClick = { selected = null }) { Text("Entendi") } }
        )
    }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal=16.dp),verticalArrangement=Arrangement.spacedBy(12.dp),contentPadding=PaddingValues(top=10.dp,bottom=34.dp)){
        item{PageHeader("Premium",onBack)}
        item{Column{
            Text("SONUS PREMIUM",fontWeight=FontWeight.Black,fontSize=25.sp)
            Text("ESCOLHA A MELHOR OPÇÃO PRA VOCÊ",fontWeight=FontWeight.Bold,fontSize=13.sp,color=MaterialTheme.colorScheme.primary)
            val activeUntil=premiumExpiresAt?.takeIf{it>System.currentTimeMillis()}
            if(membershipTier!=MembershipTier.FREE&&activeUntil!=null){
                val date=java.time.Instant.ofEpochMilli(activeUntil).atZone(java.time.ZoneId.systemDefault()).toLocalDate()
                Text("Plano atual: ${membershipLabel(membershipTier)} • válido até ${date.dayOfMonth.toString().padStart(2,'0')}/${date.monthValue.toString().padStart(2,'0')}/${date.year}",fontSize=10.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.68f))
            } else if(membershipTier==MembershipTier.FREE) Text("Plano atual: Grátis",fontSize=10.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.68f))
        }}
        item{PremiumSimplePlanCard("Grátis","Conheça o SONUS sem compromisso","R$ 0",listOf("5 Moedas SONUS/mês","1 artista • 3 envios/mês ao Stream","Player e Stream completos","SOCIAL EDIT • vídeos de 15s","PRO: 1 moeda ou anúncio por bloco de até 5 arquivos","7 dias para testar Distribuição & Pagamentos"),listOf(Color(0xFF343740),Color(0xFF555A64)),commercialTier(membershipTier)==MembershipTier.FREE,null)}
        items(plans){plan->
            val colors=when(plan.tier){
                MembershipTier.PRATA->listOf(Color(0xFF46515D),Color(0xFF8A98A8));
                MembershipTier.OURO->listOf(Color(0xFF5B4723),Color(0xFFB3914D));
                MembershipTier.DIAMANTE->listOf(Color(0xFF24364A),Color(0xFF6887A3));
                else->listOf(Color(0xFF343740),Color(0xFF555A64))
            }
            val subtitle=when(plan.tier){MembershipTier.PRATA->"Entre no PRO pagando pouco";MembershipTier.OURO->"Para quem cria e produz mais";MembershipTier.DIAMANTE->"A experiência SONUS mais completa";else->"SONUS"}
            PremiumSimplePlanCard(plan.title,subtitle,plan.monthlyPrice,plan.benefits.take(5),colors,commercialTier(membershipTier)==plan.tier,if(plan.tier==MembershipTier.OURO)"Recomendado" else if(plan.tier==MembershipTier.DIAMANTE)"Mais completo" else if(plan.tier==MembershipTier.PRATA)"Entrada PRO" else null){selected=plan}
        }
        item{Text("COMPARE OS PLANOS",fontWeight=FontWeight.Black,fontSize=15.sp)}
        item{PremiumCompareTable()}
    }
}

@Composable private fun PremiumSimplePlanCard(title:String,subtitle:String,price:String,benefits:List<String>,colors:List<Color>,current:Boolean,badge:String?,onClick:(()->Unit)?=null){
    Surface(shape=RoundedCornerShape(22.dp),color=Color.Transparent,border=BorderStroke(1.dp,Color.White.copy(alpha=.15f)),modifier=Modifier.fillMaxWidth().then(if(onClick!=null)Modifier.clickable(onClick=onClick) else Modifier)){
        Column(Modifier.background(Brush.linearGradient(colors)).padding(15.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){
            Row(verticalAlignment=Alignment.CenterVertically){
                Text(title.uppercase(),color=Color.White,fontWeight=FontWeight.Black,fontSize=18.sp,modifier=Modifier.weight(1f))
                if(badge!=null)Surface(shape=RoundedCornerShape(20.dp),color=Color.White.copy(alpha=.14f)){Text(badge,Modifier.padding(horizontal=8.dp,vertical=3.dp),color=Color.White,fontSize=10.sp,fontWeight=FontWeight.Bold)}
                if(current)Text("  • ATUAL",color=Color.White.copy(alpha=.8f),fontSize=10.sp,fontWeight=FontWeight.Bold)
            }
            Text(price,color=Color.White,fontSize=22.sp,fontWeight=FontWeight.Black)
            Text(subtitle,color=Color.White.copy(alpha=.78f),fontSize=11.sp)
            benefits.forEach{ Row(verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.CheckCircle,null,tint=Color(0xFF69E391),modifier=Modifier.size(15.dp));Spacer(Modifier.width(6.dp));Text(it,color=Color.White.copy(alpha=.90f),fontSize=11.sp)} }
            if(onClick!=null) FilledTonalButton(onClick=onClick,modifier=Modifier.fillMaxWidth()){Text("Escolher $title")}
        }
    }
}

private sealed interface PremiumCompareValue {
    data class TextValue(val text:String):PremiumCompareValue
    data class Included(val yes:Boolean):PremiumCompareValue
}

@Composable private fun PremiumCompareTable(){
    val Y=PremiumCompareValue.Included(true); val N=PremiumCompareValue.Included(false)
    fun T(v:String)=PremiumCompareValue.TextValue(v)
    val rows=listOf(
        "SONUS Player" to listOf(Y,Y,Y,Y),
        "SONUS Stream" to listOf(Y,Y,Y,Y),
        "SOCIAL EDIT" to listOf(T("15s"),T("30–65s"),T("30–65s"),T("30–65s")),
        "Moedas SONUS" to listOf(T("5/mês"),T("200/mês"),T("500/mês"),T("Ilimitadas")),
        "Artistas" to listOf(T("1"),T("3"),T("8"),T("Ilimitados")),
        "Ferramentas PRO" to listOf(T("1 moeda/anúncio"),T("1 moeda/bloco"),T("1 moeda/bloco"),T("Ilimitadas")),
        "AutoMix" to listOf(T("Moeda/anúncio"),Y,Y,Y),
        "Cortador Pro" to listOf(T("Moeda/anúncio"),Y,Y,Y),
        "Caixa Preta SONUS" to listOf(N,Y,Y,Y),
        "Widgets financeiros" to listOf(T("No teste"),Y,Y,Y),
        "Envios ao Stream/mês" to listOf(T("3"),T("10"),T("20"),T("30")),
        "Temas e ícones" to listOf(T("Básicos"),T("Prata"),T("Prata + Ouro"),T("Todos")),
        "Distribuição & Pagamentos" to listOf(T("7 dias"),Y,Y,Y)
    )
    Surface(shape=RoundedCornerShape(18.dp),color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.35f)){
        Column(Modifier.padding(10.dp)){
            Row{Text("FUNÇÃO",Modifier.weight(1.55f),fontWeight=FontWeight.Black,fontSize=10.sp);listOf("Grátis","Prata","Ouro","Diamante").forEach{Text(it,Modifier.weight(1f),fontWeight=FontWeight.Black,fontSize=8.sp,textAlign=TextAlign.Center)}}
            rows.forEach{(name,values)->
                HorizontalDivider(Modifier.padding(vertical=5.dp),color=MaterialTheme.colorScheme.outline.copy(alpha=.12f))
                Row(verticalAlignment=Alignment.CenterVertically){
                    Text(name,Modifier.weight(1.55f),fontSize=10.sp)
                    values.forEach{ value -> Box(Modifier.weight(1f),contentAlignment=Alignment.Center){when(value){is PremiumCompareValue.TextValue->Text(value.text,fontSize=9.sp,textAlign=TextAlign.Center);is PremiumCompareValue.Included->Icon(if(value.yes)Icons.Default.CheckCircle else Icons.Default.Cancel,null,tint=if(value.yes)Color(0xFF47C879) else Color(0xFFE55D62),modifier=Modifier.size(17.dp))}} }
                }
            }
        }
    }
}

@Composable
private fun PremiumPlanCard(plan: PremiumPlanInfo, onClick: () -> Unit) {
    val gradient = when (plan.tier) {
        MembershipTier.BRONZE -> membershipGradient(MembershipTier.BRONZE)
        MembershipTier.PRATA -> membershipGradient(MembershipTier.PRATA)
        MembershipTier.OURO -> membershipGradient(MembershipTier.OURO)
        MembershipTier.DIAMANTE -> membershipGradient(MembershipTier.DIAMANTE)
        else -> listOf(Color(0xFF35404E), Color(0xFF1D252E))
    }
    val shape = RoundedCornerShape(24.dp)
    Surface(
        modifier = Modifier.fillMaxWidth().clip(shape).clickable(onClick = onClick),
        color = Color.Transparent,
        border = BorderStroke(1.dp, gradient.first().copy(alpha = .55f)),
        shape = shape
    ) {
        Column(
            Modifier.background(Brush.linearGradient(gradient.map { it.copy(alpha = .62f) } + Color(0xFF101827))).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                PlanGlyph(plan.tier, 34.dp)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text(plan.title, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                        plan.highlight?.let {
                            Surface(shape = RoundedCornerShape(50), color = Color.White.copy(alpha = .15f)) {
                                Text(it, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp))
                            }
                        }
                    }
                    Text(plan.artistLimitLabel, color = Color.White.copy(alpha = .72f), style = MaterialTheme.typography.bodySmall)
                }
                Icon(Icons.Default.ChevronRight, null, tint = Color.White.copy(alpha = .75f))
            }
            Text(plan.monthlyPrice, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
            plan.annualPrice?.let { Text(it, color = Color.White.copy(alpha = .82f), fontWeight = FontWeight.SemiBold) }
            Text(plan.benefits.take(3).joinToString(" • "), color = Color.White.copy(alpha = .72f), style = MaterialTheme.typography.bodySmall, maxLines = 3)
            Surface(shape = RoundedCornerShape(50), color = Color.White.copy(alpha = .12f)) {
                Text(if (plan.annualPrice != null) "Ver mensal e anual" else "Ver opção de 30 dias", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
            }
        }
    }
}

private enum class DeveloperModule(val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    SONUS_MUSIC("SONUS Stream", Icons.Default.Public),
    ANALYTICS("Analytics", Icons.Default.QueryStats),
    REMOTE("Admin", Icons.Default.AdminPanelSettings),
    MONETIZACAO("Monetização", Icons.Default.Paid),
    SUPPORT("Suporte", Icons.Default.SupportAgent),
    PLANOS("Planos", Icons.Default.WorkspacePremium),
    PROMOS("Códigos", Icons.Default.ConfirmationNumber),
    FERRAMENTAS("Ferramentas", Icons.Default.BuildCircle),
    MEDIA("Mídia", Icons.Default.GraphicEq),
    SISTEMA("Sistema", Icons.Default.Memory),
    COMUNIDADE("Comunidade", Icons.Default.Groups),
    LOGS("Logs", Icons.Default.BugReport),
    RESUMO("Resumo", Icons.Default.Dashboard)
}

@Composable
private fun DeveloperPanelScreen(
    authUser: AuthUser,
    testMode: OwnerTestMode,
    onTestModeChange: (OwnerTestMode) -> Unit,
    onRefreshRole: () -> Unit,
    adManager: StreamPulseAdManager,
    initialModuleName: String? = null,
    pendingLrc: String? = null,
    onPendingLrcConsumed: () -> Unit = {},
    onInitialModuleConsumed: () -> Unit = {},
    onOpenLrcEditor: () -> Unit = {},
    onBack: () -> Unit
) {
    var selectedModule by rememberSaveable { mutableStateOf(initialModuleName?.let { runCatching { DeveloperModule.valueOf(it) }.getOrNull() } ?: DeveloperModule.SONUS_MUSIC) }
    var showStreamModeration by rememberSaveable { mutableStateOf(false) }
    var showLrcLibrary by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(initialModuleName) {
        initialModuleName?.let { runCatching { DeveloperModule.valueOf(it) }.getOrNull() }?.let { selectedModule = it }
        if (initialModuleName != null) onInitialModuleConsumed()
    }
    val uidPreview = if (authUser.uid.length > 16) authUser.uid.take(8) + "…" + authUser.uid.takeLast(6) else authUser.uid

    if (showStreamModeration) {
        SonusStreamCreatorCenter(
            user = authUser,
            tier = MembershipTier.DIAMANTE,
            mode = StreamCenterMode.MODERATION,
            onBack = { showStreamModeration = false }
        )
        return
    }

    if (showLrcLibrary) {
        DeveloperLrcLibraryScreen(onBack = { showLrcLibrary = false }, onOpenEditor = onOpenLrcEditor)
        return
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        PageHeader("Painel Desenvolvedor", onBack)
        Text("Central de controle OWNER", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha=.58f))
        Spacer(Modifier.height(10.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(end=8.dp)) {
            items(DeveloperModule.entries.toList(), key = { it.name }) { module ->
                val selected = module == selectedModule
                Surface(
                    modifier = Modifier.width(112.dp).height(72.dp).clickable { selectedModule = module },
                    shape = RoundedCornerShape(17.dp),
                    color = if (selected) Color(0xFF0D5E78).copy(alpha=.88f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.48f),
                    border = BorderStroke(1.dp, if (selected) Color(0xFF54D8FF).copy(alpha=.70f) else MaterialTheme.colorScheme.outline.copy(alpha=.16f))
                ) {
                    Column(Modifier.fillMaxSize().padding(9.dp), horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.Center) {
                        Icon(module.icon, null, tint = if(selected) Color(0xFF65E0FF) else MaterialTheme.colorScheme.onSurface.copy(alpha=.70f), modifier=Modifier.size(22.dp))
                        Spacer(Modifier.height(5.dp))
                        Text(module.title, fontSize=10.sp, fontWeight=FontWeight.Bold, maxLines=1, overflow=TextOverflow.Ellipsis)
                    }
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Box(Modifier.weight(1f)) {
            when (selectedModule) {
                DeveloperModule.RESUMO -> LazyColumn(
                    modifier=Modifier.fillMaxSize(), verticalArrangement=Arrangement.spacedBy(12.dp), contentPadding=PaddingValues(bottom=34.dp)
                ) {
                    item { DeveloperSectionHero(Icons.Default.Dashboard, "Visão geral", "Status rápido do SONUS e atalhos para os módulos administrativos.", Color(0xFF33C8F2)) }
                    item { OwnerDeveloperCard(authUser, uidPreview, onRefreshRole) }
                    item {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                            DeveloperSummaryTile(Modifier.weight(1f), "v${BuildConfig.VERSION_NAME}", "versão", Color(0xFF5EC8FF))
                            DeveloperSummaryTile(Modifier.weight(1f), "${BuildConfig.VERSION_CODE}", "code", Color(0xFFB694FF))
                            DeveloperSummaryTile(Modifier.weight(1f), if(testMode==OwnerTestMode.OWNER) "OWNER" else testMode.name, "modo", SignalGreen)
                        }
                    }
                    item { DeveloperBuildDeviceCard() }
                    item {
                        Surface(shape=RoundedCornerShape(20.dp),color=Color(0xFF102636).copy(alpha=.78f),border=BorderStroke(1.dp,Color(0xFF3EB8E5).copy(alpha=.30f))) {
                            Column(Modifier.padding(15.dp),verticalArrangement=Arrangement.spacedBy(7.dp)) {
                                Text("Acesso rápido",fontWeight=FontWeight.ExtraBold,color=Color.White)
                                Text("Use os módulos acima para administrar SONUS Stream, Analytics, Admin, Monetização, Suporte, Planos, Códigos, Ferramentas, Mídia, Sistema, Comunidade e Logs.",color=Color.White.copy(.68f),style=MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }


                DeveloperModule.SONUS_MUSIC -> LazyColumn(Modifier.fillMaxSize(), verticalArrangement=Arrangement.spacedBy(12.dp), contentPadding=PaddingValues(bottom=34.dp)) {
                    item {
                        Row(Modifier.fillMaxWidth().height(112.dp),horizontalArrangement=Arrangement.spacedBy(9.dp)) {
                            DeveloperModerationShortcutCard(
                                modifier = Modifier.weight(1f).fillMaxHeight(),
                                onClick = { showStreamModeration = true }
                            )
                            DeveloperLrcShortcutCard(
                                modifier = Modifier.weight(1f).fillMaxHeight(),
                                onClick = { showLrcLibrary = true }
                            )
                        }
                    }
                    item { SonusStreamServiceDiagnosticCard() }
                    item { SonusMusicDeveloperPanel(authUser = authUser, pendingLrc = pendingLrc, onPendingLrcConsumed = onPendingLrcConsumed) }
                }

                DeveloperModule.SUPPORT -> SonusSupportScreen(
                    user = authUser,
                    technicalContext = mapOf(
                        "appVersion" to "${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})",
                        "plan" to testMode.name,
                        "android" to Build.VERSION.RELEASE,
                        "device" to "${Build.MANUFACTURER} ${Build.MODEL}",
                        "page" to "DEVELOPER_SUPPORT"
                    ),
                    onBack = { selectedModule = DeveloperModule.SONUS_MUSIC }
                )

                DeveloperModule.ANALYTICS -> LazyColumn(Modifier.fillMaxSize(), verticalArrangement=Arrangement.spacedBy(12.dp), contentPadding=PaddingValues(bottom=34.dp)) {
                    item { DeveloperRemotePanel(authUser.uid, DeveloperRemoteSection.ANALYTICS) }
                }

                DeveloperModule.PROMOS -> LazyColumn(Modifier.fillMaxSize(), verticalArrangement=Arrangement.spacedBy(12.dp), contentPadding=PaddingValues(bottom=34.dp)) {
                    item { DeveloperRemotePanel(authUser.uid, DeveloperRemoteSection.PROMOS) }
                }

                DeveloperModule.PLANOS -> LazyColumn(Modifier.fillMaxSize(), verticalArrangement=Arrangement.spacedBy(12.dp), contentPadding=PaddingValues(bottom=34.dp)) {
                    item { DeveloperSectionHero(Icons.Default.WorkspacePremium, "Planos & acesso", "Simule os níveis do SONUS sem alterar sua autorização OWNER real.", Color(0xFFFFC857)) }
                    item {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(OwnerTestMode.entries.toList(), key = { it.name }) { mode ->
                                FilterChip(selected = testMode == mode, onClick = { onTestModeChange(mode) }, label = { Text(if (mode == OwnerTestMode.OWNER) "OWNER" else mode.name) }, leadingIcon = if (mode == OwnerTestMode.OWNER) { { Icon(Icons.Default.AdminPanelSettings, null, modifier = Modifier.size(17.dp)) } } else null)
                            }
                        }
                    }
                    item {
                        Surface(shape=RoundedCornerShape(20.dp),color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.68f),border=BorderStroke(1.dp,MaterialTheme.colorScheme.outline.copy(alpha=.18f))) {
                            Column(Modifier.padding(15.dp),verticalArrangement=Arrangement.spacedBy(9.dp)) {
                                Text("Comportamento atual",fontWeight=FontWeight.ExtraBold)
                                Text(when(testMode){
                                    OwnerTestMode.OWNER -> "OWNER • acesso completo • artistas e ferramentas ilimitados"
                                    OwnerTestMode.FREE -> "Simulando Grátis • 5 moedas/mês (+ até 10 por anúncios premiados) • PRO: 1 moeda ou anúncio por bloco de até 5"
                                    OwnerTestMode.PRATA -> "Simulando Prata • 200 moedas/mês • PRO: 1 moeda por bloco; sem saldo, Rewarded"
                                    OwnerTestMode.OURO -> "Simulando Ouro • 500 moedas/mês • PRO: 1 moeda por bloco; sem saldo, Rewarded"
                                    OwnerTestMode.DIAMANTE -> "Simulando Diamante • ferramentas elegíveis ilimitadas"
                                },style=MaterialTheme.typography.bodySmall)
                                Text("A simulação volta para OWNER quando você selecionar OWNER.",style=MaterialTheme.typography.labelSmall,color=SignalYellow)
                            }
                        }
                    }
                }

                DeveloperModule.MONETIZACAO -> LazyColumn(Modifier.fillMaxSize(), verticalArrangement=Arrangement.spacedBy(12.dp), contentPadding=PaddingValues(bottom=34.dp)) {
                    item { DeveloperSectionHero(Icons.Default.Paid, "Monetização", "AdMob/UMP e Rewarded Ads das ferramentas PRO. Player e Stream permanecem sem anúncios.", Color(0xFFFFC857)) }
                    item { DeveloperMonetizationCard(adManager, testMode) }
                }

                DeveloperModule.REMOTE -> LazyColumn(Modifier.fillMaxSize(), verticalArrangement=Arrangement.spacedBy(12.dp), contentPadding=PaddingValues(bottom=34.dp)) {
                    item { DeveloperRemotePanel(authUser.uid, DeveloperRemoteSection.REMOTE) }
                }

                DeveloperModule.FERRAMENTAS -> LazyColumn(Modifier.fillMaxSize(), verticalArrangement=Arrangement.spacedBy(12.dp), contentPadding=PaddingValues(bottom=34.dp)) {
                    item { DeveloperRemotePanel(authUser.uid, DeveloperRemoteSection.TOOLS) }
                }

                DeveloperModule.MEDIA -> LazyColumn(Modifier.fillMaxSize(), verticalArrangement=Arrangement.spacedBy(12.dp), contentPadding=PaddingValues(bottom=34.dp)) {
                    item { DeveloperSectionHero(Icons.Default.GraphicEq, "Diagnóstico de mídia", "Preview, áudio, exportação, spectrum e compatibilidade de codecs.", Color(0xFFB694FF)) }
                    item { DeveloperMediaDiagnosticCard() }
                    // Transcrição ao vivo removida do diagnóstico: letras TXT/LRC permanecem independentes e ativas.
                }

                DeveloperModule.SISTEMA -> LazyColumn(Modifier.fillMaxSize(), verticalArrangement=Arrangement.spacedBy(12.dp), contentPadding=PaddingValues(bottom=34.dp)) {
                    item { DeveloperSectionHero(Icons.Default.Memory, "Firebase & sistema", "Build, dispositivo, rede e infraestrutura do SONUS.", Color(0xFF64D8FF)) }
                    item { DeveloperBuildDeviceCard() }
                    item { DeveloperRemotePanel(authUser.uid, DeveloperRemoteSection.INFRA) }
                }

                DeveloperModule.COMUNIDADE -> LazyColumn(Modifier.fillMaxSize(), verticalArrangement=Arrangement.spacedBy(12.dp), contentPadding=PaddingValues(bottom=34.dp)) {
                    item { DeveloperRemotePanel(authUser.uid, DeveloperRemoteSection.COMMUNITY) }
                }

                DeveloperModule.LOGS -> LazyColumn(Modifier.fillMaxSize(), verticalArrangement=Arrangement.spacedBy(12.dp), contentPadding=PaddingValues(bottom=34.dp)) {
                    item { DeveloperRemotePanel(authUser.uid, DeveloperRemoteSection.LOGS) }
                }
            }
        }
    }
}

@Composable
private fun SonusStreamServiceDiagnosticCard() {
    val context=LocalContext.current;val scope=rememberCoroutineScope();val repo=remember{SonusStreamPlatformRepository(context)}
    var health by remember{mutableStateOf<Map<String,Boolean>>(emptyMap())};var loading by remember{mutableStateOf(false)}
    fun refresh(){scope.launch{loading=true;health=runCatching{repo.ownerStreamHealth()}.getOrDefault(emptyMap());loading=false}}
    LaunchedEffect(Unit){refresh()}
    val services = listOf(
        "audio" to "Áudio", "catalog" to "Catálogo", "counter" to "Contador",
        "artists" to "Artistas", "database" to "Firebase", "storage" to "Storage",
        "telegramUpload" to "Telegram", "analytics" to "Analytics", "notifications" to "Notificações"
    )
    Surface(shape=RoundedCornerShape(20.dp),color=Color(0xFF0D1D28),border=BorderStroke(1.dp,Color(0xFF54E3A8).copy(alpha=.22f))){
        Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){
            Row(verticalAlignment=Alignment.CenterVertically){
                Column(Modifier.weight(1f)){
                    Text("Serviços SONUS Stream",fontWeight=FontWeight.ExtraBold,color=Color.White)
                    Text("Diagnóstico técnico OWNER",style=MaterialTheme.typography.labelSmall,color=Color.White.copy(alpha=.55f))
                }
                IconButton(onClick={refresh()},enabled=!loading){Icon(Icons.Default.Refresh,"Atualizar",tint=Color(0xFF54E3A8))}
            }
            if(loading) LinearProgressIndicator(Modifier.fillMaxWidth())
            services.chunked(3).forEach { rowItems ->
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                    rowItems.forEach { (key,label) ->
                        val ok=health[key]
                        Surface(
                            modifier=Modifier.weight(1f),
                            shape=RoundedCornerShape(12.dp),
                            color=Color.White.copy(alpha=.055f),
                            border=BorderStroke(1.dp,Color.White.copy(alpha=.075f))
                        ){
                            Column(Modifier.padding(horizontal=7.dp,vertical=8.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(3.dp)){
                                Icon(
                                    if(ok==true)Icons.Default.CheckCircle else if(ok==false)Icons.Default.ErrorOutline else Icons.Default.HourglassEmpty,
                                    null,
                                    tint=if(ok==true)SignalGreen else if(ok==false)MaterialTheme.colorScheme.error else SignalYellow,
                                    modifier=Modifier.size(15.dp)
                                )
                                Text(label,color=Color.White,fontSize=9.sp,maxLines=1,overflow=TextOverflow.Ellipsis,textAlign=TextAlign.Center)
                                Text(if(ok==true)"OK" else if(ok==false)"Falha" else "—",fontSize=8.sp,color=Color.White.copy(alpha=.58f))
                            }
                        }
                    }
                    repeat(3-rowItems.size){Spacer(Modifier.weight(1f))}
                }
            }
        }
    }
}

@Composable
private fun DeveloperTranscriptionDiagnosticCard() {
    val context = LocalContext.current
    val available = remember { android.speech.SpeechRecognizer.isRecognitionAvailable(context) }
    val onDevice = remember {
        if (android.os.Build.VERSION.SDK_INT >= 31) android.speech.SpeechRecognizer.isOnDeviceRecognitionAvailable(context) else false
    }
    Surface(shape=RoundedCornerShape(20.dp),color=Color(0xFF14202C).copy(alpha=.86f),border=BorderStroke(1.dp,Color(0xFF63D5A7).copy(alpha=.30f))) {
        Column(Modifier.fillMaxWidth().padding(15.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment=Alignment.CenterVertically) {
                Icon(Icons.Default.RecordVoiceOver,null,tint=Color(0xFF63D5A7));Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)){Text("Transcrição ao vivo",fontWeight=FontWeight.ExtraBold,color=Color.White);Text("Diagnóstico do motor usado em Letras e Legenda ao vivo",fontSize=9.sp,color=Color.White.copy(alpha=.58f))}
                AssistChip(onClick={},enabled=false,label={Text(if(available) "Disponível" else "Indisponível")})
            }
            Text("Motor: ${if(onDevice) "reconhecimento no aparelho" else if(available) "serviço de voz do Android" else "nenhum motor disponível"}",fontSize=10.sp,color=Color.White.copy(alpha=.72f))
            Text("Áudio: PCM mono 16 kHz extraído internamente • sem microfone para mídias reproduzidas no SONUS",fontSize=9.sp,color=Color.White.copy(alpha=.56f))
            Text("Idiomas preparados: Português (Brasil) • English (US) • Español",fontSize=9.sp,color=Color.White.copy(alpha=.56f))
        }
    }
}

private fun developerLrcFileName(entry: SonusUnifiedLrcEntry): String {
    fun clean(raw: String): String {
        val invalid = setOf('\\', '/', ':', '*', '?', '"', '<', '>', '|')
        return raw.map { c -> if (c.code < 32 || c in invalid) ' ' else c }
            .joinToString("")
            .replace(Regex("\\s+"), " ")
            .trim().trimEnd('.', ' ')
    }
    val title = clean(entry.title).ifBlank { "Letra" }
    val artist = clean(entry.artist)
    return if (artist.isBlank()) "$title.lrc" else "$title - $artist.lrc"
}


@Composable
private fun DeveloperModerationShortcutCard(modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(
        modifier = modifier.clip(RoundedCornerShape(22.dp)).clickable(onClick=onClick),
        shape = RoundedCornerShape(22.dp),
        color = Color(0xFF163B42),
        border = BorderStroke(1.dp, Color(0xFF54E3A8).copy(alpha=.34f))
    ) {
        Column(Modifier.fillMaxSize().padding(12.dp),verticalArrangement=Arrangement.Center,horizontalAlignment=Alignment.CenterHorizontally) {
            Icon(Icons.Default.FactCheck,null,tint=Color(0xFF54E3A8),modifier=Modifier.size(25.dp))
            Spacer(Modifier.height(7.dp))
            Text("ABRIR MODERAÇÃO",color=Color.White,fontWeight=FontWeight.ExtraBold,fontSize=11.sp,textAlign=TextAlign.Center,maxLines=1)
            Text("DE ENVIOS",color=Color.White.copy(alpha=.76f),fontWeight=FontWeight.Bold,fontSize=9.sp,textAlign=TextAlign.Center)
        }
    }
}

@Composable
private fun DeveloperLrcShortcutCard(modifier: Modifier = Modifier, onClick: () -> Unit) {
    val context = LocalContext.current
    val repo = remember { SonusOnlineMusicRepository(context.applicationContext) }
    var count by remember { mutableIntStateOf(repo.cachedUnifiedLrcEntries().size) }
    LaunchedEffect(Unit) {
        count = withContext(Dispatchers.IO) { runCatching { repo.scanUnifiedLrcLibrary(false).size }.getOrDefault(count) }
    }
    Surface(
        modifier = modifier.clip(RoundedCornerShape(22.dp)).clickable(onClick=onClick),
        shape = RoundedCornerShape(22.dp),
        color = Color(0xFF080A0F),
        border = BorderStroke(1.dp, Color.White.copy(alpha=.18f))
    ) {
        Column(Modifier.fillMaxSize().padding(13.dp),verticalArrangement=Arrangement.Center,horizontalAlignment=Alignment.CenterHorizontally) {
            Icon(Icons.Default.Lyrics,null,tint=Color.White,modifier=Modifier.size(26.dp))
            Spacer(Modifier.height(7.dp))
            Text("Letras",color=Color.White,fontWeight=FontWeight.ExtraBold,fontSize=14.sp,textAlign=TextAlign.Center)
            Text("sincronizadas",color=Color.White.copy(alpha=.70f),fontSize=9.sp,textAlign=TextAlign.Center)
            Spacer(Modifier.height(7.dp))
            Text("$count LRC",color=Color(0xFF54E3A8),fontSize=10.sp,fontWeight=FontWeight.Bold)
        }
    }
}

@Composable
private fun DeveloperLrcLibraryScreen(onBack: () -> Unit, onOpenEditor: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val repo = remember { SonusOnlineMusicRepository(context.applicationContext) }
    var entries by remember { mutableStateOf(repo.cachedUnifiedLrcEntries()) }
    var query by rememberSaveable { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }
    var pendingDownload by remember { mutableStateOf<SonusUnifiedLrcEntry?>(null) }
    var bulkProgress by remember { mutableFloatStateOf(0f) }
    var bulkCancelRequested by remember { mutableStateOf(false) }

    val saveOne = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/x-lrc")) { uri ->
        val entry = pendingDownload
        pendingDownload = null
        if (uri != null && entry != null) scope.launch {
            loading = true
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val text = repo.unifiedLrcText(entry) ?: error("LRC indisponível")
                    context.contentResolver.openOutputStream(uri,"w")?.bufferedWriter(Charsets.UTF_8)?.use { it.write(text) }
                        ?: error("Não foi possível abrir o destino")
                }
            }
            loading = false
            status = if (result.isSuccess) "${entry.title} baixada." else "Falha ao baixar ${entry.title}."
        }
    }
    val saveAll = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) scope.launch {
            loading = true
            bulkCancelRequested = false
            bulkProgress = 0f
            status = "Preparando ${entries.size} letras…"
            var exported = 0
            var failed = 0
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val out = context.contentResolver.openOutputStream(uri) ?: error("Não foi possível abrir o destino")
                    out.use { raw ->
                        ZipOutputStream(raw.buffered()).use { zip ->
                            val used = mutableSetOf<String>()
                            entries.forEachIndexed { index, entry ->
                                if (bulkCancelRequested) return@forEachIndexed
                                val text = repo.unifiedLrcText(entry)
                                if (text.isNullOrBlank()) {
                                    failed++
                                } else {
                                    var name = developerLrcFileName(entry)
                                    if (!used.add(name.lowercase(Locale.ROOT))) {
                                        val base = name.removeSuffix(".lrc")
                                        var n = 2
                                        while (!used.add("$base ($n).lrc".lowercase(Locale.ROOT))) n++
                                        name = "$base ($n).lrc"
                                    }
                                    zip.putNextEntry(ZipEntry(name))
                                    zip.write(text.toByteArray(Charsets.UTF_8))
                                    zip.closeEntry()
                                    exported++
                                }
                                withContext(Dispatchers.Main) {
                                    bulkProgress = (index + 1).toFloat() / entries.size.coerceAtLeast(1).toFloat()
                                    status = if (bulkCancelRequested) "Cancelando…" else "Exportando ${index + 1}/${entries.size} • $exported válidas"
                                }
                            }
                        }
                    }
                }
            }
            loading = false
            status = when {
                bulkCancelRequested -> "Exportação interrompida • $exported letras incluídas."
                result.isSuccess -> "Pacote salvo • $exported letras${if(failed>0)" • $failed falha(s)" else ""}."
                else -> "Não foi possível salvar todas as letras."
            }
            bulkProgress = 0f
            bulkCancelRequested = false
        }
    }

    fun refreshLibrary(force: Boolean) {
        if (loading) return
        scope.launch {
            loading = true
            bulkProgress = 0f
            status = "Escaneando catálogo e letras sincronizadas…"
            entries = withContext(Dispatchers.IO) {
                runCatching { repo.scanUnifiedLrcLibrary(force=force) }.getOrDefault(repo.cachedUnifiedLrcEntries())
            }
            loading = false
            status = "Varredura concluída • ${entries.size} LRC disponíveis."
        }
    }

    LaunchedEffect(Unit) { refreshLibrary(force=false) }
    val filtered = remember(entries, query) {
        val q = query.trim()
        if (q.isBlank()) entries else entries.filter { it.title.contains(q,true) || it.artist.contains(q,true) || it.publicFile?.name.orEmpty().contains(q,true) }
    }

    Column(Modifier.fillMaxSize().padding(horizontal=16.dp)) {
        PageHeader("Letras sincronizadas", onBack)
        OutlinedTextField(query,{query=it},modifier=Modifier.fillMaxWidth(),singleLine=true,label={Text("Buscar música ou artista")},leadingIcon={Icon(Icons.Default.Search,null)})
        Spacer(Modifier.height(7.dp))
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            FilledTonalButton(onClick={refreshLibrary(force=true)},enabled=!loading,modifier=Modifier.weight(1f)) {
                Icon(Icons.Default.Refresh,null); Spacer(Modifier.width(5.dp)); Text("Atualizar")
            }
            FilledTonalButton(onClick={saveAll.launch("SONUS_Letras_Sincronizadas.zip")},enabled=!loading && entries.isNotEmpty(),modifier=Modifier.weight(1f)) {
                Icon(Icons.Default.Download,null); Spacer(Modifier.width(5.dp)); Text("Baixar todas")
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("${entries.size} letras disponíveis • ${filtered.size} exibidas",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.60f))
        status?.let { Text(it,style=MaterialTheme.typography.labelSmall,color=Color(0xFF54E3A8),modifier=Modifier.padding(top=4.dp)) }
        if (loading) {
            LinearProgressIndicator(progress={if(bulkProgress>0f)bulkProgress else 0.05f},modifier=Modifier.fillMaxWidth().padding(top=7.dp))
            if (bulkProgress > 0f) TextButton(onClick={bulkCancelRequested=true},modifier=Modifier.align(Alignment.End)){Text("Cancelar exportação")}
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(8.dp),contentPadding=PaddingValues(bottom=30.dp)) {
            items(filtered,key={it.key}) { entry ->
                Surface(shape=RoundedCornerShape(16.dp),color=Color(0xFF0B0D12),border=BorderStroke(1.dp,Color.White.copy(alpha=.10f))) {
                    Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically) {
                        Surface(shape=RoundedCornerShape(12.dp),color=Color.White.copy(alpha=.07f)) { Icon(Icons.Default.Lyrics,null,tint=Color.White,modifier=Modifier.padding(10.dp).size(21.dp)) }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(entry.title,fontWeight=FontWeight.Bold,color=Color.White,maxLines=1,overflow=TextOverflow.Ellipsis)
                            Text(entry.artist.ifBlank{"Artista não identificado"},fontSize=10.sp,color=Color.White.copy(alpha=.58f),maxLines=1,overflow=TextOverflow.Ellipsis)
                            Text("LRC sincronizado",fontSize=9.sp,color=Color(0xFF54E3A8))
                        }
                        IconButton(onClick=onOpenEditor,enabled=!loading) { Icon(Icons.Default.EditNote,"Abrir Editor LRC",tint=Color.White.copy(alpha=.82f)) }
                        IconButton(onClick={pendingDownload=entry;saveOne.launch(developerLrcFileName(entry))},enabled=!loading) { Icon(Icons.Default.Download,"Baixar LRC",tint=Color.White) }
                    }
                }
            }
        }
    }
}

@Composable
private fun DeveloperSectionHero(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, tint: Color, modifier: Modifier = Modifier) {
    Surface(modifier=modifier,shape=RoundedCornerShape(22.dp), color=tint.copy(alpha=.11f), border=BorderStroke(1.dp,tint.copy(alpha=.34f))) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment=Alignment.CenterVertically) {
            Surface(shape=RoundedCornerShape(15.dp),color=tint.copy(alpha=.16f)) { Icon(icon,null,tint=tint,modifier=Modifier.padding(12.dp).size(26.dp)) }
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) { Text(title,fontWeight=FontWeight.ExtraBold,fontSize=20.sp); Text(subtitle,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.62f)) }
        }
    }
}

@Composable
private fun DeveloperSummaryTile(modifier: Modifier, value: String, label: String, tint: Color) {
    Surface(modifier,shape=RoundedCornerShape(16.dp),color=tint.copy(alpha=.10f),border=BorderStroke(1.dp,tint.copy(alpha=.26f))) {
        Column(Modifier.padding(vertical=12.dp,horizontal=7.dp),horizontalAlignment=Alignment.CenterHorizontally) { Text(value,fontWeight=FontWeight.Black,fontSize=17.sp,maxLines=1); Text(label,fontSize=9.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.58f)) }
    }
}

@Composable
private fun OwnerDeveloperCard(authUser: AuthUser, uidPreview: String, onRefreshRole: () -> Unit) {
    Surface(shape=RoundedCornerShape(22.dp),color=Color(0xFF12243C).copy(alpha=.96f),border=BorderStroke(1.dp,Color(0xFF79BFFF).copy(alpha=.52f))) {
        Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment=Alignment.CenterVertically) {
                Surface(shape=CircleShape,color=Color(0xFF79BFFF).copy(alpha=.16f)) { Icon(Icons.Default.AdminPanelSettings,null,tint=Color(0xFFA6D3FF),modifier=Modifier.padding(10.dp).size(25.dp)) }
                Spacer(Modifier.width(11.dp)); Column(Modifier.weight(1f)){Text("OWNER verificado",color=Color.White,fontWeight=FontWeight.ExtraBold,fontSize=18.sp);Text("Autorização remota ativa",color=SignalGreen,style=MaterialTheme.typography.bodySmall,fontWeight=FontWeight.Bold)};OwnerStatusPill()
            }
            Text(authUser.email ?: "Conta autenticada",color=Color.White.copy(alpha=.74f),style=MaterialTheme.typography.bodySmall)
            Text("UID: $uidPreview",color=Color.White.copy(alpha=.52f),style=MaterialTheme.typography.labelSmall)
            OutlinedButton(onClick=onRefreshRole,modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Refresh,null,modifier=Modifier.size(18.dp));Spacer(Modifier.width(7.dp));Text("Verificar autorização novamente")}
        }
    }
}

@Composable
private fun DeveloperBuildDeviceCard() {
    val codecInfos = remember { runCatching { MediaCodecList(MediaCodecList.ALL_CODECS).codecInfos.toList() }.getOrDefault(emptyList()) }
    val encoders = codecInfos.filter { it.isEncoder }
    val h264 = encoders.any { info -> info.supportedTypes.any { it.equals("video/avc", true) } }
    val hevc = encoders.any { info -> info.supportedTypes.any { it.equals("video/hevc", true) } }
    val av1 = encoders.any { info -> info.supportedTypes.any { it.equals("video/av01", true) } }
    Surface(shape=RoundedCornerShape(20.dp),color=Color(0xFF12243C).copy(alpha=.82f),border=BorderStroke(1.dp,Color(0xFF79BFFF).copy(alpha=.25f))) {
        Column(Modifier.padding(15.dp),verticalArrangement=Arrangement.spacedBy(7.dp)) {
            Text("Build e dispositivo",fontWeight=FontWeight.ExtraBold,color=Color.White)
            Text("SONUS ${BuildConfig.VERSION_NAME} • code ${BuildConfig.VERSION_CODE}",color=Color.White.copy(.78f))
            Text("${Build.MANUFACTURER} ${Build.MODEL} • Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",color=Color.White.copy(.65f),style=MaterialTheme.typography.bodySmall)
            Text("ABI: ${Build.SUPPORTED_ABIS.joinToString()} • RAM/armazenamento conforme Android",color=Color.White.copy(.55f),style=MaterialTheme.typography.labelSmall)
            Text("Encoders: H.264 ${if(h264) "✓" else "—"} • HEVC ${if(hevc) "✓" else "—"} • AV1 ${if(av1) "✓" else "—"}",color=SignalGreen,fontWeight=FontWeight.Bold,style=MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun DeveloperMediaDiagnosticCard() {
    Surface(shape=RoundedCornerShape(20.dp),color=Color(0xFF211B33).copy(alpha=.72f),border=BorderStroke(1.dp,Color(0xFFB694FF).copy(alpha=.25f))) {
        Column(Modifier.padding(15.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
            Text("Ferramentas de diagnóstico",fontWeight=FontWeight.ExtraBold,color=Color.White)
            Text("Preview",color=Color(0xFFC9B3FF),fontWeight=FontWeight.Bold); Text("FPS • tempo de frame • compatibilidade de codec",color=Color.White.copy(.72f),style=MaterialTheme.typography.bodySmall)
            Text("Áudio",color=Color(0xFFC9B3FF),fontWeight=FontWeight.Bold); Text("sessão • sample rate • FFT • reprodução",color=Color.White.copy(.72f),style=MaterialTheme.typography.bodySmall)
            Text("Exportação",color=Color(0xFFC9B3FF),fontWeight=FontWeight.Bold); Text("resolução • codec • FPS • bitrate • duração • validação final",color=Color.White.copy(.72f),style=MaterialTheme.typography.bodySmall)
            Text("Spectrum atual: ${PulsePlayerService.lastSpectrumEngine}",color=Color.White.copy(.72f),style=MaterialTheme.typography.bodySmall)
            Text("Compatibilidade: Native → PCM Compat → Fallback",color=Color.White.copy(.72f),style=MaterialTheme.typography.bodySmall)
            Text("Logs e feature flags permanecem isolados do usuário comum.",color=SignalYellow,style=MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun DeveloperMonetizationCard(adManager: StreamPulseAdManager, testMode: OwnerTestMode) {
    val context = LocalContext.current
    val ready by adManager.ready.collectAsState()
    val rewardedReady by adManager.rewardedReady.collectAsState()
    val rewardedLoading by adManager.rewardedLoading.collectAsState()
    val canRequestAds by adManager.canRequestAds.collectAsState()
    val umpStatus by adManager.umpStatus.collectAsState()
    val metrics by adManager.metrics.collectAsState()
    Surface(shape=RoundedCornerShape(22.dp),color=Color(0xFF2C2410).copy(alpha=.82f),border=BorderStroke(1.dp,Color(0xFFFFC857).copy(alpha=.30f))) {
        Column(Modifier.fillMaxWidth().padding(15.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment=Alignment.CenterVertically) {
                Icon(Icons.Default.Paid,null,tint=Color(0xFFFFC857));Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)){Text("AdMob • ${adManager.environmentLabel}",fontWeight=FontWeight.Black);Text(if(ready)"SDK pronto" else "Aguardando consentimento/SDK",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.58f))}
                AssistChip(onClick={},label={Text(if(adManager.productionMode)"PRODUÇÃO" else "TESTE")})
            }
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                DeveloperSummaryTile(Modifier.weight(1f),if(rewardedReady)"OK" else "…","Rewarded",if(rewardedReady)SignalGreen else SignalYellow)
                DeveloperSummaryTile(Modifier.weight(1f),metrics.rewardsGranted.toString(),"recompensas",SignalGreen)
                DeveloperSummaryTile(Modifier.weight(1f),metrics.failures.toString(),"falhas",if(metrics.failures==0L)SignalGreen else Color(0xFFFF8A80))
            }
            Text("code103: anúncios foram removidos do Player e do SONUS Stream. Rewarded Ads existem somente para desbloqueios das ferramentas PRO quando o usuário opta por anúncio/está sem moedas.",style=MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                OutlinedButton(onClick={adManager.refreshAds()},modifier=Modifier.weight(1f)){Icon(Icons.Default.Refresh,null);Spacer(Modifier.width(4.dp));Text("Atualizar")}
                OutlinedButton(onClick={
                    val activity=context.findComponentActivityForApp()
                    if(activity!=null)adManager.showRewarded(
                        activity = activity,
                        ownerOrAdFree = false,
                        forceTestUnit = true,
                        onReward = { Toast.makeText(context,"Rewarded OK • teste sem alterar saldo",Toast.LENGTH_SHORT).show() },
                        onUnavailable = { Toast.makeText(context,it,Toast.LENGTH_SHORT).show() }
                    )
                },enabled=ready,modifier=Modifier.weight(1f)){Text("Testar Rewarded")}
            }
            Text("UMP: $umpStatus",fontSize=10.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.68f))
            Text("canRequestAds: ${if(canRequestAds) "SIM" else "NÃO"} • Rewarded: ${when { rewardedReady -> "PRONTO"; rewardedLoading -> "CARREGANDO"; else -> "AGUARDANDO" }}",fontSize=10.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.68f))
            Text("Solicitações: ${metrics.rewardedRequests} • impressões: ${metrics.rewardedImpressions} • recompensas: ${metrics.rewardsGranted}",fontSize=10.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.62f))
            metrics.lastError?.let{Text("Último erro: $it",fontSize=9.sp,color=Color(0xFFFF9A9A))}
            if(metrics.lastErrorCode!=null || !metrics.lastErrorDomain.isNullOrBlank()) Text("Código: ${metrics.lastErrorCode ?: "-"} • domínio: ${metrics.lastErrorDomain ?: "-"}",fontSize=9.sp,color=Color(0xFFFFB3B3))
            metrics.lastErrorMessage?.let{Text("Mensagem: $it",fontSize=9.sp,color=Color(0xFFFFB3B3))}
            metrics.lastResponseInfo?.let{Text("ResponseInfo: $it",fontSize=8.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.52f),maxLines=4,overflow=TextOverflow.Ellipsis)}
            Text("OWNER em simulação FREE usa sempre a unidade oficial de teste do Google; usuários FREE reais continuam no Rewarded de produção.",fontSize=9.sp,color=Color(0xFFFFD77A))
            Text("Modo OWNER simulado: ${testMode.name}. IDs reais nunca são exibidos neste painel.",fontSize=9.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.52f))
        }
    }
}

@Composable
private fun SettingsScreen(
    state: AppState,
    selectedArtist: Artist,
    membershipTier: MembershipTier,
    authUser: AuthUser,
    isGuest: Boolean,
    isOwner: Boolean,
    isSupport: Boolean,
    ownerTestMode: OwnerTestMode,
    repository: AppRepository,
    authManager: AuthManager,
    cloudManager: CloudAccountManager,
    adManager: StreamPulseAdManager,
    onGuestLogin: () -> Unit,
    onDeveloper: () -> Unit,
    onSupport: () -> Unit,
    onStreamCreator: () -> Unit,
    onOrganizeTabs: () -> Unit,
    onSelect: (String) -> Unit,
    onAddArtist: () -> Unit,
    onEditArtist: (String) -> Unit,
    onArtistUpdate: (Artist) -> Unit,
    onDeleteArtist: (String) -> Unit,
    onRestoreState: (AppState) -> Unit,
    onPreferencesChange: (UserPreferences) -> Unit,
    onDistributors: () -> Unit,
    onDistributionHub: () -> Unit,
    onPremium: () -> Unit,
    onUsage: () -> Unit,
    onNotificationCenter: () -> Unit,
    onNotificationSettings: () -> Unit,
    onCheckUpdate: () -> Unit,
    unreadNotifications: Int,
    onSignOut: () -> Unit,
    onReset: () -> Unit
) {
    var confirmReset by remember { mutableStateOf(false) }
    var confirmSignOut by remember { mutableStateOf(false) }
    var menuArtistId by remember { mutableStateOf<String?>(null) }
    var confirmDeleteArtistId by remember { mutableStateOf<String?>(null) }
    var showThemeDialog by remember { mutableStateOf(false) }
    var showFontDialog by remember { mutableStateOf(false) }
    var showTextAppearanceDialog by remember { mutableStateOf(false) }
    var showAppIconDialog by remember { mutableStateOf(false) }
    val themeScrollState = rememberLazyListState()
    val fontScrollState = rememberLazyListState()
    val textAppearanceScrollState = rememberLazyListState()
    var showGoalDialog by remember { mutableStateOf(false) }
    var backupPreview by remember { mutableStateOf<BackupPreview?>(null) }
    var backupMessage by remember { mutableStateOf<String?>(null) }
    var backgroundPhotoMessage by remember { mutableStateOf<String?>(null) }
    var lastBackupUriString by rememberSaveable { mutableStateOf<String?>(null) }
    var showAbout by remember { mutableStateOf(false) }
    var showAccountDialog by remember { mutableStateOf(false) }

    val prefs = state.preferences
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val camaleonPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) onPreferencesChange(prefs.copy(themeMode = ThemeMode.CAMALEON))
    }
    val sortedArtists = state.artists.sortedBy { it.name.lowercase(Locale.getDefault()) }
    val menuArtist = menuArtistId?.let { id -> state.artists.firstOrNull { it.id == id } }

    // Launchers de backup preservados do fluxo funcional anterior.
    // O code80 reorganizou Ajustes, mas estes callbacks ainda são usados na seção Backup e Restauração.
    val backupCreateLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) {
            scope.launch {
                backupMessage = "Criando backup..."
                val result = withContext(Dispatchers.IO) { BackupManager.writeBackup(context, uri, state, BuildConfig.VERSION_NAME) }
                if (result.isSuccess) {
                    lastBackupUriString = uri.toString()
                    backupMessage = "Backup criado com sucesso"
                    SonusNotificationCenter.add(
                        context,
                        "Backup concluído",
                        "Seu backup local foi criado com sucesso.",
                        "BACKUP",
                        importantExternal = false
                    )
                } else {
                    backupMessage = "Falha ao criar backup"
                    SonusNotificationCenter.add(
                        context,
                        "Falha no backup",
                        "Não foi possível criar o arquivo de backup. Seus dados atuais não foram alterados.",
                        "BACKUP",
                        importantExternal = true
                    )
                }
                delay(1500)
                backupMessage = null
            }
        }
    }

    val backupOpenLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                backupMessage = "Lendo backup..."
                val result = withContext(Dispatchers.IO) { BackupManager.readBackup(context, uri) }
                backupMessage = null
                if (result.isSuccess) backupPreview = result.getOrNull()
                else {
                    backupMessage = "Arquivo de backup inválido"
                    SonusNotificationCenter.add(
                        context,
                        "Backup não pôde ser lido",
                        "O arquivo selecionado não parece ser um backup válido do SONUS.",
                        "BACKUP",
                        importantExternal = true
                    )
                    delay(1600)
                    backupMessage = null
                }
            }
        }
    }

    if (showAccountDialog) {
        AlertDialog(
            onDismissRequest = { showAccountDialog = false },
            title = { Text("Conta SONUS", fontWeight = FontWeight.ExtraBold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        AuthProfileAvatar(authUser.photoUrl)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                authUser.displayName?.takeIf { it.isNotBlank() }
                                    ?: authUser.email?.substringBefore('@')
                                    ?: "Conta SONUS",
                                fontWeight = FontWeight.ExtraBold
                            )
                            Text(authUser.email ?: "Conta autenticada", style = MaterialTheme.typography.bodySmall, maxLines = 1)
                            Spacer(Modifier.height(5.dp))
                            if (isOwner) OwnerStatusPill() else PlanStatusPill(membershipTier)
                        }
                    }
                    HorizontalDivider()
                    Text("Sua sessão está protegida e vinculada à conta atual.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha=.62f))
                    if (!isGuest && authUser.uid.isNotBlank()) {
                        val publicId = sonusPublicId(authUser.uid)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("ID do usuário", style = MaterialTheme.typography.labelSmall)
                                Text(publicId, fontWeight = FontWeight.ExtraBold)
                            }
                            IconButton(onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                clipboard.setPrimaryClip(ClipData.newPlainText("ID SONUS", publicId))
                                Toast.makeText(context, "ID SONUS copiado", Toast.LENGTH_SHORT).show()
                            }) { Icon(Icons.Default.ContentCopy, "Copiar ID") }
                        }
                    }
                    if (isOwner && ownerTestMode != OwnerTestMode.OWNER) {
                        Text("Modo de teste: ${ownerTestMode.name}", fontWeight = FontWeight.Bold, color = SignalYellow)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAccountDialog = false; confirmSignOut = true }) { Text("Sair da conta") }
            },
            dismissButton = { TextButton(onClick = { showAccountDialog = false }) { Text("Fechar") } }
        )
    }

    if (showAppIconDialog) {
        var selectedIconId by remember(showAppIconDialog) { mutableStateOf(AppIconCatalog.selectedId(context)) }
        AlertDialog(
            onDismissRequest = { showAppIconDialog = false },
            title = { Text("Ícone do SONUS", fontWeight = FontWeight.ExtraBold) },
            text = {
                LazyColumn(
                    modifier = Modifier.heightIn(max = 520.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item { Text("Personalização não consome Moedas SONUS. Cada selo mostra o plano necessário.", style = MaterialTheme.typography.bodySmall) }
                    items(AppIconCatalog.icons) { icon ->
                        val unlocked = isOwner || membershipTier.ordinal >= icon.tier.ordinal
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = if (selectedIconId == icon.id) MaterialTheme.colorScheme.primaryContainer.copy(alpha=.52f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.34f),
                            border = BorderStroke(1.dp, if(selectedIconId==icon.id) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha=.14f)),
                            modifier = Modifier.fillMaxWidth().clickable(enabled=unlocked) {
                                AppIconCatalog.apply(context, icon).onSuccess { selectedIconId = icon.id }
                            }
                        ) {
                            Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Image(painterResource(icon.previewRes), null, Modifier.size(54.dp).clip(RoundedCornerShape(13.dp)))
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(icon.title, fontWeight = FontWeight.Bold)
                                    Text(icon.tier.name, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                }
                                Icon(if(unlocked){if(selectedIconId==icon.id)Icons.Default.CheckCircle else Icons.Default.ChevronRight}else Icons.Default.Lock,null)
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick={showAppIconDialog=false}){Text("Fechar")} }
        )
    }

    if (showAbout) {
        AlertDialog(
            onDismissRequest = { showAbout = false },
            title = { Text("Sobre o SONUS", fontWeight = FontWeight.ExtraBold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "SONUS ${BuildConfig.VERSION_NAME}",
                        fontWeight = FontWeight.Black,
                        fontSize = 20.sp
                    )
                    Text(
                        "Versão ${BuildConfig.VERSION_NAME} • code${BuildConfig.VERSION_CODE}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                    HorizontalDivider()
                    Text("Novidades desta versão", fontWeight = FontWeight.ExtraBold)
                    SONUS_CURRENT_VERSION_SUMMARY.forEach { item ->
                        Text("• $item", style = MaterialTheme.typography.bodySmall)
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showAbout = false }) { Text("Fechar") } }
        )
    }

    if (showThemeDialog) {
        val themes = ThemeMode.entries.filterNot { it == ThemeMode.SYSTEM || it == ThemeMode.PHOTO }
        AlertDialog(
            onDismissRequest = { showThemeDialog = false },
            title = {
                Column {
                    Text("Temas")
                    Text("Temas seguem os níveis Grátis, Prata, Ouro e Diamante", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .58f))
                }
            },
            text = {
                LazyColumn(
                    state = themeScrollState,
                    modifier = Modifier.heightIn(max = 520.dp),
                    verticalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    items(themes, key = { it.name }) { mode ->
                        val required = themeRequiredTier(mode)
                        val unlocked = isOwner || required == null || membershipTier.ordinal >= required.ordinal
                        Surface(
                            modifier = Modifier.fillMaxWidth().clickable(enabled = unlocked) {
                                if (mode == ThemeMode.CAMALEON && androidx.core.content.ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                                    camaleonPermissionLauncher.launch(Manifest.permission.CAMERA)
                                } else {
                                    onPreferencesChange(prefs.copy(themeMode = mode))
                                }
                            },
                            shape = RoundedCornerShape(16.dp),
                            color = if (prefs.themeMode == mode) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    Modifier.size(29.dp)
                                        .clip(CircleShape)
                                        .background(Brush.linearGradient(themePreviewColors(mode)))
                                        .border(1.dp, Color.White.copy(alpha = .25f), CircleShape)
                                )
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(themeLabel(mode), fontWeight = FontWeight.SemiBold)
                                    Text(themeDescription(mode), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .55f), maxLines = 1)
                                }
                                required?.let { PremiumFeatureMark(it) }
                                if (!unlocked) { Spacer(Modifier.width(6.dp)); Icon(Icons.Default.Lock, "Bloqueado") }
                                else if (prefs.themeMode == mode) { Spacer(Modifier.width(6.dp)); Icon(Icons.Default.CheckCircle, null) }
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showThemeDialog = false }) { Text("Fechar") } }
        )
    }

    if (showFontDialog) {
        AlertDialog(
            onDismissRequest = { showFontDialog = false },
            title = {
                Column {
                    Text("Fontes")
                    Text("Escolha um estilo • fontes seguem o nível do seu plano", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .58f))
                }
            },
            text = {
                LazyColumn(state = fontScrollState, modifier = Modifier.heightIn(max = 520.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    items(AppFont.entries, key = { it.name }) { font ->
                        val required = fontRequiredTier(font)
                        val unlocked = isOwner || required == null || membershipTier.ordinal >= required.ordinal
                        Surface(
                            modifier = Modifier.fillMaxWidth().clickable(enabled = unlocked) {
                                onPreferencesChange(prefs.copy(appFont = font))
                            },
                            shape = RoundedCornerShape(16.dp),
                            color = if (prefs.appFont == font) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(fontLabel(font), fontWeight = FontWeight.SemiBold)
                                    Text("SONUS 123", fontFamily = fontPreviewFamily(font), fontSize = 14.sp)
                                }
                                required?.let { PremiumFeatureMark(it) }
                                if (!unlocked) { Spacer(Modifier.width(8.dp)); Icon(Icons.Default.Lock, "Bloqueado") }
                                else if (prefs.appFont == font) { Spacer(Modifier.width(8.dp)); Icon(Icons.Default.CheckCircle, null) }
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showFontDialog = false }) { Text("Fechar") } }
        )
    }

    if (showTextAppearanceDialog) {
        AlertDialog(
            onDismissRequest = { showTextAppearanceDialog = false },
            title = { Column { Text("Cor e estilo do texto"); Text("Gratuito • a alteração é aplicada sem fechar esta tela", style = MaterialTheme.typography.bodySmall) } },
            text = {
                LazyColumn(state = textAppearanceScrollState, modifier = Modifier.heightIn(max = 520.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    items(TextAppearance.entries, key = { it.name }) { appearance ->
                        Surface(
                            modifier = Modifier.fillMaxWidth().clickable { onPreferencesChange(prefs.copy(textAppearance = appearance)) },
                            shape = RoundedCornerShape(16.dp),
                            color = if (prefs.textAppearance == appearance) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(textAppearanceLabel(appearance), fontWeight = FontWeight.SemiBold)
                                    Text(textAppearanceExample(appearance), style = MaterialTheme.typography.bodySmall)
                                }
                                if (prefs.textAppearance == appearance) Icon(Icons.Default.CheckCircle, null)
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showTextAppearanceDialog = false }) { Text("Fechar") } }
        )
    }

    val preview = backupPreview
    if (preview != null) {
        AlertDialog(
            onDismissRequest = { backupPreview = null },
            title = { Text("Restaurar backup?") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("Criado: ${preview.manifest.createdAtIso.replace('T', ' ').take(16)}")
                    Text("Versão: ${preview.manifest.appVersion}")
                    Text("Artistas: ${preview.manifest.artists}")
                    Text("Atualizações: ${preview.manifest.snapshots}")
                    Text("Registros diários: ${preview.manifest.dailyRecords}")
                    Text("Pagamentos: ${preview.manifest.payments}")
                    Text("Fotos: ${preview.manifest.photos}")
                    Spacer(Modifier.height(5.dp))
                    Text("Os dados atuais deste aparelho serão substituídos pelos dados do backup.", color = SignalOrange)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        backupMessage = "Restaurando dados..."
                        val result = withContext(Dispatchers.IO) { BackupManager.prepareRestoredState(context, preview) }
                        if (result.isSuccess) {
                            result.getOrNull()?.let(onRestoreState)
                            backupMessage = "Backup restaurado"
                            SonusNotificationCenter.add(
                                context,
                                "Backup restaurado",
                                "Os dados do backup foram restaurados com sucesso.",
                                "BACKUP",
                                importantExternal = false
                            )
                        } else {
                            backupMessage = "Não foi possível restaurar"
                            SonusNotificationCenter.add(
                                context,
                                "Falha ao restaurar backup",
                                "O SONUS não conseguiu concluir a restauração. Os dados atuais foram preservados.",
                                "BACKUP",
                                importantExternal = true
                            )
                        }
                        backupPreview = null
                        delay(1500)
                        backupMessage = null
                    }
                }) { Text("Restaurar") }
            },
            dismissButton = { TextButton(onClick = { backupPreview = null }) { Text("Cancelar") } }
        )
    }

    if (showGoalDialog) {
        GoalDialog(
            currentGoalBrl = selectedArtist.goalBrl,
            currentGoalStreams = selectedArtist.goalStreams,
            onDismiss = { showGoalDialog = false },
            onSave = { goalBrl, goalStreams ->
                onArtistUpdate(selectedArtist.copy(goalBrl = goalBrl, goalStreams = goalStreams))
                showGoalDialog = false
            }
        )
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Apagar todos os dados?") },
            text = { Text("Essa ação remove artistas, histórico de streams, pagamentos e preferências deste aparelho.") },
            confirmButton = { TextButton(onClick = { confirmReset = false; onReset() }) { Text("Apagar") } },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Cancelar") } }
        )
    }

    if (confirmSignOut) {
        AlertDialog(
            onDismissRequest = { confirmSignOut = false },
            title = { Text("Sair da conta?") },
            text = { Text("Sua sessão será encerrada. Os artistas, históricos e configurações locais deste aparelho não serão apagados.") },
            confirmButton = {
                TextButton(onClick = { confirmSignOut = false; onSignOut() }) { Text("Sair") }
            },
            dismissButton = { TextButton(onClick = { confirmSignOut = false }) { Text("Cancelar") } }
        )
    }



    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(9.dp),
        contentPadding = PaddingValues(top = 15.dp, bottom = 32.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Ajustes", fontSize = 27.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                BadgedBox(badge = {
                    if (unreadNotifications > 0) Badge(containerColor = Color(0xFFD6A72F)) { Text(if (unreadNotifications > 99) "99+" else unreadNotifications.toString(), color = Color.White, fontWeight = FontWeight.Black) }
                }) {
                    IconButton(onClick = onNotificationCenter) {
                        Image(painter = painterResource(R.drawable.sonus_notification_bell), contentDescription = "Notificações", modifier = Modifier.size(30.dp))
                    }
                }
            }
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (isOwner) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        SettingsHubTile(
                            icon = Icons.Default.AccountCircle,
                            title = "Conta",
                            subtitle = authUser.displayName?.takeIf { it.isNotBlank() } ?: authUser.email?.substringBefore('@') ?: "SONUS",
                            accent = Color(0xFF69A2FF),
                            containerColor = Color(0xFF164D95).copy(alpha = .34f),
                            modifier = Modifier.weight(1f),
                            avatarUrl = authUser.photoUrl,
                            onClick = { showAccountDialog = true }
                        )
                        SettingsHubTile(
                            icon = Icons.Default.AdminPanelSettings,
                            title = "Desenvolvedor",
                            subtitle = if (ownerTestMode == OwnerTestMode.OWNER) "OWNER" else "Teste ${ownerTestMode.name}",
                            accent = Color(0xFFC9EEFF),
                            containerColor = Color(0xFF9EDCFF).copy(alpha = .16f),
                            modifier = Modifier.weight(1f),
                            onClick = onDeveloper
                        )
                        SettingsHubTile(
                            icon = Icons.Default.WorkspacePremium,
                            title = "Premium",
                            subtitle = "Acesso completo",
                            accent = Color(0xFFFFD15A),
                            containerColor = Color(0xFF9A6500).copy(alpha = .24f),
                            modifier = Modifier.weight(1f),
                            onClick = onPremium
                        )
                    }
                    SettingsHubTile(
                        icon = Icons.Default.Timer,
                        title = "Uso do app",
                        subtitle = "Estatísticas locais",
                        accent = Color(0xFFFF737B),
                        containerColor = Color(0xFF8B1F31).copy(alpha = .24f),
                        modifier = Modifier.fillMaxWidth(),
                        wide = true,
                        onClick = onUsage
                    )
                } else {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        SettingsHubTile(
                            icon = Icons.Default.AccountCircle,
                            title = "Conta",
                            subtitle = if (isGuest) "Convidado" else authUser.displayName?.takeIf { it.isNotBlank() } ?: "SONUS",
                            accent = Color(0xFF69A2FF),
                            containerColor = Color(0xFF164D95).copy(alpha = .34f),
                            modifier = Modifier.weight(1f),
                            avatarUrl = if (isGuest) null else authUser.photoUrl,
                            onClick = { if (isGuest) onGuestLogin() else showAccountDialog = true }
                        )
                        SettingsHubTile(
                            icon = Icons.Default.WorkspacePremium,
                            title = "Premium",
                            subtitle = membershipLabel(membershipTier),
                            accent = Color(0xFFFFD15A),
                            containerColor = Color(0xFF9A6500).copy(alpha = .24f),
                            modifier = Modifier.weight(1f),
                            onClick = onPremium
                        )
                        SettingsHubTile(
                            icon = Icons.Default.Timer,
                            title = "Uso do app",
                            subtitle = "Estatísticas",
                            accent = Color(0xFFFF737B),
                            containerColor = Color(0xFF8B1F31).copy(alpha = .24f),
                            modifier = Modifier.weight(1f),
                            onClick = onUsage
                        )
                    }
                }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SettingsHubTile(
                        icon = Icons.Default.Notifications,
                        title = "Notificações",
                        subtitle = "Central SONUS",
                        accent = Color(0xFF8DD7FF),
                        containerColor = Color(0xFF12344A).copy(alpha = .42f),
                        modifier = Modifier.weight(1f),
                        onClick = onNotificationSettings
                    )
                }
            }
        }

        item {
            CompactSettingsCard {
                SettingsNavRow(Icons.Default.SupportAgent, if (isSupport || isOwner) "Suporte SONUS" else "Fale Conosco", if (isSupport || isOwner) "Atendimentos e diagnósticos" else "Ajuda, Premium e problemas técnicos", onClick = onSupport)
                SettingsDivider()
            }
        }

        item { SettingsSectionTitle("Recursos para Artistas") }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                ArtistResourceSettingsCard(
                    icon = Icons.Default.Payments,
                    title = "Distribuição & Pagamentos",
                    description = "Saldo, financeiro, previsões e histórico de distribuição.",
                    enabled = prefs.artistResourcesDistributionEnabled,
                    pinned = prefs.artistResourcesDistributionPinned,
                    accent = Color(0xFFFFC857),
                    pro = true,
                    locked = false,
                    onLockedClick = onDistributionHub,
                    onEnabledChange = { enabled ->
                        onPreferencesChange(
                            prefs.copy(
                                artistResourcesDistributionEnabled = enabled,
                                artistResourcesDistributionPinned = if (enabled) prefs.artistResourcesDistributionPinned else false
                            )
                        )
                    },
                    onPinnedChange = { pinned ->
                        onPreferencesChange(prefs.copy(artistResourcesDistributionPinned = pinned))
                    },
                    onOpen = onDistributionHub
                )
            }
        }


        item { SettingsSectionTitle("Personalização") }
        item {
            CompactSettingsCard {
                SettingsNavRow(Icons.Default.ViewWeek, "Organizar abas principais", "Escolher, ocultar e reordenar atalhos", onClick = onOrganizeTabs)
                SettingsDivider()
                SettingsNavRow(Icons.Default.ColorLens, "Tema", themeLabel(prefs.themeMode), onClick = { showThemeDialog = true })
                SettingsDivider()
                SettingsNavRow(Icons.Default.TextFields, "Fonte", fontLabel(prefs.appFont), onClick = { showFontDialog = true })
                SettingsDivider()
                SettingsNavRow(Icons.Default.FormatColorText, "Cor do texto", textAppearanceLabel(prefs.textAppearance), onClick = { showTextAppearanceDialog = true })
                SettingsDivider()
                SettingsNavRow(
                    Icons.Default.Apps,
                    "Ícone do aplicativo",
                    AppIconCatalog.icons.firstOrNull { it.id == AppIconCatalog.selectedId(context) }?.title ?: "Azul clássico",
                    onClick = { showAppIconDialog = true }
                )
            }
        }

        item { SettingsSectionTitle("Monitor de uso de dados") }
        item {
            CompactSettingsCard {
                SettingsToggleRow(
                    Icons.Default.DataUsage,
                    "Monitor de uso de dados",
                    "Mostra consumo aproximado nas funções online",
                    prefs.showDataUsageMonitor
                ) { onPreferencesChange(prefs.copy(showDataUsageMonitor = it)) }
                if (prefs.showDataUsageMonitor) {
                    SettingsDivider()
                    SettingsToggleRow(
                        Icons.Default.CellTower,
                        "Avisar em dados móveis",
                        "Alerta quando uma sessão online ultrapassar seu limite",
                        prefs.warnOnMobileData
                    ) { onPreferencesChange(prefs.copy(warnOnMobileData = it)) }
                    SettingsDivider()
                    Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text("Limite do alerta móvel", fontWeight = FontWeight.SemiBold)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(25, 50, 100, 250).forEach { mb ->
                                FilterChip(
                                    selected = prefs.mobileDataWarningMb == mb,
                                    onClick = { onPreferencesChange(prefs.copy(mobileDataWarningMb = mb)) },
                                    label = { Text("$mb MB", fontSize = 10.sp) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }

                }
            }
        }

        item { SettingsSectionTitle("Assinatura tátil SONUS") }
        item {
            CompactSettingsCard {
                SettingsToggleRow(
                    Icons.Default.Vibration,
                    "Assinatura tátil SONUS",
                    "Feedback curto e consistente para ações, confirmações e alertas",
                    prefs.hapticsEnabled
                ) { onPreferencesChange(prefs.copy(hapticsEnabled = it)) }
                if (prefs.hapticsEnabled) {
                    SettingsDivider()
                    Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text("Intensidade", fontWeight = FontWeight.SemiBold)
                        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            listOf(0 to "Suave", 1 to "Média", 2 to "Forte").forEach { (value, label) ->
                                FilterChip(
                                    selected = prefs.hapticsIntensity == value,
                                    onClick = { onPreferencesChange(prefs.copy(hapticsIntensity = value)) },
                                    label = { Text(label) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                    SettingsDivider()
                    SettingsToggleRow(Icons.Default.Headphones, "Player", "Gestos e ações importantes do SONUS PLAYER", prefs.hapticsPlayer) {
                        onPreferencesChange(prefs.copy(hapticsPlayer = it))
                    }
                    SettingsDivider()
                    SettingsToggleRow(Icons.Default.Build, "Ferramentas", "Confirmações e ações dos mini apps", prefs.hapticsTools) {
                        onPreferencesChange(prefs.copy(hapticsTools = it))
                    }
                    SettingsDivider()
                    SettingsToggleRow(Icons.Default.Tune, "SONUS TUNE", "Confirma uma única vez quando a corda entra afinada", prefs.hapticsTuner) {
                        onPreferencesChange(prefs.copy(hapticsTuner = it))
                    }
                }
            }
        }

        item { SettingsSectionTitle("Código promocional") }
        item {
            if (isGuest) {
                CompactSettingsCard {
                    SettingsNavRow(
                        Icons.Default.LocalOffer,
                        "Código promocional",
                        "Entre na sua conta para aplicar benefícios",
                        onClick = onGuestLogin
                    )
                }
            } else {
                CloudCouponSettings(
                    state = state,
                    authUser = authUser,
                    repository = repository
                )
            }
        }

        item { SettingsSectionTitle("Análises") }
        item {
            CompactSettingsCard {
                Column(Modifier.padding(horizontal = 14.dp, vertical = 11.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        SettingsIcon(Icons.Default.Tune)
                        Spacer(Modifier.width(11.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Janela da tendência", fontWeight = FontWeight.SemiBold)
                            Text("Comparar períodos usando registros diários", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .58f))
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        listOf(3, 7, 14).forEach { days ->
                            FilterChip(
                                selected = prefs.trendWindowDays == days,
                                onClick = { onPreferencesChange(prefs.copy(trendWindowDays = days)) },
                                label = { Text("$days dias") },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
                SettingsDivider()
                val summaryAllowed = isOwner || commercialTier(membershipTier).ordinal >= MembershipTier.PRATA.ordinal
                SettingsToggleRow(
                    Icons.Default.AutoAwesome,
                    "Resumo inteligente",
                    if (summaryAllowed) "Interpretação automática dos dados" else "Disponível no plano Prata",
                    prefs.showSmartSummary && summaryAllowed,
                    enabled = summaryAllowed,
                    badge = if (summaryAllowed) null else "PRATA"
                ) { onPreferencesChange(prefs.copy(showSmartSummary = it)) }
                SettingsDivider()
                val forecastAllowed = isOwner || commercialTier(membershipTier).ordinal >= MembershipTier.PRATA.ordinal
                SettingsToggleRow(
                    Icons.Default.AutoGraph,
                    "Previsões avançadas",
                    if (forecastAllowed) "Cenários conservador e otimista" else "Disponível no plano Prata ou superior",
                    prefs.showAdvancedForecast && forecastAllowed,
                    enabled = forecastAllowed,
                    badge = if (forecastAllowed) null else "PRATA+"
                ) { onPreferencesChange(prefs.copy(showAdvancedForecast = it)) }
            }
        }

        item { SettingsSectionTitle("Backup e Restauração") }
        item {
            CompactSettingsCard {
                SettingsNavRow(
                    Icons.Default.Archive,
                    "Criar backup ZIP",
                    "FREE • ${state.artists.size} artista(s) • ${state.snapshots.size + state.dailyStreamRecords.size} registro(s)",
                    onClick = { backupCreateLauncher.launch("SONUS_Backup_${LocalDate.now()}.zip") }
                )
                SettingsDivider()
                SettingsNavRow(
                    Icons.Default.RestorePage,
                    "Restaurar backup ZIP",
                    "Recupere artistas, fotos, histórico e preferências",
                    onClick = { backupOpenLauncher.launch(arrayOf("application/zip", "application/octet-stream", "application/x-zip-compressed")) }
                )
                SettingsDivider()
                SettingsNavRow(
                    Icons.Default.Share,
                    "Compartilhar último ZIP",
                    if (lastBackupUriString == null) "Crie um backup primeiro" else "Enviar pelo compartilhamento do Android",
                    enabled = lastBackupUriString != null,
                    onClick = {
                        lastBackupUriString?.let { raw ->
                            val uri = Uri.parse(raw)
                            val intent = Intent(Intent.ACTION_SEND).apply {
                                type = "application/zip"
                                putExtra(Intent.EXTRA_STREAM, uri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(Intent.createChooser(intent, "Compartilhar backup"))
                        }
                    }
                )
                backupMessage?.let {
                    Text(it, modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp), color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
                }
                SettingsDivider()
                if (isGuest) {
                    SettingsNavRow(
                        Icons.Default.Cloud,
                        "Backup Online",
                        "Ouro • entre na conta para sincronizar",
                        onClick = onGuestLogin
                    )
                } else {
                    CloudBackupSettings(
                        state = state,
                        authUser = authUser,
                        membershipTier = membershipTier,
                        isOwner = isOwner,
                        onStateRestored = onRestoreState,
                        embedded = true
                    )
                }
            }
        }

        item { SettingsSectionTitle("Informações") }
        item {
            CompactSettingsCard {
                SettingsNavRow(
                    Icons.Default.Info,
                    "Sobre o SONUS",
                    "Versão ${BuildConfig.VERSION_NAME} • novidades da versão atual",
                    onClick = { showAbout = true }
                )
                SettingsDivider()
                SettingsNavRow(
                    Icons.Default.SystemUpdateAlt,
                    "Checar atualização",
                    "Buscar agora uma nova versão do SONUS",
                    onClick = onCheckUpdate
                )
                SettingsDivider()
                SettingsNavRow(
                    Icons.Default.PrivacyTip,
                    "Opções de privacidade",
                    "Revisar consentimento de anúncios quando disponível",
                    onClick = {
                        val activity = context.findComponentActivityForApp()
                        if (activity != null) adManager.showPrivacyOptions(activity) { error ->
                            error?.let { Toast.makeText(context, it, Toast.LENGTH_SHORT).show() }
                        } else Toast.makeText(context, "Opções indisponíveis agora.", Toast.LENGTH_SHORT).show()
                    }
                )
                SettingsDivider()
                SettingsNavRow(
                    Icons.Default.Policy,
                    "Política de Privacidade",
                    "Abrir a política pública do SONUS",
                    onClick = {
                        runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://raffatheoo-afk.github.io/sonus-privacy/"))) }
                    }
                )
            }
        }

        item { SettingsSectionTitle("Segurança") }
        item {
            if (isGuest) {
                CompactSettingsCard {
                    SettingsNavRow(
                        Icons.Default.Security,
                        "Zona de segurança da conta",
                        "Modo convidado • entre para gerenciar uma conta",
                        onClick = onGuestLogin
                    )
                }
            } else {
                AccountSecuritySettings(
                    authUser = authUser,
                    repository = repository,
                    authManager = authManager,
                    onAfterAccountDeleted = { }
                )
            }
        }
    }

}

@Composable
private fun AppUsageScreen(
    preferences: UserPreferences,
    membershipTier: MembershipTier,
    isOwner: Boolean,
    authUser: AuthUser,
    usageEvents: List<PremiumUsageEvent>,
    onBack: () -> Unit,
    onClearUsage: () -> Unit
) {
    val ctx = LocalContext.current
    val playerStatsStore = remember { PulsePlayerStatsStore(ctx) }
    val proUsageStore = remember { SonusProUsageStats(ctx) }
    val streamRepo = remember { SonusStreamPlatformRepository(ctx) }
    val streamLocalAnalytics = remember { com.sonusstudios.streampulse.tools.SonusStreamLocalAnalyticsStore(ctx) }
    val streamLocalRevision by streamLocalAnalytics.revisionFlow.collectAsState()
    val streamLocalTotal = remember(streamLocalRevision) { streamLocalAnalytics.snapshotAllTime(limit = 5000) }
    val nowMillis by produceState(initialValue = System.currentTimeMillis()) {
        while (true) { value = System.currentTimeMillis(); delay(1000) }
    }
    val activeSession = AppSessionClock.startedAtMillis.takeIf { it > 0L }?.let { (nowMillis - it).coerceAtLeast(0L) } ?: 0L
    val periods = listOf("Hoje","Ontem","7 dias","15 dias","Mês","30 dias","3 meses","Total")
    var period by rememberSaveable { mutableStateOf("Mês") }
    val today = LocalDate.now()
    fun inPeriod(day: String): Boolean = runCatching {
        val d=LocalDate.parse(day)
        when(period){
            "Hoje" -> d==today
            "Ontem" -> d==today.minusDays(1)
            "7 dias" -> !d.isBefore(today.minusDays(6)) && !d.isAfter(today)
            "15 dias" -> !d.isBefore(today.minusDays(14)) && !d.isAfter(today)
            "Mês" -> !d.isBefore(today.withDayOfMonth(1)) && !d.isAfter(today)
            "30 dias" -> !d.isBefore(today.minusDays(29)) && !d.isAfter(today)
            "3 meses" -> !d.isBefore(today.minusMonths(3)) && !d.isAfter(today)
            else -> true
        }
    }.getOrDefault(false)
    val historical = if(period=="Total") preferences.appUsageTotalMillis else preferences.appUsageDailyMillis.filterKeys(::inPeriod).values.sum()
    val totalUsage = historical + if(period=="Hoje" || period=="Mês" || period=="7 dias" || period=="15 dias" || period=="30 dias" || period=="3 meses" || period=="Total") activeSession else 0L
    val featureTotals = remember(preferences.appUsageFeatureDailyMillis, preferences.appUsageFeatureMillis, period) {
        if(period=="Total") preferences.appUsageFeatureMillis else buildMap<String,Long> {
            preferences.appUsageFeatureDailyMillis.forEach { (key,v) ->
                val split=key.indexOf('|'); if(split>0){ val day=key.substring(0,split); val feature=key.substring(split+1); if(inPeriod(day)) put(feature,(get(feature)?:0L)+v) }
            }
        }
    }
    val usedDays = if(period=="Total") preferences.appUsageDaysIso.distinct().size else preferences.appUsageDailyMillis.keys.count(::inPeriod)
    val average = if (usedDays > 0) totalUsage / usedDays.toLong() else totalUsage
    val longestSession = maxOf(preferences.appUsageLongestSessionMillis, activeSession)
    val premiumRemaining = preferences.premiumExpiresAtEpochMillis?.let { (it - nowMillis).coerceAtLeast(0L) }
    val premiumText = when {
        isOwner -> "OWNER • acesso permanente"
        membershipTier == MembershipTier.FREE || premiumRemaining == null || premiumRemaining <= 0L -> "Nenhum plano Premium ativo"
        else -> "${membershipLabel(membershipTier)} • ${formatDurationDetailed(premiumRemaining)} restantes"
    }
    val topFeature = featureTotals.maxByOrNull { it.value }
    val uid=android.os.Process.myUid()
    val baseRx=remember { TrafficStats.getUidRxBytes(uid).coerceAtLeast(0L) }; val baseTx=remember { TrafficStats.getUidTxBytes(uid).coerceAtLeast(0L) }
    var rx by remember { mutableLongStateOf(baseRx) }; var tx by remember { mutableLongStateOf(baseTx) }
    var downBps by remember { mutableLongStateOf(0L) }; var upBps by remember { mutableLongStateOf(0L) }; var networkName by remember { mutableStateOf("Offline") }
    LaunchedEffect(Unit){ var lastRx=rx; var lastTx=tx; while(true){ delay(1000); val nr=TrafficStats.getUidRxBytes(uid).coerceAtLeast(lastRx); val nt=TrafficStats.getUidTxBytes(uid).coerceAtLeast(lastTx); downBps=(nr-lastRx).coerceAtLeast(0); upBps=(nt-lastTx).coerceAtLeast(0); rx=nr;tx=nt;lastRx=nr;lastTx=nt; val cm=ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager; val caps=cm?.activeNetwork?.let(cm::getNetworkCapabilities); networkName=when{caps==null->"Offline";caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)->"Wi‑Fi";caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)->"Dados móveis";caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)->"Ethernet";else->"Rede"} } }
    val dataPeriodRx = if(period=="Total") preferences.dataUsageTotalRxBytes else preferences.dataUsageDailyRxBytes.filterKeys(::inPeriod).values.sum()
    val dataPeriodTx = if(period=="Total") preferences.dataUsageTotalTxBytes else preferences.dataUsageDailyTxBytes.filterKeys(::inPeriod).values.sum()

    val startDate: LocalDate? = when(period){
        "Hoje" -> today
        "Ontem" -> today.minusDays(1)
        "7 dias" -> today.minusDays(6)
        "15 dias" -> today.minusDays(14)
        "Mês" -> today.withDayOfMonth(1)
        "30 dias" -> today.minusDays(29)
        "3 meses" -> today.minusMonths(3)
        else -> null
    }
    val endDate: LocalDate? = when(period){"Ontem"->today.minusDays(1);"Total"->null;else->today}
    val playerStats = remember(period, preferences.appUsageLastAccessIso) {
        if(startDate==null||endDate==null) playerStatsStore.snapshot(limit=5000) else playerStatsStore.snapshot(startDate,endDate,limit=5000)
    }
    val startMs = startDate?.atStartOfDay(ZoneId.systemDefault())?.toInstant()?.toEpochMilli()
    val endMs = endDate?.plusDays(1)?.atStartOfDay(ZoneId.systemDefault())?.toInstant()?.toEpochMilli()?.minus(1)
    val proUsage = remember(period, usageEvents.size) { proUsageStore.snapshot(startMs,endMs) }
    val replayEstimate = playerStats.topTracks.sumOf { (it.plays - 1).coerceAtLeast(0) }
    val radioSourceStats = playerStats.sourceStats.filter { it.name.contains("Rádio",true) || it.name.contains("Radio",true) }
    val radioListeningMs = radioSourceStats.sumOf { it.listenedMs }
    val radioPlays = radioSourceStats.sumOf { it.plays }
    val streamListeningMs = playerStats.sourceStats.filter { it.name.contains("SONUS Stream",true) || it.name.contains("Rádio",true) || it.name.contains("Radio",true) }.sumOf { it.listenedMs }
    val favoriteGenre = playerStats.topGenres.firstOrNull()?.first
    val submissions by produceState(initialValue=emptyList<com.sonusstudios.streampulse.stream.StreamSubmission>(),authUser.uid,period){
        value=if(authUser.uid.isBlank()) emptyList() else runCatching{streamRepo.ownSubmissions(authUser.uid)}.getOrDefault(emptyList())
    }
    val periodSubmissions = submissions.filter { sub -> (startMs==null||sub.createdAt>=startMs) && (endMs==null||sub.createdAt<=endMs) }
    val streamUsageRemote by produceState(initialValue=longArrayOf(0,0,0,0,0),authUser.uid,streamLocalRevision){
        value=runCatching{
            val snap=com.google.firebase.database.FirebaseDatabase.getInstance().getReference("streamUserSongStats").child(authUser.uid).get().awaitUsageSnapshot()
            longArrayOf(
                snap.children.sumOf{it.child("playCount").getValue(Long::class.java)?:0L},
                snap.children.sumOf{it.child("completions").getValue(Long::class.java)?:0L},
                snap.children.sumOf{it.child("replayCount").getValue(Long::class.java)?:0L},
                snap.children.sumOf{it.child("skips").getValue(Long::class.java)?:0L},
                snap.children.count{it.child("liked").getValue(Boolean::class.java)==true}.toLong()
            )
        }.getOrDefault(longArrayOf(0,0,0,0,0))
    }
    // code113 counter fix: o painel pessoal usa o maior valor confirmado entre Firebase
    // e o motor local-first. Assim uma falha de rede/regra não transforma atividade real em zero.
    val streamUsageTotal = remember(streamUsageRemote, streamLocalTotal) {
        longArrayOf(
            maxOf(streamUsageRemote[0], streamLocalTotal.validPlays),
            maxOf(streamUsageRemote[1], streamLocalTotal.completions),
            maxOf(streamUsageRemote[2], streamLocalTotal.replays),
            maxOf(streamUsageRemote[3], streamLocalTotal.skips),
            streamUsageRemote[4]
        )
    }

    val previousPeriodUsage = remember(period, preferences.appUsageDailyMillis) {
        val days = when(period){"Hoje"->1;"Ontem"->1;"7 dias"->7;"15 dias"->15;"Mês"->today.dayOfMonth;"30 dias"->30;else->0}
        if(days<=0) 0L else {
            val currentStart = startDate ?: today
            val prevEnd = currentStart.minusDays(1)
            val prevStart = prevEnd.minusDays((days-1).toLong())
            preferences.appUsageDailyMillis.entries.sumOf { (day,ms) -> val d=runCatching{LocalDate.parse(day)}.getOrNull(); if(d!=null&&!d.isBefore(prevStart)&&!d.isAfter(prevEnd)) ms else 0L }
        }
    }
    val trendText = if(previousPeriodUsage>0L && totalUsage>0L){
        val pct=((totalUsage-previousPeriodUsage)*100.0/previousPeriodUsage).roundToInt()
        when{pct>0->"$pct% a mais que o período anterior";pct<0->"${-pct}% a menos que o período anterior";else->"Uso estável em relação ao período anterior"}
    } else "Comparação aparece quando houver histórico suficiente"

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 30.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { PageHeader("Uso do app SONUS", onBack) }
        item {
            Surface(shape=RoundedCornerShape(22.dp),color=Color(0xFF5A171B).copy(alpha=.86f),border=BorderStroke(1.dp,Color(0xFFFF5B5B).copy(alpha=.55f))) {
                Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                    Text("Seus dados de utilização",color=Color.White,fontWeight=FontWeight.ExtraBold,fontSize=20.sp)
                    Text("Estatísticas locais do SONUS. Escolha o período para atualizar todos os cartões.",color=Color.White.copy(alpha=.72f),style=MaterialTheme.typography.bodySmall)
                    Column(verticalArrangement=Arrangement.spacedBy(5.dp)) {
                        periods.chunked(4).forEach { rowPeriods ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(5.dp)) {
                                rowPeriods.forEach { p ->
                                    FilterChip(selected=period==p,onClick={period=p},label={Text(p,fontSize=9.sp)},modifier=Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }
            }
        }
        item { UsageStatCard(Icons.Default.Insights,"Seu uso em resumo", "${formatDurationDetailed(totalUsage)} • ${playerStats.totalPlays} reprodução(ões)", listOfNotNull(proUsage.favoriteTool?.let{"Ferramenta favorita: $it"}, favoriteGenre?.let{"Gênero mais ouvido: $it"}).joinToString(" • ").ifBlank{trendText}, Color(0xFF9A7CFF)) }
        item { UsageStatCard(Icons.Default.TrendingUp,"Tendência",trendText,"Comparação baseada no mesmo tamanho de período quando há histórico",Color(0xFFB694FF)) }
        item { UsageStatCard(Icons.Default.Timer,"Tempo total de uso",formatDurationDetailed(totalUsage),"Conta enquanto o SONUS está em primeiro plano",Color(0xFFFF6B6B)) }
        item { UsageStatCard(Icons.Default.Headphones,"Tempo no SONUS PLAYER",formatDurationDetailed((featureTotals["SONUS PLAYER"]?:0L)+(featureTotals["Player"]?:0L)),"Somente a tela do Player; não soma o Stream",Color(0xFF69E6FF)) }
        item { UsageStatCard(Icons.Default.Radio,"Tempo no SONUS Stream",formatDurationDetailed(featureTotals["SONUS Stream"]?:0L),"Tempo na área do Stream",Color(0xFF57D6B1)) }
        item { UsageStatCard(Icons.Default.Podcasts,"Tempo ouvido na SONUS Rádio",formatDurationDetailed(radioListeningMs),"$radioPlays item(ns) de Rádio no período • locuções não geram view de faixa",Color(0xFF4CD8FF)) }
        item { UsageStatCard(Icons.Default.GraphicEq,"Reprodução local", "${playerStats.totalPlays} iniciadas • ${playerStats.totalCompleted} concluídas", "${playerStats.totalSkips} puladas • $replayEstimate repetições estimadas", Color(0xFF77D9FF)) }
        item { UsageStatCard(Icons.Default.Verified,"SONUS Stream • reproduções válidas",streamUsageTotal[0].toString(),"Total da conta • critério dinâmico por faixa + janela de 8 min",Color(0xFF59D19C)) }
        item { UsageStatCard(Icons.Default.Replay,"Interações do Stream","${streamUsageTotal[1]} concluídas • ${streamUsageTotal[2]} replays","${streamUsageTotal[3]} pulos • ${streamUsageTotal[4]} likes ativos",Color(0xFF64C7FF)) }
        item { UsageStatCard(Icons.Default.VideoLibrary,"Tempo no SONUS VIDEO",formatDurationDetailed((featureTotals["SONUS VIDEO"]?:0L)+(featureTotals["STUDIO SONUS"]?:0L)),"Vídeos locais, nuvem, YouTube e karaokê",SignalGreen) }
        item { UsageStatCard(Icons.Default.AutoAwesome,"Tempo em DESTAQUES SONUS",formatDurationDetailed((featureTotals["DESTAQUES SONUS"]?:0L)+(featureTotals["Destaques"]?:0L)),"Ferramentas essenciais",Color(0xFF9A7CFF)) }
        item { UsageStatCard(Icons.Default.Handyman,"Ferramentas PRO","${proUsage.operations} operação(ões) • ${proUsage.filesProcessed} arquivo(s)",proUsage.favoriteTool?.let{"Mais usada: $it"}?:"Histórico desta métrica começa na 1.0.0",Color(0xFFFFC857)) }
        item { UsageStatCard(Icons.Default.MonetizationOn,"Desbloqueios PRO","${proUsage.blocksUnlocked} bloco(s)","${proUsage.coinUnlocks} por moeda • ${proUsage.adUnlocks} por anúncio premiado",Color(0xFFFFB85C)) }
        item { UsageStatCard(Icons.Default.UploadFile,"Envios SONUS Stream","${periodSubmissions.size} no período","${periodSubmissions.count{it.status=="REVIEWING"||it.status=="RECEIVED"}} em análise • ${periodSubmissions.count{it.status=="APPROVED"||it.status=="PUBLISHED"}} aprovados/publicados • ${periodSubmissions.count{it.status=="REJECTED"}} rejeitados",Color(0xFF58D7FF)) }
        item { UsageStatCard(Icons.Default.Settings,"Tempo em Ajustes",formatDurationDetailed(featureTotals["Ajustes"]?:0L),"Configurações, Premium, suporte e estatísticas",Color(0xFF8EA7FF)) }
        item { UsageStatCard(Icons.Default.Login,"Entradas no SONUS","${preferences.appUsageSessionCount} entrada(s)","Uma nova sessão conta como uma entrada",SignalGreen) }
        item { UsageStatCard(Icons.Default.QueryStats,"Média diária de uso",formatDurationShort(average),"Baseada no período selecionado",SignalBlue) }
        item { UsageStatCard(Icons.Default.LocalFireDepartment,"Maior sessão",formatDurationDetailed(longestSession),"Maior período contínuo registrado",SignalOrange) }
        item { UsageStatCard(Icons.Default.WorkspacePremium,"Premium restante",premiumText,"Plano atual e tempo restante",membershipGradient(membershipTier).first()) }
        item { UsageStatCard(Icons.Default.Today,"Último acesso",preferences.appUsageLastAccessIso?.let(::formatUsageAccess)?:"Ainda não registrado","Última abertura registrada",MaterialTheme.colorScheme.primary) }
        item {
            Text("Rede e consumo",fontWeight=FontWeight.ExtraBold,fontSize=18.sp)
        }
        item { UsageStatCard(Icons.Default.DataUsage,"Consumo no período","↓ ${formatDataBytes(dataPeriodRx)} • ↑ ${formatDataBytes(dataPeriodTx)}","Histórico acumulado pelo processo SONUS",Color(0xFF42D7E8)) }
        item { UsageStatCard(Icons.Default.Speed,"Velocidade atual","↓ ${formatDataRate(downBps)} • ↑ ${formatDataRate(upBps)}","$networkName • mede o tráfego real do Pulse, sem speed test",Color(0xFF68E0A5)) }
        item { UsageStatCard(Icons.Default.Storage,"Consumo total","${formatDataBytes(preferences.dataUsageTotalRxBytes+preferences.dataUsageTotalTxBytes)}","Download + upload acumulados",Color(0xFF9A8CFF)) }
        item {
            var confirmClear by remember { mutableStateOf(false) }
            OutlinedButton(onClick={confirmClear=true}, modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.DeleteSweep,null); Spacer(Modifier.width(7.dp)); Text("Limpar todos os dados de uso") }
            if(confirmClear) AlertDialog(onDismissRequest={confirmClear=false}, title={Text("Limpar dados de uso?")}, text={Text("Somente as métricas desta tela serão zeradas. Conta, plano, arquivos e configurações permanecem intactos.")}, confirmButton={TextButton(onClick={playerStatsStore.clear();proUsageStore.clear();onClearUsage();confirmClear=false}){Text("Limpar")}}, dismissButton={TextButton(onClick={confirmClear=false}){Text("Cancelar")}})
        }
    }
}

private suspend fun com.google.android.gms.tasks.Task<com.google.firebase.database.DataSnapshot>.awaitUsageSnapshot(): com.google.firebase.database.DataSnapshot = suspendCancellableCoroutine { cont ->
    addOnSuccessListener { if (cont.isActive) cont.resume(it) }
    addOnFailureListener { if (cont.isActive) cont.resumeWithException(it) }
    addOnCanceledListener { cont.cancel() }
}

private fun formatDataBytes(bytes:Long):String { val b=bytes.coerceAtLeast(0L); return when { b>=1024L*1024L*1024L -> String.format(java.util.Locale.US,"%.2f GB",b/(1024.0*1024.0*1024.0)); b>=1024L*1024L -> String.format(java.util.Locale.US,"%.1f MB",b/(1024.0*1024.0)); b>=1024L -> String.format(java.util.Locale.US,"%.1f KB",b/1024.0); else -> "$b B" } }
private fun formatDataRate(bytesPerSec:Long):String = "${formatDataBytes(bytesPerSec)}/s"

@Composable
private fun UsageStatCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    value: String,
    subtitle: String,
    accent: Color
) {
    Surface(
        shape = RoundedCornerShape(19.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = .82f),
        border = BorderStroke(1.dp, accent.copy(alpha = .28f))
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = CircleShape, color = accent.copy(alpha = .14f)) {
                Icon(icon, null, tint = accent, modifier = Modifier.padding(9.dp).size(21.dp))
            }
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(value, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = accent)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .56f))
            }
        }
    }
}

private fun formatDurationDetailed(ms: Long): String {
    val totalMinutes = (ms.coerceAtLeast(0L) / 60_000L)
    val days = totalMinutes / (24L * 60L)
    val hours = (totalMinutes / 60L) % 24L
    val minutes = totalMinutes % 60L
    return when {
        days > 0L -> "${days}d ${hours}h ${minutes}min"
        hours > 0L -> "${hours}h ${minutes}min"
        else -> "${minutes}min"
    }
}

private fun formatDurationShort(ms: Long): String {
    val totalMinutes = (ms.coerceAtLeast(0L) / 60_000L)
    return if (totalMinutes >= 60L) "${totalMinutes / 60L}h ${totalMinutes % 60L}min/dia" else "${totalMinutes} min/dia"
}

private fun formatUsageAccess(raw: String): String = runCatching {
    val instant = Instant.parse(raw)
    val local = instant.atZone(ZoneId.systemDefault())
    val date = local.toLocalDate()
    val time = local.toLocalTime().format(DateTimeFormatter.ofPattern("HH:mm"))
    if (date == LocalDate.now()) "Hoje • $time" else "${date.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))} • $time"
}.getOrDefault(raw.take(16).replace('T', ' '))

@Composable
private fun AuthProfileAvatar(photoUrl: String?, avatarSize: androidx.compose.ui.unit.Dp = 56.dp, iconSize: androidx.compose.ui.unit.Dp = 38.dp) {
    val bitmap by produceState<android.graphics.Bitmap?>(initialValue = null, photoUrl) {
        value = if (photoUrl.isNullOrBlank()) null else withContext(Dispatchers.IO) {
            runCatching { URL(photoUrl).openStream().use { stream -> BitmapFactory.decodeStream(stream) } }.getOrNull()
        }
    }
    Surface(
        shape = CircleShape,
        color = MaterialTheme.colorScheme.primaryContainer,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = .34f))
    ) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap!!.asImageBitmap(),
                contentDescription = "Foto da conta",
                modifier = Modifier.size(avatarSize).clip(CircleShape),
                contentScale = ContentScale.Crop
            )
        } else {
            Box(Modifier.size(avatarSize), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.AccountCircle, contentDescription = null, modifier = Modifier.size(iconSize), tint = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

@Composable
private fun ArtistResourceSettingsCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    description: String,
    enabled: Boolean,
    pinned: Boolean,
    accent: Color,
    pro: Boolean,
    locked: Boolean,
    onLockedClick: () -> Unit,
    onEnabledChange: (Boolean) -> Unit,
    onPinnedChange: (Boolean) -> Unit,
    onOpen: () -> Unit
) {
    var entered by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { entered = true }
    AnimatedVisibility(
        visible = entered,
        enter = fadeIn(animationSpec = tween(180)) + slideInVertically(animationSpec = tween(220)) { it / 7 }
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth().then(if (locked) Modifier.clickable(onClick = onLockedClick) else Modifier),
            shape = RoundedCornerShape(18.dp),
            color = accent.copy(alpha = if (enabled && !locked) .13f else .07f),
            border = BorderStroke(1.dp, accent.copy(alpha = if (enabled && !locked) .42f else .18f))
        ) {
            Column(Modifier.padding(horizontal = 11.dp, vertical = 9.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(shape = RoundedCornerShape(10.dp), color = accent.copy(alpha = .18f)) {
                        Icon(icon, null, tint = accent, modifier = Modifier.padding(7.dp).size(18.dp))
                    }
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(title, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, maxLines = 1)
                            if (pro) {
                                Spacer(Modifier.width(6.dp))
                                Surface(shape = RoundedCornerShape(999.dp), color = Color(0xFFFFC84B).copy(alpha = .18f)) {
                                    Text("PRO", modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp), color = Color(0xFFFFC84B), fontSize = 9.sp, fontWeight = FontWeight.Black)
                                }
                            }
                        }
                        Text(description, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .62f))
                    }
                    Switch(
                        checked = enabled && !locked,
                        onCheckedChange = { value -> if (locked) onLockedClick() else onEnabledChange(value) }
                    )
                }
                AnimatedVisibility(visible = enabled && !locked, enter = fadeIn(tween(160))) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Switch(checked = pinned, onCheckedChange = onPinnedChange, modifier = Modifier.height(30.dp))
                        Spacer(Modifier.width(6.dp))
                        Icon(Icons.Default.PushPin, null, tint = accent, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Mostrar na barra", modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        FilledTonalButton(
                            onClick = onOpen,
                            modifier = Modifier.height(32.dp),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.filledTonalButtonColors(containerColor = accent.copy(alpha = .18f), contentColor = accent),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp)
                        ) {
                            Icon(Icons.Default.OpenInNew, null, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Abrir", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BlackBoxSettingsCard(
    pinned: Boolean,
    onPinnedChange: (Boolean) -> Unit,
    onOpen: () -> Unit
) {
    val accent = Color(0xFFB8C6E8)
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = Color(0xFF080A0F).copy(alpha = .96f),
        border = BorderStroke(1.dp, accent.copy(alpha = .24f))
    ) {
        Column(Modifier.padding(horizontal = 11.dp, vertical = 9.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Surface(shape = RoundedCornerShape(10.dp), color = accent.copy(alpha = .12f)) {
                    Icon(Icons.Default.Security, null, tint = accent, modifier = Modifier.padding(7.dp).size(18.dp))
                }
                Column(Modifier.weight(1f)) {
                    Text("Caixa Preta SONUS", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                    Text("Gravação contínua local com buffer substituível e PIN.", style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .62f))
                }
                FilledTonalButton(
                    onClick = onOpen,
                    modifier = Modifier.height(32.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.filledTonalButtonColors(containerColor = accent.copy(alpha = .13f), contentColor = accent)
                ) { Text("Abrir", fontSize = 11.sp) }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = pinned, onCheckedChange = onPinnedChange, modifier = Modifier.height(30.dp))
                Spacer(Modifier.width(6.dp))
                Icon(Icons.Default.PushPin, null, tint = accent, modifier = Modifier.size(14.dp))
                Spacer(Modifier.width(4.dp))
                Text("Mostrar nas abas principais", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                Spacer(Modifier.weight(1f))
                Text("Sem backup • local", fontSize = 9.sp, color = accent.copy(alpha = .62f))
            }
        }
    }
}

@Composable
private fun SettingsHubTile(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    accent: Color,
    containerColor: Color = accent.copy(alpha = .10f),
    modifier: Modifier = Modifier,
    wide: Boolean = false,
    badge: String? = null,
    avatarUrl: String? = null,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        color = containerColor,
        border = BorderStroke(1.dp, accent.copy(alpha = .38f))
    ) {
        if (wide) {
            Row(
                Modifier.padding(horizontal = 13.dp, vertical = 11.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(shape = RoundedCornerShape(14.dp), color = accent.copy(alpha = .16f)) {
                    Icon(icon, null, tint = accent, modifier = Modifier.padding(9.dp).size(22.dp))
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(title, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                        badge?.let {
                            Spacer(Modifier.width(6.dp))
                            Surface(shape = RoundedCornerShape(999.dp), color = accent.copy(alpha = .16f)) {
                                Text(it, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp), fontSize = 9.sp, fontWeight = FontWeight.Black, color = accent)
                            }
                        }
                    }
                    Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .60f), maxLines = 1)
                }
                Icon(Icons.Default.ChevronRight, null, tint = accent.copy(alpha=.75f))
            }
        } else {
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 11.dp),
                verticalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (!avatarUrl.isNullOrBlank()) {
                        AuthProfileAvatar(avatarUrl, 37.dp, 27.dp)
                    } else {
                        Surface(shape = RoundedCornerShape(13.dp), color = accent.copy(alpha = .16f)) {
                            Icon(icon, null, tint = accent, modifier = Modifier.padding(8.dp).size(21.dp))
                        }
                    }
                    Spacer(Modifier.weight(1f))
                    badge?.let {
                        Surface(shape = RoundedCornerShape(999.dp), color = accent.copy(alpha = .16f)) {
                            Text(it, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp), fontSize = 9.sp, fontWeight = FontWeight.Black, color = accent)
                        }
                    }
                }
                Text(title, fontWeight = FontWeight.ExtraBold, maxLines = 1, fontSize = 14.sp)
                Text(subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .56f), maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun SettingsSectionTitle(title: String) {
    Text(
        title,
        modifier = Modifier.padding(top = 3.dp, start = 2.dp),
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary
    )
}

@Composable
private fun CompactSettingsCard(content: @Composable ColumnScope.() -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(21.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .62f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = .10f))
    ) {
        Column(content = content)
    }
}

@Composable
private fun SettingsIcon(icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary.copy(alpha = .13f)) {
        Box(Modifier.size(36.dp), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
        }
    }
}

@Composable
private fun SettingsNavRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    enabled: Boolean = true,
    onClick: (() -> Unit)?
) {
    val contentAlpha = if (enabled) 1f else .42f
    val modifier = if (onClick != null && enabled) Modifier.clickable(onClick = onClick) else Modifier
    Row(
        modifier = modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        SettingsIcon(icon)
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface.copy(alpha = contentAlpha))
            Text(subtitle, style = MaterialTheme.typography.bodySmall, maxLines = 2, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .56f * contentAlpha))
        }
        if (onClick != null) {
            Icon(Icons.Default.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurface.copy(alpha = .34f * contentAlpha))
        }
    }
}

@Composable
private fun SettingsToggleRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    enabled: Boolean = true,
    badge: String? = null,
    onCheckedChange: (Boolean) -> Unit
) {
    val alpha = if (enabled) 1f else .46f
    Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
        SettingsIcon(icon)
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface.copy(alpha = alpha))
                badge?.let {
                    Spacer(Modifier.width(6.dp))
                    Surface(shape = RoundedCornerShape(999.dp), color = MaterialTheme.colorScheme.primary.copy(alpha=.12f)) {
                        Text(it, modifier = Modifier.padding(horizontal=6.dp, vertical=2.dp), fontSize=9.sp, fontWeight=FontWeight.Black, color=MaterialTheme.colorScheme.primary)
                    }
                }
            }
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .56f * alpha), maxLines = 2)
        }
        Switch(checked = checked, enabled = enabled, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun SettingsDivider() {
    HorizontalDivider(modifier = Modifier.padding(start = 60.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = .13f))
}

private fun textAppearanceLabel(value: TextAppearance): String = when (value) {
    TextAppearance.DYNAMIC -> "Dinâmico"
    TextAppearance.BLACK -> "Preto"
    TextAppearance.WHITE -> "Branco"
    TextAppearance.WHITE_BLACK_OUTLINE -> "Branco com bordas pretas"
    TextAppearance.BLACK_WHITE_OUTLINE -> "Preto com bordas brancas"
    TextAppearance.RAINBOW -> "Arco-íris"
    TextAppearance.DEEP_GRAY -> "Cinza intenso"
    TextAppearance.BOLD -> "Negrito"
    TextAppearance.WHITE_SHADOW -> "Branco sombreado"
    TextAppearance.NAVY -> "Azul-marinho"
}

private fun textAppearanceExample(value: TextAppearance): String = when (value) {
    TextAppearance.DYNAMIC -> "Adapta-se ao contraste do tema"
    TextAppearance.BOLD -> "Mantém a cor do tema e reforça o peso"
    TextAppearance.RAINBOW -> "Cores animadas e misturadas"
    else -> "SONUS 123 • Prévia aplicada em tempo real"
}

private fun effectivePromotionalTier(prefs: UserPreferences, now: Long = System.currentTimeMillis()): MembershipTier {
    val active = (prefs.premiumExpiresAtEpochMillis ?: 0L) > now
    if (!active) return MembershipTier.FREE
    return when (prefs.promotionalTierName?.uppercase(Locale.US)) {
        "BRONZE", "PLUS", "PRATA" -> MembershipTier.PRATA
        "STUDIO", "OURO", "MAX" -> MembershipTier.OURO
        "DIAMANTE", "DIAMOND" -> MembershipTier.DIAMANTE
        else -> MembershipTier.FREE
    }
}

private fun themeLabel(mode: ThemeMode): String = when (mode) {
    ThemeMode.SYSTEM -> "Sistema"
    ThemeMode.DYNAMIC -> "Dinâmico"
    ThemeMode.LIGHT -> "Claro"
    ThemeMode.DARK -> "Escuro"
    ThemeMode.BLUE -> "Azul suave"
    ThemeMode.GREEN -> "Verde suave"
    ThemeMode.RED -> "Vermelho suave"
    ThemeMode.CHECKERED -> "Xadrez"
    ThemeMode.SOFT_YELLOW -> "Amarelo suave"
    ThemeMode.SOFT_BROWN -> "Marrom suave"
    ThemeMode.SOFT_ORANGE -> "Laranja suave"
    ThemeMode.SILVER -> "Prata"
    ThemeMode.SLATE -> "Slate"
    ThemeMode.OCEAN -> "Ocean"
    ThemeMode.FOREST -> "Forest"
    ThemeMode.RAINBOW -> "Arco-íris"
    ThemeMode.MONOCHROME -> "Monocromático"
    ThemeMode.PINK -> "Rosa"
    ThemeMode.LILAC -> "Lilás"
    ThemeMode.DEEP_BLACK -> "Preto profundo"
    ThemeMode.VIOLET_PULSE -> "Violet Pulse"
    ThemeMode.SUNSET -> "Sunset"
    ThemeMode.MIDNIGHT_CYAN -> "Midnight Cyan"
    ThemeMode.AURORA -> "Aurora azul/lilás/rosa"
    ThemeMode.NEON_STUDIO -> "Neon Studio"
    ThemeMode.CRIMSON_PRO -> "Crimson Pro"
    ThemeMode.AURORA_PRO -> "Aurora Pro"
    ThemeMode.PHOTO -> "Foto no fundo"
    ThemeMode.PROFESSIONAL -> "Profissional"
    ThemeMode.GOLD -> "Dourado"
    ThemeMode.SKY -> "Céu"
    ThemeMode.SPACE -> "Space"
    ThemeMode.CYBER_PULSE -> "Cyber Pulse"
    ThemeMode.ROYAL_GOLD -> "Royal Gold"
    ThemeMode.GLASS_HORIZON -> "Glass Horizon"
    ThemeMode.NEBULA -> "Nebula"
    ThemeMode.INFINITY -> "Infinity"
    ThemeMode.LIQUID_GLASS -> "Liquid Glass"
    ThemeMode.THREE_D -> "3D"
    ThemeMode.CAMALEON -> "Camaleon"
    ThemeMode.PARALLAX -> "Paralaxe"
}

private fun themeDescription(mode: ThemeMode): String = when (mode) {
    ThemeMode.SYSTEM -> "Segue o sistema"
    ThemeMode.DYNAMIC -> "Cores em movimento suave"
    ThemeMode.LIGHT -> "Claro e limpo"
    ThemeMode.DARK -> "Escuro clássico"
    ThemeMode.BLUE -> "Azul discreto"
    ThemeMode.GREEN -> "Verde suave"
    ThemeMode.RED -> "Vermelho elegante"
    ThemeMode.CHECKERED -> "Padrão xadrez discreto"
    ThemeMode.SOFT_YELLOW -> "Quente, claro e confortável"
    ThemeMode.SOFT_BROWN -> "Tons terrosos suaves"
    ThemeMode.SOFT_ORANGE -> "Laranja leve e acolhedor"
    ThemeMode.SILVER -> "Cinza metálico elegante"
    ThemeMode.SLATE -> "Grafite azulado minimalista"
    ThemeMode.OCEAN -> "Azul oceânico profundo e calmo"
    ThemeMode.FOREST -> "Verde esmeralda sóbrio"
    ThemeMode.RAINBOW -> "Fundo e acentos multicoloridos"
    ThemeMode.MONOCHROME -> "Remove o excesso de cores"
    ThemeMode.PINK -> "Visual feminino e sofisticado"
    ThemeMode.LILAC -> "Suave, moderno e delicado"
    ThemeMode.DEEP_BLACK -> "Fundo preto com botões coloridos"
    ThemeMode.VIOLET_PULSE -> "Violeta neon com profundidade"
    ThemeMode.SUNSET -> "Roxo e laranja queimado"
    ThemeMode.MIDNIGHT_CYAN -> "Preto azulado com ciano luminoso"
    ThemeMode.AURORA -> "Degradê azul, lilás e rosa"
    ThemeMode.NEON_STUDIO -> "Estúdio escuro com ciano e violeta"
    ThemeMode.CRIMSON_PRO -> "Grafite e vinho profissional"
    ThemeMode.AURORA_PRO -> "Aurora refinada com brilho localizado"
    ThemeMode.PHOTO -> "Imagem escolhida em Foto no fundo"
    ThemeMode.PROFESSIONAL -> "Preto, limpo e ícones azuis"
    ThemeMode.GOLD -> "Ouro sofisticado e profundo"
    ThemeMode.SKY -> "Céu azul com nuvens"
    ThemeMode.SPACE -> "Espaço profundo com planetas"
    ThemeMode.CYBER_PULSE -> "Azul elétrico e magenta"
    ThemeMode.ROYAL_GOLD -> "Preto e dourado elegante"
    ThemeMode.GLASS_HORIZON -> "Vidro, profundidade e reflexos suaves"
    ThemeMode.NEBULA -> "Nebulosa violeta cinematográfica"
    ThemeMode.INFINITY -> "Tema Ouro dinâmico de assinatura"
    ThemeMode.LIQUID_GLASS -> "Vidro translúcido, camadas e profundidade"
    ThemeMode.THREE_D -> "Relevo, volume e profundidade visual"
    ThemeMode.CAMALEON -> "Cores do ambiente captadas pela câmera"
    ThemeMode.PARALLAX -> "Camadas que respondem ao movimento do aparelho"
}

private fun themeRequiredTier(mode: ThemeMode): MembershipTier? = when (mode) {
    ThemeMode.RAINBOW, ThemeMode.MONOCHROME, ThemeMode.PINK, ThemeMode.LILAC, ThemeMode.DEEP_BLACK,
    ThemeMode.VIOLET_PULSE, ThemeMode.SUNSET, ThemeMode.MIDNIGHT_CYAN -> MembershipTier.FREE
    ThemeMode.AURORA, ThemeMode.NEON_STUDIO, ThemeMode.CRIMSON_PRO, ThemeMode.AURORA_PRO -> MembershipTier.PRATA
    ThemeMode.PHOTO, ThemeMode.PROFESSIONAL, ThemeMode.GOLD, ThemeMode.SKY, ThemeMode.SPACE,
    ThemeMode.CYBER_PULSE, ThemeMode.ROYAL_GOLD, ThemeMode.GLASS_HORIZON, ThemeMode.NEBULA, ThemeMode.INFINITY -> MembershipTier.OURO
    ThemeMode.LIQUID_GLASS, ThemeMode.THREE_D, ThemeMode.CAMALEON, ThemeMode.PARALLAX -> MembershipTier.DIAMANTE
    else -> null
}

private fun themePreviewColors(mode: ThemeMode): List<Color> = when (mode) {
    ThemeMode.SYSTEM -> listOf(Color.Gray, Color.DarkGray)
    ThemeMode.DYNAMIC -> listOf(PulseBlue, PulsePurple, PulseCyan)
    ThemeMode.LIGHT -> listOf(Color(0xFFF4F7FF), Color.White)
    ThemeMode.DARK -> listOf(Color(0xFF101722), Color(0xFF061327))
    ThemeMode.BLUE -> listOf(Color(0xFF4E8FE8), Color(0xFF0C2346))
    ThemeMode.GREEN -> listOf(Color(0xFF5DBA86), Color(0xFF103429))
    ThemeMode.RED -> listOf(Color(0xFFE27878), Color(0xFF472028))
    ThemeMode.CHECKERED -> listOf(Color(0xFF101318), Color(0xFF38404A), Color(0xFF15191F))
    ThemeMode.SOFT_YELLOW -> listOf(Color(0xFFFFE98E), Color(0xFFC9A63D), Color(0xFFFFF8D8))
    ThemeMode.SOFT_BROWN -> listOf(Color(0xFF7C553C), Color(0xFF3E291E), Color(0xFF1A120E))
    ThemeMode.SOFT_ORANGE -> listOf(Color(0xFFFFB36B), Color(0xFF9A4F20), Color(0xFF2B170C))
    ThemeMode.SILVER -> listOf(Color(0xFFE3E8EE), Color(0xFF79838D), Color(0xFF171B21))
    ThemeMode.SLATE -> listOf(Color(0xFF9EB5CC), Color(0xFF263542), Color(0xFF0A1017))
    ThemeMode.OCEAN -> listOf(Color(0xFF44D7E8), Color(0xFF0B4B58), Color(0xFF02141B))
    ThemeMode.FOREST -> listOf(Color(0xFF63E0A5), Color(0xFF14533A), Color(0xFF03120C))
    ThemeMode.RAINBOW -> listOf(Color(0xFF58C7FF), Color(0xFFFF5F9E), Color(0xFFFFD066), Color(0xFF79E0B5))
    ThemeMode.MONOCHROME -> listOf(Color(0xFFF0F0F0), Color(0xFF777777), Color(0xFF111111))
    ThemeMode.PINK -> listOf(Color(0xFFFF8BC7), Color(0xFF8C315F), Color(0xFF2C1025))
    ThemeMode.LILAC -> listOf(Color(0xFFC6A7FF), Color(0xFF6D4EA1), Color(0xFF211531))
    ThemeMode.DEEP_BLACK -> listOf(Color(0xFF050505), Color(0xFF20A4F3), Color(0xFFFF4D8D))
    ThemeMode.VIOLET_PULSE -> listOf(Color(0xFFD281FF), Color(0xFF7445D8), Color(0xFF10081A))
    ThemeMode.SUNSET -> listOf(Color(0xFFFF9A5A), Color(0xFFB64F91), Color(0xFF160A1D))
    ThemeMode.MIDNIGHT_CYAN -> listOf(Color(0xFF42E8FF), Color(0xFF2876A6), Color(0xFF020A10))
    ThemeMode.AURORA -> listOf(Color(0xFF5EA8FF), Color(0xFFB778FF), Color(0xFFFF78B8))
    ThemeMode.NEON_STUDIO -> listOf(Color(0xFF22DFFF), Color(0xFF9850FF), Color(0xFF02040A))
    ThemeMode.CRIMSON_PRO -> listOf(Color(0xFFFF607A), Color(0xFF9B2948), Color(0xFF0B0508))
    ThemeMode.AURORA_PRO -> listOf(Color(0xFF56FFD4), Color(0xFFB46CFF), Color(0xFF031016))
    ThemeMode.PHOTO -> listOf(Color(0xFF355A85), Color(0xFF20152D))
    ThemeMode.PROFESSIONAL -> listOf(Color.Black, Color(0xFF1769B0), Color(0xFF0A0A0A))
    ThemeMode.GOLD -> listOf(Color(0xFFFFDF78), Color(0xFF9A741C), Color(0xFF1B1202))
    ThemeMode.SKY -> listOf(Color(0xFF5CB5F0), Color(0xFFBDE9FF), Color.White)
    ThemeMode.SPACE -> listOf(Color(0xFF9F7DFF), Color(0xFF1E2B68), Color(0xFF03040A))
    ThemeMode.CYBER_PULSE -> listOf(Color(0xFF00E4FF), Color(0xFFFF43D4), Color(0xFF01040A))
    ThemeMode.ROYAL_GOLD -> listOf(Color(0xFFFFD76A), Color(0xFFB78B2E), Color(0xFF090602))
    ThemeMode.GLASS_HORIZON -> listOf(Color(0xFFB5E7FF), Color(0xFF9C83FF), Color(0xFF07101B))
    ThemeMode.NEBULA -> listOf(Color(0xFFD774FF), Color(0xFF5B75FF), Color(0xFF04030B))
    ThemeMode.INFINITY -> listOf(Color(0xFF20E2FF), Color(0xFF8D55FF), Color(0xFF010207))
    ThemeMode.LIQUID_GLASS -> listOf(Color(0xFFBFEAFF), Color(0xFF9C83FF), Color(0xFF132B3D))
    ThemeMode.THREE_D -> listOf(Color(0xFF63C7FF), Color(0xFF725BFF), Color(0xFF070B16))
    ThemeMode.CAMALEON -> listOf(Color(0xFF65E6A8), Color(0xFF58A8FF), Color(0xFF8D6BFF))
    ThemeMode.PARALLAX -> listOf(Color(0xFF69D9FF), Color(0xFF9B79FF), Color(0xFF050A18))
}

private fun fontLabel(font: AppFont): String = when (font) {
    AppFont.MODERN -> "Moderna"
    AppFont.ROUNDED -> "Arredondada"
    AppFont.CLASSIC -> "Clássica"
    AppFont.COMPACT -> "Compacta"
    AppFont.DIGITAL -> "Digital"
    AppFont.NEO -> "Neo"
    AppFont.SOFT -> "Soft"
    AppFont.URBAN -> "Urban"
    AppFont.ELEGANT -> "Elegant"
    AppFont.WIDE -> "Wide"
    AppFont.EDITORIAL -> "Editorial"
    AppFont.SIGNATURE -> "Signature"
    AppFont.PULSE -> "Pulse"
    AppFont.MINIMAL -> "Minimal"
    AppFont.TECH -> "Tech"
    AppFont.QUANTUM -> "Quantum"
    AppFont.VISION -> "Vision"
    AppFont.PRIME -> "Prime"
    AppFont.CODEX -> "Codex"
    AppFont.CINEMA -> "Cinema"
    AppFont.ARCHITECT -> "Architect"
    AppFont.NOVA -> "Nova"
    AppFont.MONUMENT -> "Monument"
    AppFont.VELVET -> "Velvet"
    AppFont.TITAN -> "Titan"
}

private fun fontRequiredTier(font: AppFont): MembershipTier? = when (font) {
    AppFont.NEO, AppFont.SOFT, AppFont.URBAN, AppFont.ELEGANT, AppFont.WIDE -> MembershipTier.FREE
    AppFont.EDITORIAL, AppFont.SIGNATURE, AppFont.PULSE, AppFont.MINIMAL, AppFont.TECH -> MembershipTier.OURO
    AppFont.QUANTUM, AppFont.VISION, AppFont.PRIME, AppFont.CODEX, AppFont.CINEMA, AppFont.ARCHITECT, AppFont.NOVA, AppFont.MONUMENT, AppFont.VELVET, AppFont.TITAN -> MembershipTier.OURO
    else -> null
}

private fun fontPreviewFamily(font: AppFont): FontFamily = when (font) {
    AppFont.MODERN, AppFont.NEO, AppFont.URBAN, AppFont.WIDE, AppFont.PULSE, AppFont.VISION, AppFont.ARCHITECT, AppFont.MONUMENT -> FontFamily.SansSerif
    AppFont.ROUNDED, AppFont.SOFT, AppFont.SIGNATURE, AppFont.NOVA -> FontFamily.Cursive
    AppFont.CLASSIC, AppFont.ELEGANT, AppFont.EDITORIAL, AppFont.PRIME, AppFont.CINEMA, AppFont.VELVET -> FontFamily.Serif
    AppFont.DIGITAL, AppFont.TECH, AppFont.QUANTUM, AppFont.CODEX -> FontFamily.Monospace
    AppFont.COMPACT, AppFont.MINIMAL, AppFont.TITAN -> FontFamily.Default
}

@Composable
private fun SettingsCard(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, content: @Composable ColumnScope.() -> Unit) {
    Card {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null)
                Spacer(Modifier.width(8.dp))
                Text(title, fontWeight = FontWeight.Bold)
            }
            content()
        }
    }
}

@Composable
private fun SwitchSetting(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun DistributorInfoScreen(selectedDistributor: DistributorId, onBack: () -> Unit) {
    val uriHandler = LocalUriHandler.current
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 14.dp, bottom = 28.dp)
    ) {
        item { PageHeader("Sobre as distribuidoras", onBack) }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Como o SONUS escolhe o período", fontWeight = FontWeight.Bold)
                    Text("A data em que o artista recebe depende tanto do reporte das lojas quanto do calendário interno de cada distribuidora. Por isso o app mostra um período recomendado de consulta, e não promete que todo stream daquele intervalo será pago no mesmo fechamento.")
                }
            }
        }

        items(DistributorCatalog.all, key = { it.distributor.name }) { info ->
            val highlighted = info.distributor == selectedDistributor
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (highlighted) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
                )
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(DistributorRules.displayName(info.distributor), fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                        Spacer(Modifier.weight(1f))
                        if (highlighted) AssistChip(onClick = {}, label = { Text("Em uso") })
                    }
                    Text("Frequência: ${info.frequency}")
                    Text("Janela: ${info.payoutWindow}")
                    Text(info.notes, style = MaterialTheme.typography.bodySmall)
                    val royaltyScenarios = RoyaltyReferenceCatalog.scenariosFor(info.distributor)
                    if (royaltyScenarios.isNotEmpty()) {
                        HorizontalDivider()
                        Text("Planos e referência do cálculo", fontWeight = FontWeight.SemiBold)
                        royaltyScenarios.forEach { scenario ->
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .55f)
                            ) {
                                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                    Text(scenario.label, fontWeight = FontWeight.SemiBold)
                                    Text("Artista mantém ${(scenario.artistShare * 100).roundToInt()}% • confiança: ${scenario.confidence}", style = MaterialTheme.typography.bodySmall)
                                    Text(scenario.notes, style = MaterialTheme.typography.bodySmall)
                                    scenario.fixedFeeNote?.let { Text("Taxas/condições: $it", style = MaterialTheme.typography.bodySmall) }
                                }
                            }
                        }
                    }
                    HorizontalDivider()
                    Text("Orientação no SONUS", fontWeight = FontWeight.SemiBold)
                    Text(info.streamSelectionGuide)
                    OutlinedButton(onClick = { uriHandler.openUri(info.helpUrl) }) {
                        Icon(Icons.Default.OpenInNew, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Ajuda oficial")
                    }
                }
            }
        }
    }
}

@Composable
private fun PageHeader(title: String, onBack: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Voltar") }
        Text(title, fontSize = 27.sp, fontWeight = FontWeight.Bold)
    }
}

private fun artistLimitForTier(tier: MembershipTier): Int? = when (commercialTier(tier)) {
    MembershipTier.FREE -> 1
    MembershipTier.PRATA -> 3
    MembershipTier.OURO -> 8
    MembershipTier.DIAMANTE -> null
    else -> 3
}

private fun membershipLabel(tier: MembershipTier): String = when (commercialTier(tier)) {
    MembershipTier.FREE -> "FREE"
    MembershipTier.PRATA -> "PRATA"
    MembershipTier.OURO -> "OURO"
    MembershipTier.DIAMANTE -> "DIAMANTE"
    else -> "PRATA"
}

private fun membershipGradient(tier: MembershipTier): List<Color> = when (commercialTier(tier)) {
    MembershipTier.FREE -> listOf(Color(0xFF50709A), Color(0xFF27384F))
    MembershipTier.PRATA -> listOf(Color(0xFFD8E0E8), Color(0xFF8795A5), Color(0xFF42505F))
    MembershipTier.OURO -> listOf(Color(0xFFFFD76A), Color(0xFFD69A24), Color(0xFF714B0B))
    MembershipTier.DIAMANTE -> listOf(Color(0xFF8AF5FF), Color(0xFF7C7BFF), Color(0xFFD36BFF), Color(0xFFECF8FF))
    else -> listOf(Color(0xFFD8E0E8), Color(0xFF8795A5))
}

@Composable
private fun PlanInnerIcon(tier: MembershipTier, modifier: Modifier = Modifier) {
    when (tier) {
        MembershipTier.FREE -> Canvas(modifier) {
            val w = size.width
            val h = size.height
            val shield = Path().apply {
                moveTo(w * .50f, h * .05f)
                lineTo(w * .88f, h * .18f)
                lineTo(w * .82f, h * .68f)
                lineTo(w * .50f, h * .94f)
                lineTo(w * .18f, h * .68f)
                lineTo(w * .12f, h * .18f)
                close()
            }
            drawPath(shield, Color.White)
            drawCircle(Color(0xFF476990), radius = w * .12f, center = Offset(w * .50f, h * .42f))
        }
        MembershipTier.BRONZE -> Icon(Icons.Default.AutoAwesome, null, tint = Color.White, modifier = modifier)
        MembershipTier.PRATA -> Icon(Icons.Default.Star, null, tint = Color.White, modifier = modifier)
        MembershipTier.OURO -> Canvas(modifier) {
            val w = size.width
            val h = size.height
            val crown = Path().apply {
                moveTo(w * .08f, h * .72f)
                lineTo(w * .18f, h * .30f)
                lineTo(w * .39f, h * .51f)
                lineTo(w * .50f, h * .16f)
                lineTo(w * .61f, h * .51f)
                lineTo(w * .82f, h * .30f)
                lineTo(w * .92f, h * .72f)
                close()
            }
            drawPath(crown, Color.White)
            drawRoundRect(
                color = Color.White,
                topLeft = Offset(w * .12f, h * .75f),
                size = androidx.compose.ui.geometry.Size(w * .76f, h * .12f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(h * .05f, h * .05f)
            )
        }
        MembershipTier.DIAMANTE -> Icon(Icons.Default.Diamond, null, tint = Color.White, modifier = modifier)
    }
}

@Composable
private fun PlanGlyph(tier: MembershipTier, size: androidx.compose.ui.unit.Dp = 24.dp) {
    val shape = when (tier) {
        MembershipTier.FREE -> RoundedCornerShape(8.dp)
        MembershipTier.BRONZE -> CircleShape
        MembershipTier.PRATA -> RoundedCornerShape(9.dp)
        MembershipTier.OURO -> RoundedCornerShape(10.dp)
        MembershipTier.DIAMANTE -> RoundedCornerShape(11.dp)
    }
    Box(
        modifier = Modifier
            .size(size)
            .clip(shape)
            .background(Brush.linearGradient(membershipGradient(tier)))
            .border(1.dp, Color.White.copy(alpha = .34f), shape),
        contentAlignment = Alignment.Center
    ) {
        PlanInnerIcon(tier, Modifier.size(size * .55f))
    }
}

@Composable
private fun OwnerStatusPill() {
    val shape = RoundedCornerShape(50)
    Row(
        modifier = Modifier
            .clip(shape)
            .background(Brush.linearGradient(listOf(Color(0xFF2D7CC7), Color(0xFF173B68))))
            .border(1.dp, Color.White.copy(alpha = .24f), shape)
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Icon(Icons.Default.AdminPanelSettings, null, tint = Color.White, modifier = Modifier.size(13.dp))
        Text("OWNER", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
private fun OwnerProfileBadge(modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(9.dp)
    Box(
        modifier = modifier
            .size(24.dp)
            .clip(shape)
            .background(Brush.linearGradient(listOf(Color(0xFF3D95E8), Color(0xFF1C4F86))))
            .border(1.dp, Color.White.copy(alpha = .35f), shape),
        contentAlignment = Alignment.Center
    ) {
        Icon(Icons.Default.AdminPanelSettings, null, tint = Color.White, modifier = Modifier.size(15.dp))
    }
}

@Composable
private fun PlanStatusPill(tier: MembershipTier) {
    val shape = RoundedCornerShape(50)
    Row(
        modifier = Modifier
            .clip(shape)
            .background(Brush.linearGradient(membershipGradient(tier)))
            .border(1.dp, Color.White.copy(alpha = .22f), shape)
            .padding(horizontal = 7.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        PlanInnerIcon(tier, Modifier.size(12.dp))
        Text(membershipLabel(tier), color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
private fun ProfileAvatarWithTier(
    photoPath: String?,
    avatarId: String? = null,
    tier: MembershipTier,
    owner: Boolean = false,
    size: androidx.compose.ui.unit.Dp
) {
    Box(modifier = Modifier.padding(end = 13.dp, bottom = 7.dp)) {
        ArtistAvatar(photoPath = photoPath, avatarId = avatarId, size = size, fallbackToLogo = true)
        if (owner) {
            OwnerProfileBadge(modifier = Modifier.align(Alignment.BottomEnd).offset(x = 12.dp, y = 6.dp))
        } else {
            PlanProfileBadge(
                tier = tier,
                modifier = Modifier.align(Alignment.BottomEnd).offset(x = 12.dp, y = 6.dp)
            )
        }
    }
}

@Composable
private fun PlanProfileBadge(tier: MembershipTier, modifier: Modifier = Modifier) {
    Box(modifier = modifier) {
        PlanGlyph(tier = tier, size = 24.dp)
    }
}

@Composable
private fun PremiumFeatureMark(tier: MembershipTier) {
    // Selo reutilizável para funções premium; tiers legados são exibidos como Ouro.
    PlanGlyph(tier = tier, size = 20.dp)
}

@Composable
private fun ArtistAvatar(
    photoPath: String?,
    size: androidx.compose.ui.unit.Dp,
    fallbackToLogo: Boolean = false,
    avatarId: String? = null
) {
    val bitmap = remember(photoPath) {
        photoPath?.takeIf { File(it).exists() }?.let { path ->
            runCatching { BitmapFactory.decodeFile(path)?.asImageBitmap() }.getOrNull()
        }
    }
    when {
        bitmap != null -> Image(
            bitmap = bitmap,
            contentDescription = "Foto do artista",
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(size).clip(CircleShape).border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .45f), CircleShape)
        )
        !avatarId.isNullOrBlank() && SonusAvatarCatalog.byId(avatarId) != null -> SonusAvatarArtwork(
            avatarId = avatarId,
            modifier = Modifier.size(size).clip(CircleShape)
        )
        fallbackToLogo -> Image(
            painter = painterResource(R.drawable.sonus_logo_official),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(size).clip(RoundedCornerShape(16.dp))
        )
        else -> Surface(
            modifier = Modifier.size(size),
            shape = CircleShape,
            color = MaterialTheme.colorScheme.primaryContainer
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Person, null, modifier = Modifier.size(size * .58f))
            }
        }
    }
}

private fun saveBackgroundPhoto(context: android.content.Context, uri: Uri, oldPath: String?): String? {
    return runCatching {
        val folder = File(context.filesDir, "backgrounds").apply { mkdirs() }
        val target = File(folder, "premium_background_${System.currentTimeMillis()}.img")
        context.contentResolver.openInputStream(uri)?.use { input ->
            target.outputStream().use { output -> input.copyTo(output) }
        } ?: return null
        oldPath?.let { path -> runCatching { File(path).takeIf { it.exists() }?.delete() } }
        target.absolutePath
    }.getOrNull()
}

private fun saveArtistPhoto(context: android.content.Context, uri: Uri, artistId: String, oldPath: String?): String? {
    return runCatching {
        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        val maxSide = 768
        var sample = 1
        while (bounds.outWidth / sample > maxSide * 2 || bounds.outHeight / sample > maxSide * 2) sample *= 2
        val decoded = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample }) ?: return null
        val ratio = minOf(1f, maxSide.toFloat() / maxOf(decoded.width, decoded.height).coerceAtLeast(1))
        val finalBitmap = if (ratio < 1f) {
            android.graphics.Bitmap.createScaledBitmap(decoded, (decoded.width * ratio).toInt().coerceAtLeast(1), (decoded.height * ratio).toInt().coerceAtLeast(1), true)
        } else decoded
        val folder = File(context.filesDir, "artist_photos").apply { mkdirs() }
        val target = File(folder, "${artistId}_${System.currentTimeMillis()}.jpg")
        target.outputStream().use { output ->
            check(finalBitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, output)) { "Falha ao compactar imagem" }
        }
        if (finalBitmap !== decoded) finalBitmap.recycle()
        decoded.recycle()
        oldPath?.let(::deleteArtistPhoto)
        target.absolutePath
    }.getOrNull()
}

private fun deleteArtistPhoto(path: String?) {
    if (path.isNullOrBlank()) return
    runCatching { File(path).takeIf { it.exists() }?.delete() }
}

@Composable
private fun GradientHero(title: String, value: String, subtitle: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(26.dp))
            .background(Brush.linearGradient(listOf(PulseBlue, PulseCyan, PulsePurple)))
            .padding(22.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(title, color = Color.White.copy(alpha = .84f), fontWeight = FontWeight.SemiBold)
            Text(value, color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.ExtraBold)
            Text(subtitle, color = Color.White.copy(alpha = .9f))
        }
    }
}

@Composable
private fun MetricCard(modifier: Modifier, title: String, value: String, subtitle: String) {
    Card(modifier = modifier) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(title, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .64f))
            Text(value, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .68f))
        }
    }
}

@Composable
private fun HealthCard(modifier: Modifier, health: HealthResult) {
    val accent = healthPerformanceColor(health.performancePercent, health.scoredDays == 0)
    Card(modifier = modifier.border(1.dp, accent.copy(alpha = .35f), RoundedCornerShape(14.dp))) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text("Saúde do projeto", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .64f))
            Text("${health.emoji} ${health.score}", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = accent)
            Text(if (health.scoredDays == 0) "Aguardando atualização" else health.label, style = MaterialTheme.typography.bodySmall)
            health.lastDay?.let {
                Text("Último registro: ${formatNumber(it.streams)} (${if (it.points > 0) "+" else ""}${it.points})", style = MaterialTheme.typography.labelSmall)
            }
            Text("${health.score}/${health.possiblePoints} pontos possíveis até hoje • ${formatPercent(health.performancePercent)}", style = MaterialTheme.typography.labelSmall)
            if (health.missingDays > 0) {
                Text("${health.missingDays} dia(s) sem dados", style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

private fun healthPerformanceColor(percent: Double, noData: Boolean = false): Color = when {
    noData || percent <= 0.0 -> SignalBlack
    percent < 25.0 -> SignalRed
    percent < 45.0 -> SignalPurple
    percent < 65.0 -> SignalOrange
    percent < 85.0 -> SignalGreen
    else -> SignalBlue
}

private fun healthColor(score: Int): Color = when {
    score <= 0 -> SignalBlack
    score <= 20 -> SignalRed
    score <= 40 -> SignalPurple
    score <= 60 -> SignalOrange
    score <= 85 -> SignalGreen
    else -> SignalBlue
}

/**
 * Série diária de Histórico/Análises construída pelo mesmo motor usado em Saldo e Pulso.
 * Registros diários permanecem exatos; no modo acumulado, o primeiro total vira um ritmo
 * médio desde o início do ciclo, evitando tratar todo o acumulado como se tivesse ocorrido
 * em um único dia.
 */
private fun unifiedAnalyticsEntries(
    state: AppState,
    artist: Artist,
    referenceDate: LocalDate = LocalDate.now()
): List<DailyStreamEntry> {
    val snapshots = state.snapshots.filter { it.artistId == artist.id }
    val dailyRecords = state.dailyStreamRecords.filter { it.artistId == artist.id }
    val windows = linkedMapOf<String, CycleWindow>()

    snapshots.forEach { snapshot ->
        val key = "${snapshot.cycleStartIso}|${snapshot.cycleEndIso}"
        windows[key] = CycleWindow(snapshot.cycleStartIso, snapshot.cycleEndIso, "Histórico")
    }
    val current = DistributorRules.cycleFor(artist, referenceDate)
    windows["${current.startIso}|${current.endIso}"] = current

    dailyRecords.forEach { record ->
        val date = runCatching { LocalDate.parse(record.dateIso) }.getOrNull() ?: return@forEach
        val covered = windows.values.any { window ->
            val start = runCatching { LocalDate.parse(window.startIso) }.getOrNull()
            val end = runCatching { LocalDate.parse(window.endIso) }.getOrNull()
            start != null && end != null && !date.isBefore(start) && !date.isAfter(end)
        }
        if (!covered) {
            val derived = DistributorRules.cycleFor(artist, date)
            windows["${derived.startIso}|${derived.endIso}"] = derived
        }
    }

    return windows.values
        .sortedBy { it.startIso }
        .flatMap { window ->
            val start = runCatching { LocalDate.parse(window.startIso) }.getOrNull() ?: return@flatMap emptyList()
            val end = runCatching { LocalDate.parse(window.endIso) }.getOrNull() ?: return@flatMap emptyList()
            val scopedSnapshots = snapshots.filter { snapshotInCycle(it, window) }
            val scopedDaily = dailyRecords.filter { snapshotDateInCycle(it.dateIso, window) }
            StreamMetricsEngine.cycleMetrics(
                scopedSnapshots,
                scopedDaily,
                start,
                end,
                minOf(referenceDate, end),
                entryMode = resolvedStreamEntryMode(artist),
                cycleId = if (window.startIso == artist.financialCycleStartIso) artist.financialCycleId else null
            ).dailyEntries
        }
        .groupBy { it.dateIso }
        .map { (_, sameDate) -> sameDate.last() }
        .sortedBy { it.dateIso }
}

private fun snapshotInCycle(snapshot: StreamSnapshot, cycle: CycleWindow): Boolean = runCatching {
    val date = LocalDate.parse(snapshot.dateIso)
    val start = LocalDate.parse(cycle.startIso)
    val end = LocalDate.parse(cycle.endIso)
    !date.isBefore(start) && !date.isAfter(end)
}.getOrDefault(false)

private fun snapshotDateInCycle(dateIso: String, cycle: CycleWindow): Boolean = runCatching {
    val date = LocalDate.parse(dateIso)
    val start = LocalDate.parse(cycle.startIso)
    val end = LocalDate.parse(cycle.endIso)
    !date.isBefore(start) && !date.isAfter(end)
}.getOrDefault(false)

private fun snapshotComparator(): Comparator<StreamSnapshot> =
    compareBy<StreamSnapshot> { it.dateIso }.thenBy { it.recordedAtEpochMillis }

private fun money(value: Double): String = NumberFormat.getCurrencyInstance(Locale("pt", "BR")).format(value)

private fun signedMoney(value: Double): String = when {
    value > 0.004 -> "+${money(value)}"
    value < -0.004 -> "-${money(abs(value))}"
    else -> money(0.0)
}

private fun formatNumber(value: Long): String = NumberFormat.getIntegerInstance(Locale("pt", "BR")).format(value)

private fun formatDate(iso: String): String = runCatching {
    LocalDate.parse(iso).format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))
}.getOrDefault(iso)

private fun formatYearMonth(month: YearMonth): String = runCatching {
    month.format(DateTimeFormatter.ofPattern("MMMM/yyyy", Locale("pt", "BR")))
        .replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
}.getOrDefault(month.toString())

private fun formatRecordedTime(recordedAtEpochMillis: Long): String {
    if (recordedAtEpochMillis <= 0L) return "Registro antigo"
    return runCatching {
        Instant.ofEpochMilli(recordedAtEpochMillis)
            .atZone(ZoneId.systemDefault())
            .format(DateTimeFormatter.ofPattern("HH:mm"))
    }.getOrDefault("—")
}

private fun formatSnapshotTime(snapshot: StreamSnapshot): String = formatRecordedTime(snapshot.recordedAtEpochMillis)

private fun parseDateInput(input: String): LocalDate? {
    val value = input.trim()
    if (value.isBlank()) return null
    return runCatching { LocalDate.parse(value) }.getOrNull()
        ?: runCatching { LocalDate.parse(value, DateTimeFormatter.ofPattern("dd/MM/yyyy")) }.getOrNull()
}

private fun parseMoneyInput(input: String): Double? {
    val normalized = input.trim().replace("R$", "").replace(" ", "").let { raw ->
        if (raw.contains(',') && raw.contains('.')) raw.replace(".", "").replace(',', '.')
        else raw.replace(',', '.')
    }
    return normalized.toDoubleOrNull()
}

private fun formatPercent(value: Double): String = String.format(Locale("pt", "BR"), "%.1f%%", value)

private fun formatSignedPercent(value: Double): String = when {
    value > 0.05 -> "+${formatPercent(value)}"
    value < -0.05 -> "-${formatPercent(abs(value))}"
    else -> formatPercent(0.0)
}

private fun Double.roundToLongSafe(): Long = if (isFinite()) this.roundToLong() else 0L


@Composable
private fun rememberNetworkAvailable(): Boolean {
    val context = LocalContext.current
    val manager = remember(context) {
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    }
    fun current(): Boolean {
        val network = manager.activeNetwork ?: return false
        val caps = manager.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }
    var available by remember { mutableStateOf(current()) }
    DisposableEffect(manager) {
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                available = current()
            }
            override fun onLost(network: Network) {
                available = current()
            }
            override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
                available = networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                    networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
            }
        }
        runCatching { manager.registerDefaultNetworkCallback(callback) }
        onDispose { runCatching { manager.unregisterNetworkCallback(callback) } }
    }
    return available
}


private tailrec fun Context.findComponentActivityForApp(): ComponentActivity? = when (this) {
    is ComponentActivity -> this
    is ContextWrapper -> baseContext.findComponentActivityForApp()
    else -> null
}
