package com.sonusstudios.streampulse

import com.sonusstudios.streampulse.core.SonusAutoCreateDocument
import android.Manifest

import android.os.Bundle
import android.os.Build
import android.graphics.BitmapFactory
import android.net.Uri
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.TrafficStats
import android.media.MediaCodecList
import android.content.Intent
import android.content.Context
import android.content.ContextWrapper
import android.content.ClipData
import android.content.ClipboardManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.BackHandler
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonusstudios.streampulse.core.*
import com.sonusstudios.streampulse.audio.AudioConversionEngine
import com.sonusstudios.streampulse.audio.AudioConverterProScreen
import com.sonusstudios.streampulse.auth.AuthManager
import com.sonusstudios.streampulse.auth.AuthUser
import com.sonusstudios.streampulse.auth.AccountRole
import com.sonusstudios.streampulse.auth.StreamPulseAuthScreen
import com.sonusstudios.streampulse.ads.StreamPulseAdManager
import com.sonusstudios.streampulse.cloud.CloudAccountManager
import com.sonusstudios.streampulse.cloud.CloudBackupSettings
import com.sonusstudios.streampulse.cloud.CloudCouponSettings
import com.sonusstudios.streampulse.cloud.AccountSecuritySettings
import com.sonusstudios.streampulse.cloud.DeveloperRemotePanel
import com.sonusstudios.streampulse.cloud.DeveloperRemoteSection
import com.sonusstudios.streampulse.cloud.AnalyticsEvent
import com.sonusstudios.streampulse.cloud.SonusUpdateManager
import com.sonusstudios.streampulse.cloud.SonusUpdateDecision
import com.sonusstudios.streampulse.cloud.SonusUpdateInfo
import com.sonusstudios.streampulse.cloud.SonusUpdateDialog
import com.sonusstudios.streampulse.cloud.SonusOwnerUpdatePanel
import com.sonusstudios.streampulse.cloud.SONUS_CURRENT_VERSION_SUMMARY
import com.sonusstudios.streampulse.tools.SonusLiveChrome
import com.sonusstudios.streampulse.tools.PulseHaptics
import com.sonusstudios.streampulse.tools.SonusLockScreenPrefs
import com.sonusstudios.streampulse.tools.SonusStreamOpenTrace
import com.sonusstudios.streampulse.tools.ToolSuiteScreen
import com.sonusstudios.streampulse.tools.ToolHubVariant
import com.sonusstudios.streampulse.tools.ToolId
import com.sonusstudios.streampulse.tools.PulsePlayerScreen
import com.sonusstudios.streampulse.tools.PulsePlayerService
import com.sonusstudios.streampulse.tools.PulsePlayerStatsStore
import com.sonusstudios.streampulse.tools.SonusProUsageStats
import com.sonusstudios.streampulse.tools.PulseCreatorAction
import com.sonusstudios.streampulse.tools.SonusVideoPlayerScreen
import com.sonusstudios.streampulse.tools.SonusBlackBoxScreen
import com.sonusstudios.streampulse.tools.SonusMusicDeveloperPanel
import com.sonusstudios.streampulse.tools.SonusOnlineMusicRepository
import com.sonusstudios.streampulse.tools.SonusUnifiedLrcEntry
import com.sonusstudios.streampulse.tools.SonusUnifiedLrcSource
import com.sonusstudios.streampulse.audio.AudioSourceInfo
import com.sonusstudios.streampulse.audio.AudioTrackTags
import com.sonusstudios.streampulse.data.AppRepository
import com.sonusstudios.streampulse.data.BackupManager
import com.sonusstudios.streampulse.data.BackupPreview
import com.sonusstudios.streampulse.online.CommunityPresenceState
import com.sonusstudios.streampulse.online.PresenceManager
import com.sonusstudios.streampulse.notifications.SonusNotificationCenter
import com.sonusstudios.streampulse.notifications.SonusNotificationItem
import com.sonusstudios.streampulse.notifications.SonusRemoteNotificationBridge
import com.sonusstudios.streampulse.notifications.PremiumUsageEvent
import com.sonusstudios.streampulse.navigation.SonusMainTab
import com.sonusstudios.streampulse.navigation.SonusMainTabConfig
import com.sonusstudios.streampulse.navigation.SonusMainTabPreferences
import com.sonusstudios.streampulse.navigation.SonusMainTabsOrganizerScreen
import com.sonusstudios.streampulse.support.SonusSupportScreen
import com.sonusstudios.streampulse.support.sonusPublicId
import com.sonusstudios.streampulse.stream.SonusStreamCreatorCenter
import com.sonusstudios.streampulse.stream.StreamCenterMode
import com.sonusstudios.streampulse.stream.SonusStreamPlatformRepository
import com.sonusstudios.streampulse.ui.theme.*
import com.sonusstudios.streampulse.ui.avatar.SonusAvatarArtwork
import com.sonusstudios.streampulse.ui.avatar.SonusAvatarCatalog
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import java.text.NumberFormat
import java.io.File
import java.net.URL
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import java.util.UUID
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.roundToLong
import kotlin.math.sin
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

private object AppSessionClock {
    var startedAtMillis: Long = 0L
}

class MainActivity : ComponentActivity() {
    private lateinit var presenceManager: PresenceManager
    private lateinit var repository: AppRepository
    private lateinit var authManager: AuthManager
    private lateinit var cloudManager: CloudAccountManager
    private lateinit var adManager: StreamPulseAdManager
    private var sessionStartedAtMillis: Long = 0L
    private var sessionRxStart: Long = 0L
    private var sessionTxStart: Long = 0L
    private val notificationRouteState = mutableStateOf<String?>(null)
    private val widgetToolState = mutableStateOf<String?>(null)
    private val externalAudioUriState = mutableStateOf<String?>(null)
    private val externalVideoUriState = mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        authManager = AuthManager(applicationContext)
        presenceManager = PresenceManager(applicationContext)
        repository = AppRepository(applicationContext)
        cloudManager = CloudAccountManager()
        adManager = StreamPulseAdManager(applicationContext)
        notificationRouteState.value = intent?.getStringExtra("sonus_notification_route")
        widgetToolState.value = intent?.getStringExtra("sonus_widget_tool")
        externalAudioUriState.value = intent?.takeIf { it.action == Intent.ACTION_VIEW && (it.type?.startsWith("audio/") == true || it.data?.scheme.equals("sonusonline", true)) }?.data?.toString()
        externalVideoUriState.value = intent?.getStringExtra("sonus_external_video_uri")
            ?: intent?.takeIf { it.action == Intent.ACTION_VIEW && (it.type?.startsWith("video/") == true || it.type == "application/x-matroska") }?.data?.toString()
        setContent {
            StreamPulseRoot(
                presenceManager, repository, authManager, cloudManager, adManager,
                notificationRoute = notificationRouteState.value,
                onNotificationRouteConsumed = { notificationRouteState.value = null },
                widgetTool = widgetToolState.value,
                onWidgetToolConsumed = { widgetToolState.value = null },
                externalAudioUri = externalAudioUriState.value,
                onExternalAudioConsumed = { externalAudioUriState.value = null },
                externalVideoUri = externalVideoUriState.value,
                onExternalVideoConsumed = { externalVideoUriState.value = null }
            )
        }
        // Não segura o primeiro frame/splash esperando UMP/AdMob. A monetização inicia
        // depois que a interface já teve tempo de aparecer.
        lifecycleScope.launch {
            delay(3_000L)
            if (!isFinishing && !isDestroyed) adManager.initialize(this@MainActivity)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        notificationRouteState.value = intent.getStringExtra("sonus_notification_route")
        widgetToolState.value = intent.getStringExtra("sonus_widget_tool")
        if (intent.action == Intent.ACTION_VIEW && (intent.type?.startsWith("audio/") == true || intent.data?.scheme.equals("sonusonline", true))) externalAudioUriState.value = intent.data?.toString()
        val routedVideo = intent.getStringExtra("sonus_external_video_uri")
            ?: intent.takeIf { it.action == Intent.ACTION_VIEW && (it.type?.startsWith("video/") == true || it.type == "application/x-matroska") }?.data?.toString()
        if (routedVideo != null) externalVideoUriState.value = routedVideo
    }

    override fun onStart() {
        super.onStart()
        sessionStartedAtMillis = System.currentTimeMillis()
        sessionRxStart = TrafficStats.getUidRxBytes(android.os.Process.myUid()).coerceAtLeast(0L)
        sessionTxStart = TrafficStats.getUidTxBytes(android.os.Process.myUid()).coerceAtLeast(0L)
        AppSessionClock.startedAtMillis = sessionStartedAtMillis
        presenceManager.setAppActive(true)
        lifecycleScope.launch {
            // Deixa o primeiro frame e a autenticação terminarem antes de gravar telemetria local.
            delay(2_000L)
            repository.recordAppOpen(LocalDate.now().toString(), Instant.now().toString())
        }
    }

    override fun onStop() {
        val now = System.currentTimeMillis()
        val duration = (now - sessionStartedAtMillis).coerceAtLeast(0L)
        presenceManager.setAppActive(false)
        AppSessionClock.startedAtMillis = 0L
        val rxNow = TrafficStats.getUidRxBytes(android.os.Process.myUid()).coerceAtLeast(sessionRxStart)
        val txNow = TrafficStats.getUidTxBytes(android.os.Process.myUid()).coerceAtLeast(sessionTxStart)
        lifecycleScope.launch {
            val day = LocalDate.now().toString()
            repository.recordAppUsage(duration, day, Instant.now().toString())
            repository.recordDataUsage((rxNow-sessionRxStart).coerceAtLeast(0L), (txNow-sessionTxStart).coerceAtLeast(0L), day)
        }
        super.onStop()
    }
}

private enum class AppPage {
    PLAYER,
    HIGHLIGHTS,
    TOOLS,
    STREAM,
    BLACK_BOX,
    SETTINGS,
    DEVELOPER,
    PREMIUM,
    SUPPORT,
    STREAM_CREATOR,
    TAB_ORGANIZER,
    NOTIFICATIONS,
    NOTIFICATION_SETTINGS,
    ADD_ARTIST,
    EDIT_ARTIST,
    USAGE,
    AUDIO_CONVERTER,
    GUIDE
}

private fun activityPageTitle(page: AppPage): String = when (page) {
    AppPage.PLAYER -> "Abriu SONUS PLAYER"
    AppPage.HIGHLIGHTS -> "Abriu APLICATIVOS SONUS"
    AppPage.BLACK_BOX -> "Abriu Caixa Preta SONUS"
    AppPage.TOOLS -> "Abriu SONUS VIDEO"
    AppPage.STREAM -> "Abriu SONUS Stream"
    AppPage.SUPPORT -> "Abriu Suporte SONUS"
    AppPage.STREAM_CREATOR -> "Abriu Para artistas do SONUS Stream"
    AppPage.TAB_ORGANIZER -> "Abriu organização das abas"
    AppPage.SETTINGS -> "Abriu Ajustes"
    AppPage.DEVELOPER -> "Abriu o Painel do Desenvolvedor"
    AppPage.PREMIUM -> "Abriu SONUS Premium"
    AppPage.NOTIFICATIONS -> "Abriu Central de Notificações"
    AppPage.NOTIFICATION_SETTINGS -> "Abriu Ajustes de notificações"
    AppPage.ADD_ARTIST -> "Abriu Adicionar artista"
    AppPage.EDIT_ARTIST -> "Abriu Editar artista"
    AppPage.USAGE -> "Abriu Uso do SONUS"
    AppPage.AUDIO_CONVERTER -> "Abriu Conversor de áudio"
    AppPage.GUIDE -> "Abriu Guia do SONUS"
}

private enum class OwnerTestMode {
    OWNER,
    FREE,
    PRATA,
    OURO,
    DIAMANTE
}


private enum class GuestAuthTarget {
    ACCOUNT,
    PREMIUM,
    ADD_ARTIST
}

@Composable
private fun StreamPulseRoot(
    presenceManager: PresenceManager,
    repository: AppRepository,
    authManager: AuthManager,
    cloudManager: CloudAccountManager,
    adManager: StreamPulseAdManager,
    notificationRoute: String? = null,
    onNotificationRouteConsumed: () -> Unit = {},
    widgetTool: String? = null,
    onWidgetToolConsumed: () -> Unit = {},
    externalAudioUri: String? = null,
    onExternalAudioConsumed: () -> Unit = {},
    externalVideoUri: String? = null,
    onExternalVideoConsumed: () -> Unit = {}
) {
    // Não bloqueia a abertura esperando desserialização completa do DataStore.
    // A UI nasce com um estado seguro e recebe o estado real assim que estiver pronto.
    val state by produceState(initialValue = AppState(), repository) {
        repository.state.collect { value = it }
    }
    val appState = state
    val context = LocalContext.current
    val communityPresence by presenceManager.state.collectAsState()
    val authState by authManager.state.collectAsState()
    val guestPrefs = remember(context) { context.getSharedPreferences("sonus_guest_session_v1", Context.MODE_PRIVATE) }
    var guestMode by rememberSaveable { mutableStateOf(guestPrefs.getBoolean("guest_mode", false)) }
    var pendingGuestTargetName by rememberSaveable { mutableStateOf<String?>(null) }
    var pendingPremiumTierName by rememberSaveable { mutableStateOf<String?>(null) }
    var pendingPremiumPeriod by rememberSaveable { mutableStateOf<String?>(null) }
    var splashFinished by remember { mutableStateOf(false) }
    var cloudReadyUid by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        // Se autoplay estiver desligado, a entrada do app cancela qualquer pedido
        // residual de reprodução antes da splash.
        val autoPlay = context.getSharedPreferences("pulse_player_library_v1", Context.MODE_PRIVATE)
            .getBoolean("autoplay", false)
        if (!autoPlay && PulsePlayerService.isRunning) {
            runCatching {
                context.startService(
                    Intent(context, PulsePlayerService::class.java).setAction(PulsePlayerService.ACTION_PAUSE)
                )
            }
        }
        // Mantém a splash visível até a troca real de conteúdo; evita o quadro preto entre animação e app.
        delay(2425)
        splashFinished = true
    }

    LaunchedEffect(authState.user?.uid) {
        if (authState.user != null) {
            guestMode = false
            guestPrefs.edit().putBoolean("guest_mode", false).apply()
        }
    }

    StreamPulseTheme(
        themeMode = appState.preferences.themeMode,
        appFont = appState.preferences.appFont,
        textAppearance = appState.preferences.textAppearance
    ) {
        if (!splashFinished || !authState.ready) {
            StreamPulseSplashScreen()
        } else {
            val signedUser = authState.user
            if (signedUser == null && !guestMode) {
                StreamPulseAuthScreen(
                    authManager = authManager,
                    onContinueAsGuest = {
                        pendingGuestTargetName = null
                        pendingPremiumTierName = null
                        pendingPremiumPeriod = null
                        guestMode = true
                        guestPrefs.edit().putBoolean("guest_mode", true).apply()
                    },
                    showGuestOption = pendingGuestTargetName == null
                )
            } else {
                val isGuest = signedUser == null
                val user = signedUser ?: AuthUser(
                    uid = "guest-local",
                    displayName = "Convidado",
                    email = null,
                    photoUrl = null,
                    role = AccountRole.USER
                )

                if (!isGuest) {
                    val remoteNotificationBridge = remember(user.uid) { SonusRemoteNotificationBridge(context) }
                    DisposableEffect(user.uid) {
                        remoteNotificationBridge.attach(user.uid)
                        onDispose { remoteNotificationBridge.detach() }
                    }
                    LaunchedEffect(user.uid) {
                        try {
                            withContext(Dispatchers.IO) {
                                runCatching { cloudManager.ensureAccount(user.uid, user.displayName, user.email) }
                            }
                            if (!appState.onboardingComplete) {
                                val remote = withContext(Dispatchers.IO) { cloudManager.downloadBackup(user.uid).getOrNull() }
                                if (remote != null) {
                                    try { repository.replaceState(remote.first) } catch (_: Throwable) { }
                                }
                                try { repository.markAppSetupComplete() } catch (_: Throwable) { }
                            }
                            val remotePromotions = withContext(Dispatchers.IO) { cloudManager.loadRemotePromotions(user.uid).getOrNull() }
                            if (remotePromotions != null) {
                                try {
                                    repository.syncRemotePromotions(
                                        tierName = remotePromotions.tierName,
                                        premiumUntil = remotePromotions.premiumUntil,
                                        adFreeUntil = remotePromotions.adFreeUntil,
                                        adMultiplier = remotePromotions.adMultiplier,
                                        adMultiplierUntil = remotePromotions.adMultiplierUntil,
                                        discountPercent = remotePromotions.discountPercent,
                                        discountTierName = remotePromotions.discountTierName,
                                        discountUntil = remotePromotions.discountUntil
                                    )
                                } catch (_: Throwable) { }
                            }
                        } finally {
                            cloudReadyUid = user.uid
                        }
                    }
                    val promoTier = effectivePromotionalTier(appState.preferences)
                    val walletTier = if (user.role == AccountRole.OWNER) MembershipTier.DIAMANTE else promoTier
                    LaunchedEffect(user.uid, appState, cloudReadyUid) {
                        if (cloudReadyUid == user.uid) {
                            delay(1400)
                            withContext(Dispatchers.IO) { cloudManager.uploadBackup(user.uid, appState) }
                        }
                    }
                }

                val pendingTarget = pendingGuestTargetName?.let { runCatching { GuestAuthTarget.valueOf(it) }.getOrNull() }
                val initialPage = when (pendingTarget) {
                    GuestAuthTarget.ACCOUNT -> AppPage.SETTINGS
                    GuestAuthTarget.PREMIUM -> AppPage.PREMIUM
                    GuestAuthTarget.ADD_ARTIST -> AppPage.ADD_ARTIST
                    null -> AppPage.PLAYER
                }

                StreamPulseBackground(
                    themeMode = appState.preferences.themeMode,
                    backgroundPhotoPath = appState.preferences.backgroundPhotoPath
                ) {
                    StreamPulseApp(
                        repository = repository,
                        state = appState,
                        communityPresence = communityPresence,
                        authUser = user,
                        authManager = authManager,
                        cloudManager = cloudManager,
                        adManager = adManager,
                        isGuest = isGuest,
                        initialPage = initialPage,
                        notificationRoute = notificationRoute,
                        onNotificationRouteConsumed = onNotificationRouteConsumed,
                        widgetTool = widgetTool,
                        onWidgetToolConsumed = onWidgetToolConsumed,
                        externalAudioUri = externalAudioUri,
                        onExternalAudioConsumed = onExternalAudioConsumed,
                        externalVideoUri = externalVideoUri,
                        onExternalVideoConsumed = onExternalVideoConsumed,
                        resumePremiumTier = pendingPremiumTierName?.let { runCatching { MembershipTier.valueOf(it) }.getOrNull() },
                        resumePremiumPeriod = pendingPremiumPeriod,
                        onGuestAuthRequired = { target ->
                            pendingGuestTargetName = target.name
                            pendingPremiumTierName = null
                            pendingPremiumPeriod = null
                            guestMode = false
                            guestPrefs.edit().putBoolean("guest_mode", false).apply()
                        },
                        onGuestPremiumPurchase = { tier, period ->
                            pendingGuestTargetName = GuestAuthTarget.PREMIUM.name
                            pendingPremiumTierName = tier.name
                            pendingPremiumPeriod = period
                            guestMode = false
                            guestPrefs.edit().putBoolean("guest_mode", false).apply()
                        }
                    )
                }

                if (!isGuest && pendingGuestTargetName != null) {
                    LaunchedEffect(user.uid, pendingGuestTargetName) {
                        // O destino já foi entregue ao StreamPulseApp acima. Limpa somente
                        // depois da primeira composição para não perder o retorno pós-login.
                        delay(120)
                        pendingGuestTargetName = null
                        pendingPremiumTierName = null
                        pendingPremiumPeriod = null
                    }
                }
            }
        }
    }
}

@Composable
private fun StreamPulseApp(
    repository: AppRepository,
    state: AppState,
    communityPresence: CommunityPresenceState,
    authUser: AuthUser,
    authManager: AuthManager,
    cloudManager: CloudAccountManager,
    adManager: StreamPulseAdManager,
    isGuest: Boolean = false,
    initialPage: AppPage = AppPage.PLAYER,
    notificationRoute: String? = null,
    onNotificationRouteConsumed: () -> Unit = {},
    widgetTool: String? = null,
    onWidgetToolConsumed: () -> Unit = {},
    externalAudioUri: String? = null,
    onExternalAudioConsumed: () -> Unit = {},
    externalVideoUri: String? = null,
    onExternalVideoConsumed: () -> Unit = {},
    resumePremiumTier: MembershipTier? = null,
    resumePremiumPeriod: String? = null,
    onGuestAuthRequired: (GuestAuthTarget) -> Unit = {},
    onGuestPremiumPurchase: (MembershipTier, String) -> Unit = { _, _ -> }
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val online = rememberNetworkAvailable()
    var busyMessage by remember { mutableStateOf<String?>(null) }

    // code122: atualização integrada. A consulta automática é silenciosa e usa cache local;
    // somente uma versão realmente superior e publicada abre o diálogo.
    val updateManager = remember(context) { SonusUpdateManager(context) }
    var offeredUpdate by remember { mutableStateOf<SonusUpdateInfo?>(null) }
    var checkingUpdate by remember { mutableStateOf(false) }

    fun checkSonusUpdate(force: Boolean, showFeedback: Boolean) {
        if (checkingUpdate) return
        checkingUpdate = true
        scope.launch {
            val result = updateManager.checkForUpdate(force)
            checkingUpdate = false
            result.onSuccess { decision ->
                when (decision) {
                    is SonusUpdateDecision.Available -> offeredUpdate = decision.info
                    SonusUpdateDecision.UpToDate -> if (showFeedback) Toast.makeText(context, "Seu SONUS está atualizado.", Toast.LENGTH_SHORT).show()
                    SonusUpdateDecision.Deferred -> if (showFeedback) Toast.makeText(context, "Atualização já verificada. Você adiou esta versão recentemente.", Toast.LENGTH_SHORT).show()
                    SonusUpdateDecision.SkippedByCache -> if (showFeedback) Toast.makeText(context, "Verificação recente em cache. Use novamente para forçar a consulta.", Toast.LENGTH_SHORT).show()
                }
            }.onFailure { error ->
                if (showFeedback) Toast.makeText(context, error.message ?: "Não foi possível checar atualizações agora.", Toast.LENGTH_LONG).show()
            }
        }
    }

    LaunchedEffect(Unit) {
        delay(900)
        checkSonusUpdate(force = false, showFeedback = false)
    }

    DisposableEffect(authUser.uid, context) {
        val activity = context.findComponentActivityForApp()
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME && !isGuest) {
                scope.launch(Dispatchers.IO) { cloudManager.touchActivity(authUser.uid) }
            }
        }
        activity?.lifecycle?.addObserver(observer)
        onDispose { activity?.lifecycle?.removeObserver(observer) }
    }

    // O SONUS é uma suíte de criação: o usuário pode usar Player e Ferramentas
    // sem cadastrar artista.
    val hasArtistProfile = !isGuest && state.artists.isNotEmpty()
    val creatorFallbackArtist = remember(state.preferences.creatorAudioPreset) {
        Artist(
            id = "pulse-studio-local",
            name = "Criador",
            createdAtIso = LocalDate.now().toString(),
            audioPreset = state.preferences.creatorAudioPreset
        )
    }

    var page by rememberSaveable(authUser.uid) { mutableStateOf(initialPage) }
    LaunchedEffect(externalVideoUri) {
        if (externalVideoUri != null) page = AppPage.TOOLS
    }
    var videoFullscreen by rememberSaveable { mutableStateOf(false) }
    var planDialogMinTier by remember { mutableStateOf<MembershipTier?>(null) }
    var selectedPlanFromGate by remember { mutableStateOf<MembershipTier?>(null) }
    val mainTabsPrefs = remember(context) { SonusMainTabPreferences(context) }
    var mainTabsConfig by remember { mutableStateOf(mainTabsPrefs.load()) }
    var editingArtistId by rememberSaveable { mutableStateOf<String?>(null) }
    var requestedToolName by rememberSaveable { mutableStateOf<String?>(null) }
    var requestedLrcTrackId by rememberSaveable { mutableStateOf<Long?>(null) }
    var requestedLrcTitle by rememberSaveable { mutableStateOf("") }
    var requestedLrcArtist by rememberSaveable { mutableStateOf("") }
    var requestedLrcAudioUri by rememberSaveable { mutableStateOf<String?>(null) }
    var requestedDeveloperModule by rememberSaveable { mutableStateOf<String?>(null) }
    var pendingOwnerLrc by rememberSaveable { mutableStateOf<String?>(null) }
    val roleCache = remember { context.getSharedPreferences("sonus_authority_cache_v1", Context.MODE_PRIVATE) }
    LaunchedEffect(authUser.uid, authUser.role, online) {
        if (!isGuest && online && authUser.uid.isNotBlank()) roleCache.edit().putString("uid", authUser.uid).putString("role", authUser.role.name).apply()
    }
    val cachedOwner = !online && roleCache.getString("uid", null) == authUser.uid && roleCache.getString("role", null) == AccountRole.OWNER.name
    val isOwner = authUser.role == AccountRole.OWNER || cachedOwner
    val isSupport = authUser.role == AccountRole.SUPPORT
    val ownerTestPrefs = remember(authUser.uid) { context.getSharedPreferences("sonus_owner_test_mode_v2", Context.MODE_PRIVATE) }
    var ownerTestModeName by remember(authUser.uid) {
        mutableStateOf(ownerTestPrefs.getString("mode_${authUser.uid}", OwnerTestMode.OWNER.name) ?: OwnerTestMode.OWNER.name)
    }
    val ownerTestMode = if (isOwner) runCatching { OwnerTestMode.valueOf(ownerTestModeName) }.getOrDefault(OwnerTestMode.OWNER) else OwnerTestMode.FREE
    val membershipTier = if (isGuest) MembershipTier.FREE else if (isOwner) {
        when (ownerTestMode) {
            OwnerTestMode.OWNER -> MembershipTier.DIAMANTE
            OwnerTestMode.FREE -> MembershipTier.FREE
            OwnerTestMode.PRATA -> MembershipTier.PRATA
            OwnerTestMode.OURO -> MembershipTier.OURO
            OwnerTestMode.DIAMANTE -> MembershipTier.DIAMANTE
        }
    } else effectivePromotionalTier(state.preferences)
    val ownerUnlimited = isOwner && ownerTestMode == OwnerTestMode.OWNER
    val pulseCoins = state.preferences.pulseMonthlyCoins + state.preferences.pulseBonusCoins
    val notificationItems by SonusNotificationCenter.items.collectAsState()
    val premiumUsageEvents by SonusNotificationCenter.usageEvents.collectAsState()
    val unreadNotifications = notificationItems.count { !it.read }
    LaunchedEffect(authUser.uid, membershipTier, state.preferences.pulseCoinsPeriod, state.preferences.pulseUsageTierName) {
        repository.ensurePulseWallet(
            uid = authUser.uid,
            monthlyAllowance = pulseMonthlyCoinAllowance(membershipTier),
            tierName = membershipTier.name
        )
    }
    val adFree = ownerUnlimited || membershipTier != MembershipTier.FREE ||
        ((state.preferences.adFreeUntilEpochMillis ?: 0L) > System.currentTimeMillis())

    val watchFreeUseRewarded: () -> Unit = {
        val commercial = commercialTier(membershipTier)
        val paidEligible = commercial == MembershipTier.PRATA || commercial == MembershipTier.OURO
        val quotaExhausted = state.preferences.pulseMonthlyCoins <= 0
        when {
            ownerUnlimited || commercial == MembershipTier.DIAMANTE ->
                Toast.makeText(context, "Seu plano já possui ferramentas ilimitadas.", Toast.LENGTH_SHORT).show()
            paidEligible && !quotaExhausted ->
                Toast.makeText(context, "Use primeiro suas Moedas SONUS mensais. Anúncios extras ficam disponíveis quando a cota acabar.", Toast.LENGTH_LONG).show()
            state.preferences.pulseBonusCoins >= 10 ->
                Toast.makeText(context, "Limite mensal de +10 Moedas SONUS por anúncios atingido.", Toast.LENGTH_SHORT).show()
            else -> {
                val activity = context.findComponentActivityForApp()
                if (activity == null) {
                    Toast.makeText(context, "Não foi possível abrir o anúncio agora.", Toast.LENGTH_SHORT).show()
                } else {
                    adManager.showRewarded(
                        activity = activity,
                        ownerOrAdFree = false,
                        forceTestUnit = isOwner,
                        onReward = {
                            scope.launch {
                                repository.addPulseBonusCoins(authUser.uid, 1)
                                SonusNotificationCenter.add(
                                    context,
                                    title = "+1 Moeda SONUS liberada",
                                    body = "Anúncio concluído. Sua carteira recebeu +1 moeda.",
                                    category = "PREMIUM",
                                    route = "PREMIUM",
                                    importantExternal = false
                                )
                                if (!isGuest) cloudManager.track(authUser.uid, AnalyticsEvent("Rewarded Ad • +1 Moeda SONUS", "ads", membershipTier.name, success = true))
                            }
                        },
                        onUnavailable = { message -> Toast.makeText(context, message, Toast.LENGTH_SHORT).show() }
                    )
                }
            }
        }
    }

    // Compatibilidade de assinatura com telas antigas. O Passe SONUS 24h foi retirado
    // do modelo comercial atual: anúncios recompensados agora servem apenas para
    // liberar +1 Moeda SONUS. No Prata/Ouro, anúncios extras só ficam disponíveis após esgotar a cota e respeitam o teto mensal.
    val requestFeaturePass24h: (PulseFeaturePass, () -> Unit, (String) -> Unit) -> Unit = { _, _, onUnavailable ->
        onUnavailable("O Passe SONUS 24h foi descontinuado. Use suas Moedas SONUS ou o benefício do seu plano.")
    }

    val artist = if (isGuest) creatorFallbackArtist
    else state.artists.firstOrNull { it.id == state.selectedArtistId } ?: state.artists.firstOrNull() ?: creatorFallbackArtist
    val topLevelOrder = buildList {
        add(AppPage.PLAYER)
        mainTabsConfig.order.filter { it in mainTabsConfig.enabled }.forEach { tab ->
            when (tab) {
                SonusMainTab.HIGHLIGHTS -> add(AppPage.HIGHLIGHTS)
                SonusMainTab.VIDEO -> add(AppPage.TOOLS)
                SonusMainTab.STREAM -> add(AppPage.STREAM)
                }
        }
        add(AppPage.SETTINGS)
    }.distinct()
    val topLevelPages = topLevelOrder.toSet()
    val backStack = remember { mutableStateListOf<AppPage>() }
    
    val navigate: (AppPage) -> Unit = { target ->
        if (page != target) {
            if (target == AppPage.STREAM) SonusStreamOpenTrace.markTap()
            backStack.add(page)
            page = target
            scope.launch {
                busyMessage = "Carregando dados..."
                delay(180)
                busyMessage = null
            }
        }
    }
    val navigateTopLevel: (AppPage) -> Unit = { target ->
        if (page != target) {
            if (target == AppPage.STREAM) SonusStreamOpenTrace.markTap()
            backStack.clear()
            page = target
        }
    }
    LaunchedEffect(notificationRoute, authUser.uid) {
        if (notificationRoute == "PRO_GATE") {
            planDialogMinTier = MembershipTier.PRATA
            onNotificationRouteConsumed()
            return@LaunchedEffect
        }
        val target = when (notificationRoute) {
            "PREMIUM" -> AppPage.PREMIUM
            "PLAYER" -> AppPage.PLAYER
            "HIGHLIGHTS" -> AppPage.HIGHLIGHTS
            "TOOLS" -> AppPage.TOOLS
            "BLACK_BOX" -> AppPage.BLACK_BOX
            "NOTIFICATIONS" -> AppPage.NOTIFICATIONS
            "SUPPORT" -> AppPage.SUPPORT
            "STREAM" -> AppPage.STREAM
            "STREAM_CREATOR" -> AppPage.STREAM_CREATOR
            else -> null
        }
        if (target != null) navigateTopLevel(target)
        if (notificationRoute != null) onNotificationRouteConsumed()
    }
    LaunchedEffect(widgetTool, authUser.uid) {
        if (!widgetTool.isNullOrBlank()) {
            requestedToolName = widgetTool
            navigateTopLevel(AppPage.HIGHLIGHTS)
            onWidgetToolConsumed()
        }
    }
    val requestAddArtist: () -> Unit = {
        if (isGuest) {
            Toast.makeText(context, "Entre para salvar e proteger seus dados.", Toast.LENGTH_LONG).show()
            onGuestAuthRequired(GuestAuthTarget.ADD_ARTIST)
        } else {
            val limit = artistLimitForTier(membershipTier)
            val allowed = ownerUnlimited || limit == null || state.artists.size < limit
            if (allowed) {
                navigate(AppPage.ADD_ARTIST)
            } else {
                Toast.makeText(
                    context,
                    "Seu plano ${membershipLabel(membershipTier)} permite até $limit artista${if (limit == 1) "" else "s"}. Seus perfis atuais são preservados.",
                    Toast.LENGTH_LONG
                ).show()
                navigate(AppPage.PREMIUM)
            }
        }
    }
    val goBack: () -> Unit = {
        page = if (backStack.isNotEmpty()) backStack.removeAt(backStack.lastIndex)
        else if (page != AppPage.PLAYER) AppPage.PLAYER
        else page
    }


    planDialogMinTier?.let { minimumTier ->
        ProPlanChoiceDialog(
            minimumTier = minimumTier,
            onDismiss = { planDialogMinTier = null },
            onChoose = { tier ->
                selectedPlanFromGate = tier
                planDialogMinTier = null
                navigate(AppPage.PREMIUM)
            }
        )
    }

    BackHandler(enabled = (page != AppPage.PLAYER || backStack.isNotEmpty())) {
        goBack()
    }

    LaunchedEffect(page, authUser.uid, membershipTier, artist.id) {
        withContext(Dispatchers.IO) {
            if (!isGuest) cloudManager.track(authUser.uid, AnalyticsEvent("Página: ${page.name}", "page", membershipTier.name))
            repository.addActivity(
                UserActivityRecord(
                    id = UUID.randomUUID().toString(),
                    artistId = artist.id.takeIf { hasArtistProfile },
                    title = activityPageTitle(page),
                    category = "page"
                )
            )
        }
    }

    DisposableEffect(page) {
        val feature = when (page) {
            AppPage.PLAYER -> "SONUS PLAYER"
            AppPage.TOOLS -> "SONUS VIDEO"
            AppPage.STREAM -> "SONUS Stream"
            AppPage.HIGHLIGHTS -> "APLICATIVOS SONUS"
            AppPage.BLACK_BOX -> "Caixa Preta SONUS"
            AppPage.SETTINGS, AppPage.USAGE, AppPage.DEVELOPER, AppPage.PREMIUM, AppPage.SUPPORT, AppPage.STREAM_CREATOR, AppPage.TAB_ORGANIZER, AppPage.NOTIFICATIONS -> "Ajustes"
            else -> "Outros"
        }
        val started = System.currentTimeMillis()
        onDispose {
            val elapsed = (System.currentTimeMillis()-started).coerceAtLeast(0L)
            scope.launch { repository.recordFeatureUsage(feature, elapsed, LocalDate.now().toString()) }
        }
    }

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            containerColor = Color.Transparent,
            bottomBar = {
                // O SONUS PLAYER é a Home de música do SONUS, mas a navegação principal
                // permanece visível para que nenhuma área do app fique escondida.
                if (page in topLevelPages && !(page == AppPage.TOOLS && videoFullscreen) && !SonusLiveChrome.hideBottomBar) {
                    val navBarColor = when(mainTabsConfig.barStyle) {
                        "SONUS" -> Color(0xFF071A35); "NIGHT" -> Color(0xFF061224); "GRAPHITE" -> Color(0xFF202126); "PURPLE" -> Color(0xFF17102E); "DYNAMIC" -> MaterialTheme.colorScheme.surface; else -> Color.Black
                    }
                    NavigationBar(containerColor = navBarColor, tonalElevation = 0.dp, modifier = Modifier.height(68.dp)) {
                        topLevelOrder.forEach { navPage ->
                            val (label, icon) = when (navPage) {
                                AppPage.PLAYER -> "Música" to Icons.Default.Headphones
                                AppPage.HIGHLIGHTS -> "Aplicativos" to Icons.Default.AutoAwesome
                                AppPage.TOOLS -> "Vídeo" to Icons.Default.VideoLibrary
                                AppPage.STREAM -> "Stream" to Icons.Default.GraphicEq
                                AppPage.SETTINGS -> "Ajustes" to Icons.Default.Settings
                                else -> "SONUS" to Icons.Default.Apps
                            }
                            BottomNavItem(page, navPage, label, icon, navigateTopLevel, if(navPage==AppPage.SETTINGS) unreadNotifications else 0)
                        }
                    }
                }
            }
        ) { scaffoldPadding ->
            // Live no ar: a barra inferior some e, ao reaparecer por alguns segundos, fica POR CIMA da imagem (sem mexer no layout).
            val padding = if (SonusLiveChrome.onAir) PaddingValues(0.dp) else scaffoldPadding
            AnimatedContent(
                targetState = page,
                transitionSpec = {
                    val forward = targetState.ordinal >= initialState.ordinal
                    val enter = slideInHorizontally(tween(220)) { full -> if (forward) full / 5 else -full / 5 } + fadeIn(tween(180))
                    val exit = slideOutHorizontally(tween(180)) { full -> if (forward) -full / 6 else full / 6 } + fadeOut(tween(140))
                    enter togetherWith exit
                },
                label = "page-transition",
                modifier = Modifier
                    .padding(padding)
                    .fillMaxSize()
            ) { targetPage ->
                when (targetPage) {
                    AppPage.PLAYER -> PulsePlayerScreen(
                        membershipTier = membershipTier,
                        preferences = state.preferences,
                        ownerUnlimited = ownerUnlimited,
                        onBack = { (context as? android.app.Activity)?.finish() },
                        externalAudioUri = externalAudioUri,
                        onExternalAudioConsumed = onExternalAudioConsumed,
                        onUnlockFeature24h = requestFeaturePass24h,
                        onRequestPlan = { tier -> planDialogMinTier = tier },
                        onStreamCreator = { if (!isGuest) navigate(AppPage.STREAM_CREATOR) else onGuestAuthRequired(GuestAuthTarget.ACCOUNT) },
                        onTrack = { name, success, duration ->
                            scope.launch {
                                withContext(Dispatchers.IO) {
                                    if (!isGuest) cloudManager.track(authUser.uid, AnalyticsEvent(name, "player", membershipTier.name, success, duration))
                                    repository.addActivity(
                                        UserActivityRecord(
                                            id = UUID.randomUUID().toString(),
                                            artistId = artist.id.takeIf { hasArtistProfile },
                                            title = name,
                                            category = "player",
                                            success = success,
                                            durationMs = duration
                                        )
                                    )
                                }
                            }
                        },
                        onCreatorAction = { action ->
                            // O antigo Studio foi descontinuado. Atalhos do Creator Mode
                            // agora desembocam nas ferramentas preservadas de DESTAQUES SONUS.
                            requestedToolName = when (action) {
                                PulseCreatorAction.ANALYZER -> ToolId.SONUS_LAB.name
                                PulseCreatorAction.CUTTER -> ToolId.CUTTER.name
                                PulseCreatorAction.CONVERTER -> null
                                PulseCreatorAction.PITCH -> ToolId.PULSE_TUNE.name
                                PulseCreatorAction.VOCAL -> ToolId.VOICE_CLEANER.name
                                PulseCreatorAction.METADATA -> ToolId.METADATA.name
                                PulseCreatorAction.MERGE -> ToolId.MERGE.name
                                PulseCreatorAction.VIDEO_AUDIO -> ToolId.VIDEO_AUDIO.name
                            }
                            if (action == PulseCreatorAction.CONVERTER) navigate(AppPage.AUDIO_CONVERTER)
                            else navigateTopLevel(AppPage.HIGHLIGHTS)
                        },
                        adManager = adManager,
                        onCreateLrc = { fileId, title, artistName, audioUrl ->
                            if (!isGuest) {
                                requestedLrcTrackId = fileId
                                requestedLrcTitle = title
                                requestedLrcArtist = artistName
                                requestedLrcAudioUri = audioUrl
                                requestedToolName = ToolId.LRC_EDITOR.name
                                navigateTopLevel(AppPage.HIGHLIGHTS)
                            } else onGuestAuthRequired(GuestAuthTarget.ACCOUNT)
                        }
                    )

                    AppPage.STREAM -> PulsePlayerScreen(
                        membershipTier = membershipTier,
                        preferences = state.preferences,
                        ownerUnlimited = ownerUnlimited,
                        onBack = goBack,
                        onUnlockFeature24h = requestFeaturePass24h,
                        onRequestPlan = { tier -> planDialogMinTier = tier },
                        onStreamCreator = { if (!isGuest) navigate(AppPage.STREAM_CREATOR) else onGuestAuthRequired(GuestAuthTarget.ACCOUNT) },
                        onOpenFullPlayerFromStream = { navigateTopLevel(AppPage.PLAYER) },
                        onTrack = { name, success, duration -> scope.launch { if (!isGuest) cloudManager.track(authUser.uid, AnalyticsEvent(name, "stream", membershipTier.name, success, duration)) } },
                        onCreatorAction = { },
                        initialSection = "ONLINE",
                        adManager = adManager,
                        onCreateLrc = { fileId, title, artistName, audioUrl ->
                            if (!isGuest) {
                                requestedLrcTrackId = fileId
                                requestedLrcTitle = title
                                requestedLrcArtist = artistName
                                requestedLrcAudioUri = audioUrl
                                requestedToolName = ToolId.LRC_EDITOR.name
                                navigateTopLevel(AppPage.HIGHLIGHTS)
                            } else onGuestAuthRequired(GuestAuthTarget.ACCOUNT)
                        }
                    )


                    AppPage.HIGHLIGHTS -> ToolSuiteScreen(
                        state = state,
                        artist = artist,
                        pulseCoins = pulseCoins,
                        unlimited = ownerUnlimited || membershipTier == MembershipTier.DIAMANTE,
                        membershipTier = membershipTier,
                        preferences = state.preferences,
                        onAudioConverter = { navigate(AppPage.AUDIO_CONVERTER) },
                        onOpenBlackBox = { navigate(AppPage.BLACK_BOX) },
                        onSpendCoins = { amount ->
                            if (ownerUnlimited || membershipTier == MembershipTier.DIAMANTE) true
                            else repository.consumePulseCoins(authUser.uid, amount)
                        },
                        onWatchRewardedAd = watchFreeUseRewarded,
                        onUnlockFeature24h = requestFeaturePass24h,
                        onTrack = { name, success, duration ->
                            scope.launch {
                                withContext(Dispatchers.IO) {
                                    if (!isGuest) cloudManager.track(authUser.uid, AnalyticsEvent(name, "tool", membershipTier.name, success, duration))
                                    repository.addActivity(UserActivityRecord(id = UUID.randomUUID().toString(), artistId = artist.id.takeIf { hasArtistProfile }, title = name, category = "tool", success = success, durationMs = duration))
                                }
                            }
                        },
                        hubVariant = ToolHubVariant.HIGHLIGHTS,
                        initialTool = requestedToolName?.let { name -> runCatching { ToolId.valueOf(name) }.getOrDefault(ToolId.HUB) } ?: ToolId.HUB,
                        onInitialToolConsumed = { requestedToolName = null },
                        unreadNotifications = unreadNotifications,
                        onNotifications = { navigate(AppPage.NOTIFICATIONS) },
                        onPremiumUseRecorded = { name -> SonusNotificationCenter.recordPremiumUse(context, name) },
                        onRequestPlan = { tier -> planDialogMinTier = tier },
                        ownerAccess = isOwner,
                        onOwnerSaveLrc = { fileId, lrc -> cloudManager.saveSonusMusicTrackOverride(fileId, mapOf("lyrics" to lrc, "lyricsFormat" to "LRC")) },
                        onOpenOwnerSonusMusic = { lrc ->
                            if (isOwner) {
                                pendingOwnerLrc = lrc
                                requestedDeveloperModule = DeveloperModule.SONUS_MUSIC.name
                                navigate(AppPage.DEVELOPER)
                            }
                        },
                        initialLrcTrackId = requestedLrcTrackId,
                        initialLrcTitle = requestedLrcTitle,
                        initialLrcArtist = requestedLrcArtist,
                        initialLrcAudioUri = requestedLrcAudioUri,
                        onInitialLrcSeedConsumed = {
                            requestedLrcTrackId = null
                            requestedLrcTitle = ""
                            requestedLrcArtist = ""
                            requestedLrcAudioUri = null
                        }
                    )


                    AppPage.TOOLS -> SonusVideoPlayerScreen(
                        preferences = state.preferences,
                        onFullscreenChange = { videoFullscreen = it },
                        externalVideoUri = externalVideoUri,
                        onExternalVideoConsumed = onExternalVideoConsumed,
                        onTrack = { name, success, duration ->
                            scope.launch {
                                withContext(Dispatchers.IO) {
                                    if (!isGuest) cloudManager.track(authUser.uid, AnalyticsEvent(name, "video", membershipTier.name, success, duration))
                                    repository.addActivity(
                                        UserActivityRecord(
                                            id = UUID.randomUUID().toString(),
                                            artistId = artist.id.takeIf { hasArtistProfile },
                                            title = name,
                                            category = "video",
                                            success = success,
                                            durationMs = duration
                                        )
                                    )
                                }
                            }
                        }
                    )

                    AppPage.BLACK_BOX -> {
                        val blackBoxAllowed = isOwner || commercialTier(membershipTier).ordinal >= MembershipTier.PRATA.ordinal
                        if (blackBoxAllowed) {
                            SonusBlackBoxScreen(onBack = goBack)
                        } else {
                            Column(
                                modifier = Modifier.fillMaxSize().padding(24.dp),
                                verticalArrangement = Arrangement.Center,
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(Icons.Default.Security, null, modifier = Modifier.size(56.dp), tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.height(14.dp))
                                Text("Caixa Preta SONUS", fontSize = 24.sp, fontWeight = FontWeight.Black)
                                Spacer(Modifier.height(8.dp))
                                Text("Recurso PRO disponível a partir do plano Prata.", textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .68f))
                                Spacer(Modifier.height(18.dp))
                                Button(onClick = { planDialogMinTier = MembershipTier.PRATA; navigate(AppPage.PREMIUM) }) {
                                    Icon(Icons.Default.WorkspacePremium, null)
                                    Spacer(Modifier.width(7.dp))
                                    Text("Conhecer o Prata")
                                }
                            }
                        }
                    }

                    AppPage.SETTINGS -> SettingsScreen(
                        state = state,
                        selectedArtist = artist,
                        membershipTier = membershipTier,
                        authUser = authUser,
                        isGuest = isGuest,
                        isOwner = isOwner,
                        isSupport = isSupport,
                        ownerTestMode = ownerTestMode,
                        repository = repository,
                        authManager = authManager,
                        cloudManager = cloudManager,
                        adManager = adManager,
                        onGuestLogin = { onGuestAuthRequired(GuestAuthTarget.ACCOUNT) },
                        onDeveloper = { if (isOwner) navigate(AppPage.DEVELOPER) },
                        onSupport = { if (!isGuest) navigate(AppPage.SUPPORT) else onGuestAuthRequired(GuestAuthTarget.ACCOUNT) },
                        onStreamCreator = { if (!isGuest) navigate(AppPage.STREAM_CREATOR) else onGuestAuthRequired(GuestAuthTarget.ACCOUNT) },
                        onOrganizeTabs = { navigate(AppPage.TAB_ORGANIZER) },
                        onSelect = { scope.launch { repository.selectArtist(it) } },
                        onAddArtist = requestAddArtist,
                        onEditArtist = { id -> editingArtistId = id; navigate(AppPage.EDIT_ARTIST) },
                        onArtistUpdate = { updated -> scope.launch { repository.updateArtist(updated) } },
                        onDeleteArtist = { id -> scope.launch { repository.deleteArtist(id) } },
                        onRestoreState = { restored -> scope.launch { repository.replaceState(restored) } },
                        onPreferencesChange = { prefs -> scope.launch { repository.updatePreferences(prefs) } },
                        onPremium = { planDialogMinTier = MembershipTier.PRATA },
                        onUsage = { navigate(AppPage.USAGE) },
                        onNotificationCenter = { navigate(AppPage.NOTIFICATIONS) },
                        onNotificationSettings = { navigate(AppPage.NOTIFICATION_SETTINGS) },
                        onCheckUpdate = { checkSonusUpdate(force = true, showFeedback = true) },
                        unreadNotifications = unreadNotifications,
                        onSignOut = { scope.launch { authManager.signOut(context) } },
                        onReset = {
                            scope.launch {
                                busyMessage = "Apagando dados locais..."
                                delay(300)
                                repository.resetAll()
                                delay(180)
                                busyMessage = null
                            }
                        }
                    )

                    AppPage.SUPPORT -> SonusSupportScreen(
                        user = authUser,
                        technicalContext = mapOf(
                            "appVersion" to "${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})",
                            "plan" to membershipTier.name,
                            "android" to Build.VERSION.RELEASE,
                            "device" to "${Build.MANUFACTURER} ${Build.MODEL}",
                            "page" to page.name
                        ),
                        onBack = goBack
                    )

                    AppPage.STREAM_CREATOR -> SonusStreamCreatorCenter(
                        user = authUser,
                        tier = membershipTier,
                        suggestedArtistName = state.artists.firstOrNull()?.name.orEmpty(),
                        onBack = goBack
                    )

                    AppPage.TAB_ORGANIZER -> SonusMainTabsOrganizerScreen(
                        initial = mainTabsConfig,
                        onSave = { config -> mainTabsConfig = config; mainTabsPrefs.save(config) },
                        onBack = goBack
                    )

                    AppPage.DEVELOPER -> {
                        if (isOwner) {
                            DeveloperPanelScreen(
                                authUser = authUser,
                                testMode = ownerTestMode,
                                onTestModeChange = { mode ->
                                    ownerTestModeName = mode.name
                                    if (isOwner && authUser.uid.isNotBlank()) {
                                        ownerTestPrefs.edit().putString("mode_${authUser.uid}", mode.name).apply()
                                    }
                                },
                                onRefreshRole = { authManager.refreshRole() },
                                adManager = adManager,
                                initialModuleName = requestedDeveloperModule,
                                pendingLrc = pendingOwnerLrc,
                                onPendingLrcConsumed = { pendingOwnerLrc = null },
                                onInitialModuleConsumed = { requestedDeveloperModule = null },
                                onOpenLrcEditor = {
                                    requestedToolName = ToolId.LRC_EDITOR.name
                                    navigate(AppPage.HIGHLIGHTS)
                                },
                                onBack = goBack
                            )
                        } else {
                            LaunchedEffect(Unit) { goBack() }
                        }
                    }

                    AppPage.PREMIUM -> PremiumScreen(
                        membershipTier = membershipTier,
                        premiumExpiresAt = state.preferences.premiumExpiresAtEpochMillis,
                        premiumUsesRemaining = pulseCoins,
                        usageEvents = premiumUsageEvents,
                        accountId = authUser.uid.takeUnless { isGuest },
                        onBack = { selectedPlanFromGate = null; goBack() }
                    )

                    AppPage.NOTIFICATIONS -> SonusNotificationCenterScreen(
                        items = notificationItems,
                        onBack = goBack,
                        onOpenRoute = { route ->
                            when (route) {
                                "PREMIUM" -> navigate(AppPage.PREMIUM)
                                "SUPPORT" -> navigate(AppPage.SUPPORT)
                                "STREAM_CREATOR" -> navigate(AppPage.STREAM_CREATOR)
                                else -> Unit
                            }
                        }
                    )

                    AppPage.NOTIFICATION_SETTINGS -> SonusNotificationSettingsScreen(onBack = goBack)

                    AppPage.ADD_ARTIST -> AddArtistScreen(
                        membershipTier = membershipTier,
                        isOwner = ownerUnlimited,
                        onPremium = { navigate(AppPage.PREMIUM) },
                        onBack = goBack,
                        onCreate = { name, photoPath, avatarId ->
                            scope.launch {
                                busyMessage = "Adicionando artista..."
                                delay(300)
                                repository.addArtist(
                                    Artist(
                                        id = UUID.randomUUID().toString(),
                                        name = name.trim(),
                                        createdAtIso = LocalDate.now().toString(),
                                        photoPath = photoPath,
                                        avatarId = avatarId
                                    )
                                )
                                backStack.clear()
                                page = AppPage.SETTINGS
                                delay(180)
                                busyMessage = null
                            }
                        }
                    )

                    AppPage.EDIT_ARTIST -> EditArtistScreen(
                        artist = state.artists.firstOrNull { it.id == editingArtistId } ?: artist,
                        membershipTier = membershipTier,
                        isOwner = ownerUnlimited,
                        onPremium = { navigate(AppPage.PREMIUM) },
                        onBack = goBack,
                        onSave = { updated ->
                            scope.launch {
                                busyMessage = "Salvando artista..."
                                delay(260)
                                repository.updateArtist(updated)
                                backStack.clear()
                                page = AppPage.SETTINGS
                                delay(160)
                                busyMessage = null
                            }
                        },
                        onDelete = {
                            scope.launch {
                                busyMessage = "Removendo artista..."
                                delay(260)
                                repository.deleteArtist(editingArtistId ?: artist.id)
                                backStack.clear()
                                page = AppPage.SETTINGS
                                delay(160)
                                busyMessage = null
                            }
                        }
                    )

                    AppPage.USAGE -> AppUsageScreen(
                        preferences = state.preferences,
                        membershipTier = membershipTier,
                        isOwner = isOwner && ownerTestMode == OwnerTestMode.OWNER,
                        authUser = authUser,
                        usageEvents = premiumUsageEvents,
                        onBack = goBack,
                        onClearUsage = { scope.launch { repository.clearAppUsageStats() } }
                    )


                    AppPage.AUDIO_CONVERTER -> AudioConverterProScreen(
                        artist = artist,
                        pulseCoins = pulseCoins,
                        membershipTier = membershipTier,
                        coinUnlimited = ownerUnlimited || membershipTier == MembershipTier.DIAMANTE,
                        pulseLiftUnlocked = true,
                        pulseOrbit3dUnlocked = true,
                        pulseOrbit8dUnlocked = true,
                        onBack = goBack,
                        onSavePreset = { preset ->
                            scope.launch {
                                if (hasArtistProfile && state.artists.any { it.id == artist.id }) {
                                    repository.updateArtist(artist.copy(audioPreset = preset))
                                } else {
                                    repository.updatePreferences(state.preferences.copy(creatorAudioPreset = preset))
                                }
                            }
                        },
                        onWatchRewardedAdForCoin = watchFreeUseRewarded,
                        onUnlockFeature24h = requestFeaturePass24h,
                        onSpendCoins = { amount ->
                            if (ownerUnlimited || membershipTier == MembershipTier.DIAMANTE) true
                            else repository.consumePulseCoins(authUser.uid, amount.coerceAtLeast(1))
                        },
                        onTrack = { name, success, duration ->
                            scope.launch {
                                repository.addActivity(
                                    UserActivityRecord(
                                        id = UUID.randomUUID().toString(),
                                        artistId = artist.id.takeIf { hasArtistProfile },
                                        title = name,
                                        category = "tool",
                                        success = success,
                                        durationMs = duration
                                    )
                                )
                            }
                        }
                    )

                    AppPage.GUIDE -> StreamPulseGuideScreen(onBack = goBack)
                }
            }
        }
        var showOfflineNotice by remember { mutableStateOf(false) }
        LaunchedEffect(online) {
            if (!online) {
                showOfflineNotice = true
                delay(3000)
                showOfflineNotice = false
            } else { showOfflineNotice = false }
        }
        AnimatedVisibility(
            visible = !online && showOfflineNotice,
            modifier = Modifier.align(Alignment.TopCenter).padding(top = 8.dp)
        ) {
            Surface(
                color = MaterialTheme.colorScheme.errorContainer,
                shape = RoundedCornerShape(50),
                tonalElevation = 4.dp
            ) {
                Row(
                    Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.CloudOff, null, modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Offline • recursos locais continuam disponíveis", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
        offeredUpdate?.let { info ->
            SonusUpdateDialog(
                info = info,
                manager = updateManager,
                onDismiss = { offeredUpdate = null }
            )
        }
        BusyOverlay(busyMessage)
    }
}

@Composable
private fun RowScope.BottomNavItem(
    current: AppPage,
    target: AppPage,
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    navigate: (AppPage) -> Unit,
    badgeCount: Int = 0
) {
    val accent = when (target) {
        AppPage.PLAYER -> Color(0xFF63E2C2)
        AppPage.HIGHLIGHTS -> Color(0xFFFFD76A)
        AppPage.TOOLS -> Color(0xFFFF7B8A)
        AppPage.STREAM -> Color(0xFF67C8FF)
        AppPage.SETTINGS -> Color(0xFFAEB8C7)
        else -> MaterialTheme.colorScheme.primary
    }
    NavigationBarItem(
        selected = current == target,
        onClick = { navigate(target) },
        icon = {
            BadgedBox(badge = {
                if (badgeCount > 0) Badge(containerColor = Color(0xFFD6A72F), modifier = Modifier.size(8.dp))
            }) { Icon(icon, contentDescription = label, modifier = Modifier.size(23.dp)) }
        },
        label = { Text(label, maxLines = 1, fontSize = 8.sp) },
        alwaysShowLabel = current == target,
        colors = NavigationBarItemDefaults.colors(
            selectedIconColor = accent,
            selectedTextColor = accent,
            indicatorColor = accent.copy(alpha = .16f),
            unselectedIconColor = accent.copy(alpha = .62f),
            unselectedTextColor = Color.White.copy(alpha = .62f)
        )
    )
}

@Composable
private fun StreamPulseSplashScreen() {
    val context = LocalContext.current
    val iconId = remember { AppIconCatalog.selectedId(context) }
    val splashColors = remember(iconId) { AppIconCatalog.splashColors(iconId) }
    val scriptFont = remember { runCatching { FontFamily(Font(R.font.pulsefont_amalfi_coast_08)) }.getOrElse { FontFamily.Cursive } }
    val progress = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        runCatching { progress.animateTo(1f, tween(2350, easing = LinearOutSlowInEasing)) }
    }

    val symbolP = (progress.value / .30f).coerceIn(0f, 1f)
    val wordP = ((progress.value - .26f) / .34f).coerceIn(0f, 1f)
    val waveP = ((progress.value - .58f) / .22f).coerceIn(0f, 1f)
    val taglineP = ((progress.value - .76f) / .18f).coerceIn(0f, 1f)

    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF020713), splashColors.first.copy(alpha = .18f), Color.Black))
        ),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            // Símbolo SONUS desenhado como traço de lápis: barras de áudio + sorriso/onda.
            Canvas(Modifier.size(width = 132.dp, height = 112.dp)) {
                val c = Offset(size.width / 2f, size.height * .48f)
                val barX = listOf(.28f,.40f,.50f,.60f,.72f).map { size.width * it }
                val barH = listOf(.34f,.58f,.82f,.58f,.34f).map { size.height * it }
                val strokeBase = 5.2f
                fun pencilLine(a: Offset, b: Offset, alpha: Float) {
                    if (alpha <= 0f) return
                    drawLine(Color.White.copy(alpha=.72f*alpha), a, b, strokeBase, StrokeCap.Round)
                    drawLine(Color.White.copy(alpha=.30f*alpha), a+Offset(1.2f,-.8f), b+Offset(.6f,1f), 2.2f, StrokeCap.Round)
                    drawLine(Color.White.copy(alpha=.18f*alpha), a+Offset(-1.1f,.7f), b+Offset(-.5f,-.7f), 1.3f, StrokeCap.Round)
                }
                barX.forEachIndexed { i,x ->
                    val local=((symbolP*1.45f)-(i*.10f)).coerceIn(0f,1f)
                    val h=barH[i]
                    pencilLine(Offset(x,c.y-h/2),Offset(x,c.y+h/2),local)
                }
                val arcP=((symbolP-.42f)/.58f).coerceIn(0f,1f)
                if (arcP>0f) {
                    val path=Path()
                    val left=size.width*.18f; val right=size.width*.82f; val y=size.height*.60f
                    path.moveTo(left,y-size.height*.10f)
                    path.cubicTo(left+size.width*.03f,y+size.height*.22f,right-size.width*.03f,y+size.height*.22f,right,y-size.height*.10f)
                    drawPath(path,Color.White.copy(alpha=.76f*arcP),style=Stroke(width=5.2f,cap=StrokeCap.Round))
                    drawPath(path,Color.White.copy(alpha=.20f*arcP),style=Stroke(width=2.0f,cap=StrokeCap.Round,pathEffect=PathEffect.dashPathEffect(floatArrayOf(3f,2.5f),0f)))
                }
            }

            Spacer(Modifier.height(0.dp))
            // O lettering cursivo possui caudas que ultrapassam a caixa tipográfica normal.
            // Reservamos uma área larga e animamos apenas alpha/escala, sem clipRect.
            Box(
                Modifier
                    .width(330.dp)
                    .height(92.dp)
                    .offset(y = (-12).dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Sonus",
                    modifier = Modifier
                        .width(300.dp)
                        .padding(horizontal = 26.dp)
                        .graphicsLayer {
                            alpha = wordP.coerceIn(0f, 1f)
                            scaleX = .985f + (.015f * wordP.coerceIn(0f, 1f))
                            scaleY = .985f + (.015f * wordP.coerceIn(0f, 1f))
                        },
                    color = Color.White.copy(alpha = .96f),
                    fontFamily = scriptFont,
                    fontSize = 45.sp,
                    lineHeight = 74.sp,
                    fontWeight = FontWeight.Normal,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    softWrap = false,
                    overflow = TextOverflow.Visible,
                    style = TextStyle(
                        shadow = Shadow(Color.White.copy(alpha=.08f), Offset(0f,1f), 2f)
                    )
                )
            }

            Canvas(Modifier.width(218.dp).height(38.dp)) {
                val centerY=size.height*.45f
                val maxX=size.width*waveP
                val path=Path()
                var x=0f
                while(x<=maxX){
                    val n=if(size.width==0f)0f else x/size.width
                    val env=(1f-kotlin.math.abs(n-.5f)*1.6f).coerceIn(.12f,1f)
                    val y=centerY+kotlin.math.sin(n*kotlin.math.PI.toFloat()*5.0f)*size.height*.18f*env
                    if(x==0f)path.moveTo(x,y) else path.lineTo(x,y)
                    x+=3f
                }
                if(waveP>0f) drawPath(path, brush=Brush.horizontalGradient(listOf(Color.White.copy(alpha=.75f), splashColors.second.copy(alpha=.88f), splashColors.first.copy(alpha=.82f))), style=Stroke(width=2.7f,cap=StrokeCap.Round))
            }

            Text(
                text = "Sua música. Seu som.",
                color = Color.White.copy(alpha = .72f * taglineP),
                fontSize = 13.sp,
                letterSpacing = .9.sp,
                modifier = Modifier.graphicsLayer {
                    alpha = taglineP
                    translationY = 6f * (1f - taglineP)
                }
            )
        }
        Text(
            "by SONUS STUDIOS - RΛFΛ亗",
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 18.dp),
            color = Color.White.copy(alpha = .72f),
            fontSize = 10.sp,
            fontWeight = FontWeight.Medium
        )

    }
}


@Composable
private fun EligibilitySwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}


private data class GuideItem(val category: String, val title: String, val body: String)

@Composable
private fun StreamPulseGuideScreen(onBack: () -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    val guideItems = remember {
        listOf(
            GuideItem("Ferramentas", "Conversor de Áudio", "Converte áudio com formato, qualidade e equalizador à sua escolha."),
            GuideItem("Ajustes", "Temas, fontes e ícones", "Personalizam a aparência do SONUS. Alguns estilos são identificados pelos selos dos planos Premium."),
            GuideItem("Ajustes", "Backup", "Cria uma cópia local dos dados do SONUS para restauração futura. Guarde o arquivo em local seguro."),
            GuideItem("Ajustes", "Uso do SONUS", "Mostra estatísticas locais como tempo de uso, entradas, média diária e maior sessão. Esses dados pertencem ao próprio usuário."),
            GuideItem("Premium", "Planos Grátis, Prata, Ouro e Diamante", "O Grátis mantém Player e Stream completos e permite desbloqueios pontuais por anúncio/moeda. Prata abre o pacote PRO, Ouro amplia limites e recursos avançados, e Diamante oferece o nível mais completo.")
        )
    }
    val filtered = guideItems.filter {
        query.isBlank() || it.title.contains(query, ignoreCase = true) || it.category.contains(query, ignoreCase = true) || it.body.contains(query, ignoreCase = true)
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(top = 18.dp, bottom = 32.dp)
    ) {
        item { PageHeader("Guia do SONUS", onBack) }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = .72f))) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Como interpretar o app", fontWeight = FontWeight.ExtraBold)
                    Text("Este guia explica o que cada recurso faz e como ler os resultados. Fórmulas internas, pesos e critérios proprietários do motor não são exibidos.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it.take(80) },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Buscar uma função") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                singleLine = true
            )
        }
        items(filtered, key = { "${it.category}|${it.title}" }) { item ->
            GuideAccordionItem(item)
        }
    }
}

@Composable
private fun GuideAccordionItem(item: GuideItem) {
    var expanded by rememberSaveable(item.title) { mutableStateOf(false) }
    Card(modifier = Modifier.fillMaxWidth().clickable { expanded = !expanded }) {
        Column(Modifier.padding(horizontal = 15.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(item.category, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Text(item.title, fontWeight = FontWeight.Bold)
                }
                Icon(if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null)
            }
            AnimatedVisibility(expanded) {
                Text(item.body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .72f))
            }
        }
    }
}


@Composable
private fun AppLoadingScreen(message: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Image(
                painter = painterResource(R.drawable.sonus_symbol_official),
                contentDescription = null,
                modifier = Modifier.size(88.dp)
            )
            CircularProgressIndicator(strokeWidth = 3.dp)
            Text(message, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun BusyOverlay(message: String?) {
    AnimatedVisibility(visible = message != null, enter = fadeIn(tween(120)), exit = fadeOut(tween(140))) {
        Box(
            Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background.copy(alpha = .42f)),
            contentAlignment = Alignment.Center
        ) {
            Surface(shape = RoundedCornerShape(18.dp), tonalElevation = 8.dp) {
                Row(
                    Modifier.padding(horizontal = 20.dp, vertical = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 3.dp)
                    Text(message.orEmpty(), fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}


@Composable
private fun AddArtistScreen(
    membershipTier: MembershipTier,
    isOwner: Boolean,
    onPremium: () -> Unit,
    onBack: () -> Unit,
    onCreate: (String, String?, String?) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val draftKey = rememberSaveable { "draft_${UUID.randomUUID()}" }
    var photoPath by rememberSaveable { mutableStateOf<String?>(null) }
    var avatarId by rememberSaveable { mutableStateOf<String?>(null) }
    var showSourceDialog by remember { mutableStateOf(false) }
    var showAvatarDialog by remember { mutableStateOf(false) }
    var identityMessage by remember { mutableStateOf<String?>(null) }

    val photoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            scope.launch {
                identityMessage = "Preparando foto..."
                val path = withContext(Dispatchers.IO) { saveArtistPhoto(context, uri, draftKey, photoPath) }
                if (path != null) {
                    photoPath = path
                    avatarId = null
                    identityMessage = "Foto pronta"
                } else identityMessage = "Não foi possível abrir a imagem"
                delay(900)
                identityMessage = null
            }
        }
    }

    if (showSourceDialog) {
        ArtistImageSourceDialog(
            onDismiss = { showSourceDialog = false },
            onGallery = { showSourceDialog = false; photoLauncher.launch("image/*") },
            onAvatar = { showSourceDialog = false; showAvatarDialog = true }
        )
    }
    if (showAvatarDialog) {
        SonusAvatarPickerDialog(
            currentAvatarId = avatarId,
            membershipTier = membershipTier,
            isOwner = isOwner,
            onDismiss = { showAvatarDialog = false },
            onApply = { selected ->
                deleteArtistPhoto(photoPath)
                photoPath = null
                avatarId = selected
                showAvatarDialog = false
            },
            onLocked = {
                showAvatarDialog = false
                onPremium()
            }
        )
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item {
            PageHeader("Adicionar artista") {
                deleteArtistPhoto(photoPath)
                onBack()
            }
        }
        item {
            ArtistIdentityCard(
                photoPath = photoPath,
                avatarId = avatarId,
                message = identityMessage,
                onChoose = { showSourceDialog = true },
                onRemove = {
                    deleteArtistPhoto(photoPath)
                    photoPath = null
                    avatarId = null
                }
            )
        }
        item {
            ArtistForm(
                submitLabel = "Adicionar artista",
                onSubmit = { name -> onCreate(name, photoPath, avatarId) }
            )
        }
    }
}

@Composable
private fun EditArtistScreen(
    artist: Artist,
    membershipTier: MembershipTier,
    isOwner: Boolean,
    onPremium: () -> Unit,
    onBack: () -> Unit,
    onSave: (Artist) -> Unit,
    onDelete: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var confirmDelete by remember { mutableStateOf(false) }
    val originalPhotoPath = artist.photoPath
    var photoPath by rememberSaveable(artist.id) { mutableStateOf(artist.photoPath) }
    var avatarId by rememberSaveable(artist.id) { mutableStateOf(artist.avatarId) }
    var showSourceDialog by remember { mutableStateOf(false) }
    var showAvatarDialog by remember { mutableStateOf(false) }
    var identityMessage by remember { mutableStateOf<String?>(null) }

    val photoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            scope.launch {
                identityMessage = "Preparando foto..."
                val previousDraft = photoPath?.takeIf { it != originalPhotoPath }
                val path = withContext(Dispatchers.IO) { saveArtistPhoto(context, uri, artist.id, previousDraft) }
                if (path != null) {
                    photoPath = path
                    avatarId = null
                    identityMessage = "Foto atualizada"
                } else identityMessage = "Não foi possível abrir a imagem"
                delay(900)
                identityMessage = null
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Excluir ${artist.name}?") },
            text = { Text("Este artista será removido deste aparelho.") },
            confirmButton = { TextButton(onClick = {
                confirmDelete = false
                photoPath?.takeIf { it != originalPhotoPath }?.let(::deleteArtistPhoto)
                deleteArtistPhoto(originalPhotoPath)
                onDelete()
            }) { Text("Excluir") } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancelar") } }
        )
    }
    if (showSourceDialog) {
        ArtistImageSourceDialog(
            onDismiss = { showSourceDialog = false },
            onGallery = { showSourceDialog = false; photoLauncher.launch("image/*") },
            onAvatar = { showSourceDialog = false; showAvatarDialog = true }
        )
    }
    if (showAvatarDialog) {
        SonusAvatarPickerDialog(
            currentAvatarId = avatarId,
            membershipTier = membershipTier,
            isOwner = isOwner,
            onDismiss = { showAvatarDialog = false },
            onApply = { selected ->
                photoPath?.takeIf { it != originalPhotoPath }?.let(::deleteArtistPhoto)
                photoPath = null
                avatarId = selected
                showAvatarDialog = false
            },
            onLocked = {
                showAvatarDialog = false
                onPremium()
            }
        )
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 28.dp)
    ) {
        item {
            PageHeader("Editar artista") {
                photoPath?.takeIf { it != originalPhotoPath }?.let(::deleteArtistPhoto)
                onBack()
            }
        }
        item {
            ArtistIdentityCard(
                photoPath = photoPath,
                avatarId = avatarId,
                message = identityMessage,
                onChoose = { showSourceDialog = true },
                onRemove = {
                    photoPath?.takeIf { it != originalPhotoPath }?.let(::deleteArtistPhoto)
                    photoPath = null
                    avatarId = null
                }
            )
        }
        item {
            ArtistForm(
                submitLabel = "Salvar alterações",
                initialArtist = artist,
                onSubmit = { name ->
                    if (photoPath != originalPhotoPath) deleteArtistPhoto(originalPhotoPath)
                    onSave(
                        artist.copy(
                            name = name,
                            photoPath = photoPath,
                            avatarId = avatarId
                        )
                    )
                }
            )
        }
        item {
            OutlinedButton(onClick = { confirmDelete = true }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Delete, null)
                Spacer(Modifier.width(8.dp))
                Text("Excluir artista")
            }
        }
    }
}

@Composable
private fun ArtistIdentityCard(
    photoPath: String?,
    avatarId: String?,
    message: String?,
    onChoose: () -> Unit,
    onRemove: () -> Unit
) {
    Card {
        Row(
            Modifier.fillMaxWidth().padding(15.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(contentAlignment = Alignment.BottomEnd) {
                ArtistAvatar(photoPath = photoPath, avatarId = avatarId, size = 82.dp, fallbackToLogo = true)
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(28.dp).clickable(onClick = onChoose)
                ) { Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.PhotoCamera, null, tint = Color.White, modifier = Modifier.size(16.dp)) } }
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("Imagem do artista", fontWeight = FontWeight.ExtraBold)
                Text(
                    when {
                        photoPath != null -> "Foto da galeria"
                        avatarId != null -> "Avatar SONUS • ${SonusAvatarCatalog.byId(avatarId)?.title.orEmpty()}"
                        else -> "Use uma foto ou escolha um Avatar SONUS."
                    },
                    style = MaterialTheme.typography.bodySmall
                )
                message?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary) }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TextButton(onClick = onChoose, contentPadding = PaddingValues(horizontal = 0.dp)) { Text(if (photoPath == null && avatarId == null) "Adicionar" else "Alterar") }
                    if (photoPath != null || avatarId != null) TextButton(onClick = onRemove) { Text("Remover") }
                }
            }
        }
    }
}

@Composable
private fun ArtistImageSourceDialog(
    onDismiss: () -> Unit,
    onGallery: () -> Unit,
    onAvatar: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Imagem do artista", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                OutlinedButton(onClick = onGallery, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                    Icon(Icons.Default.PhotoLibrary, null); Spacer(Modifier.width(8.dp)); Text("Escolher da galeria")
                }
                OutlinedButton(onClick = onAvatar, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                    Icon(Icons.Default.Face, null); Spacer(Modifier.width(8.dp)); Text("Avatar SONUS")
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun SonusAvatarPickerDialog(
    currentAvatarId: String?,
    membershipTier: MembershipTier,
    isOwner: Boolean,
    onDismiss: () -> Unit,
    onApply: (String) -> Unit,
    onLocked: (MembershipTier) -> Unit
) {
    var previewId by remember(currentAvatarId) { mutableStateOf(currentAvatarId ?: SonusAvatarCatalog.instruments.first().id) }
    val previewSpec = SonusAvatarCatalog.byId(previewId)
    val groups = remember { SonusAvatarCatalog.all.groupBy { it.collection }.toList() }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Avatar SONUS", fontWeight = FontWeight.ExtraBold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    SonusAvatarArtwork(previewId, Modifier.size(76.dp).clip(CircleShape))
                    Column(Modifier.weight(1f)) {
                        Text(previewSpec?.title ?: "Avatar SONUS", fontWeight = FontWeight.Bold)
                        Text(previewSpec?.collection ?: "", style = MaterialTheme.typography.bodySmall)
                        Text("Trocas de avatar não consomem Moedas SONUS.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .58f))
                    }
                }
                HorizontalDivider()
                LazyColumn(
                    modifier = Modifier.heightIn(max = 430.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    groups.forEach { (collection, specs) ->
                        item(key = "header_$collection") {
                            val tier = specs.first().tier
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(collection, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                                Text(tier.name, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                        items(specs.chunked(4), key = { row -> row.joinToString("_") { it.id } }) { row ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                                row.forEach { spec ->
                                    val unlocked = SonusAvatarCatalog.unlocked(spec, membershipTier, isOwner)
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        modifier = Modifier.width(68.dp).clickable {
                                            if (unlocked) previewId = spec.id else onLocked(spec.tier)
                                        }
                                    ) {
                                        val selected = previewId == spec.id
                                        Box(
                                            Modifier
                                                .size(58.dp)
                                                .then(if (selected) Modifier.border(2.dp, MaterialTheme.colorScheme.primary, CircleShape) else Modifier)
                                                .padding(if (selected) 3.dp else 0.dp)
                                        ) {
                                            SonusAvatarArtwork(spec.id, Modifier.fillMaxSize().clip(CircleShape), locked = !unlocked)
                                        }
                                        Text(spec.title, fontSize = 8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text(
                                            if (spec.tier == MembershipTier.FREE) "FREE" else spec.tier.name,
                                            fontSize = 7.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (unlocked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = .42f)
                                        )
                                    }
                                }
                                repeat(4 - row.size) { Spacer(Modifier.width(68.dp)) }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            val unlocked = previewSpec?.let { SonusAvatarCatalog.unlocked(it, membershipTier, isOwner) } == true
            Button(onClick = { onApply(previewId) }, enabled = unlocked) { Text("Aplicar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun ArtistForm(
    submitLabel: String,
    initialArtist: Artist? = null,
    onSubmit: (String) -> Unit
) {
    var name by rememberSaveable(initialArtist?.id) { mutableStateOf(initialArtist?.name.orEmpty()) }
    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedTextColor = MaterialTheme.colorScheme.onSurface,
        unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
        focusedContainerColor = MaterialTheme.colorScheme.surface,
        unfocusedContainerColor = MaterialTheme.colorScheme.surface,
        cursorColor = MaterialTheme.colorScheme.primary
    )

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Nome do artista") },
            supportingText = { Text("Este é o nome artístico exibido no SONUS Stream.") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            colors = fieldColors,
            textStyle = TextStyle(color = MaterialTheme.colorScheme.onSurface)
        )
        Button(
            onClick = { onSubmit(name.trim()) },
            enabled = name.isNotBlank(),
            modifier = Modifier.fillMaxWidth().height(54.dp)
        ) { Text(submitLabel) }
    }
}

@Composable
private fun CommunityPresenceBadge(state: CommunityPresenceState) {
    val borderColor = when {
        state.connected -> SignalGreen
        state.connecting -> SignalYellow
        else -> MaterialTheme.colorScheme.onSurface.copy(alpha = .28f)
    }
    val total = state.totalUsers
    val text = when {
        state.connected && state.publicCounterEnabled && total != null && total >= state.publicCounterMinimum -> {
            val rounded = when {
                total >= 1000L -> (total / 100L) * 100L
                total >= 100L -> (total / 50L) * 50L
                else -> total
            }
            "👥 +$rounded  •  🟢 ${state.onlineUsers ?: "…"}"
        }
        state.connected -> "🚀 Comunidade em crescimento"
        state.connecting -> "👥 conectando…"
        else -> "👥 —"
    }
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = .78f),
        border = BorderStroke(1.dp, borderColor.copy(alpha = .65f))
    ) {
        Text(
            text,
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 7.dp),
            fontSize = 10.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1
        )
    }
}


@Composable
private fun AnimatedLongText(
    value: Long,
    suffix: String = "",
    color: Color,
    fontSize: androidx.compose.ui.unit.TextUnit
) {
    val animated by animateFloatAsState(value.toFloat(), tween(700), label = "long-counter")
    Text("${formatNumber(animated.roundToLong())}$suffix", style = digitalValueStyle(color, fontSize))
}


private val SignalBlack = Color(0xFF101216)
private val SignalRed = Color(0xFF9E2A2B)
private val SignalPurple = Color(0xFF5B357D)
private val SignalBrown = SignalPurple
private val SignalOrange = Color(0xFFA95818)
private val SignalYellow = Color(0xFFB08A16) // reservado a avisos/velocímetro
private val SignalGreen = Color(0xFF226A43)
private val SignalBlue = Color(0xFF16558B)


private fun digitalValueStyle(color: Color, fontSize: androidx.compose.ui.unit.TextUnit): TextStyle = TextStyle(
    color = color,
    fontSize = fontSize,
    fontFamily = FontFamily.Monospace,
    fontWeight = FontWeight.Black,
    letterSpacing = 0.2.sp,
    shadow = Shadow(color = Color.Black.copy(alpha = .58f), offset = Offset(1.2f, 1.8f), blurRadius = 3.2f)
)


@Composable
private fun ActivitySummaryCard(records: List<UserActivityRecord>) {
    val karaoke = records.count { it.title.contains("Karaokê", true) }
    val tools = records.count { it.category == "tool" && it.success != false }
    val completed = records.count { it.success == true }
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .52f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = .16f))
    ) {
        Row(
            Modifier.fillMaxWidth().padding(13.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ActivityMiniStat("Atividades", records.size.toString(), Modifier.weight(1f))
            ActivityMiniStat("Ferramentas", tools.toString(), Modifier.weight(1f))
            ActivityMiniStat("Karaokê", karaoke.toString(), Modifier.weight(1f))
            ActivityMiniStat("Concluídas", completed.toString(), Modifier.weight(1f))
        }
    }
}

@Composable
private fun ActivityMiniStat(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontWeight = FontWeight.Black, fontSize = 18.sp, color = MaterialTheme.colorScheme.primary)
        Text(label, style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center, maxLines = 1)
    }
}

@Composable
private fun ActivityHeatmap(records: List<UserActivityRecord>) {
    val today = LocalDate.now()
    val counts = remember(records) {
        records.groupingBy {
            Instant.ofEpochMilli(it.createdAtEpochMillis).atZone(ZoneId.systemDefault()).toLocalDate()
        }.eachCount()
    }
    val sevenDays = (0..6).sumOf { counts[today.minusDays(it.toLong())] ?: 0 }
    val activeDays7 = (0..6).count { (counts[today.minusDays(it.toLong())] ?: 0) > 0 }
    Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surface.copy(alpha = .62f)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Últimos 28 dias", fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                Text("7d: $sevenDays atividades • $activeDays7 dias ativos", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                (27 downTo 0).forEach { ago ->
                    val count = counts[today.minusDays(ago.toLong())] ?: 0
                    val alpha = when {
                        count == 0 -> .10f
                        count <= 2 -> .28f
                        count <= 5 -> .48f
                        count <= 9 -> .68f
                        else -> .92f
                    }
                    Box(
                        Modifier.weight(1f).height(18.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = alpha))
                    )
                }
            }
            Text("Quanto mais forte o bloco, mais atividades naquele dia.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .52f))
        }
    }
}

@Composable
private fun ActivityTimelineRow(record: UserActivityRecord, onDelete: () -> Unit) {
    val date = remember(record.createdAtEpochMillis) {
        Instant.ofEpochMilli(record.createdAtEpochMillis)
            .atZone(ZoneId.systemDefault())
            .format(DateTimeFormatter.ofPattern("dd/MM • HH:mm"))
    }
    val icon = when {
        record.title.contains("Karaokê", true) -> Icons.Default.Mic
        record.title.contains("Conversor", true) -> Icons.Default.GraphicEq
        record.category == "page" -> Icons.Default.Visibility
        record.success == false -> Icons.Default.ErrorOutline
        else -> Icons.Default.CheckCircleOutline
    }
    Surface(
        shape = RoundedCornerShape(17.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .38f)
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 11.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary.copy(alpha = .13f)) {
                Icon(icon, null, modifier = Modifier.padding(8.dp).size(18.dp), tint = if (record.success == false) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
            }
            Spacer(Modifier.width(9.dp))
            Column(Modifier.weight(1f)) {
                Text(record.title, fontWeight = FontWeight.Bold)
                val detail = buildList {
                    record.detail?.takeIf { it.isNotBlank() }?.let(::add)
                    record.durationMs?.takeIf { it > 0 }?.let { add(formatDurationShort(it)) }
                    add(date)
                }.joinToString(" • ")
                Text(detail, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .58f), maxLines = 2)
            }
            IconButton(onClick = onDelete) { Icon(Icons.Default.Close, "Excluir atividade", modifier = Modifier.size(18.dp)) }
        }
    }
}


@Composable
private fun PremiumSettingsBanner(membershipTier: MembershipTier, onClick: () -> Unit) {
    val transition = rememberInfiniteTransition(label = "premium-settings-glow")
    val glow by transition.animateFloat(
        initialValue = .28f,
        targetValue = .72f,
        animationSpec = infiniteRepeatable(tween(1700), RepeatMode.Reverse),
        label = "premium-glow-alpha"
    )
    val shape = RoundedCornerShape(22.dp)
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .clickable(onClick = onClick)
            .border(1.dp, Color(0xFFFFD66B).copy(alpha = .45f + glow * .35f), shape),
        color = Color.Transparent
    ) {
        Row(
            Modifier
                .background(
                    Brush.linearGradient(
                        listOf(
                            Color(0xFF5B4210).copy(alpha = .72f),
                            Color(0xFFB77A14).copy(alpha = .42f + glow * .14f),
                            Color(0xFF3A2A0C).copy(alpha = .82f)
                        )
                    )
                )
                .padding(horizontal = 15.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFFFD66B).copy(alpha = .16f + glow * .12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.WorkspacePremium, null, tint = Color(0xFFFFD66B), modifier = Modifier.size(25.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("SONUS Premium", color = Color(0xFFFFE9A8), fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                Text("Planos, temas e recursos avançados • toque para conhecer", color = Color.White.copy(alpha = .78f), style = MaterialTheme.typography.bodySmall)
            }
            PlanStatusPill(membershipTier)
            Spacer(Modifier.width(5.dp))
            Icon(Icons.Default.ChevronRight, null, tint = Color(0xFFFFD66B))
        }
    }
}

@Composable
private fun SonusNotificationCenterScreen(
    items: List<SonusNotificationItem>,
    onBack: () -> Unit,
    onOpenRoute: (String?) -> Unit
) {
    val context = LocalContext.current
    val zone = remember { ZoneId.systemDefault() }
    val grouped = remember(items, zone) {
        items.groupBy { Instant.ofEpochMilli(it.createdAtEpochMillis).atZone(zone).toLocalDate() }
            .toSortedMap(compareByDescending { it })
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 34.dp)
    ) {
        item { PageHeader("Notificações", onBack) }
        if (items.isNotEmpty()) {
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { SonusNotificationCenter.markAllRead(context) }, modifier = Modifier.weight(1f)) { Text("Marcar como lidas") }
                    TextButton(onClick = { SonusNotificationCenter.clear(context) }, modifier = Modifier.weight(1f)) { Text("Limpar histórico") }
                }
            }
        }
        if (items.isEmpty()) {
            item {
                Column(
                    Modifier.fillMaxWidth().padding(vertical = 44.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.NotificationsNone, null, modifier = Modifier.size(40.dp), tint = Color(0xFFFFD76A))
                    Text("Tudo tranquilo por aqui", fontWeight = FontWeight.ExtraBold)
                    Text(
                        "Avisos importantes do SONUS vão aparecer nesta central.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = .62f),
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            grouped.forEach { (day, dayItems) ->
                item(key = "day-$day") {
                    Text(
                        when (day) {
                            LocalDate.now() -> "Hoje"
                            LocalDate.now().minusDays(1) -> "Ontem"
                            else -> day.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))
                        },
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = .78f)
                    )
                }
                dayItems.forEach { notification ->
                    item(key = notification.id) {
                        SonusNotificationCard(
                            notification = notification,
                            onOpen = {
                                SonusNotificationCenter.markRead(context, notification.id)
                                onOpenRoute(notification.route)
                            },
                            onDelete = { SonusNotificationCenter.delete(context, notification.id) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SonusNotificationSettingsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var prefs by remember { mutableStateOf(SonusNotificationCenter.preferences(context)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        SonusNotificationCenter.setExternalEnabled(context, granted); prefs = SonusNotificationCenter.preferences(context)
    }
    fun requestExternal() {
        if (Build.VERSION.SDK_INT >= 33 && androidx.core.content.ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
        else { SonusNotificationCenter.setExternalEnabled(context, true); prefs = SonusNotificationCenter.preferences(context) }
    }
    fun cat(key:String,value:Boolean){ SonusNotificationCenter.setCategory(context,key,value); prefs=SonusNotificationCenter.preferences(context) }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal=16.dp),verticalArrangement=Arrangement.spacedBy(12.dp),contentPadding=PaddingValues(top=12.dp,bottom=34.dp)) {
        item { PageHeader("Notificações", onBack) }
        item {
            Surface(shape=RoundedCornerShape(22.dp),color=Color(0xFF12344A).copy(alpha=.55f),border=BorderStroke(1.dp,Color(0xFF66D7FF).copy(alpha=.25f))) {
                Row(Modifier.fillMaxWidth().padding(16.dp),verticalAlignment=Alignment.CenterVertically) {
                    Surface(shape=RoundedCornerShape(15.dp),color=Color(0xFF66D7FF).copy(alpha=.14f)){Icon(Icons.Default.NotificationsActive,null,tint=Color(0xFF8DD7FF),modifier=Modifier.padding(11.dp).size(25.dp))}
                    Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text("Central SONUS",fontWeight=FontWeight.Black,fontSize=19.sp);Text("Suporte, Stream, segurança e acontecimentos importantes.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.66f))}
                }
            }
        }
        item { NotificationSectionTitle("SEMPRE IMPORTANTES") }
        item { SonusLockedNotificationRow(Icons.Default.SupportAgent,"Mensagens do suporte","Respostas e solicitações da equipe SONUS") }
        item { SonusLockedNotificationRow(Icons.Default.VerifiedUser,"Conta e segurança","Alertas importantes relacionados à sua conta") }
        item {
            if(!prefs.externalEnabled) OutlinedButton(onClick=::requestExternal,modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.PhoneAndroid,null);Spacer(Modifier.width(7.dp));Text("Permitir avisos importantes no celular")}
            else Text("Avisos externos permitidos neste aparelho.",style=MaterialTheme.typography.labelSmall,color=Color(0xFF63E2C2))
        }
        item { NotificationSectionTitle("SONUS STREAM E ARTISTAS") }
        item { SonusSoftNotificationRow(Icons.Default.GraphicEq,"Stream e artistas","Envio recebido, música aprovada/recusada, correções e foto do artista",prefs.streamArtists){cat("cat_stream",it)} }
        item { NotificationSectionTitle("OUTRAS CATEGORIAS") }
        item { SonusSoftNotificationRow(Icons.Default.Diamond,"Premium e benefícios","Saldo, vencimento e benefícios importantes",prefs.premiumUsage){cat("cat_premium",it)} }
        item { SonusSoftNotificationRow(Icons.Default.Build,"Ferramentas e processos","Conclusões e falhas relevantes",prefs.tools){cat("cat_tools",it)} }
        item { SonusSoftNotificationRow(Icons.Default.Backup,"Backup e segurança","Falhas de backup e avisos que exigem atenção",prefs.backupSafety){cat("cat_backup",it)} }
        item { SonusSoftNotificationRow(Icons.Default.AutoAwesome,"Novidades SONUS","Novos recursos e comunicados gerais",prefs.sonusUpdates){cat("cat_updates",it)} }
        item { NotificationSectionTitle("NÃO PERTURBE") }
        item { Surface(shape=RoundedCornerShape(18.dp),color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.30f)){Column(Modifier.fillMaxWidth().padding(13.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){SonusSoftNotificationRow(Icons.Default.Bedtime,"Não perturbe","Silencia avisos comuns; suporte e segurança continuam prioritários",prefs.quietHours){SonusNotificationCenter.setQuietHours(context,it,prefs.quietStart,prefs.quietEnd);prefs=SonusNotificationCenter.preferences(context)};if(prefs.quietHours)Row(verticalAlignment=Alignment.CenterVertically){Text("${prefs.quietStart}:00 — ${prefs.quietEnd}:00",Modifier.weight(1f),fontWeight=FontWeight.Bold);TextButton(onClick={SonusNotificationCenter.setQuietHours(context,true,23,8);prefs=SonusNotificationCenter.preferences(context)}){Text("23h–08h")};TextButton(onClick={SonusNotificationCenter.setQuietHours(context,true,22,7);prefs=SonusNotificationCenter.preferences(context)}){Text("22h–07h")}}}} }
        item { Text("Mensagens de suporte e segurança permanecem registradas na Central SONUS. Se o Android bloquear notificações do aplicativo, o SONUS não consegue ignorar essa escolha do sistema.",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.55f)) }
    }
}

@Composable private fun NotificationSectionTitle(text:String){Text(text,fontSize=10.sp,fontWeight=FontWeight.Black,color=MaterialTheme.colorScheme.primary,modifier=Modifier.padding(top=4.dp,start=3.dp))}
@Composable private fun SonusLockedNotificationRow(icon:ImageVector,title:String,subtitle:String){Surface(shape=RoundedCornerShape(18.dp),color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.28f)){Row(Modifier.fillMaxWidth().padding(13.dp),verticalAlignment=Alignment.CenterVertically){Surface(shape=RoundedCornerShape(12.dp),color=MaterialTheme.colorScheme.primary.copy(alpha=.12f)){Icon(icon,null,tint=MaterialTheme.colorScheme.primary,modifier=Modifier.padding(9.dp).size(21.dp))};Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(title,fontWeight=FontWeight.ExtraBold);Text(subtitle,style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.58f))};Surface(shape=RoundedCornerShape(50),color=Color(0xFF63E2C2).copy(alpha=.14f)){Row(Modifier.padding(horizontal=9.dp,vertical=5.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Lock,null,modifier=Modifier.size(12.dp),tint=Color(0xFF63E2C2));Spacer(Modifier.width(4.dp));Text("Ativo",fontSize=9.sp,fontWeight=FontWeight.Bold,color=Color(0xFF63E2C2))}}}}}
@Composable private fun SonusSoftNotificationRow(icon:ImageVector,title:String,subtitle:String,checked:Boolean,onChange:(Boolean)->Unit){Surface(shape=RoundedCornerShape(18.dp),color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.28f)){Row(Modifier.fillMaxWidth().padding(horizontal=13.dp,vertical=11.dp),verticalAlignment=Alignment.CenterVertically){Icon(icon,null,tint=MaterialTheme.colorScheme.primary,modifier=Modifier.size(22.dp));Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(title,fontWeight=FontWeight.Bold);Text(subtitle,style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.55f))};Switch(checked,onChange,modifier=Modifier.scale(.82f))}}}

@Composable
private fun NotificationCategoryToggle(title: String, subtitle: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .56f))
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun SonusNotificationCard(notification: SonusNotificationItem, onOpen: () -> Unit, onDelete: () -> Unit) {
    val time = remember(notification.createdAtEpochMillis) {
        Instant.ofEpochMilli(notification.createdAtEpochMillis).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("HH:mm"))
    }
    val icon = when (notification.category) {
        "PREMIUM" -> Icons.Default.WorkspacePremium
        "BACKUP" -> Icons.Default.Cloud
        else -> Icons.Default.Notifications
    }
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onOpen),
        shape = RoundedCornerShape(18.dp),
        color = if (notification.read) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .36f) else MaterialTheme.colorScheme.primaryContainer.copy(alpha = .34f),
        border = BorderStroke(1.dp, if (notification.read) MaterialTheme.colorScheme.outline.copy(alpha = .10f) else MaterialTheme.colorScheme.primary.copy(alpha = .16f))
    ) {
        Row(Modifier.padding(13.dp), verticalAlignment = Alignment.Top) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 2.dp))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(notification.title, fontWeight = if (notification.read) FontWeight.Bold else FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                    Text(time, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .48f))
                }
                Text(notification.body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .67f))
            }
            IconButton(onClick = onDelete, modifier = Modifier.size(34.dp)) { Icon(Icons.Default.Close, "Excluir", modifier = Modifier.size(17.dp)) }
        }
    }
}

@Composable
private fun ProPlanChoiceDialog(
    minimumTier: MembershipTier,
    onDismiss: () -> Unit,
    onChoose: (MembershipTier) -> Unit
) {
    val plans = PremiumCatalog.plans.filter { it.tier.ordinal >= minimumTier.ordinal }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.WorkspacePremium, null, tint = Color(0xFFFFC84B))
                    Spacer(Modifier.width(8.dp))
                    Text("Escolha um plano", fontWeight = FontWeight.ExtraBold)
                }
                Text("Este recurso faz parte do SONUS PRO.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f))
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                plans.forEach { plan ->
                    Surface(
                        modifier = Modifier.fillMaxWidth().clickable { onChoose(plan.tier) },
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = .30f)),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .45f)
                    ) {
                        Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(plan.title, fontWeight = FontWeight.ExtraBold)
                                Text(plan.monthlyPrice, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                            }
                            plan.highlight?.let {
                                Surface(shape = RoundedCornerShape(999.dp), color = Color(0xFFFFC84B).copy(alpha = .14f)) {
                                    Text(it, modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp), fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFFC84B))
                                }
                                Spacer(Modifier.width(6.dp))
                            }
                            Icon(Icons.Default.ChevronRight, null)
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Agora não") } }
    )
}

@Composable
private fun PremiumScreen(
    membershipTier: MembershipTier,
    premiumExpiresAt: Long?,
    premiumUsesRemaining: Int,
    usageEvents: List<PremiumUsageEvent>,
    accountId: String?,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    fun openTelegramPurchase(plan: PremiumPlanInfo) {
        val requestCode = java.util.UUID.randomUUID().toString().replace("-", "").take(10).uppercase(Locale.ROOT)
        val message = buildString {
            appendLine("Olá! Quero contratar o plano ${plan.title} do SONUS.")
            appendLine("Valor mensal: ${plan.monthlyPrice}")
            plan.annualPrice?.let { appendLine("Valor anual: $it") }
            appendLine("Versão do SONUS: ${BuildConfig.VERSION_NAME} (code ${BuildConfig.VERSION_CODE})")
            appendLine("Código desta solicitação: $requestCode")
            append("ID da conta SONUS: ${accountId?.takeIf { it.isNotBlank() } ?: "Conta não conectada"}")
        }
        val uri = Uri.parse("https://t.me/sonuspremiumofc")
            .buildUpon()
            .appendQueryParameter("text", message)
            .build()
        runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, uri)) }
            .onFailure { Toast.makeText(context, "Não foi possível abrir o Telegram. Verifique se está instalado ou tente novamente.", Toast.LENGTH_LONG).show() }
    }
    var selected by remember { mutableStateOf<PremiumPlanInfo?>(null) }
    val plans=PremiumCatalog.plans
    selected?.let { plan ->
        AlertDialog(
            onDismissRequest = { selected = null },
            title = { Text(plan.title, fontWeight = FontWeight.Black) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Planos SONUS Premium", fontWeight = FontWeight.Bold)
                    Text(plan.monthlyPrice, fontSize = 24.sp, fontWeight = FontWeight.Black)
                    plan.annualPrice?.let { Text("Anual: $it", style = MaterialTheme.typography.bodySmall) }
                    plan.benefits.take(6).forEach { benefit ->
                        Row {
                            Icon(Icons.Default.CheckCircle, null, tint = SignalGreen, modifier = Modifier.size(17.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(benefit, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = .45f)
                    ) {
                        Text(
                            "A conversa é individual com o atendimento SONUS. O Telegram abrirá uma mensagem pronta com o plano, um código de solicitação e o ID da sua conta, quando conectado.",
                            modifier = Modifier.padding(10.dp),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { openTelegramPurchase(plan); selected = null }) {
                    Icon(Icons.Default.Send, null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(5.dp)); Text("Comprar pelo Telegram")
                }
            },
            dismissButton = { TextButton(onClick = { selected = null }) { Text("Fechar") } }
        )
    }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal=16.dp),verticalArrangement=Arrangement.spacedBy(12.dp),contentPadding=PaddingValues(top=10.dp,bottom=34.dp)){
        item{PageHeader("Premium",onBack)}
        item{Column{
            Text("SONUS PREMIUM",fontWeight=FontWeight.Black,fontSize=25.sp)
            Text("ESCOLHA A MELHOR OPÇÃO PRA VOCÊ",fontWeight=FontWeight.Bold,fontSize=13.sp,color=MaterialTheme.colorScheme.primary)
            val activeUntil=premiumExpiresAt?.takeIf{it>System.currentTimeMillis()}
            if(membershipTier!=MembershipTier.FREE&&activeUntil!=null){
                val date=java.time.Instant.ofEpochMilli(activeUntil).atZone(java.time.ZoneId.systemDefault()).toLocalDate()
                Text("Plano atual: ${membershipLabel(membershipTier)} • válido até ${date.dayOfMonth.toString().padStart(2,'0')}/${date.monthValue.toString().padStart(2,'0')}/${date.year}",fontSize=10.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.68f))
            } else if(membershipTier==MembershipTier.FREE) Text("Plano atual: Grátis",fontSize=10.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.68f))
        }}
        item{PremiumSimplePlanCard("Grátis","Conheça o SONUS sem compromisso","R$ 0",listOf("5 Moedas SONUS/mês","1 artista • 3 envios/mês ao Stream","Player e Stream completos","SOCIAL EDIT • vídeos de 15s","PRO: 1 moeda ou anúncio por bloco de até 5 arquivos"),listOf(Color(0xFF343740),Color(0xFF555A64)),commercialTier(membershipTier)==MembershipTier.FREE,null)}
        items(plans){plan->
            val colors=when(plan.tier){
                MembershipTier.PRATA->listOf(Color(0xFF46515D),Color(0xFF8A98A8));
                MembershipTier.OURO->listOf(Color(0xFF5B4723),Color(0xFFB3914D));
                MembershipTier.DIAMANTE->listOf(Color(0xFF24364A),Color(0xFF6887A3));
                else->listOf(Color(0xFF343740),Color(0xFF555A64))
            }
            val subtitle=when(plan.tier){MembershipTier.PRATA->"Entre no PRO pagando pouco";MembershipTier.OURO->"Para quem cria e produz mais";MembershipTier.DIAMANTE->"A experiência SONUS mais completa";else->"SONUS"}
            PremiumSimplePlanCard(
                title = plan.title,
                subtitle = subtitle,
                price = plan.monthlyPrice,
                benefits = plan.benefits.take(5),
                colors = colors,
                current = commercialTier(membershipTier) == plan.tier,
                badge = if(plan.tier==MembershipTier.OURO)"Recomendado" else if(plan.tier==MembershipTier.DIAMANTE)"Mais completo" else if(plan.tier==MembershipTier.PRATA)"Entrada PRO" else null,
                onClick = { selected = plan },
                onBuy = { openTelegramPurchase(plan) }
            )
        }
        item{Text("COMPARE OS PLANOS",fontWeight=FontWeight.Black,fontSize=15.sp)}
        item{PremiumCompareTable()}
    }
}

@Composable private fun PremiumSimplePlanCard(
    title:String, subtitle:String, price:String, benefits:List<String>, colors:List<Color>,
    current:Boolean, badge:String?, onClick:(()->Unit)?=null, onBuy:(()->Unit)?=null
){
    Surface(shape=RoundedCornerShape(22.dp),color=Color.Transparent,border=BorderStroke(1.dp,Color.White.copy(alpha=.15f)),modifier=Modifier.fillMaxWidth().then(if(onClick!=null)Modifier.clickable(onClick=onClick) else Modifier)){
        Column(Modifier.background(Brush.linearGradient(colors)).padding(15.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){
            Row(verticalAlignment=Alignment.CenterVertically){
                Text(title.uppercase(),color=Color.White,fontWeight=FontWeight.Black,fontSize=18.sp,modifier=Modifier.weight(1f))
                if(badge!=null)Surface(shape=RoundedCornerShape(20.dp),color=Color.White.copy(alpha=.14f)){Text(badge,Modifier.padding(horizontal=8.dp,vertical=3.dp),color=Color.White,fontSize=10.sp,fontWeight=FontWeight.Bold)}
                if(current)Text("  • ATUAL",color=Color.White.copy(alpha=.8f),fontSize=10.sp,fontWeight=FontWeight.Bold)
            }
            Text(price,color=Color.White,fontSize=22.sp,fontWeight=FontWeight.Black)
            Text(subtitle,color=Color.White.copy(alpha=.78f),fontSize=11.sp)
            benefits.forEach{ Row(verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.CheckCircle,null,tint=Color(0xFF69E391),modifier=Modifier.size(15.dp));Spacer(Modifier.width(6.dp));Text(it,color=Color.White.copy(alpha=.90f),fontSize=11.sp)} }
            if(onClick!=null) FilledTonalButton(onClick=onClick,modifier=Modifier.fillMaxWidth()){Text("Ver plano $title")}
            if(onBuy!=null) OutlinedButton(
                onClick = onBuy,
                modifier = Modifier.fillMaxWidth(),
                border = BorderStroke(1.dp, Color.White.copy(alpha = .52f)),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
            ) {
                Icon(Icons.Default.Send, null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(7.dp))
                Text("Comprar pelo Telegram", fontWeight = FontWeight.Bold)
            }
        }
    }
}

private sealed interface PremiumCompareValue {
    data class TextValue(val text:String):PremiumCompareValue
    data class Included(val yes:Boolean):PremiumCompareValue
}

@Composable private fun PremiumCompareTable(){
    val Y=PremiumCompareValue.Included(true); val N=PremiumCompareValue.Included(false)
    fun T(v:String)=PremiumCompareValue.TextValue(v)
    val rows=listOf(
        "SONUS Player" to listOf(Y,Y,Y,Y),
        "SONUS Stream" to listOf(Y,Y,Y,Y),
        "SOCIAL EDIT" to listOf(T("15s"),T("30–65s"),T("30–65s"),T("30–65s")),
        "Moedas SONUS" to listOf(T("5/mês"),T("200/mês"),T("500/mês"),T("Ilimitadas")),
        "Artistas" to listOf(T("1"),T("3"),T("8"),T("Ilimitados")),
        "Ferramentas PRO" to listOf(T("1 moeda/anúncio"),T("1 moeda/bloco"),T("1 moeda/bloco"),T("Ilimitadas")),
        "AutoMix" to listOf(T("Moeda/anúncio"),Y,Y,Y),
        "Cortador Pro" to listOf(T("Moeda/anúncio"),Y,Y,Y),
        "Caixa Preta SONUS" to listOf(N,Y,Y,Y),
        "Envios ao Stream/mês" to listOf(T("3"),T("10"),T("20"),T("30")),
        "Temas e ícones" to listOf(T("Básicos"),T("Prata"),T("Prata + Ouro"),T("Todos"))
    )
    Surface(shape=RoundedCornerShape(18.dp),color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.35f)){
        Column(Modifier.padding(10.dp)){
            Row{Text("FUNÇÃO",Modifier.weight(1.55f),fontWeight=FontWeight.Black,fontSize=10.sp);listOf("Grátis","Prata","Ouro","Diamante").forEach{Text(it,Modifier.weight(1f),fontWeight=FontWeight.Black,fontSize=8.sp,textAlign=TextAlign.Center)}}
            rows.forEach{(name,values)->
                HorizontalDivider(Modifier.padding(vertical=5.dp),color=MaterialTheme.colorScheme.outline.copy(alpha=.12f))
                Row(verticalAlignment=Alignment.CenterVertically){
                    Text(name,Modifier.weight(1.55f),fontSize=10.sp)
                    values.forEach{ value -> Box(Modifier.weight(1f),contentAlignment=Alignment.Center){when(value){is PremiumCompareValue.TextValue->Text(value.text,fontSize=9.sp,textAlign=TextAlign.Center);is PremiumCompareValue.Included->Icon(if(value.yes)Icons.Default.CheckCircle else Icons.Default.Cancel,null,tint=if(value.yes)Color(0xFF47C879) else Color(0xFFE55D62),modifier=Modifier.size(17.dp))}} }
                }
            }
        }
    }
}

@Composable
private fun PremiumPlanCard(plan: PremiumPlanInfo, onClick: () -> Unit) {
    val gradient = when (plan.tier) {
        MembershipTier.BRONZE -> membershipGradient(MembershipTier.BRONZE)
        MembershipTier.PRATA -> membershipGradient(MembershipTier.PRATA)
        MembershipTier.OURO -> membershipGradient(MembershipTier.OURO)
        MembershipTier.DIAMANTE -> membershipGradient(MembershipTier.DIAMANTE)
        else -> listOf(Color(0xFF35404E), Color(0xFF1D252E))
    }
    val shape = RoundedCornerShape(24.dp)
    Surface(
        modifier = Modifier.fillMaxWidth().clip(shape).clickable(onClick = onClick),
        color = Color.Transparent,
        border = BorderStroke(1.dp, gradient.first().copy(alpha = .55f)),
        shape = shape
    ) {
        Column(
            Modifier.background(Brush.linearGradient(gradient.map { it.copy(alpha = .62f) } + Color(0xFF101827))).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                PlanGlyph(plan.tier, 34.dp)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text(plan.title, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                        plan.highlight?.let {
                            Surface(shape = RoundedCornerShape(50), color = Color.White.copy(alpha = .15f)) {
                                Text(it, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp))
                            }
                        }
                    }
                    Text(plan.artistLimitLabel, color = Color.White.copy(alpha = .72f), style = MaterialTheme.typography.bodySmall)
                }
                Icon(Icons.Default.ChevronRight, null, tint = Color.White.copy(alpha = .75f))
            }
            Text(plan.monthlyPrice, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
            plan.annualPrice?.let { Text(it, color = Color.White.copy(alpha = .82f), fontWeight = FontWeight.SemiBold) }
            Text(plan.benefits.take(3).joinToString(" • "), color = Color.White.copy(alpha = .72f), style = MaterialTheme.typography.bodySmall, maxLines = 3)
            Surface(shape = RoundedCornerShape(50), color = Color.White.copy(alpha = .12f)) {
                Text(if (plan.annualPrice != null) "Ver mensal e anual" else "Ver opção de 30 dias", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
            }
        }
    }
}

private enum class DeveloperModule(val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    SONUS_MUSIC("SONUS Stream", Icons.Default.Public),
    ANALYTICS("Analytics", Icons.Default.QueryStats),
    REMOTE("Admin", Icons.Default.AdminPanelSettings),
    MONETIZACAO("Monetização", Icons.Default.Paid),
    SUPPORT("Suporte", Icons.Default.SupportAgent),
    PLANOS("Planos", Icons.Default.WorkspacePremium),
    PROMOS("Códigos", Icons.Default.ConfirmationNumber),
    FERRAMENTAS("Ferramentas", Icons.Default.BuildCircle),
    MEDIA("Mídia", Icons.Default.GraphicEq),
    SISTEMA("Sistema", Icons.Default.Memory),
    COMUNIDADE("Comunidade", Icons.Default.Groups),
    LOGS("Logs", Icons.Default.BugReport),
    RESUMO("Resumo", Icons.Default.Dashboard)
}

@Composable
private fun DeveloperPanelScreen(
    authUser: AuthUser,
    testMode: OwnerTestMode,
    onTestModeChange: (OwnerTestMode) -> Unit,
    onRefreshRole: () -> Unit,
    adManager: StreamPulseAdManager,
    initialModuleName: String? = null,
    pendingLrc: String? = null,
    onPendingLrcConsumed: () -> Unit = {},
    onInitialModuleConsumed: () -> Unit = {},
    onOpenLrcEditor: () -> Unit = {},
    onBack: () -> Unit
) {
    var selectedModule by rememberSaveable { mutableStateOf(initialModuleName?.let { runCatching { DeveloperModule.valueOf(it) }.getOrNull() } ?: DeveloperModule.SONUS_MUSIC) }
    var showStreamModeration by rememberSaveable { mutableStateOf(false) }
    var showLrcLibrary by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(initialModuleName) {
        initialModuleName?.let { runCatching { DeveloperModule.valueOf(it) }.getOrNull() }?.let { selectedModule = it }
        if (initialModuleName != null) onInitialModuleConsumed()
    }
    val uidPreview = if (authUser.uid.length > 16) authUser.uid.take(8) + "…" + authUser.uid.takeLast(6) else authUser.uid

    BackHandler(enabled = showStreamModeration || showLrcLibrary) {
        when {
            showStreamModeration -> showStreamModeration = false
            showLrcLibrary -> showLrcLibrary = false
        }
    }

    if (showStreamModeration) {
        SonusStreamCreatorCenter(
            user = authUser,
            tier = MembershipTier.DIAMANTE,
            mode = StreamCenterMode.MODERATION,
            onBack = { showStreamModeration = false }
        )
        return
    }

    if (showLrcLibrary) {
        DeveloperLrcLibraryScreen(onBack = { showLrcLibrary = false }, onOpenEditor = onOpenLrcEditor)
        return
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        PageHeader("Painel Desenvolvedor", onBack)
        Text("Central de controle OWNER", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha=.58f))
        Spacer(Modifier.height(10.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(end=8.dp)) {
            items(DeveloperModule.entries.toList(), key = { it.name }) { module ->
                val selected = module == selectedModule
                Surface(
                    modifier = Modifier.width(112.dp).height(72.dp).clickable { selectedModule = module },
                    shape = RoundedCornerShape(17.dp),
                    color = if (selected) Color(0xFF0D5E78).copy(alpha=.88f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.48f),
                    border = BorderStroke(1.dp, if (selected) Color(0xFF54D8FF).copy(alpha=.70f) else MaterialTheme.colorScheme.outline.copy(alpha=.16f))
                ) {
                    Column(Modifier.fillMaxSize().padding(9.dp), horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.Center) {
                        Icon(module.icon, null, tint = if(selected) Color(0xFF65E0FF) else MaterialTheme.colorScheme.onSurface.copy(alpha=.70f), modifier=Modifier.size(22.dp))
                        Spacer(Modifier.height(5.dp))
                        Text(module.title, fontSize=10.sp, fontWeight=FontWeight.Bold, maxLines=1, overflow=TextOverflow.Ellipsis)
                    }
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Box(Modifier.weight(1f)) {
            when (selectedModule) {
                DeveloperModule.RESUMO -> LazyColumn(
                    modifier=Modifier.fillMaxSize(), verticalArrangement=Arrangement.spacedBy(12.dp), contentPadding=PaddingValues(bottom=34.dp)
                ) {
                    item { DeveloperSectionHero(Icons.Default.Dashboard, "Visão geral", "Status rápido do SONUS e atalhos para os módulos administrativos.", Color(0xFF33C8F2)) }
                    item { OwnerDeveloperCard(authUser, uidPreview, onRefreshRole) }
                    item {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                            DeveloperSummaryTile(Modifier.weight(1f), "v${BuildConfig.VERSION_NAME}", "versão", Color(0xFF5EC8FF))
                            DeveloperSummaryTile(Modifier.weight(1f), "${BuildConfig.VERSION_CODE}", "code", Color(0xFFB694FF))
                            DeveloperSummaryTile(Modifier.weight(1f), if(testMode==OwnerTestMode.OWNER) "OWNER" else testMode.name, "modo", SignalGreen)
                        }
                    }
                    item { DeveloperBuildDeviceCard() }
                    item {
                        Surface(shape=RoundedCornerShape(20.dp),color=Color(0xFF102636).copy(alpha=.78f),border=BorderStroke(1.dp,Color(0xFF3EB8E5).copy(alpha=.30f))) {
                            Column(Modifier.padding(15.dp),verticalArrangement=Arrangement.spacedBy(7.dp)) {
                                Text("Acesso rápido",fontWeight=FontWeight.ExtraBold,color=Color.White)
                                Text("Use os módulos acima para administrar SONUS Stream, Analytics, Admin, Monetização, Suporte, Planos, Códigos, Ferramentas, Mídia, Sistema, Comunidade e Logs.",color=Color.White.copy(.68f),style=MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }


                DeveloperModule.SONUS_MUSIC -> LazyColumn(Modifier.fillMaxSize(), verticalArrangement=Arrangement.spacedBy(12.dp), contentPadding=PaddingValues(bottom=34.dp)) {
                    item {
                        Row(Modifier.fillMaxWidth().height(112.dp),horizontalArrangement=Arrangement.spacedBy(9.dp)) {
                            DeveloperModerationShortcutCard(
                                modifier = Modifier.weight(1f).fillMaxHeight(),
                                onClick = { showStreamModeration = true }
                            )
                            DeveloperLrcShortcutCard(
                                modifier = Modifier.weight(1f).fillMaxHeight(),
                                onClick = { showLrcLibrary = true }
                            )
                        }
                    }
                    item { SonusStreamServiceDiagnosticCard() }
                    item { SonusMusicDeveloperPanel(authUser = authUser, pendingLrc = pendingLrc, onPendingLrcConsumed = onPendingLrcConsumed) }
                }

                DeveloperModule.SUPPORT -> SonusSupportScreen(
                    user = authUser,
                    technicalContext = mapOf(
                        "appVersion" to "${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})",
                        "plan" to testMode.name,
                        "android" to Build.VERSION.RELEASE,
                        "device" to "${Build.MANUFACTURER} ${Build.MODEL}",
                        "page" to "DEVELOPER_SUPPORT"
                    ),
                    onBack = { selectedModule = DeveloperModule.SONUS_MUSIC }
                )

                DeveloperModule.ANALYTICS -> LazyColumn(Modifier.fillMaxSize(), verticalArrangement=Arrangement.spacedBy(12.dp), contentPadding=PaddingValues(bottom=34.dp)) {
                    item { DeveloperRemotePanel(authUser.uid, DeveloperRemoteSection.ANALYTICS) }
                }

                DeveloperModule.PROMOS -> LazyColumn(Modifier.fillMaxSize(), verticalArrangement=Arrangement.spacedBy(12.dp), contentPadding=PaddingValues(bottom=34.dp)) {
                    item { DeveloperRemotePanel(authUser.uid, DeveloperRemoteSection.PROMOS) }
                }

                DeveloperModule.PLANOS -> LazyColumn(Modifier.fillMaxSize(), verticalArrangement=Arrangement.spacedBy(12.dp), contentPadding=PaddingValues(bottom=34.dp)) {
                    item { DeveloperSectionHero(Icons.Default.WorkspacePremium, "Planos & acesso", "Simule os níveis do SONUS sem alterar sua autorização OWNER real.", Color(0xFFFFC857)) }
                    item {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(OwnerTestMode.entries.toList(), key = { it.name }) { mode ->
                                FilterChip(selected = testMode == mode, onClick = { onTestModeChange(mode) }, label = { Text(if (mode == OwnerTestMode.OWNER) "OWNER" else mode.name) }, leadingIcon = if (mode == OwnerTestMode.OWNER) { { Icon(Icons.Default.AdminPanelSettings, null, modifier = Modifier.size(17.dp)) } } else null)
                            }
                        }
                    }
                    item {
                        Surface(shape=RoundedCornerShape(20.dp),color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.68f),border=BorderStroke(1.dp,MaterialTheme.colorScheme.outline.copy(alpha=.18f))) {
                            Column(Modifier.padding(15.dp),verticalArrangement=Arrangement.spacedBy(9.dp)) {
                                Text("Comportamento atual",fontWeight=FontWeight.ExtraBold)
                                Text(when(testMode){
                                    OwnerTestMode.OWNER -> "OWNER • acesso completo • artistas e ferramentas ilimitados"
                                    OwnerTestMode.FREE -> "Simulando Grátis • 5 moedas/mês (+ até 10 por anúncios premiados) • PRO: 1 moeda ou anúncio por bloco de até 5"
                                    OwnerTestMode.PRATA -> "Simulando Prata • 200 moedas/mês • PRO: 1 moeda por bloco; sem saldo, Rewarded"
                                    OwnerTestMode.OURO -> "Simulando Ouro • 500 moedas/mês • PRO: 1 moeda por bloco; sem saldo, Rewarded"
                                    OwnerTestMode.DIAMANTE -> "Simulando Diamante • ferramentas elegíveis ilimitadas"
                                },style=MaterialTheme.typography.bodySmall)
                                Text("A simulação volta para OWNER quando você selecionar OWNER.",style=MaterialTheme.typography.labelSmall,color=SignalYellow)
                            }
                        }
                    }
                }

                DeveloperModule.MONETIZACAO -> LazyColumn(Modifier.fillMaxSize(), verticalArrangement=Arrangement.spacedBy(12.dp), contentPadding=PaddingValues(bottom=34.dp)) {
                    item { DeveloperSectionHero(Icons.Default.Paid, "Monetização", "AdMob/UMP e Rewarded Ads das ferramentas PRO. Player e Stream permanecem sem anúncios.", Color(0xFFFFC857)) }
                    item { DeveloperMonetizationCard(adManager, testMode) }
                }

                DeveloperModule.REMOTE -> LazyColumn(Modifier.fillMaxSize(), verticalArrangement=Arrangement.spacedBy(12.dp), contentPadding=PaddingValues(bottom=34.dp)) {
                    item { DeveloperRemotePanel(authUser.uid, DeveloperRemoteSection.REMOTE) }
                }

                DeveloperModule.FERRAMENTAS -> LazyColumn(Modifier.fillMaxSize(), verticalArrangement=Arrangement.spacedBy(12.dp), contentPadding=PaddingValues(bottom=34.dp)) {
                    item { DeveloperRemotePanel(authUser.uid, DeveloperRemoteSection.TOOLS) }
                }

                DeveloperModule.MEDIA -> LazyColumn(Modifier.fillMaxSize(), verticalArrangement=Arrangement.spacedBy(12.dp), contentPadding=PaddingValues(bottom=34.dp)) {
                    item { DeveloperSectionHero(Icons.Default.GraphicEq, "Diagnóstico de mídia", "Preview, áudio, exportação, spectrum e compatibilidade de codecs.", Color(0xFFB694FF)) }
                    item { DeveloperMediaDiagnosticCard() }
                    // Transcrição ao vivo removida do diagnóstico: letras TXT/LRC permanecem independentes e ativas.
                }

                DeveloperModule.SISTEMA -> LazyColumn(Modifier.fillMaxSize(), verticalArrangement=Arrangement.spacedBy(12.dp), contentPadding=PaddingValues(bottom=34.dp)) {
                    item { DeveloperSectionHero(Icons.Default.Memory, "Firebase & sistema", "Build, dispositivo, rede e infraestrutura do SONUS.", Color(0xFF64D8FF)) }
                    item { DeveloperBuildDeviceCard() }
                    item { DeveloperRemotePanel(authUser.uid, DeveloperRemoteSection.INFRA) }
                }

                DeveloperModule.COMUNIDADE -> LazyColumn(Modifier.fillMaxSize(), verticalArrangement=Arrangement.spacedBy(12.dp), contentPadding=PaddingValues(bottom=34.dp)) {
                    item { DeveloperRemotePanel(authUser.uid, DeveloperRemoteSection.COMMUNITY) }
                }

                DeveloperModule.LOGS -> LazyColumn(Modifier.fillMaxSize(), verticalArrangement=Arrangement.spacedBy(12.dp), contentPadding=PaddingValues(bottom=34.dp)) {
                    item { DeveloperRemotePanel(authUser.uid, DeveloperRemoteSection.LOGS) }
                }
            }
        }
    }
}

@Composable
private fun SonusStreamServiceDiagnosticCard() {
    val context=LocalContext.current;val scope=rememberCoroutineScope();val repo=remember{SonusStreamPlatformRepository(context)}
    var health by remember{mutableStateOf<Map<String,Boolean>>(emptyMap())};var loading by remember{mutableStateOf(false)}
    fun refresh(){scope.launch{loading=true;health=runCatching{repo.ownerStreamHealth()}.getOrDefault(emptyMap());loading=false}}
    LaunchedEffect(Unit){refresh()}
    val services = listOf(
        "audio" to "Áudio", "catalog" to "Catálogo", "counter" to "Contador",
        "artists" to "Artistas", "database" to "Firebase", "storage" to "Storage",
        "telegramUpload" to "Telegram", "analytics" to "Analytics", "notifications" to "Notificações"
    )
    Surface(shape=RoundedCornerShape(20.dp),color=Color(0xFF0D1D28),border=BorderStroke(1.dp,Color(0xFF54E3A8).copy(alpha=.22f))){
        Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){
            Row(verticalAlignment=Alignment.CenterVertically){
                Column(Modifier.weight(1f)){
                    Text("Serviços SONUS Stream",fontWeight=FontWeight.ExtraBold,color=Color.White)
                    Text("Diagnóstico técnico OWNER",style=MaterialTheme.typography.labelSmall,color=Color.White.copy(alpha=.55f))
                }
                IconButton(onClick={refresh()},enabled=!loading){Icon(Icons.Default.Refresh,"Atualizar",tint=Color(0xFF54E3A8))}
            }
            if(loading) LinearProgressIndicator(Modifier.fillMaxWidth())
            services.chunked(3).forEach { rowItems ->
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                    rowItems.forEach { (key,label) ->
                        val ok=health[key]
                        Surface(
                            modifier=Modifier.weight(1f),
                            shape=RoundedCornerShape(12.dp),
                            color=Color.White.copy(alpha=.055f),
                            border=BorderStroke(1.dp,Color.White.copy(alpha=.075f))
                        ){
                            Column(Modifier.padding(horizontal=7.dp,vertical=8.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(3.dp)){
                                Icon(
                                    if(ok==true)Icons.Default.CheckCircle else if(ok==false)Icons.Default.ErrorOutline else Icons.Default.HourglassEmpty,
                                    null,
                                    tint=if(ok==true)SignalGreen else if(ok==false)MaterialTheme.colorScheme.error else SignalYellow,
                                    modifier=Modifier.size(15.dp)
                                )
                                Text(label,color=Color.White,fontSize=9.sp,maxLines=1,overflow=TextOverflow.Ellipsis,textAlign=TextAlign.Center)
                                Text(if(ok==true)"OK" else if(ok==false)"Falha" else "—",fontSize=8.sp,color=Color.White.copy(alpha=.58f))
                            }
                        }
                    }
                    repeat(3-rowItems.size){Spacer(Modifier.weight(1f))}
                }
            }
        }
    }
}

@Composable
private fun DeveloperTranscriptionDiagnosticCard() {
    val context = LocalContext.current
    val available = remember { android.speech.SpeechRecognizer.isRecognitionAvailable(context) }
    val onDevice = remember {
        if (android.os.Build.VERSION.SDK_INT >= 31) android.speech.SpeechRecognizer.isOnDeviceRecognitionAvailable(context) else false
    }
    Surface(shape=RoundedCornerShape(20.dp),color=Color(0xFF14202C).copy(alpha=.86f),border=BorderStroke(1.dp,Color(0xFF63D5A7).copy(alpha=.30f))) {
        Column(Modifier.fillMaxWidth().padding(15.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment=Alignment.CenterVertically) {
                Icon(Icons.Default.RecordVoiceOver,null,tint=Color(0xFF63D5A7));Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)){Text("Transcrição ao vivo",fontWeight=FontWeight.ExtraBold,color=Color.White);Text("Diagnóstico do motor usado em Letras e Legenda ao vivo",fontSize=9.sp,color=Color.White.copy(alpha=.58f))}
                AssistChip(onClick={},enabled=false,label={Text(if(available) "Disponível" else "Indisponível")})
            }
            Text("Motor: ${if(onDevice) "reconhecimento no aparelho" else if(available) "serviço de voz do Android" else "nenhum motor disponível"}",fontSize=10.sp,color=Color.White.copy(alpha=.72f))
            Text("Áudio: PCM mono 16 kHz extraído internamente • sem microfone para mídias reproduzidas no SONUS",fontSize=9.sp,color=Color.White.copy(alpha=.56f))
            Text("Idiomas preparados: Português (Brasil) • English (US) • Español",fontSize=9.sp,color=Color.White.copy(alpha=.56f))
        }
    }
}

private fun developerLrcFileName(entry: SonusUnifiedLrcEntry): String {
    fun clean(raw: String): String {
        val invalid = setOf('\\', '/', ':', '*', '?', '"', '<', '>', '|')
        return raw.map { c -> if (c.code < 32 || c in invalid) ' ' else c }
            .joinToString("")
            .replace(Regex("\\s+"), " ")
            .trim().trimEnd('.', ' ')
    }
    val title = clean(entry.title).ifBlank { "Letra" }
    val artist = clean(entry.artist)
    return if (artist.isBlank()) "$title.lrc" else "$title - $artist.lrc"
}


@Composable
private fun DeveloperModerationShortcutCard(modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(
        modifier = modifier.clip(RoundedCornerShape(22.dp)).clickable(onClick=onClick),
        shape = RoundedCornerShape(22.dp),
        color = Color(0xFF163B42),
        border = BorderStroke(1.dp, Color(0xFF54E3A8).copy(alpha=.34f))
    ) {
        Column(Modifier.fillMaxSize().padding(12.dp),verticalArrangement=Arrangement.Center,horizontalAlignment=Alignment.CenterHorizontally) {
            Icon(Icons.Default.FactCheck,null,tint=Color(0xFF54E3A8),modifier=Modifier.size(25.dp))
            Spacer(Modifier.height(7.dp))
            Text("ABRIR MODERAÇÃO",color=Color.White,fontWeight=FontWeight.ExtraBold,fontSize=11.sp,textAlign=TextAlign.Center,maxLines=1)
            Text("DE ENVIOS",color=Color.White.copy(alpha=.76f),fontWeight=FontWeight.Bold,fontSize=9.sp,textAlign=TextAlign.Center)
        }
    }
}

@Composable
private fun DeveloperLrcShortcutCard(modifier: Modifier = Modifier, onClick: () -> Unit) {
    val context = LocalContext.current
    val repo = remember { SonusOnlineMusicRepository(context.applicationContext) }
    // code131: o resumo do Developer nunca dispara varredura remota de letras.
    // Até a contagem do cache local acontece fora da thread de UI para o primeiro frame abrir leve.
    var count by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        count = withContext(Dispatchers.IO) { repo.cachedUnifiedLrcEntries().size }
    }
    Surface(
        modifier = modifier.clip(RoundedCornerShape(22.dp)).clickable(onClick=onClick),
        shape = RoundedCornerShape(22.dp),
        color = Color(0xFF080A0F),
        border = BorderStroke(1.dp, Color.White.copy(alpha=.18f))
    ) {
        // CODE09: distribui os quatro elementos pelo espaço disponível do cartão.
        // A altura do atalho é fixa na linha do painel; spacers + padding antigos
        // faziam a contagem LRC ultrapassar a área útil em algumas densidades.
        Column(
            Modifier.fillMaxSize().padding(horizontal=12.dp, vertical=7.dp),
            verticalArrangement=Arrangement.SpaceEvenly,
            horizontalAlignment=Alignment.CenterHorizontally
        ) {
            Icon(Icons.Default.Lyrics,null,tint=Color.White,modifier=Modifier.size(26.dp))
            Text("Letras",color=Color.White,fontWeight=FontWeight.ExtraBold,fontSize=14.sp,textAlign=TextAlign.Center,maxLines=1)
            Text("sincronizadas",color=Color.White.copy(alpha=.70f),fontSize=9.sp,textAlign=TextAlign.Center,maxLines=1)
            Text("$count LRC",color=Color(0xFF54E3A8),fontSize=10.sp,fontWeight=FontWeight.Bold,maxLines=1)
        }
    }
}

@Composable
private fun DeveloperLrcLibraryScreen(onBack: () -> Unit, onOpenEditor: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val repo = remember { SonusOnlineMusicRepository(context.applicationContext) }
    var entries by remember { mutableStateOf(repo.cachedUnifiedLrcEntries()) }
    var query by rememberSaveable { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }
    var pendingDownload by remember { mutableStateOf<SonusUnifiedLrcEntry?>(null) }
    var bulkProgress by remember { mutableFloatStateOf(0f) }
    var bulkCancelRequested by remember { mutableStateOf(false) }

    val saveOne = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/x-lrc")) { uri ->
        val entry = pendingDownload
        pendingDownload = null
        if (uri != null && entry != null) scope.launch {
            loading = true
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val text = repo.unifiedLrcText(entry) ?: error("LRC indisponível")
                    context.contentResolver.openOutputStream(uri,"w")?.bufferedWriter(Charsets.UTF_8)?.use { it.write(text) }
                        ?: error("Não foi possível abrir o destino")
                }
            }
            loading = false
            status = if (result.isSuccess) "${entry.title} baixada." else "Falha ao baixar ${entry.title}."
        }
    }
    val saveAll = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) scope.launch {
            loading = true
            bulkCancelRequested = false
            bulkProgress = 0f
            status = "Preparando ${entries.size} letras…"
            var exported = 0
            var failed = 0
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val out = context.contentResolver.openOutputStream(uri) ?: error("Não foi possível abrir o destino")
                    out.use { raw ->
                        ZipOutputStream(raw.buffered()).use { zip ->
                            val used = mutableSetOf<String>()
                            entries.forEachIndexed { index, entry ->
                                if (bulkCancelRequested) return@forEachIndexed
                                val text = repo.unifiedLrcText(entry)
                                if (text.isNullOrBlank()) {
                                    failed++
                                } else {
                                    var name = developerLrcFileName(entry)
                                    if (!used.add(name.lowercase(Locale.ROOT))) {
                                        val base = name.removeSuffix(".lrc")
                                        var n = 2
                                        while (!used.add("$base ($n).lrc".lowercase(Locale.ROOT))) n++
                                        name = "$base ($n).lrc"
                                    }
                                    zip.putNextEntry(ZipEntry(name))
                                    zip.write(text.toByteArray(Charsets.UTF_8))
                                    zip.closeEntry()
                                    exported++
                                }
                                withContext(Dispatchers.Main) {
                                    bulkProgress = (index + 1).toFloat() / entries.size.coerceAtLeast(1).toFloat()
                                    status = if (bulkCancelRequested) "Cancelando…" else "Exportando ${index + 1}/${entries.size} • $exported válidas"
                                }
                            }
                        }
                    }
                }
            }
            loading = false
            status = when {
                bulkCancelRequested -> "Exportação interrompida • $exported letras incluídas."
                result.isSuccess -> "Pacote salvo • $exported letras${if(failed>0)" • $failed falha(s)" else ""}."
                else -> "Não foi possível salvar todas as letras."
            }
            bulkProgress = 0f
            bulkCancelRequested = false
        }
    }

    fun refreshLibrary(force: Boolean) {
        if (loading) return
        scope.launch {
            loading = true
            bulkProgress = 0f
            status = "Escaneando catálogo e letras sincronizadas…"
            entries = withContext(Dispatchers.IO) {
                runCatching { repo.scanUnifiedLrcLibrary(force=force) }.getOrDefault(repo.cachedUnifiedLrcEntries())
            }
            loading = false
            status = "Varredura concluída • ${entries.size} LRC disponíveis."
        }
    }

    LaunchedEffect(Unit) { refreshLibrary(force=false) }
    val filtered = remember(entries, query) {
        val q = query.trim()
        if (q.isBlank()) entries else entries.filter { it.title.contains(q,true) || it.artist.contains(q,true) || it.publicFile?.name.orEmpty().contains(q,true) }
    }

    Column(Modifier.fillMaxSize().padding(horizontal=16.dp)) {
        PageHeader("Letras sincronizadas", onBack)
        OutlinedTextField(query,{query=it},modifier=Modifier.fillMaxWidth(),singleLine=true,label={Text("Buscar música ou artista")},leadingIcon={Icon(Icons.Default.Search,null)})
        Spacer(Modifier.height(7.dp))
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            FilledTonalButton(onClick={refreshLibrary(force=true)},enabled=!loading,modifier=Modifier.weight(1f)) {
                Icon(Icons.Default.Refresh,null); Spacer(Modifier.width(5.dp)); Text("Atualizar")
            }
            FilledTonalButton(onClick={saveAll.launch("SONUS_Letras_Sincronizadas.zip")},enabled=!loading && entries.isNotEmpty(),modifier=Modifier.weight(1f)) {
                Icon(Icons.Default.Download,null); Spacer(Modifier.width(5.dp)); Text("Baixar todas")
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("${entries.size} letras disponíveis • ${filtered.size} exibidas",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.60f))
        status?.let { Text(it,style=MaterialTheme.typography.labelSmall,color=Color(0xFF54E3A8),modifier=Modifier.padding(top=4.dp)) }
        if (loading) {
            LinearProgressIndicator(progress={if(bulkProgress>0f)bulkProgress else 0.05f},modifier=Modifier.fillMaxWidth().padding(top=7.dp))
            if (bulkProgress > 0f) TextButton(onClick={bulkCancelRequested=true},modifier=Modifier.align(Alignment.End)){Text("Cancelar exportação")}
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(8.dp),contentPadding=PaddingValues(bottom=30.dp)) {
            items(filtered,key={it.key}) { entry ->
                Surface(shape=RoundedCornerShape(16.dp),color=Color(0xFF0B0D12),border=BorderStroke(1.dp,Color.White.copy(alpha=.10f))) {
                    Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically) {
                        Surface(shape=RoundedCornerShape(12.dp),color=Color.White.copy(alpha=.07f)) { Icon(Icons.Default.Lyrics,null,tint=Color.White,modifier=Modifier.padding(10.dp).size(21.dp)) }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(entry.title,fontWeight=FontWeight.Bold,color=Color.White,maxLines=1,overflow=TextOverflow.Ellipsis)
                            Text(entry.artist.ifBlank{"Artista não identificado"},fontSize=10.sp,color=Color.White.copy(alpha=.58f),maxLines=1,overflow=TextOverflow.Ellipsis)
                            Text(
                                when(entry.source){
                                    SonusUnifiedLrcSource.PCLOUD -> "LRC oficial • pCloud"
                                    SonusUnifiedLrcSource.COMMUNITY -> "Comunidade" + entry.contributorName.takeIf { it.isNotBlank() }?.let { " • $it" }.orEmpty()
                                    SonusUnifiedLrcSource.CATALOG -> "LRC do catálogo"
                                },
                                fontSize=9.sp,color=if(entry.source==SonusUnifiedLrcSource.COMMUNITY)Color(0xFFFF9CAB) else Color(0xFF54E3A8)
                            )
                        }
                        if(entry.source==SonusUnifiedLrcSource.COMMUNITY && entry.trackFileId!=null) {
                            IconButton(onClick={
                                val trackId = entry.trackFileId ?: return@IconButton
                                scope.launch {
                                    loading=true
                                    val r=repo.removeCommunityLrc(trackId)
                                    status=if(r.isSuccess)"Letra comunitária removida." else "Não foi possível remover a letra."
                                    entries=withContext(Dispatchers.IO){runCatching{repo.scanUnifiedLrcLibrary(force=true)}.getOrDefault(entries)}
                                    loading=false
                                }
                            },enabled=!loading){Icon(Icons.Default.DeleteOutline,"Remover somente esta letra",tint=Color(0xFFFF7D86))}
                        }
                        IconButton(onClick=onOpenEditor,enabled=!loading) { Icon(Icons.Default.EditNote,"Abrir Editor LRC",tint=Color.White.copy(alpha=.82f)) }
                        IconButton(onClick={pendingDownload=entry;saveOne.launch(developerLrcFileName(entry))},enabled=!loading) { Icon(Icons.Default.Download,"Baixar LRC",tint=Color.White) }
                    }
                }
            }
        }
    }
}

@Composable
private fun DeveloperSectionHero(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, tint: Color, modifier: Modifier = Modifier) {
    Surface(modifier=modifier,shape=RoundedCornerShape(22.dp), color=tint.copy(alpha=.11f), border=BorderStroke(1.dp,tint.copy(alpha=.34f))) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment=Alignment.CenterVertically) {
            Surface(shape=RoundedCornerShape(15.dp),color=tint.copy(alpha=.16f)) { Icon(icon,null,tint=tint,modifier=Modifier.padding(12.dp).size(26.dp)) }
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) { Text(title,fontWeight=FontWeight.ExtraBold,fontSize=20.sp); Text(subtitle,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.62f)) }
        }
    }
}

@Composable
private fun DeveloperSummaryTile(modifier: Modifier, value: String, label: String, tint: Color) {
    Surface(modifier,shape=RoundedCornerShape(16.dp),color=tint.copy(alpha=.10f),border=BorderStroke(1.dp,tint.copy(alpha=.26f))) {
        Column(Modifier.padding(vertical=12.dp,horizontal=7.dp),horizontalAlignment=Alignment.CenterHorizontally) { Text(value,fontWeight=FontWeight.Black,fontSize=17.sp,maxLines=1); Text(label,fontSize=9.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.58f)) }
    }
}

@Composable
private fun OwnerDeveloperCard(authUser: AuthUser, uidPreview: String, onRefreshRole: () -> Unit) {
    Surface(shape=RoundedCornerShape(22.dp),color=Color(0xFF12243C).copy(alpha=.96f),border=BorderStroke(1.dp,Color(0xFF79BFFF).copy(alpha=.52f))) {
        Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment=Alignment.CenterVertically) {
                Surface(shape=CircleShape,color=Color(0xFF79BFFF).copy(alpha=.16f)) { Icon(Icons.Default.AdminPanelSettings,null,tint=Color(0xFFA6D3FF),modifier=Modifier.padding(10.dp).size(25.dp)) }
                Spacer(Modifier.width(11.dp)); Column(Modifier.weight(1f)){Text("OWNER verificado",color=Color.White,fontWeight=FontWeight.ExtraBold,fontSize=18.sp);Text("Autorização remota ativa",color=SignalGreen,style=MaterialTheme.typography.bodySmall,fontWeight=FontWeight.Bold)};OwnerStatusPill()
            }
            Text(authUser.email ?: "Conta autenticada",color=Color.White.copy(alpha=.74f),style=MaterialTheme.typography.bodySmall)
            Text("UID: $uidPreview",color=Color.White.copy(alpha=.52f),style=MaterialTheme.typography.labelSmall)
            OutlinedButton(onClick=onRefreshRole,modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Refresh,null,modifier=Modifier.size(18.dp));Spacer(Modifier.width(7.dp));Text("Verificar autorização novamente")}
        }
    }
}

@Composable
private fun DeveloperBuildDeviceCard() {
    val codecInfos = remember { runCatching { MediaCodecList(MediaCodecList.ALL_CODECS).codecInfos.toList() }.getOrDefault(emptyList()) }
    val encoders = codecInfos.filter { it.isEncoder }
    val h264 = encoders.any { info -> info.supportedTypes.any { it.equals("video/avc", true) } }
    val hevc = encoders.any { info -> info.supportedTypes.any { it.equals("video/hevc", true) } }
    val av1 = encoders.any { info -> info.supportedTypes.any { it.equals("video/av01", true) } }
    Surface(shape=RoundedCornerShape(20.dp),color=Color(0xFF12243C).copy(alpha=.82f),border=BorderStroke(1.dp,Color(0xFF79BFFF).copy(alpha=.25f))) {
        Column(Modifier.padding(15.dp),verticalArrangement=Arrangement.spacedBy(7.dp)) {
            Text("Build e dispositivo",fontWeight=FontWeight.ExtraBold,color=Color.White)
            Text("SONUS ${BuildConfig.VERSION_NAME} • code ${BuildConfig.VERSION_CODE}",color=Color.White.copy(.78f))
            Text("${Build.MANUFACTURER} ${Build.MODEL} • Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",color=Color.White.copy(.65f),style=MaterialTheme.typography.bodySmall)
            Text("ABI: ${Build.SUPPORTED_ABIS.joinToString()} • RAM/armazenamento conforme Android",color=Color.White.copy(.55f),style=MaterialTheme.typography.labelSmall)
            Text("Encoders: H.264 ${if(h264) "✓" else "—"} • HEVC ${if(hevc) "✓" else "—"} • AV1 ${if(av1) "✓" else "—"}",color=SignalGreen,fontWeight=FontWeight.Bold,style=MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun DeveloperMediaDiagnosticCard() {
    Surface(shape=RoundedCornerShape(20.dp),color=Color(0xFF211B33).copy(alpha=.72f),border=BorderStroke(1.dp,Color(0xFFB694FF).copy(alpha=.25f))) {
        Column(Modifier.padding(15.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
            Text("Ferramentas de diagnóstico",fontWeight=FontWeight.ExtraBold,color=Color.White)
            Text("Preview",color=Color(0xFFC9B3FF),fontWeight=FontWeight.Bold); Text("FPS • tempo de frame • compatibilidade de codec",color=Color.White.copy(.72f),style=MaterialTheme.typography.bodySmall)
            Text("Áudio",color=Color(0xFFC9B3FF),fontWeight=FontWeight.Bold); Text("sessão • sample rate • FFT • reprodução",color=Color.White.copy(.72f),style=MaterialTheme.typography.bodySmall)
            Text("Exportação",color=Color(0xFFC9B3FF),fontWeight=FontWeight.Bold); Text("resolução • codec • FPS • bitrate • duração • validação final",color=Color.White.copy(.72f),style=MaterialTheme.typography.bodySmall)
            Text("Spectrum atual: ${PulsePlayerService.lastSpectrumEngine}",color=Color.White.copy(.72f),style=MaterialTheme.typography.bodySmall)
            Text("Compatibilidade: Native → PCM Compat → Fallback",color=Color.White.copy(.72f),style=MaterialTheme.typography.bodySmall)
            Text("Logs e feature flags permanecem isolados do usuário comum.",color=SignalYellow,style=MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun DeveloperMonetizationCard(adManager: StreamPulseAdManager, testMode: OwnerTestMode) {
    val context = LocalContext.current
    val ready by adManager.ready.collectAsState()
    val rewardedReady by adManager.rewardedReady.collectAsState()
    val rewardedLoading by adManager.rewardedLoading.collectAsState()
    val canRequestAds by adManager.canRequestAds.collectAsState()
    val umpStatus by adManager.umpStatus.collectAsState()
    val metrics by adManager.metrics.collectAsState()
    Surface(shape=RoundedCornerShape(22.dp),color=Color(0xFF2C2410).copy(alpha=.82f),border=BorderStroke(1.dp,Color(0xFFFFC857).copy(alpha=.30f))) {
        Column(Modifier.fillMaxWidth().padding(15.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment=Alignment.CenterVertically) {
                Icon(Icons.Default.Paid,null,tint=Color(0xFFFFC857));Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)){Text("AdMob • ${adManager.environmentLabel}",fontWeight=FontWeight.Black);Text(if(ready)"SDK pronto" else "Aguardando consentimento/SDK",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.58f))}
                AssistChip(onClick={},label={Text(if(adManager.productionMode)"PRODUÇÃO" else "TESTE")})
            }
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                DeveloperSummaryTile(Modifier.weight(1f),if(rewardedReady)"OK" else "…","Rewarded",if(rewardedReady)SignalGreen else SignalYellow)
                DeveloperSummaryTile(Modifier.weight(1f),metrics.rewardsGranted.toString(),"recompensas",SignalGreen)
                DeveloperSummaryTile(Modifier.weight(1f),metrics.failures.toString(),"falhas",if(metrics.failures==0L)SignalGreen else Color(0xFFFF8A80))
            }
            Text("code103: anúncios foram removidos do Player e do SONUS Stream. Rewarded Ads existem somente para desbloqueios das ferramentas PRO quando o usuário opta por anúncio/está sem moedas.",style=MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                OutlinedButton(onClick={adManager.refreshAds()},modifier=Modifier.weight(1f)){Icon(Icons.Default.Refresh,null);Spacer(Modifier.width(4.dp));Text("Atualizar")}
                OutlinedButton(onClick={
                    val activity=context.findComponentActivityForApp()
                    if(activity!=null)adManager.showRewarded(
                        activity = activity,
                        ownerOrAdFree = false,
                        forceTestUnit = true,
                        onReward = { Toast.makeText(context,"Rewarded OK • teste sem alterar saldo",Toast.LENGTH_SHORT).show() },
                        onUnavailable = { Toast.makeText(context,it,Toast.LENGTH_SHORT).show() }
                    )
                },enabled=ready,modifier=Modifier.weight(1f)){Text("Testar Rewarded")}
            }
            Text("UMP: $umpStatus",fontSize=10.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.68f))
            Text("canRequestAds: ${if(canRequestAds) "SIM" else "NÃO"} • Rewarded: ${when { rewardedReady -> "PRONTO"; rewardedLoading -> "CARREGANDO"; else -> "AGUARDANDO" }}",fontSize=10.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.68f))
            Text("Solicitações: ${metrics.rewardedRequests} • impressões: ${metrics.rewardedImpressions} • recompensas: ${metrics.rewardsGranted}",fontSize=10.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.62f))
            metrics.lastError?.let{Text("Último erro: $it",fontSize=9.sp,color=Color(0xFFFF9A9A))}
            if(metrics.lastErrorCode!=null || !metrics.lastErrorDomain.isNullOrBlank()) Text("Código: ${metrics.lastErrorCode ?: "-"} • domínio: ${metrics.lastErrorDomain ?: "-"}",fontSize=9.sp,color=Color(0xFFFFB3B3))
            metrics.lastErrorMessage?.let{Text("Mensagem: $it",fontSize=9.sp,color=Color(0xFFFFB3B3))}
            metrics.lastResponseInfo?.let{Text("ResponseInfo: $it",fontSize=8.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.52f),maxLines=4,overflow=TextOverflow.Ellipsis)}
            Text("OWNER em simulação FREE usa sempre a unidade oficial de teste do Google; usuários FREE reais continuam no Rewarded de produção.",fontSize=9.sp,color=Color(0xFFFFD77A))
            Text("Modo OWNER simulado: ${testMode.name}. IDs reais nunca são exibidos neste painel.",fontSize=9.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.52f))
        }
    }
}

@Composable
private fun SettingsScreen(
    state: AppState,
    selectedArtist: Artist,
    membershipTier: MembershipTier,
    authUser: AuthUser,
    isGuest: Boolean,
    isOwner: Boolean,
    isSupport: Boolean,
    ownerTestMode: OwnerTestMode,
    repository: AppRepository,
    authManager: AuthManager,
    cloudManager: CloudAccountManager,
    adManager: StreamPulseAdManager,
    onGuestLogin: () -> Unit,
    onDeveloper: () -> Unit,
    onSupport: () -> Unit,
    onStreamCreator: () -> Unit,
    onOrganizeTabs: () -> Unit,
    onSelect: (String) -> Unit,
    onAddArtist: () -> Unit,
    onEditArtist: (String) -> Unit,
    onArtistUpdate: (Artist) -> Unit,
    onDeleteArtist: (String) -> Unit,
    onRestoreState: (AppState) -> Unit,
    onPreferencesChange: (UserPreferences) -> Unit,
    onPremium: () -> Unit,
    onUsage: () -> Unit,
    onNotificationCenter: () -> Unit,
    onNotificationSettings: () -> Unit,
    onCheckUpdate: () -> Unit,
    unreadNotifications: Int,
    onSignOut: () -> Unit,
    onReset: () -> Unit
) {
    var confirmReset by remember { mutableStateOf(false) }
    var confirmSignOut by remember { mutableStateOf(false) }
    var menuArtistId by remember { mutableStateOf<String?>(null) }
    var confirmDeleteArtistId by remember { mutableStateOf<String?>(null) }
    var showThemeDialog by remember { mutableStateOf(false) }
    var showFontDialog by remember { mutableStateOf(false) }
    var showTextAppearanceDialog by remember { mutableStateOf(false) }
    var showAppIconDialog by remember { mutableStateOf(false) }
    val themeScrollState = rememberLazyListState()
    val fontScrollState = rememberLazyListState()
    val textAppearanceScrollState = rememberLazyListState()
    var backupPreview by remember { mutableStateOf<BackupPreview?>(null) }
    var backupMessage by remember { mutableStateOf<String?>(null) }
    var backgroundPhotoMessage by remember { mutableStateOf<String?>(null) }
    var lastBackupUriString by rememberSaveable { mutableStateOf<String?>(null) }
    var showAbout by remember { mutableStateOf(false) }
    var showAccountDialog by remember { mutableStateOf(false) }

    val prefs = state.preferences
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val camaleonPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) onPreferencesChange(prefs.copy(themeMode = ThemeMode.CAMALEON))
    }
    val sortedArtists = state.artists.sortedBy { it.name.lowercase(Locale.getDefault()) }
    val menuArtist = menuArtistId?.let { id -> state.artists.firstOrNull { it.id == id } }

    // Launchers de backup preservados do fluxo funcional anterior.
    // O code80 reorganizou Ajustes, mas estes callbacks ainda são usados na seção Backup e Restauração.
    val backupCreateLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) {
            scope.launch {
                backupMessage = "Criando backup..."
                val result = withContext(Dispatchers.IO) { BackupManager.writeBackup(context, uri, state, BuildConfig.VERSION_NAME) }
                if (result.isSuccess) {
                    lastBackupUriString = uri.toString()
                    backupMessage = "Backup criado com sucesso"
                    SonusNotificationCenter.add(
                        context,
                        "Backup concluído",
                        "Seu backup local foi criado com sucesso.",
                        "BACKUP",
                        importantExternal = false
                    )
                } else {
                    backupMessage = "Falha ao criar backup"
                    SonusNotificationCenter.add(
                        context,
                        "Falha no backup",
                        "Não foi possível criar o arquivo de backup. Seus dados atuais não foram alterados.",
                        "BACKUP",
                        importantExternal = true
                    )
                }
                delay(1500)
                backupMessage = null
            }
        }
    }

    val backupOpenLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                backupMessage = "Lendo backup..."
                val result = withContext(Dispatchers.IO) { BackupManager.readBackup(context, uri) }
                backupMessage = null
                if (result.isSuccess) backupPreview = result.getOrNull()
                else {
                    backupMessage = "Arquivo de backup inválido"
                    SonusNotificationCenter.add(
                        context,
                        "Backup não pôde ser lido",
                        "O arquivo selecionado não parece ser um backup válido do SONUS.",
                        "BACKUP",
                        importantExternal = true
                    )
                    delay(1600)
                    backupMessage = null
                }
            }
        }
    }

    if (showAccountDialog) {
        AlertDialog(
            onDismissRequest = { showAccountDialog = false },
            title = { Text("Conta SONUS", fontWeight = FontWeight.ExtraBold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        AuthProfileAvatar(authUser.photoUrl)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                authUser.displayName?.takeIf { it.isNotBlank() }
                                    ?: authUser.email?.substringBefore('@')
                                    ?: "Conta SONUS",
                                fontWeight = FontWeight.ExtraBold
                            )
                            Text(authUser.email ?: "Conta autenticada", style = MaterialTheme.typography.bodySmall, maxLines = 1)
                            Spacer(Modifier.height(5.dp))
                            if (isOwner) OwnerStatusPill() else PlanStatusPill(membershipTier)
                        }
                    }
                    HorizontalDivider()
                    Text("Sua sessão está protegida e vinculada à conta atual.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha=.62f))
                    if (!isGuest && authUser.uid.isNotBlank()) {
                        val publicId = sonusPublicId(authUser.uid)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("ID do usuário", style = MaterialTheme.typography.labelSmall)
                                Text(publicId, fontWeight = FontWeight.ExtraBold)
                            }
                            IconButton(onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                clipboard.setPrimaryClip(ClipData.newPlainText("ID SONUS", publicId))
                                Toast.makeText(context, "ID SONUS copiado", Toast.LENGTH_SHORT).show()
                            }) { Icon(Icons.Default.ContentCopy, "Copiar ID") }
                        }
                    }
                    if (isOwner && ownerTestMode != OwnerTestMode.OWNER) {
                        Text("Modo de teste: ${ownerTestMode.name}", fontWeight = FontWeight.Bold, color = SignalYellow)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAccountDialog = false; confirmSignOut = true }) { Text("Sair da conta") }
            },
            dismissButton = { TextButton(onClick = { showAccountDialog = false }) { Text("Fechar") } }
        )
    }

    if (showAppIconDialog) {
        var selectedIconId by remember(showAppIconDialog) { mutableStateOf(AppIconCatalog.selectedId(context)) }
        AlertDialog(
            onDismissRequest = { showAppIconDialog = false },
            title = { Text("Ícone do SONUS", fontWeight = FontWeight.ExtraBold) },
            text = {
                LazyColumn(
                    modifier = Modifier.heightIn(max = 520.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item { Text("Personalização não consome Moedas SONUS. Cada selo mostra o plano necessário.", style = MaterialTheme.typography.bodySmall) }
                    items(AppIconCatalog.icons) { icon ->
                        val unlocked = isOwner || membershipTier.ordinal >= icon.tier.ordinal
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = if (selectedIconId == icon.id) MaterialTheme.colorScheme.primaryContainer.copy(alpha=.52f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.34f),
                            border = BorderStroke(1.dp, if(selectedIconId==icon.id) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha=.14f)),
                            modifier = Modifier.fillMaxWidth().clickable(enabled=unlocked) {
                                AppIconCatalog.apply(context, icon).onSuccess { selectedIconId = icon.id }
                            }
                        ) {
                            Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Image(painterResource(icon.previewRes), null, Modifier.size(54.dp).clip(RoundedCornerShape(13.dp)))
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(icon.title, fontWeight = FontWeight.Bold)
                                    Text(icon.tier.name, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                }
                                Icon(if(unlocked){if(selectedIconId==icon.id)Icons.Default.CheckCircle else Icons.Default.ChevronRight}else Icons.Default.Lock,null)
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick={showAppIconDialog=false}){Text("Fechar")} }
        )
    }

    if (showAbout) {
        AlertDialog(
            onDismissRequest = { showAbout = false },
            title = { Text("Sobre o SONUS", fontWeight = FontWeight.ExtraBold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "SONUS ${BuildConfig.VERSION_NAME}",
                        fontWeight = FontWeight.Black,
                        fontSize = 20.sp
                    )
                    Text(
                        "Versão ${BuildConfig.VERSION_NAME} • code${BuildConfig.VERSION_CODE}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                    HorizontalDivider()
                    Text("Novidades desta versão", fontWeight = FontWeight.ExtraBold)
                    SONUS_CURRENT_VERSION_SUMMARY.forEach { item ->
                        Text("• $item", style = MaterialTheme.typography.bodySmall)
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showAbout = false }) { Text("Fechar") } }
        )
    }

    if (showThemeDialog) {
        val themes = ThemeMode.entries.filterNot { it == ThemeMode.SYSTEM || it == ThemeMode.PHOTO }
        AlertDialog(
            onDismissRequest = { showThemeDialog = false },
            title = {
                Column {
                    Text("Temas")
                    Text("Temas seguem os níveis Grátis, Prata, Ouro e Diamante", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .58f))
                }
            },
            text = {
                LazyColumn(
                    state = themeScrollState,
                    modifier = Modifier.heightIn(max = 520.dp),
                    verticalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    items(themes, key = { it.name }) { mode ->
                        val required = themeRequiredTier(mode)
                        val unlocked = isOwner || required == null || membershipTier.ordinal >= required.ordinal
                        Surface(
                            modifier = Modifier.fillMaxWidth().clickable(enabled = unlocked) {
                                if (mode == ThemeMode.CAMALEON && androidx.core.content.ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                                    camaleonPermissionLauncher.launch(Manifest.permission.CAMERA)
                                } else {
                                    onPreferencesChange(prefs.copy(themeMode = mode))
                                }
                            },
                            shape = RoundedCornerShape(16.dp),
                            color = if (prefs.themeMode == mode) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    Modifier.size(29.dp)
                                        .clip(CircleShape)
                                        .background(Brush.linearGradient(themePreviewColors(mode)))
                                        .border(1.dp, Color.White.copy(alpha = .25f), CircleShape)
                                )
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(themeLabel(mode), fontWeight = FontWeight.SemiBold)
                                    Text(themeDescription(mode), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .55f), maxLines = 1)
                                }
                                required?.let { PremiumFeatureMark(it) }
                                if (!unlocked) { Spacer(Modifier.width(6.dp)); Icon(Icons.Default.Lock, "Bloqueado") }
                                else if (prefs.themeMode == mode) { Spacer(Modifier.width(6.dp)); Icon(Icons.Default.CheckCircle, null) }
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showThemeDialog = false }) { Text("Fechar") } }
        )
    }

    if (showFontDialog) {
        AlertDialog(
            onDismissRequest = { showFontDialog = false },
            title = {
                Column {
                    Text("Fontes")
                    Text("Escolha um estilo • fontes seguem o nível do seu plano", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .58f))
                }
            },
            text = {
                LazyColumn(state = fontScrollState, modifier = Modifier.heightIn(max = 520.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    items(AppFont.entries, key = { it.name }) { font ->
                        val required = fontRequiredTier(font)
                        val unlocked = isOwner || required == null || membershipTier.ordinal >= required.ordinal
                        Surface(
                            modifier = Modifier.fillMaxWidth().clickable(enabled = unlocked) {
                                onPreferencesChange(prefs.copy(appFont = font))
                            },
                            shape = RoundedCornerShape(16.dp),
                            color = if (prefs.appFont == font) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(fontLabel(font), fontWeight = FontWeight.SemiBold)
                                    Text("SONUS 123", fontFamily = fontPreviewFamily(font), fontSize = 14.sp)
                                }
                                required?.let { PremiumFeatureMark(it) }
                                if (!unlocked) { Spacer(Modifier.width(8.dp)); Icon(Icons.Default.Lock, "Bloqueado") }
                                else if (prefs.appFont == font) { Spacer(Modifier.width(8.dp)); Icon(Icons.Default.CheckCircle, null) }
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showFontDialog = false }) { Text("Fechar") } }
        )
    }

    if (showTextAppearanceDialog) {
        AlertDialog(
            onDismissRequest = { showTextAppearanceDialog = false },
            title = { Column { Text("Cor e estilo do texto"); Text("Gratuito • a alteração é aplicada sem fechar esta tela", style = MaterialTheme.typography.bodySmall) } },
            text = {
                LazyColumn(state = textAppearanceScrollState, modifier = Modifier.heightIn(max = 520.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    items(TextAppearance.entries, key = { it.name }) { appearance ->
                        Surface(
                            modifier = Modifier.fillMaxWidth().clickable { onPreferencesChange(prefs.copy(textAppearance = appearance)) },
                            shape = RoundedCornerShape(16.dp),
                            color = if (prefs.textAppearance == appearance) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(textAppearanceLabel(appearance), fontWeight = FontWeight.SemiBold)
                                    Text(textAppearanceExample(appearance), style = MaterialTheme.typography.bodySmall)
                                }
                                if (prefs.textAppearance == appearance) Icon(Icons.Default.CheckCircle, null)
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showTextAppearanceDialog = false }) { Text("Fechar") } }
        )
    }

    val preview = backupPreview
    if (preview != null) {
        AlertDialog(
            onDismissRequest = { backupPreview = null },
            title = { Text("Restaurar backup?") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("Criado: ${preview.manifest.createdAtIso.replace('T', ' ').take(16)}")
                    Text("Versão: ${preview.manifest.appVersion}")
                    Text("Artistas: ${preview.manifest.artists}")
                    Text("Registros diários: ${preview.manifest.dailyRecords}")
                    Text("Fotos: ${preview.manifest.photos}")
                    Spacer(Modifier.height(5.dp))
                    Text("Os dados atuais deste aparelho serão substituídos pelos dados do backup.", color = SignalOrange)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        backupMessage = "Restaurando dados..."
                        val result = withContext(Dispatchers.IO) { BackupManager.prepareRestoredState(context, preview) }
                        if (result.isSuccess) {
                            result.getOrNull()?.let(onRestoreState)
                            backupMessage = "Backup restaurado"
                            SonusNotificationCenter.add(
                                context,
                                "Backup restaurado",
                                "Os dados do backup foram restaurados com sucesso.",
                                "BACKUP",
                                importantExternal = false
                            )
                        } else {
                            backupMessage = "Não foi possível restaurar"
                            SonusNotificationCenter.add(
                                context,
                                "Falha ao restaurar backup",
                                "O SONUS não conseguiu concluir a restauração. Os dados atuais foram preservados.",
                                "BACKUP",
                                importantExternal = true
                            )
                        }
                        backupPreview = null
                        delay(1500)
                        backupMessage = null
                    }
                }) { Text("Restaurar") }
            },
            dismissButton = { TextButton(onClick = { backupPreview = null }) { Text("Cancelar") } }
        )
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Apagar todos os dados?") },
            text = { Text("Essa ação remove artistas e preferências deste aparelho.") },
            confirmButton = { TextButton(onClick = { confirmReset = false; onReset() }) { Text("Apagar") } },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Cancelar") } }
        )
    }

    if (confirmSignOut) {
        AlertDialog(
            onDismissRequest = { confirmSignOut = false },
            title = { Text("Sair da conta?") },
            text = { Text("Sua sessão será encerrada. Os artistas, históricos e configurações locais deste aparelho não serão apagados.") },
            confirmButton = {
                TextButton(onClick = { confirmSignOut = false; onSignOut() }) { Text("Sair") }
            },
            dismissButton = { TextButton(onClick = { confirmSignOut = false }) { Text("Cancelar") } }
        )
    }


    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(9.dp),
        contentPadding = PaddingValues(top = 15.dp, bottom = 32.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Ajustes", fontSize = 27.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                BadgedBox(badge = {
                    if (unreadNotifications > 0) Badge(containerColor = Color(0xFFD6A72F)) { Text(if (unreadNotifications > 99) "99+" else unreadNotifications.toString(), color = Color.White, fontWeight = FontWeight.Black) }
                }) {
                    IconButton(onClick = onNotificationCenter) {
                        Image(painter = painterResource(R.drawable.sonus_notification_bell), contentDescription = "Notificações", modifier = Modifier.size(30.dp))
                    }
                }
            }
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (isOwner) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        SettingsHubTile(
                            icon = Icons.Default.AccountCircle,
                            title = "Conta",
                            subtitle = authUser.displayName?.takeIf { it.isNotBlank() } ?: authUser.email?.substringBefore('@') ?: "SONUS",
                            accent = Color(0xFF69A2FF),
                            containerColor = Color(0xFF164D95).copy(alpha = .34f),
                            modifier = Modifier.weight(1f),
                            avatarUrl = authUser.photoUrl,
                            onClick = { showAccountDialog = true }
                        )
                        SettingsHubTile(
                            icon = Icons.Default.AdminPanelSettings,
                            title = "Desenvolvedor",
                            subtitle = if (ownerTestMode == OwnerTestMode.OWNER) "OWNER" else "Teste ${ownerTestMode.name}",
                            accent = Color(0xFFC9EEFF),
                            containerColor = Color(0xFF9EDCFF).copy(alpha = .16f),
                            modifier = Modifier.weight(1f),
                            onClick = onDeveloper
                        )
                        SettingsHubTile(
                            icon = Icons.Default.WorkspacePremium,
                            title = "Premium",
                            subtitle = "Acesso completo",
                            accent = Color(0xFFFFD15A),
                            containerColor = Color(0xFF9A6500).copy(alpha = .24f),
                            modifier = Modifier.weight(1f),
                            onClick = onPremium
                        )
                    }
                    SettingsHubTile(
                        icon = Icons.Default.Timer,
                        title = "Uso do app",
                        subtitle = "Estatísticas locais",
                        accent = Color(0xFFFF737B),
                        containerColor = Color(0xFF8B1F31).copy(alpha = .24f),
                        modifier = Modifier.fillMaxWidth(),
                        wide = true,
                        onClick = onUsage
                    )
                } else {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        SettingsHubTile(
                            icon = Icons.Default.AccountCircle,
                            title = "Conta",
                            subtitle = if (isGuest) "Convidado" else authUser.displayName?.takeIf { it.isNotBlank() } ?: "SONUS",
                            accent = Color(0xFF69A2FF),
                            containerColor = Color(0xFF164D95).copy(alpha = .34f),
                            modifier = Modifier.weight(1f),
                            avatarUrl = if (isGuest) null else authUser.photoUrl,
                            onClick = { if (isGuest) onGuestLogin() else showAccountDialog = true }
                        )
                        SettingsHubTile(
                            icon = Icons.Default.WorkspacePremium,
                            title = "Premium",
                            subtitle = membershipLabel(membershipTier),
                            accent = Color(0xFFFFD15A),
                            containerColor = Color(0xFF9A6500).copy(alpha = .24f),
                            modifier = Modifier.weight(1f),
                            onClick = onPremium
                        )
                        SettingsHubTile(
                            icon = Icons.Default.Timer,
                            title = "Uso do app",
                            subtitle = "Estatísticas",
                            accent = Color(0xFFFF737B),
                            containerColor = Color(0xFF8B1F31).copy(alpha = .24f),
                            modifier = Modifier.weight(1f),
                            onClick = onUsage
                        )
                    }
                }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SettingsHubTile(
                        icon = Icons.Default.Notifications,
                        title = "Notificações",
                        subtitle = "Central SONUS",
                        accent = Color(0xFF8DD7FF),
                        containerColor = Color(0xFF12344A).copy(alpha = .42f),
                        modifier = Modifier.weight(1f),
                        onClick = onNotificationSettings
                    )
                }
            }
        }

        item {
            CompactSettingsCard {
                SettingsNavRow(Icons.Default.SupportAgent, if (isSupport || isOwner) "Suporte SONUS" else "Fale Conosco", if (isSupport || isOwner) "Atendimentos e diagnósticos" else "Ajuda, Premium e problemas técnicos", onClick = onSupport)
                SettingsDivider()
            }
        }

        item { SettingsSectionTitle("Personalização") }
        item {
            CompactSettingsCard {
                SettingsNavRow(Icons.Default.ViewWeek, "Organizar abas principais", "Escolher, ocultar e reordenar atalhos", onClick = onOrganizeTabs)
                SettingsDivider()
                SettingsNavRow(Icons.Default.ColorLens, "Tema", themeLabel(prefs.themeMode), onClick = { showThemeDialog = true })
                SettingsDivider()
                SettingsNavRow(Icons.Default.TextFields, "Fonte", fontLabel(prefs.appFont), onClick = { showFontDialog = true })
                SettingsDivider()
                SettingsNavRow(Icons.Default.FormatColorText, "Cor do texto", textAppearanceLabel(prefs.textAppearance), onClick = { showTextAppearanceDialog = true })
                SettingsDivider()
                SettingsNavRow(
                    Icons.Default.Apps,
                    "Ícone do aplicativo",
                    AppIconCatalog.icons.firstOrNull { it.id == AppIconCatalog.selectedId(context) }?.title ?: "Rosa",
                    onClick = { showAppIconDialog = true }
                )
                SettingsDivider()
                // code132: liga/desliga o player por cima da tela de bloqueio (padrão: ligado).
                var lockPlayerEnabled by remember { mutableStateOf(SonusLockScreenPrefs.enabled(context)) }
                SettingsToggleRow(
                    Icons.Default.Lock,
                    "Player na tela de bloqueio",
                    "Letras e controles ao tocar no cartão de mídia com o aparelho bloqueado",
                    lockPlayerEnabled
                ) {
                    lockPlayerEnabled = it
                    SonusLockScreenPrefs.setEnabled(context, it)
                }
            }
        }

        item { SettingsSectionTitle("Monitor de uso de dados") }
        item {
            CompactSettingsCard {
                SettingsToggleRow(
                    Icons.Default.DataUsage,
                    "Monitor de uso de dados",
                    "Mostra consumo aproximado nas funções online",
                    prefs.showDataUsageMonitor
                ) { onPreferencesChange(prefs.copy(showDataUsageMonitor = it)) }
                if (prefs.showDataUsageMonitor) {
                    SettingsDivider()
                    SettingsToggleRow(
                        Icons.Default.CellTower,
                        "Avisar em dados móveis",
                        "Alerta quando uma sessão online ultrapassar seu limite",
                        prefs.warnOnMobileData
                    ) { onPreferencesChange(prefs.copy(warnOnMobileData = it)) }
                    SettingsDivider()
                    Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text("Limite do alerta móvel", fontWeight = FontWeight.SemiBold)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(25, 50, 100, 250).forEach { mb ->
                                FilterChip(
                                    selected = prefs.mobileDataWarningMb == mb,
                                    onClick = { onPreferencesChange(prefs.copy(mobileDataWarningMb = mb)) },
                                    label = { Text("$mb MB", fontSize = 10.sp) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }

                }
            }
        }

        item { SettingsSectionTitle("Assinatura tátil SONUS") }
        item {
            CompactSettingsCard {
                SettingsToggleRow(
                    Icons.Default.Vibration,
                    "Assinatura tátil SONUS",
                    "Feedback curto e consistente para ações, confirmações e alertas",
                    prefs.hapticsEnabled
                ) { onPreferencesChange(prefs.copy(hapticsEnabled = it)) }
                if (prefs.hapticsEnabled) {
                    SettingsDivider()
                    Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text("Intensidade", fontWeight = FontWeight.SemiBold)
                        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            listOf(0 to "Suave", 1 to "Média", 2 to "Forte").forEach { (value, label) ->
                                FilterChip(
                                    selected = prefs.hapticsIntensity == value,
                                    onClick = { onPreferencesChange(prefs.copy(hapticsIntensity = value)) },
                                    label = { Text(label) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                        // code133: confere na hora se o aparelho vibra com a intensidade escolhida.
                        OutlinedButton(
                            onClick = {
                                if (!PulseHaptics.preview(context, prefs)) {
                                    Toast.makeText(context, "Este aparelho não informa vibração disponível.", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Testar vibração") }
                    }
                    SettingsDivider()
                    SettingsToggleRow(Icons.Default.Headphones, "Player", "Gestos e ações importantes do SONUS PLAYER", prefs.hapticsPlayer) {
                        onPreferencesChange(prefs.copy(hapticsPlayer = it))
                    }
                    SettingsDivider()
                    SettingsToggleRow(Icons.Default.Build, "Ferramentas", "Confirmações e ações dos mini apps", prefs.hapticsTools) {
                        onPreferencesChange(prefs.copy(hapticsTools = it))
                    }
                    SettingsDivider()
                    SettingsToggleRow(Icons.Default.Tune, "SONUS TUNE", "Confirma uma única vez quando a corda entra afinada", prefs.hapticsTuner) {
                        onPreferencesChange(prefs.copy(hapticsTuner = it))
                    }
                }
            }
        }

        item { SettingsSectionTitle("Código promocional") }
        item {
            if (isGuest) {
                CompactSettingsCard {
                    SettingsNavRow(
                        Icons.Default.LocalOffer,
                        "Código promocional",
                        "Entre na sua conta para aplicar benefícios",
                        onClick = onGuestLogin
                    )
                }
            } else {
                CloudCouponSettings(
                    state = state,
                    authUser = authUser,
                    repository = repository
                )
            }
        }

        item { SettingsSectionTitle("Backup e Restauração") }
        item {
            CompactSettingsCard {
                SettingsNavRow(
                    Icons.Default.Archive,
                    "Criar backup ZIP",
                    "FREE • ${state.artists.size} artista(s)",
                    onClick = { backupCreateLauncher.launch("SONUS_Backup_${LocalDate.now()}.zip") }
                )
                SettingsDivider()
                SettingsNavRow(
                    Icons.Default.RestorePage,
                    "Restaurar backup ZIP",
                    "Recupere artistas, fotos, histórico e preferências",
                    onClick = { backupOpenLauncher.launch(arrayOf("application/zip", "application/octet-stream", "application/x-zip-compressed")) }
                )
                SettingsDivider()
                SettingsNavRow(
                    Icons.Default.Share,
                    "Compartilhar último ZIP",
                    if (lastBackupUriString == null) "Crie um backup primeiro" else "Enviar pelo compartilhamento do Android",
                    enabled = lastBackupUriString != null,
                    onClick = {
                        lastBackupUriString?.let { raw ->
                            val uri = Uri.parse(raw)
                            val intent = Intent(Intent.ACTION_SEND).apply {
                                type = "application/zip"
                                putExtra(Intent.EXTRA_STREAM, uri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(Intent.createChooser(intent, "Compartilhar backup"))
                        }
                    }
                )
                backupMessage?.let {
                    Text(it, modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp), color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
                }
                SettingsDivider()
                if (isGuest) {
                    SettingsNavRow(
                        Icons.Default.Cloud,
                        "Backup Online",
                        "Ouro • entre na conta para sincronizar",
                        onClick = onGuestLogin
                    )
                } else {
                    CloudBackupSettings(
                        state = state,
                        authUser = authUser,
                        membershipTier = membershipTier,
                        isOwner = isOwner,
                        onStateRestored = onRestoreState,
                        embedded = true
                    )
                }
            }
        }

        item { SettingsSectionTitle("Informações") }
        item {
            CompactSettingsCard {
                SettingsNavRow(
                    Icons.Default.SystemUpdateAlt,
                    "ATUALIZAÇÃO SONUS",
                    "Canal oficial de novidades e atualizações no Telegram",
                    onClick = {
                        runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/sonusappupdate"))) }
                            .onFailure { Toast.makeText(context, "Não foi possível abrir o Telegram.", Toast.LENGTH_LONG).show() }
                    }
                )
                SettingsDivider()
                SettingsNavRow(
                    Icons.Default.Info,
                    "Sobre o SONUS",
                    "Versão ${BuildConfig.VERSION_NAME} • novidades da versão atual",
                    onClick = { showAbout = true }
                )
                SettingsDivider()
                SettingsNavRow(
                    Icons.Default.Policy,
                    "Política de Privacidade",
                    "Abrir a política pública do SONUS",
                    onClick = {
                        runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://raffatheoo-afk.github.io/sonus-privacy/"))) }
                    }
                )
            }
        }

        item { SettingsSectionTitle("Segurança") }
        item {
            if (isGuest) {
                CompactSettingsCard {
                    SettingsNavRow(
                        Icons.Default.Security,
                        "Zona de segurança da conta",
                        "Modo convidado • entre para gerenciar uma conta",
                        onClick = onGuestLogin
                    )
                }
            } else {
                AccountSecuritySettings(
                    authUser = authUser,
                    repository = repository,
                    authManager = authManager,
                    onAfterAccountDeleted = { }
                )
            }
        }
    }

}

@Composable
private fun AppUsageScreen(
    preferences: UserPreferences,
    membershipTier: MembershipTier,
    isOwner: Boolean,
    authUser: AuthUser,
    usageEvents: List<PremiumUsageEvent>,
    onBack: () -> Unit,
    onClearUsage: () -> Unit
) {
    val ctx = LocalContext.current
    val playerStatsStore = remember { PulsePlayerStatsStore(ctx) }
    val proUsageStore = remember { SonusProUsageStats(ctx) }
    val streamRepo = remember { SonusStreamPlatformRepository(ctx) }
    val streamLocalAnalytics = remember { com.sonusstudios.streampulse.tools.SonusStreamLocalAnalyticsStore(ctx) }
    val streamLocalRevision by streamLocalAnalytics.revisionFlow.collectAsState()
    val streamLocalTotal = remember(streamLocalRevision) { streamLocalAnalytics.snapshotAllTime(limit = 5000) }
    val nowMillis by produceState(initialValue = System.currentTimeMillis()) {
        while (true) { value = System.currentTimeMillis(); delay(1000) }
    }
    val activeSession = AppSessionClock.startedAtMillis.takeIf { it > 0L }?.let { (nowMillis - it).coerceAtLeast(0L) } ?: 0L
    val periods = listOf("Hoje","Ontem","7 dias","15 dias","Mês","30 dias","3 meses","Total")
    var period by rememberSaveable { mutableStateOf("Mês") }
    val today = LocalDate.now()
    fun inPeriod(day: String): Boolean = runCatching {
        val d=LocalDate.parse(day)
        when(period){
            "Hoje" -> d==today
            "Ontem" -> d==today.minusDays(1)
            "7 dias" -> !d.isBefore(today.minusDays(6)) && !d.isAfter(today)
            "15 dias" -> !d.isBefore(today.minusDays(14)) && !d.isAfter(today)
            "Mês" -> !d.isBefore(today.withDayOfMonth(1)) && !d.isAfter(today)
            "30 dias" -> !d.isBefore(today.minusDays(29)) && !d.isAfter(today)
            "3 meses" -> !d.isBefore(today.minusMonths(3)) && !d.isAfter(today)
            else -> true
        }
    }.getOrDefault(false)
    val historical = if(period=="Total") preferences.appUsageTotalMillis else preferences.appUsageDailyMillis.filterKeys(::inPeriod).values.sum()
    val totalUsage = historical + if(period=="Hoje" || period=="Mês" || period=="7 dias" || period=="15 dias" || period=="30 dias" || period=="3 meses" || period=="Total") activeSession else 0L
    val featureTotals = remember(preferences.appUsageFeatureDailyMillis, preferences.appUsageFeatureMillis, period) {
        if(period=="Total") preferences.appUsageFeatureMillis else buildMap<String,Long> {
            preferences.appUsageFeatureDailyMillis.forEach { (key,v) ->
                val split=key.indexOf('|'); if(split>0){ val day=key.substring(0,split); val feature=key.substring(split+1); if(inPeriod(day)) put(feature,(get(feature)?:0L)+v) }
            }
        }
    }
    val usedDays = if(period=="Total") preferences.appUsageDaysIso.distinct().size else preferences.appUsageDailyMillis.keys.count(::inPeriod)
    val average = if (usedDays > 0) totalUsage / usedDays.toLong() else totalUsage
    val longestSession = maxOf(preferences.appUsageLongestSessionMillis, activeSession)
    val premiumRemaining = preferences.premiumExpiresAtEpochMillis?.let { (it - nowMillis).coerceAtLeast(0L) }
    val premiumText = when {
        isOwner -> "OWNER • acesso permanente"
        membershipTier == MembershipTier.FREE || premiumRemaining == null || premiumRemaining <= 0L -> "Nenhum plano Premium ativo"
        else -> "${membershipLabel(membershipTier)} • ${formatDurationDetailed(premiumRemaining)} restantes"
    }
    val topFeature = featureTotals.maxByOrNull { it.value }
    val uid=android.os.Process.myUid()
    val baseRx=remember { TrafficStats.getUidRxBytes(uid).coerceAtLeast(0L) }; val baseTx=remember { TrafficStats.getUidTxBytes(uid).coerceAtLeast(0L) }
    var rx by remember { mutableLongStateOf(baseRx) }; var tx by remember { mutableLongStateOf(baseTx) }
    var downBps by remember { mutableLongStateOf(0L) }; var upBps by remember { mutableLongStateOf(0L) }; var networkName by remember { mutableStateOf("Offline") }
    LaunchedEffect(Unit){ var lastRx=rx; var lastTx=tx; while(true){ delay(1000); val nr=TrafficStats.getUidRxBytes(uid).coerceAtLeast(lastRx); val nt=TrafficStats.getUidTxBytes(uid).coerceAtLeast(lastTx); downBps=(nr-lastRx).coerceAtLeast(0); upBps=(nt-lastTx).coerceAtLeast(0); rx=nr;tx=nt;lastRx=nr;lastTx=nt; val cm=ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager; val caps=cm?.activeNetwork?.let(cm::getNetworkCapabilities); networkName=when{caps==null->"Offline";caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)->"Wi‑Fi";caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)->"Dados móveis";caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)->"Ethernet";else->"Rede"} } }
    val dataPeriodRx = if(period=="Total") preferences.dataUsageTotalRxBytes else preferences.dataUsageDailyRxBytes.filterKeys(::inPeriod).values.sum()
    val dataPeriodTx = if(period=="Total") preferences.dataUsageTotalTxBytes else preferences.dataUsageDailyTxBytes.filterKeys(::inPeriod).values.sum()

    val startDate: LocalDate? = when(period){
        "Hoje" -> today
        "Ontem" -> today.minusDays(1)
        "7 dias" -> today.minusDays(6)
        "15 dias" -> today.minusDays(14)
        "Mês" -> today.withDayOfMonth(1)
        "30 dias" -> today.minusDays(29)
        "3 meses" -> today.minusMonths(3)
        else -> null
    }
    val endDate: LocalDate? = when(period){"Ontem"->today.minusDays(1);"Total"->null;else->today}
    val playerStats = remember(period, preferences.appUsageLastAccessIso) {
        if(startDate==null||endDate==null) playerStatsStore.snapshot(limit=5000) else playerStatsStore.snapshot(startDate,endDate,limit=5000)
    }
    val startMs = startDate?.atStartOfDay(ZoneId.systemDefault())?.toInstant()?.toEpochMilli()
    val endMs = endDate?.plusDays(1)?.atStartOfDay(ZoneId.systemDefault())?.toInstant()?.toEpochMilli()?.minus(1)
    val proUsage = remember(period, usageEvents.size) { proUsageStore.snapshot(startMs,endMs) }
    val replayEstimate = playerStats.topTracks.sumOf { (it.plays - 1).coerceAtLeast(0) }
    val radioSourceStats = playerStats.sourceStats.filter { it.name.contains("Rádio",true) || it.name.contains("Radio",true) }
    val radioListeningMs = radioSourceStats.sumOf { it.listenedMs }
    val radioPlays = radioSourceStats.sumOf { it.plays }
    val streamListeningMs = playerStats.sourceStats.filter { it.name.contains("SONUS Stream",true) || it.name.contains("Rádio",true) || it.name.contains("Radio",true) }.sumOf { it.listenedMs }
    val favoriteGenre = playerStats.topGenres.firstOrNull()?.first
    val submissions by produceState(initialValue=emptyList<com.sonusstudios.streampulse.stream.StreamSubmission>(),authUser.uid,period){
        value=if(authUser.uid.isBlank()) emptyList() else runCatching{streamRepo.ownSubmissions(authUser.uid)}.getOrDefault(emptyList())
    }
    val periodSubmissions = submissions.filter { sub -> (startMs==null||sub.createdAt>=startMs) && (endMs==null||sub.createdAt<=endMs) }
    val streamUsageRemote by produceState(initialValue=longArrayOf(0,0,0,0,0),authUser.uid,streamLocalRevision){
        value=runCatching{
            val snap=com.google.firebase.database.FirebaseDatabase.getInstance().getReference("streamUserSongStats").child(authUser.uid).get().awaitUsageSnapshot()
            longArrayOf(
                snap.children.sumOf{it.child("playCount").getValue(Long::class.java)?:0L},
                snap.children.sumOf{it.child("completions").getValue(Long::class.java)?:0L},
                snap.children.sumOf{it.child("replayCount").getValue(Long::class.java)?:0L},
                snap.children.sumOf{it.child("skips").getValue(Long::class.java)?:0L},
                snap.children.count{it.child("liked").getValue(Boolean::class.java)==true}.toLong()
            )
        }.getOrDefault(longArrayOf(0,0,0,0,0))
    }
    // code113 counter fix: o painel pessoal usa o maior valor confirmado entre Firebase
    // e o motor local-first. Assim uma falha de rede/regra não transforma atividade real em zero.
    val streamUsageTotal = remember(streamUsageRemote, streamLocalTotal) {
        longArrayOf(
            maxOf(streamUsageRemote[0], streamLocalTotal.validPlays),
            maxOf(streamUsageRemote[1], streamLocalTotal.completions),
            maxOf(streamUsageRemote[2], streamLocalTotal.replays),
            maxOf(streamUsageRemote[3], streamLocalTotal.skips),
            streamUsageRemote[4]
        )
    }

    val previousPeriodUsage = remember(period, preferences.appUsageDailyMillis) {
        val days = when(period){"Hoje"->1;"Ontem"->1;"7 dias"->7;"15 dias"->15;"Mês"->today.dayOfMonth;"30 dias"->30;else->0}
        if(days<=0) 0L else {
            val currentStart = startDate ?: today
            val prevEnd = currentStart.minusDays(1)
            val prevStart = prevEnd.minusDays((days-1).toLong())
            preferences.appUsageDailyMillis.entries.sumOf { (day,ms) -> val d=runCatching{LocalDate.parse(day)}.getOrNull(); if(d!=null&&!d.isBefore(prevStart)&&!d.isAfter(prevEnd)) ms else 0L }
        }
    }
    val trendText = if(previousPeriodUsage>0L && totalUsage>0L){
        val pct=((totalUsage-previousPeriodUsage)*100.0/previousPeriodUsage).roundToInt()
        when{pct>0->"$pct% a mais que o período anterior";pct<0->"${-pct}% a menos que o período anterior";else->"Uso estável em relação ao período anterior"}
    } else "Comparação aparece quando houver histórico suficiente"

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 30.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { PageHeader("Uso do app SONUS", onBack) }
        item {
            Surface(shape=RoundedCornerShape(22.dp),color=Color(0xFF5A171B).copy(alpha=.86f),border=BorderStroke(1.dp,Color(0xFFFF5B5B).copy(alpha=.55f))) {
                Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                    Text("Seus dados de utilização",color=Color.White,fontWeight=FontWeight.ExtraBold,fontSize=20.sp)
                    Text("Estatísticas locais do SONUS. Escolha o período para atualizar todos os cartões.",color=Color.White.copy(alpha=.72f),style=MaterialTheme.typography.bodySmall)
                    Column(verticalArrangement=Arrangement.spacedBy(5.dp)) {
                        periods.chunked(4).forEach { rowPeriods ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(5.dp)) {
                                rowPeriods.forEach { p ->
                                    FilterChip(selected=period==p,onClick={period=p},label={Text(p,fontSize=9.sp)},modifier=Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }
            }
        }
        item { UsageStatCard(Icons.Default.Insights,"Seu uso em resumo", "${formatDurationDetailed(totalUsage)} • ${playerStats.totalPlays} reprodução(ões)", listOfNotNull(proUsage.favoriteTool?.let{"Ferramenta favorita: $it"}, favoriteGenre?.let{"Gênero mais ouvido: $it"}).joinToString(" • ").ifBlank{trendText}, Color(0xFF9A7CFF)) }
        item { UsageStatCard(Icons.Default.TrendingUp,"Tendência",trendText,"Comparação baseada no mesmo tamanho de período quando há histórico",Color(0xFFB694FF)) }
        item { UsageStatCard(Icons.Default.Timer,"Tempo total de uso",formatDurationDetailed(totalUsage),"Conta enquanto o SONUS está em primeiro plano",Color(0xFFFF6B6B)) }
        item { UsageStatCard(Icons.Default.Headphones,"Tempo no SONUS PLAYER",formatDurationDetailed((featureTotals["SONUS PLAYER"]?:0L)+(featureTotals["Player"]?:0L)),"Somente a tela do Player; não soma o Stream",Color(0xFF69E6FF)) }
        item { UsageStatCard(Icons.Default.Radio,"Tempo no SONUS Stream",formatDurationDetailed(featureTotals["SONUS Stream"]?:0L),"Tempo na área do Stream",Color(0xFF57D6B1)) }
        item { UsageStatCard(Icons.Default.Podcasts,"Tempo ouvido na SONUS Rádio",formatDurationDetailed(radioListeningMs),"$radioPlays item(ns) de Rádio no período • locuções não geram view de faixa",Color(0xFF4CD8FF)) }
        item { UsageStatCard(Icons.Default.GraphicEq,"Reprodução local", "${playerStats.totalPlays} iniciadas • ${playerStats.totalCompleted} concluídas", "${playerStats.totalSkips} puladas • $replayEstimate repetições estimadas", Color(0xFF77D9FF)) }
        item { UsageStatCard(Icons.Default.Verified,"SONUS Stream • reproduções válidas",streamUsageTotal[0].toString(),"Total da conta • critério dinâmico por faixa + janela de 8 min",Color(0xFF59D19C)) }
        item { UsageStatCard(Icons.Default.Replay,"Interações do Stream","${streamUsageTotal[1]} concluídas • ${streamUsageTotal[2]} replays","${streamUsageTotal[3]} pulos • ${streamUsageTotal[4]} likes ativos",Color(0xFF64C7FF)) }
        item { UsageStatCard(Icons.Default.VideoLibrary,"Tempo no SONUS VIDEO",formatDurationDetailed((featureTotals["SONUS VIDEO"]?:0L)+(featureTotals["STUDIO SONUS"]?:0L)),"Vídeos locais, nuvem e links",SignalGreen) }
        item { UsageStatCard(Icons.Default.AutoAwesome,"Tempo em APLICATIVOS SONUS",formatDurationDetailed((featureTotals["DESTAQUES SONUS"]?:0L)+(featureTotals["Destaques"]?:0L)),"Ferramentas essenciais",Color(0xFF9A7CFF)) }
        item { UsageStatCard(Icons.Default.Handyman,"Ferramentas PRO","${proUsage.operations} operação(ões) • ${proUsage.filesProcessed} arquivo(s)",proUsage.favoriteTool?.let{"Mais usada: $it"}?:"Histórico desta métrica começa na 1.0.0",Color(0xFFFFC857)) }
        item { UsageStatCard(Icons.Default.MonetizationOn,"Desbloqueios PRO","${proUsage.blocksUnlocked} bloco(s)","${proUsage.coinUnlocks} por moeda • ${proUsage.adUnlocks} por anúncio premiado",Color(0xFFFFB85C)) }
        item { UsageStatCard(Icons.Default.UploadFile,"Envios SONUS Stream","${periodSubmissions.size} no período","${periodSubmissions.count{it.status=="REVIEWING"||it.status=="RECEIVED"}} em análise • ${periodSubmissions.count{it.status=="APPROVED"||it.status=="PUBLISHED"}} aprovados/publicados • ${periodSubmissions.count{it.status=="REJECTED"}} rejeitados",Color(0xFF58D7FF)) }
        item { UsageStatCard(Icons.Default.Settings,"Tempo em Ajustes",formatDurationDetailed(featureTotals["Ajustes"]?:0L),"Configurações, Premium, suporte e estatísticas",Color(0xFF8EA7FF)) }
        item { UsageStatCard(Icons.Default.Login,"Entradas no SONUS","${preferences.appUsageSessionCount} entrada(s)","Uma nova sessão conta como uma entrada",SignalGreen) }
        item { UsageStatCard(Icons.Default.QueryStats,"Média diária de uso",formatDurationShort(average),"Baseada no período selecionado",SignalBlue) }
        item { UsageStatCard(Icons.Default.LocalFireDepartment,"Maior sessão",formatDurationDetailed(longestSession),"Maior período contínuo registrado",SignalOrange) }
        item { UsageStatCard(Icons.Default.WorkspacePremium,"Premium restante",premiumText,"Plano atual e tempo restante",membershipGradient(membershipTier).first()) }
        item { UsageStatCard(Icons.Default.Today,"Último acesso",preferences.appUsageLastAccessIso?.let(::formatUsageAccess)?:"Ainda não registrado","Última abertura registrada",MaterialTheme.colorScheme.primary) }
        item {
            Text("Rede e consumo",fontWeight=FontWeight.ExtraBold,fontSize=18.sp)
        }
        item { UsageStatCard(Icons.Default.DataUsage,"Consumo no período","↓ ${formatDataBytes(dataPeriodRx)} • ↑ ${formatDataBytes(dataPeriodTx)}","Histórico acumulado pelo processo SONUS",Color(0xFF42D7E8)) }
        item { UsageStatCard(Icons.Default.Speed,"Velocidade atual","↓ ${formatDataRate(downBps)} • ↑ ${formatDataRate(upBps)}","$networkName • mede o tráfego real do Pulse, sem speed test",Color(0xFF68E0A5)) }
        item { UsageStatCard(Icons.Default.Storage,"Consumo total","${formatDataBytes(preferences.dataUsageTotalRxBytes+preferences.dataUsageTotalTxBytes)}","Download + upload acumulados",Color(0xFF9A8CFF)) }
        item {
            var confirmClear by remember { mutableStateOf(false) }
            OutlinedButton(onClick={confirmClear=true}, modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.DeleteSweep,null); Spacer(Modifier.width(7.dp)); Text("Limpar todos os dados de uso") }
            if(confirmClear) AlertDialog(onDismissRequest={confirmClear=false}, title={Text("Limpar dados de uso?")}, text={Text("Somente as métricas desta tela serão zeradas. Conta, plano, arquivos e configurações permanecem intactos.")}, confirmButton={TextButton(onClick={playerStatsStore.clear();proUsageStore.clear();onClearUsage();confirmClear=false}){Text("Limpar")}}, dismissButton={TextButton(onClick={confirmClear=false}){Text("Cancelar")}})
        }
    }
}

private suspend fun com.google.android.gms.tasks.Task<com.google.firebase.database.DataSnapshot>.awaitUsageSnapshot(): com.google.firebase.database.DataSnapshot = suspendCancellableCoroutine { cont ->
    addOnSuccessListener { if (cont.isActive) cont.resume(it) }
    addOnFailureListener { if (cont.isActive) cont.resumeWithException(it) }
    addOnCanceledListener { cont.cancel() }
}

private fun formatDataBytes(bytes:Long):String { val b=bytes.coerceAtLeast(0L); return when { b>=1024L*1024L*1024L -> String.format(java.util.Locale.US,"%.2f GB",b/(1024.0*1024.0*1024.0)); b>=1024L*1024L -> String.format(java.util.Locale.US,"%.1f MB",b/(1024.0*1024.0)); b>=1024L -> String.format(java.util.Locale.US,"%.1f KB",b/1024.0); else -> "$b B" } }
private fun formatDataRate(bytesPerSec:Long):String = "${formatDataBytes(bytesPerSec)}/s"

@Composable
private fun UsageStatCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    value: String,
    subtitle: String,
    accent: Color
) {
    Surface(
        shape = RoundedCornerShape(19.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = .82f),
        border = BorderStroke(1.dp, accent.copy(alpha = .28f))
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = CircleShape, color = accent.copy(alpha = .14f)) {
                Icon(icon, null, tint = accent, modifier = Modifier.padding(9.dp).size(21.dp))
            }
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(value, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = accent)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .56f))
            }
        }
    }
}

private fun formatDurationDetailed(ms: Long): String {
    val totalMinutes = (ms.coerceAtLeast(0L) / 60_000L)
    val days = totalMinutes / (24L * 60L)
    val hours = (totalMinutes / 60L) % 24L
    val minutes = totalMinutes % 60L
    return when {
        days > 0L -> "${days}d ${hours}h ${minutes}min"
        hours > 0L -> "${hours}h ${minutes}min"
        else -> "${minutes}min"
    }
}

private fun formatDurationShort(ms: Long): String {
    val totalMinutes = (ms.coerceAtLeast(0L) / 60_000L)
    return if (totalMinutes >= 60L) "${totalMinutes / 60L}h ${totalMinutes % 60L}min/dia" else "${totalMinutes} min/dia"
}

private fun formatUsageAccess(raw: String): String = runCatching {
    val instant = Instant.parse(raw)
    val local = instant.atZone(ZoneId.systemDefault())
    val date = local.toLocalDate()
    val time = local.toLocalTime().format(DateTimeFormatter.ofPattern("HH:mm"))
    if (date == LocalDate.now()) "Hoje • $time" else "${date.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))} • $time"
}.getOrDefault(raw.take(16).replace('T', ' '))

@Composable
private fun AuthProfileAvatar(photoUrl: String?, avatarSize: androidx.compose.ui.unit.Dp = 56.dp, iconSize: androidx.compose.ui.unit.Dp = 38.dp) {
    val bitmap by produceState<android.graphics.Bitmap?>(initialValue = null, photoUrl) {
        value = if (photoUrl.isNullOrBlank()) null else withContext(Dispatchers.IO) {
            runCatching { URL(photoUrl).openStream().use { stream -> BitmapFactory.decodeStream(stream) } }.getOrNull()
        }
    }
    Surface(
        shape = CircleShape,
        color = MaterialTheme.colorScheme.primaryContainer,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = .34f))
    ) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap!!.asImageBitmap(),
                contentDescription = "Foto da conta",
                modifier = Modifier.size(avatarSize).clip(CircleShape),
                contentScale = ContentScale.Crop
            )
        } else {
            Box(Modifier.size(avatarSize), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.AccountCircle, contentDescription = null, modifier = Modifier.size(iconSize), tint = MaterialTheme.colorScheme.primary)
            }
        }
    }
}


@Composable
private fun BlackBoxSettingsCard(
    pinned: Boolean,
    onPinnedChange: (Boolean) -> Unit,
    onOpen: () -> Unit
) {
    val accent = Color(0xFFB8C6E8)
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = Color(0xFF080A0F).copy(alpha = .96f),
        border = BorderStroke(1.dp, accent.copy(alpha = .24f))
    ) {
        Column(Modifier.padding(horizontal = 11.dp, vertical = 9.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Surface(shape = RoundedCornerShape(10.dp), color = accent.copy(alpha = .12f)) {
                    Icon(Icons.Default.Security, null, tint = accent, modifier = Modifier.padding(7.dp).size(18.dp))
                }
                Column(Modifier.weight(1f)) {
                    Text("Caixa Preta SONUS", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                    Text("Gravação contínua local com buffer substituível e PIN.", style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .62f))
                }
                FilledTonalButton(
                    onClick = onOpen,
                    modifier = Modifier.height(32.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.filledTonalButtonColors(containerColor = accent.copy(alpha = .13f), contentColor = accent)
                ) { Text("Abrir", fontSize = 11.sp) }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = pinned, onCheckedChange = onPinnedChange, modifier = Modifier.height(30.dp))
                Spacer(Modifier.width(6.dp))
                Icon(Icons.Default.PushPin, null, tint = accent, modifier = Modifier.size(14.dp))
                Spacer(Modifier.width(4.dp))
                Text("Mostrar nas abas principais", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                Spacer(Modifier.weight(1f))
                Text("Sem backup • local", fontSize = 9.sp, color = accent.copy(alpha = .62f))
            }
        }
    }
}

@Composable
private fun SettingsHubTile(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    accent: Color,
    containerColor: Color = accent.copy(alpha = .10f),
    modifier: Modifier = Modifier,
    wide: Boolean = false,
    badge: String? = null,
    avatarUrl: String? = null,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        color = containerColor,
        border = BorderStroke(1.dp, accent.copy(alpha = .38f))
    ) {
        if (wide) {
            Row(
                Modifier.padding(horizontal = 13.dp, vertical = 11.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(shape = RoundedCornerShape(14.dp), color = accent.copy(alpha = .16f)) {
                    Icon(icon, null, tint = accent, modifier = Modifier.padding(9.dp).size(22.dp))
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(title, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                        badge?.let {
                            Spacer(Modifier.width(6.dp))
                            Surface(shape = RoundedCornerShape(999.dp), color = accent.copy(alpha = .16f)) {
                                Text(it, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp), fontSize = 9.sp, fontWeight = FontWeight.Black, color = accent)
                            }
                        }
                    }
                    Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .60f), maxLines = 1)
                }
                Icon(Icons.Default.ChevronRight, null, tint = accent.copy(alpha=.75f))
            }
        } else {
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 11.dp),
                verticalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (!avatarUrl.isNullOrBlank()) {
                        AuthProfileAvatar(avatarUrl, 37.dp, 27.dp)
                    } else {
                        Surface(shape = RoundedCornerShape(13.dp), color = accent.copy(alpha = .16f)) {
                            Icon(icon, null, tint = accent, modifier = Modifier.padding(8.dp).size(21.dp))
                        }
                    }
                    Spacer(Modifier.weight(1f))
                    badge?.let {
                        Surface(shape = RoundedCornerShape(999.dp), color = accent.copy(alpha = .16f)) {
                            Text(it, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp), fontSize = 9.sp, fontWeight = FontWeight.Black, color = accent)
                        }
                    }
                }
                Text(title, fontWeight = FontWeight.ExtraBold, maxLines = 1, fontSize = 14.sp)
                Text(subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .56f), maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun SettingsSectionTitle(title: String) {
    Text(
        title,
        modifier = Modifier.padding(top = 3.dp, start = 2.dp),
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary
    )
}

@Composable
private fun CompactSettingsCard(content: @Composable ColumnScope.() -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(21.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .62f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = .10f))
    ) {
        Column(content = content)
    }
}

@Composable
private fun SettingsIcon(icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary.copy(alpha = .13f)) {
        Box(Modifier.size(36.dp), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
        }
    }
}

@Composable
private fun SettingsNavRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    enabled: Boolean = true,
    onClick: (() -> Unit)?
) {
    val contentAlpha = if (enabled) 1f else .42f
    val modifier = if (onClick != null && enabled) Modifier.clickable(onClick = onClick) else Modifier
    Row(
        modifier = modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        SettingsIcon(icon)
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface.copy(alpha = contentAlpha))
            Text(subtitle, style = MaterialTheme.typography.bodySmall, maxLines = 2, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .56f * contentAlpha))
        }
        if (onClick != null) {
            Icon(Icons.Default.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurface.copy(alpha = .34f * contentAlpha))
        }
    }
}

@Composable
private fun SettingsToggleRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    enabled: Boolean = true,
    badge: String? = null,
    onCheckedChange: (Boolean) -> Unit
) {
    val alpha = if (enabled) 1f else .46f
    Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
        SettingsIcon(icon)
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface.copy(alpha = alpha))
                badge?.let {
                    Spacer(Modifier.width(6.dp))
                    Surface(shape = RoundedCornerShape(999.dp), color = MaterialTheme.colorScheme.primary.copy(alpha=.12f)) {
                        Text(it, modifier = Modifier.padding(horizontal=6.dp, vertical=2.dp), fontSize=9.sp, fontWeight=FontWeight.Black, color=MaterialTheme.colorScheme.primary)
                    }
                }
            }
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .56f * alpha), maxLines = 2)
        }
        Switch(checked = checked, enabled = enabled, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun SettingsDivider() {
    HorizontalDivider(modifier = Modifier.padding(start = 60.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = .13f))
}

private fun textAppearanceLabel(value: TextAppearance): String = when (value) {
    TextAppearance.DYNAMIC -> "Dinâmico"
    TextAppearance.BLACK -> "Preto"
    TextAppearance.WHITE -> "Branco"
    TextAppearance.WHITE_BLACK_OUTLINE -> "Branco com bordas pretas"
    TextAppearance.BLACK_WHITE_OUTLINE -> "Preto com bordas brancas"
    TextAppearance.RAINBOW -> "Arco-íris"
    TextAppearance.DEEP_GRAY -> "Cinza intenso"
    TextAppearance.BOLD -> "Negrito"
    TextAppearance.WHITE_SHADOW -> "Branco sombreado"
    TextAppearance.NAVY -> "Azul-marinho"
}

private fun textAppearanceExample(value: TextAppearance): String = when (value) {
    TextAppearance.DYNAMIC -> "Adapta-se ao contraste do tema"
    TextAppearance.BOLD -> "Mantém a cor do tema e reforça o peso"
    TextAppearance.RAINBOW -> "Cores animadas e misturadas"
    else -> "SONUS 123 • Prévia aplicada em tempo real"
}

private fun effectivePromotionalTier(prefs: UserPreferences, now: Long = System.currentTimeMillis()): MembershipTier {
    val active = (prefs.premiumExpiresAtEpochMillis ?: 0L) > now
    if (!active) return MembershipTier.FREE
    return when (prefs.promotionalTierName?.uppercase(Locale.US)) {
        "BRONZE", "PLUS", "PRATA" -> MembershipTier.PRATA
        "STUDIO", "OURO", "MAX" -> MembershipTier.OURO
        "DIAMANTE", "DIAMOND" -> MembershipTier.DIAMANTE
        else -> MembershipTier.FREE
    }
}

private fun themeLabel(mode: ThemeMode): String = when (mode) {
    ThemeMode.SYSTEM -> "Sistema"
    ThemeMode.DYNAMIC -> "Dinâmico"
    ThemeMode.LIGHT -> "Claro"
    ThemeMode.DARK -> "Escuro"
    ThemeMode.BLUE -> "Azul suave"
    ThemeMode.GREEN -> "Verde suave"
    ThemeMode.RED -> "Vermelho suave"
    ThemeMode.CHECKERED -> "Xadrez"
    ThemeMode.SOFT_YELLOW -> "Amarelo suave"
    ThemeMode.SOFT_BROWN -> "Marrom suave"
    ThemeMode.SOFT_ORANGE -> "Laranja suave"
    ThemeMode.SILVER -> "Prata"
    ThemeMode.SLATE -> "Slate"
    ThemeMode.OCEAN -> "Ocean"
    ThemeMode.FOREST -> "Forest"
    ThemeMode.RAINBOW -> "Arco-íris"
    ThemeMode.MONOCHROME -> "Monocromático"
    ThemeMode.PINK -> "Rosa"
    ThemeMode.LILAC -> "Lilás"
    ThemeMode.DEEP_BLACK -> "Preto profundo"
    ThemeMode.VIOLET_PULSE -> "Violet Pulse"
    ThemeMode.SUNSET -> "Sunset"
    ThemeMode.MIDNIGHT_CYAN -> "Midnight Cyan"
    ThemeMode.AURORA -> "Aurora azul/lilás/rosa"
    ThemeMode.NEON_STUDIO -> "Neon Studio"
    ThemeMode.CRIMSON_PRO -> "Crimson Pro"
    ThemeMode.AURORA_PRO -> "Aurora Pro"
    ThemeMode.PHOTO -> "Foto no fundo"
    ThemeMode.PROFESSIONAL -> "Profissional"
    ThemeMode.GOLD -> "Dourado"
    ThemeMode.SKY -> "Céu"
    ThemeMode.SPACE -> "Space"
    ThemeMode.CYBER_PULSE -> "Cyber Pulse"
    ThemeMode.ROYAL_GOLD -> "Royal Gold"
    ThemeMode.GLASS_HORIZON -> "Glass Horizon"
    ThemeMode.NEBULA -> "Nebula"
    ThemeMode.INFINITY -> "Infinity"
    ThemeMode.LIQUID_GLASS -> "Liquid Glass"
    ThemeMode.THREE_D -> "3D"
    ThemeMode.CAMALEON -> "Camaleon"
    ThemeMode.PARALLAX -> "Paralaxe"
}

private fun themeDescription(mode: ThemeMode): String = when (mode) {
    ThemeMode.SYSTEM -> "Segue o sistema"
    ThemeMode.DYNAMIC -> "Cores em movimento suave"
    ThemeMode.LIGHT -> "Claro e limpo"
    ThemeMode.DARK -> "Escuro clássico"
    ThemeMode.BLUE -> "Azul discreto"
    ThemeMode.GREEN -> "Verde suave"
    ThemeMode.RED -> "Vermelho elegante"
    ThemeMode.CHECKERED -> "Padrão xadrez discreto"
    ThemeMode.SOFT_YELLOW -> "Quente, claro e confortável"
    ThemeMode.SOFT_BROWN -> "Tons terrosos suaves"
    ThemeMode.SOFT_ORANGE -> "Laranja leve e acolhedor"
    ThemeMode.SILVER -> "Cinza metálico elegante"
    ThemeMode.SLATE -> "Grafite azulado minimalista"
    ThemeMode.OCEAN -> "Azul oceânico profundo e calmo"
    ThemeMode.FOREST -> "Verde esmeralda sóbrio"
    ThemeMode.RAINBOW -> "Fundo e acentos multicoloridos"
    ThemeMode.MONOCHROME -> "Remove o excesso de cores"
    ThemeMode.PINK -> "Visual feminino e sofisticado"
    ThemeMode.LILAC -> "Suave, moderno e delicado"
    ThemeMode.DEEP_BLACK -> "Fundo preto com botões coloridos"
    ThemeMode.VIOLET_PULSE -> "Violeta neon com profundidade"
    ThemeMode.SUNSET -> "Roxo e laranja queimado"
    ThemeMode.MIDNIGHT_CYAN -> "Preto azulado com ciano luminoso"
    ThemeMode.AURORA -> "Degradê azul, lilás e rosa"
    ThemeMode.NEON_STUDIO -> "Estúdio escuro com ciano e violeta"
    ThemeMode.CRIMSON_PRO -> "Grafite e vinho profissional"
    ThemeMode.AURORA_PRO -> "Aurora refinada com brilho localizado"
    ThemeMode.PHOTO -> "Imagem escolhida em Foto no fundo"
    ThemeMode.PROFESSIONAL -> "Preto, limpo e ícones azuis"
    ThemeMode.GOLD -> "Ouro sofisticado e profundo"
    ThemeMode.SKY -> "Céu azul com nuvens"
    ThemeMode.SPACE -> "Espaço profundo com planetas"
    ThemeMode.CYBER_PULSE -> "Azul elétrico e magenta"
    ThemeMode.ROYAL_GOLD -> "Preto e dourado elegante"
    ThemeMode.GLASS_HORIZON -> "Vidro, profundidade e reflexos suaves"
    ThemeMode.NEBULA -> "Nebulosa violeta cinematográfica"
    ThemeMode.INFINITY -> "Tema Ouro dinâmico de assinatura"
    ThemeMode.LIQUID_GLASS -> "Vidro translúcido, camadas e profundidade"
    ThemeMode.THREE_D -> "Relevo, volume e profundidade visual"
    ThemeMode.CAMALEON -> "Cores do ambiente captadas pela câmera"
    ThemeMode.PARALLAX -> "Camadas que respondem ao movimento do aparelho"
}

private fun themeRequiredTier(mode: ThemeMode): MembershipTier? = when (mode) {
    ThemeMode.RAINBOW, ThemeMode.MONOCHROME, ThemeMode.PINK, ThemeMode.LILAC, ThemeMode.DEEP_BLACK,
    ThemeMode.VIOLET_PULSE, ThemeMode.SUNSET, ThemeMode.MIDNIGHT_CYAN -> MembershipTier.FREE
    ThemeMode.AURORA, ThemeMode.NEON_STUDIO, ThemeMode.CRIMSON_PRO, ThemeMode.AURORA_PRO -> MembershipTier.PRATA
    ThemeMode.PHOTO, ThemeMode.PROFESSIONAL, ThemeMode.GOLD, ThemeMode.SKY, ThemeMode.SPACE,
    ThemeMode.CYBER_PULSE, ThemeMode.ROYAL_GOLD, ThemeMode.GLASS_HORIZON, ThemeMode.NEBULA, ThemeMode.INFINITY -> MembershipTier.OURO
    ThemeMode.LIQUID_GLASS, ThemeMode.THREE_D, ThemeMode.CAMALEON, ThemeMode.PARALLAX -> MembershipTier.DIAMANTE
    else -> null
}

private fun themePreviewColors(mode: ThemeMode): List<Color> = when (mode) {
    ThemeMode.SYSTEM -> listOf(Color.Gray, Color.DarkGray)
    ThemeMode.DYNAMIC -> listOf(PulseBlue, PulsePurple, PulseCyan)
    ThemeMode.LIGHT -> listOf(Color(0xFFF4F7FF), Color.White)
    ThemeMode.DARK -> listOf(Color(0xFF101722), Color(0xFF061327))
    ThemeMode.BLUE -> listOf(Color(0xFF4E8FE8), Color(0xFF0C2346))
    ThemeMode.GREEN -> listOf(Color(0xFF5DBA86), Color(0xFF103429))
    ThemeMode.RED -> listOf(Color(0xFFE27878), Color(0xFF472028))
    ThemeMode.CHECKERED -> listOf(Color(0xFF101318), Color(0xFF38404A), Color(0xFF15191F))
    ThemeMode.SOFT_YELLOW -> listOf(Color(0xFFFFE98E), Color(0xFFC9A63D), Color(0xFFFFF8D8))
    ThemeMode.SOFT_BROWN -> listOf(Color(0xFF7C553C), Color(0xFF3E291E), Color(0xFF1A120E))
    ThemeMode.SOFT_ORANGE -> listOf(Color(0xFFFFB36B), Color(0xFF9A4F20), Color(0xFF2B170C))
    ThemeMode.SILVER -> listOf(Color(0xFFE3E8EE), Color(0xFF79838D), Color(0xFF171B21))
    ThemeMode.SLATE -> listOf(Color(0xFF9EB5CC), Color(0xFF263542), Color(0xFF0A1017))
    ThemeMode.OCEAN -> listOf(Color(0xFF44D7E8), Color(0xFF0B4B58), Color(0xFF02141B))
    ThemeMode.FOREST -> listOf(Color(0xFF63E0A5), Color(0xFF14533A), Color(0xFF03120C))
    ThemeMode.RAINBOW -> listOf(Color(0xFF58C7FF), Color(0xFFFF5F9E), Color(0xFFFFD066), Color(0xFF79E0B5))
    ThemeMode.MONOCHROME -> listOf(Color(0xFFF0F0F0), Color(0xFF777777), Color(0xFF111111))
    ThemeMode.PINK -> listOf(Color(0xFFFF8BC7), Color(0xFF8C315F), Color(0xFF2C1025))
    ThemeMode.LILAC -> listOf(Color(0xFFC6A7FF), Color(0xFF6D4EA1), Color(0xFF211531))
    ThemeMode.DEEP_BLACK -> listOf(Color(0xFF050505), Color(0xFF20A4F3), Color(0xFFFF4D8D))
    ThemeMode.VIOLET_PULSE -> listOf(Color(0xFFD281FF), Color(0xFF7445D8), Color(0xFF10081A))
    ThemeMode.SUNSET -> listOf(Color(0xFFFF9A5A), Color(0xFFB64F91), Color(0xFF160A1D))
    ThemeMode.MIDNIGHT_CYAN -> listOf(Color(0xFF42E8FF), Color(0xFF2876A6), Color(0xFF020A10))
    ThemeMode.AURORA -> listOf(Color(0xFF5EA8FF), Color(0xFFB778FF), Color(0xFFFF78B8))
    ThemeMode.NEON_STUDIO -> listOf(Color(0xFF22DFFF), Color(0xFF9850FF), Color(0xFF02040A))
    ThemeMode.CRIMSON_PRO -> listOf(Color(0xFFFF607A), Color(0xFF9B2948), Color(0xFF0B0508))
    ThemeMode.AURORA_PRO -> listOf(Color(0xFF56FFD4), Color(0xFFB46CFF), Color(0xFF031016))
    ThemeMode.PHOTO -> listOf(Color(0xFF355A85), Color(0xFF20152D))
    ThemeMode.PROFESSIONAL -> listOf(Color.Black, Color(0xFF1769B0), Color(0xFF0A0A0A))
    ThemeMode.GOLD -> listOf(Color(0xFFFFDF78), Color(0xFF9A741C), Color(0xFF1B1202))
    ThemeMode.SKY -> listOf(Color(0xFF5CB5F0), Color(0xFFBDE9FF), Color.White)
    ThemeMode.SPACE -> listOf(Color(0xFF9F7DFF), Color(0xFF1E2B68), Color(0xFF03040A))
    ThemeMode.CYBER_PULSE -> listOf(Color(0xFF00E4FF), Color(0xFFFF43D4), Color(0xFF01040A))
    ThemeMode.ROYAL_GOLD -> listOf(Color(0xFFFFD76A), Color(0xFFB78B2E), Color(0xFF090602))
    ThemeMode.GLASS_HORIZON -> listOf(Color(0xFFB5E7FF), Color(0xFF9C83FF), Color(0xFF07101B))
    ThemeMode.NEBULA -> listOf(Color(0xFFD774FF), Color(0xFF5B75FF), Color(0xFF04030B))
    ThemeMode.INFINITY -> listOf(Color(0xFF20E2FF), Color(0xFF8D55FF), Color(0xFF010207))
    ThemeMode.LIQUID_GLASS -> listOf(Color(0xFFBFEAFF), Color(0xFF9C83FF), Color(0xFF132B3D))
    ThemeMode.THREE_D -> listOf(Color(0xFF63C7FF), Color(0xFF725BFF), Color(0xFF070B16))
    ThemeMode.CAMALEON -> listOf(Color(0xFF65E6A8), Color(0xFF58A8FF), Color(0xFF8D6BFF))
    ThemeMode.PARALLAX -> listOf(Color(0xFF69D9FF), Color(0xFF9B79FF), Color(0xFF050A18))
}

private fun fontLabel(font: AppFont): String = when (font) {
    AppFont.MODERN -> "Moderna"
    AppFont.ROUNDED -> "Arredondada"
    AppFont.CLASSIC -> "Clássica"
    AppFont.COMPACT -> "Compacta"
    AppFont.DIGITAL -> "Digital"
    AppFont.NEO -> "Neo"
    AppFont.SOFT -> "Soft"
    AppFont.URBAN -> "Urban"
    AppFont.ELEGANT -> "Elegant"
    AppFont.WIDE -> "Wide"
    AppFont.EDITORIAL -> "Editorial"
    AppFont.SIGNATURE -> "Signature"
    AppFont.PULSE -> "Pulse"
    AppFont.MINIMAL -> "Minimal"
    AppFont.TECH -> "Tech"
    AppFont.QUANTUM -> "Quantum"
    AppFont.VISION -> "Vision"
    AppFont.PRIME -> "Prime"
    AppFont.CODEX -> "Codex"
    AppFont.CINEMA -> "Cinema"
    AppFont.ARCHITECT -> "Architect"
    AppFont.NOVA -> "Nova"
    AppFont.MONUMENT -> "Monument"
    AppFont.VELVET -> "Velvet"
    AppFont.TITAN -> "Titan"
}

private fun fontRequiredTier(font: AppFont): MembershipTier? = when (font) {
    AppFont.NEO, AppFont.SOFT, AppFont.URBAN, AppFont.ELEGANT, AppFont.WIDE -> MembershipTier.FREE
    AppFont.EDITORIAL, AppFont.SIGNATURE, AppFont.PULSE, AppFont.MINIMAL, AppFont.TECH -> MembershipTier.OURO
    AppFont.QUANTUM, AppFont.VISION, AppFont.PRIME, AppFont.CODEX, AppFont.CINEMA, AppFont.ARCHITECT, AppFont.NOVA, AppFont.MONUMENT, AppFont.VELVET, AppFont.TITAN -> MembershipTier.OURO
    else -> null
}

private fun fontPreviewFamily(font: AppFont): FontFamily = when (font) {
    AppFont.MODERN, AppFont.NEO, AppFont.URBAN, AppFont.WIDE, AppFont.PULSE, AppFont.VISION, AppFont.ARCHITECT, AppFont.MONUMENT -> FontFamily.SansSerif
    AppFont.ROUNDED, AppFont.SOFT, AppFont.SIGNATURE, AppFont.NOVA -> FontFamily.Cursive
    AppFont.CLASSIC, AppFont.ELEGANT, AppFont.EDITORIAL, AppFont.PRIME, AppFont.CINEMA, AppFont.VELVET -> FontFamily.Serif
    AppFont.DIGITAL, AppFont.TECH, AppFont.QUANTUM, AppFont.CODEX -> FontFamily.Monospace
    AppFont.COMPACT, AppFont.MINIMAL, AppFont.TITAN -> FontFamily.Default
}

@Composable
private fun SettingsCard(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, content: @Composable ColumnScope.() -> Unit) {
    Card {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null)
                Spacer(Modifier.width(8.dp))
                Text(title, fontWeight = FontWeight.Bold)
            }
            content()
        }
    }
}

@Composable
private fun SwitchSetting(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}


@Composable
private fun PageHeader(title: String, onBack: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Voltar") }
        Text(title, fontSize = 27.sp, fontWeight = FontWeight.Bold)
    }
}

private fun artistLimitForTier(tier: MembershipTier): Int? = when (commercialTier(tier)) {
    MembershipTier.FREE -> 1
    MembershipTier.PRATA -> 3
    MembershipTier.OURO -> 8
    MembershipTier.DIAMANTE -> null
    else -> 3
}

private fun membershipLabel(tier: MembershipTier): String = when (commercialTier(tier)) {
    MembershipTier.FREE -> "FREE"
    MembershipTier.PRATA -> "PRATA"
    MembershipTier.OURO -> "OURO"
    MembershipTier.DIAMANTE -> "DIAMANTE"
    else -> "PRATA"
}

private fun membershipGradient(tier: MembershipTier): List<Color> = when (commercialTier(tier)) {
    MembershipTier.FREE -> listOf(Color(0xFF50709A), Color(0xFF27384F))
    MembershipTier.PRATA -> listOf(Color(0xFFD8E0E8), Color(0xFF8795A5), Color(0xFF42505F))
    MembershipTier.OURO -> listOf(Color(0xFFFFD76A), Color(0xFFD69A24), Color(0xFF714B0B))
    MembershipTier.DIAMANTE -> listOf(Color(0xFF8AF5FF), Color(0xFF7C7BFF), Color(0xFFD36BFF), Color(0xFFECF8FF))
    else -> listOf(Color(0xFFD8E0E8), Color(0xFF8795A5))
}

@Composable
private fun PlanInnerIcon(tier: MembershipTier, modifier: Modifier = Modifier) {
    when (tier) {
        MembershipTier.FREE -> Canvas(modifier) {
            val w = size.width
            val h = size.height
            val shield = Path().apply {
                moveTo(w * .50f, h * .05f)
                lineTo(w * .88f, h * .18f)
                lineTo(w * .82f, h * .68f)
                lineTo(w * .50f, h * .94f)
                lineTo(w * .18f, h * .68f)
                lineTo(w * .12f, h * .18f)
                close()
            }
            drawPath(shield, Color.White)
            drawCircle(Color(0xFF476990), radius = w * .12f, center = Offset(w * .50f, h * .42f))
        }
        MembershipTier.BRONZE -> Icon(Icons.Default.AutoAwesome, null, tint = Color.White, modifier = modifier)
        MembershipTier.PRATA -> Icon(Icons.Default.Star, null, tint = Color.White, modifier = modifier)
        MembershipTier.OURO -> Canvas(modifier) {
            val w = size.width
            val h = size.height
            val crown = Path().apply {
                moveTo(w * .08f, h * .72f)
                lineTo(w * .18f, h * .30f)
                lineTo(w * .39f, h * .51f)
                lineTo(w * .50f, h * .16f)
                lineTo(w * .61f, h * .51f)
                lineTo(w * .82f, h * .30f)
                lineTo(w * .92f, h * .72f)
                close()
            }
            drawPath(crown, Color.White)
            drawRoundRect(
                color = Color.White,
                topLeft = Offset(w * .12f, h * .75f),
                size = androidx.compose.ui.geometry.Size(w * .76f, h * .12f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(h * .05f, h * .05f)
            )
        }
        MembershipTier.DIAMANTE -> Icon(Icons.Default.Diamond, null, tint = Color.White, modifier = modifier)
    }
}

@Composable
private fun PlanGlyph(tier: MembershipTier, size: androidx.compose.ui.unit.Dp = 24.dp) {
    val shape = when (tier) {
        MembershipTier.FREE -> RoundedCornerShape(8.dp)
        MembershipTier.BRONZE -> CircleShape
        MembershipTier.PRATA -> RoundedCornerShape(9.dp)
        MembershipTier.OURO -> RoundedCornerShape(10.dp)
        MembershipTier.DIAMANTE -> RoundedCornerShape(11.dp)
    }
    Box(
        modifier = Modifier
            .size(size)
            .clip(shape)
            .background(Brush.linearGradient(membershipGradient(tier)))
            .border(1.dp, Color.White.copy(alpha = .34f), shape),
        contentAlignment = Alignment.Center
    ) {
        PlanInnerIcon(tier, Modifier.size(size * .55f))
    }
}

@Composable
private fun OwnerStatusPill() {
    val shape = RoundedCornerShape(50)
    Row(
        modifier = Modifier
            .clip(shape)
            .background(Brush.linearGradient(listOf(Color(0xFF2D7CC7), Color(0xFF173B68))))
            .border(1.dp, Color.White.copy(alpha = .24f), shape)
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Icon(Icons.Default.AdminPanelSettings, null, tint = Color.White, modifier = Modifier.size(13.dp))
        Text("OWNER", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold)
    }
}


@Composable
private fun PlanStatusPill(tier: MembershipTier) {
    val shape = RoundedCornerShape(50)
    Row(
        modifier = Modifier
            .clip(shape)
            .background(Brush.linearGradient(membershipGradient(tier)))
            .border(1.dp, Color.White.copy(alpha = .22f), shape)
            .padding(horizontal = 7.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        PlanInnerIcon(tier, Modifier.size(12.dp))
        Text(membershipLabel(tier), color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold)
    }
}


@Composable
private fun PremiumFeatureMark(tier: MembershipTier) {
    // Selo reutilizável para funções premium; tiers legados são exibidos como Ouro.
    PlanGlyph(tier = tier, size = 20.dp)
}

@Composable
private fun ArtistAvatar(
    photoPath: String?,
    size: androidx.compose.ui.unit.Dp,
    fallbackToLogo: Boolean = false,
    avatarId: String? = null
) {
    val bitmap = remember(photoPath) {
        photoPath?.takeIf { File(it).exists() }?.let { path ->
            runCatching { BitmapFactory.decodeFile(path)?.asImageBitmap() }.getOrNull()
        }
    }
    when {
        bitmap != null -> Image(
            bitmap = bitmap,
            contentDescription = "Foto do artista",
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(size).clip(CircleShape).border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .45f), CircleShape)
        )
        !avatarId.isNullOrBlank() && SonusAvatarCatalog.byId(avatarId) != null -> SonusAvatarArtwork(
            avatarId = avatarId,
            modifier = Modifier.size(size).clip(CircleShape)
        )
        fallbackToLogo -> Image(
            painter = painterResource(R.drawable.sonus_logo_official),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(size).clip(RoundedCornerShape(16.dp))
        )
        else -> Surface(
            modifier = Modifier.size(size),
            shape = CircleShape,
            color = MaterialTheme.colorScheme.primaryContainer
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Person, null, modifier = Modifier.size(size * .58f))
            }
        }
    }
}

private fun saveBackgroundPhoto(context: android.content.Context, uri: Uri, oldPath: String?): String? {
    return runCatching {
        val folder = File(context.filesDir, "backgrounds").apply { mkdirs() }
        val target = File(folder, "premium_background_${System.currentTimeMillis()}.img")
        context.contentResolver.openInputStream(uri)?.use { input ->
            target.outputStream().use { output -> input.copyTo(output) }
        } ?: return null
        oldPath?.let { path -> runCatching { File(path).takeIf { it.exists() }?.delete() } }
        target.absolutePath
    }.getOrNull()
}

private fun saveArtistPhoto(context: android.content.Context, uri: Uri, artistId: String, oldPath: String?): String? {
    return runCatching {
        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        val maxSide = 768
        var sample = 1
        while (bounds.outWidth / sample > maxSide * 2 || bounds.outHeight / sample > maxSide * 2) sample *= 2
        val decoded = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample }) ?: return null
        val ratio = minOf(1f, maxSide.toFloat() / maxOf(decoded.width, decoded.height).coerceAtLeast(1))
        val finalBitmap = if (ratio < 1f) {
            android.graphics.Bitmap.createScaledBitmap(decoded, (decoded.width * ratio).toInt().coerceAtLeast(1), (decoded.height * ratio).toInt().coerceAtLeast(1), true)
        } else decoded
        val folder = File(context.filesDir, "artist_photos").apply { mkdirs() }
        val target = File(folder, "${artistId}_${System.currentTimeMillis()}.jpg")
        target.outputStream().use { output ->
            check(finalBitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, output)) { "Falha ao compactar imagem" }
        }
        if (finalBitmap !== decoded) finalBitmap.recycle()
        decoded.recycle()
        oldPath?.let(::deleteArtistPhoto)
        target.absolutePath
    }.getOrNull()
}

private fun deleteArtistPhoto(path: String?) {
    if (path.isNullOrBlank()) return
    runCatching { File(path).takeIf { it.exists() }?.delete() }
}

@Composable
private fun GradientHero(title: String, value: String, subtitle: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(26.dp))
            .background(Brush.linearGradient(listOf(PulseBlue, PulseCyan, PulsePurple)))
            .padding(22.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(title, color = Color.White.copy(alpha = .84f), fontWeight = FontWeight.SemiBold)
            Text(value, color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.ExtraBold)
            Text(subtitle, color = Color.White.copy(alpha = .9f))
        }
    }
}


private fun healthColor(score: Int): Color = when {
    score <= 0 -> SignalBlack
    score <= 20 -> SignalRed
    score <= 40 -> SignalPurple
    score <= 60 -> SignalOrange
    score <= 85 -> SignalGreen
    else -> SignalBlue
}

/**
 * Série diária de Histórico/Análises construída pelo mesmo motor usado em Saldo e Pulso.
 * Registros diários permanecem exatos; no modo acumulado, o primeiro total vira um ritmo
 * médio desde o início do ciclo, evitando tratar todo o acumulado como se tivesse ocorrido
 * em um único dia.
 */


private fun money(value: Double): String = NumberFormat.getCurrencyInstance(Locale("pt", "BR")).format(value)


private fun formatDate(iso: String): String = runCatching {
    LocalDate.parse(iso).format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))
}.getOrDefault(iso)


private fun parseDateInput(input: String): LocalDate? {
    val value = input.trim()
    if (value.isBlank()) return null
    return runCatching { LocalDate.parse(value) }.getOrNull()
        ?: runCatching { LocalDate.parse(value, DateTimeFormatter.ofPattern("dd/MM/yyyy")) }.getOrNull()
}


@Composable
private fun rememberNetworkAvailable(): Boolean {
    val context = LocalContext.current
    val manager = remember(context) {
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    }
    fun current(): Boolean {
        val network = manager.activeNetwork ?: return false
        val caps = manager.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }
    var available by remember { mutableStateOf(current()) }
    DisposableEffect(manager) {
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                available = current()
            }
            override fun onLost(network: Network) {
                available = current()
            }
            override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
                available = networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                    networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
            }
        }
        runCatching { manager.registerDefaultNetworkCallback(callback) }
        onDispose { runCatching { manager.unregisterNetworkCallback(callback) } }
    }
    return available
}


private tailrec fun Context.findComponentActivityForApp(): ComponentActivity? = when (this) {
    is ComponentActivity -> this
    is ContextWrapper -> baseContext.findComponentActivityForApp()
    else -> null
}

private fun formatNumber(value: Long): String = NumberFormat.getIntegerInstance(Locale("pt", "BR")).format(value)
