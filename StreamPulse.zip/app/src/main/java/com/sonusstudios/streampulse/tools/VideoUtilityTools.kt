package com.sonusstudios.streampulse.tools

import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.sonusstudios.streampulse.core.MembershipTier
import com.sonusstudios.streampulse.core.commercialTier
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

@Composable
internal fun VideoConverterTool(
    onBack: () -> Unit,
    onTrack: (String, Boolean?, Long?) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var inputs by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var infos by remember { mutableStateOf<List<VideoConvertInputInfo>>(emptyList()) }
    var outputFormat by remember { mutableStateOf("MP4") }
    var targetFps by remember { mutableIntStateOf(30) }
    var targetResolution by remember { mutableStateOf("1080p") }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(0) }
    var currentIndex by remember { mutableIntStateOf(0) }
    var currentTotal by remember { mutableIntStateOf(0) }
    var message by remember { mutableStateOf<String?>(null) }
    var showSelected by remember { mutableStateOf(false) }
    var conversionJob by remember { mutableStateOf<kotlinx.coroutines.Job?>(null) }

    fun refreshInfo(list: List<Uri>) {
        val target = list.distinct()
        inputs = target
        infos = emptyList()
        message = null
        scope.launch {
            val loaded = withContext(Dispatchers.IO) {
                target.mapNotNull { uri -> CreatorAudioEngine.inspectVideoForConversion(context, uri).getOrNull() }
            }
            if (inputs == target) {
                infos = loaded
                if (target.isNotEmpty() && loaded.size != target.size) {
                    message = "Alguns vídeos não puderam ser analisados. Abra a lista e remova os arquivos indisponíveis."
                }
            }
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { selected ->
        if (selected.isNotEmpty()) {
            selected.forEach { uri ->
                runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            }
            refreshInfo((inputs + selected).distinct())
        }
    }

    val compatibility = remember(outputFormat, targetFps, targetResolution) {
        CreatorAudioEngine.videoConversionCompatibility(outputFormat, targetFps, targetResolution)
    }
    val totalInputBytes = remember(infos) { infos.sumOf { it.originalBytes.coerceAtLeast(0L) } }
    val estimatedBytes = remember(infos, outputFormat, targetFps, targetResolution) {
        CreatorAudioEngine.estimateVideoConversionBytes(infos, outputFormat, targetFps, targetResolution)
    }

    if (busy) {
        SonusExportProgressDialog(
            percent = progress,
            phase = if (currentTotal > 0) "Convertendo vídeo ${currentIndex.coerceAtLeast(1)} de $currentTotal…" else "Convertendo vídeos…",
            title = "Convertendo vídeos",
            onCancel = {
                CreatorAudioEngine.cancelActiveVideoUtility()
                conversionJob?.cancel()
                conversionJob = null
                busy = false
                message = "Conversão cancelada."
            }
        )
    }

    if (showSelected) {
        Dialog(onDismissRequest = { if (!busy) showSelected = false }) {
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
                modifier = Modifier.fillMaxWidth().heightIn(max = 560.dp)
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Vídeos selecionados", fontWeight = FontWeight.Black, fontSize = 19.sp, modifier = Modifier.weight(1f))
                        Text("${inputs.size}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    }
                    if (inputs.isEmpty()) {
                        Text("Nenhum vídeo selecionado.", style = MaterialTheme.typography.bodySmall)
                    } else {
                        LazyColumn(Modifier.weight(1f, fill = false), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            itemsIndexed(inputs, key = { _, uri -> uri.toString() }) { index, uri ->
                                val info = infos.firstOrNull { it.uri == uri }
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .55f)
                                ) {
                                    Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) {
                                            Text(info?.name ?: CreatorAudioEngine.displayName(context, uri), maxLines = 1, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                                            Text(info?.let { "${it.width}×${it.height} • ${it.fps} fps • ${formatBytes(it.originalBytes)}" } ?: "Analisando…", style = MaterialTheme.typography.labelSmall)
                                        }
                                        IconButton(onClick = {
                                            val next = inputs.toMutableList().also { it.removeAt(index) }
                                            refreshInfo(next)
                                        }, enabled = !busy) { Icon(Icons.Default.DeleteOutline, "Remover") }
                                    }
                                }
                            }
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { picker.launch(arrayOf("video/*")) }, enabled = !busy, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.Add, null); Spacer(Modifier.width(5.dp)); Text("Adicionar")
                        }
                        OutlinedButton(onClick = { refreshInfo(emptyList()) }, enabled = !busy && inputs.isNotEmpty(), modifier = Modifier.weight(1f)) {
                            Text("Limpar")
                        }
                        Button(onClick = { showSelected = false }, modifier = Modifier.weight(1f)) { Text("Fechar") }
                    }
                }
            }
        }
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val compact = maxHeight < 700.dp
        val pagePad = if (compact) 10.dp else 14.dp
        val gap = if (compact) 5.dp else 7.dp
        Column(
            Modifier.fillMaxSize().padding(horizontal = pagePad, vertical = 7.dp),
            verticalArrangement = Arrangement.spacedBy(gap)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.height(if (compact) 46.dp else 52.dp)) {
                IconButton(onClick = onBack, enabled = !busy) { Icon(Icons.Default.ArrowBack, "Voltar") }
                Column(Modifier.weight(1f)) {
                    Text("Conversor de Vídeo", fontWeight = FontWeight.Black, fontSize = if (compact) 21.sp else 24.sp)
                    Text("Formato • FPS • resolução • lote", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .60f))
                }
            }

            Row(Modifier.fillMaxWidth().height(if (compact) 106.dp else 118.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                Surface(
                    onClick = { if (inputs.isEmpty()) picker.launch(arrayOf("video/*")) else showSelected = true },
                    enabled = !busy,
                    modifier = Modifier.weight(1.25f).fillMaxHeight(),
                    shape = RoundedCornerShape(18.dp),
                    color = Color(0xFFFF6B2C)
                ) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.SpaceBetween) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.VideoLibrary, null, tint = Color.White)
                            Spacer(Modifier.width(7.dp))
                            Text("Adicionar vídeos", color = Color.White, fontWeight = FontWeight.Black, fontSize = 15.sp)
                        }
                        if (inputs.isEmpty()) {
                            Text("Toque para escolher 1 ou vários vídeos", color = Color.White.copy(alpha = .90f), fontSize = 11.sp)
                        } else {
                            Column {
                                Text("${inputs.size} ${if (inputs.size == 1) "vídeo selecionado" else "vídeos selecionados"}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text(formatBytes(totalInputBytes), color = Color.White.copy(alpha = .90f), fontSize = 11.sp)
                                Text((infos.firstOrNull()?.name ?: "Vídeo") + if (inputs.size > 1) " +${inputs.size - 1}" else "", color = Color.White.copy(alpha = .82f), maxLines = 1, fontSize = 10.sp)
                            }
                        }
                    }
                }
                Column(Modifier.weight(.92f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Surface(shape = RoundedCornerShape(16.dp), color = Color(0xFF3979E7), modifier = Modifier.weight(1f).fillMaxWidth()) {
                        Column(Modifier.padding(horizontal = 10.dp, vertical = 8.dp), verticalArrangement = Arrangement.Center) {
                            Text("Entrada", color = Color.White, fontWeight = FontWeight.Black, fontSize = 12.sp)
                            Text(if (inputs.isEmpty()) "Nenhum vídeo" else "${inputs.size} • ${formatBytes(totalInputBytes)}", color = Color.White.copy(alpha = .92f), fontSize = 10.5.sp, maxLines = 1)
                            infos.firstOrNull()?.let { Text("${it.width}×${it.height} • ${it.fps} fps", color = Color.White.copy(alpha = .76f), fontSize = 9.sp, maxLines = 1) }
                        }
                    }
                    Surface(shape = RoundedCornerShape(16.dp), color = Color(0xFF8D4AE6), modifier = Modifier.weight(1f).fillMaxWidth()) {
                        Column(Modifier.padding(horizontal = 10.dp, vertical = 8.dp), verticalArrangement = Arrangement.Center) {
                            Text("Saída estimada", color = Color.White, fontWeight = FontWeight.Black, fontSize = 12.sp)
                            Text(if (infos.isEmpty()) "—" else "~${formatBytes(estimatedBytes)}", color = Color.White.copy(alpha = .95f), fontSize = 10.5.sp)
                            Text("$outputFormat • $targetResolution • $targetFps fps", color = Color.White.copy(alpha = .76f), fontSize = 9.sp, maxLines = 1)
                        }
                    }
                }
            }

            Text("Formato", fontWeight = FontWeight.ExtraBold, fontSize = 12.sp)
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                CreatorAudioEngine.videoOutputFormats.chunked(3).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        row.forEach { format ->
                            ConverterChoiceButton(format, outputFormat == format, Modifier.weight(1f)) { outputFormat = format; message = null }
                        }
                    }
                }
            }

            Text("FPS de saída", fontWeight = FontWeight.ExtraBold, fontSize = 12.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                listOf(120, 60, 30, 24).forEach { fps ->
                    ConverterChoiceButton("$fps FPS", targetFps == fps, Modifier.weight(1f)) { targetFps = fps; message = null }
                }
            }

            Text("Resolução", fontWeight = FontWeight.ExtraBold, fontSize = 12.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                listOf("4K", "2K", "1080p", "720p", "480p", "360p").forEach { res ->
                    ConverterChoiceButton(res, targetResolution == res, Modifier.weight(1f), small = true) { targetResolution = res; message = null }
                }
            }

            val statusText = when {
                compatibility != null -> compatibility
                message != null -> message.orEmpty()
                inputs.isNotEmpty() && infos.size < inputs.size -> "Analisando arquivos…"
                inputs.isNotEmpty() -> "${infos.size} compatíveis • estimativa ${formatBytes(estimatedBytes)}"
                else -> "Selecione vídeos para começar."
            }
            Text(
                statusText,
                style = MaterialTheme.typography.labelSmall,
                color = if (compatibility != null || message?.contains("falha", true) == true) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface.copy(alpha = .62f),
                maxLines = 2,
                modifier = Modifier.heightIn(min = 24.dp)
            )

            Button(
                onClick = {
                    if (inputs.isEmpty()) return@Button
                    conversionJob = scope.launch {
                        busy = true; progress = 1; currentIndex = 1; currentTotal = inputs.size; message = null
                        val started = System.currentTimeMillis()
                        val result = CreatorAudioEngine.convertVideosToSonus(
                            context = context,
                            inputUris = inputs,
                            outputFormat = outputFormat,
                            targetFps = targetFps,
                            resolution = targetResolution
                        ) { p, index, total ->
                            scope.launch { progress = p; currentIndex = index; currentTotal = total }
                        }
                        busy = false
                        conversionJob = null
                        message = result.fold(
                            onSuccess = { r -> "✓ ${r.outputs.size} ${if (r.outputs.size == 1) "vídeo convertido" else "vídeos convertidos"} • ${formatBytes(r.inputBytes)} → ${formatBytes(r.outputBytes)}" },
                            onFailure = { "Falha: ${it.message ?: "não foi possível converter"}" }
                        )
                        onTrack("Conversor de Vídeo", result.isSuccess, System.currentTimeMillis() - started)
                    }
                },
                enabled = inputs.isNotEmpty() && infos.size == inputs.size && !busy && compatibility == null,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF43A967), contentColor = Color.White),
                modifier = Modifier.fillMaxWidth().height(if (compact) 46.dp else 52.dp),
                shape = RoundedCornerShape(18.dp)
            ) {
                Icon(Icons.Default.Sync, null)
                Spacer(Modifier.width(8.dp))
                Text(if (inputs.size > 1) "CONVERTER ${inputs.size} VÍDEOS" else "CONVERTER", fontWeight = FontWeight.Black)
            }
        }
    }
}

@Composable
private fun ConverterChoiceButton(
    text: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    small: Boolean = false,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        modifier = modifier.height(if (small) 30.dp else 34.dp),
        shape = RoundedCornerShape(10.dp),
        color = if (selected) MaterialTheme.colorScheme.primary.copy(alpha = .24f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .50f),
        border = BorderStroke(1.dp, if (selected) MaterialTheme.colorScheme.primary.copy(alpha = .70f) else MaterialTheme.colorScheme.outline.copy(alpha = .18f))
    ) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(text, fontSize = if (small) 9.sp else 10.5.sp, fontWeight = if (selected) FontWeight.Black else FontWeight.SemiBold, maxLines = 1)
        }
    }
}

@Composable
internal fun VideoMultiCutterTool(
    onBack: () -> Unit,
    membershipTier: MembershipTier,
    coins: Int,
    unlimited: Boolean,
    onSpend: suspend (Int) -> Boolean,
    onWatchAd: () -> Unit,
    onTrack: (String, Boolean?, Long?) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf<Uri?>(null) }
    var waveform by remember { mutableStateOf<VideoWaveformInfo?>(null) }
    var analyzing by remember { mutableStateOf(false) }
    var positionMs by remember { mutableLongStateOf(0L) }
    var pendingStart by remember { mutableStateOf<Long?>(null) }
    var segments by remember { mutableStateOf<List<VideoCutSegment>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(0) }
    var phase by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var editIndex by remember { mutableStateOf<Int?>(null) }
    var waveformZoom by remember(input) { mutableFloatStateOf(4f) }

    val player = remember { ExoPlayer.Builder(context).build() }
    DisposableEffect(Unit) { onDispose { player.release() } }
    LaunchedEffect(player, input) {
        while (true) {
            if (player.mediaItemCount > 0) positionMs = player.currentPosition.coerceAtLeast(0L)
            delay(80)
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            input = uri; waveform = null; segments = emptyList(); pendingStart = null; positionMs = 0L; message = null
            player.setMediaItem(MediaItem.fromUri(uri)); player.prepare(); player.pause()
            scope.launch {
                analyzing = true
                val result = withContext(Dispatchers.IO) { CreatorAudioEngine.analyzeVideoWaveform(context, uri) }
                waveform = result.getOrNull()
                message = result.exceptionOrNull()?.message
                analyzing = false
            }
        }
    }

    fun seekDelta(delta: Long) {
        val duration = (waveform?.durationMs ?: player.duration.takeIf { it > 0 } ?: 0L).coerceAtLeast(0L)
        val target = (positionMs + delta).coerceIn(0L, duration)
        player.seekTo(target); positionMs = target
    }
    fun seekAbsolute(target: Long) {
        val duration = waveform?.durationMs ?: return
        val clamped = target.coerceIn(0L, duration)
        player.seekTo(clamped); positionMs = clamped
    }

    if (busy) SonusExportProgressDialog(
        percent = progress,
        phase = phase.ifBlank { "Exportando trechos…" },
        title = "Exportando vídeos",
        onCancel = { CreatorAudioEngine.cancelActiveVideoUtility() }
    )

    CreatorToolScaffold(onBack, "Cortador Pro", "Marque vários trechos no mesmo vídeo e exporte cada seleção como um MP4 separado.") {
        item {
            CreatorCard("1. Vídeo e precisão", Icons.Default.ContentCut) {
                OutlinedButton(onClick = { picker.launch(arrayOf("video/*")) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(8.dp)); Text(if (input == null) "Selecionar vídeo" else "Trocar vídeo")
                }
                input?.let { Text(CreatorAudioEngine.displayName(context, it), style = MaterialTheme.typography.bodySmall) }
                if (input != null) {
                    AndroidView(
                        factory = { ctx -> PlayerView(ctx).apply { useController = false; this.player = player } },
                        update = { it.player = player },
                        modifier = Modifier.fillMaxWidth().height(150.dp).background(Color.Black, RoundedCornerShape(14.dp))
                    )
                    val duration = waveform?.durationMs ?: 1L
                    Slider(
                        value = (positionMs.toFloat() / duration.toFloat()).coerceIn(0f,1f),
                        onValueChange = { seekAbsolute((it * duration).toLong()) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        FilledTonalIconButton(onClick = { if (player.isPlaying) player.pause() else player.play() }) { Icon(if (player.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, null) }
                        listOf(-10_000L to "−10s", -1_000L to "−1s", 1_000L to "+1s", 10_000L to "+10s").forEach { (delta, label) ->
                            OutlinedButton(onClick = { seekDelta(delta) }, contentPadding = PaddingValues(horizontal=7.dp, vertical=0.dp), modifier = Modifier.weight(1f).height(38.dp)) { Text(label, fontSize=9.sp, maxLines=1) }
                        }
                    }
                    Text("${formatClock(positionMs)} / ${formatClock(duration)}", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                }
            }
        }
        if (input != null) item {
            CreatorCard("2. Waveform do vídeo", Icons.Default.GraphicEq) {
                if (analyzing) LinearProgressIndicator(Modifier.fillMaxWidth())
                val info = waveform
                if (info != null) {
                    VideoCutWaveform(info, positionMs, pendingStart, segments, waveformZoom) { seekAbsolute(it) }
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.ZoomIn, null, modifier = Modifier.size(18.dp))
                        Slider(
                            value = waveformZoom,
                            onValueChange = { waveformZoom = it },
                            valueRange = 2f..8f,
                            steps = 5,
                            modifier = Modifier.weight(1f)
                        )
                        Text("${waveformZoom.toInt()}x", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    }
                    Text("Arraste a waveform para navegar • a linha ciano marca o ponto exato", style = MaterialTheme.typography.labelSmall)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Button(
                            onClick = { pendingStart = positionMs; message = "Início marcado em ${formatClock(positionMs)}" },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB3261E))
                        ) { Icon(Icons.Default.RadioButtonChecked, null); Spacer(Modifier.width(5.dp)); Text("Início") }
                        Button(
                            onClick = {
                                val start = pendingStart
                                if (start == null) message = "Marque o início primeiro."
                                else if (positionMs <= start) message = "O fim precisa estar depois do início."
                                else {
                                    val candidate = VideoCutSegment(start, positionMs)
                                    val overlaps = segments.any { candidate.startMs < it.endMs && candidate.endMs > it.startMs }
                                    if (overlaps) message = "Esse trecho se sobrepõe a outro já marcado."
                                    else { segments = (segments + candidate).sortedBy { it.startMs }; pendingStart = null; message = "Trecho ${segments.size} criado." }
                                }
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF197A49))
                        ) { Icon(Icons.Default.RadioButtonChecked, null); Spacer(Modifier.width(5.dp)); Text("Fim") }
                    }
                    pendingStart?.let { Text("Início pendente: ${formatClock(it)} • posicione o playhead e toque em Fim.", color = Color(0xFFFF6B6B), style = MaterialTheme.typography.bodySmall) }
                }
            }
        }
        if (segments.isNotEmpty()) item {
            CreatorCard("3. Trechos marcados (${segments.size})", Icons.Default.VideoLibrary) {
                segments.forEachIndexed { index, seg ->
                    Surface(shape=RoundedCornerShape(12.dp), color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.55f)) {
                        Row(Modifier.fillMaxWidth().padding(9.dp), verticalAlignment=Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Trecho ${index+1}", fontWeight=FontWeight.Bold)
                                Text("${formatClock(seg.startMs)} → ${formatClock(seg.endMs)} • ${formatClock(seg.durationMs)}", style=MaterialTheme.typography.labelSmall)
                            }
                            IconButton(onClick={ seekAbsolute(seg.startMs); pendingStart = seg.startMs; segments = segments.toMutableList().also { it.removeAt(index) }; editIndex=index }) { Icon(Icons.Default.Edit, "Editar") }
                            IconButton(onClick={ segments = segments.toMutableList().also { it.removeAt(index) } }) { Icon(Icons.Default.DeleteOutline, "Remover", tint=MaterialTheme.colorScheme.error) }
                        }
                    }
                    Spacer(Modifier.height(5.dp))
                }
            }
        }
        item {
            Button(
                onClick = {
                    val uri = input ?: return@Button
                    scope.launch {
                        val paid = unlimited || commercialTier(membershipTier) != MembershipTier.FREE || onSpend(1)
                        if (!paid) { message = "Cortador Pro usa 1 Moeda SONUS no Grátis. Assista a um anúncio para ganhar uma moeda."; onWatchAd(); return@launch }
                        busy = true; progress = 1; phase = "Preparando trechos…"; message = null
                        val started = System.currentTimeMillis()
                        val result = withContext(Dispatchers.IO) {
                            CreatorAudioEngine.cutVideoSegmentsToSonus(context, uri, CreatorAudioEngine.displayName(context, uri), segments) { p ->
                                progress = p; phase = if (p < 96) "Exportando ${segments.size} trecho(s)…" else "Finalizando…"
                            }
                        }
                        busy = false
                        message = if (result.isSuccess) "✓ ${result.getOrThrow().size} vídeo(s) salvo(s) na pasta SONUS." else "Falha: ${result.exceptionOrNull()?.message ?: "não foi possível exportar"}"
                        onTrack("Cortador Pro: ${segments.size} trecho(s)", result.isSuccess, System.currentTimeMillis() - started)
                    }
                },
                enabled = input != null && segments.isNotEmpty() && !busy,
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Icon(Icons.Default.ContentCut, null); Spacer(Modifier.width(8.dp)); Text("Exportar ${segments.size} vídeo(s)") }
        }
        messageItem(message)
    }
}

@Composable
private fun VideoCutWaveform(
    info: VideoWaveformInfo,
    positionMs: Long,
    pendingStart: Long?,
    segments: List<VideoCutSegment>,
    zoom: Float,
    onSeek: (Long) -> Unit
) {
    val duration = info.durationMs.coerceAtLeast(1L)
    val waveColor = MaterialTheme.colorScheme.primary.copy(alpha=.76f)
    val surfaceColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.38f)
    val scrollState = rememberScrollState()
    val density = LocalDensity.current

    BoxWithConstraints(
        Modifier.fillMaxWidth().height(118.dp).background(surfaceColor, RoundedCornerShape(12.dp))
    ) {
        val viewportPx = with(density) { maxWidth.toPx() }.coerceAtLeast(1f)
        val safeZoom = zoom.coerceIn(2f, 8f)
        val waveWidthPx = viewportPx * safeZoom
        val sidePadPx = viewportPx / 2f
        val contentWidthPx = waveWidthPx + viewportPx
        val contentWidthDp = with(density) { contentWidthPx.toDp() }

        // A waveform é maior que a tela. O espaço lateral permite alinhar tanto 00:00
        // quanto o fim do vídeo exatamente sob o playhead central.
        Box(Modifier.fillMaxSize().horizontalScroll(scrollState)) {
            Canvas(Modifier.width(contentWidthDp).fillMaxHeight()) {
                val waveTop = 8.dp.toPx()
                val waveBottom = 82.dp.toPx()
                val center = (waveTop + waveBottom) / 2f
                val usableHalf = (waveBottom - waveTop) / 2f
                val barW = waveWidthPx / info.samples.size.coerceAtLeast(1)

                segments.forEach { seg ->
                    val x0 = sidePadPx + (seg.startMs.toFloat() / duration) * waveWidthPx
                    val x1 = sidePadPx + (seg.endMs.toFloat() / duration) * waveWidthPx
                    drawRect(Color(0xFF3BAA72).copy(alpha=.16f), Offset(x0, waveTop), Size((x1-x0).coerceAtLeast(1f), waveBottom-waveTop))
                    drawLine(Color(0xFFE74646), Offset(x0,waveTop), Offset(x0,waveBottom), 2.dp.toPx())
                    drawLine(Color(0xFF38C879), Offset(x1,waveTop), Offset(x1,waveBottom), 2.dp.toPx())
                }

                info.samples.forEachIndexed { i, sample ->
                    val x = sidePadPx + (i + .5f) * barW
                    val half = (sample * usableHalf * .88f).coerceAtLeast(1.5f)
                    drawLine(waveColor, Offset(x, center-half), Offset(x, center+half), barW.coerceAtMost(2.6.dp.toPx()), StrokeCap.Round)
                }

                pendingStart?.let {
                    val x = sidePadPx + (it.toFloat()/duration)*waveWidthPx
                    drawLine(Color(0xFFE74646), Offset(x,waveTop), Offset(x,waveBottom), 3.dp.toPx())
                }

                // Régua temporal. Em vídeos longos os passos aumentam para manter a leitura limpa.
                val tickMs = when {
                    duration <= 5 * 60_000L -> 15_000L
                    duration <= 30 * 60_000L -> 30_000L
                    duration <= 2 * 60 * 60_000L -> 60_000L
                    else -> 5 * 60_000L
                }
                val paint = android.graphics.Paint().apply {
                    color = android.graphics.Color.argb(215, 230, 238, 245)
                    textSize = 9.dp.toPx()
                    isAntiAlias = true
                }
                var tick = 0L
                while (tick <= duration) {
                    val x = sidePadPx + (tick.toFloat()/duration)*waveWidthPx
                    drawLine(Color.White.copy(alpha=.28f), Offset(x, 88.dp.toPx()), Offset(x, 95.dp.toPx()), 1.dp.toPx())
                    drawContext.canvas.nativeCanvas.drawText(formatClock(tick), x + 2.dp.toPx(), 108.dp.toPx(), paint)
                    tick += tickMs
                }
            }
        }

        // O playhead fica fixo no centro. Arrastar a waveform move o tempo por baixo dele.
        Canvas(Modifier.fillMaxSize()) {
            val x = size.width / 2f
            drawLine(Color(0xFF43D9FF), Offset(x, 4.dp.toPx()), Offset(x, 112.dp.toPx()), 3.dp.toPx(), StrokeCap.Round)
            drawCircle(Color(0xFF43D9FF), radius = 4.dp.toPx(), center = Offset(x, 8.dp.toPx()))
        }

        LaunchedEffect(scrollState.value, scrollState.maxValue, scrollState.isScrollInProgress) {
            if (scrollState.isScrollInProgress && scrollState.maxValue > 0) {
                val ratio = scrollState.value.toDouble() / scrollState.maxValue.toDouble()
                onSeek((duration * ratio).toLong().coerceIn(0L, duration))
            }
        }
        LaunchedEffect(positionMs, scrollState.maxValue, scrollState.isScrollInProgress) {
            if (!scrollState.isScrollInProgress && scrollState.maxValue > 0) {
                val target = ((positionMs.coerceIn(0L, duration).toDouble() / duration.toDouble()) * scrollState.maxValue).toInt()
                if (kotlin.math.abs(scrollState.value - target) > 2) scrollState.scrollTo(target)
            }
        }
    }
    Text(
        "${formatClock(positionMs)} / ${formatClock(duration)}",
        style = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.ExtraBold,
        modifier = Modifier.fillMaxWidth().padding(top = 5.dp)
    )
}

private fun formatClock(ms: Long): String {
    val total = (ms.coerceAtLeast(0L) / 1000L)
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) "%d:%02d:%02d".format(h,m,s) else "%02d:%02d".format(m,s)
}

private fun formatBytes(bytes: Long): String {
    if (bytes < 0L) return "—"
    val mb = bytes / (1024.0 * 1024.0)
    return if (mb >= 1.0) "%.1f MB".format(mb) else "%.0f KB".format(bytes / 1024.0)
}
