package com.sonusstudios.streampulse.tools

import android.Manifest
import android.app.TimePickerDialog
import android.content.Context
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.util.Locale
import java.util.Calendar

internal data class SonusAutoVolumeProfile(
    val id: String,
    val name: String,
    val description: String,
    val base: Int,
    val min: Int,
    val max: Int,
    val monitor: Boolean = false,
    val reduceOnly: Boolean = false,
    val sleepTimer: Boolean = false,
    val sensitivity: Float = 1f,
    val adaptation: Float = 1f,
    val scheduleStartMinute: Int? = null,
    val scheduleEndMinute: Int? = null,
    val icon: androidx.compose.ui.graphics.vector.ImageVector = Icons.Default.VolumeUp
)

internal object SonusAutoVolumeCatalog {
    val official = listOf(
        SonusAutoVolumeProfile("bus_urban", "Ônibus Urbano", "Adapta o nível ao ruído urbano, sem ultrapassar o máximo interno do perfil.", 70, 45, 100, true, false, icon=Icons.Default.DirectionsBus),
        SonusAutoVolumeProfile("bus_trip", "Ônibus de Viagem", "Referência próxima de 70%, com adaptação gradual.", 70, 52, 85, true, false, icon=Icons.Default.DirectionsBus),
        SonusAutoVolumeProfile("airplane", "Viagem de Avião", "Perfil moderado para ruído contínuo de cabine.", 58, 42, 78, true, false, icon=Icons.Default.Flight),
        SonusAutoVolumeProfile("metro_train", "Metrô e Trem", "Ajuste gradual para mudanças de ruído durante o trajeto.", 60, 35, 90, true, false, icon=Icons.Default.Train),
        SonusAutoVolumeProfile("sleep", "Modo Sono", "Começa em 50% e reduz cinco pontos a cada dez minutos até zero.", 50, 0, 50, false, true, true, icon=Icons.Default.Bedtime),
        SonusAutoVolumeProfile("voice", "Modo Voz", "Referência em 80%; classifica localmente sons de fala e reduz gradualmente até o mínimo do perfil. Não transcreve nem armazena conversas.", 80, 10, 80, true, true, icon=Icons.Default.Mic),
        SonusAutoVolumeProfile("office", "Escritório", "Volume moderado e estável para o trabalho.", 42, 35, 55, false, false, icon=Icons.Default.Work),
        SonusAutoVolumeProfile("study", "Estudo", "Nível discreto e estável, sem elevações automáticas.", 35, 28, 48, false, false, icon=Icons.Default.School),
        SonusAutoVolumeProfile("library", "Biblioteca", "Volume baixo e fixo para ambientes silenciosos.", 25, 18, 32, false, false, icon=Icons.Default.LocalLibrary),
        SonusAutoVolumeProfile("relax", "Relaxamento", "Reprodução suave com limite conservador.", 35, 25, 48, false, false, icon=Icons.Default.Spa),
        SonusAutoVolumeProfile("gym", "Academia", "Referência mais alta com adaptação moderada ao ambiente.", 65, 48, 88, true, false, icon=Icons.Default.FitnessCenter),
        SonusAutoVolumeProfile("walk", "Caminhada", "Nível moderado; reduz diante de atividade sonora externa.", 48, 20, 60, true, true, icon=Icons.Default.DirectionsWalk),
        SonusAutoVolumeProfile("silence", "Modo Silêncio", "Reduz a reprodução ao mínimo interno.", 0, 0, 0, false, true, icon=Icons.Default.VolumeOff),
        SonusAutoVolumeProfile("pedestre_rua", "Pedestre / Rua", "Referência de 50%, teto rígido de 60%; classifica sons de veículos/sirenes e reduz também diante de ruído externo intenso. Não determina direção ou distância.", 50, 10, 60, true, true, icon=Icons.Default.DirectionsWalk),
        SonusAutoVolumeProfile("bicycle", "Bicicleta", "Classifica sons de veículos e emergências e reduz diante de tráfego/ruído externo. Não tenta competir com o trânsito.", 45, 10, 60, true, true, icon=Icons.Default.DirectionsBike),
        SonusAutoVolumeProfile("public_announcements", "Avisos e Anúncios Públicos", "Usa classificação acústica local para reduzir durante fala em alto-falantes e anúncios; não transcreve palavras.", 55, 10, 60, true, true, icon=Icons.Default.RecordVoiceOver),
        SonusAutoVolumeProfile("sirens_alarms", "Sirenes e Alarmes", "Usa classificação acústica local para reconhecer padrões compatíveis com sirenes e alarmes e reduzir por prudência.", 55, 0, 60, true, true, icon=Icons.Default.Sos),
        SonusAutoVolumeProfile("calls_notifications", "Notificações e Chamadas", "Reduz durante interrupções compatíveis que solicitam foco/duck ao Android; não recebe todas as notificações do sistema.", 45, 15, 55, false, true, icon=Icons.Default.NotificationsActive),
        SonusAutoVolumeProfile("headphone_safe", "Fones Protegidos", "Limita o ganho interno a 50%; não mede decibéis no ouvido nem substitui os limites do próprio fone.", 40, 25, 50, false, true, icon=Icons.Default.Headphones)
    )
    val personalized = SonusAutoVolumeProfile("custom", "Personalizado", "Crie uma cópia de um dos perfis SONUS e personalize somente a sua cópia.", 50, 10, 80, icon=Icons.Default.Tune)
}

@Composable
internal fun SonusAutoVolumeScreen(
    service: PulsePlayerService?,
    playback: PulsePlayerPlaybackState,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("sonus_auto_volume_v1", Context.MODE_PRIVATE) }
    var activeId by remember { mutableStateOf(playback.autoVolumeProfile.ifBlank { "" }) }
    var editorOpen by remember { mutableStateOf(false) }
    var baseId by remember { mutableStateOf(prefs.getString("custom_base", "pedestre_rua") ?: "pedestre_rua") }
    var customBase by remember { mutableIntStateOf(prefs.getInt("custom_start", 50).coerceIn(0,100)) }
    var customMin by remember { mutableIntStateOf(prefs.getInt("custom_min", 10).coerceIn(0,100)) }
    var customMax by remember { mutableIntStateOf(prefs.getInt("custom_max", 80).coerceIn(0,100)) }
    var customMonitor by remember { mutableStateOf(prefs.getBoolean("custom_monitor", true)) }
    var customReduceOnly by remember { mutableStateOf(prefs.getBoolean("custom_reduce_only", true)) }
    var customSleepTimer by remember { mutableStateOf(prefs.getBoolean("custom_sleep_timer", false)) }
    var customSensitivity by remember { mutableFloatStateOf(prefs.getFloat("custom_sensitivity", 1f).coerceIn(.5f, 1.8f)) }
    var customAdaptation by remember { mutableFloatStateOf(prefs.getFloat("custom_adaptation", 1f).coerceIn(.5f, 1.8f)) }
    var customSchedule by remember { mutableStateOf(prefs.getBoolean("custom_schedule", false)) }
    var customScheduleStart by remember { mutableIntStateOf(prefs.getInt("custom_schedule_start", 8 * 60).coerceIn(0, 1439)) }
    var customScheduleEnd by remember { mutableIntStateOf(prefs.getInt("custom_schedule_end", 22 * 60).coerceIn(0, 1439)) }
    var pendingProfile by remember { mutableStateOf<SonusAutoVolumeProfile?>(null) }
    var permissionMessage by remember { mutableStateOf<String?>(null) }
    var selectedPercent by remember(playback.autoVolumePercent) { mutableIntStateOf(playback.autoVolumePercent) }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val profile = pendingProfile
        pendingProfile = null
        if (profile != null) {
            if (granted) {
                activeId = profile.id
                service?.activateAutoVolumeProfile(profile.id, profile.base, profile.min, profile.max, profile.monitor, profile.reduceOnly, profile.sleepTimer, profile.sensitivity, profile.adaptation, profile.scheduleStartMinute, profile.scheduleEndMinute)
                permissionMessage = "Monitoramento local ativado. O sistema Android poderá indicar o uso do microfone."
            } else {
                activeId = profile.id
                service?.activateAutoVolumeProfile(profile.id, profile.base, profile.min, profile.max, false, profile.reduceOnly, profile.sleepTimer, profile.sensitivity, profile.adaptation, profile.scheduleStartMinute, profile.scheduleEndMinute)
                permissionMessage = "Permissão negada: o perfil foi ativado sem monitoramento ambiental."
            }
        }
    }

    fun activate(profile: SonusAutoVolumeProfile) {
        if (profile.monitor && ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingProfile = profile
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        } else {
            activeId = profile.id
            permissionMessage = if (profile.monitor) "Monitoramento local ativo enquanto o sistema permitir." else "Perfil fixo SONUS ativado."
            service?.activateAutoVolumeProfile(profile.id, profile.base, profile.min, profile.max, profile.monitor, profile.reduceOnly, profile.sleepTimer, profile.sensitivity, profile.adaptation, profile.scheduleStartMinute, profile.scheduleEndMinute)
        }
    }

    LazyColumn(Modifier.fillMaxSize().padding(horizontal=16.dp), verticalArrangement=Arrangement.spacedBy(10.dp), contentPadding=PaddingValues(top=14.dp,bottom=30.dp)) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("SONUS AUTO VOLUME", fontSize=21.sp, fontWeight=FontWeight.Black)
                    Text("Perfis fixos de controle de reprodução", style=MaterialTheme.typography.bodySmall, color=MaterialTheme.colorScheme.onSurface.copy(alpha=.62f))
                }
                TextButton(onClick=onBack) { Text("Voltar") }
            }
        }
        item {
            Surface(shape=RoundedCornerShape(20.dp), color=Color(0xFF351B28), border=BorderStroke(1.dp, Color(0xFFFF536B).copy(alpha=.7f))) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement=Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Icon(Icons.Default.VolumeUp, null, tint=Color(0xFFFF6577), modifier=Modifier.size(24.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(when { !playback.autoVolumeActive -> "AUTO VOLUME DESATIVADO"; playback.autoVolumePaused -> "AUTO VOLUME PAUSADO"; else -> "AUTO VOLUME ATIVO" }, color=Color.White, fontWeight=FontWeight.Black, modifier=Modifier.weight(1f))
                        if (playback.autoVolumeActive) TextButton(onClick={service?.deactivateAutoVolume();activeId=""}) { Text("Desativar", color=Color.White) }
                    }
                    Text("${playback.autoVolumePercent}%", color=Color(0xFFFF6577), fontSize=30.sp, fontWeight=FontWeight.Black)
                    LinearProgressIndicator(progress={playback.autoVolumePercent/100f}, modifier=Modifier.fillMaxWidth(), color=Color(0xFFFF536B), trackColor=Color.White.copy(alpha=.12f))
                    Text("Ganho relativo ao player SONUS, sem alterar o volume global de outros aplicativos.", color=Color.White.copy(alpha=.76f), style=MaterialTheme.typography.bodySmall)
                }
            }
        }
        if (permissionMessage != null) item { Text(permissionMessage!!, style=MaterialTheme.typography.bodySmall, color=MaterialTheme.colorScheme.primary) }
        item {
            Text("PERFIS OFICIAIS • CONFIGURAÇÃO FIXA", color=MaterialTheme.colorScheme.primary, fontWeight=FontWeight.Black, style=MaterialTheme.typography.labelMedium)
            Text("Os parâmetros dos perfis SONUS são bloqueados. Ajustes próprios ficam somente em Personalizado.", style=MaterialTheme.typography.bodySmall, color=MaterialTheme.colorScheme.onSurface.copy(alpha=.62f))
        }
        items(SonusAutoVolumeCatalog.official, key={it.id}) { profile ->
            val selected = playback.autoVolumeActive && playback.autoVolumeProfile == profile.id
            Surface(
                shape=RoundedCornerShape(17.dp),
                color=if(selected) Color(0xFFFF536B).copy(alpha=.13f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.40f),
                border=BorderStroke(if(selected) 1.6.dp else 1.dp, if(selected) Color(0xFFFF536B) else MaterialTheme.colorScheme.outline.copy(alpha=.22f)),
                modifier=Modifier.fillMaxWidth().clickable { activate(profile) }
            ) {
                Row(Modifier.padding(13.dp), verticalAlignment=Alignment.CenterVertically) {
                    Icon(profile.icon, null, tint=if(selected) Color(0xFFFF536B) else MaterialTheme.colorScheme.primary, modifier=Modifier.size(25.dp))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(profile.name, fontWeight=FontWeight.Bold)
                        Text(profile.description, style=MaterialTheme.typography.bodySmall, color=MaterialTheme.colorScheme.onSurface.copy(alpha=.62f))
                        Text("Fixo • ${profile.min}%–${profile.max}%", style=MaterialTheme.typography.labelSmall, color=MaterialTheme.colorScheme.primary)
                    }
                    Icon(if(selected) Icons.Default.CheckCircle else Icons.Default.ChevronRight, null, tint=if(selected) Color(0xFFFF536B) else MaterialTheme.colorScheme.onSurface.copy(alpha=.55f))
                }
            }
        }
        item {
            Surface(shape=RoundedCornerShape(18.dp), color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.45f), border=BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha=.35f)), modifier=Modifier.fillMaxWidth().clickable { editorOpen = !editorOpen }) {
                Column(Modifier.padding(14.dp), verticalArrangement=Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Icon(Icons.Default.Tune, null, tint=MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp))
                        Text("20. Personalizado", Modifier.weight(1f), fontWeight=FontWeight.Black)
                        Icon(if(editorOpen) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null)
                    }
                    Text("Escolha um perfil como base e salve uma cópia editável. Os perfis oficiais não serão alterados.", style=MaterialTheme.typography.bodySmall, color=MaterialTheme.colorScheme.onSurface.copy(alpha=.62f))
                    if (editorOpen) {
                        var baseMenu by remember { mutableStateOf(false) }
                        Box {
                            OutlinedButton(onClick={baseMenu=true}, modifier=Modifier.fillMaxWidth()) { Text("Base: ${SonusAutoVolumeCatalog.official.firstOrNull{it.id==baseId}?.name ?: "Pedestre / Rua"}") }
                            DropdownMenu(expanded=baseMenu,onDismissRequest={baseMenu=false}) {
                                SonusAutoVolumeCatalog.official.forEach { p -> DropdownMenuItem(text={Text(p.name)},onClick={
                                    baseId=p.id;customBase=p.base;customMin=p.min;customMax=p.max.coerceAtLeast(customBase)
                                    customMonitor=p.monitor;customReduceOnly=p.reduceOnly;customSleepTimer=p.sleepTimer
                                    customSensitivity=p.sensitivity;customAdaptation=p.adaptation
                                    prefs.edit().putString("custom_base",baseId).apply();baseMenu=false
                                }) }
                            }
                        }
                        AutoVolumePercentSlider("Volume inicial", customBase) { customBase=it; customMin=customMin.coerceAtMost(it); customMax=customMax.coerceAtLeast(it) }
                        AutoVolumePercentSlider("Mínimo", customMin) { customMin=it.coerceAtMost(customBase) }
                        AutoVolumePercentSlider("Máximo", customMax) { customMax=it.coerceAtLeast(customBase).coerceAtMost(100) }
                        HorizontalDivider()
                        Text("REGRAS DA CÓPIA PERSONALIZADA", style=MaterialTheme.typography.labelMedium, color=MaterialTheme.colorScheme.primary, fontWeight=FontWeight.Black)
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Monitorar ambiente pelo microfone", fontWeight=FontWeight.SemiBold)
                                Text("Classificação local YAMNet; requer permissão de microfone.", style=MaterialTheme.typography.bodySmall, color=MaterialTheme.colorScheme.onSurface.copy(alpha=.62f))
                            }
                            Switch(checked=customMonitor,onCheckedChange={customMonitor=it})
                        }
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Somente reduzir", fontWeight=FontWeight.SemiBold)
                                Text("O ruído nunca aumenta o volume automaticamente.", style=MaterialTheme.typography.bodySmall, color=MaterialTheme.colorScheme.onSurface.copy(alpha=.62f))
                            }
                            Switch(checked=customReduceOnly,onCheckedChange={customReduceOnly=it})
                        }
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Temporizador de sono", fontWeight=FontWeight.SemiBold)
                                Text("Reduz cinco pontos a cada dez minutos até zero.", style=MaterialTheme.typography.bodySmall, color=MaterialTheme.colorScheme.onSurface.copy(alpha=.62f))
                            }
                            Switch(checked=customSleepTimer,onCheckedChange={customSleepTimer=it})
                        }
                        AutoVolumeDecimalSlider("Sensibilidade ambiental", customSensitivity, "Menor" to "Maior") { customSensitivity=it }
                        AutoVolumeDecimalSlider("Velocidade de adaptação", customAdaptation, "Suave" to "Rápida") { customAdaptation=it }
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Programação diária", fontWeight=FontWeight.SemiBold)
                                Text("Ativa o perfil somente dentro da janela escolhida.", style=MaterialTheme.typography.bodySmall, color=MaterialTheme.colorScheme.onSurface.copy(alpha=.62f))
                            }
                            Switch(checked=customSchedule,onCheckedChange={customSchedule=it})
                        }
                        if (customSchedule) {
                            val startLabel=String.format(Locale.getDefault(),"%02d:%02d",customScheduleStart/60,customScheduleStart%60)
                            val endLabel=String.format(Locale.getDefault(),"%02d:%02d",customScheduleEnd/60,customScheduleEnd%60)
                            Row(horizontalArrangement=Arrangement.spacedBy(8.dp), modifier=Modifier.fillMaxWidth()) {
                                OutlinedButton(onClick={TimePickerDialog(context,{_,h,m->customScheduleStart=h*60+m},customScheduleStart/60,customScheduleStart%60,true).show()},modifier=Modifier.weight(1f)) { Text("Início $startLabel") }
                                OutlinedButton(onClick={TimePickerDialog(context,{_,h,m->customScheduleEnd=h*60+m},customScheduleEnd/60,customScheduleEnd%60,true).show()},modifier=Modifier.weight(1f)) { Text("Fim $endLabel") }
                            }
                            Text("A janela pode atravessar a meia-noite. Horários são locais do aparelho.", style=MaterialTheme.typography.bodySmall, color=MaterialTheme.colorScheme.onSurface.copy(alpha=.62f))
                        }
                        Button(onClick={
                            prefs.edit().putString("custom_base",baseId).putInt("custom_start",customBase).putInt("custom_min",customMin).putInt("custom_max",customMax)
                                .putBoolean("custom_monitor",customMonitor).putBoolean("custom_reduce_only",customReduceOnly).putBoolean("custom_sleep_timer",customSleepTimer)
                                .putFloat("custom_sensitivity",customSensitivity).putFloat("custom_adaptation",customAdaptation)
                                .putBoolean("custom_schedule",customSchedule).putInt("custom_schedule_start",customScheduleStart).putInt("custom_schedule_end",customScheduleEnd).apply()
                            val base = SonusAutoVolumeCatalog.official.firstOrNull{it.id==baseId} ?: SonusAutoVolumeCatalog.official.first()
                            val effective = base.copy(id="custom",name="Personalizado",base=customBase,min=customMin,max=customMax,
                                monitor=customMonitor,reduceOnly=customReduceOnly,sleepTimer=customSleepTimer,
                                sensitivity=customSensitivity,adaptation=customAdaptation,
                                scheduleStartMinute=if(customSchedule) customScheduleStart else null,
                                scheduleEndMinute=if(customSchedule) customScheduleEnd else null)
                            activate(effective)
                            permissionMessage="Cópia personalizada ativada. O perfil oficial permanece inalterado."
                        },modifier=Modifier.fillMaxWidth()) { Text("Salvar e ativar minha cópia") }
                    }
                }
            }
        }
        item {
            Text("Segurança e privacidade: o YAMNet classifica localmente eventos acústicos em categorias gerais, combinado com o nível do microfone. Um único microfone não garante direção, distância ou aproximação exata de veículos, nem distingue todos os anúncios ou alertas. Mantenha atenção ao ambiente; este recurso não substitui a percepção auditiva.", style=MaterialTheme.typography.bodySmall, color=MaterialTheme.colorScheme.onSurface.copy(alpha=.60f))
        }
    }
}

@Composable
private fun AutoVolumePercentSlider(label: String, value: Int, onChange: (Int) -> Unit) {
    Column(verticalArrangement=Arrangement.spacedBy(0.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically) {
            Text(label, Modifier.weight(1f), fontWeight=FontWeight.SemiBold)
            Text("$value%", color=MaterialTheme.colorScheme.primary, fontWeight=FontWeight.Bold)
        }
        Slider(value=value.toFloat(), onValueChange={onChange(it.toInt().coerceIn(0,100))}, valueRange=0f..100f)
    }
}

@Composable
private fun AutoVolumeDecimalSlider(label: String, value: Float, captions: Pair<String,String>, onChange: (Float) -> Unit) {
    Column(verticalArrangement=Arrangement.spacedBy(0.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically) {
            Text(label, Modifier.weight(1f), fontWeight=FontWeight.SemiBold)
            Text(String.format(Locale.getDefault(),"%.1fx",value), color=MaterialTheme.colorScheme.primary, fontWeight=FontWeight.Bold)
        }
        Slider(value=value, onValueChange={onChange(it.coerceIn(.5f,1.8f))}, valueRange=.5f..1.8f)
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) {
            Text(captions.first, style=MaterialTheme.typography.labelSmall, color=MaterialTheme.colorScheme.onSurface.copy(alpha=.55f))
            Text(captions.second, style=MaterialTheme.typography.labelSmall, color=MaterialTheme.colorScheme.onSurface.copy(alpha=.55f))
        }
    }
}
