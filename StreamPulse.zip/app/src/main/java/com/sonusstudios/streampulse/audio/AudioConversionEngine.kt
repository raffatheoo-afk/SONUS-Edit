package com.sonusstudios.streampulse.audio

import android.content.Context
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.provider.OpenableColumns
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegSession
import com.arthenica.ffmpegkit.ReturnCode
import com.sonusstudios.streampulse.core.AudioConversionPreset
import com.sonusstudios.streampulse.core.SonusStorage
import com.sonusstudios.streampulse.core.SonusMediaStandards
import java.io.File
import java.util.Locale
import java.util.concurrent.CountDownLatch
import kotlin.math.max


data class AudioSourceInfo(
    val displayName: String,
    val sizeBytes: Long?,
    val durationMs: Long?,
    val sampleRateHz: Int?,
    val channels: Int?,
    val bitrate: Int?,
    val mimeType: String?
)

data class AudioTrackTags(
    val title: String = "",
    val artist: String = "",
    val album: String = "",
    val genre: String = "",
    val composer: String = "",
    val year: String = "",
    val albumArtist: String = "",
    val author: String = "",
    val copyright: String = "",
    val comment: String = "",
    val lyrics: String = "",
    val bpm: String = "",
    val isrc: String = "",
    val track: String = "",
    val disc: String = "",
    val sonusLrc: String = "",
    val sonusMusicId: String = ""
)

data class AudioProcessingConfig(
    val eqEnabled: Boolean = false,
    val eqBandsDb: List<Double> = List(10) { 0.0 },
    val pulseLiftEnabled: Boolean = false,
    val pulseLiftIntensity: Int = 50,
    val pulseOrbitMode: String = "OFF",
    val pulseOrbitPreset: String = "Natural",
    val pulseOrbitIntensity: Int = 55
)

data class AudioConversionResult(
    val success: Boolean,
    val message: String,
    val outputBytes: Long = 0L
)

/** Conversão e DSP local. O arquivo original nunca é sobrescrito. */
object AudioConversionEngine {
    val eqBandsHz = listOf(32, 64, 125, 250, 500, 1000, 2000, 4000, 8000, 16000)
    val supportedFormats = listOf("WAV", "FLAC", "MP3", "M4A", "AAC", "OGG", "OPUS", "AIFF")
    val globalSampleRates = listOf(44100, 48000, 88200, 96000, 176400, 192000)
    private val mp3SampleRates = listOf(44100, 48000)

    fun sampleRatesFor(format: String): List<Int> = when (format.uppercase(Locale.US)) {
        "MP3" -> mp3SampleRates
        else -> globalSampleRates
    }

    fun normalizedSampleRate(format: String, requested: Int): Int {
        val allowed = sampleRatesFor(format)
        return if (requested in allowed) requested else allowed.minByOrNull { kotlin.math.abs(it - requested) } ?: 44100
    }

    fun outputExtension(format: String): String = when (format.uppercase(Locale.US)) {
        "M4A" -> "m4a"
        "AAC" -> "aac"
        "AIFF" -> "aiff"
        else -> format.lowercase(Locale.US)
    }

    fun outputMime(format: String): String = when (format.uppercase(Locale.US)) {
        "WAV" -> "audio/wav"
        "FLAC" -> "audio/flac"
        "MP3" -> "audio/mpeg"
        "M4A" -> "audio/mp4"
        "AAC" -> "audio/aac"
        "OGG" -> "audio/ogg"
        "OPUS" -> "audio/opus"
        "AIFF" -> "audio/aiff"
        else -> "application/octet-stream"
    }

    fun inspect(context: Context, uri: Uri): AudioSourceInfo {
        var name = "audio"
        var size: Long? = null
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (nameIndex >= 0) name = cursor.getString(nameIndex) ?: name
                if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) size = cursor.getLong(sizeIndex)
            }
        }
        val mime = context.contentResolver.getType(uri)
        var duration: Long? = null
        var sampleRate: Int? = null
        var channels: Int? = null
        var bitrate: Int? = null
        runCatching {
            context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { afd ->
                val extractor = MediaExtractor()
                try {
                    if (afd.declaredLength >= 0) extractor.setDataSource(afd.fileDescriptor, afd.startOffset, afd.declaredLength)
                    else extractor.setDataSource(afd.fileDescriptor)
                    for (i in 0 until extractor.trackCount) {
                        val format = extractor.getTrackFormat(i)
                        val trackMime = format.getString(MediaFormat.KEY_MIME).orEmpty()
                        if (trackMime.startsWith("audio/")) {
                            if (format.containsKey(MediaFormat.KEY_DURATION)) duration = format.getLong(MediaFormat.KEY_DURATION) / 1000L
                            if (format.containsKey(MediaFormat.KEY_SAMPLE_RATE)) sampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                            if (format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                            if (format.containsKey(MediaFormat.KEY_BIT_RATE)) bitrate = format.getInteger(MediaFormat.KEY_BIT_RATE)
                            break
                        }
                    }
                } finally { extractor.release() }
            }
        }
        return AudioSourceInfo(name, size, duration, sampleRate, channels, bitrate, mime)
    }

    fun convert(
        context: Context,
        inputUri: Uri,
        outputUri: Uri,
        preset: AudioConversionPreset,
        tags: AudioTrackTags,
        onProgress: (Float) -> Unit = {},
        processing: AudioProcessingConfig = AudioProcessingConfig(),
        artworkUri: Uri? = null
    ): AudioConversionResult {
        val cacheDir = File(context.cacheDir, "audio_converter").apply { mkdirs() }
        val sourceInfo = inspect(context, inputUri)
        val sourceDurationMs = sourceInfo.durationMs?.coerceAtLeast(1L)
        val sourceExt = sourceInfo.displayName.substringAfterLast('.', "src").take(8)
        val inputFile = File(cacheDir, "input_${System.nanoTime()}.$sourceExt")
        val outputFile = File(cacheDir, "output_${System.nanoTime()}.${outputExtension(preset.format)}")
        val safeSampleRate = normalizedSampleRate(preset.format, preset.sampleRateHz)
        val safePreset = if (safeSampleRate == preset.sampleRateHz) preset else preset.copy(sampleRateHz = safeSampleRate)
        return try {
            onProgress(.01f)
            context.contentResolver.openInputStream(inputUri)?.use { input ->
                inputFile.outputStream().use { output -> input.copyTo(output) }
            } ?: return AudioConversionResult(false, "Não foi possível abrir o arquivo de origem.")
            onProgress(.03f)

            val args = mutableListOf("-y", "-hide_banner", "-i", inputFile.absolutePath, "-map", "0:a:0", "-vn", "-sn", "-dn", "-map_metadata", "-1")
            val filter = buildFilterGraph(processing, sourceInfo.channels ?: preset.channels)
            if (filter.isNotBlank()) args += listOf("-af", filter)
            args += listOf("-ar", safeSampleRate.toString(), "-ac", safePreset.channels.coerceIn(1, 2).toString())
            codecArguments(safePreset)?.let(args::addAll)
                ?: return AudioConversionResult(false, "Formato de saída não suportado pelo conversor.")
            addMetadata(args, tags)
            args += outputFile.absolutePath

            var session = runSession(args, sourceDurationMs, onProgress)
                ?: return AudioConversionResult(false, "A conversão foi interrompida antes de terminar.")
            if (!ReturnCode.isSuccess(session.returnCode)) {
                // Alguns encoders/containers de ROMs rejeitam filtros ou metadata opcionais.
                // Faz uma segunda tentativa limpa antes de declarar falha, preservando formato, taxa e canais.
                val retry = mutableListOf("-y", "-hide_banner", "-i", inputFile.absolutePath, "-map", "0:a:0", "-vn", "-sn", "-dn", "-map_metadata", "-1", "-ar", safeSampleRate.toString(), "-ac", safePreset.channels.coerceIn(1, 2).toString())
                codecArguments(safePreset)?.let(retry::addAll)
                retry += outputFile.absolutePath
                session = runSession(retry, sourceDurationMs, onProgress) ?: session
                if (!ReturnCode.isSuccess(session.returnCode) && safePreset.format.equals("MP3", true)) {
                    // FFmpegKit varia por build: tenta encoders MP3 alternativos antes de falhar.
                    for (encoder in listOf("mp3", "libshine")) {
                        val mp3Retry = mutableListOf("-y","-hide_banner","-i",inputFile.absolutePath,"-map","0:a:0","-vn","-sn","-dn","-map_metadata","-1","-ar",safeSampleRate.toString(),"-ac",safePreset.channels.coerceIn(1,2).toString(),"-c:a",encoder,"-b:a","${safePreset.bitrateKbps.coerceIn(32,320)}k",outputFile.absolutePath)
                        session = runSession(mp3Retry, sourceDurationMs, onProgress) ?: session
                        if(ReturnCode.isSuccess(session.returnCode)) break
                    }
                }
                if (!ReturnCode.isSuccess(session.returnCode)) {
                    val log = session.allLogsAsString?.takeLast(1600).orEmpty()
                    val friendly = when {
                        log.contains("Invalid argument", true) || log.contains("sample rate", true) -> "A taxa de áudio não era compatível com o formato escolhido. O SONUS tentou ajustar automaticamente, mas o encoder recusou o arquivo."
                        log.contains("encoder", true) || log.contains("codec", true) -> "O encoder deste aparelho não conseguiu gerar ${safePreset.format}. Tente novamente ou escolha outro formato."
                        else -> "Não foi possível converter este arquivo. O original foi preservado."
                    }
                    return AudioConversionResult(false, friendly)
                }
            }

            // Capa incorporada quando o container suporta artwork. Fazemos o mux após a
            // conversão para não fragilizar os caminhos de fallback dos encoders.
            if (artworkUri != null && safePreset.format.uppercase(Locale.US) in setOf("MP3", "M4A", "FLAC")) {
                val artExt = runCatching {
                    context.contentResolver.query(artworkUri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                        if (c.moveToFirst()) c.getString(0)?.substringAfterLast('.', "jpg") else "jpg"
                    }
                }.getOrNull()?.take(8) ?: "jpg"
                val artFile = File(cacheDir, "cover_${System.nanoTime()}.$artExt")
                val taggedFile = File(cacheDir, "tagged_${System.nanoTime()}.${outputExtension(safePreset.format)}")
                try {
                    context.contentResolver.openInputStream(artworkUri)?.use { input -> artFile.outputStream().use { input.copyTo(it) } }
                    if (artFile.exists() && artFile.length() > 0L) {
                        val id3 = if (safePreset.format.equals("MP3", true)) "-id3v2_version 3 " else ""
                        val coverCommand = "-y -hide_banner -i ${quote(outputFile.absolutePath)} -i ${quote(artFile.absolutePath)} -map 0:a:0 -map 1:v:0 -c:a copy -c:v mjpeg -disposition:v:0 attached_pic $id3-metadata:s:v ${quote("title=Album cover")} -metadata:s:v ${quote("comment=Cover (front)")} ${quote(taggedFile.absolutePath)}"
                        val coverSession = FFmpegKit.execute(coverCommand)
                        if (ReturnCode.isSuccess(coverSession.returnCode) && taggedFile.exists() && taggedFile.length() > 0L) {
                            outputFile.delete()
                            taggedFile.renameTo(outputFile)
                        }
                    }
                } finally { artFile.delete(); taggedFile.delete() }
            }

            onProgress(.98f)
            SonusStorage.openOutput(context, outputUri)?.use { output ->
                outputFile.inputStream().use { input -> input.copyTo(output) }
            } ?: return AudioConversionResult(false, "Não foi possível salvar o arquivo convertido.")
            onProgress(1f)
            AudioConversionResult(true, "Conversão concluída", outputFile.length())
        } catch (t: Throwable) {
            AudioConversionResult(false, t.message ?: "Falha inesperada durante a conversão.")
        } finally {
            runCatching { inputFile.delete() }
            runCatching { outputFile.delete() }
        }
    }

    /** Cria uma amostra temporária para A/B; o chamador deve apagar o File ao sair da tela. */
    fun buildProcessedPreview(
        context: Context,
        inputUri: Uri,
        processing: AudioProcessingConfig,
        startSeconds: Double,
        durationSeconds: Double = 20.0
    ): Result<File> = runCatching {
        val cacheDir = File(context.cacheDir, "audio_preview").apply { mkdirs() }
        val info = inspect(context, inputUri)
        val ext = info.displayName.substringAfterLast('.', "src").take(8)
        val input = File(cacheDir, "preview_in_${System.nanoTime()}.$ext")
        val output = File(cacheDir, "preview_processed_${System.nanoTime()}.wav")
        try {
            context.contentResolver.openInputStream(inputUri)?.use { src -> input.outputStream().use { src.copyTo(it) } }
                ?: error("Não foi possível abrir o áudio para prévia.")
            val args = mutableListOf("-y", "-ss", formatDouble(startSeconds), "-i", input.absolutePath, "-t", formatDouble(durationSeconds), "-vn")
            val filter = buildFilterGraph(processing, info.channels ?: 2)
            if (filter.isNotBlank()) args += listOf("-af", filter)
            args += listOf("-ar", "48000", "-c:a", "pcm_s16le", output.absolutePath)
            val session = runSession(args, (durationSeconds * 1000).toLong(), {}) ?: error("Prévia interrompida.")
            if (!ReturnCode.isSuccess(session.returnCode)) error(session.allLogsAsString?.takeLast(700).orEmpty().ifBlank { "Falha ao gerar prévia." })
            output
        } finally { input.delete() }
    }

    /**
     * PulseLift Signature v1: cadeia própria e conservadora, inspirada em princípios DSP públicos.
     * Não replica nem se apresenta como algoritmo Dolby. O objetivo é clareza/densidade com proteção de picos.
     */
    fun buildFilterGraph(config: AudioProcessingConfig, channels: Int): String {
        val filters = mutableListOf<String>()
        val eq = config.eqBandsDb.take(eqBandsHz.size).toMutableList().apply {
            while (size < eqBandsHz.size) add(0.0)
        }
        if (config.eqEnabled) {
            val maxBoost = eq.maxOrNull()?.coerceAtLeast(0.0) ?: 0.0
            if (maxBoost > 0.01) filters += "volume=${formatDouble(-maxBoost)}dB"
            eqBandsHz.zip(eq).forEach { (hz, gain) ->
                if (kotlin.math.abs(gain) >= .02) filters += "equalizer=f=$hz:t=o:w=1:g=${formatDouble(gain.coerceIn(-12.0, 6.0))}"
            }
        }

        if (config.pulseLiftEnabled) {
            val x = config.pulseLiftIntensity.coerceIn(0, 100) / 100.0
            if (x > 0.001) {
                val denoise = 1.0 + 2.2 * x
                val bass = 1.2 + 2.2 * x
                val lowMid = 0.25 + 0.45 * x
                val presence = 0.75 + 1.45 * x
                val air = 0.45 + 1.05 * x
                val ratio = 1.35 + 0.85 * x
                val makeup = 1.4 + 2.3 * x
                val width = 1.0 + 0.055 * x
                filters += "highpass=f=26:p=2"
                filters += "afftdn=nr=${formatDouble(denoise)}:nf=-54:ad=0.35"
                filters += "equalizer=f=78:t=o:w=1.05:g=${formatDouble(bass)}"
                filters += "equalizer=f=520:t=o:w=1.10:g=${formatDouble(lowMid)}"
                filters += "equalizer=f=2900:t=o:w=1.05:g=${formatDouble(presence)}"
                filters += "equalizer=f=10500:t=o:w=1:g=${formatDouble(air)}"
                filters += "acompressor=threshold=0.16:ratio=${formatDouble(ratio)}:attack=18:release=145:knee=4:link=average:detection=rms:makeup=${formatDouble(makeup)}"
                if (channels >= 2) {
                    filters += "stereotools=mode=lr>ms:slev=${formatDouble(width)}"
                    filters += "stereotools=mode=ms>lr"
                }
                // ~ -1.2 dBFS. O limiter é proteção, não fonte de loudness.
                filters += "alimiter=limit=0.891:attack=4:release=95:latency=true:level=false"
            }
        }

        if (channels >= 2 && config.pulseOrbitMode.uppercase(Locale.US) != "OFF") {
            val x = config.pulseOrbitIntensity.coerceIn(0, 100) / 100.0
            val p = config.pulseOrbitPreset.lowercase(Locale.US)
            when (config.pulseOrbitMode.uppercase(Locale.US)) {
                "3D", "THREE_D" -> {
                    // PulseOrbit 3D: presets próprios modulam largura, profundidade e ambiência.
                    val profile = when {
                        "deep" in p -> Triple(1.18, 18.0, 0.17)
                        "cinema" in p -> Triple(1.15, 15.5, 0.15)
                        "stage" in p -> Triple(1.12, 13.0, 0.135)
                        "studio" in p -> Triple(1.09, 10.5, 0.115)
                        else -> Triple(1.06, 8.0, 0.095)
                    }
                    val width = 1.0 + (profile.first - 1.0) * x
                    val delay = 6.0 + (profile.second - 6.0) * x
                    val crossfeed = profile.third * (0.55 + 0.45 * x)
                    val dry = 0.98 - 0.08 * x
                    filters += "stereowiden=delay=${formatDouble(delay)}:feedback=${formatDouble(0.02 + 0.04 * x)}:crossfeed=${formatDouble(crossfeed)}:drymix=${formatDouble(dry)}"
                    // pequeno ajuste M/S dá identidade sem destruir a imagem estéreo
                    filters += "stereotools=mode=lr>ms:slev=${formatDouble(width)}"
                    filters += "stereotools=mode=ms>lr"
                    filters += "aecho=0.94:${formatDouble(0.07 + 0.05 * x)}:22|43:${formatDouble(0.024 + 0.022 * x)}|${formatDouble(0.014 + 0.014 * x)}"
                }
                "8D", "EIGHT_D" -> {
                    // PulseOrbit 8D: órbita senoidal com velocidades e amplitudes próprias por preset.
                    val hz = when {
                        "energy" in p -> 0.075
                        "dream" in p -> 0.040
                        "live" in p -> 0.045
                        "deep" in p -> 0.050
                        "wide" in p -> 0.060
                        "flow" in p -> 0.065
                        "infinite" in p -> 0.058
                        else -> 0.055
                    }
                    val baseAmount = when {
                        "wide" in p -> 0.82
                        "deep" in p -> 0.76
                        "infinite" in p -> 0.80
                        "energy" in p -> 0.72
                        "dream" in p -> 0.66
                        "flow" in p -> 0.62
                        "live" in p -> 0.54
                        else -> 0.50
                    }
                    val amount = (0.16 + baseAmount * x * 0.46).coerceIn(0.18, 0.58)
                    filters += "apulsator=mode=sine:timing=hz:hz=${formatDouble(hz)}:amount=${formatDouble(amount)}:offset_l=0:offset_r=0.5"
                    filters += "aecho=0.95:${formatDouble(0.06 + 0.045 * x)}:26|54:${formatDouble(0.020 + 0.020 * x)}|${formatDouble(0.012 + 0.012 * x)}"
                    val cutoff = when {
                        "deep" in p || "dream" in p -> 11800
                        "infinite" in p -> 12400
                        else -> 13800
                    }
                    filters += "lowpass=f=${(14500 - (14500 - cutoff) * x).toInt().coerceAtLeast(10500)}"
                }
            }
            filters += "alimiter=limit=0.891:attack=4:release=80:latency=true:level=false"
        }
        return filters.joinToString(",")
    }

    private fun codecArguments(preset: AudioConversionPreset): List<String>? = when (preset.format.uppercase(Locale.US)) {
        "WAV" -> listOf("-c:a", if (preset.bitDepth >= 24) "pcm_s24le" else "pcm_s16le")
        "FLAC" -> buildList {
            addAll(listOf("-c:a", "flac", "-compression_level", "8"))
            if (preset.bitDepth >= 24) addAll(listOf("-sample_fmt", "s32", "-bits_per_raw_sample", "24")) else addAll(listOf("-sample_fmt", "s16"))
        }
        "MP3" -> listOf("-c:a", "libmp3lame", "-b:a", "${preset.bitrateKbps.coerceIn(32, 320)}k")
        "M4A" -> listOf("-c:a", "aac", "-b:a", "${preset.bitrateKbps.coerceIn(32, 320)}k")
        "AAC" -> listOf("-c:a", "aac", "-b:a", "${preset.bitrateKbps.coerceIn(32, 320)}k", "-f", "adts")
        "OGG" -> listOf("-c:a", "libvorbis", "-q:a", "6")
        "OPUS" -> listOf("-c:a", "libopus", "-b:a", "${preset.bitrateKbps.coerceIn(48, 256)}k")
        "AIFF" -> listOf("-c:a", if (preset.bitDepth >= 24) "pcm_s24be" else "pcm_s16be")
        else -> null
    }

    private fun runSession(args: List<String>, durationMs: Long?, onProgress: (Float) -> Unit): FFmpegSession? {
        val command = args.joinToString(" ") { quote(it) }
        val latch = CountDownLatch(1)
        var completed: FFmpegSession? = null
        FFmpegKit.executeAsync(command, { session -> completed = session; latch.countDown() }, null, { statistics ->
            durationMs?.takeIf { it > 0 }?.let {
                val ratio = statistics.time.toFloat() / it.toFloat()
                onProgress(ratio.coerceIn(.03f, .98f))
            }
        })
        latch.await()
        return completed
    }

    private fun addMetadata(args: MutableList<String>, tags: AudioTrackTags) {
        listOf(
            "title" to tags.title, "artist" to tags.artist, "album_artist" to tags.albumArtist, "album" to tags.album,
            "genre" to tags.genre, "composer" to tags.composer, "author" to tags.author, "date" to tags.year,
            "copyright" to tags.copyright, "comment" to tags.comment, "lyrics" to tags.lyrics, "bpm" to tags.bpm,
            "isrc" to tags.isrc, "track" to tags.track, "disc" to tags.disc,
            "SONUS_LRC" to tags.sonusLrc, "SONUS_MUSIC_ID" to tags.sonusMusicId
        ).filter { it.second.isNotBlank() }.forEach { (key, value) -> args += listOf("-metadata", "$key=$value") }
    }

    private fun quote(value: String): String = "'" + value.replace("'", "'\\''") + "'"
    private fun formatDouble(value: Double): String = String.format(Locale.US, "%.3f", value)
}
