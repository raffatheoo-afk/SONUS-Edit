package com.sonusstudios.streampulse.tools

import android.content.Context
import android.media.MediaCodecList
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.os.Handler
import android.os.Looper
import android.net.Uri
import android.provider.OpenableColumns
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.transformer.AudioEncoderSettings
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import java.util.concurrent.CountDownLatch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import com.sonusstudios.streampulse.core.SonusStorage
import java.io.File
import java.util.Locale
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Motor local dos miniapps de criação adicionados na v1.9.5.
 * Sempre trabalha em cache e copia o resultado para um novo documento SAF.
 * O arquivo original nunca é sobrescrito.
 */
data class VideoWaveformInfo(val durationMs: Long, val samples: List<Float>)
data class VideoCutSegment(val startMs: Long, val endMs: Long) { val durationMs: Long get() = (endMs - startMs).coerceAtLeast(0L) }

data class VideoCompressionSourceInfo(
    val originalBytes: Long,
    val durationMs: Long,
    val width: Int,
    val height: Int,
    val fps: Int,
    val bitrate: Int,
    val codecMime: String,
    val hasAudio: Boolean
)

data class VideoCompressionPlan(
    val requestedReductionPercent: Int,
    val targetBytes: Long,
    val targetWidth: Int,
    val targetHeight: Int,
    val targetFps: Int,
    val videoBitrate: Int,
    val audioBitrate: Int,
    val videoMime: String,
    val codecLabel: String
)

data class VideoCompressionResult(
    val uri: Uri,
    val originalBytes: Long,
    val finalBytes: Long,
    val requestedReductionPercent: Int,
    val actualReductionPercent: Double,
    val plan: VideoCompressionPlan,
    val recalibrated: Boolean
)


data class VideoConvertInputInfo(
    val uri: Uri,
    val name: String,
    val originalBytes: Long,
    val durationMs: Long,
    val width: Int,
    val height: Int,
    val fps: Int
)

data class VideoConversionProfile(
    val label: String,
    val extension: String,
    val mime: String,
    val videoCodec: String,
    val audioCodec: String,
    val extraArgs: List<String> = emptyList(),
    val maxShortSide: Int = 2160,
    val maxFps: Int = 120,
    val bitsPerPixelFrame: Double = 0.085,
    val audioBitrate: Int = 160_000
)

data class VideoConversionBatchResult(
    val outputs: List<Uri>,
    val inputBytes: Long,
    val outputBytes: Long
)

object CreatorAudioEngine {
    val outputFormats = listOf("MP3", "WAV", "FLAC", "M4A", "AAC", "OGG", "OPUS", "AIFF")
    val videoOutputFormats = listOf("MP4", "MOV", "MKV", "WEBM", "AVI", "3GP", "MPEG", "TS", "FLV")

    fun extension(format: String): String = when (format.uppercase(Locale.US)) {
        "M4A" -> "m4a"
        else -> format.lowercase(Locale.US)
    }

    fun mime(format: String): String = when (format.uppercase(Locale.US)) {
        "MP3" -> "audio/mpeg"
        "WAV" -> "audio/wav"
        "FLAC" -> "audio/flac"
        "M4A" -> "audio/mp4"
        "AAC" -> "audio/aac"
        "OGG" -> "audio/ogg"
        "OPUS" -> "audio/opus"
        "AIFF" -> "audio/aiff"
        else -> "application/octet-stream"
    }

    fun displayName(context: Context, uri: Uri): String {
        var name = "arquivo"
        runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getColumnIndex(OpenableColumns.DISPLAY_NAME).takeIf { it >= 0 }?.let { name = c.getString(it) ?: name }
            }
        }
        return name
    }

    /**
     * Fluxo dedicado do Vídeo → Áudio.
     * Converte primeiro em cache e só então cria uma entrada pendente no MediaStore.
     * A saída é publicada apenas depois de receber bytes válidos; em qualquer falha,
     * a entrada incompleta é removida para não deixar arquivo fantasma.
     */
    fun extractAudioToSonus(
        context: Context,
        inputUri: Uri,
        displayName: String,
        format: String
    ): Result<Uri> = runCatching {
        requireAudioTrack(context, inputUri)
        withCachedInputs(context, listOf(inputUri), "video_audio") { inputs, work ->
            val out = File(work, "audio_${System.nanoTime()}.${extension(format)}")
            try {
                renderVideoAudio(inputs.first(), out, format)
                require(out.exists() && out.length() > 0L) { "O processamento não gerou um arquivo de áudio válido." }

                val outputUri = SonusStorage.createAudio(
                    context = context,
                    displayName = displayName,
                    mime = mime(format),
                    bucket = SonusStorage.Bucket.AUDIO
                ) ?: error("Não foi possível criar o arquivo de saída em SONUS/Audio.")

                try {
                    SonusStorage.openOutput(context, outputUri)?.use { target ->
                        out.inputStream().use { source -> source.copyTo(target) }
                    } ?: error("Não foi possível salvar o arquivo de saída em SONUS/Audio.")

                    val written = runCatching {
                        context.contentResolver.openAssetFileDescriptor(outputUri, "r")?.use { afd -> afd.length } ?: -1L
                    }.getOrDefault(-1L)
                    if (written == 0L) error("O arquivo de saída ficou vazio.")

                    SonusStorage.finish(context, outputUri)
                    outputUri
                } catch (t: Throwable) {
                    SonusStorage.abort(context, outputUri)
                    throw t
                }
            } finally {
                runCatching { out.delete() }
            }
        }
    }

    private fun renderVideoAudio(input: File, out: File, format: String) {
        val base = "-y -hide_banner -i ${q(input.absolutePath)} -map 0:a:0 -vn -sn -dn -ar 48000 -ac 2"
        if (format.equals("MP3", ignoreCase = true)) {
            val primary = runCatching {
                execute("$base -c:a libmp3lame -b:a 256k ${q(out.absolutePath)}")
            }
            if (primary.isFailure) {
                out.delete()
                // Alguns builds Android do FFmpeg expõem libshine em vez de libmp3lame.
                execute("$base -c:a libshine -b:a 192k ${q(out.absolutePath)}")
            }
        } else {
            execute("$base ${codec(format)} ${q(out.absolutePath)}")
        }
    }

    /** Faz uma cópia imediata das seleções do picker. Alguns MediaStore/Samsung URIs podem
     * desaparecer antes do usuário escolher o destino; a mesclagem nunca depende deles. */
    fun stageMergeAudioInputs(context: Context, uris: List<Uri>): Result<List<Pair<String, String>>> = runCatching {
        val dir = File(context.cacheDir, "creator_tools/merge_audio_selected").apply { mkdirs() }
        dir.listFiles()?.forEach { runCatching { it.delete() } }
        uris.mapIndexed { index, uri ->
            // O nome é apenas informativo: nunca deixe uma consulta MediaStore impedir a cópia.
            val name = runCatching { displayName(context, uri).take(100) }.getOrDefault("Música ${index + 1}")
            val ext = name.substringAfterLast('.', "audio").take(8).ifBlank { "audio" }
            val out = File(dir, "selected_${index}_${System.nanoTime()}.$ext")
            try {
                // Abra o descritor imediatamente enquanto a permissão temporária do picker ainda está viva.
                // FileInputStream sobre PFD é mais robusto com MediaStore/Samsung do que reabrir o URI no FFmpeg.
                val copied = runCatching {
                    context.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
                        java.io.FileInputStream(pfd.fileDescriptor).use { input ->
                            out.outputStream().use { output -> input.copyTo(output) }
                        }
                    }
                    out.length() > 0L
                }.getOrDefault(false)
                if (!copied) {
                    // Fallback para providers que não oferecem PFD, mas aceitam stream.
                    context.contentResolver.openInputStream(uri)?.use { input ->
                        out.outputStream().use { output -> input.copyTo(output) }
                    } ?: error("arquivo indisponível")
                }
            } catch (t: Throwable) {
                out.delete(); error("Não foi possível copiar a música ${index + 1} (${name.ifBlank { "arquivo" }}) para o SONUS. Selecione-a novamente.")
            }
            require(out.length() > 0L) { "A música ${index + 1} (${name.ifBlank { "arquivo" }}) está vazia." }
            name to out.absolutePath
        }
    }

    fun mergeAudioStaged(
        context: Context, inputPaths: List<String>, outputUri: Uri, format: String, onProgress: (Int) -> Unit = {}
    ): Result<Unit> = runCatching {
        val inputs = inputPaths.map { File(it) }
        require(inputs.size >= 2) { "Selecione pelo menos dois arquivos." }
        inputs.forEachIndexed { i, file -> require(file.exists() && file.length() > 0L) { "A música ${i + 1} não está mais disponível. Selecione-a novamente." } }
        val work = File(context.cacheDir, "creator_tools/merge_audio_render").apply { mkdirs() }
        var last = 0
        fun report(v:Int){ val n=v.coerceIn(0,100); if(n>last){last=n;onProgress(n)} }
        val durations = inputs.map { mediaDurationMs(it).coerceAtLeast(1L) }
        val out = File(work, "merged_${System.nanoTime()}.${extension(format)}")
        try {
            report(2)
            val normalized = inputs.indices.joinToString(";") { i -> "[$i:a]aresample=48000,aformat=sample_fmts=fltp:channel_layouts=stereo,asetpts=PTS-STARTPTS[a$i]" }
            val refs = inputs.indices.joinToString("") { "[a$it]" }
            val filter = "$normalized;$refs concat=n=${inputs.size}:v=0:a=1[outa]"
            val command = buildString { append("-y -hide_banner "); inputs.forEach { append("-i ${q(it.absolutePath)} ") }; append("-filter_complex ${q(filter)} -map ${q("[outa]")} ${codec(format)} ${q(out.absolutePath)}") }
            executeWithProgress(command, durations.sum().coerceAtLeast(1L), 4, 96, ::report)
            require(out.exists() && out.length() > 0L) { "A mesclagem não gerou um áudio válido." }
            // Em alguns Samsung/MediaStore o documento automático pode ser publicado vazio e
            // invalidado antes da gravação. Se isso acontecer, recrie a saída somente agora,
            // quando o áudio final já existe, e grave nela imediatamente.
            val saved = runCatching { copyOut(context, out, outputUri) }.isSuccess
            if (!saved) {
                val fresh = SonusStorage.createForMime(
                    context,
                    "Mesclado_SONUS_${System.currentTimeMillis()}.${extension(format)}",
                    mime(format),
                    SonusStorage.Bucket.AUDIO
                ) ?: error("Não foi possível criar o arquivo final na pasta SONUS.")
                copyOut(context, out, fresh)
            }
            report(100)
        } finally { runCatching { out.delete() } }
    }

    @Volatile
    private var activeMergeSessionId: Long? = null
    @Volatile
    private var activeVideoTransformer: Transformer? = null

    fun cancelActiveMerge() {
        activeMergeSessionId?.let { id -> runCatching { FFmpegKit.cancel(id) } }
    }

    fun mergeAudio(
        context: Context,
        inputUris: List<Uri>,
        outputUri: Uri,
        format: String,
        transition: MergeTransition = MergeTransition.DIRECT,
        transitionSeconds: Double = 0.0,
        onProgress: (Int) -> Unit = {}
    ): Result<Unit> = runCatching {
        require(inputUris.size >= 2) { "Selecione pelo menos dois arquivos." }
        var lastProgress = 0
        fun report(value: Int) {
            val next = value.coerceIn(0, 100)
            if (next > lastProgress) { lastProgress = next; onProgress(next) }
        }
        report(1)
        withCachedInputs(context, inputUris, "merge_audio") { inputs, work ->
            report(7)
            val durations = inputs.map { mediaDurationMs(it).coerceAtLeast(1L) }
            val totalDurationMs = durations.sum().coerceAtLeast(1L)
            val out = File(work, "merged_${System.nanoTime()}.${extension(format)}")
            try {
                val normalized = inputs.indices.joinToString(";") { i ->
                    "[$i:a]aresample=48000,aformat=sample_fmts=fltp:channel_layouts=stereo,asetpts=PTS-STARTPTS[a$i]"
                }
                val refs = inputs.indices.joinToString("") { "[a$it]" }
                val filter = "$normalized;$refs concat=n=${inputs.size}:v=0:a=1[outa]"
                val command = buildString {
                    append("-y -hide_banner ")
                    inputs.forEach { file -> append("-i ${q(file.absolutePath)} ") }
                    append("-filter_complex ${q(filter)} -map ${q("[outa]")} ${codec(format)} ${q(out.absolutePath)}")
                }
                executeWithProgress(command, totalDurationMs, 8, 95, ::report)
                require(out.exists() && out.length() > 0L) { "A mesclagem não gerou um áudio válido." }
                report(97)
                copyOut(context, out, outputUri)
                report(100)
            } finally {
                runCatching { out.delete() }
            }
        }
    }

    fun mergeVideoToSonus(
        context: Context,
        inputUris: List<Uri>,
        displayName: String,
        quality: String,
        onProgress: (Int) -> Unit = {}
    ): Result<Uri> = runCatching {
        require(inputUris.size >= 2) { "Selecione pelo menos dois vídeos." }
        var lastProgress = 0
        fun report(value: Int) {
            val next = value.coerceIn(0, 100)
            if (next > lastProgress) { lastProgress = next; onProgress(next) }
        }
        report(1)
        withCachedInputs(context, inputUris, "merge_video") { inputs, work ->
            val durations = inputs.map { mediaDurationMs(it).coerceAtLeast(1L) }
            val totalDurationMs = durations.sum().coerceAtLeast(1L)
            val firstSize = videoDisplaySize(inputs.first())
            val targetHeight = when (quality) { "480p" -> 480; "720p" -> 720; "1080p" -> 1080; else -> firstSize.second }
            val aspect = firstSize.first.toDouble() / firstSize.second.coerceAtLeast(1).toDouble()
            val targetWidth = makeEven((targetHeight * aspect).toInt().coerceAtLeast(2))
            val safeTargetHeight = makeEven(targetHeight.coerceAtLeast(2))
            val segments = mutableListOf<File>()
            var completedDuration = 0L
            try {
                inputs.forEachIndexed { index, input ->
                    val segment = File(work, "segment_${index}_${System.nanoTime()}.mp4")
                    val segmentDuration = durations[index]
                    val startP = 5 + ((completedDuration.toDouble() / totalDurationMs) * 82.0).toInt()
                    val endP = 5 + (((completedDuration + segmentDuration).toDouble() / totalDurationMs) * 82.0).toInt()
                    normalizeVideoSegment(
                        input = input,
                        out = segment,
                        width = targetWidth,
                        height = safeTargetHeight,
                        durationMs = segmentDuration,
                        progressStart = startP,
                        progressEnd = endP.coerceAtMost(87),
                        onProgress = ::report
                    )
                    require(segment.exists() && segment.length() > 0L) { "O vídeo ${index + 1} não pôde ser preparado para a mesclagem." }
                    segments += segment
                    completedDuration += segmentDuration
                }
                val concatList = File(work, "concat_${System.nanoTime()}.txt")
                concatList.writeText(segments.joinToString("\n") { "file '${it.absolutePath}'" })
                val out = File(work, "merged_video_${System.nanoTime()}.mp4")
                try {
                    executeWithProgress(
                        "-y -hide_banner -f concat -safe 0 -i ${q(concatList.absolutePath)} -c copy -movflags +faststart ${q(out.absolutePath)}",
                        totalDurationMs, 88, 97, ::report
                    )
                    require(out.exists() && out.length() > 0L) { "A mesclagem não gerou um vídeo válido." }
                    val uri = SonusStorage.createVideo(context, displayName, "video/mp4", SonusStorage.Bucket.VISUALIZER)
                        ?: error("Não foi possível criar o vídeo de saída.")
                    try {
                        report(98)
                        SonusStorage.openOutput(context, uri)?.use { target -> out.inputStream().use { it.copyTo(target) } }
                            ?: error("Não foi possível salvar o vídeo.")
                        SonusStorage.finish(context, uri)
                        report(100)
                        uri
                    } catch (t: Throwable) {
                        SonusStorage.abort(context, uri)
                        throw t
                    } finally { runCatching { out.delete() } }
                } finally { runCatching { concatList.delete() } }
            } finally {
                segments.forEach { runCatching { it.delete() } }
            }
        }
    }

    private fun normalizeVideoSegment(
        input: File, out: File, width: Int, height: Int, durationMs: Long,
        progressStart: Int, progressEnd: Int, onProgress: (Int) -> Unit
    ) {
        val hasAudio = hasAudioTrack(input)
        val filter = "scale=w=$width:h=$height:force_original_aspect_ratio=decrease,pad=$width:$height:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=30,format=yuv420p"
        val durationSec = String.format(Locale.US, "%.3f", durationMs / 1000.0)
        fun command(videoCodec: String): String = buildString {
            append("-y -hide_banner -i ${q(input.absolutePath)} ")
            if (!hasAudio) append("-f lavfi -i ${q("anullsrc=r=48000:cl=stereo")} ")
            append("-map 0:v:0 ")
            append(if (hasAudio) "-map 0:a:0 " else "-map 1:a:0 ")
            append("-vf ${q(filter)} $videoCodec -pix_fmt yuv420p -c:a aac -ar 48000 -ac 2 -b:a 192k ")
            if (!hasAudio) append("-t $durationSec ")
            append("-shortest -movflags +faststart ${q(out.absolutePath)}")
        }
        // O encoder MPEG-4 nativo faz parte do FFmpeg base e evita opções privadas
        // (como -preset) que variam entre builds Android. Prioridade aqui: compatibilidade.
        executeWithProgress(command("-c:v mpeg4 -q:v 3"), durationMs, progressStart, progressEnd, onProgress)
    }

    fun analyzeVideoWaveform(context: Context, inputUri: Uri, sampleCount: Int = 720): Result<VideoWaveformInfo> = runCatching {
        withCachedInputs(context, listOf(inputUri), "video_waveform") { inputs, work ->
            val input = inputs.first()
            require(hasAudioTrack(input)) { "Este vídeo não possui áudio para gerar a waveform." }
            val duration = mediaDurationMs(input).coerceAtLeast(1L)
            val raw = File(work, "wave_${System.nanoTime()}.pcm")
            try {
                execute("-y -hide_banner -i ${q(input.absolutePath)} -map 0:a:0 -vn -ac 1 -ar 4000 -f s16le ${q(raw.absolutePath)}")
                val bytes = raw.readBytes()
                require(bytes.size >= 2) { "Não foi possível analisar o áudio deste vídeo." }
                val totalSamples = bytes.size / 2
                val buckets = sampleCount.coerceIn(240, 1400).coerceAtMost(totalSamples.coerceAtLeast(1))
                val step = totalSamples.toDouble() / buckets.toDouble()
                val peaks = ArrayList<Float>(buckets)
                for (bucket in 0 until buckets) {
                    val from = (bucket * step).toInt().coerceIn(0, totalSamples - 1)
                    val to = (((bucket + 1) * step).toInt()).coerceIn(from + 1, totalSamples)
                    var peak = 0
                    var i = from
                    while (i < to) {
                        val lo = bytes[i * 2].toInt() and 0xff
                        val hi = bytes[i * 2 + 1].toInt()
                        val value = kotlin.math.abs(((hi shl 8) or lo).toShort().toInt())
                        if (value > peak) peak = value
                        i++
                    }
                    peaks += (peak / 32768f).coerceIn(0f, 1f)
                }
                val maxPeak = peaks.maxOrNull()?.coerceAtLeast(.02f) ?: 1f
                VideoWaveformInfo(duration, peaks.map { (it / maxPeak).coerceIn(.03f, 1f) })
            } finally { runCatching { raw.delete() } }
        }
    }


    fun inspectVideoForConversion(context: Context, inputUri: Uri): Result<VideoConvertInputInfo> = runCatching {
        val source = inspectVideoCompressionSource(context, inputUri).getOrThrow()
        VideoConvertInputInfo(
            uri = inputUri,
            name = displayName(context, inputUri),
            originalBytes = source.originalBytes,
            durationMs = source.durationMs,
            width = source.width,
            height = source.height,
            fps = source.fps
        )
    }

    fun videoConversionCompatibility(format: String, fps: Int, resolution: String): String? {
        val profile = videoProfile(format) ?: return "Formato de saída não reconhecido."
        val shortSide = targetShortSide(resolution)
        if (fps !in listOf(24, 30, 60, 120)) return "FPS de saída inválido."
        if (shortSide > profile.maxShortSide) return "$format suporta no SONUS até ${profile.maxShortSide}p para manter compatibilidade."
        if (fps > profile.maxFps) return "$format suporta no SONUS até ${profile.maxFps} FPS."
        return null
    }

    fun estimateVideoConversionBytes(
        inputs: List<VideoConvertInputInfo>,
        format: String,
        targetFps: Int,
        resolution: String
    ): Long {
        val profile = videoProfile(format) ?: return 0L
        if (videoConversionCompatibility(format, targetFps, resolution) != null) return 0L
        return inputs.sumOf { info ->
            val (w, h) = scaledVideoDimensions(info.width, info.height, resolution)
            val videoBitrate = estimatedVideoBitrate(w, h, targetFps, profile)
            val totalBitrate = videoBitrate.toLong() + profile.audioBitrate
            ((totalBitrate * info.durationMs.coerceAtLeast(1L)) / 8_000L).coerceAtLeast(1L)
        }
    }

    suspend fun convertVideosToSonus(
        context: Context,
        inputUris: List<Uri>,
        outputFormat: String,
        targetFps: Int,
        resolution: String,
        onProgress: (percent: Int, current: Int, total: Int) -> Unit = { _, _, _ -> }
    ): Result<VideoConversionBatchResult> = withContext(Dispatchers.IO) {
        runCatching {
            require(inputUris.isNotEmpty()) { "Selecione pelo menos um vídeo." }
        val profile = videoProfile(outputFormat) ?: error("Formato de saída não reconhecido.")
        videoConversionCompatibility(outputFormat, targetFps, resolution)?.let { error(it) }
        ensureVideoProfileAvailable(profile)

        // Pré-check completo antes do primeiro encode: evita descobrir um arquivo inválido
        // apenas no final de um lote grande.
        val infos = inputUris.mapIndexed { index, uri ->
            inspectVideoForConversion(context, uri).getOrElse {
                error("O vídeo ${index + 1} não pôde ser analisado: ${it.message.orEmpty()}")
            }
        }
        require(infos.size == inputUris.size) { "Nem todos os vídeos selecionados estão disponíveis." }

        val outputs = mutableListOf<Uri>()
        var outputBytes = 0L
        val totalInput = infos.sumOf { it.originalBytes.coerceAtLeast(0L) }
        inputUris.forEachIndexed { index, uri ->
            val info = infos[index]
            val current = index + 1
            val total = inputUris.size
            val p0 = 2 + ((index.toDouble() / total) * 95.0).toInt()
            val p1 = 2 + (((index + 1).toDouble() / total) * 95.0).toInt()
            onProgress(p0.coerceIn(1, 97), current, total)

            withCachedInputs(context, listOf(uri), "video_convert_${index}_${System.nanoTime()}") { cached, work ->
                val input = cached.first()
                val out = File(work, "converted_${System.nanoTime()}.${profile.extension}")
                try {
                    val (targetWidth, targetHeight) = scaledVideoDimensions(info.width, info.height, resolution)
                    val bitrate = estimatedVideoBitrate(targetWidth, targetHeight, targetFps, profile)
                    // Code122: o tamanho final já é calculado no Kotlin. O FFmpeg recebe um
                    // argumento de filtro simples, sem expressões aninhadas/aspas de shell.
                    // Isso elimina o escaping frágil que fazia o Conversor falhar após ler o MP4.
                    val filter = "scale=${targetWidth}:${targetHeight},fps=$targetFps"
                    val args = buildList {
                        addAll(listOf("-y", "-hide_banner", "-i", input.absolutePath))
                        addAll(listOf("-map", "0:v:0", "-map", "0:a?", "-vf", filter))
                        addAll(listOf("-c:v", profile.videoCodec, "-b:v", bitrate.toString()))
                        addAll(listOf("-maxrate", (bitrate * 1.18).roundToInt().toString()))
                        addAll(listOf("-bufsize", (bitrate * 2.0).roundToInt().toString()))
                        addAll(listOf("-pix_fmt", "yuv420p"))
                        addAll(listOf("-c:a", profile.audioCodec, "-b:a", profile.audioBitrate.toString()))
                        addAll(profile.extraArgs)
                        add(out.absolutePath)
                    }
                    executeWithArgumentsProgress(args, info.durationMs.coerceAtLeast(1L), p0, p1.coerceAtMost(97)) { p ->
                        onProgress(p, current, total)
                    }
                    require(out.exists() && out.length() > 0L) { "O vídeo $current não gerou um arquivo válido." }

                    val base = info.name.substringBeforeLast('.').replace(Regex("[^A-Za-z0-9À-ÿ _.-]"), "_").trim().ifBlank { "Video_SONUS" }
                    val safeName = "${base}_SONUS_${resolution}_${targetFps}fps.${profile.extension}"
                    val outputUri = SonusStorage.createVideo(context, safeName, profile.mime, SonusStorage.Bucket.VISUALIZER)
                        ?: error("Não foi possível criar a saída do vídeo $current.")
                    try {
                        SonusStorage.openOutput(context, outputUri)?.use { target -> out.inputStream().use { it.copyTo(target) } }
                            ?: error("Não foi possível salvar o vídeo $current.")
                        SonusStorage.finish(context, outputUri)
                        outputs += outputUri
                        outputBytes += out.length()
                    } catch (t: Throwable) {
                        SonusStorage.abort(context, outputUri)
                        throw t
                    }
                } finally {
                    runCatching { out.delete() }
                }
            }
        }
            onProgress(100, inputUris.size, inputUris.size)
            VideoConversionBatchResult(outputs.toList(), totalInput, outputBytes)
        }
    }

    private fun ensureVideoProfileAvailable(profile: VideoConversionProfile) {
        val session = FFmpegKit.execute("-hide_banner -encoders")
        require(ReturnCode.isSuccess(session.returnCode)) { "Não foi possível validar os codecs do Conversor de Vídeo." }
        val encoders = session.allLogsAsString.orEmpty()
        require(encoders.contains(profile.videoCodec, ignoreCase = true)) { "O codec de vídeo necessário para ${profile.label} não está disponível neste aparelho." }
        require(encoders.contains(profile.audioCodec, ignoreCase = true)) { "O codec de áudio necessário para ${profile.label} não está disponível neste aparelho." }
    }

    private fun videoProfile(format: String): VideoConversionProfile? = when (format.uppercase(Locale.US)) {
        // Perfis não-GPL e previsíveis: cada botão é contêiner + codecs válidos,
        // não uma simples troca de extensão.
        "MP4" -> VideoConversionProfile("MP4", "mp4", "video/mp4", "mpeg4", "aac", listOf("-movflags", "+faststart"), bitsPerPixelFrame = .090)
        "MOV" -> VideoConversionProfile("MOV", "mov", "video/quicktime", "mpeg4", "aac", bitsPerPixelFrame = .090)
        "MKV" -> VideoConversionProfile("MKV", "mkv", "video/x-matroska", "mpeg4", "aac", bitsPerPixelFrame = .085)
        "WEBM" -> VideoConversionProfile("WEBM", "webm", "video/webm", "libvpx-vp9", "libopus", listOf("-deadline", "good", "-cpu-used", "4"), bitsPerPixelFrame = .055, audioBitrate = 128_000)
        "AVI" -> VideoConversionProfile("AVI", "avi", "video/x-msvideo", "mpeg4", "libmp3lame", bitsPerPixelFrame = .100)
        "3GP" -> VideoConversionProfile("3GP", "3gp", "video/3gpp", "mpeg4", "aac", listOf("-ar", "44100"), maxShortSide = 1080, maxFps = 60, bitsPerPixelFrame = .085, audioBitrate = 96_000)
        "MPEG" -> VideoConversionProfile("MPEG", "mpeg", "video/mpeg", "mpeg2video", "mp2", listOf("-f", "mpeg"), maxShortSide = 1080, maxFps = 60, bitsPerPixelFrame = .140, audioBitrate = 192_000)
        "TS" -> VideoConversionProfile("TS", "ts", "video/mp2t", "mpeg2video", "mp2", listOf("-f", "mpegts"), bitsPerPixelFrame = .140, audioBitrate = 192_000)
        "FLV" -> VideoConversionProfile("FLV", "flv", "video/x-flv", "flv", "libmp3lame", listOf("-f", "flv"), maxShortSide = 1080, maxFps = 60, bitsPerPixelFrame = .115, audioBitrate = 128_000)
        else -> null
    }

    private fun targetShortSide(resolution: String): Int = when (resolution) {
        "4K" -> 2160
        "2K" -> 1440
        "720p" -> 720
        "480p" -> 480
        "360p" -> 360
        else -> 1080
    }

    private fun scaledVideoDimensions(width: Int, height: Int, resolution: String): Pair<Int, Int> {
        val w = width.coerceAtLeast(2)
        val h = height.coerceAtLeast(2)
        val shortSide = targetShortSide(resolution).coerceAtLeast(2)
        return when {
            w > h -> makeEven((shortSide * (w.toDouble() / h.toDouble())).roundToInt()) to makeEven(shortSide)
            h > w -> makeEven(shortSide) to makeEven((shortSide * (h.toDouble() / w.toDouble())).roundToInt())
            else -> makeEven(shortSide) to makeEven(shortSide)
        }
    }

    private fun estimatedVideoBitrate(width: Int, height: Int, fps: Int, profile: VideoConversionProfile): Int {
        val raw = width.toDouble() * height.toDouble() * fps.coerceAtLeast(1).toDouble() * profile.bitsPerPixelFrame
        return raw.roundToInt().coerceIn(550_000, 60_000_000)
    }

    fun inspectVideoCompressionSource(context: Context, inputUri: Uri): Result<VideoCompressionSourceInfo> = runCatching {
        val retriever = MediaMetadataRetriever()
        var width = 0
        var height = 0
        var durationMs = 0L
        var fps = 0
        var bitrate = 0
        try {
            retriever.setDataSource(context, inputUri)
            width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rotation = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rotation == 90 || rotation == 270) { val tmp = width; width = height; height = tmp }
            durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            fps = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_CAPTURE_FRAMERATE)?.toFloatOrNull()?.roundToInt() ?: 0
            bitrate = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toIntOrNull() ?: 0
        } finally { runCatching { retriever.release() } }

        var codecMime = "video/unknown"
        var hasAudio = false
        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(context, inputUri, null)
            for (index in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(index)
                val mime = format.getString(MediaFormat.KEY_MIME).orEmpty()
                if (mime.startsWith("video/")) {
                    codecMime = mime
                    if (fps <= 0 && format.containsKey(MediaFormat.KEY_FRAME_RATE)) {
                        fps = format.getInteger(MediaFormat.KEY_FRAME_RATE)
                    }
                }
                if (mime.startsWith("audio/")) hasAudio = true
            }
        } finally { runCatching { extractor.release() } }

        val originalBytes = queryUriSize(context, inputUri)
        require(originalBytes > 0L) { "Não foi possível identificar o tamanho do vídeo original." }
        require(durationMs > 0L) { "Não foi possível identificar a duração do vídeo." }
        require(width > 0 && height > 0) { "Não foi possível identificar a resolução do vídeo." }
        VideoCompressionSourceInfo(
            originalBytes = originalBytes,
            durationMs = durationMs,
            width = makeEven(width.coerceAtLeast(2)),
            height = makeEven(height.coerceAtLeast(2)),
            fps = fps.takeIf { it in 1..240 } ?: 30,
            bitrate = bitrate.coerceAtLeast(0),
            codecMime = codecMime,
            hasAudio = hasAudio
        )
    }

    fun buildVideoCompressionPlan(
        context: Context,
        source: VideoCompressionSourceInfo,
        preset: String,
        resolution: String
    ): VideoCompressionPlan {
        val requestedReduction = when (preset) {
            "Leve" -> 30
            "Máxima compressão" -> 50
            else -> 40
        }
        val requestedShortSide = when (resolution) {
            "720p" -> 720
            "1080p" -> 1080
            else -> minOf(source.width, source.height)
        }
        val originalShort = minOf(source.width, source.height)
        val targetShort = minOf(originalShort, requestedShortSide).coerceAtLeast(2)
        val ratio = if (source.width >= source.height) source.width.toDouble() / source.height.toDouble() else source.height.toDouble() / source.width.toDouble()
        val targetWidth: Int
        val targetHeight: Int
        if (source.width >= source.height) {
            targetHeight = makeEven(targetShort)
            targetWidth = makeEven((targetHeight * ratio).roundToInt().coerceAtLeast(2))
        } else {
            targetWidth = makeEven(targetShort)
            targetHeight = makeEven((targetWidth * ratio).roundToInt().coerceAtLeast(2))
        }

        val targetFps = targetCompressionFps(source.fps, preset)
        val wantsHevc = targetShort >= 2160 && hasEncoderFor(MimeTypes.VIDEO_H265)
        val videoMime = if (wantsHevc) MimeTypes.VIDEO_H265 else MimeTypes.VIDEO_H264
        val codecLabel = if (videoMime == MimeTypes.VIDEO_H265) "HEVC/H.265" else "H.264/AVC"
        val audioBitrate = if (!source.hasAudio) 0 else when (preset) {
            "Leve" -> 160_000
            "Máxima compressão" -> 96_000
            else -> 128_000
        }
        val rawTargetBytes = (source.originalBytes * (100 - requestedReduction) / 100.0).toLong().coerceAtLeast(1L)
        val targetTotalBitrate = ((rawTargetBytes * 8_000L) / source.durationMs.coerceAtLeast(1L)).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        val minVideoBitrate = minimumSafeVideoBitrate(targetWidth, targetHeight, videoMime)
        val videoBitrate = (targetTotalBitrate - audioBitrate - 24_000).coerceAtLeast(minVideoBitrate)
        val effectiveTotalBitrate = videoBitrate + audioBitrate + 24_000
        val effectiveTargetBytes = ((effectiveTotalBitrate.toLong() * source.durationMs) / 8_000L)
            .coerceAtMost(source.originalBytes - 1L)
            .coerceAtLeast(1L)

        return VideoCompressionPlan(
            requestedReductionPercent = requestedReduction,
            targetBytes = effectiveTargetBytes,
            targetWidth = targetWidth,
            targetHeight = targetHeight,
            targetFps = targetFps,
            videoBitrate = videoBitrate,
            audioBitrate = audioBitrate,
            videoMime = videoMime,
            codecLabel = codecLabel
        )
    }

    @OptIn(UnstableApi::class)
    suspend fun compressVideoToSonus(
        context: Context,
        inputUri: Uri,
        displayName: String,
        preset: String,
        resolution: String,
        onProgress: (Int) -> Unit = {}
    ): Result<VideoCompressionResult> = withContext(Dispatchers.Main.immediate) {
        runCatching {
            val source = inspectVideoCompressionSource(context, inputUri).getOrThrow()
            var plan = buildVideoCompressionPlan(context, source, preset, resolution)
            val work = File(context.cacheDir, "creator_tools/video_compress_media3").apply { mkdirs() }
            work.listFiles()?.forEach { runCatching { it.delete() } }
            var out = File(work, "compressed_${System.nanoTime()}.mp4")
            var recalibrated = false
            try {
                renderCompressionMedia3(context, inputUri, out, plan, 2, 88, onProgress)
                var finalBytes = out.length()
                require(finalBytes > 0L) { "A compressão não gerou um vídeo válido." }

                val tooLargeForTarget = finalBytes > (plan.targetBytes * 1.12).toLong()
                if (tooLargeForTarget || finalBytes >= source.originalBytes) {
                    val desiredRatio = (plan.targetBytes.toDouble() / finalBytes.toDouble()).coerceIn(.45, .98)
                    val adjustedBitrate = (plan.videoBitrate * desiredRatio * .95).roundToInt()
                        .coerceAtLeast(minimumSafeVideoBitrate(plan.targetWidth, plan.targetHeight, plan.videoMime))
                    if (adjustedBitrate < plan.videoBitrate) {
                        recalibrated = true
                        plan = plan.copy(videoBitrate = adjustedBitrate)
                        runCatching { out.delete() }
                        out = File(work, "compressed_retry_${System.nanoTime()}.mp4")
                        renderCompressionMedia3(context, inputUri, out, plan, 89, 96, onProgress)
                        finalBytes = out.length()
                    }
                }

                require(finalBytes > 0L) { "A compressão não gerou um vídeo válido." }
                require(finalBytes < source.originalBytes) {
                    "O vídeo original já está altamente comprimido e uma nova codificação não conseguiu reduzir o arquivo com segurança. O original foi preservado."
                }

                val safeName = displayName.substringBeforeLast('.').ifBlank { "Video_SONUS" } + "_comprimido.mp4"
                val outputUri = SonusStorage.createVideo(context, safeName, "video/mp4", SonusStorage.Bucket.VISUALIZER)
                    ?: error("Não foi possível criar o vídeo comprimido.")
                try {
                    onProgress(98)
                    withContext(Dispatchers.IO) {
                        SonusStorage.openOutput(context, outputUri)?.use { target -> out.inputStream().use { it.copyTo(target) } }
                            ?: error("Não foi possível salvar o vídeo comprimido.")
                    }
                    SonusStorage.finish(context, outputUri)
                    onProgress(100)
                    val actualReduction = (1.0 - finalBytes.toDouble() / source.originalBytes.toDouble()) * 100.0
                    VideoCompressionResult(
                        uri = outputUri,
                        originalBytes = source.originalBytes,
                        finalBytes = finalBytes,
                        requestedReductionPercent = plan.requestedReductionPercent,
                        actualReductionPercent = actualReduction.coerceAtLeast(0.0),
                        plan = plan,
                        recalibrated = recalibrated
                    )
                } catch (t: Throwable) {
                    SonusStorage.abort(context, outputUri)
                    throw t
                }
            } finally {
                activeVideoTransformer = null
                work.listFiles()?.forEach { runCatching { it.delete() } }
            }
        }
    }

    @OptIn(UnstableApi::class)
    private suspend fun renderCompressionMedia3(
        context: Context,
        inputUri: Uri,
        out: File,
        plan: VideoCompressionPlan,
        progressStart: Int,
        progressEnd: Int,
        onProgress: (Int) -> Unit
    ) {
        runCatching { out.delete() }
        val effects = mutableListOf<Effect>()
        effects += Presentation.createForWidthAndHeight(
            plan.targetWidth,
            plan.targetHeight,
            Presentation.LAYOUT_SCALE_TO_FIT
        )
        val edited = EditedMediaItem.Builder(MediaItem.fromUri(inputUri))
            .setFrameRate(plan.targetFps)
            .setEffects(Effects(emptyList(), effects))
            .build()

        suspendCancellableCoroutine<Unit> { cont ->
            val handler = Handler(Looper.getMainLooper())
            lateinit var transformer: Transformer
            val poll = object : Runnable {
                override fun run() {
                    if (!cont.isActive) return
                    runCatching {
                        val holder = ProgressHolder()
                        val state = transformer.getProgress(holder)
                        if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                            val mapped = progressStart + ((progressEnd - progressStart) * holder.progress.coerceIn(0, 100) / 100f).roundToInt()
                            onProgress(mapped.coerceIn(progressStart, progressEnd))
                        }
                    }
                    handler.postDelayed(this, 180L)
                }
            }
            val listener = object : Transformer.Listener {
                override fun onCompleted(composition: androidx.media3.transformer.Composition, result: ExportResult) {
                    handler.removeCallbacks(poll)
                    activeVideoTransformer = null
                    if (cont.isActive) cont.resume(Unit)
                }
                override fun onError(composition: androidx.media3.transformer.Composition, result: ExportResult, exception: ExportException) {
                    handler.removeCallbacks(poll)
                    activeVideoTransformer = null
                    if (cont.isActive) cont.resumeWith(Result.failure(exception))
                }
            }
            val encoderBuilder = DefaultEncoderFactory.Builder(context)
                .setEnableFallback(true)
                .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(plan.videoBitrate).build())
            if (plan.audioBitrate > 0) {
                encoderBuilder.setRequestedAudioEncoderSettings(AudioEncoderSettings.Builder().setBitrate(plan.audioBitrate).build())
            }
            transformer = Transformer.Builder(context)
                .setVideoMimeType(plan.videoMime)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .setEncoderFactory(encoderBuilder.build())
                .addListener(listener)
                .build()
            activeVideoTransformer = transformer
            cont.invokeOnCancellation {
                handler.removeCallbacks(poll)
                runCatching { transformer.cancel() }
                activeVideoTransformer = null
            }
            transformer.start(edited, out.absolutePath)
            handler.post(poll)
        }
        require(out.exists() && out.length() > 0L) { "A codificação de vídeo não produziu um arquivo válido." }
    }

    private fun targetCompressionFps(sourceFps: Int, preset: String): Int {
        val source = sourceFps.coerceIn(1, 240)
        val target = when {
            source <= 24 -> source
            source <= 30 -> when (preset) { "Leve" -> source; "Máxima compressão" -> 24; else -> 25 }
            source <= 60 -> when (preset) { "Leve" -> 45; "Máxima compressão" -> 24; else -> 30 }
            else -> when (preset) { "Leve" -> 60; "Máxima compressão" -> 30; else -> 45 }
        }
        return minOf(source, target).coerceAtLeast(1)
    }

    private fun minimumSafeVideoBitrate(width: Int, height: Int, mime: String): Int {
        val pixels = width.toLong() * height.toLong()
        val base = when {
            pixels <= 1280L * 720L -> 450_000
            pixels <= 1920L * 1080L -> 750_000
            pixels <= 2560L * 1440L -> 1_300_000
            else -> 2_500_000
        }
        return if (mime == MimeTypes.VIDEO_H265) (base * .72).roundToInt() else base
    }

    private fun hasEncoderFor(mime: String): Boolean = runCatching {
        MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.any { info ->
            info.isEncoder && info.supportedTypes.any { it.equals(mime, ignoreCase = true) }
        }
    }.getOrDefault(false)

    private fun queryUriSize(context: Context, uri: Uri): Long {
        val afdSize = runCatching { context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L }.getOrDefault(-1L)
        if (afdSize > 0L) return afdSize
        return runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getColumnIndex(OpenableColumns.SIZE).takeIf { it >= 0 }?.let { c.getLong(it) } ?: -1L else -1L
            } ?: -1L
        }.getOrDefault(-1L)
    }


    fun cutVideoSegmentsToSonus(
        context: Context,
        inputUri: Uri,
        sourceDisplayName: String,
        segments: List<VideoCutSegment>,
        onProgress: (Int) -> Unit = {}
    ): Result<List<Uri>> = runCatching {
        val ordered = segments.sortedBy { it.startMs }
        require(ordered.isNotEmpty()) { "Marque pelo menos um trecho." }
        ordered.forEachIndexed { index, segment ->
            require(segment.startMs >= 0L && segment.endMs > segment.startMs) { "Trecho ${index + 1} inválido." }
            if (index > 0) require(segment.startMs >= ordered[index - 1].endMs) { "Há trechos sobrepostos. Ajuste as marcações antes de exportar." }
        }
        withCachedInputs(context, listOf(inputUri), "video_multicut") { inputs, work ->
            val input = inputs.first()
            val sourceDuration = mediaDurationMs(input).coerceAtLeast(1L)
            ordered.forEachIndexed { index, seg -> require(seg.endMs <= sourceDuration + 50L) { "Trecho ${index + 1} ultrapassa o fim do vídeo." } }
            val outputs = mutableListOf<Uri>()
            val base = sourceDisplayName.substringBeforeLast('.').replace(Regex("[^A-Za-z0-9À-ÿ _.-]"), "").trim().ifBlank { "Video_SONUS" }
            try {
                ordered.forEachIndexed { index, seg ->
                    val out = File(work, "cut_${index}_${System.nanoTime()}.mp4")
                    val startSec = String.format(Locale.US, "%.3f", seg.startMs / 1000.0)
                    val durSec = String.format(Locale.US, "%.3f", seg.durationMs / 1000.0)
                    val p0 = 2 + ((index.toDouble() / ordered.size) * 94.0).toInt()
                    val p1 = 2 + (((index + 1).toDouble() / ordered.size) * 94.0).toInt()
                    try {
                        // Reencode deliberado: prioriza o ponto exato, não apenas keyframes do original.
                        val command = "-y -hide_banner -i ${q(input.absolutePath)} -ss $startSec -t $durSec -map 0:v:0 -map 0:a? -c:v mpeg4 -q:v 2 -pix_fmt yuv420p -c:a aac -b:a 192k -avoid_negative_ts make_zero -movflags +faststart ${q(out.absolutePath)}"
                        executeWithProgress(command, seg.durationMs.coerceAtLeast(1L), p0, p1.coerceAtMost(96), onProgress)
                        require(out.exists() && out.length() > 0L) { "O trecho ${index + 1} não gerou um vídeo válido." }
                        val name = "${base}_Trecho_${(index + 1).toString().padStart(2, '0')}.mp4"
                        val uri = SonusStorage.createVideo(context, name, "video/mp4", SonusStorage.Bucket.VISUALIZER)
                            ?: error("Não foi possível criar o arquivo do trecho ${index + 1}.")
                        try {
                            SonusStorage.openOutput(context, uri)?.use { target -> out.inputStream().use { it.copyTo(target) } }
                                ?: error("Não foi possível salvar o trecho ${index + 1}.")
                            SonusStorage.finish(context, uri)
                            outputs += uri
                        } catch (t: Throwable) {
                            SonusStorage.abort(context, uri)
                            throw t
                        }
                    } finally { runCatching { out.delete() } }
                }
                onProgress(100)
                outputs.toList()
            } catch (t: Throwable) {
                // Saídas já finalizadas são válidas; a operação não publica temporários parciais.
                throw t
            }
        }
    }

    fun cancelActiveVideoUtility() {
        cancelActiveMerge()
        Handler(Looper.getMainLooper()).post {
            runCatching { activeVideoTransformer?.cancel() }
            activeVideoTransformer = null
        }
    }

    /**
     * Pitch shift musical preservando aproximadamente a duração.
     * A cadeia asetrate + resample + atempo evita depender do filtro rubberband.
     */
    fun shiftPitch(
        context: Context,
        inputUri: Uri,
        outputUri: Uri,
        format: String,
        semitones: Int,
        cents: Int
    ): Result<Unit> = runCatching {
        val totalSemitones = (semitones.coerceIn(-12, 12) + cents.coerceIn(-100, 100) / 100.0).coerceIn(-12.0, 12.0)
        val factor = 2.0.pow(totalSemitones / 12.0)
        val tempo = 1.0 / factor
        withCachedInputs(context, listOf(inputUri), "pitch") { inputs, work ->
            val out = File(work, "pitch_${System.nanoTime()}.${extension(format)}")
            val filter = "aresample=48000,asetrate=${fmt(48000.0 * factor)},aresample=48000,atempo=${fmt(tempo)}"
            execute("-y -i ${q(inputs.first().absolutePath)} -vn -af ${q(filter)} ${codec(format)} ${q(out.absolutePath)}")
            copyOut(context, out, outputUri)
        }
    }

    fun buildPitchPreview(context: Context, inputUri: Uri, semitones: Int, cents: Int, seconds: Int = 22): Result<File> = runCatching {
        val totalSemitones = (semitones.coerceIn(-12, 12) + cents.coerceIn(-100, 100) / 100.0).coerceIn(-12.0, 12.0)
        val factor = 2.0.pow(totalSemitones / 12.0)
        val tempo = 1.0 / factor
        val work = File(context.cacheDir, "creator_preview").apply { mkdirs() }
        val input = cacheInput(context, inputUri, work, 0)
        val out = File(work, "pitch_preview_${System.nanoTime()}.m4a")
        try {
            val filter = "aresample=48000,asetrate=${fmt(48000.0 * factor)},aresample=48000,atempo=${fmt(tempo)}"
            execute("-y -i ${q(input.absolutePath)} -t ${seconds.coerceIn(8, 45)} -vn -af ${q(filter)} -c:a aac -b:a 192k ${q(out.absolutePath)}")
            out
        } finally {
            input.delete()
        }
    }

    fun separateCenter(
        context: Context,
        inputUri: Uri,
        outputUri: Uri,
        output: VocalOutput,
        format: String,
        denoise: DenoiseStrength,
        pulseLift: Boolean,
        separation: VocalSeparationStrength = VocalSeparationStrength.BALANCED
    ): Result<Unit> = runCatching {
        withCachedInputs(context, listOf(inputUri), "vocal") { inputs, work ->
            val out = File(work, "${output.name.lowercase()}_${System.nanoTime()}.${extension(format)}")
            val filters = mutableListOf<String>()
            when (output) {
                VocalOutput.INSTRUMENTAL -> {
                    // Preserva parte do grave central para evitar instrumental "magro".
                    val bassMix = when(separation) {
                        VocalSeparationStrength.NATURAL -> 0.78
                        VocalSeparationStrength.BALANCED -> 0.62
                        VocalSeparationStrength.STRONG -> 0.48
                    }
                    filters += "asplit=2[full][bass];[full]pan=stereo|c0=FL-FR|c1=FR-FL[side];[bass]lowpass=f=150,volume=$bassMix[b];[side][b]amix=inputs=2:normalize=0"
                    filters += when(separation) {
                        VocalSeparationStrength.NATURAL -> "equalizer=f=220:t=q:w=1.1:g=0.8"
                        VocalSeparationStrength.BALANCED -> "equalizer=f=3000:t=q:w=1.4:g=-0.8"
                        VocalSeparationStrength.STRONG -> "equalizer=f=2500:t=q:w=1.3:g=-1.8"
                    }
                }
                VocalOutput.VOCAL -> {
                    filters += "pan=mono|c0=0.5*FL+0.5*FR"
                    filters += "highpass=f=85"
                    filters += "lowpass=f=12500"
                    if (separation == VocalSeparationStrength.STRONG) filters += "equalizer=f=320:t=q:w=1.2:g=-1.2"
                }
            }
            when (denoise) {
                DenoiseStrength.OFF -> Unit
                DenoiseStrength.LIGHT -> filters += "afftdn=nf=-36"
                DenoiseStrength.MEDIUM -> filters += "afftdn=nf=-30"
                DenoiseStrength.STRONG -> filters += "afftdn=nf=-25"
            }
            if (pulseLift) {
                filters += "highpass=f=28"
                filters += "equalizer=f=72:t=q:w=1.0:g=2.8"
                filters += "equalizer=f=135:t=q:w=1.1:g=1.7"
                filters += "equalizer=f=245:t=q:w=1.2:g=-1.4"
                filters += "equalizer=f=3100:t=q:w=1.0:g=1.4"
                filters += "acompressor=threshold=-18dB:ratio=2.2:attack=12:release=170:makeup=1.4"
                filters += "alimiter=limit=0.89"
            }
            execute("-y -i ${q(inputs.first().absolutePath)} -vn -af ${q(filters.joinToString(","))} ${codec(format)} ${q(out.absolutePath)}")
            copyOut(context, out, outputUri)
        }
    }

    fun buildVocalPreview(
        context: Context,
        inputUri: Uri,
        output: VocalOutput,
        denoise: DenoiseStrength,
        pulseLift: Boolean,
        separation: VocalSeparationStrength = VocalSeparationStrength.BALANCED,
        seconds: Int = 0
    ): Result<File> = runCatching {
        val work = File(context.cacheDir, "creator_preview").apply { mkdirs() }
        val input = cacheInput(context, inputUri, work, 0)
        val out = File(work, "vocal_preview_${System.nanoTime()}.m4a")
        try {
            val filters = mutableListOf<String>()
            when (output) {
                VocalOutput.INSTRUMENTAL -> {
                    // Preserva parte do grave central para evitar instrumental "magro".
                    val bassMix = when(separation) {
                        VocalSeparationStrength.NATURAL -> 0.78
                        VocalSeparationStrength.BALANCED -> 0.62
                        VocalSeparationStrength.STRONG -> 0.48
                    }
                    filters += "asplit=2[full][bass];[full]pan=stereo|c0=FL-FR|c1=FR-FL[side];[bass]lowpass=f=150,volume=$bassMix[b];[side][b]amix=inputs=2:normalize=0"
                    filters += when(separation) {
                        VocalSeparationStrength.NATURAL -> "equalizer=f=220:t=q:w=1.1:g=0.8"
                        VocalSeparationStrength.BALANCED -> "equalizer=f=3000:t=q:w=1.4:g=-0.8"
                        VocalSeparationStrength.STRONG -> "equalizer=f=2500:t=q:w=1.3:g=-1.8"
                    }
                }
                VocalOutput.VOCAL -> {
                    filters += "pan=mono|c0=0.5*FL+0.5*FR"
                    filters += "highpass=f=85"
                    filters += "lowpass=f=12500"
                    if (separation == VocalSeparationStrength.STRONG) filters += "equalizer=f=320:t=q:w=1.2:g=-1.2"
                }
            }
            when (denoise) {
                DenoiseStrength.OFF -> Unit
                DenoiseStrength.LIGHT -> filters += "afftdn=nf=-36"
                DenoiseStrength.MEDIUM -> filters += "afftdn=nf=-30"
                DenoiseStrength.STRONG -> filters += "afftdn=nf=-25"
            }
            if (pulseLift) filters += listOf(
                "highpass=f=28", "equalizer=f=72:t=q:w=1:g=2.8", "equalizer=f=135:t=q:w=1.1:g=1.7",
                "equalizer=f=245:t=q:w=1.2:g=-1.4", "equalizer=f=3100:t=q:w=1:g=1.4",
                "acompressor=threshold=-18dB:ratio=2.2:attack=12:release=170:makeup=1.4", "alimiter=limit=0.89"
            )
            val durationArg = if (seconds > 0) "-t ${seconds.coerceIn(8, 300)} " else ""
            execute("-y -i ${q(input.absolutePath)} $durationArg-vn -af ${q(filters.joinToString(","))} -c:a aac -b:a 192k ${q(out.absolutePath)}")
            out
        } finally { input.delete() }
    }

    private fun requireAudioTrack(context: Context, uri: Uri) {
        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(context, uri, null)
            val hasAudio = (0 until extractor.trackCount).any { index ->
                extractor.getTrackFormat(index).getString(android.media.MediaFormat.KEY_MIME)?.startsWith("audio/") == true
            }
            require(hasAudio) { "Este vídeo não possui uma faixa de áudio compatível." }
        } catch (t: Throwable) {
            if (t is IllegalArgumentException && t.message?.contains("faixa de áudio") == true) throw t
            throw IllegalStateException("Não foi possível ler o áudio deste vídeo. Tente outro arquivo ou formato de vídeo.", t)
        } finally {
            runCatching { extractor.release() }
        }
    }

    private fun codec(format: String): String = when (format.uppercase(Locale.US)) {
        "MP3" -> "-c:a libmp3lame -b:a 256k"
        "WAV" -> "-c:a pcm_s24le"
        "FLAC" -> "-c:a flac -compression_level 8"
        "M4A" -> "-c:a aac -b:a 256k"
        "AAC" -> "-c:a aac -b:a 256k"
        "OGG" -> "-c:a libvorbis -q:a 6"
        "OPUS" -> "-c:a libopus -b:a 192k"
        "AIFF" -> "-c:a pcm_s24be"
        else -> "-c:a aac -b:a 256k"
    }

    private inline fun <T> withCachedInputs(
        context: Context,
        uris: List<Uri>,
        prefix: String,
        block: (List<File>, File) -> T
    ): T {
        val work = File(context.cacheDir, "creator_tools/$prefix").apply { mkdirs() }
        val cached = mutableListOf<File>()
        try {
            uris.forEachIndexed { i, uri ->
                val name = displayName(context, uri)
                val file = try { cacheInput(context, uri, work, i) }
                catch (t: Throwable) {
                    error("Não foi possível ler o arquivo ${i + 1} (${name.take(60)}). Selecione esse arquivo novamente.")
                }
                require(file.exists() && file.length() > 0L) { "O arquivo ${i + 1} (${name.take(60)}) está vazio ou inacessível." }
                cached += file
            }
            return block(cached, work)
        } finally { cached.forEach { runCatching { it.delete() } } }
    }

    private fun cacheInput(context: Context, uri: Uri, work: File, index: Int): File {
        val name = displayName(context, uri)
        val ext = name.substringAfterLast('.', "src").take(8).ifBlank { "src" }
        val file = File(work, "in_${index}_${System.nanoTime()}.$ext")
        context.contentResolver.openInputStream(uri)?.use { input -> file.outputStream().use { input.copyTo(it) } }
            ?: error("Não foi possível abrir ${name.take(80)}")
        return file
    }

    private fun copyOut(context: Context, file: File, uri: Uri) {
        require(file.exists() && file.length() > 0) { "O processamento não gerou um arquivo válido." }
        SonusStorage.openOutput(context, uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
            ?: error("Não foi possível salvar o arquivo de saída.")
        SonusStorage.finish(context, uri)
        file.delete()
    }

    private fun execute(command: String) {
        val session = FFmpegKit.execute(command)
        if (!ReturnCode.isSuccess(session.returnCode)) {
            val logs = session.allLogsAsString.orEmpty()
            val friendly = when {
                logs.contains("matches no streams", ignoreCase = true) || logs.contains("does not contain any stream", ignoreCase = true) ->
                    "Este vídeo não possui uma faixa de áudio compatível."
                logs.contains("Unknown encoder", ignoreCase = true) ->
                    "Este formato de áudio não está disponível neste aparelho."
                logs.contains("Permission denied", ignoreCase = true) ->
                    "O Android não permitiu acessar um dos arquivos selecionados."
                else -> logs.takeLast(1200).ifBlank { "O processamento FFmpeg não foi concluído." }
            }
            error(friendly)
        }
    }


    private fun ffmpegFriendlyFailure(logs: String): String {
        val lines = logs.lineSequence().map { it.trim() }.filter { it.isNotBlank() }.toList()
        val keywords = listOf("error", "invalid", "failed", "unable", "unknown", "not supported", "no such", "permission denied", "could not", "conversion failed")
        val relevant = lines.asReversed().firstOrNull { line -> keywords.any { key -> line.contains(key, ignoreCase = true) } }
        return when {
            logs.contains("cancel", ignoreCase = true) -> "Processamento cancelado."
            logs.contains("Unknown encoder", ignoreCase = true) -> "O codec necessário não está disponível neste aparelho."
            logs.contains("Permission denied", ignoreCase = true) -> "O Android não permitiu acessar um dos arquivos selecionados."
            logs.contains("No such file", ignoreCase = true) -> "Um dos arquivos selecionados não está mais disponível."
            relevant != null -> relevant.take(420)
            else -> lines.takeLast(3).joinToString(" · ").take(420).ifBlank { "O processamento FFmpeg não foi concluído." }
        }
    }

    private suspend fun executeWithArgumentsProgress(
        arguments: List<String>,
        durationMs: Long,
        progressStart: Int,
        progressEnd: Int,
        onProgress: (Int) -> Unit
    ) = suspendCancellableCoroutine<Unit> { continuation ->
        val session = FFmpegKit.executeWithArgumentsAsync(arguments.toTypedArray(), { completed ->
            val logs = completed.allLogsAsString.orEmpty()
            activeMergeSessionId = null
            if (continuation.isActive) {
                if (ReturnCode.isSuccess(completed.returnCode)) continuation.resume(Unit)
                else continuation.resumeWithException(IllegalStateException(ffmpegFriendlyFailure(logs)))
            }
        }, null, { statistics ->
            val ratio = (statistics.time.toDouble() / durationMs.coerceAtLeast(1L).toDouble()).coerceIn(0.0, 1.0)
            val mapped = progressStart + ((progressEnd - progressStart) * ratio).toInt()
            onProgress(mapped)
        })
        activeMergeSessionId = session.sessionId
        continuation.invokeOnCancellation {
            runCatching { FFmpegKit.cancel(session.sessionId) }
            if (activeMergeSessionId == session.sessionId) activeMergeSessionId = null
        }
    }

    private fun executeWithProgress(
        command: String,
        durationMs: Long,
        progressStart: Int,
        progressEnd: Int,
        onProgress: (Int) -> Unit
    ) {
        val latch = CountDownLatch(1)
        var success = false
        var logs = ""
        val session = FFmpegKit.executeAsync(command, { completed ->
            success = ReturnCode.isSuccess(completed.returnCode)
            logs = completed.allLogsAsString.orEmpty()
            activeMergeSessionId = null
            latch.countDown()
        }, null, { statistics ->
            val ratio = (statistics.time.toDouble() / durationMs.coerceAtLeast(1L).toDouble()).coerceIn(0.0, 1.0)
            val mapped = progressStart + ((progressEnd - progressStart) * ratio).toInt()
            onProgress(mapped)
        })
        activeMergeSessionId = session.sessionId
        latch.await()
        if (!success) error(ffmpegFriendlyFailure(logs))
    }

    private fun mediaDurationMs(file: File): Long {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(file.absolutePath)
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } finally { runCatching { retriever.release() } }
    }

    private fun videoDisplaySize(file: File): Pair<Int, Int> {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(file.absolutePath)
            var w = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 1280
            var h = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 720
            val rotation = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rotation == 90 || rotation == 270) { val tmp = w; w = h; h = tmp }
            makeEven(w.coerceAtLeast(2)) to makeEven(h.coerceAtLeast(2))
        } finally { runCatching { retriever.release() } }
    }

    private fun hasAudioTrack(file: File): Boolean {
        val extractor = MediaExtractor()
        return try {
            extractor.setDataSource(file.absolutePath)
            (0 until extractor.trackCount).any { index ->
                extractor.getTrackFormat(index).getString(android.media.MediaFormat.KEY_MIME)?.startsWith("audio/") == true
            }
        } catch (_: Throwable) { false } finally { runCatching { extractor.release() } }
    }

    private fun makeEven(value: Int): Int = if (value % 2 == 0) value else value - 1
    private fun q(value: String): String = "'${value.replace("'", "'\\''")}'"
    private fun fmt(value: Double): String = String.format(Locale.US, "%.6f", value)
}

enum class MergeTransition { DIRECT, CROSSFADE, SILENCE }
enum class VocalOutput { INSTRUMENTAL, VOCAL }
enum class DenoiseStrength { OFF, LIGHT, MEDIUM, STRONG }
enum class VocalSeparationStrength { NATURAL, BALANCED, STRONG }
