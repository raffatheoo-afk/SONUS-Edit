package com.sonusstudios.streampulse.tools

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.AudioRecordingConfiguration
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import com.sonusstudios.streampulse.MainActivity
import com.sonusstudios.streampulse.R
import java.io.File
import java.io.FileOutputStream
import java.security.KeyStore
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import javax.crypto.KeyGenerator
import javax.crypto.Mac
import javax.crypto.SecretKey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.roundToInt

internal data class SonusBlackBoxGap(val startMs: Long, val endMs: Long? = null)

internal data class SonusBlackBoxSnapshot(
    val recording: Boolean = false,
    val paused: Boolean = false,
    val microphoneBusy: Boolean = false,
    val startedAtMs: Long = 0L,
    val retainedFromMs: Long = 0L,
    val retentionHours: Int = 1,
    val bitrateKbps: Int = 96,
    val storageBytes: Long = 0L,
    val encodedSegments: Int = 0,
    val status: String = "Parada",
    val gaps: List<SonusBlackBoxGap> = emptyList(),
    val error: String? = null
)

internal object SonusBlackBoxBus {
    private val _state = MutableStateFlow(SonusBlackBoxSnapshot())
    val state: StateFlow<SonusBlackBoxSnapshot> = _state.asStateFlow()
    internal fun publish(snapshot: SonusBlackBoxSnapshot) { _state.value = snapshot }
}

internal class SonusBlackBoxPreferences(private val context: Context) {
    private val prefs = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    var retentionHours: Int
        get() = prefs.getInt(KEY_RETENTION, 1).coerceIn(1, 24)
        set(value) { prefs.edit().putInt(KEY_RETENTION, value.coerceIn(1, 24)).apply() }

    var bitrateKbps: Int
        get() = prefs.getInt(KEY_BITRATE, 96).coerceIn(24, 320)
        set(value) { prefs.edit().putInt(KEY_BITRATE, value.coerceIn(24, 320)).apply() }

    var pinLength: Int
        get() = prefs.getInt(KEY_PIN_LENGTH, 3).let { if (it == 4) 4 else 3 }
        set(value) { prefs.edit().putInt(KEY_PIN_LENGTH, if (value == 4) 4 else 3).apply() }


    var active: Boolean
        get() = prefs.getBoolean(KEY_ACTIVE, false)
        set(value) { prefs.edit().putBoolean(KEY_ACTIVE, value).apply() }

    @Synchronized
    fun nextSavedCounter(): Int {
        val next = prefs.getInt(KEY_COUNTER, 0).coerceAtLeast(0) + 1
        prefs.edit().putInt(KEY_COUNTER, next).commit()
        return next
    }

    companion object {
        const val FILE = "sonus_blackbox_settings_v1"
        private const val KEY_RETENTION = "retention_hours"
        private const val KEY_BITRATE = "bitrate_kbps"
        private const val KEY_PIN_LENGTH = "pin_length"
        private const val KEY_ACTIVE = "active"
        private const val KEY_COUNTER = "saved_counter"
    }
}

internal class SonusBlackBoxPinStore(private val context: Context) {
    private val prefs = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun isConfigured(): Boolean = prefs.contains(KEY_DIGEST)
    fun pinLength(): Int = prefs.getInt(KEY_LENGTH, 3).let { if (it == 4) 4 else 3 }
    fun lockoutRemainingMs(): Long = (prefs.getLong(KEY_LOCKOUT, 0L) - System.currentTimeMillis()).coerceAtLeast(0L)

    fun setPin(pin: String, length: Int): Boolean {
        val expected = if (length == 4) 4 else 3
        if (pin.length != expected || pin.any { !it.isDigit() }) return false
        val digest = runCatching { hmac(pin) }.getOrNull() ?: return false
        prefs.edit()
            .putString(KEY_DIGEST, Base64.encodeToString(digest, Base64.NO_WRAP))
            .putInt(KEY_LENGTH, expected)
            .putInt(KEY_FAILURES, 0)
            .putLong(KEY_LOCKOUT, 0L)
            .apply()
        return true
    }

    fun verify(pin: String): Boolean {
        if (lockoutRemainingMs() > 0L) return false
        val expected = prefs.getString(KEY_DIGEST, null) ?: return false
        val actual = runCatching { Base64.encodeToString(hmac(pin), Base64.NO_WRAP) }.getOrNull() ?: return false
        val ok = constantTimeEquals(expected, actual)
        if (ok) {
            prefs.edit().putInt(KEY_FAILURES, 0).putLong(KEY_LOCKOUT, 0L).apply()
        } else {
            val failures = prefs.getInt(KEY_FAILURES, 0) + 1
            val lockout = if (failures >= 5) System.currentTimeMillis() + 30_000L else 0L
            prefs.edit().putInt(KEY_FAILURES, if (failures >= 5) 0 else failures).putLong(KEY_LOCKOUT, lockout).apply()
        }
        return ok
    }

    private fun hmac(pin: String): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(key())
        return mac.doFinal(pin.toByteArray(Charsets.UTF_8))
    }

    private fun key(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_HMAC_SHA256, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_SIGN or KeyProperties.PURPOSE_VERIFY)
                .setDigests(KeyProperties.DIGEST_SHA256)
                .build()
        )
        return generator.generateKey()
    }

    private fun constantTimeEquals(a: String, b: String): Boolean {
        val aa = a.toByteArray(Charsets.UTF_8)
        val bb = b.toByteArray(Charsets.UTF_8)
        if (aa.size != bb.size) return false
        var diff = 0
        aa.indices.forEach { diff = diff or (aa[it].toInt() xor bb[it].toInt()) }
        return diff == 0
    }

    companion object {
        const val FILE = "sonus_blackbox_secret_v1"
        private const val KEY_ALIAS = "sonus_blackbox_pin_hmac_v1"
        private const val KEY_DIGEST = "pin_digest"
        private const val KEY_LENGTH = "pin_length"
        private const val KEY_FAILURES = "failed_attempts"
        private const val KEY_LOCKOUT = "lockout_until"
    }
}

internal data class SonusBlackBoxSegment(val file: File, val startMs: Long, val endMs: Long)

internal object SonusBlackBoxStorage {
    private fun root(context: Context) = File(context.noBackupFilesDir, "sonus_blackbox").apply { mkdirs() }
    fun bufferDir(context: Context) = File(root(context), "buffer").apply { mkdirs() }
    fun savedDir(context: Context) = File(root(context), "saved").apply { mkdirs() }
    fun tempDir(context: Context) = File(root(context), "temp").apply { mkdirs() }

    fun listSegments(context: Context): List<SonusBlackBoxSegment> = bufferDir(context).listFiles()
        .orEmpty()
        .mapNotNull { file ->
            val parts = file.nameWithoutExtension.split('_')
            if (parts.size != 3 || parts[0] != "bb") return@mapNotNull null
            val start = parts[1].toLongOrNull() ?: return@mapNotNull null
            val end = parts[2].toLongOrNull() ?: return@mapNotNull null
            SonusBlackBoxSegment(file, start, end)
        }
        .sortedBy { it.startMs }

    fun listSaved(context: Context): List<File> = savedDir(context).listFiles().orEmpty().filter { it.extension.equals("mp3", true) }.sortedByDescending { it.lastModified() }

    fun bufferBytes(context: Context): Long = listSegments(context).sumOf { it.file.length() }

    fun clearBuffer(context: Context) {
        bufferDir(context).listFiles().orEmpty().forEach { runCatching { it.delete() } }
        tempDir(context).listFiles().orEmpty().forEach { runCatching { it.delete() } }
    }

    fun prune(context: Context, retentionHours: Int) {
        val cutoff = System.currentTimeMillis() - retentionHours.coerceIn(1, 24) * 60L * 60L * 1000L
        listSegments(context).filter { it.endMs < cutoff }.forEach { runCatching { it.file.delete() } }
    }

    fun renameSaved(file: File, newBaseName: String): File? {
        val safe = newBaseName.trim().replace(Regex("[^A-Za-zÀ-ÿ0-9._ -]"), "_").take(80).trim().ifBlank { return null }
        val target = File(file.parentFile, if (safe.endsWith(".mp3", true)) safe else "$safe.mp3")
        if (target.exists()) return null
        return if (file.renameTo(target)) target else null
    }

    fun saveExcerpt(context: Context, startMs: Long, endMs: Long): File? {
        if (endMs <= startMs) return null
        val segments = listSegments(context).filter { it.endMs > startMs && it.startMs < endMs }
        if (segments.isEmpty()) return null
        val tmpDir = tempDir(context)
        val listFile = File(tmpDir, "concat_${System.nanoTime()}.txt")
        val joined = File(tmpDir, "joined_${System.nanoTime()}.mp3")
        listFile.writeText(segments.joinToString("\n") { "file '${it.file.absolutePath.replace("'", "'\\''")}'" })
        val concat = FFmpegKit.execute("-y -hide_banner -f concat -safe 0 -i '${listFile.absolutePath.replace("'", "'\\''")}' -c copy '${joined.absolutePath.replace("'", "'\\''")}'")
        listFile.delete()
        if (!ReturnCode.isSuccess(concat.returnCode) || !joined.exists()) {
            joined.delete(); return null
        }
        val firstStart = segments.first().startMs
        val offsetSec = ((startMs - firstStart).coerceAtLeast(0L) / 1000.0)
        val durationSec = ((endMs - startMs).coerceAtLeast(1L) / 1000.0)
        val prefs = SonusBlackBoxPreferences(context)
        val counter = prefs.nextSavedCounter()
        val zone = ZoneId.systemDefault()
        val start = Instant.ofEpochMilli(startMs).atZone(zone)
        val end = Instant.ofEpochMilli(endMs).atZone(zone)
        val timeFmt = DateTimeFormatter.ofPattern("HH-mm")
        val dateFmt = DateTimeFormatter.ofPattern("dd-MM-yyyy")
        val fileName = "SONUS_CaixaPreta_arq${counter.toString().padStart(3, '0')}_${start.format(timeFmt)}_a_${end.format(timeFmt)}_${start.format(dateFmt)}.mp3"
        val out = File(savedDir(context), fileName)
        val bitrate = prefs.bitrateKbps.coerceIn(24, 320)
        val command = "-y -hide_banner -ss $offsetSec -t $durationSec -i '${joined.absolutePath.replace("'", "'\\''")}' -vn -c:a libmp3lame -b:a ${bitrate}k '${out.absolutePath.replace("'", "'\\''")}'"
        var cut = FFmpegKit.execute(command)
        if (!ReturnCode.isSuccess(cut.returnCode)) {
            cut = FFmpegKit.execute("-y -hide_banner -ss $offsetSec -t $durationSec -i '${joined.absolutePath.replace("'", "'\\''")}' -vn -c:a mp3 -b:a ${bitrate}k '${out.absolutePath.replace("'", "'\\''")}'")
        }
        joined.delete()
        return out.takeIf { ReturnCode.isSuccess(cut.returnCode) && it.exists() && it.length() > 0L }
    }
}

class SonusBlackBoxService : Service() {
    private val running = AtomicBoolean(false)
    private val userPaused = AtomicBoolean(false)
    private val systemSilenced = AtomicBoolean(false)
    private var audioRecord: AudioRecord? = null
    private var worker: Thread? = null
    private val encoder = Executors.newSingleThreadExecutor()
    private var wakeLock: PowerManager.WakeLock? = null
    private lateinit var prefs: SonusBlackBoxPreferences
    private lateinit var audioManager: AudioManager
    private var gapStartedAt: Long? = null
    private val gaps = mutableListOf<SonusBlackBoxGap>()
    private var encodedSegments = 0
    private var sessionStartedAt = 0L
    private var currentSessionId = -1

    private val recordingCallback = object : AudioManager.AudioRecordingCallback() {
        override fun onRecordingConfigChanged(configs: MutableList<AudioRecordingConfiguration>) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return
            val mine = configs.firstOrNull { it.clientAudioSessionId == currentSessionId }
            systemSilenced.set(mine?.isClientSilenced == true)
        }
    }

    override fun onCreate() {
        super.onCreate()
        prefs = SonusBlackBoxPreferences(this)
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        createChannel()
        runCatching { audioManager.registerAudioRecordingCallback(recordingCallback, Handler(Looper.getMainLooper())) }
        if (prefs.active) startForeground(NOTIFICATION_ID, notification("Retomando Caixa Preta…"))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startCapture()
            ACTION_PAUSE -> pauseCapture()
            ACTION_RESUME -> resumeCapture()
            ACTION_STOP -> stopCapture()
            null -> if (prefs.active) startCapture()
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        runCatching { audioManager.unregisterAudioRecordingCallback(recordingCallback) }
        if (running.get()) stopCapture()
        runCatching { encoder.shutdownNow() }
        super.onDestroy()
    }

    @SuppressLint("MissingPermission")
    private fun startCapture() {
        if (running.get()) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            prefs.active = false
            SonusBlackBoxBus.publish(SonusBlackBoxSnapshot(error = "Permissão de microfone não concedida."))
            stopSelf(); return
        }
        SonusBlackBoxStorage.clearBuffer(this)
        gaps.clear(); encodedSegments = 0
        sessionStartedAt = System.currentTimeMillis()
        prefs.active = true
        running.set(true); userPaused.set(false); systemSilenced.set(false)
        val power = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SONUS:CaixaPreta").apply {
            setReferenceCounted(false)
            acquire(25L * 60L * 60L * 1000L)
        }
        startForeground(NOTIFICATION_ID, notification("Iniciando • MP3 ${prefs.bitrateKbps} kbps"))
        worker = Thread { captureLoop() }.apply { name = "SONUSBlackBox"; start() }
    }

    private fun pauseCapture() {
        if (!running.get()) return
        userPaused.set(true)
        publishState("Pausada", paused = true)
        updateNotification("Pausada")
    }

    private fun resumeCapture() {
        if (!running.get()) return
        userPaused.set(false)
        publishState("Retomando…", paused = false)
    }

    private fun stopCapture() {
        if (!running.getAndSet(false)) {
            prefs.active = false
            stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return
        }
        userPaused.set(false)
        runCatching { audioRecord?.stop() }
        runCatching { worker?.join(2500) }
        releaseRecorder()
        runCatching { encoder.shutdown(); encoder.awaitTermination(20, TimeUnit.SECONDS) }
        runCatching { wakeLock?.takeIf { it.isHeld }?.release() }; wakeLock = null
        prefs.active = false
        publishState("Parada", paused = false, recording = false)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    @SuppressLint("MissingPermission")
    private fun createRecorder(): AudioRecord? = runCatching {
        val min = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        AudioRecord.Builder()
            .setAudioSource(MediaRecorder.AudioSource.MIC)
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(SAMPLE_RATE).setChannelMask(AudioFormat.CHANNEL_IN_MONO).build())
            .setBufferSizeInBytes(max(min * 2, 16_384))
            .build()
            .takeIf { it.state == AudioRecord.STATE_INITIALIZED }
    }.getOrNull()

    private fun ensureRecorder(): AudioRecord? {
        val current = audioRecord
        if (current != null && current.recordingState == AudioRecord.RECORDSTATE_RECORDING) return current
        releaseRecorder()
        val created = createRecorder() ?: return null
        val start = runCatching { created.startRecording() }.exceptionOrNull()
        if (start != null || created.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
            runCatching { created.release() }; return null
        }
        currentSessionId = created.audioSessionId
        audioRecord = created
        return created
    }

    private fun releaseRecorder() {
        val r = audioRecord
        audioRecord = null
        currentSessionId = -1
        runCatching { if (r?.recordingState == AudioRecord.RECORDSTATE_RECORDING) r.stop() }
        runCatching { r?.release() }
    }

    private fun captureLoop() {
        var raw: File? = null
        var output: FileOutputStream? = null
        var segmentStartMs = 0L
        var bytesInSegment = 0L
        val targetBytes = SAMPLE_RATE.toLong() * 2L * SEGMENT_SECONDS
        val buffer = ByteArray(16_384)

        fun closeAndEncode(endMs: Long) {
            val file = raw
            runCatching { output?.flush() }; runCatching { output?.close() }
            output = null; raw = null
            val startMs = segmentStartMs
            val bytes = bytesInSegment
            bytesInSegment = 0L
            if (file != null && bytes > SAMPLE_RATE) encodeRawSegment(file, startMs, endMs) else runCatching { file?.delete() }
        }

        try {
            while (running.get()) {
                if (userPaused.get()) {
                    if (output != null) closeAndEncode(System.currentTimeMillis())
                    releaseRecorder()
                    closeGapIfNeeded()
                    publishState("Pausada", paused = true)
                    Thread.sleep(350)
                    continue
                }

                val recorder = ensureRecorder()
                if (recorder == null) {
                    if (output != null) closeAndEncode(System.currentTimeMillis())
                    openGapIfNeeded()
                    publishState("Microfone ocupado • aguardando", microphoneBusy = true)
                    updateNotification("Microfone ocupado • aguardando")
                    Thread.sleep(900)
                    continue
                }

                if (systemSilenced.get()) {
                    if (output != null) closeAndEncode(System.currentTimeMillis())
                    openGapIfNeeded()
                    publishState("Microfone em uso por outro app", microphoneBusy = true)
                    Thread.sleep(350)
                    continue
                }

                closeGapIfNeeded()
                if (output == null) {
                    segmentStartMs = System.currentTimeMillis()
                    raw = File(SonusBlackBoxStorage.tempDir(this), "capture_${segmentStartMs}_${System.nanoTime()}.pcm")
                    output = FileOutputStream(raw!!)
                    bytesInSegment = 0L
                }

                val read = recorder.read(buffer, 0, buffer.size, AudioRecord.READ_BLOCKING)
                if (read > 0) {
                    output?.write(buffer, 0, read)
                    bytesInSegment += read
                    if (bytesInSegment >= targetBytes) closeAndEncode(System.currentTimeMillis())
                    publishState("Gravando", microphoneBusy = false)
                } else if (read == AudioRecord.ERROR_DEAD_OBJECT || read == AudioRecord.ERROR_INVALID_OPERATION || read == AudioRecord.ERROR_BAD_VALUE) {
                    if (output != null) closeAndEncode(System.currentTimeMillis())
                    releaseRecorder(); openGapIfNeeded()
                    publishState("Microfone interrompido • retomando", microphoneBusy = true)
                    Thread.sleep(700)
                }
            }
        } catch (t: Throwable) {
            SonusBlackBoxBus.publish(SonusBlackBoxBus.state.value.copy(error = t.message ?: "A Caixa Preta foi interrompida."))
        } finally {
            if (output != null) closeAndEncode(System.currentTimeMillis())
            releaseRecorder()
            closeGapIfNeeded()
        }
    }

    private fun encodeRawSegment(raw: File, startMs: Long, endMs: Long) {
        val bitrate = prefs.bitrateKbps.coerceIn(24, 320)
        encoder.submit {
            val out = File(SonusBlackBoxStorage.bufferDir(this), "bb_${startMs}_${endMs}.mp3")
            val input = raw.absolutePath.replace("'", "'\\''")
            val output = out.absolutePath.replace("'", "'\\''")
            var session = FFmpegKit.execute("-y -hide_banner -f s16le -ar $SAMPLE_RATE -ac 1 -i '$input' -vn -c:a libmp3lame -b:a ${bitrate}k '$output'")
            if (!ReturnCode.isSuccess(session.returnCode)) {
                session = FFmpegKit.execute("-y -hide_banner -f s16le -ar $SAMPLE_RATE -ac 1 -i '$input' -vn -c:a mp3 -b:a ${bitrate}k '$output'")
            }
            raw.delete()
            if (ReturnCode.isSuccess(session.returnCode) && out.exists() && out.length() > 0L) {
                encodedSegments += 1
                SonusBlackBoxStorage.prune(this, prefs.retentionHours)
            } else {
                out.delete()
            }
            publishState(if (userPaused.get()) "Pausada" else "Gravando", paused = userPaused.get(), microphoneBusy = systemSilenced.get())
        }
    }

    @Synchronized
    private fun openGapIfNeeded() {
        if (gapStartedAt == null) gapStartedAt = System.currentTimeMillis()
    }

    @Synchronized
    private fun closeGapIfNeeded() {
        val start = gapStartedAt ?: return
        val end = System.currentTimeMillis()
        if (end - start > 300L) {
            gaps += SonusBlackBoxGap(start, end)
            while (gaps.size > 60) gaps.removeAt(0)
        }
        gapStartedAt = null
    }

    private fun publishState(
        status: String,
        paused: Boolean = userPaused.get(),
        microphoneBusy: Boolean = systemSilenced.get(),
        recording: Boolean = running.get()
    ) {
        val segments = SonusBlackBoxStorage.listSegments(this)
        val liveGap = gapStartedAt?.let { SonusBlackBoxGap(it, null) }
        SonusBlackBoxBus.publish(
            SonusBlackBoxSnapshot(
                recording = recording,
                paused = paused,
                microphoneBusy = microphoneBusy,
                startedAtMs = sessionStartedAt,
                retainedFromMs = segments.firstOrNull()?.startMs ?: sessionStartedAt,
                retentionHours = prefs.retentionHours,
                bitrateKbps = prefs.bitrateKbps,
                storageBytes = segments.sumOf { it.file.length() },
                encodedSegments = encodedSegments,
                status = status,
                gaps = (gaps + listOfNotNull(liveGap)).toList(),
                error = null
            )
        )
        if (recording) updateNotification(if (paused) "Pausada" else "$status • MP3 ${prefs.bitrateKbps} kbps")
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Caixa Preta SONUS", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Mantém a Caixa Preta ativa em segundo plano."
                setSound(null, null)
            }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun notification(text: String): Notification {
        val open = Intent(this, MainActivity::class.java).putExtra("sonus_notification_route", "BLACK_BOX")
        val pi = PendingIntent.getActivity(this, 801, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_sonus_notification)
            .setContentTitle("Caixa Preta SONUS ativa")
            .setContentText(text)
            .setOngoing(true)
            .setSilent(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(pi)
            .build()
    }

    private fun updateNotification(text: String) {
        if (!running.get()) return
        runCatching { (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIFICATION_ID, notification(text)) }
    }

    companion object {
        const val ACTION_START = "sonus.blackbox.START"
        const val ACTION_PAUSE = "sonus.blackbox.PAUSE"
        const val ACTION_RESUME = "sonus.blackbox.RESUME"
        const val ACTION_STOP = "sonus.blackbox.STOP"
        private const val CHANNEL_ID = "sonus_blackbox"
        private const val NOTIFICATION_ID = 7980
        private const val SAMPLE_RATE = 44_100
        private const val SEGMENT_SECONDS = 60L

        fun start(context: Context) = ContextCompat.startForegroundService(context, Intent(context, SonusBlackBoxService::class.java).setAction(ACTION_START))
        fun pause(context: Context) = context.startService(Intent(context, SonusBlackBoxService::class.java).setAction(ACTION_PAUSE))
        fun resume(context: Context) = context.startService(Intent(context, SonusBlackBoxService::class.java).setAction(ACTION_RESUME))
        fun stop(context: Context) = context.startService(Intent(context, SonusBlackBoxService::class.java).setAction(ACTION_STOP))
    }
}

@Composable
internal fun SonusBlackBoxScreen(
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val prefs = remember { SonusBlackBoxPreferences(context) }
    val pinStore = remember { SonusBlackBoxPinStore(context) }
    val snapshot by SonusBlackBoxBus.state.collectAsState()
    val scope = rememberCoroutineScope()
    var unlocked by remember { mutableStateOf(false) }
    var tick by remember { mutableIntStateOf(0) }
    var message by remember { mutableStateOf<String?>(null) }
    var pinInput by remember { mutableStateOf("") }
    var pinConfirm by remember { mutableStateOf("") }
    var setupLength by remember { mutableIntStateOf(prefs.pinLength) }
    var failedMessage by remember { mutableStateOf<String?>(null) }
    var retention by remember { mutableIntStateOf(prefs.retentionHours) }
    var bitrate by remember { mutableIntStateOf(prefs.bitrateKbps) }
    var timelineMs by remember { mutableFloatStateOf(0f) }
    var rangeStartMs by remember { mutableFloatStateOf(0f) }
    var rangeEndMs by remember { mutableFloatStateOf(0f) }
    var followLive by remember { mutableStateOf(true) }
    var confirmAction by remember { mutableStateOf<String?>(null) }
    var confirmActionPin by remember { mutableStateOf("") }
    var showChangePin by remember { mutableStateOf(false) }
    var oldPin by remember { mutableStateOf("") }
    var newPin by remember { mutableStateOf("") }
    var newPinConfirm by remember { mutableStateOf("") }
    var renameFile by remember { mutableStateOf<File?>(null) }
    var renameText by remember { mutableStateOf("") }

    val player = remember { ExoPlayer.Builder(context).build() }
    DisposableEffect(player) { onDispose { player.release() } }

    LaunchedEffect(Unit) {
        while (true) { tick++; delay(1000) }
    }

    val segments = remember(tick, snapshot.encodedSegments, snapshot.storageBytes) { SonusBlackBoxStorage.listSegments(context) }
    val savedFiles = remember(tick, message) { SonusBlackBoxStorage.listSaved(context) }
    val startMs = segments.firstOrNull()?.startMs ?: snapshot.startedAtMs.takeIf { it > 0 } ?: System.currentTimeMillis()
    val endMs = System.currentTimeMillis()
    val availableMs = (endMs - startMs).coerceAtLeast(1L).toFloat()
    LaunchedEffect(availableMs, followLive) {
        if (followLive) {
            timelineMs = availableMs
            rangeEndMs = availableMs
            rangeStartMs = (availableMs - 5 * 60_000f).coerceAtLeast(0f)
        }
    }

    fun verifyForAction(pin: String): Boolean {
        if (pinStore.lockoutRemainingMs() > 0L) {
            message = "Muitas tentativas. Aguarde alguns segundos."
            return false
        }
        val ok = pinStore.verify(pin)
        if (!ok) message = "PIN incorreto."
        return ok
    }

    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) SonusBlackBoxService.start(context) else message = "A Caixa Preta precisa da permissão de microfone para iniciar."
    }

    if (!pinStore.isConfigured()) {
        Box(Modifier.fillMaxSize().padding(18.dp)) {
            Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Surface(shape = CircleShape, color = Color(0xFF111318), border = BorderStroke(1.dp, Color.White.copy(alpha=.10f))) {
                    Icon(Icons.Default.Security, null, tint = Color(0xFFD8E1FF), modifier = Modifier.padding(16.dp).size(32.dp))
                }
                Text("Criar PIN da Caixa Preta", fontSize = 22.sp, fontWeight = FontWeight.Black)
                Text("O PIN protege o acesso, o encerramento e os trechos salvos. Ele fica somente neste dispositivo.", style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = setupLength == 3, onClick = { setupLength = 3; pinInput=""; pinConfirm="" }, label = { Text("3 dígitos") })
                    FilterChip(selected = setupLength == 4, onClick = { setupLength = 4; pinInput=""; pinConfirm="" }, label = { Text("4 dígitos") })
                }
                OutlinedTextField(pinInput, { if (it.length <= setupLength && it.all(Char::isDigit)) pinInput = it }, label = { Text("Novo PIN") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), singleLine = true)
                OutlinedTextField(pinConfirm, { if (it.length <= setupLength && it.all(Char::isDigit)) pinConfirm = it }, label = { Text("Confirmar PIN") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), singleLine = true)
                failedMessage?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                Button(onClick = {
                    if (pinInput.length != setupLength || pinInput != pinConfirm) failedMessage = "Digite e confirme os $setupLength dígitos."
                    else if (pinStore.setPin(pinInput, setupLength)) {
                        prefs.pinLength = setupLength; unlocked = true; pinInput=""; pinConfirm=""; failedMessage=null
                    } else failedMessage = "Não foi possível criar o PIN."
                }) { Text("Criar PIN e entrar") }
                TextButton(onClick=onBack) { Text("Voltar") }
            }
        }
        return
    }

    if (!unlocked) {
        Box(Modifier.fillMaxSize().padding(18.dp)) {
            Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Icon(Icons.Default.Lock, null, modifier = Modifier.size(42.dp), tint = MaterialTheme.colorScheme.primary)
                Text("Caixa Preta SONUS", fontSize = 24.sp, fontWeight = FontWeight.Black)
                val remaining = pinStore.lockoutRemainingMs()
                if (remaining > 0) Text("Aguarde ${(remaining / 1000L + 1)} s para tentar novamente.", color = MaterialTheme.colorScheme.error)
                OutlinedTextField(pinInput, { if (it.length <= pinStore.pinLength() && it.all(Char::isDigit)) pinInput = it }, label = { Text("PIN de ${pinStore.pinLength()} dígitos") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), singleLine = true)
                failedMessage?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                Button(enabled = remaining <= 0L && pinInput.length == pinStore.pinLength(), onClick = {
                    if (pinStore.verify(pinInput)) { unlocked = true; pinInput=""; failedMessage=null }
                    else { failedMessage = if (pinStore.lockoutRemainingMs() > 0L) "Muitas tentativas. Bloqueio temporário ativado." else "PIN incorreto."; pinInput="" }
                }) { Text("Entrar") }
                TextButton(onClick=onBack) { Text("Voltar") }
            }
        }
        return
    }

    confirmAction?.let { action ->
        AlertDialog(
            onDismissRequest = { confirmAction=null; confirmActionPin="" },
            title = { Text("Confirmar com PIN") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(when(action){"STOP"->"Digite o PIN para encerrar a Caixa Preta.";"SAVE"->"Digite o PIN para salvar este trecho.";"CLEAR"->"Digite o PIN para apagar o buffer atual.";else->"Confirme sua ação."})
                    OutlinedTextField(confirmActionPin,{if(it.length<=pinStore.pinLength()&&it.all(Char::isDigit))confirmActionPin=it},label={Text("PIN")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.NumberPassword),singleLine=true)
                }
            },
            confirmButton = {
                TextButton(onClick={
                    if (!verifyForAction(confirmActionPin)) { confirmActionPin=""; return@TextButton }
                    when(action){
                        "STOP" -> SonusBlackBoxService.stop(context)
                        "CLEAR" -> { SonusBlackBoxStorage.clearBuffer(context); message="Buffer apagado." }
                        "SAVE" -> {
                            val absStart = startMs + rangeStartMs.toLong()
                            val absEnd = startMs + rangeEndMs.toLong()
                            scope.launch {
                                message = "Salvando trecho…"
                                val file = withContext(Dispatchers.IO) { SonusBlackBoxStorage.saveExcerpt(context, absStart, absEnd) }
                                message = file?.let { "Trecho salvo: ${it.name}" } ?: "Não foi possível salvar esse período. Aguarde os blocos terminarem de ser processados."
                            }
                        }
                    }
                    confirmAction=null; confirmActionPin=""
                }){Text("Confirmar")}
            },
            dismissButton = { TextButton(onClick={confirmAction=null;confirmActionPin=""}){Text("Cancelar")} }
        )
    }

    if (showChangePin) {
        AlertDialog(
            onDismissRequest = { showChangePin=false; oldPin="";newPin="";newPinConfirm="" },
            title={Text("Alterar PIN")},
            text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
                OutlinedTextField(oldPin,{if(it.length<=pinStore.pinLength()&&it.all(Char::isDigit))oldPin=it},label={Text("PIN atual")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.NumberPassword),singleLine=true)
                Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){FilterChip(selected=setupLength==3,onClick={setupLength=3;newPin="";newPinConfirm=""},label={Text("3 dígitos")});FilterChip(selected=setupLength==4,onClick={setupLength=4;newPin="";newPinConfirm=""},label={Text("4 dígitos")})}
                OutlinedTextField(newPin,{if(it.length<=setupLength&&it.all(Char::isDigit))newPin=it},label={Text("Novo PIN")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.NumberPassword),singleLine=true)
                OutlinedTextField(newPinConfirm,{if(it.length<=setupLength&&it.all(Char::isDigit))newPinConfirm=it},label={Text("Confirmar novo PIN")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.NumberPassword),singleLine=true)
            }},
            confirmButton={TextButton(onClick={
                when {
                    !pinStore.verify(oldPin) -> message="PIN atual incorreto."
                    newPin.length!=setupLength || newPin!=newPinConfirm -> message="O novo PIN não confere."
                    pinStore.setPin(newPin,setupLength) -> {prefs.pinLength=setupLength;message="PIN alterado.";showChangePin=false;oldPin="";newPin="";newPinConfirm=""}
                    else -> message="Não foi possível alterar o PIN."
                }
            }){Text("Alterar")}},
            dismissButton={TextButton(onClick={showChangePin=false}){Text("Cancelar")}}
        )
    }

    renameFile?.let { file ->
        AlertDialog(
            onDismissRequest={renameFile=null},
            title={Text("Renomear trecho")},
            text={OutlinedTextField(renameText,{renameText=it},label={Text("Nome do arquivo")},singleLine=true)},
            confirmButton={TextButton(onClick={
                val renamed = SonusBlackBoxStorage.renameSaved(file,renameText)
                message = if(renamed!=null)"Arquivo renomeado." else "Esse nome não pôde ser usado."
                renameFile=null
            }){Text("Renomear")}},
            dismissButton={TextButton(onClick={renameFile=null}){Text("Cancelar")}}
        )
    }

    val mbPerMinute = bitrate * 60.0 / 8.0 / 1000.0
    val mbPerHour = mbPerMinute * 60.0
    val storageMb = snapshot.storageBytes / 1_000_000.0

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(top=14.dp,bottom=34.dp)
    ) {
        item {
            Row(verticalAlignment=Alignment.CenterVertically) {
                IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,"Voltar")}
                Column(Modifier.weight(1f)) {
                    Text("Caixa Preta SONUS", fontSize=25.sp, fontWeight=FontWeight.Black)
                    Text("Buffer local contínuo • nenhum backup ou nuvem", style=MaterialTheme.typography.bodySmall, color=MaterialTheme.colorScheme.onSurface.copy(alpha=.62f))
                }
                Surface(shape=RoundedCornerShape(999.dp),color=if(snapshot.recording)Color(0xFF183927) else MaterialTheme.colorScheme.surfaceVariant) {
                    Text(if(snapshot.recording) snapshot.status else "Parada",modifier=Modifier.padding(horizontal=9.dp,vertical=5.dp),fontSize=10.sp,fontWeight=FontWeight.Bold,color=if(snapshot.recording)Color(0xFF78F3A7) else MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        item {
            Surface(shape=RoundedCornerShape(22.dp),color=Color(0xFF080A0E),border=BorderStroke(1.dp,Color.White.copy(alpha=.10f))) {
                Column(Modifier.padding(15.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Security,null,tint=Color(0xFFE1E7FF));Spacer(Modifier.width(8.dp));Text("Privacidade por projeto",fontWeight=FontWeight.Black)}
                    Text("Os blocos ficam em uma área interna excluída de backup. O Android continua mostrando o indicador de microfone e a notificação do serviço enquanto a função está ativa.",style=MaterialTheme.typography.bodySmall,color=Color.White.copy(alpha=.68f))
                }
            }
        }

        item {
            Text("Tempo máximo do buffer",fontWeight=FontWeight.Black)
            LazyRow(horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                items(listOf(1,2,3,4,6,12,24)) { h ->
                    FilterChip(selected=retention==h,onClick={retention=h;prefs.retentionHours=h},label={Text(if(h==24)"24h" else "${h}h")})
                }
            }
        }

        item {
            Surface(shape=RoundedCornerShape(20.dp),color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.35f)) {
                Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically){Text("Qualidade MP3",fontWeight=FontWeight.Black,modifier=Modifier.weight(1f));Text("$bitrate kbps",fontWeight=FontWeight.Black,color=MaterialTheme.colorScheme.primary)}
                    Slider(value=bitrate.toFloat(),onValueChange={bitrate=(it/8f).roundToInt()*8;bitrate=bitrate.coerceIn(24,320);prefs.bitrateKbps=bitrate},valueRange=24f..320f,steps=36)
                    val label=when{bitrate<=48->"Extrema economia";bitrate<=80->"Baixa";bitrate<=128->"Equilibrada";bitrate<=224->"Alta";else->"Máxima"}
                    Text("$label • ${"%.2f".format(mbPerMinute)} MB/min • ${"%.1f".format(mbPerHour)} MB/h",style=MaterialTheme.typography.bodySmall)
                    Text("Estimativa do buffer de ${retention}h: ${"%.1f".format(mbPerHour*retention)} MB",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.60f))
                    if(bitrate in 64..128) Text("Faixa recomendada para voz e gravação contínua.",fontSize=10.sp,color=Color(0xFF74DDA5))
                }
            }
        }

        item {
            Surface(shape=RoundedCornerShape(20.dp),color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.28f)) {
                Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(9.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically){Text("Gravação em segundo plano",fontWeight=FontWeight.Black,modifier=Modifier.weight(1f));Text("${"%.1f".format(storageMb)} MB",fontSize=11.sp)}
                    Text(if(snapshot.recording)"${snapshot.status} • ${snapshot.encodedSegments} bloco(s) processado(s)" else "Pronta para iniciar",style=MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        if(!snapshot.recording) {
                            Button(onClick={
                                prefs.retentionHours=retention;prefs.bitrateKbps=bitrate
                                if(ContextCompat.checkSelfPermission(context,Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED)SonusBlackBoxService.start(context) else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                            },modifier=Modifier.weight(1f)){Icon(Icons.Default.FiberManualRecord,null);Spacer(Modifier.width(5.dp));Text("Iniciar")}
                        } else {
                            Button(onClick={if(snapshot.paused){SonusBlackBoxService.resume(context)}else{SonusBlackBoxService.pause(context)}},modifier=Modifier.weight(1f)){Icon(if(snapshot.paused)Icons.Default.PlayArrow else Icons.Default.Pause,null);Spacer(Modifier.width(5.dp));Text(if(snapshot.paused)"Retomar" else "Pausar")}
                            OutlinedButton(onClick={confirmAction="STOP"},modifier=Modifier.weight(1f)){Icon(Icons.Default.Stop,null);Spacer(Modifier.width(5.dp));Text("Encerrar")}
                        }
                    }
                }
            }
        }

        if(snapshot.recording || segments.isNotEmpty()) {
            item { Text("Linha do tempo",fontWeight=FontWeight.Black) }
            item {
                Surface(shape=RoundedCornerShape(20.dp),color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.30f)) {
                    Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                        val behind = ((availableMs-timelineMs).coerceAtLeast(0f)/60_000f)
                        Row(verticalAlignment=Alignment.CenterVertically){Text(if(behind<.05f)"AO VIVO" else "-${"%.1f".format(behind)} min",fontWeight=FontWeight.Black,color=if(behind<.05f)Color(0xFF72F0A3) else MaterialTheme.colorScheme.primary,modifier=Modifier.weight(1f));Text("janela ${retention}h",fontSize=10.sp)}
                        Slider(value=timelineMs.coerceIn(0f,availableMs),onValueChange={timelineMs=it;followLive=false},valueRange=0f..availableMs)
                        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick={
                                if(segments.isEmpty()){message="Aguarde o primeiro bloco MP3 ficar pronto.";return@OutlinedButton}
                                val target=startMs+timelineMs.toLong()
                                val index=segments.indexOfLast{it.startMs<=target}.coerceAtLeast(0)
                                val chosen=segments.drop(index)
                                player.setMediaItems(chosen.map{MediaItem.fromUri(Uri.fromFile(it.file))})
                                player.prepare()
                                val offset=(target-chosen.first().startMs).coerceAtLeast(0L)
                                player.seekTo(0,offset)
                                player.play()
                            },modifier=Modifier.weight(1f)){Icon(Icons.Default.PlayArrow,null);Spacer(Modifier.width(4.dp));Text("Ouvir daqui")}
                            Button(onClick={followLive=true;timelineMs=availableMs;player.stop()},modifier=Modifier.weight(1f)){Icon(Icons.Default.LiveTv,null);Spacer(Modifier.width(4.dp));Text("Voltar ao vivo")}
                        }
                        if(snapshot.gaps.isNotEmpty()) Text("${snapshot.gaps.size} interrupção(ões) do microfone registrada(s) nesta sessão.",style=MaterialTheme.typography.labelSmall,color=Color(0xFFFFB86B))
                    }
                }
            }

            item { Text("Salvar trecho",fontWeight=FontWeight.Black) }
            item {
                Surface(shape=RoundedCornerShape(20.dp),color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.30f)) {
                    Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(7.dp)) {
                        Text("Selecione o início e o fim. O arquivo final será MP3 e terá data brasileira no nome.",style=MaterialTheme.typography.bodySmall)
                        RangeSlider(
                            value=rangeStartMs.coerceIn(0f,availableMs)..rangeEndMs.coerceIn(0f,availableMs),
                            onValueChange={rangeStartMs=it.start;rangeEndMs=it.endInclusive;followLive=false},
                            valueRange=0f..availableMs
                        )
                        val sBehind=((availableMs-rangeStartMs)/60_000f).coerceAtLeast(0f)
                        val eBehind=((availableMs-rangeEndMs)/60_000f).coerceAtLeast(0f)
                        Text("Início: -${"%.1f".format(sBehind)} min • fim: ${if(eBehind<.05f)"agora" else "-${"%.1f".format(eBehind)} min"}",fontSize=10.sp)
                        Button(enabled=segments.isNotEmpty()&&rangeEndMs>rangeStartMs,onClick={confirmAction="SAVE"},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Save,null);Spacer(Modifier.width(6.dp));Text("Salvar trecho protegido")}
                    }
                }
            }
        }

        item {
            Surface(shape=RoundedCornerShape(18.dp),color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.25f)) {
                Column(Modifier.padding(13.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick={showChangePin=true},modifier=Modifier.weight(1f)){Icon(Icons.Default.Dialpad,null);Spacer(Modifier.width(4.dp));Text("Alterar PIN")}
                        OutlinedButton(onClick={confirmAction="CLEAR"},modifier=Modifier.weight(1f)){Icon(Icons.Default.DeleteSweep,null);Spacer(Modifier.width(4.dp));Text("Apagar buffer")}
                    }
                }
            }
        }

        if(savedFiles.isNotEmpty()) {
            item { Text("Trechos salvos",fontWeight=FontWeight.Black) }
            items(savedFiles,key={it.absolutePath}) { file ->
                Surface(shape=RoundedCornerShape(15.dp),color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.28f)) {
                    Row(Modifier.padding(10.dp),verticalAlignment=Alignment.CenterVertically) {
                        Icon(Icons.Default.AudioFile,null,tint=MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)){Text(file.name,fontSize=10.sp,fontWeight=FontWeight.Bold,maxLines=2,overflow=TextOverflow.Ellipsis);Text("${"%.2f".format(file.length()/1_000_000.0)} MB",fontSize=9.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.55f))}
                        TextButton(onClick={renameFile=file;renameText=file.nameWithoutExtension}){Text("Renomear")}
                    }
                }
            }
        }

        message?.let { item { Text(it,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.primary) } }
        snapshot.error?.let { item { Text(it,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.error) } }
    }
}
