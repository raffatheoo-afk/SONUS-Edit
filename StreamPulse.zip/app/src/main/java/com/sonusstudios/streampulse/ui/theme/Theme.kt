package com.sonusstudios.streampulse.ui.theme

import android.graphics.BitmapFactory
import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.core.content.ContextCompat
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.size
import androidx.camera.core.ImageAnalysis
import androidx.camera.view.LifecycleCameraController
import java.util.concurrent.Executors
import androidx.compose.animation.animateColor
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.sonusstudios.streampulse.R
import com.sonusstudios.streampulse.core.AppFont
import com.sonusstudios.streampulse.core.ThemeMode
import com.sonusstudios.streampulse.core.TextAppearance
import java.io.File

val PulseBlue = Color(0xFF1167FF)
val PulseCyan = Color(0xFF16D5F5)
val PulsePurple = Color(0xFF7A35F5)
val PulseNavy = Color(0xFF071A3D)
val PulseSurface = Color(0xFFF5F8FF)

private val LightColors = lightColorScheme(
    primary = PulseBlue,
    secondary = PulsePurple,
    tertiary = PulseCyan,
    background = PulseSurface,
    surface = Color.White,
    onPrimary = Color.White,
    onBackground = PulseNavy,
    onSurface = PulseNavy
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF73A7FF),
    secondary = Color(0xFFB597FF),
    tertiary = Color(0xFF66E4F8),
    background = Color(0xFF061327),
    surface = Color(0xFF0B1E3B),
    onPrimary = Color(0xFF001B3F),
    onBackground = Color(0xFFEAF1FF),
    onSurface = Color(0xFFEAF1FF)
)


private fun signatureScheme(primary: Color, secondary: Color, background: Color, surface: Color) = darkColorScheme(
    primary = primary, secondary = secondary, tertiary = primary.copy(alpha = .82f),
    background = background, surface = surface, primaryContainer = primary.copy(alpha = .22f),
    secondaryContainer = secondary.copy(alpha = .22f), onPrimary = Color(0xFF02060D),
    onBackground = Color(0xFFF4F7FF), onSurface = Color(0xFFF4F7FF)
)

private fun blueScheme() = darkColorScheme(
    primary = Color(0xFF78A9FF), secondary = Color(0xFF8EC5FF), tertiary = Color(0xFF55D8FF),
    background = Color(0xFF06152B), surface = Color(0xFF102442), primaryContainer = Color(0xFF173C70),
    secondaryContainer = Color(0xFF1A3558), onPrimary = Color(0xFF031426), onBackground = Color(0xFFF0F6FF), onSurface = Color(0xFFF0F6FF)
)

private fun greenScheme() = darkColorScheme(
    primary = Color(0xFF7DDAA5), secondary = Color(0xFF9ED9BD), tertiary = Color(0xFF7BE8D0),
    background = Color(0xFF071D18), surface = Color(0xFF102E27), primaryContainer = Color(0xFF1D4B3B),
    secondaryContainer = Color(0xFF23483D), onPrimary = Color(0xFF032318), onBackground = Color(0xFFF0FFF8), onSurface = Color(0xFFF0FFF8)
)

private fun redScheme() = darkColorScheme(
    primary = Color(0xFFFF9C9C), secondary = Color(0xFFE8A4B7), tertiary = Color(0xFFFFB480),
    background = Color(0xFF251013), surface = Color(0xFF3A1B21), primaryContainer = Color(0xFF642B35),
    secondaryContainer = Color(0xFF573039), onPrimary = Color(0xFF31070B), onBackground = Color(0xFFFFF4F4), onSurface = Color(0xFFFFF4F4)
)


private fun softYellowScheme() = lightColorScheme(
    primary = Color(0xFF9A7A10), secondary = Color(0xFFC4A33A), tertiary = Color(0xFFFFD95A),
    background = Color(0xFFFFF8D8), surface = Color(0xFFFFFDF0), primaryContainer = Color(0xFFFFE98E),
    secondaryContainer = Color(0xFFFFF1B7), onPrimary = Color.White, onBackground = Color(0xFF302600), onSurface = Color(0xFF302600)
)

private fun softBrownScheme() = darkColorScheme(
    primary = Color(0xFFD2A57B), secondary = Color(0xFFC28B63), tertiary = Color(0xFFE2B88F),
    background = Color(0xFF1A120E), surface = Color(0xFF2A1D17), primaryContainer = Color(0xFF533827),
    secondaryContainer = Color(0xFF442E24), onPrimary = Color(0xFF27150B), onBackground = Color(0xFFFFF3E8), onSurface = Color(0xFFFFF3E8)
)

private fun softOrangeScheme() = darkColorScheme(
    primary = Color(0xFFFFB36B), secondary = Color(0xFFE58A46), tertiary = Color(0xFFFFD18F),
    background = Color(0xFF24140B), surface = Color(0xFF3A2215), primaryContainer = Color(0xFF6A3E1D),
    secondaryContainer = Color(0xFF5B331B), onPrimary = Color(0xFF321601), onBackground = Color(0xFFFFF2E4), onSurface = Color(0xFFFFF2E4)
)

private fun silverScheme() = darkColorScheme(
    primary = Color(0xFFE3E8EE), secondary = Color(0xFFB9C2CC), tertiary = Color(0xFF8FA4B8),
    background = Color(0xFF101318), surface = Color(0xFF1B2027), primaryContainer = Color(0xFF39424C),
    secondaryContainer = Color(0xFF2E353D), onPrimary = Color(0xFF15191E), onBackground = Color(0xFFF5F7FA), onSurface = Color(0xFFF5F7FA)
)

private fun checkeredScheme() = darkColorScheme(
    primary = Color(0xFF8EB8FF), secondary = Color(0xFFB0B7C2), tertiary = Color(0xFF7FE1D7),
    background = Color(0xFF10131A), surface = Color(0xFF1B2029), primaryContainer = Color(0xFF263956),
    secondaryContainer = Color(0xFF2A3039), onPrimary = Color(0xFF07152C), onBackground = Color(0xFFF2F5FA), onSurface = Color(0xFFF2F5FA)
)

private fun rainbowScheme() = darkColorScheme(
    primary = Color(0xFF70D6FF), secondary = Color(0xFFFF70A6), tertiary = Color(0xFFFFD670),
    background = Color(0xFF11142A), surface = Color(0xFF1A2240), primaryContainer = Color(0xFF243A67),
    secondaryContainer = Color(0xFF512C5C), onPrimary = Color(0xFF06111C), onBackground = Color.White, onSurface = Color.White
)

private fun monochromeScheme() = darkColorScheme(
    primary = Color(0xFFE7E7EA), secondary = Color(0xFFB7BAC0), tertiary = Color(0xFF8A8E96),
    background = Color(0xFF0B0C0F), surface = Color(0xFF17191E), primaryContainer = Color(0xFF303239),
    secondaryContainer = Color(0xFF25272D), onPrimary = Color.Black, onBackground = Color(0xFFF2F2F4), onSurface = Color(0xFFF2F2F4)
)

private fun pinkScheme() = darkColorScheme(
    primary = Color(0xFFFF8BC7), secondary = Color(0xFFFFB0D8), tertiary = Color(0xFFE7A7FF),
    background = Color(0xFF24101F), surface = Color(0xFF39192F), primaryContainer = Color(0xFF6C2853),
    secondaryContainer = Color(0xFF522348), onPrimary = Color(0xFF3A0828), onBackground = Color(0xFFFFF2FA), onSurface = Color(0xFFFFF2FA)
)

private fun lilacScheme() = darkColorScheme(
    primary = Color(0xFFC6A7FF), secondary = Color(0xFFE1C8FF), tertiary = Color(0xFFB2C7FF),
    background = Color(0xFF171125), surface = Color(0xFF281C3D), primaryContainer = Color(0xFF4A356D),
    secondaryContainer = Color(0xFF3B2B59), onPrimary = Color(0xFF24113D), onBackground = Color(0xFFF8F2FF), onSurface = Color(0xFFF8F2FF)
)

private fun deepBlackScheme() = darkColorScheme(
    primary = Color(0xFF4CC9F0), secondary = Color(0xFFFF4D8D), tertiary = Color(0xFFFFC857),
    background = Color.Black, surface = Color(0xFF0C0C0E), primaryContainer = Color(0xFF102A3A),
    secondaryContainer = Color(0xFF35101F), onPrimary = Color.Black, onBackground = Color.White, onSurface = Color.White
)

private fun auroraScheme() = darkColorScheme(
    primary = Color(0xFF6FB6FF), secondary = Color(0xFFC38CFF), tertiary = Color(0xFFFF8CC8),
    background = Color(0xFF0C1027), surface = Color(0xFF181D3D), primaryContainer = Color(0xFF283B71),
    secondaryContainer = Color(0xFF4C315F), onPrimary = Color(0xFF061426), onBackground = Color(0xFFF8F4FF), onSurface = Color(0xFFF8F4FF)
)

private fun photoScheme() = darkColorScheme(
    primary = Color(0xFF86B8FF), secondary = Color(0xFFC89EFF), tertiary = Color(0xFF70E6FF),
    background = Color.Transparent, surface = Color(0xD90A1830), primaryContainer = Color(0xCC173B68),
    secondaryContainer = Color(0xCC362957), onPrimary = Color(0xFF061426), onBackground = Color.White, onSurface = Color.White
)


private fun goldScheme() = darkColorScheme(
    primary = Color(0xFFFFD76A), secondary = Color(0xFFD5A429), tertiary = Color(0xFFFFE9A3),
    background = Color(0xFF120D03), surface = Color(0xFF241A08), primaryContainer = Color(0xFF5C4312),
    secondaryContainer = Color(0xFF49340C), onPrimary = Color(0xFF2B1D00), onBackground = Color(0xFFFFF6D8), onSurface = Color(0xFFFFF6D8)
)

private fun skyScheme() = lightColorScheme(
    primary = Color(0xFF1D72C9), secondary = Color(0xFF67A9E8), tertiary = Color(0xFFB9E6FF),
    background = Color.Transparent, surface = Color(0xDDF7FBFF), primaryContainer = Color(0xFFD6EBFF),
    secondaryContainer = Color(0xFFEAF6FF), onPrimary = Color.White, onBackground = Color(0xFF08233D), onSurface = Color(0xFF08233D)
)

private fun spaceScheme() = darkColorScheme(
    primary = Color(0xFFA98CFF), secondary = Color(0xFF5F8CFF), tertiary = Color(0xFFFF8FCB),
    background = Color.Transparent, surface = Color(0xE6111225), primaryContainer = Color(0xFF2A2358),
    secondaryContainer = Color(0xFF1E2E5D), onPrimary = Color(0xFF160B32), onBackground = Color(0xFFF4F1FF), onSurface = Color(0xFFF4F1FF)
)

private fun professionalScheme() = darkColorScheme(
    primary = Color(0xFF4C9CFF), secondary = Color(0xFF2D7CD8), tertiary = Color(0xFF68B7FF),
    background = Color.Black, surface = Color(0xFF0C1016), primaryContainer = Color(0xFF11243E),
    secondaryContainer = Color(0xFF101C2D), onPrimary = Color(0xFF00162F), onBackground = Color(0xFFEAF3FF), onSurface = Color(0xFFEAF3FF)
)

private data class FontPreset(
    val family: FontFamily,
    val trackingSp: Float = 0f,
    val weight: FontWeight? = null
)

private fun presetFor(font: AppFont): FontPreset = when (font) {
    AppFont.MODERN -> FontPreset(FontFamily.SansSerif)
    AppFont.ROUNDED -> FontPreset(FontFamily.Cursive)
    AppFont.CLASSIC -> FontPreset(FontFamily.Serif)
    AppFont.COMPACT -> FontPreset(FontFamily.Default, -0.25f)
    AppFont.DIGITAL -> FontPreset(FontFamily.Monospace, 0.1f)

    AppFont.NEO -> FontPreset(FontFamily.SansSerif, 0.35f, FontWeight.Medium)
    AppFont.SOFT -> FontPreset(FontFamily.Cursive, 0.05f)
    AppFont.URBAN -> FontPreset(FontFamily.SansSerif, -0.15f, FontWeight.SemiBold)
    AppFont.ELEGANT -> FontPreset(FontFamily.Serif, 0.2f)
    AppFont.WIDE -> FontPreset(FontFamily.SansSerif, 0.75f)

    AppFont.EDITORIAL -> FontPreset(FontFamily.Serif, 0.45f, FontWeight.Medium)
    AppFont.SIGNATURE -> FontPreset(FontFamily.Cursive, 0.3f)
    AppFont.PULSE -> FontPreset(FontFamily.SansSerif, 0.55f, FontWeight.SemiBold)
    AppFont.MINIMAL -> FontPreset(FontFamily.Default, 0.15f, FontWeight.Light)
    AppFont.TECH -> FontPreset(FontFamily.Monospace, 0.35f, FontWeight.Medium)

    AppFont.QUANTUM -> FontPreset(FontFamily.Monospace, 0.8f, FontWeight.Bold)
    AppFont.VISION -> FontPreset(FontFamily.SansSerif, 0.6f, FontWeight.Medium)
    AppFont.PRIME -> FontPreset(FontFamily.Serif, 0.1f, FontWeight.SemiBold)
    AppFont.CODEX -> FontPreset(FontFamily.Monospace, -0.05f)
    AppFont.CINEMA -> FontPreset(FontFamily.Serif, 0.85f)
    AppFont.ARCHITECT -> FontPreset(FontFamily.SansSerif, 0.25f, FontWeight.Light)
    AppFont.NOVA -> FontPreset(FontFamily.Cursive, 0.2f, FontWeight.Medium)
    AppFont.MONUMENT -> FontPreset(FontFamily.SansSerif, 1.0f, FontWeight.Bold)
    AppFont.VELVET -> FontPreset(FontFamily.Serif, 0.35f, FontWeight.Medium)
    AppFont.TITAN -> FontPreset(FontFamily.Default, -0.2f, FontWeight.ExtraBold)
}

private fun typographyFor(font: AppFont, appearance: TextAppearance, accentColor: Color): Typography {
    val preset = presetFor(font)
    val base = Typography()
    val requestedColor = when (appearance) {
        TextAppearance.BLACK, TextAppearance.BLACK_WHITE_OUTLINE -> Color.Black
        TextAppearance.WHITE, TextAppearance.WHITE_BLACK_OUTLINE, TextAppearance.WHITE_SHADOW -> Color.White
        TextAppearance.RAINBOW -> accentColor
        TextAppearance.DEEP_GRAY -> Color(0xFF343A40)
        TextAppearance.NAVY -> Color(0xFF071A3D)
        TextAppearance.DYNAMIC, TextAppearance.BOLD -> Color.Unspecified
    }
    val requestedShadow = when (appearance) {
        TextAppearance.WHITE_BLACK_OUTLINE -> Shadow(Color.Black, Offset.Zero, 3.4f)
        TextAppearance.BLACK_WHITE_OUTLINE -> Shadow(Color.White, Offset.Zero, 3.4f)
        TextAppearance.WHITE_SHADOW -> Shadow(Color.Black.copy(alpha=.82f), Offset(1.8f, 2.2f), 4.5f)
        else -> null
    }
    fun TextStyle.withPreset(): TextStyle = copy(
        fontFamily = preset.family,
        letterSpacing = preset.trackingSp.sp,
        fontWeight = when { appearance == TextAppearance.BOLD -> FontWeight.ExtraBold; else -> preset.weight ?: fontWeight },
        color = if (requestedColor == Color.Unspecified) color else requestedColor,
        shadow = requestedShadow ?: shadow
    )
    return Typography(
        displayLarge = base.displayLarge.withPreset(), displayMedium = base.displayMedium.withPreset(), displaySmall = base.displaySmall.withPreset(),
        headlineLarge = base.headlineLarge.withPreset(), headlineMedium = base.headlineMedium.withPreset(), headlineSmall = base.headlineSmall.withPreset(),
        titleLarge = base.titleLarge.withPreset(), titleMedium = base.titleMedium.withPreset(), titleSmall = base.titleSmall.withPreset(),
        bodyLarge = base.bodyLarge.withPreset(), bodyMedium = base.bodyMedium.withPreset(), bodySmall = base.bodySmall.withPreset(),
        labelLarge = base.labelLarge.withPreset(), labelMedium = base.labelMedium.withPreset(), labelSmall = base.labelSmall.withPreset()
    )
}

@Composable
fun StreamPulseTheme(
    themeMode: ThemeMode = ThemeMode.DYNAMIC,
    appFont: AppFont = AppFont.MODERN,
    textAppearance: TextAppearance = TextAppearance.DYNAMIC,
    content: @Composable () -> Unit
) {
    val systemDark = isSystemInDarkTheme()
    val scheme = remember(themeMode, systemDark) {
        when (themeMode) {
            ThemeMode.SYSTEM -> if (systemDark) DarkColors else LightColors
            ThemeMode.DYNAMIC -> darkColorScheme(
                primary = Color(0xFF829EF4), secondary = Color(0xFF66D6E8), tertiary = Color(0xFFB783FF),
                background = Color.Transparent, surface = Color(0xE60C203C), primaryContainer = Color(0xFF243C75),
                secondaryContainer = Color(0xFF244D5E), onPrimary = Color(0xFF071327), onBackground = Color(0xFFEAF1FF), onSurface = Color(0xFFEAF1FF)
            )
            ThemeMode.LIGHT -> LightColors
            ThemeMode.DARK -> DarkColors
            ThemeMode.BLUE -> blueScheme()
            ThemeMode.GREEN -> greenScheme()
            ThemeMode.RED -> redScheme()
            ThemeMode.CHECKERED -> checkeredScheme()
            ThemeMode.SOFT_YELLOW -> softYellowScheme()
            ThemeMode.SOFT_BROWN -> softBrownScheme()
            ThemeMode.SOFT_ORANGE -> softOrangeScheme()
            ThemeMode.SILVER -> silverScheme()
            ThemeMode.RAINBOW -> rainbowScheme()
            ThemeMode.MONOCHROME -> monochromeScheme()
            ThemeMode.PINK -> pinkScheme()
            ThemeMode.LILAC -> lilacScheme()
            ThemeMode.DEEP_BLACK -> deepBlackScheme()
            ThemeMode.AURORA -> auroraScheme()
            ThemeMode.SLATE -> signatureScheme(Color(0xFF9EB5CC), Color(0xFF657A91), Color(0xFF0B1118), Color(0xFF17212B))
            ThemeMode.OCEAN -> signatureScheme(Color(0xFF44D7E8), Color(0xFF1B83A0), Color(0xFF03171F), Color(0xFF0A2D38))
            ThemeMode.FOREST -> signatureScheme(Color(0xFF63E0A5), Color(0xFF2E8D66), Color(0xFF04150F), Color(0xFF0B2C21))
            ThemeMode.VIOLET_PULSE -> signatureScheme(Color(0xFFD281FF), Color(0xFF7445D8), Color(0xFF10081A), Color(0xFF27143C))
            ThemeMode.SUNSET -> signatureScheme(Color(0xFFFF9A5A), Color(0xFFB64F91), Color(0xFF160A1D), Color(0xFF3B1A35))
            ThemeMode.MIDNIGHT_CYAN -> signatureScheme(Color(0xFF42E8FF), Color(0xFF2876A6), Color(0xFF020A10), Color(0xFF082434))
            ThemeMode.NEON_STUDIO -> signatureScheme(Color(0xFF22DFFF), Color(0xFF9850FF), Color(0xFF02040A), Color(0xFF0C1830))
            ThemeMode.CRIMSON_PRO -> signatureScheme(Color(0xFFFF607A), Color(0xFF9B2948), Color(0xFF0B0508), Color(0xFF271017))
            ThemeMode.AURORA_PRO -> signatureScheme(Color(0xFF56FFD4), Color(0xFFB46CFF), Color(0xFF031016), Color(0xFF142C39))
            ThemeMode.CYBER_PULSE -> signatureScheme(Color(0xFF00E4FF), Color(0xFFFF43D4), Color(0xFF01040A), Color(0xFF0A1830))
            ThemeMode.ROYAL_GOLD -> signatureScheme(Color(0xFFFFD76A), Color(0xFFB78B2E), Color(0xFF090602), Color(0xFF271C07))
            ThemeMode.GLASS_HORIZON -> signatureScheme(Color(0xFFB5E7FF), Color(0xFF9C83FF), Color(0xFF07101B), Color(0xFF1A2837))
            ThemeMode.NEBULA -> signatureScheme(Color(0xFFD774FF), Color(0xFF5B75FF), Color(0xFF04030B), Color(0xFF20113A))
            ThemeMode.INFINITY -> signatureScheme(Color(0xFF20E2FF), Color(0xFF8D55FF), Color(0xFF010207), Color(0xFF08152A))
            ThemeMode.LIQUID_GLASS -> signatureScheme(Color(0xFFBFEAFF), Color(0xFFA99BFF), Color(0xFF07111D), Color(0xB31B2B3A))
            ThemeMode.THREE_D -> signatureScheme(Color(0xFF63C7FF), Color(0xFF725BFF), Color(0xFF070B16), Color(0xFF17243A))
            ThemeMode.CAMALEON -> signatureScheme(Color(0xFF78F7C0), Color(0xFF65B8FF), Color(0xFF07120F), Color(0xD91A2B2A))
            ThemeMode.PARALLAX -> signatureScheme(Color(0xFF69D9FF), Color(0xFF9B79FF), Color(0xFF050A18), Color(0xE0142038))
            ThemeMode.PHOTO -> photoScheme()
            ThemeMode.PROFESSIONAL -> professionalScheme()
            ThemeMode.GOLD -> goldScheme()
            ThemeMode.SKY -> skyScheme()
            ThemeMode.SPACE -> spaceScheme()
        }
    }
    val rainbow = rememberInfiniteTransition(label = "text-rainbow")
    val rainbowText by rainbow.animateColor(
        initialValue = Color(0xFF62D8FF),
        targetValue = Color(0xFFFF70C8),
        animationSpec = infiniteRepeatable(tween(1900), RepeatMode.Reverse),
        label = "text-rainbow-color"
    )
    val typography = remember(appFont, textAppearance, rainbowText) { typographyFor(appFont, textAppearance, rainbowText) }
    MaterialTheme(colorScheme = scheme, typography = typography, content = content)
}

/**
 * Plano de fundo separado do MaterialTheme para que temas animados não forcem
 * recomposição global da árvore inteira. Só esta camada é redesenhada.
 */
@Composable
fun StreamPulseBackground(
    themeMode: ThemeMode,
    backgroundPhotoPath: String?,
    content: @Composable () -> Unit
) {
    Box(Modifier.fillMaxSize()) {
        when (themeMode) {
            ThemeMode.DYNAMIC -> DynamicGradientBackground(
                startA = Color(0xFF071B3D), startB = Color(0xFF25113F),
                endA = Color(0xFF0A3141), endB = Color(0xFF111A44)
            )
            ThemeMode.RAINBOW -> DynamicGradientBackground(
                startA = Color(0xFF162A5A), startB = Color(0xFF5A153F),
                endA = Color(0xFF174D47), endB = Color(0xFF40205D)
            )
            ThemeMode.AURORA -> Box(
                Modifier.fillMaxSize().background(
                    Brush.linearGradient(
                        listOf(Color(0xFF081B3E), Color(0xFF2E1C5C), Color(0xFF5A214D), Color(0xFF101733))
                    )
                )
            )
            ThemeMode.SLATE -> Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF0A1017), Color(0xFF263542), Color(0xFF111A22)))))
            ThemeMode.OCEAN -> Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF02141B), Color(0xFF0B4B58), Color(0xFF05232D)))))
            ThemeMode.FOREST -> Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF03120C), Color(0xFF14533A), Color(0xFF08261B)))))
            ThemeMode.VIOLET_PULSE -> DynamicGradientBackground(Color(0xFF10061D), Color(0xFF45166A), Color(0xFF241145), Color(0xFF6A1E7F))
            ThemeMode.SUNSET -> DynamicGradientBackground(Color(0xFF16091F), Color(0xFF7B2E4F), Color(0xFF3A174B), Color(0xFF9A4B24))
            ThemeMode.MIDNIGHT_CYAN -> DynamicGradientBackground(Color(0xFF010910), Color(0xFF06445A), Color(0xFF071A2B), Color(0xFF09667A))
            ThemeMode.NEON_STUDIO -> DynamicGradientBackground(Color(0xFF01040A), Color(0xFF082A58), Color(0xFF24104E), Color(0xFF00657A))
            ThemeMode.CRIMSON_PRO -> Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF090407), Color(0xFF5B1728), Color(0xFF1A0910)))))
            ThemeMode.AURORA_PRO -> DynamicGradientBackground(Color(0xFF021017), Color(0xFF0D594E), Color(0xFF3C1E5A), Color(0xFF0D374B))
            ThemeMode.CYBER_PULSE -> DynamicGradientBackground(Color(0xFF01040A), Color(0xFF004D66), Color(0xFF4B0C58), Color(0xFF071C40))
            ThemeMode.ROYAL_GOLD -> Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF080500), Color(0xFF604910), Color(0xFF1B1202)))))
            ThemeMode.GLASS_HORIZON -> DynamicGradientBackground(Color(0xFF07101B), Color(0xFF29445A), Color(0xFF35294F), Color(0xFF132B3D))
            ThemeMode.NEBULA -> DynamicGradientBackground(Color(0xFF04030B), Color(0xFF32145A), Color(0xFF5B174D), Color(0xFF121E4A))
            ThemeMode.INFINITY -> DynamicGradientBackground(Color(0xFF010207), Color(0xFF071E4A), Color(0xFF35115C), Color(0xFF00465E))
            ThemeMode.LIQUID_GLASS -> LiquidGlassBackground()
            ThemeMode.THREE_D -> ThreeDBackground()
            ThemeMode.CAMALEON -> CamaleonBackground()
            ThemeMode.PARALLAX -> ParallaxBackground()
            ThemeMode.PINK -> Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF311129), Color(0xFF5B1D49), Color(0xFF1F1020)))))
            ThemeMode.LILAC -> Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF19102B), Color(0xFF3B2865), Color(0xFF151026)))))
            ThemeMode.BLUE -> Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF06152B), Color(0xFF0B2448), Color(0xFF08172E)))))
            ThemeMode.GREEN -> Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF061B16), Color(0xFF12392D), Color(0xFF081B18)))))
            ThemeMode.RED -> Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF241012), Color(0xFF482027), Color(0xFF1F0E13)))))
            ThemeMode.CHECKERED -> CheckeredBackground()
            ThemeMode.SOFT_YELLOW -> Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFFFFF5BF), Color(0xFFFFE38A), Color(0xFFFFF8D8)))))
            ThemeMode.SOFT_BROWN -> Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF1B120E), Color(0xFF493023), Color(0xFF21150F)))))
            ThemeMode.SOFT_ORANGE -> Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF26140A), Color(0xFF7A3D16), Color(0xFF321A0D)))))
            ThemeMode.SILVER -> Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF0F1217), Color(0xFF39434D), Color(0xFF161A20)))))
            ThemeMode.DEEP_BLACK, ThemeMode.PROFESSIONAL -> Box(Modifier.fillMaxSize().background(Color.Black))
            ThemeMode.MONOCHROME -> Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF07080A), Color(0xFF15171B), Color(0xFF08090B)))))
            ThemeMode.PHOTO -> PhotoBackground(backgroundPhotoPath)
            ThemeMode.GOLD -> Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF100B02), Color(0xFF5A4010), Color(0xFF1E1404), Color(0xFF9A741C)))))
            ThemeMode.SKY -> SkyBackground()
            ThemeMode.SPACE -> SpaceBackground()
            ThemeMode.LIGHT -> Box(Modifier.fillMaxSize().background(PulseSurface))
            ThemeMode.SYSTEM -> Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background))
            ThemeMode.DARK -> Box(Modifier.fillMaxSize().background(Color(0xFF061327)))
        }
        content()
    }
}

@Composable
private fun DynamicGradientBackground(startA: Color, startB: Color, endA: Color, endB: Color) {
    val transition = rememberInfiniteTransition(label = "theme-background")
    val first = transition.animateColor(
        initialValue = startA,
        targetValue = endA,
        animationSpec = infiniteRepeatable(tween(9000), RepeatMode.Reverse),
        label = "theme-first"
    ).value
    val second = transition.animateColor(
        initialValue = startB,
        targetValue = endB,
        animationSpec = infiniteRepeatable(tween(11000), RepeatMode.Reverse),
        label = "theme-second"
    ).value
    Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(first, second, Color(0xFF071327)))))
}


@Composable
private fun CheckeredBackground() {
    Box(Modifier.fillMaxSize().background(Color(0xFF11151B))) {
        Canvas(Modifier.fillMaxSize()) {
            val cell = 42f
            var y = 0f
            var row = 0
            while (y < size.height) {
                var x = 0f
                var col = 0
                while (x < size.width) {
                    val color = if ((row + col) % 2 == 0) Color(0xFF1E2530) else Color(0xFF12171E)
                    drawRect(color = color, topLeft = Offset(x, y), size = androidx.compose.ui.geometry.Size(cell, cell))
                    x += cell
                    col++
                }
                y += cell
                row++
            }
        }
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0x88050A10)))))
    }
}

@Composable
private fun SkyBackground() {
    Box(Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(R.drawable.theme_sky),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    listOf(Color(0x22000000), Color.Transparent, Color(0x44002040))
                )
            )
        )
    }
}

@Composable
private fun SpaceBackground() {
    Box(Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(R.drawable.theme_space),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    listOf(Color(0x22000000), Color.Transparent, Color(0x77000000))
                )
            )
        )
    }
}

@Composable
private fun PhotoBackground(path: String?) {
    val bitmap = remember(path) {
        path?.takeIf { it.isNotBlank() && File(it).exists() }
            ?.let { runCatching { BitmapFactory.decodeFile(it)?.asImageBitmap() }.getOrNull() }
    }
    if (bitmap != null) {
        Image(bitmap = bitmap, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x99020A14), Color(0xD9071223), Color(0xF0061020)))))
    } else {
        Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF071327), Color(0xFF25163A)))))
    }
}


@Composable
private fun LiquidGlassBackground() {
    val transition = rememberInfiniteTransition(label = "liquid-glass")
    val glow by transition.animateColor(
        initialValue = Color(0xFF3B8CFF), targetValue = Color(0xFF9B6CFF),
        animationSpec = infiniteRepeatable(tween(7000), RepeatMode.Reverse), label = "glass-glow"
    )
    Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF06111F), Color(0xFF142A42), Color(0xFF130D2B))))) {
        Canvas(Modifier.fillMaxSize()) {
            drawCircle(glow.copy(alpha=.25f), radius=size.minDimension*.42f, center=Offset(size.width*.16f,size.height*.18f))
            drawCircle(Color(0xFF39E6FF).copy(alpha=.16f), radius=size.minDimension*.34f, center=Offset(size.width*.88f,size.height*.72f))
        }
        Box(Modifier.fillMaxSize().background(Color.White.copy(alpha=.035f)))
    }
}

@Composable
private fun ThreeDBackground() {
    Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF050914), Color(0xFF172946), Color(0xFF0A1022))))) {
        Canvas(Modifier.fillMaxSize()) {
            val step = 90f
            var y = -step
            while (y < size.height + step) {
                drawLine(Color.White.copy(alpha=.045f), Offset(0f,y), Offset(size.width,y+size.width*.18f), 2f)
                y += step
            }
            drawCircle(Color(0xFF55C9FF).copy(alpha=.16f), size.minDimension*.38f, Offset(size.width*.82f,size.height*.22f))
        }
    }
}

@Composable
private fun ParallaxBackground() {
    val context = LocalContext.current
    var x by remember { mutableFloatStateOf(0f) }
    var y by remember { mutableFloatStateOf(0f) }
    DisposableEffect(context) {
        val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR) ?: sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val listener = object : SensorEventListener {
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
            override fun onSensorChanged(event: SensorEvent) {
                val nx = event.values.getOrNull(0)?.coerceIn(-1f,1f) ?: 0f
                val ny = event.values.getOrNull(1)?.coerceIn(-1f,1f) ?: 0f
                x += (nx - x) * .08f; y += (ny - y) * .08f
            }
        }
        sensor?.let { sm.registerListener(listener, it, SensorManager.SENSOR_DELAY_GAME) }
        onDispose { sm.unregisterListener(listener) }
    }
    Box(Modifier.fillMaxSize().background(Color(0xFF050A18))) {
        Box(Modifier.fillMaxSize().graphicsLayer { translationX=x*32f; translationY=y*32f; scaleX=1.08f; scaleY=1.08f }
            .background(Brush.linearGradient(listOf(Color(0xFF071A38),Color(0xFF33205D),Color(0xFF06394A)))))
        Canvas(Modifier.fillMaxSize().graphicsLayer { translationX=-x*55f; translationY=-y*55f }) {
            drawCircle(Color(0xFF4FDFFF).copy(alpha=.20f), size.minDimension*.30f, Offset(size.width*.22f,size.height*.26f))
            drawCircle(Color(0xFFA16EFF).copy(alpha=.18f), size.minDimension*.26f, Offset(size.width*.82f,size.height*.70f))
        }
    }
}

@Composable
private fun CamaleonBackground() {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var sampled by remember { mutableStateOf(Color(0xFF38D9A9)) }
    val hasPermission = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
    DisposableEffect(hasPermission, lifecycleOwner) {
        if (!hasPermission) return@DisposableEffect onDispose { }
        val executor = Executors.newSingleThreadExecutor()
        val controller = LifecycleCameraController(context).apply {
            imageAnalysisBackpressureStrategy = ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST
            setImageAnalysisAnalyzer(executor) { image ->
                try {
                    if (image.planes.size >= 3) {
                        fun avg(index: Int): Int {
                            val b = image.planes[index].buffer
                            val n = b.remaining()
                            if (n <= 0) return 128
                            var sum = 0L
                            var count = 0
                            val step = (n / 64).coerceAtLeast(1)
                            var i = 0
                            while (i < n) {
                                sum += (b.get(i).toInt() and 0xff)
                                count++
                                i += step
                            }
                            return (sum / count.coerceAtLeast(1)).toInt()
                        }
                        val yy = avg(0)
                        val uu = avg(1) - 128
                        val vv = avg(2) - 128
                        val r = (yy + 1.402 * vv).toInt().coerceIn(0, 255)
                        val g = (yy - .344136 * uu - .714136 * vv).toInt().coerceIn(0, 255)
                        val bl = (yy + 1.772 * uu).toInt().coerceIn(0, 255)
                        sampled = Color(r, g, bl)
                    }
                } finally {
                    image.close()
                }
            }
        }
        runCatching { controller.bindToLifecycle(lifecycleOwner) }
        onDispose {
            controller.clearImageAnalysisAnalyzer()
            controller.unbind()
            executor.shutdown()
        }
    }
    Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF07110F), sampled.copy(alpha=.75f), Color(0xFF071327)))))
}
