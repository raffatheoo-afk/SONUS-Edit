package com.sonusstudios.streampulse.tools

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.arthenica.ffmpegkit.FFmpegKit
import com.sonusstudios.streampulse.core.MembershipTier
import com.sonusstudios.streampulse.core.commercialTier
import com.sonusstudios.streampulse.core.SonusStorage
import com.sonusstudios.streampulse.notifications.SonusNotificationCenter
import com.arthenica.ffmpegkit.ReturnCode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.*

enum class SonusLabModule { HOME, MASTER, MATCH, SOUND }

@Composable
internal fun SonusLabScreen(membershipTier: MembershipTier, sonusCoins: Int, onSpendCoins: suspend (Int) -> Boolean, onBack: () -> Unit, onTrack: (String, Boolean?, Long?) -> Unit) {
    var module by remember { mutableStateOf(SonusLabModule.HOME) }
    when (module) {
        SonusLabModule.HOME -> SonusLabHome(onBack) { module = it }
        SonusLabModule.MASTER -> SonusMasterScreen(membershipTier, sonusCoins, onSpendCoins, { module = SonusLabModule.HOME }, onTrack)
        SonusLabModule.MATCH -> SonusMatchScreen(membershipTier, sonusCoins, onSpendCoins, { module = SonusLabModule.HOME }, onTrack)
        SonusLabModule.SOUND -> SonusSoundTestScreen(membershipTier, sonusCoins, onSpendCoins, { module = SonusLabModule.HOME }, onTrack)
    }
}

@Composable
private fun SonusLabHome(onBack: () -> Unit, onOpen: (SonusLabModule) -> Unit) {
    val bg = Brush.verticalGradient(listOf(Color(0xFF07131D), Color(0xFF0B1724), Color(0xFF071018)))
    LazyColumn(Modifier.fillMaxSize().background(bg).padding(horizontal = 18.dp), contentPadding = PaddingValues(top = 14.dp, bottom = 34.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { PremiumHeader("SONUS LAB", "Áudio inteligente, análise e testes em um só lugar", onBack, Color(0xFF54D8FF)) }
        item { LabHeroCard("SONUS MASTER", "Diagnóstico, masterização segura e comparação antes/depois", Icons.Default.GraphicEq, listOf(Color(0xFF0E5064), Color(0xFF13293B)), { onOpen(SonusLabModule.MASTER) }) }
        item { LabHeroCard("SONUS MATCH", "Encontre faixas compatíveis por BPM, tom, energia e loudness", Icons.Default.Hub, listOf(Color(0xFF43366B), Color(0xFF18213B)), { onOpen(SonusLabModule.MATCH) }) }
        item { LabHeroCard("TESTE DE SOM", "Estéreo, frequências, fase, balanceamento e teste rápido", Icons.Default.Headphones, listOf(Color(0xFF5C3814), Color(0xFF1F2630)), { onOpen(SonusLabModule.SOUND) }) }
    }
}

@Composable
private fun PremiumHeader(title: String, subtitle: String, onBack: () -> Unit, accent: Color) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Voltar", tint = Color.White) }
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                Text(subtitle, color = Color.White.copy(.62f), fontSize = 12.sp)
            }
        }
        Box(Modifier.fillMaxWidth().height(2.dp).background(Brush.horizontalGradient(listOf(accent, Color.Transparent))))
    }
}

@Composable
private fun LabHeroCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, colors: List<Color>, onClick: () -> Unit) {
    Surface(Modifier.fillMaxWidth().height(154.dp).clickable(onClick = onClick), shape = RoundedCornerShape(28.dp), color = Color.Transparent, border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(.12f))) {
        Row(Modifier.background(Brush.linearGradient(colors)).padding(18.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Surface(Modifier.size(88.dp), RoundedCornerShape(26.dp), color = Color.Black.copy(.22f), border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(.16f))) {
                Box(contentAlignment = Alignment.Center) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(47.dp)) }
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text(title, color = Color.White, fontWeight = FontWeight.Black, fontSize = 20.sp)
                Text(subtitle, color = Color.White.copy(.72f), fontSize = 12.sp, lineHeight = 17.sp)
            }
            Icon(Icons.Default.ChevronRight, null, tint = Color.White.copy(.7f))
        }
    }
}

private data class MasterPreset(val id: String, val label: String, val filter: (Int) -> String)
private val masterPresets = listOf(
    MasterPreset("stream", "Streaming") { i -> val x=i/100.0; "highpass=f=28,equalizer=f=90:t=q:w=1.0:g=${1.0*x},equalizer=f=3200:t=q:w=1.1:g=${0.8*x},acompressor=threshold=-18dB:ratio=${1.7+0.8*x}:attack=15:release=180:makeup=${1.0+0.8*x},loudnorm=I=-14:LRA=9:TP=-1.0" },
    MasterPreset("loud", "Mais Volume") { i -> val x=i/100.0; "highpass=f=28,equalizer=f=75:t=q:w=1.0:g=${1.5*x},equalizer=f=2500:t=q:w=1.1:g=${1.0*x},acompressor=threshold=-20dB:ratio=${2.0+1.2*x}:attack=12:release=150:makeup=${1.2+1.8*x},alimiter=limit=0.89,loudnorm=I=-11:LRA=7:TP=-1.0" },
    MasterPreset("soft", "Suave") { i -> val x=i/100.0; "highpass=f=25,equalizer=f=140:t=q:w=1.1:g=${0.5*x},equalizer=f=5000:t=q:w=1.2:g=${-0.5*x},acompressor=threshold=-15dB:ratio=${1.25+0.45*x}:attack=28:release=260:makeup=${1.0+0.35*x},loudnorm=I=-16:LRA=11:TP=-1.2" },
    MasterPreset("voice", "Voz em Destaque") { i -> val x=i/100.0; "highpass=f=32,equalizer=f=220:t=q:w=1.0:g=${-0.7*x},equalizer=f=1800:t=q:w=1.1:g=${1.2*x},equalizer=f=3500:t=q:w=1.0:g=${1.7*x},acompressor=threshold=-18dB:ratio=${1.8+0.7*x}:attack=12:release=170:makeup=${1.0+0.8*x},alimiter=limit=0.92,loudnorm=I=-14:LRA=8:TP=-1.0" }
)

@Composable
private fun SonusMasterScreen(membershipTier: MembershipTier, sonusCoins: Int, onSpendCoins: suspend (Int) -> Boolean, onBack: () -> Unit, onTrack: (String, Boolean?, Long?) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var source by remember { mutableStateOf<Uri?>(null) }
    var analysis by remember { mutableStateOf<AudioDeepAnalysis?>(null) }
    var preset by remember { mutableStateOf(masterPresets.first()) }
    var intensity by remember { mutableFloatStateOf(65f) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Selecione uma música para começar") }
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    var processedPreview by remember { mutableStateOf<File?>(null) }
    var playingProcessed by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            source=u; analysis=null; processedPreview?.delete(); processedPreview=null; status="Analisando áudio…"; busy=true
            scope.launch {
                val a=withContext(Dispatchers.IO){runCatching{AudioToolEngine.analyze(context,u)}.getOrNull()}
                var usageOk=true
                if(a!=null){
                    if(membershipTier==MembershipTier.DIAMANTE) SonusNotificationCenter.recordPremiumUse(context,"SONUS Master • análise")
                    else { usageOk=onSpendCoins(1); if(usageOk) SonusNotificationCenter.recordPremiumUse(context,"SONUS Master • análise") }
                }
                analysis=if(usageOk)a else null; busy=false
                status=when { a==null -> "Não foi possível analisar o arquivo"; !usageOk -> "Análise concluída, mas não foi possível descontar a Moeda SONUS."; else -> "Diagnóstico concluído • 1 Moeda SONUS" }
                onTrack("Sonus Master • análise", a!=null&&usageOk, null)
            }
        }
    }
    val masterTierAllowed = commercialTier(membershipTier).ordinal >= MembershipTier.PRATA.ordinal || membershipTier == MembershipTier.FREE
    val masterUsageAvailable = membershipTier == MembershipTier.DIAMANTE || sonusCoins > 0
    fun performMasterExport(src: Uri) {
        val out = SonusStorage.createAudio(context, "Sonus_Master_${System.currentTimeMillis()}.wav", "audio/wav", SonusStorage.Bucket.MASTERS)
            ?: run { status = "Falha ao criar saída SONUS"; return }
        busy = true
        status = "Renderizando master…"
        SonusProcessNotifier.publish(context, "SONUS Master", 0)
        scope.launch {
            val ok = withContext(Dispatchers.IO) { renderMaster(context, src, out, preset.filter(intensity.roundToInt())) }
            if (ok) SonusStorage.finish(context, out) else SonusStorage.abort(context, out)
            var usageOk = true
            if (ok) {
                if (membershipTier == MembershipTier.DIAMANTE) {
                    SonusNotificationCenter.recordPremiumUse(context, "SONUS Master")
                } else {
                    usageOk = onSpendCoins(1)
                    if (usageOk) SonusNotificationCenter.recordPremiumUse(context, "SONUS Master")
                }
            }
            busy = false
            status = when {
                !ok -> "Falha ao exportar"
                !usageOk -> "Master salvo, mas não foi possível descontar a Moeda SONUS."
                else -> "Master salvo em SONUS/Masters"
            }
            if (ok) SonusProcessNotifier.publish(context, "SONUS Master", 100) else SonusProcessNotifier.fail(context, "SONUS Master")
            if (!ok) SonusProcessNotifier.clear(context, "SONUS Master")
            SonusNotificationCenter.add(
                context,
                if (ok) "SONUS Master concluído" else "Falha no SONUS Master",
                if (ok) "Seu master foi salvo em SONUS/Masters." else "A masterização não pôde ser concluída.",
                "FERRAMENTAS",
                importantExternal = false
            )
            onTrack("Sonus Master", ok, null)
        }
    }
    fun exportMaster() {
        val src = source ?: return
        when {
            !masterTierAllowed -> status = "SONUS Master completo está disponível no plano Prata ou superior."
            !masterUsageAvailable -> status = "Suas Moedas SONUS acabaram. Reponha uma moeda no FREE ou aguarde a renovação do plano."
            else -> performMasterExport(src)
        }
    }
    DisposableEffect(Unit){onDispose{runCatching{player?.release()};processedPreview?.delete()}}
    LazyColumn(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF06131B),Color(0xFF0B1B25)))).padding(horizontal=18.dp), contentPadding=PaddingValues(top=14.dp,bottom=34.dp), verticalArrangement=Arrangement.spacedBy(14.dp)){
        item{PremiumHeader("SONUS MASTER","Masterização com diagnóstico e proteção de pico",onBack,Color(0xFF50D5FF))}
        item{
            Surface(shape=RoundedCornerShape(28.dp),color=Color(0xFF0F2632),border=androidx.compose.foundation.BorderStroke(1.dp,Color(0xFF5DE0FF).copy(.25f))){
                Column(Modifier.fillMaxWidth().padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
                    Row(verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.AudioFile,null,tint=Color(0xFF63DDFF));Spacer(Modifier.width(10.dp));Text(source?.let{displayName(context,it)}?:"Nenhum arquivo",color=Color.White,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f));Button(enabled=masterUsageAvailable,onClick={picker.launch(arrayOf("audio/*"))}){Text(if(masterUsageAvailable) "Escolher • 1 uso" else "Sem usos")}}
                    MasterWave(analysis?.waveform?:List(80){((sin(it*.45)+1)/4).toFloat()})
                    if(analysis!=null){val a=analysis!!;Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){MetricChip("LUFS",a.loudnessLufs?.let{"%.1f".format(it)}?:"—");MetricChip("Pico",a.truePeakDbtp?.let{"%.1f dB".format(it)}?:a.peakDbfs?.let{"%.1f dB".format(it)}?:"—");MetricChip("Clipping",a.clippingPercent?.let{"%.2f%%".format(it)}?:"—")}}
                }
            }
        }
        item{Text("CARÁTER",color=Color(0xFF69DFFF),fontSize=11.sp,fontWeight=FontWeight.Black,letterSpacing=1.2.sp);LazyRow(horizontalArrangement=Arrangement.spacedBy(8.dp)){items(masterPresets){p->FilterChip(selected=p.id==preset.id,onClick={preset=p;processedPreview?.delete();processedPreview=null},label={Text(p.label)})}}}
        item{Column{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Intensidade",color=Color.White,fontWeight=FontWeight.Bold);Text("${intensity.roundToInt()}%",color=Color(0xFF65DFFF))};Slider(value=intensity,onValueChange={intensity=it},valueRange=20f..100f)}}
        item{
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){
                Button(enabled=source!=null&&!busy,onClick={val src=source?:return@Button;scope.launch{busy=true;status="Preparando prévia…";val f=withContext(Dispatchers.IO){renderMasterPreview(context,src,preset.filter(intensity.roundToInt()))};processedPreview?.delete();processedPreview=f;busy=false;status=if(f!=null)"Prévia pronta • toque Play" else "Falha na prévia"}},modifier=Modifier.weight(1f)){Icon(Icons.Default.AutoFixHigh,null);Spacer(Modifier.width(6.dp));Text("Preparar")}
                FilledTonalButton(enabled=source!=null&&!busy,onClick={val target=if(playingProcessed&&processedPreview!=null) Uri.fromFile(processedPreview) else source; if(target!=null){runCatching{player?.release()};val mp=MediaPlayer.create(context,target);player=mp;mp?.setOnCompletionListener{playingProcessed=false};mp?.start()}},modifier=Modifier.weight(1f)){Icon(Icons.Default.PlayArrow,null);Spacer(Modifier.width(6.dp));Text(if(playingProcessed)"Depois" else "Play")}
            }
        }
        if(processedPreview!=null){item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.Center){FilterChip(selected=!playingProcessed,onClick={playingProcessed=false},label={Text("Antes")});Spacer(Modifier.width(8.dp));FilterChip(selected=playingProcessed,onClick={playingProcessed=true},label={Text("Depois")})}}}
        item{Text(status,color=Color.White.copy(.66f),fontSize=12.sp,textAlign=TextAlign.Center,modifier=Modifier.fillMaxWidth())}
        item{Button(enabled=source!=null&&!busy,onClick={exportMaster()},modifier=Modifier.fillMaxWidth().height(54.dp)){Icon(Icons.Default.FileDownload,null);Spacer(Modifier.width(8.dp));Text(when { membershipTier==MembershipTier.DIAMANTE -> "EXPORTAR MASTER • ILIMITADO"; membershipTier==MembershipTier.OURO -> "EXPORTAR MASTER • 1 MOEDA SONUS"; membershipTier==MembershipTier.FREE -> "TESTAR MASTER • 1 MOEDA SONUS"; else -> "SONUS MASTER • OURO" },fontWeight=FontWeight.Black)}}
    }
}

@Composable private fun MasterWave(values:List<Float>){Canvas(Modifier.fillMaxWidth().height(92.dp)){val n=values.size.coerceAtLeast(1);val dx=size.width/n;values.forEachIndexed{i,v->val h=(v.coerceIn(.03f,1f)*size.height*.82f);drawLine(Color(0xFF61E0FF),Offset(i*dx,size.height/2-h/2),Offset(i*dx,size.height/2+h/2),strokeWidth=max(2f,dx*.55f),cap=StrokeCap.Round)}}}
@Composable private fun MetricChip(label:String,value:String){Surface(shape=RoundedCornerShape(14.dp),color=Color.Black.copy(.22f)){Column(Modifier.padding(horizontal=11.dp,vertical=8.dp),horizontalAlignment=Alignment.CenterHorizontally){Text(label,color=Color.White.copy(.55f),fontSize=9.sp);Text(value,color=Color.White,fontWeight=FontWeight.Bold,fontSize=12.sp)}}}

private data class MatchFeature(val uri:Uri,val name:String,val bpm:Int,val key:String,val energy:Double,val loudness:Double,val durationMs:Long)
@Composable
private fun SonusMatchScreen(membershipTier: MembershipTier, sonusCoins: Int, onSpendCoins: suspend (Int) -> Boolean, onBack:()->Unit, onTrack:(String,Boolean?,Long?)->Unit){
    val context=LocalContext.current;val scope=rememberCoroutineScope();var files by remember{mutableStateOf<List<Uri>>(emptyList())};var features by remember{mutableStateOf<List<MatchFeature>>(emptyList())};var busy by remember{mutableStateOf(false)};var mode by remember{mutableStateOf("Geral")};var usageMessage by remember{mutableStateOf<String?>(null)}
    val matchTierEligible = membershipTier.ordinal>=MembershipTier.PRATA.ordinal || membershipTier==MembershipTier.FREE
    val matchUsageAvailable = membershipTier==MembershipTier.DIAMANTE || sonusCoins>0
    val matchPro = matchTierEligible && matchUsageAvailable
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()){u->if(u.isNotEmpty()){val max=if(matchPro)40 else 6;files=u.take(max);busy=true;usageMessage=null;scope.launch{val analyzed=withContext(Dispatchers.IO){files.mapNotNull{analyzeMatch(context,it)}};var usageOk=true;if(analyzed.isNotEmpty()){if(membershipTier==MembershipTier.DIAMANTE)SonusNotificationCenter.recordPremiumUse(context,"SONUS Match") else {usageOk=onSpendCoins(1);if(usageOk)SonusNotificationCenter.recordPremiumUse(context,"SONUS Match")}};features=if(usageOk)analyzed else emptyList();busy=false;usageMessage=when{analyzed.isEmpty()->"Não foi possível analisar as faixas.";!usageOk->"Análise concluída, mas não foi possível descontar a Moeda SONUS.";else->"Análise concluída • 1 Moeda SONUS"};onTrack("Sonus Match",analyzed.isNotEmpty()&&usageOk,null)}}}
    val base=features.firstOrNull();val ranked=remember(features,mode){if(base==null) emptyList() else features.drop(1).map{it to matchScore(base,it,mode)}.sortedByDescending{it.second}.take(10)}
    LazyColumn(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF100C20),Color(0xFF09111C)))).padding(horizontal=18.dp),contentPadding=PaddingValues(top=14.dp,bottom=34.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        item{PremiumHeader("SONUS MATCH","Compatibilidade musical dentro da sua biblioteca",onBack,Color(0xFFAF8CFF))}
        item{Surface(shape=RoundedCornerShape(26.dp),color=Color(0xFF201B38)){Column(Modifier.fillMaxWidth().padding(18.dp)){Text(if(matchPro)"Escolha de 2 a 40 músicas" else "Free: referência + até 5 comparações",color=Color.White,fontWeight=FontWeight.Bold);Text("A primeira vira a referência. O Sonus compara BPM, tom, energia, loudness e duração.",color=Color.White.copy(.62f),fontSize=12.sp);Spacer(Modifier.height(12.dp));Button(enabled=matchUsageAvailable,onClick={picker.launch(arrayOf("audio/*"))},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.LibraryMusic,null);Spacer(Modifier.width(8.dp));Text(if(matchUsageAvailable) "Selecionar músicas • 1 uso" else "Sem Moedas SONUS")}}}}
        if(base!=null){item{Surface(shape=RoundedCornerShape(24.dp),color=Color(0xFF34295A)){Column(Modifier.padding(16.dp)){Text("REFERÊNCIA",color=Color(0xFFD8C8FF),fontSize=10.sp,fontWeight=FontWeight.Black);Text(base.name,color=Color.White,fontSize=18.sp,fontWeight=FontWeight.Black);Text("${base.bpm} BPM • ${base.key} • energia ${"%.0f".format(base.energy*100)}%",color=Color.White.copy(.68f),fontSize=12.sp)}}}}
        item{Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){(if(matchPro) listOf("Geral","Mix/DJ","Clima") else listOf("Geral")).forEach{m->FilterChip(selected=mode==m,onClick={mode=m},label={Text(m)})}}}
        if(!matchPro) item { Text(when { !matchUsageAvailable -> "Sem Moedas SONUS • reponha uma moeda no FREE ou aguarde a renovação."; commercialTier(membershipTier)==MembershipTier.PRATA -> "Modo básico • recursos completos do Match ficam no Prata ou superior."; else -> "Modo básico ativo • cada análise concluída consome 1 Moeda SONUS." },color=Color.White.copy(.58f),fontSize=11.sp,textAlign=TextAlign.Center,modifier=Modifier.fillMaxWidth())}
        if(busy)item{LinearProgressIndicator(Modifier.fillMaxWidth())}
        usageMessage?.let { item { Text(it,color=Color(0xFFCDBBFF),fontSize=11.sp,textAlign=TextAlign.Center,modifier=Modifier.fillMaxWidth()) } }
        items(ranked){(f,s)->Surface(shape=RoundedCornerShape(20.dp),color=Color.White.copy(.055f),border=androidx.compose.foundation.BorderStroke(1.dp,Color.White.copy(.08f))){Row(Modifier.fillMaxWidth().padding(14.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(48.dp).background(Brush.radialGradient(listOf(Color(0xFF9D78FF),Color(0xFF34295A))),CircleShape),contentAlignment=Alignment.Center){Text("${s.roundToInt()}%",color=Color.White,fontWeight=FontWeight.Black,fontSize=11.sp)};Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(f.name,color=Color.White,fontWeight=FontWeight.Bold,maxLines=1);Text("${f.bpm} BPM • ${f.key} • ${"%.1f".format(f.loudness)} dB",color=Color.White.copy(.58f),fontSize=11.sp)};Text(when{ s>=82->"Muito compatível";s>=65->"Compatível";else->"Pouco compatível"},color=Color(0xFFCDBBFF),fontSize=11.sp,fontWeight=FontWeight.Bold)}}}
    }
}

@Composable
private fun SonusSoundTestScreen(membershipTier:MembershipTier, sonusCoins:Int, onSpendCoins:suspend (Int)->Boolean, onBack:()->Unit, onTrack:(String,Boolean?,Long?)->Unit){
    val context=LocalContext.current;val scope=rememberCoroutineScope();var freq by remember{mutableFloatStateOf(440f)};var balance by remember{mutableFloatStateOf(0f)};var playing by remember{mutableStateOf(false)};var quick by remember{mutableStateOf(false)};var tone by remember{mutableStateOf<AudioTrack?>(null)};var usageRecorded by remember{mutableStateOf(false)};var usageMessage by remember{mutableStateOf<String?>(null)}
    val usageAvailable=membershipTier==MembershipTier.DIAMANTE||sonusCoins>0||usageRecorded
    fun stop(resetQuick:Boolean=true){playing=false;if(resetQuick)quick=false;runCatching{tone?.stop()};runCatching{tone?.release()};tone=null}
    fun recordSessionUse(){if(usageRecorded)return;usageRecorded=true;scope.launch{val ok=if(membershipTier==MembershipTier.DIAMANTE){SonusNotificationCenter.recordPremiumUse(context,"SONUS Teste de Som");true}else onSpendCoins(1).also{if(it)SonusNotificationCenter.recordPremiumUse(context,"SONUS Teste de Som")};if(ok){usageMessage="Sessão ativa • 1 Moeda SONUS";onTrack("Sonus Teste de Som",true,null)}else{usageRecorded=false;usageMessage="Não foi possível descontar a Moeda SONUS.";stop()}}}
    fun start(hz:Float,bal:Float=balance){if(!usageAvailable)return;stop(false);tone=createTone(hz,bal);tone?.play();playing=true;recordSessionUse()}
    DisposableEffect(Unit){onDispose{stop()}}
    LaunchedEffect(quick){if(quick){recordSessionUse();val seq=listOf(120f,440f,1000f,4000f,100f,8000f);for(h in seq){if(!quick)break;freq=h;runCatching{tone?.stop()};runCatching{tone?.release()};tone=createTone(h,balance);tone?.play();playing=true;delay(2200)};if(quick)stop()}}
    val output=remember{currentOutputLabel(context)}
    LazyColumn(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF171006),Color(0xFF10161D)))).padding(horizontal=18.dp),contentPadding=PaddingValues(top=14.dp,bottom=34.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
        item{PremiumHeader("TESTE DE SOM","Diagnóstico rápido para fones, Bluetooth e alto-falante",onBack,Color(0xFFFFB85C))}
        item{Surface(shape=RoundedCornerShape(26.dp),color=Color(0xFF2A2116)){Row(Modifier.fillMaxWidth().padding(16.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.SpeakerGroup,null,tint=Color(0xFFFFC36E));Spacer(Modifier.width(10.dp));Column{Text("Saída atual",color=Color.White.copy(.55f),fontSize=10.sp);Text(output,color=Color.White,fontWeight=FontWeight.Black)}}}}
        item{StereoMeter(balance,playing)}
        item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(enabled=usageAvailable,onClick={start(700f,-1f)},modifier=Modifier.weight(1f)){Text("L ESQUERDO")};OutlinedButton(enabled=usageAvailable,onClick={start(700f,1f)},modifier=Modifier.weight(1f)){Text("R DIREITO")}}}
        item{OutlinedButton(enabled=usageAvailable,onClick={stop(false);tone=createTone(700f,0f,true);tone?.play();playing=true;recordSessionUse()},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.SwapHoriz,null);Spacer(Modifier.width(6.dp));Text("TESTE DE FASE")}}
        item{Column{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Frequência",color=Color.White,fontWeight=FontWeight.Bold);Text("${freq.roundToInt()} Hz",color=Color(0xFFFFC36E),fontWeight=FontWeight.Black)};Slider(value=freq,onValueChange={freq=it;if(playing)start(it)},valueRange=40f..12000f)}}
        item{Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){listOf(80f to "Graves",800f to "Médios",6000f to "Agudos").forEach{(h,l)->FilterChip(selected=abs(freq-h)<5,onClick={freq=h;start(h)},label={Text(l)},enabled=usageAvailable)}}}
        item{Column{Text("Balanceamento L / R",color=Color.White,fontWeight=FontWeight.Bold);Slider(value=balance,onValueChange={balance=it;if(playing)start(freq,it)},valueRange=-1f..1f)}}
        item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){Button(enabled=usageAvailable,onClick={if(playing){stop()}else start(freq)},modifier=Modifier.weight(1f)){Icon(if(playing)Icons.Default.Stop else Icons.Default.PlayArrow,null);Spacer(Modifier.width(6.dp));Text(if(playing)"PARAR" else if(usageAvailable)"PLAY" else "SEM MOEDAS")};FilledTonalButton(enabled=usageAvailable,onClick={if(quick){stop()}else{quick=true;recordSessionUse()}},modifier=Modifier.weight(1f)){Icon(Icons.Default.Bolt,null);Spacer(Modifier.width(6.dp));Text("TESTE RÁPIDO")}}}
        usageMessage?.let{item{Text(it,color=Color(0xFFFFC36E),fontSize=11.sp,textAlign=TextAlign.Center,modifier=Modifier.fillMaxWidth())}}
        item{Text("Uma sessão do Teste de Som consome 1 Moeda SONUS. Comece com volume moderado; tons contínuos em volume alto podem ser desconfortáveis, principalmente em fones.",color=Color.White.copy(.52f),fontSize=11.sp,textAlign=TextAlign.Center,modifier=Modifier.fillMaxWidth())}
    }
}

@Composable private fun StereoMeter(balance:Float,active:Boolean){Canvas(Modifier.fillMaxWidth().height(120.dp)){val c=size.width/2;drawCircle(Color.White.copy(.08f),radius=min(size.width,size.height)*.36f,center=Offset(c,size.height/2),style=Stroke(3f));val x=c+balance*(size.width*.34f);drawCircle(if(active)Color(0xFFFFC05A)else Color.Gray,radius=16f,center=Offset(x,size.height/2));drawLine(Color.White.copy(.25f),Offset(size.width*.12f,size.height/2),Offset(size.width*.88f,size.height/2),2f);}}

@Composable
internal fun SonusAutoMixScreen(membershipTier:MembershipTier, sonusCoins:Int, onSpendCoins:suspend (Int)->Boolean, onBack:()->Unit,onTrack:(String,Boolean?,Long?)->Unit){
    val context=LocalContext.current;val scope=rememberCoroutineScope();var files by remember{mutableStateOf<List<Uri>>(emptyList())};var transition by remember{mutableFloatStateOf(6f)};var busy by remember{mutableStateOf(false)};var status by remember{mutableStateOf("Preparando acesso ao AutoMix…")};var mode by remember{mutableStateOf("Auto")};var preview by remember{mutableStateOf<File?>(null)};var player by remember{mutableStateOf<MediaPlayer?>(null)};var playing by remember{mutableStateOf(false)}
    val paidPlan = commercialTier(membershipTier) != MembershipTier.FREE
    var accessGranted by remember(membershipTier) { mutableStateOf(paidPlan) }
    var accessChecked by remember(membershipTier) { mutableStateOf(paidPlan) }
    var exporting by remember { mutableStateOf(false) }
    var exportProgress by remember { mutableIntStateOf(0) }
    LaunchedEffect(membershipTier) {
        if (paidPlan) {
            accessGranted = true
            accessChecked = true
            status = "AutoMix PRO liberado pelo seu plano"
        } else if (!accessChecked) {
            val ok = onSpendCoins(1)
            accessGranted = ok
            accessChecked = true
            if (ok) {
                status = "AutoMix liberado nesta sessão • 1 Moeda SONUS"
                SonusNotificationCenter.recordPremiumUse(context,"SONUS AutoMix • acesso")
            } else {
                status = "Sem Moedas SONUS para abrir o AutoMix."
            }
        }
    }
    val autoMixUsageAvailable = accessGranted
    val autoMixPro = paidPlan && accessGranted
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()){u->
        val chosen=u.take(if(autoMixPro)20 else 3)
        if(chosen.size>=2){busy=true;status="Analisando ordem ideal…";scope.launch{val ordered=withContext(Dispatchers.IO){autoOrderMix(context,chosen)};files=ordered;preview?.delete();preview=null;busy=false;status="${files.size} faixas organizadas pelo Sonus"}} else {files=chosen;status="Selecione pelo menos duas músicas"}
    }
    DisposableEffect(Unit){onDispose{runCatching{player?.release()};preview?.delete()}}
    fun exportAutoMix(){
        if(files.size<2||!autoMixUsageAvailable)return
        val out=SonusStorage.createAudio(context,"Sonus_AutoMix_${System.currentTimeMillis()}.wav","audio/wav",SonusStorage.Bucket.AUTOMIX) ?: run{status="Falha ao criar saída SONUS";return}
        busy=true; exporting=true; exportProgress=8; status="Preparando AutoMix…"; SonusProcessNotifier.publish(context,"SONUS AutoMix",0)
        scope.launch{
            exportProgress=18; status="Criando transições e mix…"
            val ok=withContext(Dispatchers.IO){renderAutoMix(context,files,out,transition)}
            exportProgress=90; status="Finalizando arquivo…"
            if(ok)SonusStorage.finish(context,out) else SonusStorage.abort(context,out)
            if(ok&&paidPlan)SonusNotificationCenter.recordPremiumUse(context,"SONUS AutoMix")
            exportProgress=100
            busy=false; exporting=false
            status=if(ok)"AutoMix salvo em SONUS/AutoMix" else "Falha ao criar AutoMix"
            if(ok)SonusProcessNotifier.publish(context,"SONUS AutoMix",100) else SonusProcessNotifier.fail(context,"SONUS AutoMix")
            SonusNotificationCenter.add(context,if(ok)"SONUS AutoMix concluído" else "Falha no SONUS AutoMix",if(ok)"Seu mix foi salvo em SONUS/AutoMix." else "O AutoMix não pôde ser concluído.","FERRAMENTAS",importantExternal=false)
            onTrack("Sonus AutoMix",ok,null)
        }
    }
    LazyColumn(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF07121A),Color(0xFF100B1A),Color(0xFF07121A)))).padding(horizontal=18.dp),contentPadding=PaddingValues(top=14.dp,bottom=34.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
        item{PremiumHeader("SONUS AUTOMIX","Mix contínuo com transições suaves e volume uniforme",onBack,Color(0xFF8BE8FF))}
        item{DeckPair(files.getOrNull(0)?.let{displayName(context,it)}?:"DECK A",files.getOrNull(1)?.let{displayName(context,it)}?:"DECK B")}
        item{Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){FilterChip(selected=mode=="Auto",onClick={mode="Auto"},label={Text("Automático")});if(autoMixPro)FilterChip(selected=mode=="Personalizado",onClick={mode="Personalizado"},label={Text("Personalizado")})}}
        if(!paidPlan) item { Text(if(!autoMixUsageAvailable) "Sem Moedas SONUS • reponha uma moeda no FREE ou aguarde a renovação." else "FREE • AutoMix liberado nesta sessão com 1 Moeda SONUS.",color=Color.White.copy(.58f),fontSize=11.sp,textAlign=TextAlign.Center,modifier=Modifier.fillMaxWidth())}
        item{Button(onClick={picker.launch(arrayOf("audio/*"))},enabled=accessChecked&&accessGranted&&!busy,modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.QueueMusic,null);Spacer(Modifier.width(8.dp));Text(if(accessGranted)"Selecionar músicas" else "AutoMix bloqueado")}}
        if(files.isNotEmpty())item{Column{Text("TIMELINE",color=Color(0xFF7DE4FF),fontSize=10.sp,fontWeight=FontWeight.Black);files.forEachIndexed{i,u->Row(Modifier.fillMaxWidth().padding(vertical=5.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(30.dp).background(Color(0xFF16384A),CircleShape),contentAlignment=Alignment.Center){Text("${i+1}",color=Color.White,fontSize=10.sp,fontWeight=FontWeight.Bold)};Spacer(Modifier.width(10.dp));Text(displayName(context,u),color=Color.White.copy(.85f),maxLines=1,modifier=Modifier.weight(1f));if(i<files.lastIndex)Text("↘ ${transition.roundToInt()}s",color=Color(0xFF7DE4FF),fontSize=10.sp)}}}}
        if(mode=="Personalizado")item{Column{Text("Transição ${transition.roundToInt()}s",color=Color.White,fontWeight=FontWeight.Bold);Slider(value=transition,onValueChange={transition=it},valueRange=3f..12f)}}
        if(busy && !exporting)item{LinearProgressIndicator(Modifier.fillMaxWidth())}
        item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){
            FilledTonalButton(enabled=files.size>=2&&!busy,onClick={scope.launch{busy=true;status="Preparando prévia do mix…";val f=withContext(Dispatchers.IO){renderAutoMixPreview(context,files,transition)};preview?.delete();preview=f;busy=false;status=if(f!=null)"Prévia pronta" else "Falha ao preparar prévia"}},modifier=Modifier.weight(1f)){Icon(Icons.Default.AutoFixHigh,null);Spacer(Modifier.width(5.dp));Text("Prévia")}
            Button(enabled=preview!=null&&!busy,onClick={if(playing){runCatching{player?.pause()};playing=false}else{if(player==null){player=MediaPlayer.create(context,Uri.fromFile(preview));player?.setOnCompletionListener{playing=false}};player?.start();playing=true}},modifier=Modifier.weight(1f)){Icon(if(playing)Icons.Default.Pause else Icons.Default.PlayArrow,null);Spacer(Modifier.width(5.dp));Text(if(playing)"Pausar" else "Play")}
        }}
        item{Text(status,color=Color.White.copy(.62f),fontSize=12.sp,textAlign=TextAlign.Center,modifier=Modifier.fillMaxWidth())}
        item{Button(enabled=files.size>=2&&!busy&&autoMixUsageAvailable,onClick={exportAutoMix()},modifier=Modifier.fillMaxWidth().height(56.dp)){Icon(Icons.Default.AutoAwesome,null);Spacer(Modifier.width(8.dp));Text(when{!autoMixUsageAvailable->"SEM MOEDAS SONUS";paidPlan->"CRIAR AUTOMIX • PRO";else->"CRIAR AUTOMIX • ACESSO LIBERADO"},fontWeight=FontWeight.Black)}}
    }
    if(exporting) SonusExportProgressDialog(percent=exportProgress,phase=status,title="SONUS AutoMix")
}

@Composable private fun DeckPair(a:String,b:String){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){listOf(a to "A",b to "B").forEach{(name,deck)->Surface(Modifier.weight(1f).height(142.dp),RoundedCornerShape(24.dp),color=Color(0xFF101F2C),border=androidx.compose.foundation.BorderStroke(1.dp,Color(0xFF6BDFFF).copy(.18f))){Column(Modifier.padding(14.dp),horizontalAlignment=Alignment.CenterHorizontally){Text("DECK $deck",color=Color(0xFF73E3FF),fontSize=10.sp,fontWeight=FontWeight.Black);Spacer(Modifier.height(8.dp));Icon(Icons.Default.Album,null,tint=Color.White,modifier=Modifier.size(48.dp));Spacer(Modifier.height(7.dp));Text(name,color=Color.White,fontWeight=FontWeight.Bold,maxLines=1,fontSize=11.sp)}}}}}

private fun renderMaster(context:Context,input:Uri,output:Uri,filter:String):Boolean=runCatching{val src=cacheAudio(context,input,"master");val dst=File(context.cacheDir,"sonus_master_${System.nanoTime()}.wav");val s=FFmpegKit.execute("-y -i '${esc(src.absolutePath)}' -vn -af '${esc(filter)}' -c:a pcm_s24le -ar 48000 '${esc(dst.absolutePath)}'");if(!ReturnCode.isSuccess(s.returnCode))error("ffmpeg");SonusStorage.openOutput(context,output)!!.use{o->dst.inputStream().use{it.copyTo(o)}};src.delete();dst.delete();true}.getOrDefault(false)
private fun renderMasterPreview(context:Context,input:Uri,filter:String):File?=runCatching{val src=cacheAudio(context,input,"preview");val dst=File(context.cacheDir,"sonus_master_preview_${System.nanoTime()}.wav");val s=FFmpegKit.execute("-y -t 35 -i '${esc(src.absolutePath)}' -vn -af '${esc(filter)}' -c:a pcm_s16le '${esc(dst.absolutePath)}'");src.delete();if(!ReturnCode.isSuccess(s.returnCode))error("ffmpeg");dst}.getOrNull()
private fun renderAutoMix(context:Context,inputs:List<Uri>,out:Uri,fade:Float):Boolean=runCatching{
    val cached=inputs.mapIndexed{i,u->cacheAudio(context,u,"mix$i")};val features=inputs.map{analyzeMatch(context,it)}
    val dst=File(context.cacheDir,"automix_${System.nanoTime()}.wav");val inputArgs=cached.joinToString(" "){"-i '${esc(it.absolutePath)}'"}
    val targetBpm=features.mapNotNull{it?.bpm}.sorted().let{if(it.isEmpty())120 else it[it.size/2]}
    val parts=mutableListOf<String>()
    for(i in cached.indices){val bpm=features.getOrNull(i)?.bpm?:targetBpm;val ratio=(targetBpm.toDouble()/bpm.coerceAtLeast(1)).coerceIn(.94,1.06);parts += "[$i:a]atempo=${"%.4f".format(java.util.Locale.US,ratio)},dynaudnorm=f=150:g=9[p$i]"}
    var prev="[p0]";for(i in 1 until cached.size){val label="m$i";parts += "$prev[p$i]acrossfade=d=${"%.2f".format(java.util.Locale.US,fade)}:c1=qsin:c2=qsin[$label]";prev="[$label]"}
    parts += "$prev loudnorm=I=-14:LRA=9:TP=-1.0,alimiter=limit=0.93[out]"
    val cmd="-y $inputArgs -filter_complex '${esc(parts.joinToString(";"))}' -map '[out]' -c:a pcm_s16le '${esc(dst.absolutePath)}'";val session=FFmpegKit.execute(cmd);if(!ReturnCode.isSuccess(session.returnCode))error(session.allLogsAsString.orEmpty().takeLast(300));SonusStorage.openOutput(context,out)!!.use{o->dst.inputStream().use{it.copyTo(o)}};cached.forEach{it.delete()};dst.delete();true
}.getOrDefault(false)

private fun renderAutoMixPreview(context:Context,inputs:List<Uri>,fade:Float):File?=runCatching{val take=inputs.take(4);val cached=take.mapIndexed{i,u->cacheAudio(context,u,"mixprev$i")};val dst=File(context.cacheDir,"automix_preview_${System.nanoTime()}.wav");val inputArgs=cached.joinToString(" "){"-t 35 -i '${esc(it.absolutePath)}'"};val parts=mutableListOf<String>();var prev="[0:a]";for(i in 1 until cached.size){val label="p$i";parts += "$prev[$i:a]acrossfade=d=${"%.2f".format(java.util.Locale.US,fade)}:c1=tri:c2=tri[$label]";prev="[$label]"};parts += "$prev loudnorm=I=-14:LRA=9:TP=-1.0,alimiter=limit=0.93[out]";val s=FFmpegKit.execute("-y $inputArgs -filter_complex '${esc(parts.joinToString(";"))}' -map '[out]' -c:a pcm_s16le '${esc(dst.absolutePath)}'");cached.forEach{it.delete()};if(!ReturnCode.isSuccess(s.returnCode))error("ffmpeg");dst}.getOrNull()
private fun autoOrderMix(context:Context,uris:List<Uri>):List<Uri>{
    if(uris.size<3)return uris
    val features=uris.mapNotNull{u->analyzeMatch(context,u)?.let{u to it}}
    if(features.size<2)return uris
    val remaining=features.toMutableList();val ordered=mutableListOf<Pair<Uri,MatchFeature>>();ordered+=remaining.removeAt(0)
    while(remaining.isNotEmpty()){val last=ordered.last().second;val idx=remaining.indices.maxByOrNull{i->matchScore(last,remaining[i].second,"Mix/DJ")}?:0;ordered+=remaining.removeAt(idx)}
    val known=ordered.map{it.first};return known + uris.filterNot{it in known}
}
private fun analyzeMatch(context:Context,uri:Uri):MatchFeature?=runCatching{val pcm=decodeMatchPcm(context,uri,11025,38)?:return@runCatching null;val bpm=estimateBpm(pcm,11025);val key=estimateKey(pcm,11025);var sum=0.0;for(v in pcm){val x=v/32768.0;sum+=x*x};val energy=sqrt(sum/pcm.size.coerceAtLeast(1)).coerceIn(0.0,1.0);val loud=20*log10(energy.coerceAtLeast(1e-6));val r=MediaMetadataRetriever();var dur=0L;runCatching{r.setDataSource(context,uri);dur=r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()?:0L};runCatching{r.release()};MatchFeature(uri,displayName(context,uri),bpm,key,energy,loud,dur)}.getOrNull()
private fun matchScore(a:MatchFeature,b:MatchFeature,mode:String):Double{val bpm=(1-abs(a.bpm-b.bpm)/80.0).coerceIn(0.0,1.0);val key=if(a.key==b.key)1.0 else .55;val energy=(1-abs(a.energy-b.energy)*4).coerceIn(0.0,1.0);val loud=(1-abs(a.loudness-b.loudness)/18).coerceIn(0.0,1.0);val dur=(1-abs(a.durationMs-b.durationMs)/300000.0).coerceIn(0.0,1.0);return 100*when(mode){"Mix/DJ"->bpm*.50+key*.30+energy*.12+loud*.08;"Clima"->energy*.46+loud*.27+bpm*.17+key*.10;else->bpm*.30+key*.22+energy*.22+loud*.16+dur*.10}}
private fun estimateBpm(pcm:ShortArray,sr:Int):Int{val frame=512;val e=DoubleArray(pcm.size/frame);for(f in e.indices){var s=0.0;for(i in f*frame until min(pcm.size,(f+1)*frame)){val x=pcm[i]/32768.0;s+=x*x};e[f]=sqrt(s/frame)};val onset=DoubleArray(e.size);for(i in 1 until e.size)onset[i]=max(0.0,e[i]-e[i-1]);val rate=sr.toDouble()/frame;var best=120;var score=-1.0;for(b in 60..190){val lag=(rate*60/b).roundToInt().coerceAtLeast(1);var x=0.0;for(i in lag until onset.size)x+=onset[i]*onset[i-lag];if(x>score){score=x;best=b}};return best}
private fun estimateKey(pcm:ShortArray,sr:Int):String{val names=arrayOf("C","C#","D","D#","E","F","F#","G","G#","A","A#","B");val chroma=DoubleArray(12);val n=2048;var pos=0;while(pos+n<pcm.size){for(pc in 0..11){for(o in 2..5){val midi=12*(o+1)+pc;val hz=440.0*2.0.pow((midi-69)/12.0);if(hz<sr/2)chroma[pc]+=goertzelMatch(pcm,pos,n,sr,hz)}};pos+=4096};return names[chroma.indices.maxByOrNull{chroma[it]}?:0]}
private fun goertzelMatch(data:ShortArray,start:Int,n:Int,sr:Int,hz:Double):Double{val w=2*PI*hz/sr;val c=2*cos(w);var s0:Double;var s1=0.0;var s2=0.0;var i=0;while(i<n){s0=data[start+i]/32768.0+c*s1-s2;s2=s1;s1=s0;i+=2};return s1*s1+s2*s2-c*s1*s2}
private fun decodeMatchPcm(context:Context,uri:Uri,sr:Int,seconds:Int):ShortArray?=runCatching{val src=cacheAudio(context,uri,"match");val raw=File(context.cacheDir,"match_${System.nanoTime()}.pcm");val s=FFmpegKit.execute("-y -t $seconds -i '${esc(src.absolutePath)}' -vn -ac 1 -ar $sr -f s16le '${esc(raw.absolutePath)}'");src.delete();if(!ReturnCode.isSuccess(s.returnCode))error("ffmpeg");val bytes=raw.readBytes();raw.delete();ShortArray(bytes.size/2).also{ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(it)}}.getOrNull()
private fun cacheAudio(context:Context,uri:Uri,prefix:String):File{val ext=displayName(context,uri).substringAfterLast('.',"bin").take(8);val f=File(context.cacheDir,"${prefix}_${System.nanoTime()}.$ext");context.contentResolver.openInputStream(uri)!!.use{i->f.outputStream().use{i.copyTo(it)}};return f}
private fun displayName(context:Context,uri:Uri):String{var n="Áudio";context.contentResolver.query(uri,arrayOf(OpenableColumns.DISPLAY_NAME),null,null,null)?.use{c->if(c.moveToFirst()){val i=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(i>=0)n=c.getString(i)?:n}};return n}
private fun esc(s:String)=s.replace("'","'\\''")
private fun currentOutputLabel(context:Context):String{val am=context.getSystemService(Context.AUDIO_SERVICE) as AudioManager;return runCatching{val d=am.getDevices(AudioManager.GET_DEVICES_OUTPUTS);when{d.any{it.type==android.media.AudioDeviceInfo.TYPE_BLUETOOTH_A2DP||it.type==android.media.AudioDeviceInfo.TYPE_BLE_HEADSET}->"Bluetooth";d.any{it.type==android.media.AudioDeviceInfo.TYPE_WIRED_HEADPHONES||it.type==android.media.AudioDeviceInfo.TYPE_WIRED_HEADSET}->"Fones com fio";else->"Alto-falante / saída do aparelho"}}.getOrDefault("Saída do aparelho")}
private fun createTone(hz:Float,balance:Float,phaseInvertRight:Boolean=false):AudioTrack{val sr=44100;val secs=12;val samples=ShortArray(sr*secs);val amp=(Short.MAX_VALUE*.12).toInt();for(i in samples.indices)samples[i]=(sin(2*PI*i*hz/sr)*amp).toInt().toShort();val mono=ByteBuffer.allocate(samples.size*4).order(ByteOrder.LITTLE_ENDIAN);val l=((1-balance)/2).coerceIn(0f,1f);val r=((1+balance)/2).coerceIn(0f,1f);for(s in samples){mono.putShort((s*l).toInt().toShort());val rv=(s*r).toInt().toShort();mono.putShort(if(phaseInvertRight)(-rv.toInt()).toShort() else rv)};return AudioTrack.Builder().setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()).setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build()).setBufferSizeInBytes(mono.array().size).setTransferMode(AudioTrack.MODE_STATIC).build().apply{write(mono.array(),0,mono.array().size);setLoopPoints(0,samples.size,-1)}}

private fun statusToast(context:Context,message:String){android.widget.Toast.makeText(context,message,android.widget.Toast.LENGTH_SHORT).show()}
