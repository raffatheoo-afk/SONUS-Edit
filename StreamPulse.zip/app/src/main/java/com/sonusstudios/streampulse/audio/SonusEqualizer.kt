package com.sonusstudios.streampulse.audio

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.util.Locale
import kotlin.math.abs

/**
 * Equalizador padrão do SONUS (mesmas 10 bandas e presets do Conversor de Áudio), compartilhado por todas
 * as funções que convertem áudio ou vídeo. [chain] é a cadeia de filtros FFmpeg ("" = desligado).
 */
internal data class SonusEqState(
    val enabled: Boolean = false,
    val presetName: String = "Flat",
    val bassDb: Double = 0.0,
    val midDb: Double = 0.0,
    val trebleDb: Double = 0.0
) {
    val finalBands: List<Double>
        get() {
            val base = SonusEqualizer.presets[presetName] ?: SonusEqualizer.presets.getValue("Flat")
            return base.mapIndexed { i, v ->
                val region = when (i) { in 0..3 -> bassDb; in 4..6 -> midDb; else -> trebleDb }
                (v + region).coerceIn(-12.0, 6.0)
            }
        }
    val chain: String get() = if (enabled) SonusEqualizer.filterChain(finalBands) else ""
}

internal object SonusEqualizer {
    val bandsHz = listOf(32, 64, 125, 250, 500, 1000, 2000, 4000, 8000, 16000)
    val presets = linkedMapOf(
        "Flat" to listOf(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
        "Rock" to listOf(0.0, -0.530, -2.259, -4.281, -5.493, -6.564, -4.752, -2.716, -0.901, -0.337),
        "Pop" to listOf(-7.213, -6.232, -4.382, -2.258, 0.0, -0.040, -2.265, -4.077, -5.822, -7.363),
        "Classical" to listOf(0.0, -0.872, -2.197, -4.184, -6.156, -5.733, -4.510, -2.850, -1.410, -0.964),
        "Hip-Hop" to listOf(0.0, -0.235, -1.203, -3.799, -6.432, -6.994, -5.662, -4.968, -4.003, -1.329),
        "Jazz" to listOf(-3.826, -3.670, -3.263, -2.812, -3.525, -4.614, -4.027, -2.569, -1.162, 0.0)
    )

    /** Mesma regra do motor de conversão: reduz o ganho geral antes dos reforços, para evitar clipping. */
    fun filterChain(bandsDb: List<Double>): String {
        val filters = mutableListOf<String>()
        val maxBoost = bandsDb.maxOrNull()?.coerceAtLeast(0.0) ?: 0.0
        if (maxBoost > 0.01) filters += "volume=${String.format(Locale.US, "%.2f", -maxBoost)}dB"
        bandsHz.zip(bandsDb).forEach { (hz, gain) ->
            if (abs(gain) >= .02) filters += "equalizer=f=$hz:t=o:w=1:g=${String.format(Locale.US, "%.2f", gain.coerceIn(-12.0, 6.0))}"
        }
        return filters.joinToString(",")
    }

    fun presetColor(name: String): Color = when (name) {
        "Rock" -> Color(0xFFEF5350); "Pop" -> Color(0xFFAB47BC); "Hip-Hop" -> Color(0xFFFFA726)
        "Jazz" -> Color(0xFF42A5F5); "Classical" -> Color(0xFF66BB6A); else -> Color(0xFF5C6BC0)
    }
}

/** Painel compacto do equalizador: liga/desliga, presets, curva e ajuste rápido de graves/médios/agudos. */
@Composable
internal fun SonusEqPanel(state: SonusEqState, onChange: (SonusEqState) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Ativar equalizador", Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
            Switch(checked = state.enabled, onCheckedChange = { onChange(state.copy(enabled = it)) })
        }
        if (state.enabled) {
            Text("10 bandas • 32 Hz → 16 kHz", style = MaterialTheme.typography.bodySmall)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                items(SonusEqualizer.presets.keys.toList()) { name ->
                    FilterChip(selected = state.presetName == name, onClick = { onChange(state.copy(presetName = name)) }, label = { Text(name) })
                }
            }
            val bands = state.finalBands
            val color = SonusEqualizer.presetColor(state.presetName)
            Canvas(Modifier.fillMaxWidth().height(56.dp)) {
                val path = Path()
                bands.forEachIndexed { i, v ->
                    val x = size.width * i / (bands.size - 1).coerceAtLeast(1)
                    val y = size.height / 2f - (v.toFloat() / 12f) * size.height / 2f
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                drawLine(color.copy(alpha = .25f), Offset(0f, size.height / 2f), Offset(size.width, size.height / 2f), 2f)
                drawPath(path, color, style = Stroke(width = 5f))
            }
            EqRegionSlider("Graves", state.bassDb) { onChange(state.copy(bassDb = it)) }
            EqRegionSlider("Médios", state.midDb) { onChange(state.copy(midDb = it)) }
            EqRegionSlider("Agudos", state.trebleDb) { onChange(state.copy(trebleDb = it)) }
            OutlinedButton(onClick = { onChange(SonusEqState(enabled = true)) }, modifier = Modifier.fillMaxWidth()) { Text("Zerar equalizador") }
        }
    }
}

@Composable
private fun EqRegionSlider(label: String, value: Double, onValue: (Double) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.width(64.dp), style = MaterialTheme.typography.labelMedium)
        Slider(value = value.toFloat(), onValueChange = { onValue(it.toDouble()) }, valueRange = -6f..6f, modifier = Modifier.weight(1f))
        Text(String.format(Locale.US, "%+.1f", value), Modifier.width(44.dp), style = MaterialTheme.typography.labelSmall)
    }
}
