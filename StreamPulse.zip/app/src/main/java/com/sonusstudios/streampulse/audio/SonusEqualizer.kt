package com.sonusstudios.streampulse.audio

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.util.Locale
import kotlin.math.abs

/**
 * Equalizador padrão do SONUS (mesmas 10 bandas e presets do Conversor de Áudio), compartilhado por todas
 * as funções que convertem áudio ou vídeo. [chain] é a cadeia de filtros FFmpeg ("" = desligado).
 */
internal data class SonusEqState(
    val enabled: Boolean = false,
    val presetName: String = "Neutro",
    val bassDb: Double = 0.0,
    val midDb: Double = 0.0,
    val trebleDb: Double = 0.0,
    val volumeExtraDb: Double = 0.0
) {
    val finalBands: List<Double>
        get() {
            val normalized = if (presetName == "Flat") "Neutro" else presetName
            val base = SonusEqualizer.presets[normalized] ?: SonusEqualizer.presets.getValue("Neutro")
            return base.mapIndexed { i, v ->
                val region = when (i) { in 0..3 -> bassDb; in 4..6 -> midDb; else -> trebleDb }
                (v + region).coerceIn(-12.0, 6.0)
            }
        }
    val chain: String get() = SonusEqualizer.filterChain(finalBands, volumeExtraDb, enabled)
}

internal object SonusEqualizer {
    val bandsHz = SonusEqPresetCatalog.bandsHz
    val presets: LinkedHashMap<String, List<Double>> = SonusEqPresetCatalog.curves

    /** Preamp independente do EQ. O compressor controla a média e o limiter segura os picos. */
    fun filterChain(bandsDb: List<Double>, volumeExtraDb: Double = 0.0, eqEnabled: Boolean = true): String {
        val filters = mutableListOf<String>()
        if (eqEnabled) {
            val maxBoost = bandsDb.maxOrNull()?.coerceAtLeast(0.0) ?: 0.0
            if (maxBoost > 0.01) filters += "volume=${String.format(Locale.US, "%.2f", -maxBoost)}dB"
            bandsHz.zip(bandsDb).forEach { (hz, gain) ->
                if (abs(gain) >= .02) filters += "equalizer=f=$hz:t=o:w=1:g=${String.format(Locale.US, "%.2f", gain.coerceIn(-12.0, 6.0))}"
            }
        }
        val extra = volumeExtraDb.coerceIn(0.0, 12.0)
        if (extra > 0.01) {
            filters += "volume=${String.format(Locale.US, "%.2f", extra)}dB"
            filters += "acompressor=threshold=0.45:ratio=2.2:attack=12:release=160:knee=4:makeup=1.12"
            filters += "alimiter=limit=0.94:attack=5:release=90:latency=true:level=false"
        }
        return filters.joinToString(",")
    }

    fun presetColor(name: String): Color = when {
        name.contains("Rock", true) || name == "Metal" -> Color(0xFFEF5350)
        name.contains("Pop", true) || name.contains("Dance", true) -> Color(0xFFAB47BC)
        name.contains("Hip", true) || name.contains("Trap", true) -> Color(0xFFFFA726)
        name.contains("Jazz", true) || name.contains("Blues", true) -> Color(0xFF42A5F5)
        name.contains("Clássico", true) || name.contains("Orquestral", true) -> Color(0xFF66BB6A)
        name.contains("Vocal", true) || name.contains("Podcast", true) -> Color(0xFFFF8A65)
        else -> Color(0xFF5C6BC0)
    }
}

/** Painel compacto do equalizador: liga/desliga, presets, curva e ajuste rápido de graves/médios/agudos. */
@Composable
internal fun SonusEqPanel(state: SonusEqState, onChange: (SonusEqState) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Ativar equalizador", Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
            Switch(checked = state.enabled, onCheckedChange = { onChange(state.copy(enabled = it)) })
        }
        Text("Presets manuais • ${SonusEqualizer.presets.size} opções", style = MaterialTheme.typography.bodySmall)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            items(SonusEqPresetCatalog.manualPresetNames) { name ->
                FilterChip(selected = state.presetName == name, onClick = { onChange(state.copy(enabled = true, presetName = name, bassDb = 0.0, midDb = 0.0, trebleDb = 0.0)) }, label = { Text(name) })
            }
        }
        if (state.enabled) {
            Text("10 bandas • 32 Hz → 16 kHz", style = MaterialTheme.typography.bodySmall)
            val bands = state.finalBands
            val color = SonusEqualizer.presetColor(state.presetName)
            Canvas(Modifier.fillMaxWidth().height(56.dp)) {
                val path = Path()
                bands.forEachIndexed { i, v ->
                    val x = size.width * i / (bands.size - 1).coerceAtLeast(1)
                    val y = size.height / 2f - (v.toFloat() / 12f) * size.height / 2f
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                drawLine(color.copy(alpha = .25f), Offset(0f, size.height / 2f), Offset(size.width, size.height / 2f), 2f)
                drawPath(path, color, style = Stroke(width = 5f))
            }
            EqRegionSlider("Graves", state.bassDb) { onChange(state.copy(bassDb = it)) }
            EqRegionSlider("Médios", state.midDb) { onChange(state.copy(midDb = it)) }
            EqRegionSlider("Agudos", state.trebleDb) { onChange(state.copy(trebleDb = it)) }
            OutlinedButton(onClick = { onChange(SonusEqState(enabled = true, volumeExtraDb = state.volumeExtraDb)) }, modifier = Modifier.fillMaxWidth()) { Text("Zerar equalizador") }
        }
        Surface(color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .45f), shape = RoundedCornerShape(12.dp)) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("VOLUME EXTRA", modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                    Text(String.format(Locale.US, "+%.1f dB", state.volumeExtraDb), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                }
                Slider(value = state.volumeExtraDb.toFloat(), onValueChange = { onChange(state.copy(volumeExtraDb = it.toDouble())) }, valueRange = 0f..12f)
                Text("Pré-ganho com compressor e limiter. Independente do equalizador.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .62f))
            }
        }
    }
}

@Composable
private fun EqRegionSlider(label: String, value: Double, onValue: (Double) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.width(64.dp), style = MaterialTheme.typography.labelMedium)
        Slider(value = value.toFloat(), onValueChange = { onValue(it.toDouble()) }, valueRange = -6f..6f, modifier = Modifier.weight(1f))
        Text(String.format(Locale.US, "%+.1f", value), Modifier.width(44.dp), style = MaterialTheme.typography.labelSmall)
    }
}
