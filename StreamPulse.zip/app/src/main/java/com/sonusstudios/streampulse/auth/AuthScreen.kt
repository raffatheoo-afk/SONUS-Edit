package com.sonusstudios.streampulse.auth

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonusstudios.streampulse.R
import kotlinx.coroutines.launch

private enum class AuthMode { LOGIN, CREATE }

@Composable
fun StreamPulseAuthScreen(
    authManager: AuthManager,
    onContinueAsGuest: () -> Unit = {},
    showGuestOption: Boolean = true
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var mode by rememberSaveable { mutableStateOf(AuthMode.LOGIN) }
    var email by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }
    var confirmPassword by rememberSaveable { mutableStateOf("") }
    var passwordVisible by rememberSaveable { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var messageSuccess by remember { mutableStateOf(false) }
    var showResetDialog by remember { mutableStateOf(false) }

    fun runAuth(block: suspend () -> Result<Unit>) {
        if (busy) return
        scope.launch {
            busy = true
            message = null
            val result = block()
            if (result.isFailure) {
                messageSuccess = false
                message = result.exceptionOrNull()?.message ?: "Não foi possível continuar."
            }
            busy = false
        }
    }

    if (showResetDialog) {
        var resetEmail by remember(email) { mutableStateOf(email) }
        var resetBusy by remember { mutableStateOf(false) }
        var resetMessage by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { if (!resetBusy) showResetDialog = false },
            title = { Text("Recuperar senha", fontWeight = FontWeight.ExtraBold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Informe o e-mail da sua conta. O Firebase enviará as instruções de redefinição.")
                    OutlinedTextField(
                        value = resetEmail,
                        onValueChange = { resetEmail = it.take(180) },
                        label = { Text("E-mail") },
                        leadingIcon = { Icon(Icons.Default.Email, null) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    resetMessage?.let { Text(it, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall) }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = !resetBusy,
                    onClick = {
                        scope.launch {
                            resetBusy = true
                            val result = authManager.sendPasswordReset(resetEmail)
                            resetMessage = if (result.isSuccess) {
                                "E-mail enviado. Confira também a caixa de spam."
                            } else {
                                result.exceptionOrNull()?.message ?: "Não foi possível enviar o e-mail."
                            }
                            resetBusy = false
                        }
                    }
                ) { Text(if (resetBusy) "Enviando..." else "Enviar") }
            },
            dismissButton = { TextButton(enabled = !resetBusy, onClick = { showResetDialog = false }) { Text("Fechar") } }
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF090B18), Color(0xFF17113A), Color(0xFF09172C))
                )
            )
            .padding(horizontal = 22.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Spacer(Modifier.height(28.dp))
            Surface(
                shape = CircleShape,
                color = Color.White.copy(alpha = .08f),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = .14f))
            ) {
                Image(
                    painter = painterResource(R.drawable.sonus_symbol_official),
                    contentDescription = "SONUS",
                    modifier = Modifier.padding(12.dp).size(72.dp).clip(CircleShape)
                )
            }
            Spacer(Modifier.height(16.dp))
            Text("SONUS", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 30.sp)
            Text(
                if (mode == AuthMode.LOGIN) "Bem-vindo de volta" else "Crie sua conta",
                color = Color.White.copy(alpha = .78f),
                fontSize = 16.sp
            )
            Text(
                "Seus projetos, dados e ferramentas em um só lugar.",
                color = Color.White.copy(alpha = .58f),
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.bodySmall
            )
            Spacer(Modifier.height(22.dp))

            Surface(
                shape = RoundedCornerShape(28.dp),
                color = Color(0xFF111528).copy(alpha = .96f),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = .10f)),
                tonalElevation = 8.dp
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = { runAuth { authManager.signInWithGoogle(context) } },
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = .28f))
                    ) {
                        Surface(shape = CircleShape, color = Color.White) {
                            Text("G", color = Color(0xFF202124), fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp))
                        }
                        Spacer(Modifier.width(10.dp))
                        Text("Continuar com Google", fontWeight = FontWeight.Bold)
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        HorizontalDivider(Modifier.weight(1f), color = Color.White.copy(alpha = .10f))
                        Text("  ou  ", color = Color.White.copy(alpha = .42f), style = MaterialTheme.typography.labelSmall)
                        HorizontalDivider(Modifier.weight(1f), color = Color.White.copy(alpha = .10f))
                    }

                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it.take(180) },
                        label = { Text("E-mail") },
                        leadingIcon = { Icon(Icons.Default.Email, null) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        singleLine = true,
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it.take(120) },
                        label = { Text("Senha") },
                        leadingIcon = { Icon(Icons.Default.Lock, null) },
                        trailingIcon = {
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility, null)
                            }
                        },
                        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        singleLine = true,
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (mode == AuthMode.CREATE) {
                        OutlinedTextField(
                            value = confirmPassword,
                            onValueChange = { confirmPassword = it.take(120) },
                            label = { Text("Confirmar senha") },
                            leadingIcon = { Icon(Icons.Default.Lock, null) },
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            singleLine = true,
                            enabled = !busy,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    if (mode == AuthMode.LOGIN) {
                        TextButton(
                            onClick = { showResetDialog = true },
                            enabled = !busy,
                            modifier = Modifier.align(Alignment.End)
                        ) { Text("Esqueci minha senha") }
                    }

                    message?.let {
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = (if (messageSuccess) Color(0xFF27AE60) else Color(0xFFE67E22)).copy(alpha = .14f)
                        ) {
                            Text(
                                it,
                                modifier = Modifier.padding(11.dp),
                                color = Color.White.copy(alpha = .90f),
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }

                    Button(
                        onClick = {
                            if (mode == AuthMode.CREATE && password != confirmPassword) {
                                messageSuccess = false
                                message = "As duas senhas precisam ser iguais."
                            } else {
                                runAuth {
                                    if (mode == AuthMode.LOGIN) authManager.signInWithEmail(email, password)
                                    else authManager.createAccount(email, password)
                                }
                            }
                        },
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth().height(52.dp)
                    ) {
                        if (busy) {
                            CircularProgressIndicator(Modifier.size(21.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                            Spacer(Modifier.width(9.dp))
                        }
                        Text(
                            when {
                                busy -> "Aguarde..."
                                mode == AuthMode.LOGIN -> "Entrar com e-mail"
                                else -> "Criar conta"
                            },
                            fontWeight = FontWeight.ExtraBold
                        )
                    }

                    TextButton(
                        onClick = {
                            mode = if (mode == AuthMode.LOGIN) AuthMode.CREATE else AuthMode.LOGIN
                            message = null
                            confirmPassword = ""
                        },
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (mode == AuthMode.LOGIN) "Não possui conta? Criar conta" else "Já possui conta? Entrar")
                    }

                    if (mode == AuthMode.LOGIN && showGuestOption) {
                        HorizontalDivider(color = Color.White.copy(alpha = .08f))
                        OutlinedButton(
                            onClick = onContinueAsGuest,
                            enabled = !busy,
                            modifier = Modifier.fillMaxWidth().height(50.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White.copy(alpha = .86f)),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF4EA8FF).copy(alpha = .40f))
                        ) {
                            Icon(Icons.Default.AccountCircle, null)
                            Spacer(Modifier.width(9.dp))
                            Text("Continuar como convidado", fontWeight = FontWeight.Bold)
                        }
                        Text(
                            "Explore o SONUS no FREE. Login será solicitado apenas para dados de distribuição, backup online e compras Premium.",
                            color = Color.White.copy(alpha = .46f),
                            style = MaterialTheme.typography.labelSmall,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            Spacer(Modifier.height(18.dp))
            Text(
                if (showGuestOption) "Login e compras são protegidos pelo Firebase Authentication." else "Entre para continuar com esta ação protegida.",
                color = Color.White.copy(alpha = .42f),
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.labelSmall
            )
            Spacer(Modifier.height(28.dp))
        }
    }
}
