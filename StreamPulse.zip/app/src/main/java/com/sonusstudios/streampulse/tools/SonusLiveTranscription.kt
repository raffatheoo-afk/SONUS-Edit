package com.sonusstudios.streampulse.tools

import android.content.Context
import android.net.Uri
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File

/** Estado visual leve compartilhado entre a tela de Letras e as 9 interfaces do SONUS PLAYER. */
internal object SonusLiveLyricsBus {
    private val _line = MutableStateFlow("")
    val line: StateFlow<String> = _line.asStateFlow()
    fun publish(text: String) { _line.value = text.lineSequence().filter { it.isNotBlank() }.lastOrNull().orEmpty().take(180) }
    fun clear() { _line.value = "" }
}

internal data class SonusTranscriptLine(val startMs: Long, val text: String)

internal fun transcriptToLrc(lines: List<SonusTranscriptLine>): String = lines
    .filter { it.text.isNotBlank() }
    .distinctBy { it.startMs to it.text.trim() }
    .sortedBy { it.startMs }
    .joinToString("\n") { line ->
        val totalCs = (line.startMs.coerceAtLeast(0L) / 10L)
        val min = totalCs / 6000L
        val sec = (totalCs % 6000L) / 100L
        val cs = totalCs % 100L
        "[%02d:%02d.%02d]%s".format(min, sec, cs, line.text.trim())
    }

/**
 * Extrai apenas um pequeno trecho PCM mono/16 kHz do áudio interno da mídia.
 * Isso evita usar o microfone e impede que a transcrição precise copiar um filme inteiro.
 */
internal fun prepareSpeechPcmSegment(
    context: Context,
    source: String,
    startMs: Long,
    durationSeconds: Int = 18,
    focusVoice: Boolean = false
): File? = runCatching {
    val dir = File(context.cacheDir, "sonus_live_transcribe").apply { mkdirs() }
    val out = File(dir, "live_${System.nanoTime()}.pcm")
    val online = SonusOnlineRef.parse(source)
    val input: String
    var temp: File? = null
    if (online != null) {
        input = SonusPCloudClient.streamUrl(online.fileId)
    } else {
        val uri = Uri.parse(source)
        when (uri.scheme?.lowercase()) {
            "http", "https" -> input = source
            "file" -> input = uri.path ?: error("Arquivo inválido")
            else -> {
                temp = File(dir, "src_${System.nanoTime()}.bin")
                context.contentResolver.openInputStream(uri)?.use { src -> temp!!.outputStream().use { dst -> src.copyTo(dst) } }
                    ?: error("Não foi possível abrir a mídia")
                input = temp!!.absolutePath
            }
        }
    }
    val escaped = input.replace("'", "'\\''")
    val start = startMs.coerceAtLeast(0L) / 1000.0
    val seconds = durationSeconds.coerceIn(6, 30)
    val voiceFilter = if (focusVoice) " -af 'highpass=f=120,lowpass=f=7000,acompressor=threshold=-22dB:ratio=3:attack=10:release=100'" else ""
    val session = FFmpegKit.execute("-y -ss $start -i '$escaped' -t $seconds -vn -ac 1 -ar 16000$voiceFilter -f s16le '${out.absolutePath.replace("'", "'\\''")}'")
    temp?.delete()
    if (!ReturnCode.isSuccess(session.returnCode) || !out.exists() || out.length() < 3200L) {
        out.delete(); error("Não foi possível preparar este trecho")
    }
    out
}.getOrNull()
