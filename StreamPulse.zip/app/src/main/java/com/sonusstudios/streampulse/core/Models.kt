package com.sonusstudios.streampulse.core

import androidx.compose.runtime.Immutable
import kotlinx.serialization.Serializable

@Serializable
enum class DistributorId {
    SOUNDON,
    DITTO,
    DISTROKID,
    TUNECORE,
    FRESHTUNES,
    ROUTENOTE,
    CDBABY,
    ONERPM,
    UNITEDMASTERS,
    AMUSE,
    LANDR,
    SYMPHONIC,
    TOOLOST,
    OTHER
}

@Serializable
enum class ThemeMode {
    // SYSTEM permanece por compatibilidade com backups/instalações antigas.
    SYSTEM,
    DYNAMIC,
    LIGHT,
    DARK,
    BLUE,
    GREEN,
    RED,
    // Gratuitos extras
    CHECKERED,
    SOFT_YELLOW,
    SOFT_BROWN,
    SOFT_ORANGE,
    SILVER,
    // v1.9.5 • gratuitos adicionais
    SLATE,
    OCEAN,
    FOREST,
    // Legado Premium (agora Bronze)
    RAINBOW,
    MONOCHROME,
    PINK,
    LILAC,
    DEEP_BLACK,
    // extras Bronze
    VIOLET_PULSE,
    SUNSET,
    MIDNIGHT_CYAN,
    // Legado Premium (agora Prata)
    AURORA,
    // extras Prata
    NEON_STUDIO,
    CRIMSON_PRO,
    AURORA_PRO,
    // Legado Premium (agora Ouro)
    PHOTO,
    PROFESSIONAL,
    GOLD,
    SKY,
    SPACE,
    // extras Ouro
    CYBER_PULSE,
    ROYAL_GOLD,
    GLASS_HORIZON,
    NEBULA,
    INFINITY,
    LIQUID_GLASS,
    THREE_D,
    CAMALEON,
    PARALLAX
}

@Serializable
enum class AppFont {
    // Gratuitas
    MODERN,
    ROUNDED,
    CLASSIC,
    COMPACT,
    DIGITAL,
    // Bronze
    NEO,
    SOFT,
    URBAN,
    ELEGANT,
    WIDE,
    // Prata
    EDITORIAL,
    SIGNATURE,
    PULSE,
    MINIMAL,
    TECH,
    // Ouro
    QUANTUM,
    VISION,
    PRIME,
    CODEX,
    CINEMA,
    ARCHITECT,
    NOVA,
    MONUMENT,
    VELVET,
    TITAN
}



@Serializable
enum class TextAppearance {
    DYNAMIC,
    BLACK,
    WHITE,
    WHITE_BLACK_OUTLINE,
    BLACK_WHITE_OUTLINE,
    RAINBOW,
    DEEP_GRAY,
    BOLD,
    WHITE_SHADOW,
    NAVY
}

@Serializable
@Immutable
data class AudioConversionPreset(
    val format: String = "WAV",
    val sampleRateHz: Int = 44100,
    val bitDepth: Int = 16,
    val bitrateKbps: Int = 320,
    val channels: Int = 2,
    val album: String = "",
    val albumArtist: String = "",
    val genre: String = "",
    val composer: String = "",
    val copyright: String = "",
    // v1.9.2: preferências do Conversor Pro. Defaults preservam backups antigos.
    val eqPresetName: String = "Flat",
    val eqBassDb: Double = 0.0,
    val eqMidDb: Double = 0.0,
    val eqTrebleDb: Double = 0.0,
    val eqAdvancedOffsetsDb: List<Double> = emptyList(),
    val pulseLiftEnabled: Boolean = false,
    val pulseLiftIntensity: Int = 50,
    // PulseOrbit™: assinatura espacial própria do SONUS.
    val pulseOrbitMode: String = "OFF",
    val pulseOrbitPreset: String = "Natural",
    val pulseOrbitIntensity: Int = 55,
    val useDistributorRecommended: Boolean = true
)

@Serializable
@Immutable
data class UserPreferences(
    val themeMode: ThemeMode = ThemeMode.DYNAMIC,
    val appFont: AppFont = AppFont.MODERN,
    val dashboardCompact: Boolean = false,
    val showSmartSummary: Boolean = true,
    val showAdvancedForecast: Boolean = true,
    val trendWindowDays: Int = 3,
    val backgroundPhotoPath: String? = null,
    val portfolioAnnualGoalBrl: Double? = null,
    val portfolioAnnualGoalStartIso: String? = null,
    val appUsageTotalMillis: Long = 0L,
    val appUsageSessionCount: Long = 0L,
    val appUsageDaysIso: List<String> = emptyList(),
    val appUsageLongestSessionMillis: Long = 0L,
    val appUsageLastAccessIso: String? = null,
    // 0.7.8: histórico local detalhado de uso. As chaves diárias usam yyyy-MM-dd.
    val appUsageDailyMillis: Map<String, Long> = emptyMap(),
    val appUsageFeatureMillis: Map<String, Long> = emptyMap(),
    val appUsageFeatureDailyMillis: Map<String, Long> = emptyMap(),
    val dataUsageTotalRxBytes: Long = 0L,
    val dataUsageTotalTxBytes: Long = 0L,
    val dataUsageDailyRxBytes: Map<String, Long> = emptyMap(),
    val dataUsageDailyTxBytes: Map<String, Long> = emptyMap(),
    val premiumExpiresAtEpochMillis: Long? = null,
    // v1.7.x: mantido para compatibilidade com backups antigos.
    val converterCoins: Int = 5,
    val converterCoinsPeriod: String? = null,
    val converterCoinsOwnerUid: String? = null,
    // Compatibilidade interna: estes campos agora representam o saldo GLOBAL de Moedas SONUS.
    // O saldo mensal não acumula; no FREE anúncios apenas repõem até o teto de 20.
    val pulseMonthlyCoins: Int = 20,
    val pulseBonusCoins: Int = 0,
    val pulseCoinsPeriod: String? = null,
    val pulseCoinsOwnerUid: String? = null,
    val pulseUsageTierName: String? = null,
    // Incrementado quando a tabela de franquias muda para que instalações existentes recebam
    // o novo saldo uma única vez, mesmo dentro do mesmo mês/plano.
    val pulseWalletPolicyVersion: Int = 0,
    val textAppearance: TextAppearance = TextAppearance.DYNAMIC,
    // Benefícios promocionais temporários. Compras reais serão autoridade separada do estado local.
    val promotionalTierName: String? = null,
    val adFreeUntilEpochMillis: Long? = null,
    val adRewardMultiplier: Int = 1,
    val adRewardMultiplierUntilEpochMillis: Long? = null,
    val discountPercent: Int? = null,
    val discountTierName: String? = null,
    val discountUntilEpochMillis: Long? = null,
    val publicCommunityCounterEnabled: Boolean = true,
    val publicCommunityMinimum: Int = 100,
    // v1.9.3: monitor discreto de rede. Valores são estimativas do tráfego do processo Android.
    val showDataUsageMonitor: Boolean = true,
    val warnOnMobileData: Boolean = true,
    val mobileDataWarningMb: Int = 50,
    // SONUS 0.5: preset do Conversor para usuários que não usam distribuidora.
    // Evita amarrar uma ferramenta central ao cadastro opcional de artista.
    val creatorAudioPreset: AudioConversionPreset? = null,
    // Passe SONUS 24h: recompensas voluntárias por função. Não representa plano pago
    // e nunca deve ser usado como autoridade de OWNER/Premium no servidor.
    val passPulseLiftUntilEpochMillis: Long? = null,
    val passPulseOrbit3dUntilEpochMillis: Long? = null,
    val passPulseOrbit8dUntilEpochMillis: Long? = null,
    val passVocalRemoverUntilEpochMillis: Long? = null,
    val passPitchProUntilEpochMillis: Long? = null,
    val passMergeProUntilEpochMillis: Long? = null,
    val passVideoAudioProUntilEpochMillis: Long? = null,
    // SONUS 0.6: assinatura tátil configurável. Defaults suaves para não incomodar.
    val hapticsEnabled: Boolean = true,
    val hapticsIntensity: Int = 1, // 0 suave, 1 médio, 2 forte
    val hapticsPlayer: Boolean = true,
    val hapticsTools: Boolean = true,
    val hapticsTuner: Boolean = true,
    // SONUS 0.8.24: recursos profissionais opcionais. Ambos ficam desligados
    // por padrão para manter a navegação limpa para quem usa só Música/Vídeo/Destaques.
    val artistResourcesDistributionEnabled: Boolean = false,
    val artistResourcesDistributionPinned: Boolean = false,
)

@Serializable
@Immutable
data class Artist(
    val id: String,
    val name: String,
    val distributor: DistributorId,
    val customDistributorName: String? = null,
    val customCycleStartDay: Int? = null,
    val lastPayoutDateIso: String? = null,
    // code111: the payment event closes the financial cycle without discarding delayed report days.
    val financialCycleStartIso: String? = null,
    // code119: persisted input semantics for stream data. TOTAL = cumulative panel, DIA = daily value.
    val streamEntryMode: String? = null,
    // code119: isolates records created after each explicit cycle reset/payment boundary.
    val financialCycleId: String? = null,
    val lastCountedDataDateIso: String? = null,
    val nextUnconsumedDataDateIso: String? = null,
    val nextExpectedPayoutDateIso: String? = null,
    // Optional user-confirmed payout pattern. A one-off early/late payment does not change it automatically.
    val financialExpectedPayoutDayOverride: Int? = null,
    val lastActualPayoutDateIso: String? = null,
    // Anonymous/global calibration cache. Only aggregate statistics are synchronized;
    // no individual payment or user identity is stored here.
    val globalReferenceRpmBrl: Double? = null,
    val globalReferenceMedianRpmBrl: Double? = null,
    val globalReferenceSpreadRpmBrl: Double? = null,
    val globalReferenceAccuracyPercent: Double? = null,
    val globalReferenceSampleCount: Int = 0,
    val currency: String = "BRL",
    val createdAtIso: String = "",
    val photoPath: String? = null,
    // Avatar SONUS é uma alternativa local à foto da galeria. Backups antigos recebem null.
    val avatarId: String? = null,
    val goalBrl: Double? = null,
    val goalStreams: Long? = null,
    val royaltyScenarioId: String? = null,
    val annualGoalBrl: Double? = null,
    val annualGoalStartIso: String? = null,
    val audioPreset: AudioConversionPreset? = null
)

@Serializable
@Immutable
data class StreamSnapshot(
    val id: String,
    val artistId: String,
    val dateIso: String,
    val cumulativeStreams: Long,
    val cycleStartIso: String,
    val cycleEndIso: String,
    val recordedAtEpochMillis: Long = 0L,
    val estimatedBrlAtSave: Double? = null,
    // null identifies legacy records; new cycles persist a stable id.
    val cycleId: String? = null
)

@Serializable
@Immutable
data class DailyStreamRecord(
    val id: String,
    val artistId: String,
    val dateIso: String,
    val streams: Long,
    val recordedAtEpochMillis: Long = 0L,
    // null identifies legacy records; new cycles persist a stable id.
    val cycleId: String? = null
)

@Serializable
@Immutable
data class RoyaltyPayment(
    val id: String,
    val artistId: String,
    val paidDateIso: String,
    val amountBrl: Double,
    val cycleStreams: Long,
    val cycleStartIso: String? = null,
    val cycleEndIso: String? = null,
    val estimatedBrlBeforeCalibration: Double? = null,
    val rpmBeforeCalibration: Double? = null,
    val referenceMonthIso: String? = null,
    val expectedPayoutDateIso: String? = null,
    val lastCountedDataDateIso: String? = null,
    // User-selected first day of the newly opened financial/data cycle.
    // Kept separate from paidDateIso so an early/late payout does not force the data window.
    val newCycleStartIso: String? = null,
    val effectiveRpmBrlPerThousand: Double? = null,
    // Explicit consent to make this real payment day the future expected payout pattern.
    val adoptActualPayoutDayAsPattern: Boolean = false,
    val isRetroactive: Boolean = false,
    val recordedAtEpochMillis: Long = 0L
)


@Serializable
@Immutable
data class UserActivityRecord(
    val id: String,
    val artistId: String? = null,
    val title: String,
    val category: String,
    val detail: String? = null,
    val success: Boolean? = null,
    val durationMs: Long? = null,
    val createdAtEpochMillis: Long = System.currentTimeMillis()
)

@Serializable
@Immutable
data class AppState(
    val schemaVersion: Int = 20,
    val artists: List<Artist> = emptyList(),
    val selectedArtistId: String? = null,
    val snapshots: List<StreamSnapshot> = emptyList(),
    val dailyStreamRecords: List<DailyStreamRecord> = emptyList(),
    val payments: List<RoyaltyPayment> = emptyList(),
    val activityRecords: List<UserActivityRecord> = emptyList(),
    val onboardingComplete: Boolean = false,
    val preferences: UserPreferences = UserPreferences()
)

/** Persisted stream-entry semantics used consistently by input, history, charts and projections. */
fun resolvedStreamEntryMode(artist: Artist): String {
    val persisted = artist.streamEntryMode?.trim()?.uppercase()
    if (persisted == "TOTAL" || persisted == "DIA") return persisted
    val fallback = DistributorRules.financialProfile(artist).entryMode.trim().uppercase()
    return if (fallback == "DIA") "DIA" else "TOTAL"
}

fun recordBelongsToCurrentCycle(recordCycleId: String?, artist: Artist): Boolean =
    artist.financialCycleId == null || recordCycleId == artist.financialCycleId

@Immutable
data class CycleWindow(
    val startIso: String,
    val endIso: String,
    val description: String,
    val isEstimatedRule: Boolean = false
)

@Immutable
data class ForecastResult(
    val currentStreams: Long,
    val estimatedCurrentBrl: Double,
    val projectedStreams: Long,
    val projectedBrl: Double,
    val conservativeStreams: Long,
    val conservativeBrl: Double,
    val optimisticStreams: Long,
    val optimisticBrl: Double,
    val cycleDailyAverage: Double,
    val recentDailyAverage: Double,
    val projectedDailyRate: Double,
    val confidence: String
)

@Immutable
data class DailyStreamEntry(
    val dateIso: String,
    val streams: Long,
    val points: Int
)

@Immutable
data class HealthResult(
    val score: Int,
    val emoji: String,
    val label: String,
    val scoredDays: Int,
    val positiveDays: Int,
    val weakDays: Int,
    val missingDays: Int = 0,
    val lastDay: DailyStreamEntry? = null,
    val possiblePoints: Int = 0,
    val performancePercent: Double = 0.0,
    val cycleStartIso: String? = null,
    val cycleEndIso: String? = null
)

@Immutable
data class AccuracyResult(
    val completedCycles: Int,
    val averageAbsoluteErrorPercent: Double?,
    val accuracyPercent: Double?,
    val label: String
)

@Immutable
data class TrendResult(
    val label: String,
    val percentChange: Double?,
    val recentAverage: Double,
    val previousAverage: Double?,
    val direction: Int,
    val sampleCount: Int
)

@Immutable
data class DistributorInfo(
    val distributor: DistributorId,
    val frequency: String,
    val payoutWindow: String,
    val notes: String,
    val streamSelectionGuide: String,
    val helpUrl: String
)
