package com.sonusstudios.streampulse.core

import androidx.compose.runtime.Immutable
import kotlinx.serialization.Serializable


@Serializable
enum class ThemeMode {
    // SYSTEM permanece por compatibilidade com backups/instalações antigas.
    SYSTEM,
    DYNAMIC,
    LIGHT,
    DARK,
    BLUE,
    GREEN,
    RED,
    // Gratuitos extras
    CHECKERED,
    SOFT_YELLOW,
    SOFT_BROWN,
    SOFT_ORANGE,
    SILVER,
    // v1.9.5 • gratuitos adicionais
    SLATE,
    OCEAN,
    FOREST,
    // Legado Premium (agora Bronze)
    RAINBOW,
    MONOCHROME,
    PINK,
    LILAC,
    DEEP_BLACK,
    // extras Bronze
    VIOLET_PULSE,
    SUNSET,
    MIDNIGHT_CYAN,
    // Legado Premium (agora Prata)
    AURORA,
    // extras Prata
    NEON_STUDIO,
    CRIMSON_PRO,
    AURORA_PRO,
    // Legado Premium (agora Ouro)
    PHOTO,
    PROFESSIONAL,
    GOLD,
    SKY,
    SPACE,
    // extras Ouro
    CYBER_PULSE,
    ROYAL_GOLD,
    GLASS_HORIZON,
    NEBULA,
    INFINITY,
    LIQUID_GLASS,
    THREE_D,
    CAMALEON,
    PARALLAX
}

@Serializable
enum class AppFont {
    // Gratuitas
    MODERN,
    ROUNDED,
    CLASSIC,
    COMPACT,
    DIGITAL,
    // Bronze
    NEO,
    SOFT,
    URBAN,
    ELEGANT,
    WIDE,
    // Prata
    EDITORIAL,
    SIGNATURE,
    PULSE,
    MINIMAL,
    TECH,
    // Ouro
    QUANTUM,
    VISION,
    PRIME,
    CODEX,
    CINEMA,
    ARCHITECT,
    NOVA,
    MONUMENT,
    VELVET,
    TITAN
}


@Serializable
enum class TextAppearance {
    DYNAMIC,
    BLACK,
    WHITE,
    WHITE_BLACK_OUTLINE,
    BLACK_WHITE_OUTLINE,
    RAINBOW,
    DEEP_GRAY,
    BOLD,
    WHITE_SHADOW,
    NAVY
}

@Serializable
@Immutable
data class AudioConversionPreset(
    val format: String = "WAV",
    val sampleRateHz: Int = 44100,
    val bitDepth: Int = 16,
    val bitrateKbps: Int = 320,
    val channels: Int = 2,
    val album: String = "",
    val albumArtist: String = "",
    val genre: String = "",
    val composer: String = "",
    val copyright: String = "",
    // v1.9.2: preferências do Conversor Pro. Defaults preservam backups antigos.
    val eqPresetName: String = "Flat",
    val eqBassDb: Double = 0.0,
    val eqMidDb: Double = 0.0,
    val eqTrebleDb: Double = 0.0,
    val eqAdvancedOffsetsDb: List<Double> = emptyList(),
    val pulseLiftEnabled: Boolean = false,
    val pulseLiftIntensity: Int = 50,
    // PulseOrbit™: assinatura espacial própria do SONUS.
    val pulseOrbitMode: String = "OFF",
    val pulseOrbitPreset: String = "Natural",
    val pulseOrbitIntensity: Int = 55
)

@Serializable
@Immutable
data class UserPreferences(
    val themeMode: ThemeMode = ThemeMode.DYNAMIC,
    val appFont: AppFont = AppFont.MODERN,
    val dashboardCompact: Boolean = false,
    val backgroundPhotoPath: String? = null,
    val appUsageTotalMillis: Long = 0L,
    val appUsageSessionCount: Long = 0L,
    val appUsageDaysIso: List<String> = emptyList(),
    val appUsageLongestSessionMillis: Long = 0L,
    val appUsageLastAccessIso: String? = null,
    // 0.7.8: histórico local detalhado de uso. As chaves diárias usam yyyy-MM-dd.
    val appUsageDailyMillis: Map<String, Long> = emptyMap(),
    val appUsageFeatureMillis: Map<String, Long> = emptyMap(),
    val appUsageFeatureDailyMillis: Map<String, Long> = emptyMap(),
    val dataUsageTotalRxBytes: Long = 0L,
    val dataUsageTotalTxBytes: Long = 0L,
    val dataUsageDailyRxBytes: Map<String, Long> = emptyMap(),
    val dataUsageDailyTxBytes: Map<String, Long> = emptyMap(),
    val premiumExpiresAtEpochMillis: Long? = null,
    // v1.7.x: mantido para compatibilidade com backups antigos.
    val converterCoins: Int = 5,
    val converterCoinsPeriod: String? = null,
    val converterCoinsOwnerUid: String? = null,
    // Compatibilidade interna: estes campos agora representam o saldo GLOBAL de Moedas SONUS.
    // O saldo mensal não acumula; no FREE anúncios apenas repõem até o teto de 20.
    val pulseMonthlyCoins: Int = 20,
    val pulseBonusCoins: Int = 0,
    val pulseCoinsPeriod: String? = null,
    val pulseCoinsOwnerUid: String? = null,
    val pulseUsageTierName: String? = null,
    // Incrementado quando a tabela de franquias muda para que instalações existentes recebam
    // o novo saldo uma única vez, mesmo dentro do mesmo mês/plano.
    val pulseWalletPolicyVersion: Int = 0,
    val textAppearance: TextAppearance = TextAppearance.DYNAMIC,
    // Benefícios promocionais temporários. Compras reais serão autoridade separada do estado local.
    val promotionalTierName: String? = null,
    val adFreeUntilEpochMillis: Long? = null,
    val adRewardMultiplier: Int = 1,
    val adRewardMultiplierUntilEpochMillis: Long? = null,
    val discountPercent: Int? = null,
    val discountTierName: String? = null,
    val discountUntilEpochMillis: Long? = null,
    val publicCommunityCounterEnabled: Boolean = true,
    val publicCommunityMinimum: Int = 100,
    // v1.9.3: monitor discreto de rede. Valores são estimativas do tráfego do processo Android.
    val showDataUsageMonitor: Boolean = true,
    val warnOnMobileData: Boolean = true,
    val mobileDataWarningMb: Int = 50,
    // SONUS 0.5: preset livre do Conversor.
    // Evita amarrar uma ferramenta central ao cadastro opcional de artista.
    val creatorAudioPreset: AudioConversionPreset? = null,
    // Passe SONUS 24h: recompensas voluntárias por função. Não representa plano pago
    // e nunca deve ser usado como autoridade de OWNER/Premium no servidor.
    val passPulseLiftUntilEpochMillis: Long? = null,
    val passPulseOrbit3dUntilEpochMillis: Long? = null,
    val passPulseOrbit8dUntilEpochMillis: Long? = null,
    val passVocalRemoverUntilEpochMillis: Long? = null,
    val passPitchProUntilEpochMillis: Long? = null,
    val passMergeProUntilEpochMillis: Long? = null,
    val passVideoAudioProUntilEpochMillis: Long? = null,
    // SONUS 0.6: assinatura tátil configurável. Defaults suaves para não incomodar.
    val hapticsEnabled: Boolean = true,
    val hapticsIntensity: Int = 1, // 0 suave, 1 médio, 2 forte
    val hapticsPlayer: Boolean = true,
    val hapticsTools: Boolean = true,
    val hapticsTuner: Boolean = true,
    // SONUS 0.8.24: recursos profissionais opcionais. Ambos ficam desligados
    // por padrão para manter a navegação limpa para quem usa só Música/Vídeo/Destaques.
)

@Serializable
@Immutable
data class Artist(
    val id: String,
    val name: String,
    // 0.0.1: o cadastro de artista serve apenas ao SONUS Stream (nome artístico e identidade pública).
    val currency: String = "BRL",
    val createdAtIso: String = "",
    val photoPath: String? = null,
    // Avatar SONUS é uma alternativa local à foto da galeria. Backups antigos recebem null.
    val avatarId: String? = null,
    val audioPreset: AudioConversionPreset? = null
)

@Serializable
@Immutable
data class UserActivityRecord(
    val id: String,
    val artistId: String? = null,
    val title: String,
    val category: String,
    val detail: String? = null,
    val success: Boolean? = null,
    val durationMs: Long? = null,
    val createdAtEpochMillis: Long = System.currentTimeMillis()
)

@Serializable
@Immutable
data class AppState(
    val schemaVersion: Int = 20,
    val artists: List<Artist> = emptyList(),
    val selectedArtistId: String? = null,
    val activityRecords: List<UserActivityRecord> = emptyList(),
    val onboardingComplete: Boolean = false,
    val preferences: UserPreferences = UserPreferences()
)
