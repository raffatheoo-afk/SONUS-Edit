package com.sonusstudios.streampulse.notifications

import android.content.Context
import com.google.firebase.database.ChildEventListener
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase

/**
 * Ponte leve entre notificações remotas do Realtime Database e a Central SONUS.
 * Não guarda histórico remoto completo no aparelho: apenas os IDs já entregues para evitar duplicação.
 */
class SonusRemoteNotificationBridge(context: Context) {
    private val app = context.applicationContext
    private val db = FirebaseDatabase.getInstance()
    private val prefs = app.getSharedPreferences("sonus_remote_notifications_v1", Context.MODE_PRIVATE)
    private var uid: String? = null
    private var listener: ChildEventListener? = null

    fun attach(userUid: String) {
        if (userUid.isBlank() || uid == userUid) return
        detach()
        uid = userUid
        val ref = db.getReference("streamUserNotifications").child(userUid).limitToLast(100)
        val l = object : ChildEventListener {
            override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) = deliver(snapshot)
            override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) = deliver(snapshot)
            override fun onChildRemoved(snapshot: DataSnapshot) = Unit
            override fun onChildMoved(snapshot: DataSnapshot, previousChildName: String?) = Unit
            override fun onCancelled(error: DatabaseError) = Unit
        }
        listener = l
        ref.addChildEventListener(l)
    }

    private fun deliver(s: DataSnapshot) {
        val key = s.key ?: return
        if (s.child("read").getValue(Boolean::class.java) == true) return
        val dedupe = "delivered_${uid}_$key"
        if (prefs.getBoolean(dedupe, false)) return
        val title = s.child("title").getValue(String::class.java).orEmpty().ifBlank { "SONUS" }
        val message = s.child("message").getValue(String::class.java).orEmpty()
        if (message.isBlank()) return
        val type = s.child("type").getValue(String::class.java).orEmpty().ifBlank { "SONUS" }
        val category = when {
            type.startsWith("SUPPORT") -> "SUPPORT"
            type.contains("SUBMISSION") || type.contains("ARTIST") || type.contains("MUSIC") -> "ARTIST"
            type.contains("SECURITY") || type.contains("ACCOUNT") -> "SECURITY"
            else -> type
        }
        val route = s.child("route").getValue(String::class.java)?.takeIf { it.isNotBlank() }
        SonusNotificationCenter.add(app, title.take(120), message.take(600), category, route, importantExternal = true)
        prefs.edit().putBoolean(dedupe, true).apply()
    }

    fun detach() {
        val u = uid
        val l = listener
        if (u != null && l != null) db.getReference("streamUserNotifications").child(u).removeEventListener(l)
        uid = null
        listener = null
    }
}
