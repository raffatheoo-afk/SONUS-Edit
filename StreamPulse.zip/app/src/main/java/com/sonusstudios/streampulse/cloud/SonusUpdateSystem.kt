package com.sonusstudios.streampulse.cloud

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.FirebaseDatabase
import com.sonusstudios.streampulse.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.util.Locale
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

private const val AUTO_CHECK_INTERVAL_MS = 12L * 60L * 60L * 1000L
private const val DISMISS_INTERVAL_MS = 24L * 60L * 60L * 1000L
private const val UPDATE_PREFS = "sonus_update_state_v1"
private const val FIREBASE_CURRENT = "updates/current"
private const val FIREBASE_HISTORY = "updates/history"

/**
 * Fonte da verdade das atualizações do SONUS.
 * O pCloud armazena o APK; Firebase informa qual APK o OWNER publicou.
 * Nenhum token/senha do pCloud é necessário: a pasta de update é um link público somente leitura.
 */
data class SonusUpdateInfo(
    val published: Boolean = false,
    val versionCode: Int = 0,
    val versionName: String = "",
    val fileId: Long = 0L,
    val fileName: String = "",
    val apkSize: Long = 0L,
    val sha256: String = "",
    val changelog: String = "",
    val mandatory: Boolean = false,
    val minimumVersionCode: Int = 0,
    val publishedAt: Long = 0L
) {
    fun isMandatoryForInstalled(): Boolean = mandatory || (minimumVersionCode > 0 && BuildConfig.VERSION_CODE < minimumVersionCode)
}

data class PCloudUpdateApk(
    val fileId: Long,
    val name: String,
    val size: Long,
    val modified: String = ""
)

sealed interface SonusUpdateDecision {
    data class Available(val info: SonusUpdateInfo) : SonusUpdateDecision
    data object UpToDate : SonusUpdateDecision
    data object Deferred : SonusUpdateDecision
    data object SkippedByCache : SonusUpdateDecision
}

enum class UpdateInstallResult { STARTED, NEED_PERMISSION, INVALID_APK, ERROR }

class SonusUpdateManager(private val context: Context) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences(UPDATE_PREFS, Context.MODE_PRIVATE)
    private val db = FirebaseDatabase.getInstance()
    private val publicCode get() = BuildConfig.SONUS_UPDATE_PCLOUD_PUBLIC_CODE

    suspend fun checkForUpdate(force: Boolean = false): Result<SonusUpdateDecision> = runCatching {
        val now = System.currentTimeMillis()
        val lastCheck = prefs.getLong("lastUpdateCheck", 0L)
        if (!force && lastCheck > 0L && now - lastCheck < AUTO_CHECK_INTERVAL_MS) {
            return@runCatching SonusUpdateDecision.SkippedByCache
        }

        val snapshot = db.getReference(FIREBASE_CURRENT).get().awaitUpdateSnapshot()
        prefs.edit().putLong("lastUpdateCheck", now).apply()
        val info = snapshot.toUpdateInfo()
        prefs.edit().putInt("lastSeenVersionCode", info?.versionCode ?: 0).apply()

        if (info == null || !info.published || info.versionCode <= BuildConfig.VERSION_CODE) {
            SonusUpdateDecision.UpToDate
        } else {
            val dismissedCode = prefs.getInt("dismissedVersionCode", 0)
            val dismissedAt = prefs.getLong("dismissedAt", 0L)
            if (!force && !info.isMandatoryForInstalled() && dismissedCode == info.versionCode && now - dismissedAt < DISMISS_INTERVAL_MS) {
                SonusUpdateDecision.Deferred
            } else SonusUpdateDecision.Available(info)
        }
    }

    fun dismiss(info: SonusUpdateInfo) {
        if (info.isMandatoryForInstalled()) return
        prefs.edit().putInt("dismissedVersionCode", info.versionCode).putLong("dismissedAt", System.currentTimeMillis()).apply()
    }

    suspend fun currentPublished(): Result<SonusUpdateInfo?> = runCatching {
        db.getReference(FIREBASE_CURRENT).get().awaitUpdateSnapshot().toUpdateInfo()
    }

    suspend fun updateHistory(): Result<List<SonusUpdateInfo>> = runCatching {
        db.getReference(FIREBASE_HISTORY).get().awaitUpdateSnapshot().children.mapNotNull { it.toUpdateInfo() }
            .sortedByDescending { it.versionCode }
    }

    suspend fun listPCloudApks(): Result<List<PCloudUpdateApk>> = withContext(Dispatchers.IO) {
        runCatching {
            val url = "https://api.pcloud.com/showpublink?code=${enc(publicCode)}"
            val json = JSONObject(httpGetText(url))
            require(json.optInt("result", -1) == 0) { json.optString("error").ifBlank { "pCloud recusou a pasta de atualizações." } }
            val metadata = json.optJSONObject("metadata") ?: error("pCloud não retornou os dados da pasta.")
            val result = mutableListOf<PCloudUpdateApk>()
            collectApks(metadata.optJSONArray("contents"), result)
            result.sortedWith(compareByDescending<PCloudUpdateApk> { it.modified }.thenByDescending { it.fileId })
        }
    }

    suspend fun publishUpdate(
        apk: PCloudUpdateApk,
        versionCode: Int,
        versionName: String,
        changelog: String,
        mandatory: Boolean,
        minimumVersionCode: Int = 0
    ): Result<SonusUpdateInfo> = withContext(Dispatchers.IO) {
        runCatching {
            require(versionCode > 0) { "Informe um versionCode válido." }
            require(versionName.trim().isNotBlank()) { "Informe a versão." }
            require(apk.fileId > 0 && apk.name.endsWith(".apk", true)) { "Selecione um APK válido." }
            val existing = runCatching { db.getReference(FIREBASE_CURRENT).get().awaitUpdateSnapshot().toUpdateInfo() }.getOrNull()
            if (existing != null && existing.versionCode >= versionCode) {
                error("Já existe code${existing.versionCode} no histórico ativo. Para uma nova publicação use um versionCode maior.")
            }

            val resolved = resolvePCloudDownload(apk.fileId)
            val sha = sha256Remote(resolved, apk.size, versionCode)
            val now = System.currentTimeMillis()
            val info = SonusUpdateInfo(
                published = true,
                versionCode = versionCode,
                versionName = versionName.trim(),
                fileId = apk.fileId,
                fileName = apk.name,
                apkSize = apk.size,
                sha256 = sha,
                changelog = changelog.trim(),
                mandatory = mandatory,
                minimumVersionCode = minimumVersionCode.coerceAtLeast(0),
                publishedAt = now
            )
            val values = info.toMap()
            db.reference.updateChildren(
                mapOf(
                    FIREBASE_CURRENT to values,
                    "$FIREBASE_HISTORY/$versionCode" to values
                )
            ).awaitUpdateVoid()
            info
        }
    }

    suspend fun pauseCurrentUpdate(): Result<Unit> = runCatching {
        db.getReference(FIREBASE_CURRENT).child("published").setValue(false).awaitUpdateVoid()
    }

    suspend fun resumeCurrentUpdate(): Result<Unit> = runCatching {
        db.getReference(FIREBASE_CURRENT).child("published").setValue(true).awaitUpdateVoid()
    }

    suspend fun downloadUpdate(info: SonusUpdateInfo, onProgress: (Int, Long, Long) -> Unit): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            require(info.fileId > 0L) { "A atualização publicada não possui arquivo." }
            require(info.sha256.length >= 32) { "A atualização não possui verificação de integridade." }
            val downloadUrl = resolvePCloudDownload(info.fileId)
            val dir = File(appContext.cacheDir, "sonus_updates").apply { mkdirs() }
            dir.listFiles()?.filter { it.name.endsWith(".apk", true) }?.forEach { runCatching { it.delete() } }
            val output = File(dir, "SONUS-${info.versionName}-code${info.versionCode}.apk")
            val digest = MessageDigest.getInstance("SHA-256")
            val conn = (URL(downloadUrl).openConnection() as HttpURLConnection).apply {
                connectTimeout = 15_000
                readTimeout = 60_000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", "SONUS/${BuildConfig.VERSION_NAME}")
            }
            try {
                val code = conn.responseCode
                require(code in 200..299) { "Download recusado pelo servidor ($code)." }
                val expectedTotal = info.apkSize.takeIf { it > 0L } ?: conn.contentLengthLong.coerceAtLeast(0L)
                var written = 0L
                conn.inputStream.use { input ->
                    output.outputStream().buffered().use { out ->
                        val buffer = ByteArray(128 * 1024)
                        while (true) {
                            val n = input.read(buffer)
                            if (n < 0) break
                            if (n == 0) continue
                            out.write(buffer, 0, n)
                            digest.update(buffer, 0, n)
                            written += n
                            val percent = if (expectedTotal > 0) ((written * 100L) / expectedTotal).toInt().coerceIn(0, 100) else 0
                            onProgress(percent, written, expectedTotal)
                        }
                    }
                }
                require(output.exists() && output.length() > 0L) { "O APK baixado está vazio." }
                if (info.apkSize > 0L) require(output.length() == info.apkSize) { "O tamanho do APK baixado não confere." }
                val actual = digest.digest().joinToString("") { "%02x".format(it) }
                require(actual.equals(info.sha256, ignoreCase = true)) { "O APK não passou na verificação SHA-256." }
                validateApkIdentity(output, info.versionCode).getOrThrow()
                onProgress(100, output.length(), output.length())
                output
            } catch (t: Throwable) {
                runCatching { output.delete() }
                throw t
            } finally {
                conn.disconnect()
            }
        }
    }

    fun installApk(file: File): UpdateInstallResult {
        if (!file.exists() || file.length() <= 0L) return UpdateInstallResult.INVALID_APK
        if (validateApkIdentity(file).isFailure) return UpdateInstallResult.INVALID_APK
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !appContext.packageManager.canRequestPackageInstalls()) {
                val permissionIntent = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${appContext.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                appContext.startActivity(permissionIntent)
                UpdateInstallResult.NEED_PERMISSION
            } else {
                val uri = FileProvider.getUriForFile(appContext, "${appContext.packageName}.updates", file)
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "application/vnd.android.package-archive")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                appContext.startActivity(intent)
                UpdateInstallResult.STARTED
            }
        } catch (_: Throwable) {
            UpdateInstallResult.ERROR
        }
    }

    private fun validateApkIdentity(
        file: File,
        expectedVersionCode: Int? = null,
        requireNewerThanInstalled: Boolean = true
    ): Result<Unit> = runCatching {
        val pm = appContext.packageManager
        @Suppress("DEPRECATION")
        val archive = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            pm.getPackageArchiveInfo(file.absolutePath, PackageManager.GET_SIGNING_CERTIFICATES)
        } else pm.getPackageArchiveInfo(file.absolutePath, PackageManager.GET_SIGNATURES)
        requireNotNull(archive) { "O arquivo baixado não é um APK Android válido." }
        require(archive.packageName == appContext.packageName) { "O APK pertence a outro aplicativo." }
        val archiveVersionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) archive.longVersionCode else {
            @Suppress("DEPRECATION") archive.versionCode.toLong()
        }
        if (expectedVersionCode != null) {
            require(archiveVersionCode == expectedVersionCode.toLong()) { "O versionCode do APK não corresponde à atualização publicada." }
        }
        if (requireNewerThanInstalled) {
            require(archiveVersionCode > BuildConfig.VERSION_CODE.toLong()) { "O APK não é mais novo que a versão instalada." }
        }
        val installed = when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU ->
                pm.getPackageInfo(appContext.packageName, PackageManager.PackageInfoFlags.of(PackageManager.GET_SIGNING_CERTIFICATES.toLong()))
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.P -> {
                @Suppress("DEPRECATION") pm.getPackageInfo(appContext.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
            }
            else -> {
                @Suppress("DEPRECATION") pm.getPackageInfo(appContext.packageName, PackageManager.GET_SIGNATURES)
            }
        }
        val archiveSigs = packageSignatures(archive)
        val installedSigs = packageSignatures(installed)
        require(archiveSigs.isNotEmpty() && installedSigs.isNotEmpty() && archiveSigs.intersect(installedSigs).isNotEmpty()) {
            "A assinatura do APK não corresponde à instalação atual do SONUS."
        }
    }

    @Suppress("DEPRECATION")
    private fun packageSignatures(info: android.content.pm.PackageInfo): Set<String> {
        val signatures = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            info.signingInfo?.apkContentsSigners?.toList().orEmpty()
        } else info.signatures?.toList().orEmpty()
        return signatures.map { sig ->
            MessageDigest.getInstance("SHA-256").digest(sig.toByteArray()).joinToString("") { "%02x".format(it) }
        }.toSet()
    }

    private suspend fun resolvePCloudDownload(fileId: Long): String = withContext(Dispatchers.IO) {
        val url = "https://api.pcloud.com/getpublinkdownload?code=${enc(publicCode)}&fileid=$fileId&forcedownload=1"
        val json = JSONObject(httpGetText(url))
        require(json.optInt("result", -1) == 0) { json.optString("error").ifBlank { "pCloud não liberou o download." } }
        val hosts = json.optJSONArray("hosts") ?: error("pCloud não retornou servidor de download.")
        val host = hosts.optString(0).takeIf { it.isNotBlank() } ?: error("Servidor de download indisponível.")
        val path = json.optString("path").takeIf { it.isNotBlank() } ?: error("Caminho do download indisponível.")
        "https://$host$path"
    }

    private fun sha256Remote(url: String, expectedSize: Long, expectedVersionCode: Int): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val validationDir = File(appContext.cacheDir, "sonus_owner_update_validation").apply { mkdirs() }
        val validationFile = File(validationDir, "candidate.apk")
        runCatching { validationFile.delete() }
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 60_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "SONUS-OWNER/${BuildConfig.VERSION_NAME}")
        }
        try {
            require(conn.responseCode in 200..299) { "Não foi possível validar o APK no pCloud." }
            var total = 0L
            conn.inputStream.use { input ->
                validationFile.outputStream().buffered().use { output ->
                    val buffer = ByteArray(128 * 1024)
                    while (true) {
                        val n = input.read(buffer)
                        if (n < 0) break
                        if (n == 0) continue
                        output.write(buffer, 0, n)
                        digest.update(buffer, 0, n)
                        total += n
                    }
                }
            }
            if (expectedSize > 0L) require(total == expectedSize) { "O APK mudou durante a validação. Atualize a lista e tente novamente." }
            require(validationFile.exists() && validationFile.length() > 0L) { "O APK do pCloud está vazio." }
            validateApkIdentity(validationFile, expectedVersionCode, requireNewerThanInstalled = false).getOrThrow()
            return digest.digest().joinToString("") { "%02x".format(it) }
        } finally {
            conn.disconnect()
            runCatching { validationFile.delete() }
        }
    }

    private fun httpGetText(url: String): String {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 12_000
            readTimeout = 20_000
            instanceFollowRedirects = true
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "SONUS/${BuildConfig.VERSION_NAME}")
        }
        return try {
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            require(code in 200..299) { "Servidor respondeu $code." }
            text
        } finally { conn.disconnect() }
    }

    private fun collectApks(contents: JSONArray?, target: MutableList<PCloudUpdateApk>) {
        if (contents == null) return
        for (i in 0 until contents.length()) {
            val item = contents.optJSONObject(i) ?: continue
            if (item.optBoolean("isfolder", false)) {
                collectApks(item.optJSONArray("contents"), target)
            } else {
                val name = item.optString("name")
                if (name.endsWith(".apk", true)) {
                    target += PCloudUpdateApk(
                        fileId = item.optLong("fileid", 0L),
                        name = name,
                        size = item.optLong("size", 0L),
                        modified = item.optString("modified")
                    )
                }
            }
        }
    }

    private fun DataSnapshot.toUpdateInfo(): SonusUpdateInfo? {
        if (!exists()) return null
        fun str(key: String) = child(key).getValue(String::class.java).orEmpty()
        fun bool(key: String) = child(key).getValue(Boolean::class.java) ?: false
        fun long(key: String) = child(key).getValue(Long::class.java) ?: child(key).value?.toString()?.toLongOrNull() ?: 0L
        return SonusUpdateInfo(
            published = bool("published"),
            versionCode = long("versionCode").toInt(),
            versionName = str("versionName"),
            fileId = long("fileId"),
            fileName = str("fileName"),
            apkSize = long("apkSize"),
            sha256 = str("sha256"),
            changelog = str("changelog"),
            mandatory = bool("mandatory"),
            minimumVersionCode = long("minimumVersionCode").toInt(),
            publishedAt = long("publishedAt")
        )
    }

    private fun SonusUpdateInfo.toMap(): Map<String, Any> = linkedMapOf(
        "published" to published,
        "versionCode" to versionCode,
        "versionName" to versionName,
        "fileId" to fileId,
        "fileName" to fileName,
        "apkSize" to apkSize,
        "sha256" to sha256.lowercase(Locale.ROOT),
        "changelog" to changelog,
        "mandatory" to mandatory,
        "minimumVersionCode" to minimumVersionCode,
        "publishedAt" to publishedAt,
        "publicCode" to publicCode
    )

    private fun enc(value: String): String = URLEncoder.encode(value, Charsets.UTF_8.name())
}

@Composable
fun SonusUpdateDialog(
    info: SonusUpdateInfo,
    manager: SonusUpdateManager,
    onDismiss: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var downloading by remember(info.versionCode) { mutableStateOf(false) }
    var progress by remember(info.versionCode) { mutableIntStateOf(0) }
    var bytes by remember(info.versionCode) { mutableLongStateOf(0L) }
    var total by remember(info.versionCode) { mutableLongStateOf(info.apkSize) }
    var downloaded by remember(info.versionCode) { mutableStateOf<File?>(null) }
    var message by remember(info.versionCode) { mutableStateOf<String?>(null) }
    val mandatory = info.isMandatoryForInstalled()

    fun install(file: File) {
        message = when (manager.installApk(file)) {
            UpdateInstallResult.STARTED -> "Instalador do Android aberto."
            UpdateInstallResult.NEED_PERMISSION -> "Autorize o SONUS a instalar atualizações e, ao voltar, toque em Instalar novamente."
            UpdateInstallResult.INVALID_APK -> "O APK não passou na validação de pacote/assinatura."
            UpdateInstallResult.ERROR -> "Não foi possível abrir o instalador do Android."
        }
    }

    AlertDialog(
        onDismissRequest = { if (!mandatory && !downloading) { manager.dismiss(info); onDismiss() } },
        icon = { Icon(Icons.Default.SystemUpdateAlt, null, tint = Color(0xFF57C8FF)) },
        title = { Text("Atualização disponível", fontWeight = FontWeight.Black) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = Color(0xFF0C2635),
                    border = BorderStroke(1.dp, Color(0xFF4EC7F2).copy(alpha=.35f))
                ) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("SONUS ${info.versionName}", fontSize = 21.sp, fontWeight = FontWeight.Black, color = Color.White)
                        Text("code${info.versionCode} • ${formatUpdateBytes(info.apkSize)}", color = Color.White.copy(alpha=.65f), style = MaterialTheme.typography.bodySmall)
                        if (mandatory) Text("Atualização necessária", color = Color(0xFFFFC857), fontWeight = FontWeight.Bold)
                    }
                }
                Text("O que há de novo", fontWeight = FontWeight.ExtraBold)
                val lines = info.changelog.lines().map { it.trim().removePrefix("•").removePrefix("-").trim() }.filter { it.isNotBlank() }
                if (lines.isEmpty()) Text("Melhorias de estabilidade e recursos do SONUS.", style=MaterialTheme.typography.bodySmall)
                else lines.take(8).forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                if (downloading) {
                    LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth())
                    Text("Baixando… $progress% • ${formatUpdateBytes(bytes)} / ${formatUpdateBytes(total)}", style = MaterialTheme.typography.labelSmall)
                }
                message?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary) }
            }
        },
        dismissButton = if (!mandatory && !downloading && downloaded == null) {
            { TextButton(onClick = { manager.dismiss(info); onDismiss() }) { Text("Adiar") } }
        } else null,
        confirmButton = {
            when {
                downloaded != null -> Button(onClick = { install(downloaded!!) }) { Icon(Icons.Default.InstallMobile, null); Spacer(Modifier.width(6.dp)); Text("Instalar atualização") }
                downloading -> Button(onClick = {}, enabled = false) { Text("Baixando…") }
                else -> Button(onClick = {
                    downloading = true; message = null; progress = 0
                    scope.launch {
                        val result = manager.downloadUpdate(info) { p, b, t -> progress = p; bytes = b; total = t }
                        downloading = false
                        result.onSuccess { file -> downloaded = file; message = "Download concluído e verificado." }
                            .onFailure { message = it.message ?: "Falha ao baixar a atualização." }
                    }
                }) { Icon(Icons.Default.Download, null); Spacer(Modifier.width(6.dp)); Text("Baixar atualização") }
            }
        }
    )
}

@Composable
fun SonusOwnerUpdatePanel() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    val manager = remember { SonusUpdateManager(context) }
    var apks by remember { mutableStateOf<List<PCloudUpdateApk>>(emptyList()) }
    var selected by remember { mutableStateOf<PCloudUpdateApk?>(null) }
    var current by remember { mutableStateOf<SonusUpdateInfo?>(null) }
    var history by remember { mutableStateOf<List<SonusUpdateInfo>>(emptyList()) }
    var versionName by remember { mutableStateOf(BuildConfig.VERSION_NAME) }
    var versionCode by remember { mutableStateOf(BuildConfig.VERSION_CODE.toString()) }
    var changelog by remember { mutableStateOf(SONUS_CURRENT_VERSION_SUMMARY.joinToString("\n") { "• $it" }) }
    var mandatory by remember { mutableStateOf(false) }
    var minimumCode by remember { mutableStateOf("0") }
    var loading by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }

    fun refresh() {
        scope.launch {
            loading = true; status = null
            val listResult = manager.listPCloudApks()
            apks = listResult.getOrDefault(emptyList())
            current = manager.currentPublished().getOrNull()
            history = manager.updateHistory().getOrDefault(emptyList()).take(8)
            if (selected == null) selected = apks.firstOrNull()
            status = listResult.exceptionOrNull()?.message ?: if (apks.isEmpty()) "Nenhum APK encontrado na pasta SONUS ATUALIZAÇÃO." else "${apks.size} APK(s) encontrado(s)."
            loading = false
        }
    }
    LaunchedEffect(Unit) { refresh() }

    LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom=34.dp)) {
        item {
            Surface(
                shape=RoundedCornerShape(24.dp),
                color=Color(0xFF0B2230),
                border=BorderStroke(1.dp,Color(0xFF57C8FF).copy(alpha=.30f))
            ) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Surface(shape=RoundedCornerShape(15.dp),color=Color(0xFF57C8FF).copy(alpha=.13f)) { Icon(Icons.Default.SystemUpdateAlt,null,tint=Color(0xFF57C8FF),modifier=Modifier.padding(10.dp).size(28.dp)) }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) { Text("SONUS Update",fontWeight=FontWeight.Black,fontSize=20.sp,color=Color.White); Text("pCloud armazena • OWNER publica • Firebase distribui",color=Color.White.copy(alpha=.60f),style=MaterialTheme.typography.bodySmall) }
                        IconButton(onClick={refresh()},enabled=!loading){Icon(Icons.Default.Refresh,"Atualizar",tint=Color.White)}
                    }
                    current?.let { info ->
                        Surface(shape=RoundedCornerShape(14.dp), color=if(info.published)Color(0xFF123E31) else Color(0xFF40351C)) {
                            Column(Modifier.fillMaxWidth().padding(11.dp)) {
                                Text(if(info.published)"PUBLICADA" else "PAUSADA",fontWeight=FontWeight.Black,color=if(info.published)Color(0xFF62E6A5) else Color(0xFFFFC857))
                                Text("SONUS ${info.versionName} • code${info.versionCode}",color=Color.White,fontWeight=FontWeight.Bold)
                                Text(info.fileName,color=Color.White.copy(alpha=.58f),style=MaterialTheme.typography.labelSmall,maxLines=1,overflow=TextOverflow.Ellipsis)
                            }
                        }
                    } ?: Text("Nenhuma atualização publicada no Firebase.",color=Color.White.copy(alpha=.65f),style=MaterialTheme.typography.bodySmall)
                }
            }
        }
        if (loading) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
        item { Text("APK no pCloud",fontWeight=FontWeight.ExtraBold) }
        if (apks.isEmpty()) item { Text("Envie um APK para a pasta pública SONUS ATUALIZAÇÃO e toque em atualizar.",style=MaterialTheme.typography.bodySmall) }
        items(apks, key={it.fileId}) { apk ->
            val active = selected?.fileId == apk.fileId
            Surface(
                modifier=Modifier.fillMaxWidth().clickable{selected=apk},
                shape=RoundedCornerShape(16.dp),
                color=if(active)MaterialTheme.colorScheme.primaryContainer.copy(alpha=.55f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.38f),
                border=BorderStroke(1.dp,if(active)MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha=.14f))
            ) {
                Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically) {
                    Icon(Icons.Default.Android,null,tint=if(active)MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha=.65f))
                    Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)){Text(apk.name,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis);Text(formatUpdateBytes(apk.size),style=MaterialTheme.typography.labelSmall)}
                    if(active)Icon(Icons.Default.CheckCircle,null,tint=MaterialTheme.colorScheme.primary)
                }
            }
        }
        item {
            Surface(shape=RoundedCornerShape(20.dp),color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.33f)) {
                Column(Modifier.fillMaxWidth().padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                    Text("Publicar atualização",fontWeight=FontWeight.Black,fontSize=18.sp)
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(versionName,{versionName=it},label={Text("Versão")},singleLine=true,modifier=Modifier.weight(1f))
                        OutlinedTextField(versionCode,{versionCode=it.filter(Char::isDigit)},label={Text("Code")},singleLine=true,modifier=Modifier.weight(1f))
                    }
                    OutlinedTextField(changelog,{changelog=it},label={Text("O que há de novo")},minLines=4,maxLines=8,modifier=Modifier.fillMaxWidth())
                    Row(verticalAlignment=Alignment.CenterVertically) { Switch(mandatory,{mandatory=it}); Spacer(Modifier.width(8.dp)); Column{Text("Atualização obrigatória",fontWeight=FontWeight.Bold);Text("Use somente para correções críticas.",style=MaterialTheme.typography.labelSmall)} }
                    OutlinedTextField(minimumCode,{minimumCode=it.filter(Char::isDigit)},label={Text("Code mínimo permitido (opcional)")},singleLine=true,modifier=Modifier.fillMaxWidth())
                    Button(
                        onClick={
                            val apk=selected ?: return@Button
                            val code=versionCode.toIntOrNull() ?: 0
                            val min=minimumCode.toIntOrNull() ?: 0
                            loading=true;status="Validando APK e calculando SHA-256…"
                            scope.launch {
                                val result=manager.publishUpdate(apk,code,versionName,changelog,mandatory,min)
                                loading=false
                                result.onSuccess { current=it;history=(listOf(it)+history.filterNot { old -> old.versionCode == it.versionCode }).sortedByDescending { row -> row.versionCode }.take(8);status="✓ SONUS ${it.versionName} / code${it.versionCode} publicado." }
                                    .onFailure { status=it.message ?: "Falha ao publicar atualização." }
                            }
                        },
                        enabled=!loading && selected!=null && versionCode.toIntOrNull()!=null && versionName.isNotBlank(),
                        modifier=Modifier.fillMaxWidth()
                    ){Icon(Icons.Default.Publish,null);Spacer(Modifier.width(7.dp));Text("PUBLICAR ATUALIZAÇÃO",fontWeight=FontWeight.Black)}
                    if (current?.published == true) {
                        OutlinedButton(
                            onClick={scope.launch{loading=true;val r=manager.pauseCurrentUpdate();loading=false;r.onSuccess{current=current?.copy(published=false);status="Atualização pausada."}.onFailure{status=it.message}}},
                            enabled=!loading,
                            modifier=Modifier.fillMaxWidth()
                        ){Icon(Icons.Default.PauseCircle,null);Spacer(Modifier.width(7.dp));Text("Pausar publicação")}
                    } else if (current != null) {
                        OutlinedButton(
                            onClick={scope.launch{loading=true;val r=manager.resumeCurrentUpdate();loading=false;r.onSuccess{current=current?.copy(published=true);status="Atualização publicada novamente."}.onFailure{status=it.message}}},
                            enabled=!loading,
                            modifier=Modifier.fillMaxWidth()
                        ){Icon(Icons.Default.PlayCircle,null);Spacer(Modifier.width(7.dp));Text("Retomar publicação")}
                    }
                }
            }
        }
        if (history.isNotEmpty()) {
            item { Text("Histórico de publicações", fontWeight = FontWeight.ExtraBold) }
            items(history, key={"history-${it.versionCode}"}) { info ->
                Surface(shape=RoundedCornerShape(14.dp), color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.28f)) {
                    Row(Modifier.fillMaxWidth().padding(11.dp), verticalAlignment=Alignment.CenterVertically) {
                        Icon(Icons.Default.History, null, tint=MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(9.dp))
                        Column(Modifier.weight(1f)) {
                            Text("SONUS ${info.versionName} • code${info.versionCode}", fontWeight=FontWeight.Bold)
                            Text(info.fileName, style=MaterialTheme.typography.labelSmall, maxLines=1, overflow=TextOverflow.Ellipsis)
                        }
                        Text(if(current?.versionCode==info.versionCode && current?.published==true)"Ativa" else "Histórico", style=MaterialTheme.typography.labelSmall, color=MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
        status?.let { item { Text(it,fontWeight=FontWeight.SemiBold,color=MaterialTheme.colorScheme.primary) } }
    }
}

val SONUS_CURRENT_VERSION_SUMMARY = listOf(
    "Player mais inteligente quando a biblioteca local não está disponível.",
    "Estatísticas com Mês e 30 dias separados e períodos mais visíveis.",
    "Social Edit agora aceita múltiplas imagens com fade individual.",
    "Diagnóstico de anúncios aprimorado para testes OWNER."
)

private fun formatUpdateBytes(bytes: Long): String {
    if (bytes <= 0L) return "—"
    val mb = bytes / (1024.0 * 1024.0)
    return if (mb >= 1024.0) String.format(Locale.getDefault(), "%.2f GB", mb / 1024.0) else String.format(Locale.getDefault(), "%.1f MB", mb)
}

private suspend fun com.google.android.gms.tasks.Task<DataSnapshot>.awaitUpdateSnapshot(): DataSnapshot =
    suspendCancellableCoroutine { c ->
        addOnCompleteListener { task ->
            if (!c.isActive) return@addOnCompleteListener
            if (task.isSuccessful) c.resume(task.result)
            else c.resumeWithException(task.exception ?: IllegalStateException("Falha ao consultar Firebase."))
        }
    }

private suspend fun com.google.android.gms.tasks.Task<Void>.awaitUpdateVoid(): Unit =
    suspendCancellableCoroutine { c ->
        addOnCompleteListener { task ->
            if (!c.isActive) return@addOnCompleteListener
            if (task.isSuccessful) c.resume(Unit)
            else c.resumeWithException(task.exception ?: IllegalStateException("Falha ao salvar atualização no Firebase."))
        }
    }
