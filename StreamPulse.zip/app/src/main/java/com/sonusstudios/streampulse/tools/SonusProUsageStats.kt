package com.sonusstudios.streampulse.tools

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Métricas privadas e locais das ferramentas PRO da code103. */
class SonusProUsageStats(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("sonus_pro_usage_v1", Context.MODE_PRIVATE)
    private val lock = Any()

    data class Snapshot(
        val coinUnlocks: Int,
        val adUnlocks: Int,
        val blocksUnlocked: Int,
        val operations: Int,
        val filesProcessed: Int,
        val favoriteTool: String?,
        val toolOperations: Map<String, Int>
    )

    fun recordUnlock(tool: String, viaAd: Boolean) = append("unlock", tool, if (viaAd) "ad" else "coin", 0)
    fun recordOperation(tool: String, files: Int) = append("operation", tool, "", files.coerceAtLeast(0))

    fun snapshot(startMs: Long? = null, endMs: Long? = null): Snapshot = synchronized(lock) {
        val arr = load()
        var coin = 0; var ad = 0; var operations = 0; var files = 0
        val toolCounts = linkedMapOf<String, Int>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val ts = o.optLong("ts")
            if (startMs != null && ts < startMs) continue
            if (endMs != null && ts > endMs) continue
            when (o.optString("kind")) {
                "unlock" -> if (o.optString("method") == "ad") ad++ else coin++
                "operation" -> {
                    operations++
                    files += o.optInt("files")
                    val tool = o.optString("tool").ifBlank { "Ferramenta PRO" }
                    toolCounts[tool] = (toolCounts[tool] ?: 0) + 1
                }
            }
        }
        Snapshot(
            coinUnlocks = coin,
            adUnlocks = ad,
            blocksUnlocked = coin + ad,
            operations = operations,
            filesProcessed = files,
            favoriteTool = toolCounts.maxByOrNull { it.value }?.key,
            toolOperations = toolCounts.toMap()
        )
    }

    fun clear() = synchronized(lock) { prefs.edit().remove("events").apply() }

    private fun append(kind: String, tool: String, method: String, files: Int) = synchronized(lock) {
        val old = load()
        val out = JSONArray()
        val keepFrom = (old.length() - 1499).coerceAtLeast(0)
        for (i in keepFrom until old.length()) out.put(old.optJSONObject(i))
        out.put(JSONObject().apply {
            put("kind", kind); put("tool", tool.take(80)); put("method", method); put("files", files); put("ts", System.currentTimeMillis())
        })
        prefs.edit().putString("events", out.toString()).apply()
    }

    private fun load(): JSONArray = runCatching { JSONArray(prefs.getString("events", "[]") ?: "[]") }.getOrDefault(JSONArray())
}
