package com.sonusstudios.streampulse.core

/**
 * Planos públicos do SONUS.
 *
 * A ordem é proposital: ela é usada por comparações de acesso (ordinal).
 * FREE < BRONZE < PRATA < OURO < DIAMANTE.
 */
enum class MembershipTier {
    FREE,
    BRONZE,
    PRATA,
    OURO,
    DIAMANTE
}


enum class PulseFeaturePass {
    PULSE_LIFT,
    PULSE_ORBIT_3D,
    PULSE_ORBIT_8D,
    VOCAL_REMOVER,
    PITCH_PRO,
    MERGE_PRO,
    VIDEO_AUDIO_PRO
}

fun featurePassUntil(preferences: UserPreferences, feature: PulseFeaturePass): Long? = when (feature) {
    PulseFeaturePass.PULSE_LIFT -> preferences.passPulseLiftUntilEpochMillis
    PulseFeaturePass.PULSE_ORBIT_3D -> preferences.passPulseOrbit3dUntilEpochMillis
    PulseFeaturePass.PULSE_ORBIT_8D -> preferences.passPulseOrbit8dUntilEpochMillis
    PulseFeaturePass.VOCAL_REMOVER -> preferences.passVocalRemoverUntilEpochMillis
    PulseFeaturePass.PITCH_PRO -> preferences.passPitchProUntilEpochMillis
    PulseFeaturePass.MERGE_PRO -> preferences.passMergeProUntilEpochMillis
    PulseFeaturePass.VIDEO_AUDIO_PRO -> preferences.passVideoAudioProUntilEpochMillis
}

fun hasActiveFeaturePass(preferences: UserPreferences, feature: PulseFeaturePass, nowEpochMillis: Long = System.currentTimeMillis()): Boolean =
    (featurePassUntil(preferences, feature) ?: 0L) > nowEpochMillis

fun requiredTierFor(feature: PulseFeaturePass): MembershipTier = when (feature) {
    PulseFeaturePass.PULSE_LIFT, PulseFeaturePass.PULSE_ORBIT_3D, PulseFeaturePass.PULSE_ORBIT_8D -> MembershipTier.FREE
    PulseFeaturePass.VOCAL_REMOVER, PulseFeaturePass.PITCH_PRO,
    PulseFeaturePass.MERGE_PRO, PulseFeaturePass.VIDEO_AUDIO_PRO -> MembershipTier.PRATA
}

fun hasFeatureAccess(tier: MembershipTier, preferences: UserPreferences, feature: PulseFeaturePass, owner: Boolean = false): Boolean =
    owner || commercialTier(tier).ordinal >= commercialTier(requiredTierFor(feature)).ordinal || hasActiveFeaturePass(preferences, feature)

data class PremiumPlanInfo(
    val tier: MembershipTier,
    val title: String,
    val monthlyPrice: String,
    val annualPrice: String? = null,
    val artistLimitLabel: String,
    val benefits: List<String>,
    val highlight: String? = null
)

/**
 * Catálogo comercial SONUS 1.0.16 / code119.
 * BRONZE permanece apenas para migração segura e é normalizado para PRATA.
 */
object PremiumCatalog {
    val prata = PremiumPlanInfo(
        MembershipTier.PRATA,
        "Prata",
        "R$ 8,90 / mês",
        "R$ 89,00 / ano",
        "Até 3 artistas",
        listOf(
            "200 Moedas SONUS por mês",
            "Até 10 músicas/mês no SONUS Stream",
            "SOCIAL EDIT de 30 a 65 segundos",
            "Distribuição & Pagamentos completa",
            "Widgets financeiros e Caixa Preta SONUS",
            "Ferramentas PRO: 1 moeda por bloco de até 5 arquivos",
            "Temas e ícones Prata"
        ),
        "2 meses grátis no anual"
    )

    val ouro = PremiumPlanInfo(
        MembershipTier.OURO,
        "Ouro",
        "R$ 14,90 / mês",
        "R$ 149,00 / ano",
        "Até 8 artistas",
        listOf(
            "500 Moedas SONUS por mês",
            "Até 20 músicas/mês no SONUS Stream",
            "SOCIAL EDIT de 30 a 65 segundos",
            "Lotes maiores nas ferramentas PRO",
            "Prioridade superior no SONUS Stream",
            "Projeções e planejamento financeiro avançados",
            "Temas e ícones Prata + Ouro"
        ),
        "Recomendado • melhor custo-benefício"
    )

    val diamante = PremiumPlanInfo(
        MembershipTier.DIAMANTE,
        "Diamante",
        "R$ 24,90 / mês",
        "R$ 249,00 / ano",
        "Artistas ilimitados",
        listOf(
            "Moedas e ferramentas elegíveis ilimitadas",
            "Até 30 músicas/mês no SONUS Stream",
            "SOCIAL EDIT de 30 a 65 segundos",
            "Lotes ilimitados nas ferramentas elegíveis",
            "Prioridade máxima no SONUS Stream",
            "Todos os temas, ícones e personalizações",
            "Todos os recursos PRO elegíveis"
        ),
        "2 meses grátis no anual"
    )

    val plans = listOf(prata, ouro, diamante)
}

/** Franquia mensal de Moedas SONUS. */
fun monthlyToolUsageAllowance(tier: MembershipTier): Int = when (commercialTier(tier)) {
    MembershipTier.FREE -> 5
    MembershipTier.PRATA -> 200
    MembershipTier.OURO -> 500
    MembershipTier.DIAMANTE -> Int.MAX_VALUE
    else -> 200
}

fun converterMonthlyCoinAllowance(tier: MembershipTier): Int = monthlyToolUsageAllowance(tier)
fun pulseMonthlyCoinAllowance(tier: MembershipTier): Int = monthlyToolUsageAllowance(tier)

/** Normaliza somente o BRONZE legado para PRATA. */
fun commercialTier(tier: MembershipTier): MembershipTier = when (tier) {
    MembershipTier.BRONZE -> MembershipTier.PRATA
    else -> tier
}
