package com.sonusstudios.streampulse.tools

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioDeviceInfo
import android.media.AudioDeviceCallback
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.os.Handler
import android.os.Looper
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MonitorHeart
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs

/** Mic monitor. Playback is forced to a connected wired/USB/Bluetooth headset; speaker output is rejected. */
internal class SonusAudioMonitorEngine(context: Context) {
    private val app = context.applicationContext
    private val audioManager = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    @Volatile private var running = false
    @Volatile private var gain = 0.85f
    private var record: AudioRecord? = null
    private var track: AudioTrack? = null
    private var worker: Thread? = null
    private var echo: AcousticEchoCanceler? = null
    private var noise: NoiseSuppressor? = null
    private var agc: AutomaticGainControl? = null
    private var previousMode = AudioManager.MODE_NORMAL
    private var previousSpeakerphone = false
    private val mainHandler = Handler(Looper.getMainLooper())

    fun setGain(value: Float) { gain = value.coerceIn(0.15f, 1.25f) }

    @Synchronized
    fun start(input: AudioDeviceInfo, output: AudioDeviceInfo, gain: Float, echoCancellation: Boolean, onLevel: (Float) -> Unit) {
        stop()
        require(isSafeHeadphone(output)) { "Selecione um fone com fio, USB ou Bluetooth. A saída de caixa de som é bloqueada para evitar microfonia." }
        require(input.isSource) { "A entrada selecionada não está disponível." }
        this.gain = gain.coerceIn(0.15f, 1.25f)
        val rate = 48_000
        val channelIn = AudioFormat.CHANNEL_IN_MONO
        val channelOut = AudioFormat.CHANNEL_OUT_MONO
        val encoding = AudioFormat.ENCODING_PCM_16BIT
        val minIn = AudioRecord.getMinBufferSize(rate, channelIn, encoding)
        val minOut = AudioTrack.getMinBufferSize(rate, channelOut, encoding)
        require(minIn > 0 && minOut > 0) { "Este aparelho não oferece um caminho de áudio compatível." }
        val bufferBytes = maxOf(minIn, minOut, rate / 5)
        val formatIn = AudioFormat.Builder().setSampleRate(rate).setChannelMask(channelIn).setEncoding(encoding).build()
        val formatOut = AudioFormat.Builder().setSampleRate(rate).setChannelMask(channelOut).setEncoding(encoding).build()
        val inputRecorder = AudioRecord.Builder()
            .setAudioSource(MediaRecorder.AudioSource.VOICE_COMMUNICATION)
            .setAudioFormat(formatIn)
            .setBufferSizeInBytes(bufferBytes)
            .build()
        val outputTrack = AudioTrack.Builder()
            .setAudioAttributes(android.media.AudioAttributes.Builder()
                .setUsage(android.media.AudioAttributes.USAGE_VOICE_COMMUNICATION)
                .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SPEECH)
                .build())
            .setAudioFormat(formatOut)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setBufferSizeInBytes(bufferBytes)
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            .build()
        if (!inputRecorder.setPreferredDevice(input)) {
            inputRecorder.release(); outputTrack.release()
            throw IllegalStateException("O Android não aceitou a entrada selecionada. Atualize a lista de dispositivos e tente novamente.")
        }
        if (!outputTrack.setPreferredDevice(output)) {
            inputRecorder.release(); outputTrack.release()
            throw IllegalStateException("O Android não aceitou a rota para o fone selecionado.")
        }
        previousMode = audioManager.mode
        previousSpeakerphone = audioManager.isSpeakerphoneOn
        audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
        audioManager.isSpeakerphoneOn = false
        record = inputRecorder
        track = outputTrack
        if (echoCancellation && AcousticEchoCanceler.isAvailable()) {
            echo = runCatching { AcousticEchoCanceler.create(inputRecorder.audioSessionId)?.apply { enabled = true } }.getOrNull()
        }
        if (NoiseSuppressor.isAvailable()) noise = runCatching { NoiseSuppressor.create(inputRecorder.audioSessionId)?.apply { enabled = true } }.getOrNull()
        if (AutomaticGainControl.isAvailable()) agc = runCatching { AutomaticGainControl.create(inputRecorder.audioSessionId)?.apply { enabled = false } }.getOrNull()
        inputRecorder.startRecording()
        outputTrack.play()
        running = true
        worker = Thread {
            val samples = ShortArray(bufferBytes / 2)
            var lastUi = 0L
            try {
                while (running) {
                    val count = inputRecorder.read(samples, 0, samples.size, AudioRecord.READ_BLOCKING)
                    if (count <= 0) continue
                    var peak = 0
                    val localGain = gain
                    for (i in 0 until count) {
                        val amplified = (samples[i] * localGain).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                        samples[i] = amplified.toShort()
                        peak = maxOf(peak, abs(amplified))
                    }
                    var offset = 0
                    while (running && offset < count) {
                        val written = outputTrack.write(samples, offset, count - offset, AudioTrack.WRITE_BLOCKING)
                        if (written <= 0) break
                        offset += written
                    }
                    val now = System.currentTimeMillis()
                    if (now - lastUi >= 90L) {
                        lastUi = now
                        val level = (peak / 32767f).coerceIn(0f, 1f)
                        mainHandler.post { if (running) onLevel(level) }
                    }
                }
            } catch (_: Throwable) {
                // O stop do serviço pode interromper read/write; a UI recebe a parada ao liberar.
            }
        }.apply { name = "SONUS-Audio-Monitor"; priority = Thread.MAX_PRIORITY; start() }
    }

    @Synchronized
    fun stop() {
        running = false
        runCatching { record?.stop() }
        runCatching { track?.pause() }
        runCatching { track?.flush() }
        runCatching { worker?.join(500) }
        worker = null
        runCatching { echo?.release() }; echo = null
        runCatching { noise?.release() }; noise = null
        runCatching { agc?.release() }; agc = null
        runCatching { record?.release() }; record = null
        runCatching { track?.stop() }; runCatching { track?.release() }; track = null
        runCatching { audioManager.isSpeakerphoneOn = previousSpeakerphone }
        runCatching { audioManager.mode = previousMode }
    }

    private fun isSafeHeadphone(device: AudioDeviceInfo): Boolean = isSafeOutputDevice(device)

    companion object {
        val safeOutputTypes = setOf(
            AudioDeviceInfo.TYPE_WIRED_HEADSET,
            AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
            AudioDeviceInfo.TYPE_USB_HEADSET,
            AudioDeviceInfo.TYPE_USB_DEVICE,
            AudioDeviceInfo.TYPE_BLUETOOTH_A2DP,
            AudioDeviceInfo.TYPE_BLUETOOTH_SCO,
            AudioDeviceInfo.TYPE_BLE_HEADSET
        )
        fun isSafeOutputDevice(device: AudioDeviceInfo): Boolean {
            if (!device.isSink || device.type !in safeOutputTypes) return false
            if (device.type != AudioDeviceInfo.TYPE_BLUETOOTH_A2DP) return true
            // Android reports both A2DP headphones and A2DP speakers with the same device type.
            // Permit only names that clearly identify a headset/earbud; unknown A2DP routes are blocked.
            val label = device.productName?.toString()?.lowercase().orEmpty()
            val headphoneHints = listOf("headphone", "headset", "earbud", "earphone", "airpod", "buds", "fone", "quietcomfort", "freebuds", "wh-", "wf-", "tune", "pixel bud", "galaxy bud")
            return headphoneHints.any(label::contains)
        }
        val inputTypes = setOf(
            AudioDeviceInfo.TYPE_BUILTIN_MIC,
            AudioDeviceInfo.TYPE_WIRED_HEADSET,
            AudioDeviceInfo.TYPE_USB_HEADSET,
            AudioDeviceInfo.TYPE_USB_DEVICE,
            AudioDeviceInfo.TYPE_LINE_ANALOG,
            AudioDeviceInfo.TYPE_LINE_DIGITAL,
            AudioDeviceInfo.TYPE_AUX_LINE,
            AudioDeviceInfo.TYPE_BLUETOOTH_SCO,
            AudioDeviceInfo.TYPE_BLE_HEADSET
        )
        fun deviceLabel(device: AudioDeviceInfo): String {
            val name = device.productName?.toString()?.takeIf { it.isNotBlank() } ?: "Dispositivo de áudio"
            val type = when (device.type) {
                AudioDeviceInfo.TYPE_BUILTIN_MIC -> "Microfone do celular"
                AudioDeviceInfo.TYPE_WIRED_HEADSET -> if (device.isSource) "Fone com microfone" else "Fone com fio"
                AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> "Fone com fio"
                AudioDeviceInfo.TYPE_USB_HEADSET, AudioDeviceInfo.TYPE_USB_DEVICE -> "USB / entrada externa"
                AudioDeviceInfo.TYPE_LINE_ANALOG, AudioDeviceInfo.TYPE_LINE_DIGITAL, AudioDeviceInfo.TYPE_AUX_LINE -> "Entrada de linha externa"
                AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_BLUETOOTH_SCO, AudioDeviceInfo.TYPE_BLE_HEADSET -> "Bluetooth"
                else -> "Áudio externo"
            }
            return "$type • $name"
        }
    }
}

@Composable
internal fun SonusAudioMonitorScreen(onBack: () -> Unit, onTrack: (String, Boolean?, Long?) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val audioManager = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val engine = remember { SonusAudioMonitorEngine(context) }
    var inputs by remember { mutableStateOf(audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS).filter { it.type in SonusAudioMonitorEngine.inputTypes }) }
    var outputs by remember { mutableStateOf(audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS).filter(SonusAudioMonitorEngine::isSafeOutputDevice)) }
    var inputId by remember { mutableIntStateOf(inputs.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_MIC }?.id ?: inputs.firstOrNull()?.id ?: -1) }
    var outputId by remember { mutableIntStateOf(outputs.firstOrNull { it.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES || it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET }?.id ?: outputs.firstOrNull()?.id ?: -1) }
    var gain by remember { mutableFloatStateOf(.85f) }
    var echoCancellation by remember { mutableStateOf(true) }
    var running by remember { mutableStateOf(false) }
    var level by remember { mutableFloatStateOf(0f) }
    var error by remember { mutableStateOf<String?>(null) }

    fun refreshDevices() {
        val previousOutputId = outputId
        inputs = audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS)
            .filter { it.type in SonusAudioMonitorEngine.inputTypes }
            .distinctBy { "${it.type}:${it.productName}" }
        outputs = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
            .filter(SonusAudioMonitorEngine::isSafeOutputDevice)
            .distinctBy { "${it.type}:${it.productName}" }
        if (inputs.none { it.id == inputId }) inputId = inputs.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_MIC }?.id ?: inputs.firstOrNull()?.id ?: -1
        if (outputs.none { it.id == outputId }) outputId = outputs.firstOrNull()?.id ?: -1
        if (running && outputs.none { it.id == previousOutputId }) {
            scope.launch(Dispatchers.IO) { engine.stop() }
            running = false
            level = 0f
            error = "O fone foi desconectado. O monitor foi interrompido por segurança."
        }
    }

    DisposableEffect(audioManager) {
        val callback = object : AudioDeviceCallback() {
            override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>) { Handler(Looper.getMainLooper()).post { refreshDevices() } }
            override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>) { Handler(Looper.getMainLooper()).post { refreshDevices() } }
        }
        audioManager.registerAudioDeviceCallback(callback, Handler(Looper.getMainLooper()))
        onDispose { audioManager.unregisterAudioDeviceCallback(callback) }
    }

    fun beginMonitor() {
        val input = inputs.firstOrNull { it.id == inputId }
        val output = outputs.firstOrNull { it.id == outputId }
        if (input == null) { error = "Nenhuma entrada de microfone compatível foi detectada."; return }
        if (output == null) { error = "Conecte um fone com fio, USB ou Bluetooth. A caixa de som não é usada como retorno."; return }
        scope.launch {
            try {
                withContext(Dispatchers.IO) { engine.start(input, output, gain, echoCancellation) { value -> level = value } }
                running = true
                error = null
                onTrack("Monitor de Áudio Premium", true, null)
            } catch (t: Throwable) {
                withContext(Dispatchers.IO) { engine.stop() }
                running = false
                error = t.message ?: "Não foi possível iniciar o monitor de áudio."
                onTrack("Monitor de Áudio Premium", false, null)
            }
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) beginMonitor() else error = "Permissão de microfone negada."
    }
    DisposableEffect(Unit) { onDispose { engine.stop() } }

    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF150B13), Color(0xFF25111A), Color(0xFF080B12)))).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { engine.stop(); onBack() }) { Icon(Icons.Default.ArrowBack, "Voltar", tint = Color.White) }
            Column(Modifier.weight(1f)) {
                Text("SONUS AUDIO MONITOR", color = Color.White, fontWeight = FontWeight.Black, fontSize = 19.sp)
                Text("Retorno de voz • monitoramento local", color = Color.White.copy(alpha = .60f), fontSize = 10.sp)
            }
            Icon(Icons.Default.MonitorHeart, null, tint = Color(0xFFFF6478), modifier = Modifier.size(26.dp))
        }

        Card(colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = .06f)), border = BorderStroke(1.dp, Color(0xFFFF6478).copy(alpha = .26f))) {
            Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Mic, null, tint = Color(0xFFFF8191))
                    Spacer(Modifier.width(8.dp)); Text("ENTRADA DE ÁUDIO", color = Color.White, fontWeight = FontWeight.Black, fontSize = 12.sp)
                    Spacer(Modifier.weight(1f)); TextButton(onClick = { if (!running) refreshDevices() }, enabled = !running) { Text("Atualizar") }
                }
                Text("Microfone do celular ou entrada externa USB/fone com microfone. A saída de uma caixa Bluetooth não pode ser capturada como entrada genérica do Android.", color = Color.White.copy(alpha = .64f), fontSize = 10.sp)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    items(inputs, key = { it.id }) { device ->
                        FilterChip(selected = inputId == device.id, onClick = { if (!running) inputId = device.id }, enabled = !running,
                            label = { Text(SonusAudioMonitorEngine.deviceLabel(device), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 9.sp) })
                    }
                }
                if (inputs.none { it.type != AudioDeviceInfo.TYPE_BUILTIN_MIC }) Text("Nenhuma entrada externa detectada • usando o microfone do aparelho.", color = Color.White.copy(alpha = .46f), fontSize = 9.sp)
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = .06f)), border = BorderStroke(1.dp, Color(0xFF65D8FF).copy(alpha = .25f))) {
            Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Headphones, null, tint = Color(0xFF65D8FF)); Spacer(Modifier.width(8.dp)); Text("SAÍDA / RETORNO", color = Color.White, fontWeight = FontWeight.Black, fontSize = 12.sp) }
                Text("O retorno é direcionado somente para fones com fio, USB ou Bluetooth. A saída por alto-falante é bloqueada para reduzir risco de microfonia.", color = Color.White.copy(alpha = .64f), fontSize = 10.sp)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    items(outputs, key = { it.id }) { device ->
                        FilterChip(selected = outputId == device.id, onClick = { if (!running) outputId = device.id }, enabled = !running,
                            label = { Text(SonusAudioMonitorEngine.deviceLabel(device), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 9.sp) })
                    }
                }
                if (outputs.isEmpty()) Text("Nenhum fone compatível detectado. Caixas Bluetooth e dispositivos A2DP sem identificação clara de fone são bloqueados para evitar retorno em alto-falante.", color = Color(0xFFFFA5AD), fontSize = 10.sp)
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = .06f))) {
            Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Tune, null, tint = Color(0xFFFFB46A)); Spacer(Modifier.width(8.dp)); Text("AJUSTE FINO", color = Color.White, fontWeight = FontWeight.Black, fontSize = 12.sp) }
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Ganho", color = Color.White.copy(alpha = .75f), fontSize = 10.sp); Spacer(Modifier.weight(1f)); Text("${(gain * 100).toInt()}%", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 10.sp) }
                Slider(value = gain, onValueChange = { gain = it; engine.setGain(it) }, valueRange = .15f..1.25f)
                Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("Proteção contra eco", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 10.sp); Text("AEC e supressão de ruído quando o aparelho oferece suporte", color = Color.White.copy(alpha = .50f), fontSize = 8.sp) }; Switch(checked = echoCancellation, onCheckedChange = { if (!running) echoCancellation = it }, enabled = !running) }
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = .25f)), border = BorderStroke(1.dp, Color.White.copy(alpha = .10f))) {
            Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.GraphicEq, null, tint = Color(0xFF65D8FF)); Spacer(Modifier.width(8.dp)); Text(if (running) "MONITOR ATIVO" else "MONITOR EM ESPERA", color = Color.White, fontWeight = FontWeight.Black, fontSize = 11.sp) }
                LinearProgressIndicator(progress = { level }, modifier = Modifier.fillMaxWidth().height(8.dp), color = Color(0xFF65D8FF), trackColor = Color.White.copy(alpha = .08f))
                Text(if (running) "Nível de entrada ${(level * 100).toInt()}% • saída em fone" else "A latência depende do aparelho e da rota. Bluetooth sempre acrescenta atraso perceptível.", color = Color.White.copy(alpha = .58f), fontSize = 9.sp)
            }
        }

        error?.let { Text(it, color = Color(0xFFFF9AA4), fontSize = 10.sp) }
        Button(onClick = {
            if (running) {
                scope.launch(Dispatchers.IO) { engine.stop() }
                running = false; level = 0f; onTrack("Monitor de Áudio Premium", true, null)
            } else if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) beginMonitor()
            else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }, enabled = running || outputs.isNotEmpty(), modifier = Modifier.fillMaxWidth().height(52.dp), colors = ButtonDefaults.buttonColors(containerColor = if (running) Color(0xFF8C2435) else Color(0xFF176A80))) {
            Icon(if (running) Icons.Default.Stop else Icons.Default.GraphicEq, null); Spacer(Modifier.width(8.dp)); Text(if (running) "Parar monitor" else "Iniciar monitor", fontWeight = FontWeight.Black)
        }
        Text("Atenção: latência zero não é garantida. Não use alto-falantes como retorno; o monitor deve ser usado com fones.", color = Color.White.copy(alpha = .45f), fontSize = 9.sp)
    }
}
