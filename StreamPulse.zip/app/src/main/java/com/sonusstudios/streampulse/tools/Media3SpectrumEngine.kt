package com.sonusstudios.streampulse.tools

import android.content.Context
import android.os.SystemClock
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.audio.TeeAudioProcessor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

/**
 * Analyzer PCM independente do Visualizer do fabricante.
 *
 * O player audível do SONUS continua preservado. Este ExoPlayer fica mudo e acompanha a mesma
 * faixa/posição somente para decodificar PCM pelo pipeline do Media3. O TeeAudioProcessor copia os
 * buffers sem alterar o áudio e a FFT é calculada fora da thread de áudio.
 */
@UnstableApi
internal class Media3SpectrumEngine(
    context: Context,
    private val scope: CoroutineScope,
    private val onSpectrum: (List<Float>) -> Unit
) {
    private val appContext = context.applicationContext
    private val processorBusy = AtomicBoolean(false)
    private val pcmSink = SpectrumPcmSink(scope, processorBusy) { values ->
        lastPcmAtMs = SystemClock.elapsedRealtime()
        onSpectrum(values)
    }
    private val teeProcessor = TeeAudioProcessor(pcmSink)

    private val renderersFactory = object : DefaultRenderersFactory(appContext) {
        override fun buildAudioSink(
            context: Context,
            enableFloatOutput: Boolean,
            enableAudioOutputPlaybackParams: Boolean
        ): AudioSink? {
            // Um AudioProcessor ativo força o caminho PCM e evita depender de offload/passthrough
            // de DSPs específicos do fabricante, que é justamente onde o Visualizer costuma morrer.
            return DefaultAudioSink.Builder(context)
                .setEnableFloatOutput(false)
                .setAudioProcessors(arrayOf<AudioProcessor>(teeProcessor))
                .build()
        }
    }

    private val analyzerPlayer: ExoPlayer = ExoPlayer.Builder(appContext, renderersFactory).build().apply {
        volume = 0f
        playWhenReady = false
    }

    /**
     * Renderers do player audível com TeeAudioProcessor no mesmo pipeline PCM.
     * Usado pelo SONUS Stream para não depender de um segundo player/URI sonusonline://.
     */
    fun createLiveRenderersFactory(): DefaultRenderersFactory {
        val liveBusy = AtomicBoolean(false)
        val liveSink = SpectrumPcmSink(scope, liveBusy) { values ->
            lastPcmAtMs = SystemClock.elapsedRealtime()
            onSpectrum(values)
        }
        val liveTee = TeeAudioProcessor(liveSink)
        return object : DefaultRenderersFactory(appContext) {
            override fun buildAudioSink(
                context: Context,
                enableFloatOutput: Boolean,
                enableAudioOutputPlaybackParams: Boolean
            ): AudioSink? = DefaultAudioSink.Builder(context)
                .setEnableFloatOutput(false)
                .setAudioProcessors(arrayOf<AudioProcessor>(liveTee))
                .build()
        }
    }

    fun resetFreshness() {
        lastPcmAtMs = 0L
    }

    private var currentUri: String? = null
    private var requestedPlaying = false
    private var requestedSpeed = 1f
    private var lastRestartAtMs = 0L
    @Volatile private var lastPcmAtMs = 0L

    fun load(uri: String, positionMs: Long, playing: Boolean, speed: Float) {
        analyzerPlayer.volume = 0f
        currentUri = uri
        requestedPlaying = playing
        requestedSpeed = speed.coerceIn(.5f, 2f)
        pcmSink.reset()
        lastPcmAtMs = 0L
        analyzerPlayer.setMediaItem(MediaItem.fromUri(uri), positionMs.coerceAtLeast(0L))
        analyzerPlayer.playbackParameters = PlaybackParameters(requestedSpeed)
        analyzerPlayer.prepare()
        analyzerPlayer.playWhenReady = playing
    }

    fun sync(uri: String, positionMs: Long, playing: Boolean, speed: Float) {
        analyzerPlayer.volume = 0f
        if (currentUri != uri) {
            load(uri, positionMs, playing, speed)
            return
        }
        requestedPlaying = playing
        requestedSpeed = speed.coerceIn(.5f, 2f)
        if (abs(analyzerPlayer.playbackParameters.speed - requestedSpeed) > .01f) {
            analyzerPlayer.playbackParameters = PlaybackParameters(requestedSpeed)
        }
        analyzerPlayer.playWhenReady = playing
        val diff = abs(analyzerPlayer.currentPosition - positionMs)
        if (diff > 450L) analyzerPlayer.seekTo(positionMs.coerceAtLeast(0L))
    }

    fun play() {
        analyzerPlayer.volume = 0f
        requestedPlaying = true
        analyzerPlayer.playWhenReady = true
    }

    fun pause() {
        requestedPlaying = false
        analyzerPlayer.volume = 0f
        analyzerPlayer.playWhenReady = false
        runCatching { analyzerPlayer.pause() }
    }

    fun seekTo(positionMs: Long) {
        analyzerPlayer.seekTo(positionMs.coerceAtLeast(0L))
        pcmSink.reset()
    }

    fun setSpeed(speed: Float) {
        requestedSpeed = speed.coerceIn(.5f, 2f)
        analyzerPlayer.playbackParameters = PlaybackParameters(requestedSpeed)
    }

    fun isFresh(nowMs: Long = SystemClock.elapsedRealtime(), maxAgeMs: Long = 1_700L): Boolean =
        lastPcmAtMs > 0L && nowMs - lastPcmAtMs <= maxAgeMs

    fun restartIfStale(positionMs: Long, nowMs: Long = SystemClock.elapsedRealtime()) {
        val uri = currentUri ?: return
        if (!requestedPlaying || isFresh(nowMs, 2_600L) || nowMs - lastRestartAtMs < 3_500L) return
        lastRestartAtMs = nowMs
        load(uri, positionMs, requestedPlaying, requestedSpeed)
    }

    fun stop() {
        requestedPlaying = false
        currentUri = null
        lastPcmAtMs = 0L
        pcmSink.reset()
        analyzerPlayer.stop()
        analyzerPlayer.clearMediaItems()
    }

    fun release() {
        runCatching { analyzerPlayer.release() }
    }

    private class SpectrumPcmSink(
        private val scope: CoroutineScope,
        private val processorBusy: AtomicBoolean,
        private val onSpectrum: (List<Float>) -> Unit
    ) : TeeAudioProcessor.AudioBufferSink {
        private val lock = Any()
        private var sampleRateHz = 44_100
        private var channelCount = 2
        private var encoding = C.ENCODING_PCM_16BIT
        // 512 amostras dão resposta mais rápida que a janela antiga de 1024 sem perder leitura musical.
        private val window = FloatArray(512)
        private var filled = 0
        private var lastDispatchAtMs = 0L
        private var adaptivePeak = .16f

        override fun flush(sampleRateHz: Int, channelCount: Int, encoding: Int) {
            synchronized(lock) {
                this.sampleRateHz = sampleRateHz.coerceAtLeast(8_000)
                this.channelCount = channelCount.coerceAtLeast(1)
                this.encoding = encoding
                filled = 0
                adaptivePeak = .16f
            }
        }

        fun reset() = synchronized(lock) { filled = 0; adaptivePeak = .16f }

        override fun handleBuffer(buffer: ByteBuffer) {
            val duplicate = buffer.asReadOnlyBuffer().order(ByteOrder.LITTLE_ENDIAN)
            var ready: FloatArray? = null
            var rate = sampleRateHz
            synchronized(lock) {
                val channels = channelCount.coerceAtLeast(1)
                val bytesPerSample = when (encoding) {
                    C.ENCODING_PCM_FLOAT, C.ENCODING_PCM_32BIT -> 4
                    C.ENCODING_PCM_24BIT -> 3
                    C.ENCODING_PCM_16BIT -> 2
                    C.ENCODING_PCM_8BIT -> 1
                    else -> return
                }
                val frameBytes = bytesPerSample * channels

                // Consome TODO o ByteBuffer. A implementação anterior encerrava ao completar uma janela
                // e descartava o restante daquele callback, criando saltos perceptíveis no visual.
                while (duplicate.remaining() >= frameBytes) {
                    var mono = 0f
                    when (encoding) {
                        C.ENCODING_PCM_FLOAT -> repeat(channels) { mono += duplicate.float.coerceIn(-1f, 1f) }
                        C.ENCODING_PCM_8BIT -> repeat(channels) { mono += ((duplicate.get().toInt() and 0xFF) - 128) / 128f }
                        C.ENCODING_PCM_24BIT -> repeat(channels) {
                            val b0 = duplicate.get().toInt() and 0xFF
                            val b1 = duplicate.get().toInt() and 0xFF
                            val b2 = duplicate.get().toInt() // mantém sinal no byte mais alto
                            val value = b0 or (b1 shl 8) or (b2 shl 16)
                            mono += value / 8_388_608f
                        }
                        C.ENCODING_PCM_32BIT -> repeat(channels) { mono += duplicate.int / 2_147_483_648f }
                        C.ENCODING_PCM_16BIT -> repeat(channels) { mono += duplicate.short / 32768f }
                    }
                    window[filled++] = (mono / channels).coerceIn(-1f, 1f)

                    if (filled >= window.size) {
                        val now = SystemClock.elapsedRealtime()
                        // ~55 Hz: o renderizador interpola no refresh da tela (60/90/120 Hz).
                        if (now - lastDispatchAtMs >= 18L && ready == null && processorBusy.compareAndSet(false, true)) {
                            ready = window.copyOf()
                            rate = sampleRateHz
                            lastDispatchAtMs = now
                        }
                        // 50% de sobreposição mantém continuidade entre FFTs.
                        window.copyInto(window, 0, window.size / 2, window.size)
                        filled = window.size / 2
                    }
                }
            }
            val samples = ready ?: return
            scope.launch(Dispatchers.Default) {
                try {
                    val spectrum = computeBands(samples, rate)
                    withContext(Dispatchers.Main.immediate) { onSpectrum(spectrum) }
                } finally {
                    processorBusy.set(false)
                }
            }
        }

        private fun computeBands(input: FloatArray, sampleRate: Int): List<Float> {
            val n = input.size
            val real = DoubleArray(n)
            val imag = DoubleArray(n)
            var peak = 0.0
            for (i in input.indices) {
                val hann = .5 - .5 * cos(2.0 * PI * i / (n - 1))
                real[i] = input[i] * hann
                peak = max(peak, abs(real[i]))
            }
            if (peak < .00035) return List(24) { 0f }
            fft(real, imag)

            val nyquist = sampleRate / 2.0
            val lowHz = 32.0
            val highHz = min(18_500.0, nyquist * .94)
            val raw = FloatArray(24)
            for (band in raw.indices) {
                val f0 = lowHz * Math.exp(ln(highHz / lowHz) * band / raw.size)
                val f1 = lowHz * Math.exp(ln(highHz / lowHz) * (band + 1) / raw.size)
                val b0 = ((f0 * n / sampleRate).toInt()).coerceIn(1, n / 2 - 1)
                val b1 = ((f1 * n / sampleRate).toInt()).coerceIn(b0 + 1, n / 2)
                var sum = 0.0
                var count = 0
                for (bin in b0 until b1) {
                    sum += hypot(real[bin], imag[bin])
                    count++
                }
                val avg = if (count == 0) 0.0 else sum / count
                // Compressão moderada: preserva diferença entre batida e sustentação.
                raw[band] = (ln(1.0 + avg * 13.0) / ln(14.0)).coerceIn(0.0, 1.0).toFloat()
            }

            val framePeak = raw.maxOrNull() ?: 0f
            // Normalização adaptativa impede músicas baixas de parecerem mortas sem manter tudo no teto.
            adaptivePeak = if (framePeak > adaptivePeak) {
                adaptivePeak * .40f + framePeak * .60f
            } else {
                max(.055f, adaptivePeak * .988f)
            }
            val ceiling = adaptivePeak.coerceIn(.055f, 1f)
            val normalized = FloatArray(raw.size) { i ->
                ((raw[i] - .004f).coerceAtLeast(0f) / ceiling).coerceIn(0f, 1f)
            }

            // Suavização apenas entre frequências vizinhas; suavização temporal é feita no UI motor.
            return List(normalized.size) { i ->
                val a = normalized[(i - 1).coerceAtLeast(0)]
                val b = normalized[i]
                val c = normalized[(i + 1).coerceAtMost(normalized.lastIndex)]
                (b * .70f + (a + c) * .15f).coerceIn(0f, 1f)
            }
        }

        private fun fft(real: DoubleArray, imag: DoubleArray) {
            val n = real.size
            var j = 0
            for (i in 1 until n) {
                var bit = n shr 1
                while (j and bit != 0) { j = j xor bit; bit = bit shr 1 }
                j = j xor bit
                if (i < j) {
                    val tr = real[i]; real[i] = real[j]; real[j] = tr
                    val ti = imag[i]; imag[i] = imag[j]; imag[j] = ti
                }
            }
            var len = 2
            while (len <= n) {
                val angle = -2.0 * PI / len
                val wLenR = cos(angle)
                val wLenI = kotlin.math.sin(angle)
                var i = 0
                while (i < n) {
                    var wr = 1.0
                    var wi = 0.0
                    for (k in 0 until len / 2) {
                        val uR = real[i + k]
                        val uI = imag[i + k]
                        val vR = real[i + k + len / 2] * wr - imag[i + k + len / 2] * wi
                        val vI = real[i + k + len / 2] * wi + imag[i + k + len / 2] * wr
                        real[i + k] = uR + vR
                        imag[i + k] = uI + vI
                        real[i + k + len / 2] = uR - vR
                        imag[i + k + len / 2] = uI - vI
                        val nextWr = wr * wLenR - wi * wLenI
                        wi = wr * wLenI + wi * wLenR
                        wr = nextWr
                    }
                    i += len
                }
                len = len shl 1
            }
        }
    }
}
