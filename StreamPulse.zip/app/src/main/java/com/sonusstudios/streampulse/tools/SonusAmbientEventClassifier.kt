package com.sonusstudios.streampulse.tools

import android.content.Context
import org.tensorflow.lite.Interpreter
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Classificador local de eventos acústicos baseado no YAMNet AudioSet (521 classes).
 * Recebe PCM mono 16 kHz, mantém uma janela de 0,975 s e classifica localmente.
 * Nenhum áudio é gravado em disco ou enviado para rede.
 */
internal class SonusAmbientEventClassifier(context: Context) : AutoCloseable {
    data class Scores(
        val traffic: Float = 0f,
        val emergency: Float = 0f,
        val speech: Float = 0f,
        val announcement: Float = 0f,
        val alarm: Float = 0f,
        val transit: Float = 0f
    )

    private val modelFile = File(context.cacheDir, "sonus_yamnet.tflite")
    private val interpreter: Interpreter
    private val labels: List<String>
    private val window = FloatArray(WINDOW_SAMPLES)
    private var samplesInWindow = 0
    private var closed = false

    init {
        if (!modelFile.exists() || modelFile.length() < 1_000_000L) {
            context.assets.open("yamnet.tflite").use { input -> modelFile.outputStream().use { output -> input.copyTo(output) } }
        }
        interpreter = Interpreter(modelFile, Interpreter.Options().setNumThreads(2))
        labels = context.assets.open("yamnet_label_list.txt").bufferedReader().useLines { lines ->
            lines.mapNotNull { line ->
                val trimmed = line.trim()
                if (trimmed.isEmpty() || trimmed.startsWith("index", ignoreCase = true)) null
                else {
                    // O arquivo oficial de labels do modelo pode vir como lista simples (1 label/linha)
                    // ou no formato CSV index,mid,label. Aceitamos ambos para não deixar o classificador
                    // sem categorias quando o provedor publica o companion file em formato simples.
                    val parts = trimmed.split(',', limit = 3)
                    if (parts.size >= 3 && parts[0].trim().toIntOrNull() != null) {
                        parts[2].trim().trim('"')
                    } else {
                        trimmed.trim('"')
                    }
                }
            }.toList()
        }
        require(labels.size >= OUTPUT_CLASSES) { "Lista de categorias YAMNet incompleta." }
        require(interpreter.getInputTensor(0).numElements() == WINDOW_SAMPLES) { "Formato de entrada YAMNet inesperado." }
        require(interpreter.getOutputTensor(0).numElements() >= OUTPUT_CLASSES) { "Formato de saída YAMNet inesperado." }
    }

    @Synchronized
    fun offer(pcm: ShortArray, count: Int): Scores? {
        if (closed) return null
        val safeCount = count.coerceIn(0, pcm.size)
        var cursor = 0
        var latest: Scores? = null
        while (cursor < safeCount) {
            val take = minOf(WINDOW_SAMPLES - samplesInWindow, safeCount - cursor)
            for (i in 0 until take) window[samplesInWindow + i] = pcm[cursor + i] / 32768f
            samplesInWindow += take
            cursor += take
            if (samplesInWindow == WINDOW_SAMPLES) {
                latest = classifyWindow()
                // Janela sobreposta em 50%: resposta média a cada ~0,49 s.
                System.arraycopy(window, WINDOW_SAMPLES / 2, window, 0, WINDOW_SAMPLES / 2)
                samplesInWindow = WINDOW_SAMPLES / 2
            }
        }
        return latest
    }

    private fun classifyWindow(): Scores {
        val inputShape = interpreter.getInputTensor(0).shape()
        val input: Any = if (inputShape.size == 1) window.copyOf() else arrayOf(window.copyOf())
        val outputShape = interpreter.getOutputTensor(0).shape()
        val output: Any = if (outputShape.size == 1) FloatArray(outputShape.last())
            else Array(outputShape[0]) { FloatArray(outputShape[1]) }
        interpreter.run(input, output)
        val scores = when (output) {
            is FloatArray -> output
            is Array<*> -> (output.firstOrNull() as? FloatArray) ?: FloatArray(OUTPUT_CLASSES)
            else -> FloatArray(OUTPUT_CLASSES)
        }
        fun scoreFor(vararg terms: String): Float {
            var best = 0f
            for (i in 0 until minOf(labels.size, scores.size)) {
                val label = labels[i].lowercase().replace(Regex("[^a-z0-9]+"), " ").trim()
                val paddedLabel = " $label "
                val matches = terms.any { rawTerm ->
                    val term = rawTerm.lowercase().replace(Regex("[^a-z0-9]+"), " ").trim()
                    term.isNotEmpty() && (label == term || paddedLabel.contains(" $term "))
                }
                if (matches) best = maxOf(best, scores[i])
            }
            return best.coerceIn(0f, 1f)
        }
        return Scores(
            traffic = scoreFor("vehicle", "car", "truck", "motorcycle", "bus", "traffic noise", "roadway", "vehicle horn", "skidding", "engine"),
            emergency = scoreFor("siren", "ambulance", "police car", "emergency vehicle", "fire engine"),
            speech = scoreFor("speech", "conversation", "male speech", "female speech", "child speech", "talking", "narration"),
            announcement = scoreFor("public speaking", "announcement", "megaphone", "loudspeaker"),
            alarm = scoreFor("alarm", "smoke detector", "fire alarm", "buzzer", "warning signal"),
            transit = scoreFor("train", "subway", "rail transport", "train whistle", "bus", "aircraft", "airplane")
        )
    }

    @Synchronized
    override fun close() {
        if (closed) return
        closed = true
        runCatching { interpreter.close() }
        samplesInWindow = 0
    }

    companion object {
        private const val WINDOW_SAMPLES = 15_600 // 0,975 s a 16 kHz mono.
        private const val OUTPUT_CLASSES = 521
    }
}
