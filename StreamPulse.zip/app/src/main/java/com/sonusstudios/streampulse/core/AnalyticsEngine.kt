package com.sonusstudios.streampulse.core

import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.math.abs

object AnalyticsEngine {
    fun trend(snapshots: List<StreamSnapshot>, windowDays: Int = 3): TrendResult {
        val safeWindow = windowDays.coerceIn(2, 14)
        val rates = dailyRates(snapshots)
        if (rates.isEmpty()) {
            return TrendResult(
                label = "Coletando dados",
                percentChange = null,
                recentAverage = 0.0,
                previousAverage = null,
                direction = 0,
                sampleCount = 0
            )
        }

        val recent = rates.takeLast(safeWindow)
        val previous = rates.dropLast(recent.size).takeLast(safeWindow)
        val recentAverage = recent.average()
        val previousAverage = previous.takeIf { it.isNotEmpty() }?.average()

        if (previousAverage == null || previousAverage <= 0.0) {
            return TrendResult(
                label = "Ritmo recente",
                percentChange = null,
                recentAverage = recentAverage,
                previousAverage = null,
                direction = if (recentAverage > 0.0) 1 else 0,
                sampleCount = rates.size
            )
        }

        val percent = (recentAverage - previousAverage) / previousAverage * 100.0
        val direction = when {
            percent >= 5.0 -> 1
            percent <= -5.0 -> -1
            else -> 0
        }
        val label = when (direction) {
            1 -> "Em aceleração"
            -1 -> "Em desaceleração"
            else -> "Estável"
        }
        return TrendResult(
            label = label,
            percentChange = percent,
            recentAverage = recentAverage,
            previousAverage = previousAverage,
            direction = direction,
            sampleCount = rates.size
        )
    }

    fun trendFromDailyEntries(entries: List<DailyStreamEntry>, windowDays: Int = 3): TrendResult {
        val safeWindow = windowDays.coerceIn(2, 14)
        val rates = entries.sortedBy { it.dateIso }.map { it.streams.toDouble() }
        if (rates.isEmpty()) {
            return TrendResult(
                label = "Coletando dados",
                percentChange = null,
                recentAverage = 0.0,
                previousAverage = null,
                direction = 0,
                sampleCount = 0
            )
        }

        val recent = rates.takeLast(safeWindow)
        val previous = rates.dropLast(recent.size).takeLast(safeWindow)
        val recentAverage = recent.average()
        val previousAverage = previous.takeIf { it.isNotEmpty() }?.average()

        if (previousAverage == null || previousAverage <= 0.0) {
            return TrendResult(
                label = "Ritmo recente",
                percentChange = null,
                recentAverage = recentAverage,
                previousAverage = null,
                direction = if (recentAverage > 0.0) 1 else 0,
                sampleCount = rates.size
            )
        }

        val percent = (recentAverage - previousAverage) / previousAverage * 100.0
        val direction = when {
            percent >= 5.0 -> 1
            percent <= -5.0 -> -1
            else -> 0
        }
        val label = when (direction) {
            1 -> "Em aceleração"
            -1 -> "Em desaceleração"
            else -> "Estável"
        }
        return TrendResult(
            label = label,
            percentChange = percent,
            recentAverage = recentAverage,
            previousAverage = previousAverage,
            direction = direction,
            sampleCount = rates.size
        )
    }

    fun dailyRates(snapshots: List<StreamSnapshot>): List<Double> {
        val result = mutableListOf<Double>()
        snapshots.groupBy { it.cycleStartIso }.values.forEach { cycle ->
            val latest = latestPerDate(cycle)
            latest.zipWithNext().forEach { (a, b) ->
                val dateA = LocalDate.parse(a.dateIso)
                val dateB = LocalDate.parse(b.dateIso)
                val days = ChronoUnit.DAYS.between(dateA, dateB)
                val delta = b.cumulativeStreams - a.cumulativeStreams
                if (days > 0 && delta >= 0) result += delta.toDouble() / days
            }
        }
        return result
    }

    fun smartSummary(
        trend: TrendResult,
        forecast: ForecastResult,
        health: HealthResult,
        daysRemaining: Long
    ): String {
        if (forecast.currentStreams == 0L) {
            return "Cadastre sua primeira atualização de streams para o SONUS começar a interpretar o ritmo do projeto."
        }

        val trendText = when (trend.direction) {
            1 -> "O ritmo recente está acelerando"
            -1 -> "O ritmo recente desacelerou"
            else -> if (trend.percentChange != null) "O ritmo recente está estável" else "Ainda estamos formando uma base de tendência"
        }

        val percentText = trend.percentChange?.let { " (${formatSignedPercent(it)})" }.orEmpty()
        val healthText = when {
            health.scoredDays == 0 -> "A saúde ainda precisa de mais atualizações diárias."
            health.performancePercent < 25.0 -> "A saúde do projeto está em zona crítica e merece atenção."
            health.performancePercent < 55.0 -> "A saúde do projeto ainda está instável."
            health.performancePercent < 80.0 -> "A saúde do projeto está reagindo bem."
            else -> "A saúde do projeto está forte."
        }
        val closeText = if (daysRemaining > 0) {
            "Mantendo o ritmo calculado, a previsão principal é de ${forecast.projectedStreams} streams no fechamento em $daysRemaining dia(s)."
        } else {
            "O ciclo está na data de fechamento de referência."
        }

        return "$trendText$percentText. $healthText $closeText"
    }

    private fun latestPerDate(snapshots: List<StreamSnapshot>): List<StreamSnapshot> {
        val ordered = snapshots.sortedWith(compareBy<StreamSnapshot> { it.dateIso }.thenBy { it.recordedAtEpochMillis })
        val map = linkedMapOf<String, StreamSnapshot>()
        ordered.forEach { map[it.dateIso] = it }
        return map.values.sortedBy { it.dateIso }
    }

    private fun formatSignedPercent(value: Double): String {
        val rounded = kotlin.math.round(abs(value) * 10.0) / 10.0
        return if (value >= 0) "+$rounded%" else "-$rounded%"
    }
}
