package com.sonusstudios.streampulse.tools

import android.os.SystemClock
import android.util.Log

/**
 * code132: medição real da abertura do SONUS Stream (toque na aba -> primeira composição -> primeiro frame ->
 * catálogo visível). Só escreve no Logcat (tag SONUS_STREAM_OPEN); não altera nenhum comportamento.
 * Filtro sugerido: `adb logcat -s SONUS_STREAM_OPEN`.
 */
internal object SonusStreamOpenTrace {
    private const val TAG = "SONUS_STREAM_OPEN"
    @Volatile private var tapAt = 0L

    fun markTap() {
        tapAt = SystemClock.elapsedRealtime()
    }

    fun mark(stage: String, warmSnapshot: Boolean? = null) {
        val start = tapAt
        if (start <= 0L) return
        val elapsed = SystemClock.elapsedRealtime() - start
        val cache = when (warmSnapshot) {
            true -> " (cache aquecido)"
            false -> " (cache frio)"
            null -> ""
        }
        runCatching { Log.i(TAG, "$stage: $elapsed ms$cache") }
    }

    fun done() {
        tapAt = 0L
    }
}
