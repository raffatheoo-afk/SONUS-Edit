package com.sonusstudios.streampulse.widgets

import android.Manifest
import android.app.Activity
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.content.pm.PackageManager
import android.view.View
import android.widget.RemoteViews
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color as ComposeColor
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonusstudios.streampulse.MainActivity
import com.sonusstudios.streampulse.R
import com.sonusstudios.streampulse.auth.AccountRole
import com.sonusstudios.streampulse.core.AppState
import com.sonusstudios.streampulse.data.AppRepository
import com.sonusstudios.streampulse.tools.PulsePlayerPlaybackState
import com.sonusstudios.streampulse.tools.PulsePlayerService
import com.sonusstudios.streampulse.tools.SonusBlackBoxPreferences
import com.sonusstudios.streampulse.tools.SonusBlackBoxPinStore
import com.sonusstudios.streampulse.tools.SonusBlackBoxService
import com.sonusstudios.streampulse.tools.SonusBlackBoxStorage
import com.sonusstudios.streampulse.tools.RecorderBus
import com.sonusstudios.streampulse.tools.VoiceRecorderService
import java.text.NumberFormat
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.ChronoUnit
import java.util.Locale
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

private const val WIDGET_STYLE_PREFS = "sonus_widget_styles_v2"
private const val PLAYER_SNAPSHOT_PREFS = "sonus_widget_player_v2"
private const val TASK_SNAPSHOT_PREFS = "sonus_widget_task_v1"
private const val ACTION_BLACKBOX_TOGGLE = "sonus.widget.BLACKBOX_TOGGLE"
private const val ACTION_RECORDER_TOGGLE = "sonus.widget.RECORDER_TOGGLE"

internal enum class WidgetMode {
    PLAYER_COMPACT,
    PLAYER_COMPLETE,
    BLACK_BOX,
    VOICE_RECORDER,
    RADIO_STREAM,
    QUICK_ACTIONS
}

private data class PlayerWidgetSnapshot(
    val title: String = "Nada tocando",
    val artist: String = "Abra o SONUS para escolher uma música",
    val uri: String? = null,
    val source: String = "Local",
    val playing: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L
)

object SonusWidgetCenter {
    @Volatile private var lastPlayerWidgetPush = 0L

    fun publishPlayer(context: Context, state: PulsePlayerPlaybackState) {
        val cur = state.current
        context.getSharedPreferences(PLAYER_SNAPSHOT_PREFS, Context.MODE_PRIVATE).edit()
            .putString("title", cur?.title ?: "Nada tocando")
            .putString("artist", cur?.artist?.ifBlank { "SONUS" } ?: "Abra o SONUS para escolher uma música")
            .putString("uri", cur?.uri)
            .putString("source", cur?.source ?: "Local")
            .putBoolean("playing", state.playing)
            .putLong("position", state.positionMs)
            .putLong("duration", state.durationMs)
            .apply()

        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastPlayerWidgetPush >= 1_500L || !state.playing) {
            lastPlayerWidgetPush = now
            updateModes(context, setOf(WidgetMode.PLAYER_COMPACT, WidgetMode.PLAYER_COMPLETE, WidgetMode.RADIO_STREAM))
        }
    }

    /** Mantido para processos internos/notificações. Não existe mais widget de processamento. */
    fun publishTask(context: Context, title: String?, progress: Int?) {
        context.getSharedPreferences(TASK_SNAPSHOT_PREFS, Context.MODE_PRIVATE).edit()
            .putString("title", title ?: "Sem processamento ativo")
            .putInt("progress", progress ?: -1)
            .putLong("updated", System.currentTimeMillis())
            .apply()
    }

    fun refreshAll(context: Context) {
        val manager = AppWidgetManager.getInstance(context)
        providerMap.forEach { (cls, mode) ->
            manager.getAppWidgetIds(ComponentName(context, cls)).forEach { id -> updateOne(context, manager, id, mode) }
        }
    }

    fun updateOne(context: Context, appWidgetId: Int) {
        val manager = AppWidgetManager.getInstance(context)
        val provider = manager.getAppWidgetInfo(appWidgetId)?.provider?.className
        val mode = providerMap.entries.firstOrNull { it.key.name == provider }?.value ?: return
        updateOne(context, manager, appWidgetId, mode)
    }

    private fun updateModes(context: Context, modes: Set<WidgetMode>) {
        val manager = AppWidgetManager.getInstance(context)
        providerMap.filterValues { it in modes }.forEach { (cls, mode) ->
            manager.getAppWidgetIds(ComponentName(context, cls)).forEach { id -> updateOne(context, manager, id, mode) }
        }
    }

    private fun updateOne(context: Context, manager: AppWidgetManager, id: Int, mode: WidgetMode) {
        val rv = RemoteViews(context.packageName, R.layout.widget_sonus_card)
        val style = context.getSharedPreferences(WIDGET_STYLE_PREFS, Context.MODE_PRIVATE)
            .getString("style_$id", "black") ?: "black"
        reset(rv)
        applyStyle(context, rv, style, mode)

        when (mode) {
            WidgetMode.PLAYER_COMPACT, WidgetMode.PLAYER_COMPLETE -> renderPlayer(context, rv, mode)
            WidgetMode.BLACK_BOX -> renderBlackBox(context, rv)
            WidgetMode.VOICE_RECORDER -> renderVoiceRecorder(context, rv)
            WidgetMode.RADIO_STREAM -> renderRadioStream(context, rv)
            WidgetMode.QUICK_ACTIONS -> renderQuickActions(context, rv, id)
        }
        manager.updateAppWidget(id, rv)
    }

    private fun reset(rv: RemoteViews) {
        listOf(
            R.id.widget_cover, R.id.widget_main_value, R.id.widget_secondary, R.id.widget_graph,
            R.id.widget_progress, R.id.widget_metrics, R.id.widget_controls, R.id.widget_pro, R.id.widget_metric_4
        ).forEach { rv.setViewVisibility(it, View.GONE) }
        rv.setViewVisibility(R.id.widget_header, View.VISIBLE)
        rv.setViewVisibility(R.id.widget_texts, View.VISIBLE)
        rv.setTextViewText(R.id.widget_title, "SONUS")
        rv.setTextViewText(R.id.widget_subtitle, "")
    }

    private fun renderPlayer(context: Context, rv: RemoteViews, mode: WidgetMode) {
        val s = playerSnapshot(context)
        val route = if (s.source.contains("Stream", ignoreCase = true) || s.source.contains("Rádio", ignoreCase = true) || s.source.contains("Radio", ignoreCase = true)) "STREAM" else "PLAYER"
        rv.setTextViewText(R.id.widget_title, s.title)
        val sourceLabel = when {
            s.source.contains("Rádio", true) || s.source.contains("Radio", true) -> "SONUS Rádio"
            s.source.contains("Stream", true) -> "SONUS Stream"
            else -> "Local"
        }
        rv.setTextViewText(R.id.widget_subtitle, "${s.artist} • $sourceLabel")
        loadArtwork(context, s.uri)?.let {
            rv.setViewVisibility(R.id.widget_cover, View.VISIBLE)
            rv.setImageViewBitmap(R.id.widget_cover, it)
        }
        if (mode == WidgetMode.PLAYER_COMPLETE) {
            rv.setViewVisibility(R.id.widget_progress, View.VISIBLE)
            rv.setProgressBar(
                R.id.widget_progress,
                100,
                if (s.durationMs > 0L) ((s.positionMs * 100L / s.durationMs).toInt()).coerceIn(0, 100) else 0,
                false
            )
            rv.setViewVisibility(R.id.widget_secondary, View.VISIBLE)
            rv.setTextViewText(R.id.widget_secondary, "${s.artist} • $sourceLabel • ${formatTime(s.positionMs)} / ${formatTime(s.durationMs)}")
        }
        rv.setViewVisibility(R.id.widget_controls, View.VISIBLE)
        rv.setImageViewResource(R.id.widget_play, if (s.playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play)
        rv.setOnClickPendingIntent(R.id.widget_prev, playerActionIntent(context, PulsePlayerService.ACTION_PREVIOUS, 1101 + mode.ordinal * 10))
        rv.setOnClickPendingIntent(R.id.widget_play, playerActionIntent(context, PulsePlayerService.ACTION_TOGGLE, 1102 + mode.ordinal * 10))
        rv.setOnClickPendingIntent(R.id.widget_next, playerActionIntent(context, PulsePlayerService.ACTION_NEXT, 1103 + mode.ordinal * 10))
        rv.setOnClickPendingIntent(R.id.widget_open, openAppIntent(context, route, 1104 + mode.ordinal * 10))
        rv.setOnClickPendingIntent(R.id.widget_root, openAppIntent(context, route, 1105 + mode.ordinal * 10))
    }


    private fun renderBlackBox(context: Context, rv: RemoteViews) {
        val prefs = SonusBlackBoxPreferences(context)
        val active = prefs.active
        val bytes = runCatching { SonusBlackBoxStorage.bufferBytes(context) }.getOrDefault(0L)
        val saved = runCatching { SonusBlackBoxStorage.listSaved(context).size }.getOrDefault(0)
        rv.setTextViewText(R.id.widget_title, "Caixa Preta SONUS")
        rv.setTextViewText(R.id.widget_subtitle, if (active) "● Gravando continuamente" else "Parada")
        rv.setViewVisibility(R.id.widget_main_value, View.VISIBLE)
        rv.setTextViewText(R.id.widget_main_value, humanBytes(bytes))
        rv.setViewVisibility(R.id.widget_metrics, View.VISIBLE)
        rv.setTextViewText(R.id.widget_metric_1, "${prefs.retentionHours}h\nRETENÇÃO")
        rv.setTextViewText(R.id.widget_metric_2, "$saved\nSALVOS")
        rv.setTextViewText(R.id.widget_metric_3, if (active) "ATIVA\nCAPTURA" else "PARADA\nCAPTURA")
        rv.setViewVisibility(R.id.widget_controls, View.VISIBLE)
        rv.setViewVisibility(R.id.widget_prev, View.GONE)
        rv.setViewVisibility(R.id.widget_next, View.GONE)
        rv.setImageViewResource(R.id.widget_play, if (active) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play)
        rv.setOnClickPendingIntent(R.id.widget_play, widgetActionIntent(context, BlackBoxWidget::class.java, ACTION_BLACKBOX_TOGGLE, 1601))
        rv.setOnClickPendingIntent(R.id.widget_open, openAppIntent(context, "BLACK_BOX", 1602))
        rv.setOnClickPendingIntent(R.id.widget_root, openAppIntent(context, "BLACK_BOX", 1603))
    }

    private fun renderVoiceRecorder(context: Context, rv: RemoteViews) {
        val state = RecorderBus.state.value
        rv.setTextViewText(R.id.widget_title, "Gravador de Voz")
        rv.setTextViewText(R.id.widget_subtitle, when { state.recording && state.paused -> "Pausado"; state.recording -> "● Gravando"; else -> "Pronto para gravar" })
        rv.setViewVisibility(R.id.widget_main_value, View.VISIBLE)
        rv.setTextViewText(R.id.widget_main_value, formatTime(state.durationMs))
        rv.setViewVisibility(R.id.widget_secondary, View.VISIBLE)
        rv.setTextViewText(R.id.widget_secondary, state.outputPath?.substringAfterLast('/')?.let { "Último: $it" } ?: "Toque para iniciar uma gravação rápida")
        rv.setViewVisibility(R.id.widget_controls, View.VISIBLE)
        rv.setViewVisibility(R.id.widget_prev, View.GONE)
        rv.setViewVisibility(R.id.widget_next, View.GONE)
        rv.setImageViewResource(R.id.widget_play, if (state.recording) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play)
        rv.setOnClickPendingIntent(R.id.widget_play, widgetActionIntent(context, VoiceRecorderWidget::class.java, ACTION_RECORDER_TOGGLE, 1611))
        rv.setOnClickPendingIntent(R.id.widget_open, openToolIntent(context, "RECORDER", 1612))
        rv.setOnClickPendingIntent(R.id.widget_root, openToolIntent(context, "RECORDER", 1613))
    }

    private fun renderRadioStream(context: Context, rv: RemoteViews) {
        val s = playerSnapshot(context)
        rv.setTextViewText(R.id.widget_title, "SONUS Rádio / Stream")
        rv.setTextViewText(R.id.widget_subtitle, if (s.title == "Nada tocando") "Abra o Stream para uma recomendação" else "${s.title} • ${s.artist}")
        loadArtwork(context, s.uri)?.let {
            rv.setViewVisibility(R.id.widget_cover, View.VISIBLE)
            rv.setImageViewBitmap(R.id.widget_cover, it)
        }
        rv.setViewVisibility(R.id.widget_main_value, View.VISIBLE)
        rv.setTextViewText(R.id.widget_main_value, if (s.playing) "Reproduzindo" else "Pronto")
        rv.setViewVisibility(R.id.widget_controls, View.VISIBLE)
        rv.setImageViewResource(R.id.widget_play, if (s.playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play)
        rv.setOnClickPendingIntent(R.id.widget_prev, playerActionIntent(context, PulsePlayerService.ACTION_PREVIOUS, 1621))
        rv.setOnClickPendingIntent(R.id.widget_play, playerActionIntent(context, PulsePlayerService.ACTION_TOGGLE, 1622))
        rv.setOnClickPendingIntent(R.id.widget_next, playerActionIntent(context, PulsePlayerService.ACTION_NEXT, 1623))
        rv.setOnClickPendingIntent(R.id.widget_open, openAppIntent(context, "STREAM", 1624))
        rv.setOnClickPendingIntent(R.id.widget_root, openAppIntent(context, "STREAM", 1625))
    }

    private fun renderQuickActions(context: Context, rv: RemoteViews, id: Int) {
        val prefs = context.getSharedPreferences(WIDGET_STYLE_PREFS, Context.MODE_PRIVATE)
        val selected = prefs.getString("quick_$id", null)?.split(',')?.filter { it.isNotBlank() }?.take(4)
            ?: listOf("SONUS_AUTOMIX", "COVER_PRO", "IMAGE_RENAME_BATCH", "VIDEO_CONVERTER")
        val labels = mapOf(
            "SONUS_AUTOMIX" to "AutoMix", "IMAGE_RENAME_BATCH" to "Renomear",
            "VIDEO_CONVERTER" to "Converter", "COVER_PRO" to "Imagens", "LRC_EDITOR" to "LRC",
            "TAG_BATCH" to "Tags", "RECORDER" to "Gravador"
        )
        rv.setTextViewText(R.id.widget_title, "Central Rápida SONUS")
        rv.setTextViewText(R.id.widget_subtitle, "Suas ferramentas favoritas")
        rv.setViewVisibility(R.id.widget_metrics, View.VISIBLE)
        val ids = listOf(R.id.widget_metric_1, R.id.widget_metric_2, R.id.widget_metric_3, R.id.widget_metric_4)
        ids.forEachIndexed { index, viewId ->
            val tool = selected.getOrNull(index)
            if (tool != null) {
                rv.setViewVisibility(viewId, View.VISIBLE)
                rv.setTextViewText(viewId, labels[tool] ?: tool.replace('_', ' '))
                rv.setOnClickPendingIntent(viewId, openToolIntent(context, tool, 1700 + id * 10 + index))
            } else rv.setViewVisibility(viewId, View.GONE)
        }
        rv.setOnClickPendingIntent(R.id.widget_root, openAppIntent(context, "HIGHLIGHTS", 1799 + id))
    }


    private fun playerSnapshot(context: Context): PlayerWidgetSnapshot {
        val p = context.getSharedPreferences(PLAYER_SNAPSHOT_PREFS, Context.MODE_PRIVATE)
        return PlayerWidgetSnapshot(
            title = p.getString("title", "Nada tocando") ?: "Nada tocando",
            artist = p.getString("artist", "Abra o SONUS para escolher uma música") ?: "Abra o SONUS para escolher uma música",
            uri = p.getString("uri", null),
            source = p.getString("source", "Local") ?: "Local",
            playing = p.getBoolean("playing", false),
            positionMs = p.getLong("position", 0L),
            durationMs = p.getLong("duration", 0L)
        )
    }

    private fun loadArtwork(context: Context, uri: String?): Bitmap? {
        if (uri.isNullOrBlank()) return null
        return runCatching {
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(context, Uri.parse(uri))
            val bytes = retriever.embeddedPicture
            retriever.release()
            val src = bytes?.let { BitmapFactory.decodeByteArray(it, 0, it.size) } ?: return@runCatching null
            roundedSquare(src, 180)
        }.getOrNull()
    }

    private fun roundedSquare(src: Bitmap, size: Int): Bitmap {
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val rect = RectF(0f, 0f, size.toFloat(), size.toFloat())
        canvas.drawRoundRect(rect, 28f, 28f, paint)
        paint.xfermode = android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.SRC_IN)
        canvas.drawBitmap(src, null, rect, paint)
        return out
    }


    private fun applyStyle(context: Context, rv: RemoteViews, style: String, mode: WidgetMode) {
        val light = style == "white"
        val bg = when (style) {
            "white" -> R.drawable.widget_bg_white
            "transparent" -> R.drawable.widget_bg_transparent
            else -> R.drawable.widget_bg_black
        }
        rv.setInt(R.id.widget_root, "setBackgroundResource", bg)
        val accent = when (mode) {
            WidgetMode.BLACK_BOX -> Color.rgb(255, 74, 91)
            WidgetMode.VOICE_RECORDER -> Color.rgb(223, 65, 107)
            WidgetMode.QUICK_ACTIONS -> Color.rgb(56, 225, 177)
            else -> Color.rgb(56, 225, 177)
        }
        rv.setInt(R.id.widget_accent, "setBackgroundColor", accent)
        val main = if (light) Color.rgb(18, 21, 26) else Color.WHITE
        val secondary = if (light) Color.rgb(73, 80, 90) else Color.argb(205, 255, 255, 255)
        rv.setTextColor(R.id.widget_title, main)
        listOf(R.id.widget_main_value, R.id.widget_metric_1, R.id.widget_metric_2, R.id.widget_metric_3, R.id.widget_metric_4).forEach { rv.setTextColor(it, main) }
        listOf(R.id.widget_subtitle, R.id.widget_secondary).forEach { rv.setTextColor(it, secondary) }
        listOf(R.id.widget_prev, R.id.widget_play, R.id.widget_next, R.id.widget_open).forEach { rv.setInt(it, "setColorFilter", main) }
    }

    private fun playerActionIntent(context: Context, action: String, code: Int): PendingIntent {
        val intent = Intent(context, PulsePlayerService::class.java).setAction(action)
        return PendingIntent.getService(context, code, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun openAppIntent(context: Context, route: String?, code: Int): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        if (route != null) intent.putExtra("sonus_notification_route", route)
        return PendingIntent.getActivity(context, code, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun openToolIntent(context: Context, tool: String, code: Int): PendingIntent {
        val intent = Intent(context, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra("sonus_notification_route", "HIGHLIGHTS")
            .putExtra("sonus_widget_tool", tool)
        return PendingIntent.getActivity(context, code, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun widgetActionIntent(context: Context, cls: Class<out AppWidgetProvider>, action: String, code: Int): PendingIntent {
        val intent = Intent(context, cls).setAction(action)
        return PendingIntent.getBroadcast(context, code, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun humanBytes(bytes: Long): String = when {
        bytes >= 1_073_741_824L -> String.format(Locale.US, "%.1f GB", bytes / 1_073_741_824.0)
        bytes >= 1_048_576L -> String.format(Locale.US, "%.1f MB", bytes / 1_048_576.0)
        bytes >= 1_024L -> String.format(Locale.US, "%.1f KB", bytes / 1_024.0)
        else -> "$bytes B"
    }

    private fun formatTime(ms: Long): String {
        val s = (ms / 1000L).coerceAtLeast(0L)
        return "%d:%02d".format(s / 60L, s % 60L)
    }

    internal val providerMap: Map<Class<out AppWidgetProvider>, WidgetMode> = linkedMapOf(
        PlayerCompactWidget::class.java to WidgetMode.PLAYER_COMPACT,
        PlayerCompleteWidget::class.java to WidgetMode.PLAYER_COMPLETE,
        BlackBoxWidget::class.java to WidgetMode.BLACK_BOX,
        VoiceRecorderWidget::class.java to WidgetMode.VOICE_RECORDER,
        RadioStreamWidget::class.java to WidgetMode.RADIO_STREAM,
        QuickActionsWidget::class.java to WidgetMode.QUICK_ACTIONS
    )
}

abstract class SonusWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { SonusWidgetCenter.updateOne(context, it) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_BLACKBOX_TOGGLE -> {
                val pinProtected = SonusBlackBoxPinStore(context).isConfigured()
                if (pinProtected || context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    context.startActivity(Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("sonus_notification_route", "BLACK_BOX"))
                } else {
                    val active = SonusBlackBoxPreferences(context).active
                    if (active) SonusBlackBoxService.stop(context) else SonusBlackBoxService.start(context)
                }
                Handler(Looper.getMainLooper()).postDelayed({ SonusWidgetCenter.refreshAll(context) }, 700L)
            }
            ACTION_RECORDER_TOGGLE -> {
                val rec = RecorderBus.state.value
                if (rec.recording) {
                    VoiceRecorderService.stop(context)
                } else if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                    VoiceRecorderService.start(context, 48_000, 1, "VOICE", bitDepth = 24)
                } else {
                    context.startActivity(Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        .putExtra("sonus_notification_route", "HIGHLIGHTS").putExtra("sonus_widget_tool", "RECORDER"))
                }
                Handler(Looper.getMainLooper()).postDelayed({ SonusWidgetCenter.refreshAll(context) }, 700L)
            }
        }
    }

    override fun onDeleted(context: Context, ids: IntArray) {
        val editor = context.getSharedPreferences(WIDGET_STYLE_PREFS, Context.MODE_PRIVATE).edit()
        ids.forEach { editor.remove("style_$it").remove("quick_$it") }
        editor.apply()
    }
}

class PlayerCompactWidget : SonusWidgetProvider()
class PlayerCompleteWidget : SonusWidgetProvider()
class BlackBoxWidget : SonusWidgetProvider()
class VoiceRecorderWidget : SonusWidgetProvider()
class RadioStreamWidget : SonusWidgetProvider()
class QuickActionsWidget : SonusWidgetProvider()

class SonusWidgetConfigActivity : ComponentActivity() {
    private var widgetId: Int = AppWidgetManager.INVALID_APPWIDGET_ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        widgetId = intent?.extras?.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
            ?: AppWidgetManager.INVALID_APPWIDGET_ID
        setResult(Activity.RESULT_CANCELED)
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish()
            return
        }
        val prefs = getSharedPreferences(WIDGET_STYLE_PREFS, Context.MODE_PRIVATE)
        val providerName = AppWidgetManager.getInstance(this).getAppWidgetInfo(widgetId)?.provider?.className
        val mode = SonusWidgetCenter.providerMap.entries.firstOrNull { it.key.name == providerName }?.value
        val quick = mode == WidgetMode.QUICK_ACTIONS
        val initialActions = prefs.getString("quick_$widgetId", null)?.split(',')?.filter { it.isNotBlank() }
            ?: listOf("SONUS_AUTOMIX", "COVER_PRO", "IMAGE_RENAME_BATCH", "VIDEO_CONVERTER")
        setContent {
            MaterialTheme {
                WidgetConfigScreen(
                    initialStyle = prefs.getString("style_$widgetId", "black") ?: "black",
                    quickMode = quick,
                    initialQuickActions = initialActions
                ) { style, actions ->
                    prefs.edit()
                        .putString("style_$widgetId", style)
                        .putString("quick_$widgetId", actions.joinToString(","))
                        .apply()
                    SonusWidgetCenter.updateOne(this, widgetId)
                    setResult(Activity.RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
                    finish()
                }
            }
        }
    }
}

@Composable
private fun WidgetConfigScreen(
    initialStyle: String,
    quickMode: Boolean,
    initialQuickActions: List<String>,
    onSave: (String, List<String>) -> Unit
) {
    var style by remember { mutableStateOf(initialStyle) }
    var actions by remember { mutableStateOf(initialQuickActions.take(4)) }
    val options = listOf(
        "SONUS_AUTOMIX" to "AutoMix",
        "IMAGE_RENAME_BATCH" to "Renomear imagens",
        "VIDEO_CONVERTER" to "Converter vídeo",
        "COVER_PRO" to "Imagens",
        "LRC_EDITOR" to "Editor LRC",
        "TAG_BATCH" to "Tags em lote",
        "RECORDER" to "Gravador"
    )
    Box(
        Modifier.fillMaxSize().background(ComposeColor(0xFF090D14)).padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Aparência do widget", color = ComposeColor.White, fontSize = 26.sp)
            Text("Escolha uma aparência. O conteúdo continuará atualizado pelo SONUS.", color = ComposeColor.White.copy(alpha = .68f), fontSize = 14.sp)
            StyleOption("Preto", ComposeColor(0xFF11151D), selected = style == "black") { style = "black" }
            StyleOption("Branco", ComposeColor(0xFFF3F4F6), darkText = true, selected = style == "white") { style = "white" }
            StyleOption("Transparente", ComposeColor(0x663A4453), selected = style == "transparent") { style = "transparent" }
            if (quickMode) {
                Spacer(Modifier.height(8.dp))
                Text("Ações rápidas", color = ComposeColor.White, fontSize = 21.sp)
                Text("Escolha até 4 ferramentas para aparecer na Home.", color = ComposeColor.White.copy(alpha = .68f), fontSize = 13.sp)
                options.forEach { (id, label) ->
                    val selected = id in actions
                    StyleOption(label, ComposeColor(0xFF172331), selected = selected) {
                        actions = when {
                            selected -> actions - id
                            actions.size < 4 -> actions + id
                            else -> actions.drop(1) + id
                        }
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
            Button(onClick = { onSave(style, if (quickMode) actions.take(4) else emptyList()) }, modifier = Modifier.fillMaxWidth()) {
                Text("Adicionar widget")
            }
        }
    }
}

@Composable
private fun StyleOption(
    label: String,
    bg: ComposeColor,
    darkText: Boolean = false,
    selected: Boolean = false,
    onClick: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth()
            .background(if (selected) bg.copy(alpha = .96f) else bg, RoundedCornerShape(24.dp))
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = if (darkText) ComposeColor(0xFF16191E) else ComposeColor.White, fontSize = 17.sp, modifier = Modifier.weight(1f))
        if (selected) Text("✓", color = if (darkText) ComposeColor(0xFF16191E) else ComposeColor.White, fontSize = 18.sp)
    }
}
