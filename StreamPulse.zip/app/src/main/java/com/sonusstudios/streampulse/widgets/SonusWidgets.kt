package com.sonusstudios.streampulse.widgets

import android.app.Activity
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.RemoteViews
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color as ComposeColor
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonusstudios.streampulse.MainActivity
import com.sonusstudios.streampulse.R
import com.sonusstudios.streampulse.auth.AccountRole
import com.sonusstudios.streampulse.core.AppState
import com.sonusstudios.streampulse.core.DistributorRules
import com.sonusstudios.streampulse.core.RoyaltyEngine
import com.sonusstudios.streampulse.core.StreamMetricsEngine
import com.sonusstudios.streampulse.core.resolvedStreamEntryMode
import com.sonusstudios.streampulse.data.AppRepository
import com.sonusstudios.streampulse.tools.PulsePlayerPlaybackState
import com.sonusstudios.streampulse.tools.PulsePlayerService
import java.text.NumberFormat
import java.time.LocalDate
import java.time.YearMonth
import java.util.Locale
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

private const val WIDGET_STYLE_PREFS = "sonus_widget_styles_v2"
private const val PLAYER_SNAPSHOT_PREFS = "sonus_widget_player_v2"
private const val TASK_SNAPSHOT_PREFS = "sonus_widget_task_v1"
private const val DISTRIBUTION_TRIAL_PREFS = "sonus_distribution_trial_cache_v1"

internal enum class WidgetMode(val distribution: Boolean = false) {
    PLAYER_COMPACT,
    PLAYER_COMPLETE,
    DISTRIBUTION_SUMMARY(true),
    DISTRIBUTION_GRAPH(true)
}

private data class PlayerWidgetSnapshot(
    val title: String = "Nada tocando",
    val artist: String = "Abra o SONUS para escolher uma música",
    val uri: String? = null,
    val source: String = "Local",
    val playing: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L
)

object SonusWidgetCenter {
    @Volatile private var lastPlayerWidgetPush = 0L

    fun publishPlayer(context: Context, state: PulsePlayerPlaybackState) {
        val cur = state.current
        context.getSharedPreferences(PLAYER_SNAPSHOT_PREFS, Context.MODE_PRIVATE).edit()
            .putString("title", cur?.title ?: "Nada tocando")
            .putString("artist", cur?.artist?.ifBlank { "SONUS" } ?: "Abra o SONUS para escolher uma música")
            .putString("uri", cur?.uri)
            .putString("source", cur?.source ?: "Local")
            .putBoolean("playing", state.playing)
            .putLong("position", state.positionMs)
            .putLong("duration", state.durationMs)
            .apply()

        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastPlayerWidgetPush >= 1_500L || !state.playing) {
            lastPlayerWidgetPush = now
            updateModes(context, setOf(WidgetMode.PLAYER_COMPACT, WidgetMode.PLAYER_COMPLETE))
        }
    }

    /** Mantido para processos internos/notificações. Não existe mais widget de processamento. */
    fun publishTask(context: Context, title: String?, progress: Int?) {
        context.getSharedPreferences(TASK_SNAPSHOT_PREFS, Context.MODE_PRIVATE).edit()
            .putString("title", title ?: "Sem processamento ativo")
            .putInt("progress", progress ?: -1)
            .putLong("updated", System.currentTimeMillis())
            .apply()
    }

    fun refreshAll(context: Context) {
        val manager = AppWidgetManager.getInstance(context)
        providerMap.forEach { (cls, mode) ->
            manager.getAppWidgetIds(ComponentName(context, cls)).forEach { id -> updateOne(context, manager, id, mode) }
        }
    }

    fun updateOne(context: Context, appWidgetId: Int) {
        val manager = AppWidgetManager.getInstance(context)
        val provider = manager.getAppWidgetInfo(appWidgetId)?.provider?.className
        val mode = providerMap.entries.firstOrNull { it.key.name == provider }?.value ?: return
        updateOne(context, manager, appWidgetId, mode)
    }

    private fun updateModes(context: Context, modes: Set<WidgetMode>) {
        val manager = AppWidgetManager.getInstance(context)
        providerMap.filterValues { it in modes }.forEach { (cls, mode) ->
            manager.getAppWidgetIds(ComponentName(context, cls)).forEach { id -> updateOne(context, manager, id, mode) }
        }
    }

    private fun updateOne(context: Context, manager: AppWidgetManager, id: Int, mode: WidgetMode) {
        val rv = RemoteViews(context.packageName, R.layout.widget_sonus_card)
        val style = context.getSharedPreferences(WIDGET_STYLE_PREFS, Context.MODE_PRIVATE)
            .getString("style_$id", "black") ?: "black"
        reset(rv)
        applyStyle(context, rv, style)

        if (mode.distribution) {
            val state = runCatching { runBlocking { AppRepository(context.applicationContext).state.first() } }.getOrDefault(AppState())
            if (!hasDistributionAccess(context, state)) renderDistributionGate(context, rv, mode)
            else renderDistribution(context, rv, mode, state)
        } else {
            renderPlayer(context, rv, mode)
        }
        manager.updateAppWidget(id, rv)
    }

    private fun reset(rv: RemoteViews) {
        listOf(
            R.id.widget_cover, R.id.widget_main_value, R.id.widget_secondary, R.id.widget_graph,
            R.id.widget_progress, R.id.widget_metrics, R.id.widget_controls, R.id.widget_pro
        ).forEach { rv.setViewVisibility(it, View.GONE) }
        rv.setViewVisibility(R.id.widget_header, View.VISIBLE)
        rv.setViewVisibility(R.id.widget_texts, View.VISIBLE)
        rv.setTextViewText(R.id.widget_title, "SONUS")
        rv.setTextViewText(R.id.widget_subtitle, "")
    }

    private fun renderPlayer(context: Context, rv: RemoteViews, mode: WidgetMode) {
        val s = playerSnapshot(context)
        val route = if (s.source.contains("Stream", ignoreCase = true) || s.source.contains("Rádio", ignoreCase = true) || s.source.contains("Radio", ignoreCase = true)) "STREAM" else "PLAYER"
        rv.setTextViewText(R.id.widget_title, s.title)
        val sourceLabel = when {
            s.source.contains("Rádio", true) || s.source.contains("Radio", true) -> "SONUS Rádio"
            s.source.contains("Stream", true) -> "SONUS Stream"
            else -> "Local"
        }
        rv.setTextViewText(R.id.widget_subtitle, "${s.artist} • $sourceLabel")
        loadArtwork(context, s.uri)?.let {
            rv.setViewVisibility(R.id.widget_cover, View.VISIBLE)
            rv.setImageViewBitmap(R.id.widget_cover, it)
        }
        if (mode == WidgetMode.PLAYER_COMPLETE) {
            rv.setViewVisibility(R.id.widget_progress, View.VISIBLE)
            rv.setProgressBar(
                R.id.widget_progress,
                100,
                if (s.durationMs > 0L) ((s.positionMs * 100L / s.durationMs).toInt()).coerceIn(0, 100) else 0,
                false
            )
            rv.setViewVisibility(R.id.widget_secondary, View.VISIBLE)
            rv.setTextViewText(R.id.widget_secondary, "${s.artist} • $sourceLabel • ${formatTime(s.positionMs)} / ${formatTime(s.durationMs)}")
        }
        rv.setViewVisibility(R.id.widget_controls, View.VISIBLE)
        rv.setImageViewResource(R.id.widget_play, if (s.playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play)
        rv.setOnClickPendingIntent(R.id.widget_prev, playerActionIntent(context, PulsePlayerService.ACTION_PREVIOUS, 1101 + mode.ordinal * 10))
        rv.setOnClickPendingIntent(R.id.widget_play, playerActionIntent(context, PulsePlayerService.ACTION_TOGGLE, 1102 + mode.ordinal * 10))
        rv.setOnClickPendingIntent(R.id.widget_next, playerActionIntent(context, PulsePlayerService.ACTION_NEXT, 1103 + mode.ordinal * 10))
        rv.setOnClickPendingIntent(R.id.widget_open, openAppIntent(context, route, 1104 + mode.ordinal * 10))
        rv.setOnClickPendingIntent(R.id.widget_root, openAppIntent(context, route, 1105 + mode.ordinal * 10))
    }

    private fun renderDistributionGate(context: Context, rv: RemoteViews, mode: WidgetMode) {
        rv.setViewVisibility(R.id.widget_pro, View.VISIBLE)
        rv.setTextViewText(R.id.widget_title, if (mode == WidgetMode.DISTRIBUTION_GRAPH) "Distribuição • Gráfico" else "Distribuição • Resumo")
        rv.setTextViewText(R.id.widget_subtitle, "Teste de 7 dias ou plano Prata+")
        rv.setViewVisibility(R.id.widget_main_value, View.VISIBLE)
        rv.setTextViewText(R.id.widget_main_value, "PRO")
        rv.setViewVisibility(R.id.widget_secondary, View.VISIBLE)
        rv.setTextViewText(R.id.widget_secondary, "Abra o SONUS para ativar o teste ou conhecer os planos.")
        rv.setOnClickPendingIntent(R.id.widget_root, openAppIntent(context, "DISTRIBUTION", 1300 + mode.ordinal))
    }

    private fun renderDistribution(context: Context, rv: RemoteViews, mode: WidgetMode, state: AppState) {
        rv.setViewVisibility(R.id.widget_pro, View.VISIBLE)
        val artist = state.artists.firstOrNull { it.id == state.selectedArtistId } ?: state.artists.firstOrNull()
        if (artist == null) {
            rv.setTextViewText(R.id.widget_title, "Distribuição & Pagamentos")
            rv.setTextViewText(R.id.widget_subtitle, "Cadastre um artista no SONUS")
            rv.setViewVisibility(R.id.widget_main_value, View.VISIBLE)
            rv.setTextViewText(R.id.widget_main_value, "Sem artista")
            rv.setOnClickPendingIntent(R.id.widget_root, openAppIntent(context, "DISTRIBUTION", 1399))
            return
        }

        val cycle = DistributorRules.cycleFor(artist)
        val start = runCatching { LocalDate.parse(cycle.startIso) }.getOrDefault(LocalDate.now().withDayOfMonth(1))
        val end = runCatching { LocalDate.parse(cycle.endIso) }.getOrDefault(YearMonth.now().atEndOfMonth())
        val snapshots = state.snapshots.filter { it.artistId == artist.id }
        val daily = state.dailyStreamRecords.filter { it.artistId == artist.id }
        val payments = state.payments.filter { it.artistId == artist.id }
        val metrics = StreamMetricsEngine.cycleMetrics(
            snapshots, daily, start, end,
            entryMode = resolvedStreamEntryMode(artist), cycleId = artist.financialCycleId
        )
        val rpm = RoyaltyEngine.personalizedRpm(artist, payments)
        val forecast = RoyaltyEngine.forecast(
            snapshots, daily, start, end, LocalDate.now(), rpm,
            entryMode = resolvedStreamEntryMode(artist), cycleId = artist.financialCycleId
        )
        val estimated = RoyaltyEngine.estimateBrl(metrics.currentStreams, rpm)

        rv.setTextViewText(R.id.widget_title, if (mode == WidgetMode.DISTRIBUTION_GRAPH) "Distribuição • Gráfico" else "Distribuição • Resumo")
        rv.setTextViewText(R.id.widget_subtitle, "${artist.name} • ${DistributorRules.displayName(artist.distributor, artist.customDistributorName)}")

        if (mode == WidgetMode.DISTRIBUTION_SUMMARY) {
            rv.setViewVisibility(R.id.widget_main_value, View.VISIBLE)
            rv.setTextViewText(R.id.widget_main_value, "${number(metrics.currentStreams)} streams")
            rv.setViewVisibility(R.id.widget_metrics, View.VISIBLE)
            rv.setTextViewText(R.id.widget_metric_1, "${money(estimated)}\nESTIMADO")
            rv.setTextViewText(R.id.widget_metric_2, "${money(forecast.projectedBrl)}\nPREVISÃO")
            rv.setTextViewText(R.id.widget_metric_3, "${metrics.recentDailyAverage.toLong()}\n/DIA")
        } else {
            rv.setViewVisibility(R.id.widget_graph, View.VISIBLE)
            val values = metrics.dailyEntries.takeLast(12).map { it.streams.toFloat() }.ifEmpty { listOf(0f, 0f) }
            rv.setImageViewBitmap(R.id.widget_graph, lineChartBitmap(values))
            rv.setViewVisibility(R.id.widget_metrics, View.VISIBLE)
            rv.setTextViewText(R.id.widget_metric_1, "${number(metrics.currentStreams)}\nSTREAMS")
            rv.setTextViewText(R.id.widget_metric_2, "${metrics.recentDailyAverage.toLong()}\nRITMO/DIA")
            rv.setTextViewText(R.id.widget_metric_3, "${number(forecast.projectedStreams)}\nPROJEÇÃO")
        }
        rv.setOnClickPendingIntent(R.id.widget_root, openAppIntent(context, "DISTRIBUTION", 1400 + mode.ordinal))
    }

    private fun hasDistributionAccess(context: Context, state: AppState): Boolean {
        val authority = context.getSharedPreferences("sonus_authority_cache_v1", Context.MODE_PRIVATE)
        if (authority.getString("role", null) == AccountRole.OWNER.name) return true

        val premiumActive = (state.preferences.premiumExpiresAtEpochMillis ?: 0L) > System.currentTimeMillis()
        if (premiumActive) {
            val paidTier = when (state.preferences.promotionalTierName?.uppercase(Locale.US)) {
                "BRONZE", "PLUS", "PRATA", "STUDIO", "OURO", "MAX", "DIAMANTE", "DIAMOND" -> true
                else -> false
            }
            if (paidTier) return true
        }

        val trial = context.getSharedPreferences(DISTRIBUTION_TRIAL_PREFS, Context.MODE_PRIVATE)
        return trial.getBoolean("active", false) && trial.getLong("expires_at", 0L) > System.currentTimeMillis()
    }

    private fun playerSnapshot(context: Context): PlayerWidgetSnapshot {
        val p = context.getSharedPreferences(PLAYER_SNAPSHOT_PREFS, Context.MODE_PRIVATE)
        return PlayerWidgetSnapshot(
            title = p.getString("title", "Nada tocando") ?: "Nada tocando",
            artist = p.getString("artist", "Abra o SONUS para escolher uma música") ?: "Abra o SONUS para escolher uma música",
            uri = p.getString("uri", null),
            source = p.getString("source", "Local") ?: "Local",
            playing = p.getBoolean("playing", false),
            positionMs = p.getLong("position", 0L),
            durationMs = p.getLong("duration", 0L)
        )
    }

    private fun loadArtwork(context: Context, uri: String?): Bitmap? {
        if (uri.isNullOrBlank()) return null
        return runCatching {
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(context, Uri.parse(uri))
            val bytes = retriever.embeddedPicture
            retriever.release()
            val src = bytes?.let { BitmapFactory.decodeByteArray(it, 0, it.size) } ?: return@runCatching null
            roundedSquare(src, 180)
        }.getOrNull()
    }

    private fun roundedSquare(src: Bitmap, size: Int): Bitmap {
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val rect = RectF(0f, 0f, size.toFloat(), size.toFloat())
        canvas.drawRoundRect(rect, 28f, 28f, paint)
        paint.xfermode = android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.SRC_IN)
        canvas.drawBitmap(src, null, rect, paint)
        return out
    }

    private fun lineChartBitmap(values: List<Float>): Bitmap {
        val w = 800
        val h = 180
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val colors = intArrayOf(Color.rgb(56, 225, 177), Color.rgb(68, 160, 255), Color.rgb(168, 91, 255))
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 8f
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            shader = LinearGradient(0f, 0f, w.toFloat(), 0f, colors, null, Shader.TileMode.CLAMP)
        }
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            shader = LinearGradient(0f, 0f, 0f, h.toFloat(), intArrayOf(Color.argb(80, 56, 225, 177), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        }
        val maxV = (values.maxOrNull() ?: 0f).coerceAtLeast(1f)
        val path = Path()
        val fillPath = Path()
        values.forEachIndexed { i, v ->
            val x = if (values.size <= 1) 0f else i * w.toFloat() / (values.size - 1)
            val y = h - 12f - (v / maxV) * (h - 30f)
            if (i == 0) {
                path.moveTo(x, y)
                fillPath.moveTo(x, h.toFloat())
                fillPath.lineTo(x, y)
            } else {
                path.lineTo(x, y)
                fillPath.lineTo(x, y)
            }
        }
        fillPath.lineTo(w.toFloat(), h.toFloat())
        fillPath.close()
        canvas.drawPath(fillPath, fill)
        canvas.drawPath(path, line)
        return bmp
    }

    private fun applyStyle(context: Context, rv: RemoteViews, style: String) {
        val light = style == "white"
        val bg = when (style) {
            "white" -> R.drawable.widget_bg_white
            "transparent" -> R.drawable.widget_bg_transparent
            else -> R.drawable.widget_bg_black
        }
        rv.setInt(R.id.widget_root, "setBackgroundResource", bg)
        val main = if (light) Color.rgb(18, 21, 26) else Color.WHITE
        val secondary = if (light) Color.rgb(73, 80, 90) else Color.argb(205, 255, 255, 255)
        rv.setTextColor(R.id.widget_title, main)
        listOf(R.id.widget_main_value, R.id.widget_metric_1, R.id.widget_metric_2, R.id.widget_metric_3).forEach { rv.setTextColor(it, main) }
        listOf(R.id.widget_subtitle, R.id.widget_secondary).forEach { rv.setTextColor(it, secondary) }
        listOf(R.id.widget_prev, R.id.widget_play, R.id.widget_next, R.id.widget_open).forEach { rv.setInt(it, "setColorFilter", main) }
    }

    private fun playerActionIntent(context: Context, action: String, code: Int): PendingIntent {
        val intent = Intent(context, PulsePlayerService::class.java).setAction(action)
        return PendingIntent.getService(context, code, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun openAppIntent(context: Context, route: String?, code: Int): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        if (route != null) intent.putExtra("sonus_notification_route", route)
        return PendingIntent.getActivity(context, code, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun number(v: Long): String = NumberFormat.getIntegerInstance(Locale("pt", "BR")).format(v)
    private fun money(v: Double): String = NumberFormat.getCurrencyInstance(Locale("pt", "BR")).format(v)
    private fun formatTime(ms: Long): String {
        val s = (ms / 1000L).coerceAtLeast(0L)
        return "%d:%02d".format(s / 60L, s % 60L)
    }

    internal val providerMap: Map<Class<out AppWidgetProvider>, WidgetMode> = linkedMapOf(
        PlayerCompactWidget::class.java to WidgetMode.PLAYER_COMPACT,
        PlayerCompleteWidget::class.java to WidgetMode.PLAYER_COMPLETE,
        DistributionSummaryWidget::class.java to WidgetMode.DISTRIBUTION_SUMMARY,
        DistributionGraphWidget::class.java to WidgetMode.DISTRIBUTION_GRAPH
    )
}

abstract class SonusWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { SonusWidgetCenter.updateOne(context, it) }
    }

    override fun onDeleted(context: Context, ids: IntArray) {
        val editor = context.getSharedPreferences(WIDGET_STYLE_PREFS, Context.MODE_PRIVATE).edit()
        ids.forEach { editor.remove("style_$it") }
        editor.apply()
    }
}

class PlayerCompactWidget : SonusWidgetProvider()
class PlayerCompleteWidget : SonusWidgetProvider()
class DistributionSummaryWidget : SonusWidgetProvider()
class DistributionGraphWidget : SonusWidgetProvider()

class SonusWidgetConfigActivity : ComponentActivity() {
    private var widgetId: Int = AppWidgetManager.INVALID_APPWIDGET_ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        widgetId = intent?.extras?.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
            ?: AppWidgetManager.INVALID_APPWIDGET_ID
        setResult(Activity.RESULT_CANCELED)
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish()
            return
        }
        val prefs = getSharedPreferences(WIDGET_STYLE_PREFS, Context.MODE_PRIVATE)
        setContent {
            MaterialTheme {
                WidgetConfigScreen(
                    initialStyle = prefs.getString("style_$widgetId", "black") ?: "black"
                ) { style ->
                    prefs.edit().putString("style_$widgetId", style).apply()
                    SonusWidgetCenter.updateOne(this, widgetId)
                    setResult(Activity.RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
                    finish()
                }
            }
        }
    }
}

@Composable
private fun WidgetConfigScreen(initialStyle: String, onSave: (String) -> Unit) {
    var style by remember { mutableStateOf(initialStyle) }
    Box(
        Modifier.fillMaxSize().background(ComposeColor(0xFF090D14)).padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Aparência do widget", color = ComposeColor.White, fontSize = 26.sp)
            Text("Escolha uma aparência. O conteúdo continuará atualizado pelo SONUS.", color = ComposeColor.White.copy(alpha = .68f), fontSize = 14.sp)
            StyleOption("Preto", ComposeColor(0xFF11151D), selected = style == "black") { style = "black" }
            StyleOption("Branco", ComposeColor(0xFFF3F4F6), darkText = true, selected = style == "white") { style = "white" }
            StyleOption("Transparente", ComposeColor(0x663A4453), selected = style == "transparent") { style = "transparent" }
            Spacer(Modifier.height(4.dp))
            Button(onClick = { onSave(style) }, modifier = Modifier.fillMaxWidth()) { Text("Adicionar widget") }
        }
    }
}

@Composable
private fun StyleOption(
    label: String,
    bg: ComposeColor,
    darkText: Boolean = false,
    selected: Boolean = false,
    onClick: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth()
            .background(if (selected) bg.copy(alpha = .96f) else bg, RoundedCornerShape(24.dp))
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = if (darkText) ComposeColor(0xFF16191E) else ComposeColor.White, fontSize = 17.sp, modifier = Modifier.weight(1f))
        if (selected) Text("✓", color = if (darkText) ComposeColor(0xFF16191E) else ComposeColor.White, fontSize = 18.sp)
    }
}
