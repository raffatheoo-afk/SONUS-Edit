package com.sonusstudios.streampulse.tools

import androidx.compose.runtime.LaunchedEffect
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Color as AndroidColor
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path as AndroidPath
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Draw
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.Highlight
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.roundToInt

private class PdfDoc(val renderer: PdfRenderer, val pfd: ParcelFileDescriptor) {
    private val mutex = Mutex()
    val pageCount: Int get() = renderer.pageCount
    suspend fun render(page: Int, width: Int): Bitmap = mutex.withLock {
        renderer.openPage(page).use { p ->
            val h = (width * p.height / p.width.toFloat()).roundToInt().coerceAtLeast(1)
            val bmp = Bitmap.createBitmap(width, h, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(AndroidColor.WHITE)
            p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            bmp
        }
    }
    fun close() { runCatching { renderer.close() }; runCatching { pfd.close() } }
}

private sealed class PdfSource {
    class FromPdf(val doc: Int, val page: Int) : PdfSource()
    class FromBitmap(val bitmap: Bitmap) : PdfSource()
}

/** Elementos colocados sobre a página. Coordenadas normalizadas (0..1) para valerem em qualquer resolução. */
private sealed class PdfOverlay {
    class Stroke(val points: List<Offset>, val color: Int, val widthFrac: Float, val alpha: Int) : PdfOverlay()
    class Img(val bitmap: Bitmap, cx: Float, cy: Float, wFrac: Float) : PdfOverlay() {
        var cx by mutableFloatStateOf(cx); var cy by mutableFloatStateOf(cy); var wFrac by mutableFloatStateOf(wFrac)
    }
    class Txt(val text: String, val color: Int, cx: Float, cy: Float, sizeFrac: Float) : PdfOverlay() {
        var cx by mutableFloatStateOf(cx); var cy by mutableFloatStateOf(cy); var sizeFrac by mutableFloatStateOf(sizeFrac)
    }
}

private class PdfPageState(val id: Long, val source: PdfSource) {
    var rotation by mutableIntStateOf(0)
    val overlays = mutableStateListOf<PdfOverlay>()
}

private enum class PdfMode(val label: String) { MOVE("Mover"), DRAW("Desenhar"), HIGHLIGHT("Marca-texto") }
private val pdfColors = listOf(AndroidColor.BLACK, AndroidColor.rgb(211, 47, 47), AndroidColor.rgb(25, 118, 210), AndroidColor.rgb(56, 142, 60), AndroidColor.rgb(255, 193, 7), AndroidColor.WHITE)
private const val A4_W = 1654
private const val A4_H = 2339

private fun blankA4(): Bitmap = Bitmap.createBitmap(A4_W, A4_H, Bitmap.Config.ARGB_8888).also { it.eraseColor(AndroidColor.WHITE) }

private fun imageAsPage(src: Bitmap): Bitmap {
    val page = blankA4()
    val scale = minOf(A4_W.toFloat() / src.width, A4_H.toFloat() / src.height)
    val w = src.width * scale; val h = src.height * scale
    AndroidCanvas(page).drawBitmap(src, null, RectF((A4_W - w) / 2f, (A4_H - h) / 2f, (A4_W + w) / 2f, (A4_H + h) / 2f), Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
    return page
}

private fun rotateBitmap(src: Bitmap, degrees: Int): Bitmap =
    if (degrees % 360 == 0) src else Bitmap.createBitmap(src, 0, 0, src.width, src.height, Matrix().apply { postRotate(degrees.toFloat()) }, true)

private suspend fun renderBase(docs: List<PdfDoc>, page: PdfPageState, rotation: Int, width: Int): Bitmap = withContext(Dispatchers.IO) {
    val raw = when (val s = page.source) {
        is PdfSource.FromPdf -> docs[s.doc].render(s.page, width)
        is PdfSource.FromBitmap -> Bitmap.createScaledBitmap(s.bitmap, width, (width * s.bitmap.height / s.bitmap.width.toFloat()).roundToInt().coerceAtLeast(1), true)
    }
    rotateBitmap(raw, rotation)
}

/** Desenha as marcas da página (mesma função para a tela e para a exportação). */
private fun drawOverlays(canvas: AndroidCanvas, w: Float, h: Float, overlays: List<PdfOverlay>, live: List<Offset>? = null, liveColor: Int = 0, liveWidth: Float = 0f, liveAlpha: Int = 255) {
    val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    fun stroke(points: List<Offset>, color: Int, widthFrac: Float, alpha: Int) {
        if (points.isEmpty()) return
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
            strokeWidth = widthFrac * w; this.color = color; this.alpha = alpha
        }
        if (points.size == 1) { canvas.drawPoint(points[0].x * w, points[0].y * h, p); return }
        val path = AndroidPath(); path.moveTo(points[0].x * w, points[0].y * h)
        points.drop(1).forEach { path.lineTo(it.x * w, it.y * h) }
        canvas.drawPath(path, p)
    }
    overlays.forEach { o ->
        when (o) {
            is PdfOverlay.Stroke -> stroke(o.points, o.color, o.widthFrac, o.alpha)
            is PdfOverlay.Img -> {
                val iw = o.wFrac * w; val ih = iw * o.bitmap.height / o.bitmap.width.toFloat()
                val cx = o.cx * w; val cy = o.cy * h
                canvas.drawBitmap(o.bitmap, null, RectF(cx - iw / 2f, cy - ih / 2f, cx + iw / 2f, cy + ih / 2f), paint)
            }
            is PdfOverlay.Txt -> {
                paint.color = o.color; paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD); paint.textSize = o.sizeFrac * w
                val tw = paint.measureText(o.text)
                canvas.drawText(o.text, o.cx * w - tw / 2f, o.cy * h + paint.textSize * 0.35f, paint)
            }
        }
    }
    if (live != null) stroke(live, liveColor, liveWidth, liveAlpha)
}

private fun overlayHit(o: PdfOverlay, p: Offset, w: Float, h: Float): Boolean = when (o) {
    is PdfOverlay.Img -> {
        val iw = o.wFrac; val ih = o.wFrac * w * o.bitmap.height / o.bitmap.width.toFloat() / h
        kotlin.math.abs(p.x - o.cx) <= iw / 2f && kotlin.math.abs(p.y - o.cy) <= ih / 2f
    }
    is PdfOverlay.Txt -> kotlin.math.abs(p.x - o.cx) <= max(0.12f, o.sizeFrac * o.text.length * 0.35f) && kotlin.math.abs(p.y - o.cy) <= max(0.03f, o.sizeFrac * w / h)
    else -> false
}

@Composable
internal fun PdfStudioTool(onBack: () -> Unit, onTrack: (String, Boolean?, Long?) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val docs = remember { mutableStateListOf<PdfDoc>() }
    val pages = remember { mutableStateListOf<PdfPageState>() }
    var nextId by remember { mutableLongStateOf(1L) }
    var selected by remember { mutableStateOf<Long?>(null) }
    var mode by remember { mutableStateOf(PdfMode.MOVE) }
    var penColor by remember { mutableIntStateOf(AndroidColor.BLACK) }
    var penWidth by remember { mutableFloatStateOf(0.006f) }
    var message by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(0) }
    var textDialog by remember { mutableStateOf(false) }
    var signDialog by remember { mutableStateOf(false) }
    var pendingExport by remember { mutableStateOf<Uri?>(null) }

    DisposableEffect(Unit) { onDispose { docs.forEach { it.close() } } }

    fun openPdf(uri: Uri, replace: Boolean) {
        scope.launch {
            val doc = withContext(Dispatchers.IO) {
                runCatching {
                    val pfd = context.contentResolver.openFileDescriptor(uri, "r") ?: error("sem acesso")
                    try { PdfDoc(PdfRenderer(pfd), pfd) } catch (t: Throwable) { runCatching { pfd.close() }; throw t }
                }
            }
            doc.onSuccess { d ->
                if (replace) { docs.forEach { it.close() }; docs.clear(); pages.clear(); selected = null }
                docs.add(d)
                val index = docs.lastIndex
                for (i in 0 until d.pageCount) { pages.add(PdfPageState(nextId++, PdfSource.FromPdf(index, i))) }
                message = "✓ ${d.pageCount} página(s) carregada(s). Toque em uma página para editar."
            }.onFailure { message = "Não foi possível abrir este PDF (arquivos protegidos por senha ou corrompidos não são suportados)." }
        }
    }
    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) openPdf(uri, replace = true) }
    val addPdfLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) openPdf(uri, replace = false) }
    val imagePageLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val bmp = withContext(Dispatchers.IO) { SonusImageIo.decode(context, uri, 12_000_000L) }
            if (bmp == null) message = "Não foi possível ler a imagem." else { pages.add(PdfPageState(nextId++, PdfSource.FromBitmap(imageAsPage(bmp)))); message = "✓ Imagem adicionada como página." }
        }
    }
    val overlayImageLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val page = pages.firstOrNull { it.id == selected }
        if (uri != null && page != null) scope.launch {
            val bmp = withContext(Dispatchers.IO) { SonusImageIo.decode(context, uri, 6_000_000L) }
            if (bmp != null) { page.overlays.add(PdfOverlay.Img(bmp, 0.5f, 0.5f, 0.4f)); message = "Foto adicionada. Arraste para posicionar e use o controle de tamanho." }
        }
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri -> pendingExport = uri }

    // Exportação: cada página vira uma imagem A4 (150–200 dpi) com as marcas por cima, dentro de um novo PDF.
    LaunchedEffect(pendingExport) {
        val target = pendingExport ?: return@LaunchedEffect
        pendingExport = null
        busy = true; progress = 1; message = null
        val started = System.currentTimeMillis()
        val pageSnapshot = pages.toList()
        val exportResult = withContext(Dispatchers.IO) {
            runCatching {
                val out = PdfDocument()
                try {
                pageSnapshot.forEachIndexed { index, page ->
                    val base = renderBase(docs, page, page.rotation, A4_W)
                    val canvasBmp = base.copy(Bitmap.Config.ARGB_8888, true)
                    drawOverlays(AndroidCanvas(canvasBmp), canvasBmp.width.toFloat(), canvasBmp.height.toFloat(), page.overlays.toList())
                    val pw = 595; val ph = (595f * canvasBmp.height / canvasBmp.width).roundToInt().coerceAtLeast(1)
                    val pdfPage = out.startPage(PdfDocument.PageInfo.Builder(pw, ph, index + 1).create())
                    pdfPage.canvas.drawBitmap(canvasBmp, null, RectF(0f, 0f, pw.toFloat(), ph.toFloat()), Paint(Paint.FILTER_BITMAP_FLAG))
                    out.finishPage(pdfPage)
                    withContext(Dispatchers.Main) { progress = ((index + 1) * 100f / pageSnapshot.size.coerceAtLeast(1)).roundToInt() }
                }
                context.contentResolver.openOutputStream(target, "w")?.use { out.writeTo(it) } ?: error("Não foi possível abrir o arquivo de destino.")
                } finally { out.close() }
            }
        }
        busy = false
        val ok = exportResult.isSuccess
        message = if (ok) "✓ PDF salvo com ${pageSnapshot.size} página(s). As páginas exportadas viram imagens (o texto deixa de ser selecionável)." else "Falha ao salvar: ${exportResult.exceptionOrNull()?.message ?: "erro desconhecido"}"
        onTrack("Editor de PDF: ${pageSnapshot.size} página(s)", ok, System.currentTimeMillis() - started)
    }

    if (busy) SonusExportProgressDialog(percent = progress, phase = "Montando o PDF…", title = "Editor de PDF")

    val current = pages.firstOrNull { it.id == selected }

    if (textDialog && current != null) PdfTextDialog(onDismiss = { textDialog = false }) { text, color ->
        current.overlays.add(PdfOverlay.Txt(text, color, 0.5f, 0.5f, 0.05f)); textDialog = false
        message = "Texto adicionado. Arraste para posicionar."
    }
    if (signDialog && current != null) PdfSignDialog(onDismiss = { signDialog = false }) { bmp ->
        current.overlays.add(PdfOverlay.Img(bmp, 0.5f, 0.85f, 0.35f)); signDialog = false
        message = "Assinatura adicionada. Arraste para posicionar."
    }

    CreatorToolScaffold(onBack, "Leitor e editor de PDF", "Leia, junte, reorganize e edite PDFs: fotos, texto, desenho, marca-texto e assinatura.") {
        item {
            CreatorCard("Arquivo", Icons.Default.PictureAsPdf) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { openLauncher.launch(arrayOf("application/pdf")) }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.FileOpen, null); Spacer(Modifier.width(6.dp)); Text("Abrir PDF") }
                    OutlinedButton(onClick = { addPdfLauncher.launch(arrayOf("application/pdf")) }, modifier = Modifier.weight(1f)) { Text("Juntar PDF") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { imagePageLauncher.launch(arrayOf("image/*")) }, modifier = Modifier.weight(1f)) { Text("Imagem → página") }
                    OutlinedButton(onClick = { pages.add(PdfPageState(nextId++, PdfSource.FromBitmap(blankA4()))) }, modifier = Modifier.weight(1f)) { Text("Página em branco") }
                }
                Button(
                    onClick = { saveLauncher.launch("Documento_SONUS_${System.currentTimeMillis() / 1000}.pdf") },
                    enabled = pages.isNotEmpty() && !busy, modifier = Modifier.fillMaxWidth()
                ) { Icon(Icons.Default.Save, null); Spacer(Modifier.width(8.dp)); Text("Salvar PDF (${pages.size} página(s))") }
            }
        }
        if (current != null) item {
            CreatorCard("Ferramentas da página ${pages.indexOf(current) + 1}", Icons.Default.Brush) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(PdfMode.entries.toList()) { m -> FilterChip(selected = mode == m, onClick = { mode = m }, label = { Text(m.label) }) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = { overlayImageLauncher.launch(arrayOf("image/*")) }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.AddPhotoAlternate, null); Spacer(Modifier.width(4.dp)); Text("Foto") }
                    OutlinedButton(onClick = { textDialog = true }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.TextFields, null); Spacer(Modifier.width(4.dp)); Text("Texto") }
                    OutlinedButton(onClick = { signDialog = true }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Draw, null); Spacer(Modifier.width(4.dp)); Text("Assinar") }
                }
                if (mode != PdfMode.MOVE) {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(pdfColors) { c ->
                            Box(
                                Modifier.size(34.dp).clip(CircleShape).background(Color(c))
                                    .border(if (penColor == c) 3.dp else 1.dp, if (penColor == c) MaterialTheme.colorScheme.primary else Color.Gray, CircleShape)
                                    .clickable { penColor = c }
                            )
                        }
                    }
                    Text("Espessura", style = MaterialTheme.typography.labelMedium)
                    Slider(value = penWidth, onValueChange = { penWidth = it }, valueRange = 0.002f..0.03f)
                }
                val lastMovable = current.overlays.lastOrNull { it is PdfOverlay.Img || it is PdfOverlay.Txt }
                if (lastMovable is PdfOverlay.Img) { Text("Tamanho da foto", style = MaterialTheme.typography.labelMedium); Slider(value = lastMovable.wFrac, onValueChange = { lastMovable.wFrac = it }, valueRange = 0.08f..1f) }
                if (lastMovable is PdfOverlay.Txt) { Text("Tamanho do texto", style = MaterialTheme.typography.labelMedium); Slider(value = lastMovable.sizeFrac, onValueChange = { lastMovable.sizeFrac = it }, valueRange = 0.015f..0.14f) }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(onClick = { current.overlays.removeLastOrNull() }) { Icon(Icons.Default.Undo, "Desfazer") }
                    IconButton(onClick = { current.rotation = (current.rotation + 90) % 360 }) { Icon(Icons.Default.RotateRight, "Girar") }
                    IconButton(onClick = {
                        val i = pages.indexOf(current)
                        val copy = PdfPageState(nextId++, current.source).also { c -> c.rotation = current.rotation; c.overlays.addAll(current.overlays) }
                        pages.add(i + 1, copy)
                    }) { Icon(Icons.Default.ContentCopy, "Duplicar") }
                    IconButton(onClick = { val i = pages.indexOf(current); if (i > 0) { pages.removeAt(i); pages.add(i - 1, current) } }) { Icon(Icons.Default.ArrowUpward, "Subir") }
                    IconButton(onClick = { val i = pages.indexOf(current); if (i < pages.lastIndex) { pages.removeAt(i); pages.add(i + 1, current) } }) { Icon(Icons.Default.ArrowDownward, "Descer") }
                    IconButton(onClick = { pages.remove(current); selected = null }) { Icon(Icons.Default.Delete, "Excluir página", tint = MaterialTheme.colorScheme.error) }
                }
            }
        }
        items(pages.toList(), key = { it.id }) { page ->
            PdfPageCard(
                page = page, docs = docs, number = pages.indexOf(page) + 1, isSelected = page.id == selected,
                mode = mode, penColor = penColor, penWidth = penWidth, onSelect = { selected = page.id }
            )
        }
        messageItem(message)
    }
}

@Composable
private fun PdfPageCard(
    page: PdfPageState, docs: List<PdfDoc>, number: Int, isSelected: Boolean, mode: PdfMode, penColor: Int, penWidth: Float, onSelect: () -> Unit
) {
    val bitmap by produceState<Bitmap?>(null, page.id, page.rotation) { value = runCatching { renderBase(docs, page, page.rotation, 1000) }.getOrNull() }
    var size by remember { mutableStateOf(IntSize.Zero) }
    var live by remember { mutableStateOf<List<Offset>>(emptyList()) }
    var dragging by remember { mutableStateOf<PdfOverlay?>(null) }
    val highlight = mode == PdfMode.HIGHLIGHT
    Column(Modifier.fillMaxWidth()) {
        Text("Página $number", style = MaterialTheme.typography.labelMedium, fontWeight = if (isSelected) FontWeight.Black else FontWeight.Normal, modifier = Modifier.padding(bottom = 4.dp))
        val bmp = bitmap
        val ratio = if (bmp != null) bmp.width.toFloat() / bmp.height else 0.707f
        Box(
            Modifier.fillMaxWidth().aspectRatio(ratio).clip(RoundedCornerShape(10.dp)).background(Color.White).onSizeChanged { size = it }
                .let { base -> if (isSelected) base.pointerInput(mode, penColor, penWidth, bmp) {
                    detectDragGestures(
                        onDragStart = { start ->
                            val w = size.width.toFloat(); val h = size.height.toFloat()
                            if (mode == PdfMode.MOVE) {
                                val n = Offset(start.x / w, start.y / h)
                                dragging = page.overlays.lastOrNull { overlayHit(it, n, w, h) }
                            } else live = listOf(Offset(start.x / w, start.y / h))
                        },
                        onDrag = { change, delta ->
                            val w = size.width.toFloat(); val h = size.height.toFloat()
                            if (mode == PdfMode.MOVE) {
                                when (val o = dragging) {
                                    is PdfOverlay.Img -> { o.cx = (o.cx + delta.x / w).coerceIn(0f, 1f); o.cy = (o.cy + delta.y / h).coerceIn(0f, 1f) }
                                    is PdfOverlay.Txt -> { o.cx = (o.cx + delta.x / w).coerceIn(0f, 1f); o.cy = (o.cy + delta.y / h).coerceIn(0f, 1f) }
                                    else -> Unit
                                }
                            } else live = live + Offset(change.position.x / w, change.position.y / h)
                        },
                        onDragEnd = {
                            if (mode != PdfMode.MOVE && live.isNotEmpty()) {
                                page.overlays.add(PdfOverlay.Stroke(live, penColor, if (highlight) penWidth * 4f else penWidth, if (highlight) 90 else 255))
                            }
                            live = emptyList(); dragging = null
                        },
                        onDragCancel = { live = emptyList(); dragging = null }
                    )
                } else base.pointerInput(Unit) { detectTapGestures { onSelect() } } }
        ) {
            if (bmp != null) {
                Image(bitmap = bmp.asImageBitmap(), contentDescription = "Página $number", contentScale = ContentScale.FillBounds, modifier = Modifier.fillMaxSize())
                Canvas(Modifier.fillMaxSize()) {
                    // Use the DrawScope dimensions, not the outer IntSize from onSizeChanged.
                    val canvasSize = this.size
                    drawIntoCanvas { c ->
                        drawOverlays(c.nativeCanvas, canvasSize.width, canvasSize.height, page.overlays.toList(), live.takeIf { it.isNotEmpty() }, penColor, if (highlight) penWidth * 4f else penWidth, if (highlight) 90 else 255)
                    }
                }
            } else {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Carregando…") }
            }
        }
        if (!isSelected) TextButton(onClick = onSelect) { Text("Editar esta página") }
    }
}

@Composable
private fun PdfTextDialog(onDismiss: () -> Unit, onOk: (String, Int) -> Unit) {
    var text by remember { mutableStateOf("") }
    var color by remember { mutableIntStateOf(AndroidColor.BLACK) }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("Adicionar texto") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = text, onValueChange = { text = it.take(120) }, singleLine = true, label = { Text("Texto") })
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(pdfColors) { c -> FilterChip(selected = color == c, onClick = { color = c }, label = { Box(Modifier.width(18.dp).height(18.dp).background(Color(c))) }) }
                }
            }
        },
        confirmButton = { TextButton(onClick = { if (text.isNotBlank()) onOk(text.trim(), color) }) { Text("Adicionar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun PdfSignDialog(onDismiss: () -> Unit, onOk: (Bitmap) -> Unit) {
    var strokes by remember { mutableStateOf<List<List<Offset>>>(emptyList()) }
    var current by remember { mutableStateOf<List<Offset>>(emptyList()) }
    var area by remember { mutableStateOf(IntSize.Zero) }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("Assinatura") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Desenhe sua assinatura no quadro.", style = MaterialTheme.typography.bodySmall)
                Box(
                    Modifier.fillMaxWidth().height(160.dp).clip(RoundedCornerShape(12.dp)).background(Color.White).onSizeChanged { area = it }
                        .pointerInput(Unit) {
                            detectDragGestures(
                                onDragStart = { current = listOf(it) },
                                onDrag = { change, _ -> current = current + change.position },
                                onDragEnd = { strokes = strokes + listOf(current); current = emptyList() }
                            )
                        }
                ) {
                    Canvas(Modifier.fillMaxWidth().height(160.dp)) {
                        (strokes + listOf(current)).forEach { s ->
                            for (i in 1 until s.size) drawLine(Color.Black, s[i - 1], s[i], 6f)
                        }
                    }
                }
                TextButton(onClick = { strokes = emptyList(); current = emptyList() }) { Text("Limpar") }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (strokes.isNotEmpty() && area.width > 0) {
                    val bmp = Bitmap.createBitmap(area.width, area.height, Bitmap.Config.ARGB_8888)
                    val c = AndroidCanvas(bmp)
                    val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = AndroidColor.BLACK; strokeWidth = 6f; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
                    strokes.forEach { s -> for (i in 1 until s.size) c.drawLine(s[i - 1].x, s[i - 1].y, s[i].x, s[i].y, p) }
                    onOk(bmp)
                }
            }) { Text("Usar assinatura") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
