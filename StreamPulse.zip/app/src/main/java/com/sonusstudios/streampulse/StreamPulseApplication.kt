package com.sonusstudios.streampulse

import android.app.Application
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.playintegrity.PlayIntegrityAppCheckProviderFactory
import com.sonusstudios.streampulse.core.SonusStorage
import com.sonusstudios.streampulse.notifications.SonusNotificationCenter
import com.sonusstudios.streampulse.tools.SonusLockScreenController
import com.sonusstudios.streampulse.widgets.SonusWidgetCenter

class StreamPulseApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // code99: prepara a autenticação de origem do app. O enforcement é ativado no Firebase Console
        // somente quando o projeto estiver pronto, evitando quebrar builds beta/sideload durante a migração.
        runCatching { FirebaseAppCheck.getInstance().installAppCheckProviderFactory(PlayIntegrityAppCheckProviderFactory.getInstance()) }
        SonusStorage.ensureAppFolders(this)
        SonusNotificationCenter.initialize(this)
        runCatching { SonusWidgetCenter.refreshAll(this) }
        // code132: tentativa automática do player sobre o bloqueio (best effort; ver SonusLockScreenController).
        runCatching { SonusLockScreenController.install(this) }
        // Catálogo, capas e locuções da Rádio são obtidos sob demanda, depois da escolha do usuário.
    }
}
