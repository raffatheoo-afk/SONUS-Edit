package com.sonusstudios.streampulse

import android.app.Application
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.playintegrity.PlayIntegrityAppCheckProviderFactory
import com.sonusstudios.streampulse.core.SonusStorage
import com.sonusstudios.streampulse.notifications.SonusNotificationCenter
import com.sonusstudios.streampulse.tools.SonusOnlineMusicRepository
import com.sonusstudios.streampulse.widgets.SonusWidgetCenter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class StreamPulseApplication : Application() {
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    override fun onCreate() {
        super.onCreate()
        // code99: prepara a autenticação de origem do app. O enforcement é ativado no Firebase Console
        // somente quando o projeto estiver pronto, evitando quebrar builds beta/sideload durante a migração.
        runCatching { FirebaseAppCheck.getInstance().installAppCheckProviderFactory(PlayIntegrityAppCheckProviderFactory.getInstance()) }
        SonusStorage.ensureAppFolders(this)
        SonusNotificationCenter.initialize(this)
        runCatching { SonusWidgetCenter.refreshAll(this) }
        // Prepara o snapshot do SONUS Stream fora da UI. Com ~200 músicas, o custo
        // de desserialização/capas já acontece antes do primeiro toque na aba.
        appScope.launch { runCatching { SonusOnlineMusicRepository(applicationContext).warmProcessSnapshot() } }
    }
}
