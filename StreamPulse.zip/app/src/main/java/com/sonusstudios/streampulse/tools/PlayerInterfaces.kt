package com.sonusstudios.streampulse.tools

import android.content.Context
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonusstudios.streampulse.core.MembershipTier
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.isActive
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.roundToInt

/**
 * Interfaces visuais do SONUS PLAYER. Elas alteram somente a apresentação do player:
 * transporte, fila, áudio, temas e regras de reprodução continuam compartilhados.
 *
 * code68: todas as visualizações usam o mesmo motor visual SONUS, alimentado pelo PCM Media3.
 */
private val LocalSonusStreamPlayCount = staticCompositionLocalOf<Long?> { null }

internal data class PlayerInterfaceSpec(
    val id: String,
    val name: String,
    val tier: MembershipTier,
    val description: String,
    val badge: String
)

internal val PulsePlayerInterfaces = listOf(
    PlayerInterfaceSpec("classic", "SONUS Classic", MembershipTier.FREE, "Interface original do SONUS, limpa e completa.", "PADRÃO"),
    PlayerInterfaceSpec("pure", "Pure", MembershipTier.FREE, "Minimalista, leve e focada na capa.", "GRÁTIS"),
    PlayerInterfaceSpec("flow", "Flow", MembershipTier.FREE, "Gradiente moderno e leitura rápida.", "GRÁTIS"),
    PlayerInterfaceSpec("orbit", "Orbit", MembershipTier.FREE, "Disco circular com progresso ao redor.", "GRÁTIS"),
    PlayerInterfaceSpec("vinyl_glow", "Vinyl Glow", MembershipTier.FREE, "Vinil moderno giratório com capa ampliada.", "GRÁTIS"),
    PlayerInterfaceSpec("neon_disc", "Neon Disc", MembershipTier.FREE, "Disco neon reativo com barras SONUS.", "GRÁTIS"),
    PlayerInterfaceSpec("cassette_retro", "Cassette Retro", MembershipTier.FREE, "Cassete mecânico com VU estéreo.", "GRÁTIS"),
    PlayerInterfaceSpec("turntable_classic", "Turntable Classic", MembershipTier.FREE, "Toca-discos animado com VU Meter.", "GRÁTIS"),
    PlayerInterfaceSpec("aurora", "Aurora", MembershipTier.FREE, "Azul-marinho, ondas ciano e equalizador multicolorido.", "NOVO"),
    PlayerInterfaceSpec("sonus_vibe", "Sonus Vibe", MembershipTier.FREE, "Capa circular, espectro radial e ondas luminosas.", "NOVO"),
    PlayerInterfaceSpec("pulse", "Pulse", MembershipTier.FREE, "Anéis luminosos e visual de pulso sonoro.", "NOVO"),
    PlayerInterfaceSpec("spectra", "Spectra", MembershipTier.FREE, "Espectro multicolorido e ondas fluidas.", "NOVO"),
    PlayerInterfaceSpec("neon_wave", "Neon Wave", MembershipTier.FREE, "Fitas neon e painel de controles Glass.", "NOVO"),
    PlayerInterfaceSpec("deep_blue", "Deep Blue", MembershipTier.FREE, "Azul profundo, halo radial e barras de áudio.", "NOVO"),
    PlayerInterfaceSpec("prism", "Prism", MembershipTier.FREE, "Arcos luminosos roxos e magenta.", "NOVO"),
    PlayerInterfaceSpec("verde_vivo", "Verde Vivo", MembershipTier.FREE, "Ondas orgânicas e acentos esmeralda.", "NOVO"),
    PlayerInterfaceSpec("ouro", "Ouro", MembershipTier.FREE, "Fitas douradas e equalizador âmbar.", "NOVO"),
    PlayerInterfaceSpec("mare", "Maré", MembershipTier.FREE, "Ambiente oceânico, teal e ondas fluidas.", "NOVO")
)

private data class InterfaceCallbacks(
    val onToggle: () -> Unit,
    val onPrevious: () -> Unit,
    val onNext: () -> Unit,
    val onSeek: (Long) -> Unit,
    val onShuffle: () -> Unit,
    val onRepeat: () -> Unit,
    val onLike: (String) -> Unit,
    val onPin: (String) -> Unit,
    val streamDownloadEnabled: Boolean,
    val streamDownloaded: Boolean,
    val streamDownloading: Boolean,
    val streamDownloadProgress: Float,
    val onStreamDownload: () -> Unit,
    val onLyrics: () -> Unit,
    val onStats: () -> Unit,
    val onAutoVolume: () -> Unit,
    val onLibrary: () -> Unit,
    val onEqualizer: () -> Unit,
    val radioMode: Boolean,
    val radioDelayMs: Long,
    val radioWindowMs: Long,
    val onRadioDelay: (Long) -> Unit
)

@Composable
internal fun SonusPlayerInterface(
    spec: PlayerInterfaceSpec,
    item: PulsePlayerQueueItem,
    state: PulsePlayerPlaybackState,
    spectrumFlow: StateFlow<List<Float>>,
    artwork: ImageBitmap?,
    coverColors: List<Color>,
    themeColors: List<Color>,
    accent: Color,
    visualizer: PlayerVisualizerSpec,
    visualizerEnabled: Boolean,
    intensityPercent: Int,
    sensitivity: Float,
    smoothness: Int,
    liked: Set<String>,
    pinned: Set<String>,
    onToggle: () -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    onSeek: (Long) -> Unit,
    onShuffle: () -> Unit,
    onRepeat: () -> Unit,
    onLike: (String) -> Unit,
    onPin: (String) -> Unit,
    onLyrics: () -> Unit,
    onStats: () -> Unit,
    onAutoVolume: () -> Unit,
    onLibrary: () -> Unit,
    onEqualizer: () -> Unit,
    streamPlayCount: Long? = null,
    radioMode: Boolean = false,
    radioDelayMs: Long = 0L,
    radioWindowMs: Long = SonusRadioEngine.MAX_REWIND_MS,
    onRadioDelay: (Long) -> Unit = {},
    compact: Boolean,
    modifier: Modifier = Modifier,
    streamDownloadEnabled: Boolean = false,
    streamDownloaded: Boolean = false,
    streamDownloading: Boolean = false,
    streamDownloadProgress: Float = 0f,
    onStreamDownload: () -> Unit = {}
) {
    val callbacks = InterfaceCallbacks(
        onToggle,onPrevious,onNext,onSeek,onShuffle,onRepeat,onLike,onPin,
        streamDownloadEnabled,streamDownloaded,streamDownloading,streamDownloadProgress,onStreamDownload,
        onLyrics,onStats,onAutoVolume,onLibrary,onEqualizer,radioMode,radioDelayMs,radioWindowMs,onRadioDelay
    )
    val spectrum = rememberFluidSpectrum(
        sourceFlow = spectrumFlow,
        playing = state.playing,
        intensityPercent = intensityPercent,
        sensitivity = sensitivity,
        smoothness = smoothness
    )
    val visualColors = rememberResolvedVisualizerColors(visualizer, coverColors, accent)
    CompositionLocalProvider(LocalSonusStreamPlayCount provides streamPlayCount) {
    Box(modifier) {
        // O player mantém toda a área original; as letras ficam no TopAppBar da tela.
        val inner = Modifier.fillMaxSize()
        when (spec.id) {
            "pure" -> PurePlayer(item,state,artwork,accent,visualColors,spectrum,visualizerEnabled,liked,pinned,callbacks,compact,inner)
            "flow" -> FlowPlayer(item,state,artwork,themeColors,accent,visualColors,spectrum,visualizerEnabled,liked,pinned,callbacks,compact,inner)
            "orbit" -> OrbitPlayer(item,state,artwork,accent,visualColors,spectrum,visualizerEnabled,liked,pinned,callbacks,compact,inner)
            "vinyl_glow" -> VinylGlowPlayer(item,state,artwork,accent,visualColors,spectrum,visualizerEnabled,liked,pinned,callbacks,compact,inner)
            "neon_disc" -> NeonDiscPlayer(item,state,artwork,accent,visualColors,spectrum,visualizerEnabled,liked,pinned,callbacks,compact,inner)
            "aurora", "sonus_vibe", "pulse", "spectra", "neon_wave", "deep_blue", "prism", "verde_vivo", "ouro", "mare" ->
                ReferenceThemePlayer(spec.id,item,state,artwork,themeColors,accent,visualColors,spectrum,visualizerEnabled,liked,pinned,callbacks,compact,inner)
            "cassette_retro" -> CassettePlayer(item,state,artwork,accent,visualColors,spectrum,visualizerEnabled,liked,pinned,callbacks,compact,inner)
            "turntable_classic" -> TurntablePlayer(item,state,artwork,accent,visualColors,spectrum,visualizerEnabled,liked,pinned,callbacks,compact,inner)
            else -> ClassicPlayer(item,state,artwork,accent,visualColors,spectrum,visualizerEnabled,liked,pinned,callbacks,compact,inner)
        }
    }
    }
}

/**
 * Motor visual compartilhado.
 *
 * A coleta do PCM não usa State do Compose, então cada pacote PCM NÃO recompõe a tela inteira.
 * O estado abaixo muda no clock de desenho, próximo ao refresh da tela. As Canvas observam esse
 * estado na fase de draw, deixando transporte/capa/textos fora do loop de 60 fps.
 */
@Composable
private fun rememberFluidSpectrum(
    sourceFlow: StateFlow<List<Float>>,
    playing: Boolean,
    intensityPercent: Int,
    sensitivity: Float,
    smoothness: Int,
    bins: Int = 40
): State<List<Float>> {
    val latestSource = remember(sourceFlow) { AtomicReference(sourceFlow.value.ifEmpty { List(24) { 0f } }) }
    val latestPlaying by rememberUpdatedState(playing)
    val latestIntensity by rememberUpdatedState(intensityPercent.coerceIn(50,200) / 100f)
    val latestSensitivity by rememberUpdatedState(sensitivity.coerceIn(.7f,2.2f))
    val latestSmoothness by rememberUpdatedState(smoothness.coerceIn(0,2))
    val smoothed = remember(bins) { FloatArray(bins) }
    val output = remember(bins) { mutableStateOf(List(bins) { 0f }) }

    LaunchedEffect(sourceFlow) {
        sourceFlow.collect { values ->
            if (values.isNotEmpty()) latestSource.set(values)
        }
    }

    LaunchedEffect(bins) {
        var previousFrameNs = 0L
        var adaptiveCeiling = .18f
        while (isActive) {
            val nowNs = withFrameNanos { it }
            val dtSeconds = if (previousFrameNs == 0L) 1f / 60f
            else ((nowNs - previousFrameNs).coerceIn(4_000_000L, 40_000_000L) / 1_000_000_000f)
            previousFrameNs = nowNs

            val source = latestSource.get().ifEmpty { List(24){0f} }
            val sourcePeak = source.maxOrNull()?.coerceAtLeast(0f) ?: 0f
            // Ceiling sobe rápido em masters altos e cai devagar em músicas baixas.
            val ceilingAttack = 1f - exp((-dtSeconds / .055f).toDouble()).toFloat()
            val ceilingRelease = 1f - exp((-dtSeconds / 1.25f).toDouble()).toFloat()
            val wantedCeiling = sourcePeak.coerceIn(.055f, 1f)
            adaptiveCeiling += (wantedCeiling - adaptiveCeiling) * if (wantedCeiling > adaptiveCeiling) ceilingAttack else ceilingRelease
            adaptiveCeiling = adaptiveCeiling.coerceIn(.055f, 1f)

            val attackTau = when (latestSmoothness) { 0 -> .030f; 2 -> .085f; else -> .050f }
            val releaseTau = when (latestSmoothness) { 0 -> .105f; 2 -> .260f; else -> .175f }
            val attack = 1f - exp((-dtSeconds / attackTau).toDouble()).toFloat()
            val release = 1f - exp((-dtSeconds / releaseTau).toDouble()).toFloat()
            val pauseRelease = 1f - exp((-dtSeconds / .115f).toDouble()).toFloat()

            for (i in 0 until bins) {
                val raw = if (latestPlaying) {
                    val pos = i * (source.lastIndex.coerceAtLeast(1).toFloat() / (bins - 1).coerceAtLeast(1))
                    val lo = pos.toInt().coerceIn(0,source.lastIndex)
                    val hi = (lo+1).coerceAtMost(source.lastIndex)
                    val mix = pos-lo
                    source[lo]*(1f-mix)+source[hi]*mix
                } else 0f

                // Remove um piso muito baixo, normaliza pela dinâmica recente e preserva transientes.
                val normalized = ((raw - .006f).coerceAtLeast(0f) / adaptiveCeiling).coerceIn(0f,1f)
                val musical = normalized.pow(.72f)
                val target = (musical * latestSensitivity * latestIntensity).coerceIn(0f,1f)
                val amount = if (!latestPlaying) pauseRelease else if (target >= smoothed[i]) attack else release
                smoothed[i] += (target-smoothed[i])*amount
                if (smoothed[i] < .0025f) smoothed[i] = 0f
            }
            output.value = smoothed.toList()
        }
    }
    return output
}

@Composable
private fun rememberResolvedVisualizerColors(spec: PlayerVisualizerSpec, coverColors: List<Color>, accent: Color): List<Color> {
    var hue by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(spec.dynamicColor) {
        if (!spec.dynamicColor) return@LaunchedEffect
        while (isActive) {
            withFrameNanos { time -> hue = ((time / 1_000_000L) % 12_000L) / 12_000f * 360f }
        }
    }
    return when {
        spec.coverAdaptive && coverColors.size >= 2 -> coverColors.take(5)
        spec.dynamicColor -> listOf(0f,72f,144f,216f,288f).map { h -> Color(android.graphics.Color.HSVToColor(floatArrayOf((h+hue)%360f,.82f,1f))) }
        spec.colors.isNotEmpty() -> spec.colors
        else -> listOf(accent)
    }
}

@Composable
private fun rememberRotationState(playing: Boolean, durationMs: Int): State<Float> {
    val rotation = remember { mutableFloatStateOf(0f) }
    val latestPlaying by rememberUpdatedState(playing)
    val latestDuration by rememberUpdatedState(durationMs.coerceAtLeast(900))
    LaunchedEffect(Unit) {
        var previous = 0L
        while (isActive) {
            val now = withFrameNanos { it }
            if (previous != 0L && latestPlaying) {
                val dt = (now-previous).coerceIn(0L,50_000_000L) / 1_000_000_000f
                rotation.floatValue = (rotation.floatValue + 360f * dt / (latestDuration / 1000f)) % 360f
            }
            previous = now
        }
    }
    return rotation
}

@Composable
private fun Artwork(
    artwork: ImageBitmap?,
    accent: Color,
    modifier: Modifier,
    shape: androidx.compose.ui.graphics.Shape = RoundedCornerShape(24.dp)
) {
    if (artwork != null) Image(artwork,null,modifier.clip(shape),contentScale=ContentScale.Crop)
    else Surface(modifier,shape=shape,color=accent.copy(alpha=.14f)) {
        Box(contentAlignment=Alignment.Center){ Icon(Icons.Default.MusicNote,null,tint=accent,modifier=Modifier.size(52.dp)) }
    }
}

@Composable
private fun TrackHeader(item: PulsePlayerQueueItem, liked:Set<String>, onLike:(String)->Unit, onStats:()->Unit, color:Color=Color.White) {
    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(item.title,fontWeight=FontWeight.Black,fontSize=19.sp,maxLines=1,overflow=TextOverflow.Ellipsis,color=color)
            Text(item.artist.ifBlank{"Artista desconhecido"},fontSize=13.sp,maxLines=1,overflow=TextOverflow.Ellipsis,color=color.copy(alpha=.72f))
        }
        IconButton(onClick={onLike(item.uri)}) { Icon(if(item.uri in liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,null,tint=if(item.uri in liked) Color(0xFFFF5679) else color.copy(alpha=.88f)) }
    }
}

@Composable
private fun ProgressRow(
    state:PulsePlayerPlaybackState,
    accent:Color,
    onSeek:(Long)->Unit,
    contentColor:Color=Color.White,
    arc:Boolean=false,
    cb:InterfaceCallbacks?=null
) {
    val radio = cb?.radioMode == true
    val streamCount = LocalSonusStreamPlayCount.current
    if (radio) {
        val window = cb!!.radioWindowMs.coerceAtLeast(1L)
        val delay = cb.radioDelayMs.coerceIn(0L, window)
        val liveFraction = (1f - delay.toFloat()/window.toFloat()).coerceIn(0f,1f)
        var dragFraction by remember(window) { mutableFloatStateOf(liveFraction) }
        var dragging by remember { mutableStateOf(false) }
        LaunchedEffect(liveFraction, dragging) { if (!dragging) dragFraction = liveFraction }
        Slider(
            value = dragFraction,
            onValueChange = { fraction -> dragging=true; dragFraction=fraction.coerceIn(0f,1f) },
            onValueChangeFinished = { dragging=false; cb.onRadioDelay(((1f-dragFraction)*window).toLong()) },
            modifier=Modifier.fillMaxWidth().height(24.dp),
            colors=SliderDefaults.colors(thumbColor=if(delay<1500L) Color(0xFF45D47B) else Color(0xFFE75B61),activeTrackColor=accent,inactiveTrackColor=contentColor.copy(alpha=.25f))
        )
        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween){
            Text("-10 min",fontSize=9.sp,color=contentColor.copy(alpha=.58f))
            if(streamCount != null || state.autoVolumeActive) Row(verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.spacedBy(5.dp)) {
                if (streamCount != null) Surface(shape=RoundedCornerShape(999.dp),color=contentColor.copy(alpha=.09f)){Row(Modifier.padding(horizontal=8.dp,vertical=3.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.PlayCircle,null,modifier=Modifier.size(12.dp),tint=accent);Spacer(Modifier.width(4.dp));Text("$streamCount reproduções",fontSize=8.sp,fontWeight=FontWeight.SemiBold,color=contentColor.copy(alpha=.78f))}}
                if (state.autoVolumeActive) AutoVolumeBadge(contentColor, cb?.onAutoVolume ?: {}, state.autoVolumePaused)
            }
            Surface(
                shape=RoundedCornerShape(999.dp),
                color=(if(delay<1500L) Color(0xFF45D47B) else Color(0xFFE75B61)).copy(alpha=.16f),
                border=BorderStroke(1.dp,(if(delay<1500L) Color(0xFF45D47B) else Color(0xFFE75B61)).copy(alpha=.42f)),
                modifier=Modifier.clickable { cb.onRadioDelay(0L) }
            ){ Row(Modifier.padding(horizontal=9.dp,vertical=4.dp),verticalAlignment=Alignment.CenterVertically){
                Box(Modifier.size(7.dp).background(if(delay<1500L) Color(0xFF45D47B) else Color(0xFFE75B61),CircleShape));Spacer(Modifier.width(5.dp));Text("AO VIVO",fontSize=8.sp,fontWeight=FontWeight.Black,color=contentColor.copy(alpha=.90f))
            }}
        }
        return
    }
    val progress=if(state.durationMs>0)(state.positionMs.toFloat()/state.durationMs).coerceIn(0f,1f) else 0f
    if(arc){
        Box(Modifier.fillMaxWidth().height(42.dp)){
            Canvas(Modifier.fillMaxSize()){
                val rect=Size(size.width*.84f,size.height*2.1f)
                val top=Offset(size.width*.08f,5f)
                drawArc(contentColor.copy(alpha=.32f),198f,144f,false,top,rect,style=Stroke(4.5f,cap=StrokeCap.Round))
                drawArc(accent,198f,144f*progress,false,top,rect,style=Stroke(6f,cap=StrokeCap.Round))
            }
        }
    } else {
        Slider(progress,{f->if(state.durationMs>0)onSeek((state.durationMs*f).toLong())},modifier=Modifier.fillMaxWidth().height(24.dp),colors=SliderDefaults.colors(thumbColor=accent,activeTrackColor=accent,inactiveTrackColor=contentColor.copy(alpha=.25f)))
    }
    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween){
        Text(clock(state.positionMs),fontSize=10.sp,color=contentColor.copy(alpha=.70f))
        if(streamCount != null || state.autoVolumeActive) Row(verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.spacedBy(5.dp)) {
                if (streamCount != null) Surface(shape=RoundedCornerShape(999.dp),color=contentColor.copy(alpha=.09f)){Row(Modifier.padding(horizontal=8.dp,vertical=3.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.PlayCircle,null,modifier=Modifier.size(12.dp),tint=accent);Spacer(Modifier.width(4.dp));Text("$streamCount reproduções",fontSize=8.sp,fontWeight=FontWeight.SemiBold,color=contentColor.copy(alpha=.78f))}}
                if (state.autoVolumeActive) AutoVolumeBadge(contentColor, cb?.onAutoVolume ?: {}, state.autoVolumePaused)
            }
        Text(clock(state.durationMs),fontSize=10.sp,color=contentColor.copy(alpha=.70f))
    }
}

@Composable
internal fun SonusAutoVolumeMark(modifier: Modifier = Modifier, tint: Color = Color(0xFFFF536B)) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val speaker = Path().apply {
            moveTo(w * .08f, h * .38f)
            lineTo(w * .30f, h * .38f)
            lineTo(w * .54f, h * .18f)
            quadraticTo(w * .61f, h * .14f, w * .61f, h * .24f)
            lineTo(w * .61f, h * .76f)
            quadraticTo(w * .61f, h * .86f, w * .54f, h * .82f)
            lineTo(w * .30f, h * .62f)
            lineTo(w * .08f, h * .62f)
            close()
        }
        drawPath(speaker, tint.copy(alpha = .95f))
        drawArc(tint, -48f, 96f, false, topLeft = Offset(w * .42f, h * .19f), size = Size(w * .56f, h * .62f), style = Stroke(width = (w * .075f).coerceAtLeast(1f), cap = StrokeCap.Round))
        drawArc(tint.copy(alpha = .72f), -48f, 96f, false, topLeft = Offset(w * .51f, h * .05f), size = Size(w * .60f, h * .90f), style = Stroke(width = (w * .06f).coerceAtLeast(1f), cap = StrokeCap.Round))
        drawCircle(tint, radius = (w * .075f).coerceAtLeast(1f), center = Offset(w * .88f, h * .16f))
    }
}

@Composable
private fun AutoVolumeBadge(contentColor: Color, onClick: () -> Unit, paused: Boolean = false) {
    val pulse = rememberInfiniteTransition(label = "auto-volume-pulse")
    val animatedAlpha by pulse.animateFloat(0.55f, 1f, infiniteRepeatable(tween(850), RepeatMode.Reverse), label = "auto-volume-alpha")
    val alpha = if (paused) .48f else animatedAlpha
    Surface(
        modifier = Modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(999.dp),
        color = Color(0xFF651F2C).copy(alpha = .55f * alpha),
        border = BorderStroke(1.dp, Color(0xFFFF5267).copy(alpha = alpha))
    ) {
        Row(Modifier.padding(horizontal = 8.dp, vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
            SonusAutoVolumeMark(Modifier.size(12.dp), Color(0xFFFF6577))
            Spacer(Modifier.width(3.dp))
            Text(if (paused) "PAUSA" else "AUTO", color = Color(0xFFFF8794).copy(alpha = alpha), fontSize = 8.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun Transport(state:PulsePlayerPlaybackState,accent:Color,cb:InterfaceCallbacks,contentColor:Color=Color.White,large:Boolean=true) {
    val disabled=contentColor.copy(alpha=.28f)
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly,verticalAlignment=Alignment.CenterVertically){
        IconButton(onClick=cb.onShuffle,enabled=!cb.radioMode){Icon(Icons.Default.Shuffle,null,tint=if(cb.radioMode)disabled else if(state.shuffle)accent else contentColor.copy(alpha=.72f))}
        IconButton(onClick=cb.onPrevious,enabled=!cb.radioMode){Icon(Icons.Default.SkipPrevious,null,tint=if(cb.radioMode)disabled else contentColor,modifier=Modifier.size(if(large)34.dp else 28.dp))}
        FilledIconButton(onClick=cb.onToggle,modifier=Modifier.size(if(large)62.dp else 54.dp),colors=IconButtonDefaults.filledIconButtonColors(containerColor=accent,contentColor=Color.Black)){Icon(if(state.playing)Icons.Default.Pause else Icons.Default.PlayArrow,null,modifier=Modifier.size(if(large)36.dp else 31.dp))}
        IconButton(onClick=cb.onNext,enabled=!cb.radioMode){Icon(Icons.Default.SkipNext,null,tint=if(cb.radioMode)disabled else contentColor,modifier=Modifier.size(if(large)34.dp else 28.dp))}
        IconButton(onClick=cb.onRepeat,enabled=!cb.radioMode){Icon(if(state.repeatMode==2)Icons.Default.RepeatOne else Icons.Default.Repeat,null,tint=if(cb.radioMode)disabled else if(state.repeatMode>0)accent else contentColor.copy(alpha=.72f))}
    }
}

@Composable
private fun BottomActions(item:PulsePlayerQueueItem,pinned:Set<String>,accent:Color,cb:InterfaceCallbacks,contentColor:Color=Color.White){
    // Ações compartilhadas: o mesmo conjunto aparece em todos os layouts do player.
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly,verticalAlignment=Alignment.CenterVertically){
        TextButton(onClick=cb.onLyrics, contentPadding=PaddingValues(horizontal=5.dp, vertical=2.dp)) {
            Icon(Icons.Default.Lyrics,null,tint=contentColor.copy(alpha=.82f),modifier=Modifier.size(18.dp))
            Spacer(Modifier.width(3.dp));Text("Letras",color=contentColor.copy(alpha=.82f),fontSize=10.sp)
        }
        IconButton(onClick=cb.onLibrary, modifier=Modifier.size(36.dp)) {
            Icon(Icons.Default.LibraryMusic,"Abrir biblioteca",tint=contentColor.copy(alpha=.88f),modifier=Modifier.size(20.dp))
        }
        IconButton(onClick=cb.onEqualizer, modifier=Modifier.size(36.dp)) {
            Icon(Icons.Default.GraphicEq,"Equalizador",tint=accent,modifier=Modifier.size(21.dp))
        }
        IconButton(onClick={cb.onPin(item.uri)},enabled=!cb.radioMode,modifier=Modifier.size(36.dp)) {
            Icon(Icons.Default.PushPin,"Fixar música",tint=if(cb.radioMode)contentColor.copy(alpha=.28f) else if(item.uri in pinned)accent else contentColor.copy(alpha=.72f),modifier=Modifier.size(19.dp))
        }
    }
}

@Composable
private fun StreamDownloadIconAction(cb: InterfaceCallbacks, contentColor: Color = Color.White) {
    val green = Color(0xFF66D6A3)
    IconButton(
        onClick = cb.onStreamDownload,
        enabled = !cb.streamDownloading,
        modifier = Modifier.size(38.dp)
    ) {
        when {
            cb.streamDownloading -> CircularProgressIndicator(
                progress = { cb.streamDownloadProgress.coerceIn(0f, 1f) },
                modifier = Modifier.size(19.dp),
                color = green,
                trackColor = green.copy(alpha = .18f),
                strokeWidth = 2.dp
            )
            cb.streamDownloaded -> Icon(Icons.Default.DownloadDone, "Remover download offline", tint = green, modifier = Modifier.size(21.dp))
            else -> Icon(Icons.Default.Download, "Baixar música", tint = green.copy(alpha = .92f), modifier = Modifier.size(21.dp))
        }
    }
}

/** Barras padrão SONUS. O State é lido no draw, evitando recompor o restante do player a 60 fps. */
@Composable
private fun Bars(valuesState:State<List<Float>>,colors:List<Color>,modifier:Modifier,mirror:Boolean=false){
    Canvas(modifier){
        val values = valuesState.value
        if(values.isEmpty())return@Canvas
        val safeColors = colors.ifEmpty { listOf(Color.White) }
        val step=size.width/values.size
        values.forEachIndexed{i,v0->
            val v=v0.coerceIn(0f,1f)
            if(v<=.001f)return@forEachIndexed
            val h=(v*(if(mirror)size.height*.46f else size.height-4f)).coerceAtLeast(1.5f)
            val c=safeColors[(i*safeColors.size/values.size).coerceIn(0,safeColors.lastIndex)]
            if(mirror){
                drawRoundRect(c.copy(alpha=.96f),Offset(i*step+step*.18f,size.height/2-h),Size(step*.64f,h),CornerRadius(step*.30f))
                drawRoundRect(c.copy(alpha=.66f),Offset(i*step+step*.18f,size.height/2),Size(step*.64f,h),CornerRadius(step*.30f))
            } else {
                drawRoundRect(c.copy(alpha=.50f+.50f*v),Offset(i*step+step*.18f,size.height-h),Size(step*.64f,h),CornerRadius(step*.30f))
            }
        }
    }
}

@Composable
private fun ReferenceThemePlayer(
    variant: String,
    item: PulsePlayerQueueItem,
    state: PulsePlayerPlaybackState,
    artwork: ImageBitmap?,
    themeColors: List<Color>,
    accent: Color,
    colors: List<Color>,
    spectrum: State<List<Float>>,
    viz: Boolean,
    liked: Set<String>,
    pinned: Set<String>,
    cb: InterfaceCallbacks,
    compact: Boolean,
    modifier: Modifier
) {
    val visual = when (variant) {
        "aurora" -> Triple(Color(0xFF071B35), Color(0xFF0B4C66), RoundedCornerShape(30.dp))
        "sonus_vibe" -> Triple(Color(0xFF071C2E), Color(0xFF123B54), RoundedCornerShape(34.dp))
        "pulse" -> Triple(Color(0xFF080E21), Color(0xFF10294D), RoundedCornerShape(26.dp))
        "spectra" -> Triple(Color(0xFF17102B), Color(0xFF34204F), RoundedCornerShape(22.dp))
        "neon_wave" -> Triple(Color(0xFF071B29), Color(0xFF26314E), RoundedCornerShape(20.dp))
        "deep_blue" -> Triple(Color(0xFF04152F), Color(0xFF0B315E), RoundedCornerShape(32.dp))
        "prism" -> Triple(Color(0xFF170D29), Color(0xFF351A4A), RoundedCornerShape(30.dp))
        "verde_vivo" -> Triple(Color(0xFF071F19), Color(0xFF123C2D), RoundedCornerShape(26.dp))
        "ouro" -> Triple(Color(0xFF17130D), Color(0xFF3A2A15), RoundedCornerShape(18.dp))
        else -> Triple(Color(0xFF05232D), Color(0xFF0B4952), RoundedCornerShape(32.dp))
    }
    val progress = if (state.durationMs > 0L) (state.positionMs.toFloat() / state.durationMs).coerceIn(0f, 1f) else 0f
    val coverSize = when (variant) {
        "sonus_vibe", "deep_blue", "ouro" -> if (compact) 174.dp else 222.dp
        "pulse", "prism", "verde_vivo" -> if (compact) 164.dp else 206.dp
        "spectra" -> if (compact) 150.dp else 184.dp
        else -> if (compact) 168.dp else 210.dp
    }
    val coverShape = when (variant) {
        "sonus_vibe", "ouro" -> CircleShape
        "spectra" -> RoundedCornerShape(13.dp)
        "neon_wave", "mare" -> RoundedCornerShape(24.dp)
        else -> RoundedCornerShape(27.dp)
    }
    val foreground = Color.White
    val accentColors = when (variant) {
        "aurora" -> listOf(Color(0xFF27E3D3), Color(0xFF42B5F5), Color(0xFF7B6CFF))
        "sonus_vibe" -> listOf(Color(0xFF20E8D3), Color(0xFF43B9FF), Color(0xFFAA75FF))
        "pulse" -> listOf(Color(0xFF27C9FF), Color(0xFF2C8DFF), Color(0xFF64E7FF))
        "spectra" -> listOf(Color(0xFFFF5CCB), Color(0xFF9D67FF), Color(0xFF42C7FF), Color(0xFF65E8D2))
        "neon_wave" -> listOf(Color(0xFF22D7FF), Color(0xFFB84EFF), Color(0xFFFF537E))
        "deep_blue" -> listOf(Color(0xFF2879FF), Color(0xFF27D8F2), Color(0xFF6E9EFF))
        "prism" -> listOf(Color(0xFFB45CFF), Color(0xFFFF54BC), Color(0xFF5C8CFF))
        "verde_vivo" -> listOf(Color(0xFF3BE38F), Color(0xFFA4ED56), Color(0xFF22BDAA))
        "ouro" -> listOf(Color(0xFFFFD16B), Color(0xFFC78B35), Color(0xFFFFE8A0))
        else -> listOf(Color(0xFF3FE5D4), Color(0xFF39A8DB), Color(0xFFFFB56C))
    }
    val rotation = rememberRotationState(state.playing, if (variant == "ouro") 12_000 else 18_000)
    Card(modifier, shape=visual.third, colors=CardDefaults.cardColors(containerColor=visual.first), border=BorderStroke(1.dp, accentColors.first().copy(alpha=.56f))) {
        Column(
            Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(visual.first, visual.second, visual.first))).padding(if (compact) 11.dp else 15.dp),
            horizontalAlignment=Alignment.CenterHorizontally,
            verticalArrangement=Arrangement.spacedBy(if (compact) 5.dp else 7.dp)
        ) {
            when (variant) {
                "neon_wave" -> {
                    Box(Modifier.fillMaxWidth().height(if (compact) 150.dp else 188.dp), contentAlignment=Alignment.Center) {
                        ReferenceThemeCanvas(variant, accentColors, spectrum, Modifier.fillMaxSize(), progress)
                        Artwork(artwork, accent, Modifier.fillMaxWidth(.88f).height(if (compact) 124.dp else 158.dp), coverShape)
                    }
                }
                "mare" -> {
                    Box(Modifier.fillMaxWidth().height(if (compact) 145.dp else 178.dp), contentAlignment=Alignment.Center) {
                        ReferenceThemeCanvas(variant, accentColors, spectrum, Modifier.fillMaxSize(), progress)
                        Artwork(artwork, accent, Modifier.fillMaxWidth(.82f).height(if (compact) 112.dp else 140.dp), coverShape)
                    }
                }
                "ouro" -> {
                    Box(Modifier.size(if (compact) 194.dp else 238.dp), contentAlignment=Alignment.Center) {
                        ReferenceThemeCanvas(variant, accentColors, spectrum, Modifier.fillMaxSize().graphicsLayer { rotationZ = rotation.value }, progress)
                        Artwork(artwork, accent, Modifier.fillMaxSize(.62f).graphicsLayer { rotationZ = -rotation.value }, coverShape)
                    }
                }
                "sonus_vibe" -> {
                    Box(Modifier.size(if (compact) 194.dp else 238.dp), contentAlignment=Alignment.Center) {
                        ReferenceThemeCanvas(variant, accentColors, spectrum, Modifier.fillMaxSize(), progress)
                        Artwork(artwork, accent, Modifier.fillMaxSize(.61f), coverShape)
                    }
                }
                "pulse", "prism", "deep_blue" -> {
                    Box(Modifier.size(if (compact) 190.dp else 232.dp), contentAlignment=Alignment.Center) {
                        ReferenceThemeCanvas(variant, accentColors, spectrum, Modifier.fillMaxSize(), progress)
                        Artwork(artwork, accent, Modifier.fillMaxSize(if (variant == "deep_blue") .66f else .72f), coverShape)
                    }
                }
                else -> {
                    Box(Modifier.fillMaxWidth().height(if (compact) 176.dp else 218.dp), contentAlignment=Alignment.Center) {
                        ReferenceThemeCanvas(variant, accentColors, spectrum, Modifier.fillMaxSize(), progress)
                        Artwork(artwork, accent, Modifier.size(coverSize), coverShape)
                    }
                }
            }
            TrackHeader(item, liked, cb.onLike, cb.onStats, foreground)
            if (viz) {
                when (variant) {
                    "spectra" -> Bars(spectrum, accentColors, Modifier.fillMaxWidth().height(if (compact) 35.dp else 44.dp), mirror=true)
                    "pulse" -> ReferenceThemeCanvas("pulse_line", accentColors, spectrum, Modifier.fillMaxWidth().height(34.dp), progress)
                    "mare" -> ReferenceThemeCanvas("mare", accentColors, spectrum, Modifier.fillMaxWidth().height(32.dp), progress)
                    else -> Bars(spectrum, accentColors, Modifier.fillMaxWidth(.84f).height(if (compact) 32.dp else 40.dp), mirror=variant == "aurora" || variant == "neon_wave")
                }
            } else Spacer(Modifier.height(if (compact) 32.dp else 40.dp))
            Spacer(Modifier.weight(1f, fill=true))
            ProgressRow(state, accentColors.first(), cb.onSeek, foreground, cb=cb)
            Transport(state, accentColors.first(), cb, foreground, large=!compact)
            BottomActions(item, pinned, accentColors.first(), cb, foreground)
        }
    }
}

@Composable
private fun ReferenceThemeCanvas(
    variant: String,
    colors: List<Color>,
    spectrum: State<List<Float>>,
    modifier: Modifier,
    progress: Float
) {
    Canvas(modifier) {
        val safe = colors.ifEmpty { listOf(Color.Cyan) }
        val w = size.width
        val h = size.height
        when (variant) {
            "aurora" -> {
                for (i in 0..3) {
                    val path = Path()
                    val y = h * (.22f + i * .17f)
                    path.moveTo(0f, y)
                    path.cubicTo(w * .25f, y - h * .23f, w * .55f, y + h * .20f, w, y - h * .08f)
                    drawPath(path, Brush.horizontalGradient(safe), style=Stroke((3 + i).dp.toPx(), cap=StrokeCap.Round), alpha=.16f + i * .04f)
                }
                drawCircle(Brush.radialGradient(listOf(safe.first().copy(alpha=.30f), Color.Transparent)), radius=w*.45f, center=Offset(w*.5f,h*.48f))
            }
            "sonus_vibe" -> {
                val center=Offset(w/2f,h/2f)
                for (i in 1..6) drawCircle(safe[(i-1)%safe.size].copy(alpha=.11f), radius=w*(.20f+i*.065f), center=center, style=Stroke((1.4f+i*.12f).dp.toPx()))
                val vals=spectrum.value
                for (i in vals.indices) {
                    val angle=(i.toFloat()/vals.size)*2f*PI.toFloat()
                    val r0=w*.42f; val r1=r0+vals[i].coerceIn(0f,1f)*w*.07f
                    drawLine(safe[i%safe.size], Offset(center.x+cos(angle)*r0,center.y+sin(angle)*r0), Offset(center.x+cos(angle)*r1,center.y+sin(angle)*r1), 2.dp.toPx(), cap=StrokeCap.Round)
                }
            }
            "pulse" -> {
                val center=Offset(w/2f,h/2f)
                for (i in 0..2) drawCircle(safe[i%safe.size].copy(alpha=.22f-i*.045f), radius=w*(.34f+i*.09f), center=center, style=Stroke((2-i*.3f).dp.toPx()))
                val path=Path(); path.moveTo(0f,h*.55f); path.lineTo(w*.25f,h*.55f); path.lineTo(w*.34f,h*.55f); path.lineTo(w*.40f,h*.28f); path.lineTo(w*.47f,h*.82f); path.lineTo(w*.54f,h*.44f); path.lineTo(w*.62f,h*.55f); path.lineTo(w,h*.55f)
                drawPath(path, safe.first(), style=Stroke(2.dp.toPx(),cap=StrokeCap.Round), alpha=.62f)
            }
            "spectra" -> {
                val vals=spectrum.value
                val step=w/vals.size.coerceAtLeast(1)
                vals.forEachIndexed { i,v ->
                    val bar=(v.coerceIn(0f,1f)*h*.62f).coerceAtLeast(2.dp.toPx())
                    drawRoundRect(safe[i%safe.size].copy(alpha=.30f+.55f*v.coerceIn(0f,1f)), Offset(i*step+step*.20f,h*.48f-bar), Size(step*.58f,bar*2f), CornerRadius(step*.3f))
                }
                drawRoundRect(Brush.horizontalGradient(safe), Offset(w*.06f,h*.12f), Size(w*.88f,h*.76f), CornerRadius(26.dp.toPx()), style=Stroke(1.2.dp.toPx()), alpha=.44f)
            }
            "neon_wave" -> {
                for (i in 0..5) {
                    val y=h*(.15f+i*.14f)
                    val path=Path().apply { moveTo(0f,y); cubicTo(w*.25f,y-h*.17f,w*.55f,y+h*.20f,w,y-h*.10f) }
                    drawPath(path, Brush.horizontalGradient(safe), style=Stroke((2+i*.25f).dp.toPx(),cap=StrokeCap.Round), alpha=.34f-i*.035f)
                }
            }
            "deep_blue" -> {
                val c=Offset(w/2f,h/2f)
                drawCircle(Brush.radialGradient(listOf(safe[1 % safe.size].copy(alpha=.34f), safe.first().copy(alpha=.12f), Color.Transparent), center=c, radius=w*.56f), radius=w*.55f, center=c)
                for(i in 1..5) drawCircle(safe.first().copy(alpha=.16f-i*.02f), radius=w*(.28f+i*.07f), center=c, style=Stroke(1.2.dp.toPx()))
            }
            "prism" -> {
                val rect=androidx.compose.ui.geometry.Size(w*.86f,h*.86f)
                val top=Offset(w*.07f,h*.07f)
                for(i in 0..4) drawArc(Brush.sweepGradient(safe), 205f+i*12f, 135f, false, top, rect, style=Stroke((2.5f+i*.35f).dp.toPx(),cap=StrokeCap.Round), alpha=.72f-i*.09f)
            }
            "verde_vivo" -> {
                for(i in 0..6) {
                    val x=w*(.10f+i*.13f)
                    val path=Path().apply { moveTo(x,h); cubicTo(x-w*.20f,h*.63f,x+w*.20f,h*.37f,x+w*.02f,0f) }
                    drawPath(path, safe[i%safe.size].copy(alpha=.17f), style=Stroke((2.5f+i*.15f).dp.toPx(),cap=StrokeCap.Round))
                }
                drawCircle(Brush.radialGradient(listOf(safe.first().copy(alpha=.22f),Color.Transparent)),radius=w*.48f,center=Offset(w*.5f,h*.5f))
            }
            "ouro" -> {
                val c=Offset(w/2f,h/2f)
                drawCircle(Brush.sweepGradient(safe),radius=w*.48f,center=c,style=Stroke(5.dp.toPx()))
                for(i in 1..8) drawCircle(Color(0xFFFFD98A).copy(alpha=.10f),radius=w*(.18f+i*.032f),center=c,style=Stroke(1.dp.toPx()))
                drawArc(safe.first(),-90f,360f*progress,false,style=Stroke(3.dp.toPx(),cap=StrokeCap.Round))
            }
            "mare" -> {
                drawRect(Brush.verticalGradient(listOf(Color(0xFF164858),Color(0xFF09252E),Color(0xFF061B28))))
                drawCircle(Color(0xFFFFB66F).copy(alpha=.8f),radius=h*.14f,center=Offset(w*.72f,h*.30f))
                for(i in 0..5) {
                    val y=h*(.58f+i*.075f)
                    val path=Path().apply { moveTo(0f,y); cubicTo(w*.24f,y-h*.09f,w*.45f,y+h*.07f,w*.68f,y); cubicTo(w*.83f,y-h*.08f,w*.92f,y+h*.08f,w,y-h*.01f) }
                    drawPath(path, safe[i%safe.size].copy(alpha=.36f-i*.035f), style=Stroke((1.5f+i*.18f).dp.toPx(),cap=StrokeCap.Round))
                }
            }
            "pulse_line" -> {
                val path=Path(); path.moveTo(0f,h*.58f); path.lineTo(w*.26f,h*.58f); path.lineTo(w*.34f,h*.58f); path.lineTo(w*.40f,h*.14f); path.lineTo(w*.47f,h*.90f); path.lineTo(w*.54f,h*.43f); path.lineTo(w*.63f,h*.58f); path.lineTo(w,h*.58f)
                drawPath(path, Brush.horizontalGradient(safe), style=Stroke(2.6.dp.toPx(),cap=StrokeCap.Round))
            }
        }
    }
}

@Composable
private fun ClassicPlayer(item:PulsePlayerQueueItem,state:PulsePlayerPlaybackState,artwork:ImageBitmap?,accent:Color,colors:List<Color>,spectrum:State<List<Float>>,viz:Boolean,liked:Set<String>,pinned:Set<String>,cb:InterfaceCallbacks,compact:Boolean,modifier:Modifier){
    Card(modifier,colors=CardDefaults.cardColors(containerColor=Color.Black.copy(alpha=.32f)),border=BorderStroke(1.dp,accent.copy(alpha=.32f))){
        Column(Modifier.fillMaxSize().padding(if(compact)9.dp else 12.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(if(compact)3.dp else 6.dp)){
            Artwork(artwork,accent,Modifier.size(if(compact)184.dp else 246.dp),RoundedCornerShape(26.dp))
            Text(item.title,fontWeight=FontWeight.Black,fontSize=if(compact)17.sp else 19.sp,maxLines=1,overflow=TextOverflow.Ellipsis,color=Color.White)
            Text(item.artist.ifBlank{"Artista desconhecido"},fontSize=13.sp,maxLines=1,overflow=TextOverflow.Ellipsis,color=Color.White.copy(alpha=.72f))
            Spacer(Modifier.height(if(compact)2.dp else 5.dp))
            if(viz) Bars(spectrum,colors,Modifier.fillMaxWidth().height(if(compact)58.dp else 70.dp),mirror=true) else Spacer(Modifier.height(if(compact)58.dp else 70.dp))
            ProgressRow(state,accent,cb.onSeek,cb=cb)
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.Center) {
                IconButton(onClick={cb.onLike(item.uri)}) {
                    Icon(if(item.uri in liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null,
                        tint=if(item.uri in liked) Color(0xFFFF5F82) else Color.White)
                }
            }
            // Transporte compartilhado: todos os layouts mantêm os mesmos botões e ações,
            // inclusive a Biblioteca na posição definida após o botão Próxima.
            Transport(state, accent, cb, large = !compact)
            BottomActions(item,pinned,accent,cb)
        }
    }
}

@Composable
private fun PurePlayer(item:PulsePlayerQueueItem,state:PulsePlayerPlaybackState,artwork:ImageBitmap?,accent:Color,colors:List<Color>,spectrum:State<List<Float>>,viz:Boolean,liked:Set<String>,pinned:Set<String>,cb:InterfaceCallbacks,compact:Boolean,modifier:Modifier){
    Card(modifier,colors=CardDefaults.cardColors(containerColor=Color.Black.copy(alpha=.23f)),shape=RoundedCornerShape(28.dp)){
        Column(Modifier.fillMaxSize().padding(if(compact)12.dp else 18.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(8.dp)){
            Artwork(artwork,accent,Modifier.size(if(compact)180.dp else 250.dp),CircleShape)
            TrackHeader(item,liked,cb.onLike,cb.onStats)
            if(viz) Bars(spectrum,colors,Modifier.fillMaxWidth(.84f).height(if(compact)38.dp else 46.dp)) else Spacer(Modifier.height(if(compact)38.dp else 46.dp))
            Spacer(Modifier.weight(1f))
            ProgressRow(state,accent,cb.onSeek,cb=cb)
            Transport(state,accent,cb)
            BottomActions(item,pinned,accent,cb)
        }
    }
}

@Composable
private fun FlowPlayer(item:PulsePlayerQueueItem,state:PulsePlayerPlaybackState,artwork:ImageBitmap?,themeColors:List<Color>,accent:Color,colors:List<Color>,spectrum:State<List<Float>>,viz:Boolean,liked:Set<String>,pinned:Set<String>,cb:InterfaceCallbacks,compact:Boolean,modifier:Modifier){
    val gradient=(themeColors+accent.copy(alpha=.7f)).takeLast(4).ifEmpty { listOf(Color.Black,accent) }
    Card(modifier,shape=RoundedCornerShape(28.dp),colors=CardDefaults.cardColors(containerColor=Color.Transparent)){
        Column(Modifier.fillMaxSize().background(Brush.verticalGradient(gradient)).padding(if(compact)12.dp else 16.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(7.dp)){
            Text("NOW PLAYING",fontSize=10.sp,fontWeight=FontWeight.Black,letterSpacing=2.sp,color=Color.White.copy(alpha=.78f))
            Artwork(artwork,accent,Modifier.size(if(compact)165.dp else 225.dp),CircleShape)
            TrackHeader(item,liked,cb.onLike,cb.onStats)
            if(viz) Bars(spectrum,colors,Modifier.fillMaxWidth(.82f).height(if(compact)42.dp else 50.dp)) else Spacer(Modifier.height(if(compact)42.dp else 50.dp))
            Spacer(Modifier.weight(1f))
            Transport(state,Color.White,cb)
            ProgressRow(state,Color.White,cb.onSeek,cb=cb)
            BottomActions(item,pinned,Color.White,cb)
        }
    }
}

@Composable
private fun OrbitDisc(artwork:ImageBitmap?,accent:Color,progress:Float,rotation:State<Float>,modifier:Modifier,neon:Boolean=false){
    Box(modifier,contentAlignment=Alignment.Center){
        Canvas(Modifier.fillMaxSize()){
            val stroke=size.minDimension*.035f
            drawCircle(Color.Black.copy(alpha=.72f),radius=size.minDimension*.43f)
            for(i in 1..7)drawCircle(Color.White.copy(alpha=.035f),radius=size.minDimension*(.20f+i*.03f),style=Stroke(1f))
            drawArc(Color.White.copy(alpha=.18f),-90f,360f,false,style=Stroke(stroke,cap=StrokeCap.Round))
            drawArc(if(neon)Brush.sweepGradient(listOf(accent,Color.Magenta,Color.Cyan,accent)) else SolidColor(accent),-90f,360f*progress,false,style=Stroke(stroke,cap=StrokeCap.Round))
        }
        Artwork(artwork,accent,Modifier.fillMaxSize(.58f).graphicsLayer { rotationZ=rotation.value },CircleShape)
        Surface(Modifier.size(18.dp),CircleShape,color=Color(0xFF0B0D12),border=BorderStroke(2.dp,accent.copy(alpha=.7f))){}
    }
}

@Composable
private fun OrbitPlayer(item:PulsePlayerQueueItem,state:PulsePlayerPlaybackState,artwork:ImageBitmap?,accent:Color,colors:List<Color>,spectrum:State<List<Float>>,viz:Boolean,liked:Set<String>,pinned:Set<String>,cb:InterfaceCallbacks,compact:Boolean,modifier:Modifier){
    val rotation=rememberRotationState(state.playing,9000)
    val progress=if(state.durationMs>0)(state.positionMs.toFloat()/state.durationMs).coerceIn(0f,1f)else 0f
    Card(modifier,colors=CardDefaults.cardColors(containerColor=Color(0xFF11151B).copy(alpha=.88f)),shape=RoundedCornerShape(30.dp)){
        Column(Modifier.fillMaxSize().padding(if(compact)12.dp else 16.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(7.dp)){
            OrbitDisc(artwork,accent,progress,rotation,Modifier.size(if(compact)190.dp else 270.dp))
            TrackHeader(item,liked,cb.onLike,cb.onStats)
            if(viz) Bars(spectrum,colors,Modifier.fillMaxWidth(.74f).height(if(compact)34.dp else 42.dp)) else Spacer(Modifier.height(if(compact)34.dp else 42.dp))
            Spacer(Modifier.weight(1f));Transport(state,accent,cb);ProgressRow(state,accent,cb.onSeek,cb=cb);BottomActions(item,pinned,accent,cb)
        }
    }
}

@Composable
private fun VinylGlowPlayer(item:PulsePlayerQueueItem,state:PulsePlayerPlaybackState,artwork:ImageBitmap?,accent:Color,colors:List<Color>,spectrum:State<List<Float>>,viz:Boolean,liked:Set<String>,pinned:Set<String>,cb:InterfaceCallbacks,compact:Boolean,modifier:Modifier){
    val rotation=rememberRotationState(state.playing,6500)
    Card(modifier,colors=CardDefaults.cardColors(containerColor=Color.Black.copy(alpha=.38f)),shape=RoundedCornerShape(28.dp),border=BorderStroke(1.dp,accent.copy(alpha=.4f))){
        Column(Modifier.fillMaxSize().padding(if(compact)10.dp else 14.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(6.dp)){
            TrackHeader(item,liked,cb.onLike,cb.onStats)
            Box(Modifier.size(if(compact)192.dp else 264.dp),contentAlignment=Alignment.Center){
                Canvas(Modifier.fillMaxSize()){
                    drawCircle(Brush.radialGradient(listOf(Color(0xFF17191E),Color.Black)),radius=size.minDimension*.48f)
                    repeat(12){i->drawCircle(Color.White.copy(alpha=.025f),radius=size.minDimension*(.16f+i*.026f),style=Stroke(1f))}
                    drawCircle(accent.copy(alpha=.20f),radius=size.minDimension*.50f,style=Stroke(8f))
                }
                // code68: a capa deixa de ser um selo minúsculo e preenche visualmente o centro do disco.
                Artwork(artwork,accent,Modifier.fillMaxSize(.58f).graphicsLayer { rotationZ=rotation.value },CircleShape)
                Surface(Modifier.size(15.dp),CircleShape,color=Color(0xFF0B0D12),border=BorderStroke(1.5.dp,accent.copy(alpha=.7f))){}
            }
            Spacer(Modifier.height(if(compact)5.dp else 10.dp))
            if(viz) Bars(spectrum,colors,Modifier.fillMaxWidth(.84f).height(if(compact)42.dp else 52.dp),mirror=true) else Spacer(Modifier.height(if(compact)42.dp else 52.dp))
            Spacer(Modifier.weight(1f));ProgressRow(state,accent,cb.onSeek,cb=cb);Transport(state,accent,cb);BottomActions(item,pinned,accent,cb)
        }
    }
}

@Composable
private fun NeonDiscPlayer(item:PulsePlayerQueueItem,state:PulsePlayerPlaybackState,artwork:ImageBitmap?,accent:Color,colors:List<Color>,spectrum:State<List<Float>>,viz:Boolean,liked:Set<String>,pinned:Set<String>,cb:InterfaceCallbacks,compact:Boolean,modifier:Modifier){
    val rotation=rememberRotationState(state.playing,11000)
    val safeColors=colors.ifEmpty{listOf(accent)}
    Card(modifier,colors=CardDefaults.cardColors(containerColor=Color.Black.copy(alpha=.30f)),shape=RoundedCornerShape(30.dp)){
        Column(Modifier.fillMaxSize().padding(if(compact)10.dp else 15.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(8.dp)){
            Box(Modifier.size(if(compact)190.dp else 270.dp),contentAlignment=Alignment.Center){
                Canvas(Modifier.fillMaxSize()){
                    drawCircle(Brush.radialGradient(listOf(accent.copy(alpha=.30f),Color(0xFF101322),Color.Black)),radius=size.minDimension*.48f)
                    drawCircle(Brush.sweepGradient(safeColors+safeColors.first()),radius=size.minDimension*.48f,style=Stroke(7f))
                }
                Artwork(artwork,accent,Modifier.fillMaxSize(.74f).graphicsLayer { rotationZ=rotation.value },CircleShape)
                if(viz)Bars(spectrum,safeColors,Modifier.fillMaxWidth(.66f).height(if(compact)66.dp else 82.dp),mirror=true)
            }
            TrackHeader(item,liked,cb.onLike,cb.onStats);Spacer(Modifier.weight(1f));ProgressRow(state,accent,cb.onSeek,cb=cb);Transport(state,accent,cb);BottomActions(item,pinned,accent,cb)
        }
    }
}

private data class CassetteSkin(
    val name:String,
    val body:Color,
    val frame:Color,
    val label:Color,
    val band:Color,
    val ink:Color,
    val window:Color,
    val metal:Color
)

private val CassetteSkins=listOf(
    CassetteSkin("Blue Red",Color(0xFF7286E8),Color(0xFF5C67A9),Color(0xFFE8E7E0),Color(0xFFFF2727),Color(0xFF18202A),Color(0xFF4C5159),Color(0xFFC7CDD1)),
    CassetteSkin("Red Black",Color(0xFFC9D0D2),Color(0xFF7C888D),Color(0xFFFF1F17),Color(0xFF080808),Color(0xFF111111),Color(0xFFC8D0D3),Color(0xFFB9C2C5)),
    CassetteSkin("Cream Pop",Color(0xFFF0251B),Color(0xFFB51B15),Color(0xFFFFF5D5),Color(0xFF2D7099),Color(0xFF34383B),Color(0xFFE5E6E1),Color(0xFFBEC6C8)),
    CassetteSkin("Black Red",Color(0xFF303234),Color(0xFF141516),Color(0xFFF4F4F2),Color(0xFFFF2525),Color(0xFF111111),Color(0xFF111214),Color(0xFFD4D7D8)),
    CassetteSkin("Blue Yellow",Color(0xFF0A5E9B),Color(0xFF074B7C),Color(0xFFF1F1E8),Color(0xFFFFD20A),Color(0xFF163044),Color(0xFF152433),Color(0xFFC7CFD3)),
    CassetteSkin("Silver Pink",Color(0xFF787878),Color(0xFF4D4D4D),Color(0xFFE8E8E8),Color(0xFFFF00C7),Color(0xFF292929),Color(0xFF55585B),Color(0xFFC9CCCE))
)

private data class ReelMotion(val left:State<Float>,val right:State<Float>)

@Composable
private fun rememberCassetteReels(playing:Boolean,progress:Float):ReelMotion{
    val left=remember{mutableFloatStateOf(0f)}
    val right=remember{mutableFloatStateOf(0f)}
    val latestPlaying by rememberUpdatedState(playing)
    val latestProgress by rememberUpdatedState(progress.coerceIn(0f,1f))
    LaunchedEffect(Unit){
        var previous=0L
        while(isActive){
            val now=withFrameNanos{it}
            if(previous!=0L && latestPlaying){
                val dt=(now-previous).coerceIn(0L,50_000_000L)/1_000_000_000f
                val leftFill=(.12f+(1f-latestProgress)*.82f).coerceIn(.12f,.94f)
                val rightFill=(.12f+latestProgress*.82f).coerceIn(.12f,.94f)
                // Menos fita = menor raio = rotação angular maior, como em um cassete real.
                val leftSpeed=205f/sqrt(leftFill)
                val rightSpeed=205f/sqrt(rightFill)
                left.floatValue=(left.floatValue+leftSpeed*dt)%360f
                right.floatValue=(right.floatValue+rightSpeed*dt)%360f
            }
            previous=now
        }
    }
    return ReelMotion(left,right)
}

@Composable
private fun CassettePlayer(item:PulsePlayerQueueItem,state:PulsePlayerPlaybackState,artwork:ImageBitmap?,accent:Color,colors:List<Color>,spectrum:State<List<Float>>,viz:Boolean,liked:Set<String>,pinned:Set<String>,cb:InterfaceCallbacks,compact:Boolean,modifier:Modifier){
    val context=LocalContext.current
    val prefs=remember{context.getSharedPreferences("sonus_player_interface_quick_v1",Context.MODE_PRIVATE)}
    var skinIndex by remember{mutableIntStateOf(prefs.getInt("cassette_skin",0).coerceIn(0,CassetteSkins.lastIndex))}
    val skin=CassetteSkins[skinIndex]
    val progress=if(state.durationMs>0)(state.positionMs.toFloat()/state.durationMs).coerceIn(0f,1f)else 0f
    val motion=rememberCassetteReels(state.playing,progress)
    Card(modifier,colors=CardDefaults.cardColors(containerColor=Color(0xFF111417)),shape=RoundedCornerShape(22.dp),border=BorderStroke(1.dp,Color.White.copy(alpha=.10f))){
        Column(Modifier.fillMaxSize().padding(if(compact)8.dp else 12.dp),verticalArrangement=Arrangement.spacedBy(if(compact)5.dp else 7.dp)){
            Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
                Column(Modifier.weight(1f)){
                    Text("CASSETTE RETRO",fontSize=10.sp,fontWeight=FontWeight.Black,letterSpacing=1.5.sp,color=Color.White.copy(alpha=.82f))
                    Text("${skin.name} • ${skinIndex+1}/${CassetteSkins.size}",fontSize=10.sp,color=Color.White.copy(alpha=.58f))
                }
                FilledTonalIconButton(onClick={skinIndex=(skinIndex+1)%CassetteSkins.size;prefs.edit().putInt("cassette_skin",skinIndex).apply()},colors=IconButtonDefaults.filledTonalIconButtonColors(containerColor=Color.White.copy(alpha=.08f),contentColor=Color.White)){
                    Icon(Icons.Default.SwapHoriz,"Trocar modelo de fita")
                }
            }
            StereoVu(spectrum,colors,viz,Modifier.fillMaxWidth().height(if(compact)44.dp else 58.dp))
            CassetteBody(item,artwork,accent,skin,motion,progress,Modifier.fillMaxWidth().weight(1f))
            TrackHeader(item,liked,cb.onLike,cb.onStats,Color.White)
            ProgressRow(state,accent,cb.onSeek,cb=cb)
            Transport(state,accent,cb)
            BottomActions(item,pinned,accent,cb)
        }
    }
}

@Composable
private fun StereoVu(valuesState:State<List<Float>>,colors:List<Color>,enabled:Boolean,modifier:Modifier){
    Canvas(modifier.background(Color(0xFF07090B),RoundedCornerShape(9.dp)).border(1.dp,Color.White.copy(alpha=.14f),RoundedCornerShape(9.dp))){
        val values=valuesState.value
        val safe=if(enabled)values else emptyList()
        val palette=colors.ifEmpty { listOf(Color(0xFF83EF43)) }
        fun level(start:Int,end:Int):Float{
            if(safe.isEmpty())return 0f
            val a=start.coerceIn(0,safe.lastIndex);val b=end.coerceIn(a+1,safe.size)
            val slice=safe.subList(a,b)
            val rms=sqrt(slice.map{it*it}.average().toFloat())
            val peak=slice.maxOrNull()?:0f
            return (rms*1.10f+peak*.32f).coerceIn(0f,1f)
        }
        val split=(safe.size/2).coerceAtLeast(1)
        val left=if(safe.isEmpty())0f else level(0,split)
        val right=if(safe.isEmpty())0f else level(split.coerceAtMost(safe.lastIndex),safe.size)
        val meters=listOf(left,right)
        val labels=listOf("L","R")
        val segments=22
        val labelW=size.width*.065f
        val usable=size.width-labelW-size.width*.035f
        val step=usable/segments
        meters.forEachIndexed{row,level->
            val cy=size.height*(if(row==0).34f else .72f)
            // Pequeno traço L/R no lugar de texto evita dependência de Paint/Typeface na Canvas Compose.
            drawLine(Color.White.copy(alpha=.72f),Offset(size.width*.025f,cy-5f),Offset(size.width*.025f,cy+5f),2.2f)
            if(labels[row]=="R")drawLine(Color.White.copy(alpha=.72f),Offset(size.width*.018f,cy-5f),Offset(size.width*.034f,cy-5f),2f)
            repeat(segments){i->
                val active=i < (level*segments).toInt().coerceIn(0,segments)
                val c=when{ i>=19->Color(0xFFFF3D45);i>=15->Color(0xFFFFC02E);else->palette[i%palette.size]}
                drawRoundRect(if(active)c else Color(0xFF22272C),Offset(labelW+i*step,cy-size.height*.055f),Size(step*.70f,size.height*.11f),CornerRadius(2.4f))
            }
            val peakPos=(level*segments).toInt().coerceIn(0,segments-1)
            if(level>.08f)drawRoundRect(Color.White.copy(alpha=.72f),Offset(labelW+peakPos*step,cy-size.height*.073f),Size(step*.54f,2f),CornerRadius(1f))
        }
    }
}

@Composable
private fun CassetteBody(item:PulsePlayerQueueItem,artwork:ImageBitmap?,accent:Color,skin:CassetteSkin,motion:ReelMotion,progress:Float,modifier:Modifier){
    val leftFill=(.12f+(1f-progress)*.82f).coerceIn(.12f,.94f)
    val rightFill=(.12f+progress*.82f).coerceIn(.12f,.94f)
    Box(modifier.background(skin.body,RoundedCornerShape(18.dp)).border(2.dp,skin.frame,RoundedCornerShape(18.dp)),contentAlignment=Alignment.Center){
        // Parafusos e detalhes externos deixam a silhueta reconhecível mesmo nos seis skins.
        Canvas(Modifier.fillMaxSize()){
            val r=size.minDimension*.020f
            listOf(Offset(size.width*.055f,size.height*.07f),Offset(size.width*.945f,size.height*.07f),Offset(size.width*.065f,size.height*.90f),Offset(size.width*.935f,size.height*.90f)).forEach{drawCircle(Color.Black.copy(alpha=.82f),r,it)}
            drawRoundRect(skin.band,Offset(size.width*.055f,size.height*.18f),Size(size.width*.89f,size.height*.12f),CornerRadius(5f))
        }
        Column(Modifier.fillMaxSize().padding(horizontal=12.dp,vertical=10.dp),horizontalAlignment=Alignment.CenterHorizontally){
            Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
                Text("SONUS",fontWeight=FontWeight.Black,color=skin.ink,fontSize=11.sp,letterSpacing=1.1.sp)
                Spacer(Modifier.weight(1f))
                Text("C-90 • SIDE A",fontWeight=FontWeight.Black,color=skin.ink.copy(alpha=.86f),fontSize=9.sp)
            }
            Spacer(Modifier.height(9.dp))
            Surface(color=skin.label,shape=RoundedCornerShape(10.dp),modifier=Modifier.fillMaxWidth().weight(1f),border=BorderStroke(1.dp,skin.frame.copy(alpha=.50f))){
                Column(Modifier.padding(horizontal=8.dp,vertical=7.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(5.dp)){
                    Text(item.title,maxLines=1,overflow=TextOverflow.Ellipsis,color=skin.ink,fontWeight=FontWeight.Black,fontSize=11.sp)
                    Text(item.artist.ifBlank{"SONUS PLAYER"},maxLines=1,overflow=TextOverflow.Ellipsis,color=skin.ink.copy(alpha=.72f),fontWeight=FontWeight.SemiBold,fontSize=9.sp)
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly,verticalAlignment=Alignment.CenterVertically){
                        Reel(motion.left,leftFill,skin,accent,62.dp)
                        // A arte vira parte da etiqueta, grande o bastante para ser reconhecida.
                        Box(Modifier.weight(1f).padding(horizontal=8.dp).height(72.dp).background(skin.window,RoundedCornerShape(10.dp)).border(1.dp,skin.frame.copy(alpha=.7f),RoundedCornerShape(10.dp)),contentAlignment=Alignment.Center){
                            Artwork(artwork,accent,Modifier.fillMaxSize().padding(5.dp),RoundedCornerShape(7.dp))
                        }
                        Reel(motion.right,rightFill,skin,accent,62.dp)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            // Janela/guia inferior típica de fita compacta.
            Canvas(Modifier.fillMaxWidth(.78f).height(44.dp)){
                val p=Path().apply{moveTo(size.width*.10f,size.height);lineTo(size.width*.20f,0f);lineTo(size.width*.80f,0f);lineTo(size.width*.90f,size.height);close()}
                drawPath(p,skin.frame.copy(alpha=.90f))
                drawLine(skin.metal,Offset(size.width*.20f,4f),Offset(size.width*.80f,4f),4f,StrokeCap.Round)
                drawCircle(Color.Black.copy(alpha=.72f),5.5f,Offset(size.width*.28f,size.height*.56f))
                drawCircle(Color.Black.copy(alpha=.72f),5.5f,Offset(size.width*.72f,size.height*.56f))
            }
        }
    }
}

@Composable
private fun Reel(rotation:State<Float>,fill:Float,skin:CassetteSkin,accent:Color,sizeDp:androidx.compose.ui.unit.Dp){
    Canvas(Modifier.size(sizeDp).graphicsLayer { rotationZ=rotation.value }){
        // A massa de fita cresce/diminui junto com o progresso.
        val tapeRadius=size.minDimension*(.27f+.18f*fill.coerceIn(0f,1f))
        drawCircle(Color(0xFF2A211C),radius=tapeRadius)
        drawCircle(skin.metal,radius=size.minDimension*.27f)
        drawCircle(skin.window.copy(alpha=.92f),radius=size.minDimension*.19f)
        repeat(6){i->
            val a=i*PI/3
            val c=Offset(center.x+cos(a).toFloat()*size.minDimension*.135f,center.y+sin(a).toFloat()*size.minDimension*.135f)
            drawCircle(skin.ink.copy(alpha=.78f),size.minDimension*.050f,c)
        }
        drawCircle(accent.copy(alpha=.92f),radius=size.minDimension*.055f)
    }
}

@Composable
private fun TurntablePlayer(item:PulsePlayerQueueItem,state:PulsePlayerPlaybackState,artwork:ImageBitmap?,accent:Color,colors:List<Color>,spectrum:State<List<Float>>,viz:Boolean,liked:Set<String>,pinned:Set<String>,cb:InterfaceCallbacks,compact:Boolean,modifier:Modifier){
    val rotation=rememberRotationState(state.playing,5200)
    val progress=if(state.durationMs>0)(state.positionMs.toFloat()/state.durationMs).coerceIn(0f,1f)else 0f
    Card(modifier,colors=CardDefaults.cardColors(containerColor=Color(0xFF171A1F)),shape=RoundedCornerShape(24.dp)){
        Column(Modifier.fillMaxSize().padding(if(compact)9.dp else 12.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){
            Box(Modifier.fillMaxWidth().weight(1f).background(Brush.linearGradient(listOf(Color(0xFF34291F),Color(0xFFE6DED2),Color(0xFF263342))),RoundedCornerShape(18.dp))){
                Box(Modifier.fillMaxSize().padding(10.dp)){
                    Box(Modifier.fillMaxHeight(.82f).aspectRatio(1f).align(Alignment.CenterStart),contentAlignment=Alignment.Center){
                        Canvas(Modifier.fillMaxSize().graphicsLayer { rotationZ=rotation.value }){drawCircle(Color.Black);repeat(14){i->drawCircle(Color.White.copy(alpha=.025f),radius=size.minDimension*(.16f+i*.022f),style=Stroke(1f))};drawCircle(accent.copy(alpha=.18f),radius=size.minDimension*.48f,style=Stroke(5f))}
                        Artwork(artwork,accent,Modifier.fillMaxSize(.34f).graphicsLayer { rotationZ=rotation.value },CircleShape)
                    }
                    ToneArm(state.current!=null,progress,Modifier.fillMaxHeight(.78f).fillMaxWidth(.42f).align(Alignment.TopEnd))
                    if(viz) StereoVu(spectrum,colors,true,Modifier.fillMaxWidth(.43f).height(if(compact)38.dp else 44.dp).align(Alignment.BottomEnd))
                }
            }
            TrackHeader(item,liked,cb.onLike,cb.onStats);ProgressRow(state,accent,cb.onSeek,cb=cb);Transport(state,accent,cb);BottomActions(item,pinned,accent,cb)
        }
    }
}

@Composable
private fun ToneArm(hasTrack:Boolean,progress:Float,modifier:Modifier){
    // Em Pause o braço permanece sobre o sulco atual; só o prato para.
    val target=if(hasTrack)16f+progress.coerceIn(0f,1f)*10f else 0f
    val angle by androidx.compose.animation.core.animateFloatAsState(targetValue=target,animationSpec=tween(420),label="tonearm")
    Canvas(modifier.graphicsLayer(rotationZ=angle,transformOrigin=TransformOrigin(.82f,.12f))){
        val pivot=Offset(size.width*.82f,size.height*.12f)
        drawCircle(Color(0xFFBFC5CA),size.width*.14f,pivot);drawCircle(Color(0xFF34383D),size.width*.08f,pivot)
        val end=Offset(size.width*.25f,size.height*.85f);drawLine(Color(0xFFD2D5D8),pivot,end,8f,StrokeCap.Round);drawLine(Color(0xFF22262A),end,Offset(end.x-15f,end.y+18f),10f,StrokeCap.Round)
    }
}

private fun clock(ms:Long):String{val total=(ms/1000).coerceAtLeast(0);return "%d:%02d".format(total/60,total%60)}
