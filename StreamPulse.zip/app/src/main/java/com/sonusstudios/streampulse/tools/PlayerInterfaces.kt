package com.sonusstudios.streampulse.tools

import android.content.Context
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonusstudios.streampulse.core.MembershipTier
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.isActive
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.roundToInt

/**
 * Interfaces visuais do SONUS PLAYER. Elas alteram somente a apresentação do player:
 * transporte, fila, áudio, temas e regras de reprodução continuam compartilhados.
 *
 * code68: todas as visualizações usam o mesmo motor visual SONUS, alimentado pelo PCM Media3.
 */
private val LocalSonusStreamPlayCount = staticCompositionLocalOf<Long?> { null }

internal data class PlayerInterfaceSpec(
    val id: String,
    val name: String,
    val tier: MembershipTier,
    val description: String,
    val badge: String
)

internal val PulsePlayerInterfaces = listOf(
    PlayerInterfaceSpec("classic", "SONUS Classic", MembershipTier.FREE, "Interface original do SONUS, limpa e completa.", "FREE"),
    PlayerInterfaceSpec("pure", "Pure", MembershipTier.FREE, "Minimalista, leve e focada na capa.", "GRÁTIS"),
    PlayerInterfaceSpec("flow", "Flow", MembershipTier.FREE, "Gradiente moderno e leitura rápida.", "GRÁTIS"),
    PlayerInterfaceSpec("orbit", "Orbit", MembershipTier.FREE, "Disco circular com progresso ao redor.", "GRÁTIS"),
    PlayerInterfaceSpec("vinyl_glow", "Vinyl Glow", MembershipTier.FREE, "Vinil moderno giratório com capa ampliada.", "GRÁTIS"),
    PlayerInterfaceSpec("arc_light", "Arc Light", MembershipTier.OURO, "Arco de progresso com modo claro/escuro rápido.", "OURO"),
    PlayerInterfaceSpec("neon_disc", "Neon Disc", MembershipTier.OURO, "Disco neon reativo com barras SONUS.", "OURO"),
    PlayerInterfaceSpec("cassette_retro", "Cassette Retro", MembershipTier.DIAMANTE, "Cassete mecânico com 6 estilos e VU estéreo.", "DIAMANTE"),
    PlayerInterfaceSpec("turntable_classic", "Turntable Classic", MembershipTier.DIAMANTE, "Toca-discos animado com VU Meter.", "DIAMANTE")
)

private data class InterfaceCallbacks(
    val onToggle: () -> Unit,
    val onPrevious: () -> Unit,
    val onNext: () -> Unit,
    val onSeek: (Long) -> Unit,
    val onShuffle: () -> Unit,
    val onRepeat: () -> Unit,
    val onLike: (String) -> Unit,
    val onPin: (String) -> Unit,
    val onLyrics: () -> Unit,
    val onStats: () -> Unit,
    val onLibrary: () -> Unit,
    val onEqualizer: () -> Unit,
    val radioMode: Boolean,
    val radioDelayMs: Long,
    val radioWindowMs: Long,
    val onRadioDelay: (Long) -> Unit
)

@Composable
internal fun SonusPlayerInterface(
    spec: PlayerInterfaceSpec,
    item: PulsePlayerQueueItem,
    state: PulsePlayerPlaybackState,
    spectrumFlow: StateFlow<List<Float>>,
    artwork: ImageBitmap?,
    coverColors: List<Color>,
    themeColors: List<Color>,
    accent: Color,
    visualizer: PlayerVisualizerSpec,
    visualizerEnabled: Boolean,
    intensityPercent: Int,
    sensitivity: Float,
    smoothness: Int,
    liked: Set<String>,
    pinned: Set<String>,
    onToggle: () -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    onSeek: (Long) -> Unit,
    onShuffle: () -> Unit,
    onRepeat: () -> Unit,
    onLike: (String) -> Unit,
    onPin: (String) -> Unit,
    onLyrics: () -> Unit,
    onStats: () -> Unit,
    onLibrary: () -> Unit,
    onEqualizer: () -> Unit,
    lyricsLine: String,
    streamPlayCount: Long? = null,
    radioMode: Boolean = false,
    radioDelayMs: Long = 0L,
    radioWindowMs: Long = SonusRadioEngine.MAX_REWIND_MS,
    onRadioDelay: (Long) -> Unit = {},
    compact: Boolean,
    modifier: Modifier = Modifier
) {
    val callbacks = InterfaceCallbacks(onToggle,onPrevious,onNext,onSeek,onShuffle,onRepeat,onLike,onPin,onLyrics,onStats,onLibrary,onEqualizer,radioMode,radioDelayMs,radioWindowMs,onRadioDelay)
    val spectrum = rememberFluidSpectrum(
        sourceFlow = spectrumFlow,
        playing = state.playing,
        intensityPercent = intensityPercent,
        sensitivity = sensitivity,
        smoothness = smoothness
    )
    val visualColors = rememberResolvedVisualizerColors(visualizer, coverColors, accent)
    CompositionLocalProvider(LocalSonusStreamPlayCount provides streamPlayCount) {
    Box(modifier) {
        val inner = Modifier.fillMaxSize()
        when (spec.id) {
            "pure" -> PurePlayer(item,state,artwork,accent,visualColors,spectrum,visualizerEnabled,liked,pinned,callbacks,compact,inner)
            "flow" -> FlowPlayer(item,state,artwork,themeColors,accent,visualColors,spectrum,visualizerEnabled,liked,pinned,callbacks,compact,inner)
            "orbit" -> OrbitPlayer(item,state,artwork,accent,visualColors,spectrum,visualizerEnabled,liked,pinned,callbacks,compact,inner)
            "vinyl_glow" -> VinylGlowPlayer(item,state,artwork,accent,visualColors,spectrum,visualizerEnabled,liked,pinned,callbacks,compact,inner)
            "arc_light" -> ArcLightPlayer(item,state,artwork,accent,visualColors,spectrum,visualizerEnabled,liked,pinned,callbacks,compact,inner)
            "neon_disc" -> NeonDiscPlayer(item,state,artwork,accent,visualColors,spectrum,visualizerEnabled,liked,pinned,callbacks,compact,inner)
            "cassette_retro" -> CassettePlayer(item,state,artwork,accent,visualColors,spectrum,visualizerEnabled,liked,pinned,callbacks,compact,inner)
            "turntable_classic" -> TurntablePlayer(item,state,artwork,accent,visualColors,spectrum,visualizerEnabled,liked,pinned,callbacks,compact,inner)
            else -> ClassicPlayer(item,state,artwork,accent,visualColors,spectrum,visualizerEnabled,liked,pinned,callbacks,compact,inner)
        }
        if (lyricsLine.isNotBlank()) {
            // code89: LRC compacto, personalizável e reposicionado por layout.
            // O arraste só é armado após 3 s; posição e aparência ficam salvas por layout.
            SmartLyricsOverlay(lyricsLine, spec.id)
        }
    }
    }
}

@Immutable
private data class LyricsVisualPrefs(
    val widthPercent:Int=72,
    val fontSp:Int=11,
    val opacityPercent:Int=72,
    val theme:String="AUTO"
)

private fun lyricsDefaultAlignment(layout:String):Alignment = when(layout){
    // Cassete: sai do VU estéreo superior e nasce no canto inferior direito da área visual.
    "cassette_retro" -> Alignment.CenterEnd
    "turntable_classic" -> Alignment.TopEnd
    "vinyl_glow","neon_disc" -> Alignment.TopStart
    else -> Alignment.TopCenter
}

private fun lyricsBasePadding(layout:String):PaddingValues = when(layout){
    "cassette_retro" -> PaddingValues(start=18.dp,end=14.dp,top=96.dp,bottom=164.dp)
    "turntable_classic" -> PaddingValues(start=18.dp,end=16.dp,top=18.dp,bottom=150.dp)
    "vinyl_glow","neon_disc" -> PaddingValues(start=16.dp,end=18.dp,top=18.dp,bottom=150.dp)
    else -> PaddingValues(start=20.dp,end=20.dp,top=16.dp,bottom=150.dp)
}

@Composable
private fun SmartLyricsOverlay(text:String, layout:String){
    val context=LocalContext.current
    val haptic=LocalHapticFeedback.current
    val prefs=remember{context.getSharedPreferences("sonus_lyrics_overlay_v1",Context.MODE_PRIVATE)}
    fun key(s:String)="${layout}_$s"
    var dx by remember(layout){mutableFloatStateOf(prefs.getFloat(key("dx"),0f))}
    var dy by remember(layout){mutableFloatStateOf(prefs.getFloat(key("dy"),0f))}
    var width by remember(layout){mutableIntStateOf(prefs.getInt(key("width"),72).coerceIn(45,92))}
    var font by remember(layout){mutableIntStateOf(prefs.getInt(key("font"),11).coerceIn(8,18))}
    var opacity by remember(layout){mutableIntStateOf(prefs.getInt(key("opacity"),72).coerceIn(25,95))}
    var theme by remember(layout){mutableStateOf(prefs.getString(key("theme"),"AUTO")?:"AUTO")}
    var moving by remember{mutableStateOf(false)}
    var settings by remember{mutableStateOf(false)}
    val density=androidx.compose.ui.platform.LocalDensity.current
    val retro=layout in setOf("cassette_retro","arc_light","turntable_classic")

    fun savePosition(){prefs.edit().putFloat(key("dx"),dx).putFloat(key("dy"),dy).apply()}
    fun reset(){dx=0f;dy=0f;width=72;font=11;opacity=72;theme="AUTO";prefs.edit().remove(key("dx")).remove(key("dy")).remove(key("width")).remove(key("font")).remove(key("opacity")).remove(key("theme")).apply()}

    val dragModifier=Modifier.pointerInput(layout){
        awaitEachGesture {
            val down=awaitFirstDown(requireUnconsumed=false)
            val releasedEarly=withTimeoutOrNull(3000L){waitForUpOrCancellation()}
            if(releasedEarly==null){
                moving=true
                haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
                drag(down.id){change->
                    val d=change.positionChange()
                    // Janela deliberadamente limitada: liberdade sem permitir jogar a letra sobre todo o player.
                    dx=(dx+d.x).coerceIn(-160f,160f)
                    dy=(dy+d.y).coerceIn(-120f,120f)
                    change.consume()
                }
                // Snap leve em grade e persistência por layout.
                dx=(dx/24f).roundToInt()*24f
                dy=(dy/24f).roundToInt()*24f
                savePosition();moving=false
                haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove)
            }
        }
    }
    val offset=with(density){IntOffset(dx.roundToInt(),dy.roundToInt())}
    Box(Modifier.fillMaxSize().padding(lyricsBasePadding(layout))){
        MiniLyricsDisplay(
            text=text,retro=retro,widthPercent=width,fontSp=font,opacityPercent=opacity,theme=theme,moving=moving,
            modifier=Modifier.align(lyricsDefaultAlignment(layout)).offset{offset}.fillMaxWidth(width/100f).widthIn(max=430.dp)
                .then(dragModifier).clickable{settings=true}
        )
    }
    if(settings){
        AlertDialog(onDismissRequest={settings=false},title={Text("Bloco de letras")},text={
            Column(verticalArrangement=Arrangement.spacedBy(10.dp)){
                Text("Ajustes deste layout",style=MaterialTheme.typography.labelMedium)
                Text("Largura: $width%",fontSize=12.sp); Slider(value=width.toFloat(), onValueChange={ width=it.roundToInt(); prefs.edit().putInt(key("width"),width).apply() }, valueRange=45f..92f)
                Text("Tamanho da letra: $font",fontSize=12.sp); Slider(value=font.toFloat(), onValueChange={ font=it.roundToInt(); prefs.edit().putInt(key("font"),font).apply() }, valueRange=8f..18f, steps=9)
                Text("Fundo: $opacity%",fontSize=12.sp); Slider(value=opacity.toFloat(), onValueChange={ opacity=it.roundToInt(); prefs.edit().putInt(key("opacity"),opacity).apply() }, valueRange=25f..95f)
                Text("Tema",fontSize=12.sp)
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(5.dp)){
                    listOf("AUTO" to "Auto","GLASS" to "Vidro","GRADIENT" to "Degradê").forEach{(id,label)->FilterChip(selected=theme==id,onClick={theme=id;prefs.edit().putString(key("theme"),id).apply()},label={Text(label,fontSize=9.sp)})}
                }
                Text("Segure o bloco por 3 segundos para mover. O SONUS vibra ao liberar e ao fixar.",fontSize=10.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
                TextButton(onClick={reset()}){Icon(Icons.Default.Restore,null);Spacer(Modifier.width(4.dp));Text("Restaurar padrão deste layout")}
            }
        },confirmButton={TextButton(onClick={settings=false}){Text("Concluir")}})
    }
}

@Composable
private fun MiniLyricsDisplay(text:String,retro:Boolean,widthPercent:Int,fontSp:Int,opacityPercent:Int,theme:String,moving:Boolean,modifier:Modifier=Modifier){
    val alpha=opacityPercent/100f
    val autoBg=if(retro)Color(0xFFB7C49A).copy(alpha=alpha) else Color.Black.copy(alpha=alpha)
    val fg=if(retro&&theme=="AUTO")Color(0xFF182016) else Color.White.copy(alpha=.97f)
    val bgModifier=when(theme){
        "GRADIENT"->Modifier.background(Brush.horizontalGradient(listOf(Color(0xFF121826).copy(alpha=alpha),Color(0xFF34224D).copy(alpha=alpha))),RoundedCornerShape(10.dp))
        "GLASS"->Modifier.background(Color(0xFF171A20).copy(alpha=(alpha*.72f).coerceAtLeast(.22f)),RoundedCornerShape(10.dp))
        else->Modifier.background(autoBg,RoundedCornerShape(if(retro)7.dp else 10.dp))
    }
    Box(
        modifier=modifier.heightIn(min=34.dp,max=56.dp).then(bgModifier).border(BorderStroke(if(moving)2.dp else 1.dp,if(moving)MaterialTheme.colorScheme.primary else Color.White.copy(alpha=.16f)),RoundedCornerShape(if(retro)7.dp else 10.dp)).padding(horizontal=9.dp,vertical=5.dp),
        contentAlignment=Alignment.Center
    ){
        Text(text=text.trim(),color=fg,fontSize=fontSp.sp,lineHeight=(fontSp+3).sp,fontWeight=FontWeight.SemiBold,maxLines=2,overflow=TextOverflow.Ellipsis,textAlign=TextAlign.Center)
    }
}

/**
 * Motor visual compartilhado.
 *
 * A coleta do PCM não usa State do Compose, então cada pacote PCM NÃO recompõe a tela inteira.
 * O estado abaixo muda no clock de desenho, próximo ao refresh da tela. As Canvas observam esse
 * estado na fase de draw, deixando transporte/capa/textos fora do loop de 60 fps.
 */
@Composable
private fun rememberFluidSpectrum(
    sourceFlow: StateFlow<List<Float>>,
    playing: Boolean,
    intensityPercent: Int,
    sensitivity: Float,
    smoothness: Int,
    bins: Int = 40
): State<List<Float>> {
    val latestSource = remember(sourceFlow) { AtomicReference(sourceFlow.value.ifEmpty { List(24) { 0f } }) }
    val latestPlaying by rememberUpdatedState(playing)
    val latestIntensity by rememberUpdatedState(intensityPercent.coerceIn(50,200) / 100f)
    val latestSensitivity by rememberUpdatedState(sensitivity.coerceIn(.7f,2.2f))
    val latestSmoothness by rememberUpdatedState(smoothness.coerceIn(0,2))
    val smoothed = remember(bins) { FloatArray(bins) }
    val output = remember(bins) { mutableStateOf(List(bins) { 0f }) }

    LaunchedEffect(sourceFlow) {
        sourceFlow.collect { values ->
            if (values.isNotEmpty()) latestSource.set(values)
        }
    }

    LaunchedEffect(bins) {
        var previousFrameNs = 0L
        var adaptiveCeiling = .18f
        while (isActive) {
            val nowNs = withFrameNanos { it }
            val dtSeconds = if (previousFrameNs == 0L) 1f / 60f
            else ((nowNs - previousFrameNs).coerceIn(4_000_000L, 40_000_000L) / 1_000_000_000f)
            previousFrameNs = nowNs

            val source = latestSource.get().ifEmpty { List(24){0f} }
            val sourcePeak = source.maxOrNull()?.coerceAtLeast(0f) ?: 0f
            // Ceiling sobe rápido em masters altos e cai devagar em músicas baixas.
            val ceilingAttack = 1f - exp((-dtSeconds / .055f).toDouble()).toFloat()
            val ceilingRelease = 1f - exp((-dtSeconds / 1.25f).toDouble()).toFloat()
            val wantedCeiling = sourcePeak.coerceIn(.055f, 1f)
            adaptiveCeiling += (wantedCeiling - adaptiveCeiling) * if (wantedCeiling > adaptiveCeiling) ceilingAttack else ceilingRelease
            adaptiveCeiling = adaptiveCeiling.coerceIn(.055f, 1f)

            val attackTau = when (latestSmoothness) { 0 -> .030f; 2 -> .085f; else -> .050f }
            val releaseTau = when (latestSmoothness) { 0 -> .105f; 2 -> .260f; else -> .175f }
            val attack = 1f - exp((-dtSeconds / attackTau).toDouble()).toFloat()
            val release = 1f - exp((-dtSeconds / releaseTau).toDouble()).toFloat()
            val pauseRelease = 1f - exp((-dtSeconds / .115f).toDouble()).toFloat()

            for (i in 0 until bins) {
                val raw = if (latestPlaying) {
                    val pos = i * (source.lastIndex.coerceAtLeast(1).toFloat() / (bins - 1).coerceAtLeast(1))
                    val lo = pos.toInt().coerceIn(0,source.lastIndex)
                    val hi = (lo+1).coerceAtMost(source.lastIndex)
                    val mix = pos-lo
                    source[lo]*(1f-mix)+source[hi]*mix
                } else 0f

                // Remove um piso muito baixo, normaliza pela dinâmica recente e preserva transientes.
                val normalized = ((raw - .006f).coerceAtLeast(0f) / adaptiveCeiling).coerceIn(0f,1f)
                val musical = normalized.pow(.72f)
                val target = (musical * latestSensitivity * latestIntensity).coerceIn(0f,1f)
                val amount = if (!latestPlaying) pauseRelease else if (target >= smoothed[i]) attack else release
                smoothed[i] += (target-smoothed[i])*amount
                if (smoothed[i] < .0025f) smoothed[i] = 0f
            }
            output.value = smoothed.toList()
        }
    }
    return output
}

@Composable
private fun rememberResolvedVisualizerColors(spec: PlayerVisualizerSpec, coverColors: List<Color>, accent: Color): List<Color> {
    var hue by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(spec.dynamicColor) {
        if (!spec.dynamicColor) return@LaunchedEffect
        while (isActive) {
            withFrameNanos { time -> hue = ((time / 1_000_000L) % 12_000L) / 12_000f * 360f }
        }
    }
    return when {
        spec.coverAdaptive && coverColors.size >= 2 -> coverColors.take(5)
        spec.dynamicColor -> listOf(0f,72f,144f,216f,288f).map { h -> Color(android.graphics.Color.HSVToColor(floatArrayOf((h+hue)%360f,.82f,1f))) }
        spec.colors.isNotEmpty() -> spec.colors
        else -> listOf(accent)
    }
}

@Composable
private fun rememberRotationState(playing: Boolean, durationMs: Int): State<Float> {
    val rotation = remember { mutableFloatStateOf(0f) }
    val latestPlaying by rememberUpdatedState(playing)
    val latestDuration by rememberUpdatedState(durationMs.coerceAtLeast(900))
    LaunchedEffect(Unit) {
        var previous = 0L
        while (isActive) {
            val now = withFrameNanos { it }
            if (previous != 0L && latestPlaying) {
                val dt = (now-previous).coerceIn(0L,50_000_000L) / 1_000_000_000f
                rotation.floatValue = (rotation.floatValue + 360f * dt / (latestDuration / 1000f)) % 360f
            }
            previous = now
        }
    }
    return rotation
}

@Composable
private fun Artwork(
    artwork: ImageBitmap?,
    accent: Color,
    modifier: Modifier,
    shape: androidx.compose.ui.graphics.Shape = RoundedCornerShape(24.dp)
) {
    if (artwork != null) Image(artwork,null,modifier.clip(shape),contentScale=ContentScale.Crop)
    else Surface(modifier,shape=shape,color=accent.copy(alpha=.14f)) {
        Box(contentAlignment=Alignment.Center){ Icon(Icons.Default.MusicNote,null,tint=accent,modifier=Modifier.size(52.dp)) }
    }
}

@Composable
private fun TrackHeader(item: PulsePlayerQueueItem, liked:Set<String>, onLike:(String)->Unit, onStats:()->Unit, color:Color=Color.White) {
    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(item.title,fontWeight=FontWeight.Black,fontSize=19.sp,maxLines=1,overflow=TextOverflow.Ellipsis,color=color)
            Text(item.artist.ifBlank{"Artista desconhecido"},fontSize=13.sp,maxLines=1,overflow=TextOverflow.Ellipsis,color=color.copy(alpha=.72f))
        }
        IconButton(onClick={onLike(item.uri)}) { Icon(if(item.uri in liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,null,tint=if(item.uri in liked) Color(0xFFFF5679) else color.copy(alpha=.88f)) }
    }
}

@Composable
private fun ProgressRow(
    state:PulsePlayerPlaybackState,
    accent:Color,
    onSeek:(Long)->Unit,
    contentColor:Color=Color.White,
    arc:Boolean=false,
    cb:InterfaceCallbacks?=null
) {
    val radio = cb?.radioMode == true
    val streamCount = LocalSonusStreamPlayCount.current
    if (radio) {
        val window = cb!!.radioWindowMs.coerceAtLeast(1L)
        val delay = cb.radioDelayMs.coerceIn(0L, window)
        val liveFraction = (1f - delay.toFloat()/window.toFloat()).coerceIn(0f,1f)
        var dragFraction by remember(window) { mutableFloatStateOf(liveFraction) }
        var dragging by remember { mutableStateOf(false) }
        LaunchedEffect(liveFraction, dragging) { if (!dragging) dragFraction = liveFraction }
        Slider(
            value = dragFraction,
            onValueChange = { fraction -> dragging=true; dragFraction=fraction.coerceIn(0f,1f) },
            onValueChangeFinished = { dragging=false; cb.onRadioDelay(((1f-dragFraction)*window).toLong()) },
            modifier=Modifier.fillMaxWidth().height(24.dp),
            colors=SliderDefaults.colors(thumbColor=if(delay<1500L) Color(0xFF45D47B) else Color(0xFFE75B61),activeTrackColor=accent,inactiveTrackColor=contentColor.copy(alpha=.25f))
        )
        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween){
            Text("-10 min",fontSize=9.sp,color=contentColor.copy(alpha=.58f))
            if(streamCount != null) Surface(shape=RoundedCornerShape(999.dp),color=contentColor.copy(alpha=.09f)){Row(Modifier.padding(horizontal=8.dp,vertical=3.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.PlayCircle,null,modifier=Modifier.size(12.dp),tint=accent);Spacer(Modifier.width(4.dp));Text("$streamCount reproduções",fontSize=8.sp,fontWeight=FontWeight.SemiBold,color=contentColor.copy(alpha=.78f))}}
            Surface(
                shape=RoundedCornerShape(999.dp),
                color=(if(delay<1500L) Color(0xFF45D47B) else Color(0xFFE75B61)).copy(alpha=.16f),
                border=BorderStroke(1.dp,(if(delay<1500L) Color(0xFF45D47B) else Color(0xFFE75B61)).copy(alpha=.42f)),
                modifier=Modifier.clickable { cb.onRadioDelay(0L) }
            ){ Row(Modifier.padding(horizontal=9.dp,vertical=4.dp),verticalAlignment=Alignment.CenterVertically){
                Box(Modifier.size(7.dp).background(if(delay<1500L) Color(0xFF45D47B) else Color(0xFFE75B61),CircleShape));Spacer(Modifier.width(5.dp));Text("AO VIVO",fontSize=8.sp,fontWeight=FontWeight.Black,color=contentColor.copy(alpha=.90f))
            }}
        }
        return
    }
    val progress=if(state.durationMs>0)(state.positionMs.toFloat()/state.durationMs).coerceIn(0f,1f) else 0f
    if(arc){
        Box(Modifier.fillMaxWidth().height(42.dp)){
            Canvas(Modifier.fillMaxSize()){
                val rect=Size(size.width*.84f,size.height*2.1f)
                val top=Offset(size.width*.08f,5f)
                drawArc(contentColor.copy(alpha=.32f),198f,144f,false,top,rect,style=Stroke(4.5f,cap=StrokeCap.Round))
                drawArc(accent,198f,144f*progress,false,top,rect,style=Stroke(6f,cap=StrokeCap.Round))
            }
        }
    } else {
        Slider(progress,{f->if(state.durationMs>0)onSeek((state.durationMs*f).toLong())},modifier=Modifier.fillMaxWidth().height(24.dp),colors=SliderDefaults.colors(thumbColor=accent,activeTrackColor=accent,inactiveTrackColor=contentColor.copy(alpha=.25f)))
    }
    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween){
        Text(clock(state.positionMs),fontSize=10.sp,color=contentColor.copy(alpha=.70f))
        if(streamCount != null) Surface(shape=RoundedCornerShape(999.dp),color=contentColor.copy(alpha=.09f)){Row(Modifier.padding(horizontal=8.dp,vertical=3.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.PlayCircle,null,modifier=Modifier.size(12.dp),tint=accent);Spacer(Modifier.width(4.dp));Text("$streamCount reproduções",fontSize=8.sp,fontWeight=FontWeight.SemiBold,color=contentColor.copy(alpha=.78f))}}
        Text(clock(state.durationMs),fontSize=10.sp,color=contentColor.copy(alpha=.70f))
    }
}

@Composable
private fun Transport(state:PulsePlayerPlaybackState,accent:Color,cb:InterfaceCallbacks,contentColor:Color=Color.White,large:Boolean=true) {
    val disabled=contentColor.copy(alpha=.28f)
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly,verticalAlignment=Alignment.CenterVertically){
        IconButton(onClick=cb.onShuffle,enabled=!cb.radioMode){Icon(Icons.Default.Shuffle,null,tint=if(cb.radioMode)disabled else if(state.shuffle)accent else contentColor.copy(alpha=.72f))}
        IconButton(onClick=cb.onPrevious,enabled=!cb.radioMode){Icon(Icons.Default.SkipPrevious,null,tint=if(cb.radioMode)disabled else contentColor,modifier=Modifier.size(if(large)34.dp else 28.dp))}
        FilledIconButton(onClick=cb.onToggle,modifier=Modifier.size(if(large)62.dp else 54.dp),colors=IconButtonDefaults.filledIconButtonColors(containerColor=accent,contentColor=Color.Black)){Icon(if(state.playing)Icons.Default.Pause else Icons.Default.PlayArrow,null,modifier=Modifier.size(if(large)36.dp else 31.dp))}
        IconButton(onClick=cb.onNext,enabled=!cb.radioMode){Icon(Icons.Default.SkipNext,null,tint=if(cb.radioMode)disabled else contentColor,modifier=Modifier.size(if(large)34.dp else 28.dp))}
        IconButton(onClick=cb.onRepeat,enabled=!cb.radioMode){Icon(if(state.repeatMode==2)Icons.Default.RepeatOne else Icons.Default.Repeat,null,tint=if(cb.radioMode)disabled else if(state.repeatMode>0)accent else contentColor.copy(alpha=.72f))}
    }
}

@Composable
private fun BottomActions(item:PulsePlayerQueueItem,pinned:Set<String>,accent:Color,cb:InterfaceCallbacks,contentColor:Color=Color.White){
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.Center,verticalAlignment=Alignment.CenterVertically){
        TextButton(onClick=cb.onLyrics){Icon(Icons.Default.Lyrics,null,tint=contentColor.copy(alpha=.80f));Spacer(Modifier.width(4.dp));Text("Letras",color=contentColor.copy(alpha=.80f))}
        Spacer(Modifier.width(10.dp))
        IconButton(onClick={cb.onPin(item.uri)},enabled=!cb.radioMode){Icon(Icons.Default.PushPin,null,tint=if(cb.radioMode)contentColor.copy(alpha=.28f) else if(item.uri in pinned)accent else contentColor.copy(alpha=.72f))}
    }
}

/** Barras padrão SONUS. O State é lido no draw, evitando recompor o restante do player a 60 fps. */
@Composable
private fun Bars(valuesState:State<List<Float>>,colors:List<Color>,modifier:Modifier,mirror:Boolean=false){
    Canvas(modifier){
        val values = valuesState.value
        if(values.isEmpty())return@Canvas
        val safeColors = colors.ifEmpty { listOf(Color.White) }
        val step=size.width/values.size
        values.forEachIndexed{i,v0->
            val v=v0.coerceIn(0f,1f)
            if(v<=.001f)return@forEachIndexed
            val h=(v*(if(mirror)size.height*.46f else size.height-4f)).coerceAtLeast(1.5f)
            val c=safeColors[(i*safeColors.size/values.size).coerceIn(0,safeColors.lastIndex)]
            if(mirror){
                drawRoundRect(c.copy(alpha=.96f),Offset(i*step+step*.18f,size.height/2-h),Size(step*.64f,h),CornerRadius(step*.30f))
                drawRoundRect(c.copy(alpha=.66f),Offset(i*step+step*.18f,size.height/2),Size(step*.64f,h),CornerRadius(step*.30f))
            } else {
                drawRoundRect(c.copy(alpha=.50f+.50f*v),Offset(i*step+step*.18f,size.height-h),Size(step*.64f,h),CornerRadius(step*.30f))
            }
        }
    }
}

@Composable
private fun ClassicPlayer(item:PulsePlayerQueueItem,state:PulsePlayerPlaybackState,artwork:ImageBitmap?,accent:Color,colors:List<Color>,spectrum:State<List<Float>>,viz:Boolean,liked:Set<String>,pinned:Set<String>,cb:InterfaceCallbacks,compact:Boolean,modifier:Modifier){
    Card(modifier,colors=CardDefaults.cardColors(containerColor=Color.Black.copy(alpha=.32f)),border=BorderStroke(1.dp,accent.copy(alpha=.32f))){
        Column(Modifier.fillMaxSize().padding(if(compact)9.dp else 12.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(if(compact)3.dp else 6.dp)){
            Artwork(artwork,accent,Modifier.size(if(compact)184.dp else 246.dp),RoundedCornerShape(26.dp))
            Text(item.title,fontWeight=FontWeight.Black,fontSize=if(compact)17.sp else 19.sp,maxLines=1,overflow=TextOverflow.Ellipsis,color=Color.White)
            Text(item.artist.ifBlank{"Artista desconhecido"},fontSize=13.sp,maxLines=1,overflow=TextOverflow.Ellipsis,color=Color.White.copy(alpha=.72f))
            Spacer(Modifier.height(if(compact)2.dp else 5.dp))
            if(viz) Bars(spectrum,colors,Modifier.fillMaxWidth().height(if(compact)58.dp else 70.dp),mirror=true) else Spacer(Modifier.height(if(compact)58.dp else 70.dp))
            ProgressRow(state,accent,cb.onSeek,cb=cb)
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly,verticalAlignment=Alignment.CenterVertically){
                IconButton(onClick={cb.onLike(item.uri)}){Icon(if(item.uri in liked)Icons.Default.Favorite else Icons.Default.FavoriteBorder,null,tint=if(item.uri in liked)Color(0xFFFF5F82) else Color.White)}
                IconButton(onClick=cb.onPrevious,enabled=!cb.radioMode){Icon(Icons.Default.SkipPrevious,null,tint=if(cb.radioMode)Color.White.copy(alpha=.28f) else Color.White,modifier=Modifier.size(34.dp))}
                FilledIconButton(onClick=cb.onToggle,modifier=Modifier.size(if(compact)52.dp else 58.dp),colors=IconButtonDefaults.filledIconButtonColors(containerColor=accent,contentColor=Color.Black)){Icon(if(state.playing)Icons.Default.Pause else Icons.Default.PlayArrow,null,modifier=Modifier.size(if(compact)31.dp else 35.dp))}
                IconButton(onClick=cb.onNext,enabled=!cb.radioMode){Icon(Icons.Default.SkipNext,null,tint=if(cb.radioMode)Color.White.copy(alpha=.28f) else Color.White,modifier=Modifier.size(34.dp))}
                IconButton(onClick={cb.onPin(item.uri)},enabled=!cb.radioMode){Icon(Icons.Default.PushPin,null,tint=if(cb.radioMode)Color.White.copy(alpha=.28f) else if(item.uri in pinned)accent else Color.White.copy(alpha=.78f))}
            }
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly,verticalAlignment=Alignment.CenterVertically){
                IconButton(onClick=cb.onShuffle,enabled=!cb.radioMode){Icon(Icons.Default.Shuffle,null,tint=if(cb.radioMode)Color.White.copy(alpha=.28f) else if(state.shuffle)accent else Color.White.copy(alpha=.72f))}
                IconButton(onClick=cb.onRepeat,enabled=!cb.radioMode){Icon(if(state.repeatMode==2)Icons.Default.RepeatOne else Icons.Default.Repeat,null,tint=if(cb.radioMode)Color.White.copy(alpha=.28f) else if(state.repeatMode>0)accent else Color.White.copy(alpha=.72f))}
                IconButton(onClick=cb.onLyrics){Icon(Icons.Default.Lyrics,"Letras",tint=Color.White.copy(alpha=.78f))}
                IconButton(onClick=cb.onEqualizer){Icon(Icons.Default.GraphicEq,"Equalizador",tint=accent.copy(alpha=.92f))}
            }
        }
    }
}

@Composable
private fun PurePlayer(item:PulsePlayerQueueItem,state:PulsePlayerPlaybackState,artwork:ImageBitmap?,accent:Color,colors:List<Color>,spectrum:State<List<Float>>,viz:Boolean,liked:Set<String>,pinned:Set<String>,cb:InterfaceCallbacks,compact:Boolean,modifier:Modifier){
    Card(modifier,colors=CardDefaults.cardColors(containerColor=Color.Black.copy(alpha=.23f)),shape=RoundedCornerShape(28.dp)){
        Column(Modifier.fillMaxSize().padding(if(compact)12.dp else 18.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(8.dp)){
            Artwork(artwork,accent,Modifier.size(if(compact)180.dp else 250.dp),CircleShape)
            TrackHeader(item,liked,cb.onLike,cb.onStats)
            if(viz) Bars(spectrum,colors,Modifier.fillMaxWidth(.84f).height(if(compact)38.dp else 46.dp)) else Spacer(Modifier.height(if(compact)38.dp else 46.dp))
            Spacer(Modifier.weight(1f))
            ProgressRow(state,accent,cb.onSeek,cb=cb)
            Transport(state,accent,cb)
            BottomActions(item,pinned,accent,cb)
        }
    }
}

@Composable
private fun FlowPlayer(item:PulsePlayerQueueItem,state:PulsePlayerPlaybackState,artwork:ImageBitmap?,themeColors:List<Color>,accent:Color,colors:List<Color>,spectrum:State<List<Float>>,viz:Boolean,liked:Set<String>,pinned:Set<String>,cb:InterfaceCallbacks,compact:Boolean,modifier:Modifier){
    val gradient=(themeColors+accent.copy(alpha=.7f)).takeLast(4).ifEmpty { listOf(Color.Black,accent) }
    Card(modifier,shape=RoundedCornerShape(28.dp),colors=CardDefaults.cardColors(containerColor=Color.Transparent)){
        Column(Modifier.fillMaxSize().background(Brush.verticalGradient(gradient)).padding(if(compact)12.dp else 16.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(7.dp)){
            Text("NOW PLAYING",fontSize=10.sp,fontWeight=FontWeight.Black,letterSpacing=2.sp,color=Color.White.copy(alpha=.78f))
            Artwork(artwork,accent,Modifier.size(if(compact)165.dp else 225.dp),CircleShape)
            TrackHeader(item,liked,cb.onLike,cb.onStats)
            if(viz) Bars(spectrum,colors,Modifier.fillMaxWidth(.82f).height(if(compact)42.dp else 50.dp)) else Spacer(Modifier.height(if(compact)42.dp else 50.dp))
            Spacer(Modifier.weight(1f))
            Transport(state,Color.White,cb)
            ProgressRow(state,Color.White,cb.onSeek,cb=cb)
            BottomActions(item,pinned,Color.White,cb)
        }
    }
}

@Composable
private fun OrbitDisc(artwork:ImageBitmap?,accent:Color,progress:Float,rotation:State<Float>,modifier:Modifier,neon:Boolean=false){
    Box(modifier,contentAlignment=Alignment.Center){
        Canvas(Modifier.fillMaxSize()){
            val stroke=size.minDimension*.035f
            drawCircle(Color.Black.copy(alpha=.72f),radius=size.minDimension*.43f)
            for(i in 1..7)drawCircle(Color.White.copy(alpha=.035f),radius=size.minDimension*(.20f+i*.03f),style=Stroke(1f))
            drawArc(Color.White.copy(alpha=.18f),-90f,360f,false,style=Stroke(stroke,cap=StrokeCap.Round))
            drawArc(if(neon)Brush.sweepGradient(listOf(accent,Color.Magenta,Color.Cyan,accent)) else SolidColor(accent),-90f,360f*progress,false,style=Stroke(stroke,cap=StrokeCap.Round))
        }
        Artwork(artwork,accent,Modifier.fillMaxSize(.58f).graphicsLayer { rotationZ=rotation.value },CircleShape)
        Surface(Modifier.size(18.dp),CircleShape,color=Color(0xFF0B0D12),border=BorderStroke(2.dp,accent.copy(alpha=.7f))){}
    }
}

@Composable
private fun OrbitPlayer(item:PulsePlayerQueueItem,state:PulsePlayerPlaybackState,artwork:ImageBitmap?,accent:Color,colors:List<Color>,spectrum:State<List<Float>>,viz:Boolean,liked:Set<String>,pinned:Set<String>,cb:InterfaceCallbacks,compact:Boolean,modifier:Modifier){
    val rotation=rememberRotationState(state.playing,9000)
    val progress=if(state.durationMs>0)(state.positionMs.toFloat()/state.durationMs).coerceIn(0f,1f)else 0f
    Card(modifier,colors=CardDefaults.cardColors(containerColor=Color(0xFF11151B).copy(alpha=.88f)),shape=RoundedCornerShape(30.dp)){
        Column(Modifier.fillMaxSize().padding(if(compact)12.dp else 16.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(7.dp)){
            OrbitDisc(artwork,accent,progress,rotation,Modifier.size(if(compact)190.dp else 270.dp))
            TrackHeader(item,liked,cb.onLike,cb.onStats)
            if(viz) Bars(spectrum,colors,Modifier.fillMaxWidth(.74f).height(if(compact)34.dp else 42.dp)) else Spacer(Modifier.height(if(compact)34.dp else 42.dp))
            Spacer(Modifier.weight(1f));Transport(state,accent,cb);ProgressRow(state,accent,cb.onSeek,cb=cb);BottomActions(item,pinned,accent,cb)
        }
    }
}

@Composable
private fun VinylGlowPlayer(item:PulsePlayerQueueItem,state:PulsePlayerPlaybackState,artwork:ImageBitmap?,accent:Color,colors:List<Color>,spectrum:State<List<Float>>,viz:Boolean,liked:Set<String>,pinned:Set<String>,cb:InterfaceCallbacks,compact:Boolean,modifier:Modifier){
    val rotation=rememberRotationState(state.playing,6500)
    Card(modifier,colors=CardDefaults.cardColors(containerColor=Color.Black.copy(alpha=.38f)),shape=RoundedCornerShape(28.dp),border=BorderStroke(1.dp,accent.copy(alpha=.4f))){
        Column(Modifier.fillMaxSize().padding(if(compact)10.dp else 14.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(6.dp)){
            TrackHeader(item,liked,cb.onLike,cb.onStats)
            Box(Modifier.size(if(compact)192.dp else 264.dp),contentAlignment=Alignment.Center){
                Canvas(Modifier.fillMaxSize()){
                    drawCircle(Brush.radialGradient(listOf(Color(0xFF17191E),Color.Black)),radius=size.minDimension*.48f)
                    repeat(12){i->drawCircle(Color.White.copy(alpha=.025f),radius=size.minDimension*(.16f+i*.026f),style=Stroke(1f))}
                    drawCircle(accent.copy(alpha=.20f),radius=size.minDimension*.50f,style=Stroke(8f))
                }
                // code68: a capa deixa de ser um selo minúsculo e preenche visualmente o centro do disco.
                Artwork(artwork,accent,Modifier.fillMaxSize(.58f).graphicsLayer { rotationZ=rotation.value },CircleShape)
                Surface(Modifier.size(15.dp),CircleShape,color=Color(0xFF0B0D12),border=BorderStroke(1.5.dp,accent.copy(alpha=.7f))){}
            }
            Spacer(Modifier.height(if(compact)5.dp else 10.dp))
            if(viz) Bars(spectrum,colors,Modifier.fillMaxWidth(.84f).height(if(compact)42.dp else 52.dp),mirror=true) else Spacer(Modifier.height(if(compact)42.dp else 52.dp))
            Spacer(Modifier.weight(1f));ProgressRow(state,accent,cb.onSeek,cb=cb);Transport(state,accent,cb);BottomActions(item,pinned,accent,cb)
        }
    }
}

@Composable
private fun ArcLightPlayer(item:PulsePlayerQueueItem,state:PulsePlayerPlaybackState,artwork:ImageBitmap?,accent:Color,colors:List<Color>,spectrum:State<List<Float>>,viz:Boolean,liked:Set<String>,pinned:Set<String>,cb:InterfaceCallbacks,compact:Boolean,modifier:Modifier){
    val context=LocalContext.current
    val prefs=remember{context.getSharedPreferences("sonus_player_interface_quick_v1",Context.MODE_PRIVATE)}
    var darkMode by remember { mutableStateOf(prefs.getBoolean("arc_light_dark",false)) }
    val background=if(darkMode)Color(0xFF080B10) else Color(0xFFF7F9FC)
    val foreground=if(darkMode)Color(0xFFF4F7FB) else Color(0xFF111923)
    val secondary=foreground.copy(alpha=.72f)
    Card(modifier,colors=CardDefaults.cardColors(containerColor=background),shape=RoundedCornerShape(30.dp),border=BorderStroke(1.dp,if(darkMode)Color.White.copy(alpha=.09f) else Color.Black.copy(alpha=.08f))){
        Column(Modifier.fillMaxSize().padding(if(compact)11.dp else 15.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(7.dp)){
            Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
                Column(Modifier.weight(1f)){
                    Text("ARC LIGHT",fontSize=10.sp,fontWeight=FontWeight.Black,letterSpacing=1.7.sp,color=secondary)
                    Text(if(darkMode)"Modo escuro" else "Modo claro",fontSize=10.sp,color=secondary)
                }
                FilledTonalIconButton(onClick={darkMode=!darkMode;prefs.edit().putBoolean("arc_light_dark",darkMode).apply()},colors=IconButtonDefaults.filledTonalIconButtonColors(containerColor=foreground.copy(alpha=.10f),contentColor=foreground)){
                    Icon(if(darkMode)Icons.Default.LightMode else Icons.Default.DarkMode,if(darkMode)"Usar fundo claro" else "Usar fundo escuro")
                }
            }
            Box(contentAlignment=Alignment.Center){
                Artwork(artwork,accent,Modifier.fillMaxWidth(.72f).aspectRatio(.82f),RoundedCornerShape(bottomStart=110.dp,bottomEnd=110.dp,topStart=24.dp,topEnd=24.dp))
                if(viz)Bars(spectrum,colors,Modifier.fillMaxWidth(.50f).height(if(compact)80.dp else 96.dp),mirror=true)
            }
            ProgressRow(state,accent,cb.onSeek,contentColor=foreground,arc=true,cb=cb)
            TrackHeader(item,liked,cb.onLike,cb.onStats,foreground)
            Spacer(Modifier.weight(1f));Transport(state,accent,cb,contentColor=foreground);BottomActions(item,pinned,accent,cb,contentColor=foreground)
        }
    }
}

@Composable
private fun NeonDiscPlayer(item:PulsePlayerQueueItem,state:PulsePlayerPlaybackState,artwork:ImageBitmap?,accent:Color,colors:List<Color>,spectrum:State<List<Float>>,viz:Boolean,liked:Set<String>,pinned:Set<String>,cb:InterfaceCallbacks,compact:Boolean,modifier:Modifier){
    val rotation=rememberRotationState(state.playing,11000)
    val safeColors=colors.ifEmpty{listOf(accent)}
    Card(modifier,colors=CardDefaults.cardColors(containerColor=Color.Black.copy(alpha=.30f)),shape=RoundedCornerShape(30.dp)){
        Column(Modifier.fillMaxSize().padding(if(compact)10.dp else 15.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(8.dp)){
            Box(Modifier.size(if(compact)190.dp else 270.dp),contentAlignment=Alignment.Center){
                Canvas(Modifier.fillMaxSize()){
                    drawCircle(Brush.radialGradient(listOf(accent.copy(alpha=.30f),Color(0xFF101322),Color.Black)),radius=size.minDimension*.48f)
                    drawCircle(Brush.sweepGradient(safeColors+safeColors.first()),radius=size.minDimension*.48f,style=Stroke(7f))
                }
                Artwork(artwork,accent,Modifier.fillMaxSize(.74f).graphicsLayer { rotationZ=rotation.value },CircleShape)
                if(viz)Bars(spectrum,safeColors,Modifier.fillMaxWidth(.66f).height(if(compact)66.dp else 82.dp),mirror=true)
            }
            TrackHeader(item,liked,cb.onLike,cb.onStats);Spacer(Modifier.weight(1f));ProgressRow(state,accent,cb.onSeek,cb=cb);Transport(state,accent,cb);BottomActions(item,pinned,accent,cb)
        }
    }
}

private data class CassetteSkin(
    val name:String,
    val body:Color,
    val frame:Color,
    val label:Color,
    val band:Color,
    val ink:Color,
    val window:Color,
    val metal:Color
)

private val CassetteSkins=listOf(
    CassetteSkin("Blue Red",Color(0xFF7286E8),Color(0xFF5C67A9),Color(0xFFE8E7E0),Color(0xFFFF2727),Color(0xFF18202A),Color(0xFF4C5159),Color(0xFFC7CDD1)),
    CassetteSkin("Red Black",Color(0xFFC9D0D2),Color(0xFF7C888D),Color(0xFFFF1F17),Color(0xFF080808),Color(0xFF111111),Color(0xFFC8D0D3),Color(0xFFB9C2C5)),
    CassetteSkin("Cream Pop",Color(0xFFF0251B),Color(0xFFB51B15),Color(0xFFFFF5D5),Color(0xFF2D7099),Color(0xFF34383B),Color(0xFFE5E6E1),Color(0xFFBEC6C8)),
    CassetteSkin("Black Red",Color(0xFF303234),Color(0xFF141516),Color(0xFFF4F4F2),Color(0xFFFF2525),Color(0xFF111111),Color(0xFF111214),Color(0xFFD4D7D8)),
    CassetteSkin("Blue Yellow",Color(0xFF0A5E9B),Color(0xFF074B7C),Color(0xFFF1F1E8),Color(0xFFFFD20A),Color(0xFF163044),Color(0xFF152433),Color(0xFFC7CFD3)),
    CassetteSkin("Silver Pink",Color(0xFF787878),Color(0xFF4D4D4D),Color(0xFFE8E8E8),Color(0xFFFF00C7),Color(0xFF292929),Color(0xFF55585B),Color(0xFFC9CCCE))
)

private data class ReelMotion(val left:State<Float>,val right:State<Float>)

@Composable
private fun rememberCassetteReels(playing:Boolean,progress:Float):ReelMotion{
    val left=remember{mutableFloatStateOf(0f)}
    val right=remember{mutableFloatStateOf(0f)}
    val latestPlaying by rememberUpdatedState(playing)
    val latestProgress by rememberUpdatedState(progress.coerceIn(0f,1f))
    LaunchedEffect(Unit){
        var previous=0L
        while(isActive){
            val now=withFrameNanos{it}
            if(previous!=0L && latestPlaying){
                val dt=(now-previous).coerceIn(0L,50_000_000L)/1_000_000_000f
                val leftFill=(.12f+(1f-latestProgress)*.82f).coerceIn(.12f,.94f)
                val rightFill=(.12f+latestProgress*.82f).coerceIn(.12f,.94f)
                // Menos fita = menor raio = rotação angular maior, como em um cassete real.
                val leftSpeed=205f/sqrt(leftFill)
                val rightSpeed=205f/sqrt(rightFill)
                left.floatValue=(left.floatValue+leftSpeed*dt)%360f
                right.floatValue=(right.floatValue+rightSpeed*dt)%360f
            }
            previous=now
        }
    }
    return ReelMotion(left,right)
}

@Composable
private fun CassettePlayer(item:PulsePlayerQueueItem,state:PulsePlayerPlaybackState,artwork:ImageBitmap?,accent:Color,colors:List<Color>,spectrum:State<List<Float>>,viz:Boolean,liked:Set<String>,pinned:Set<String>,cb:InterfaceCallbacks,compact:Boolean,modifier:Modifier){
    val context=LocalContext.current
    val prefs=remember{context.getSharedPreferences("sonus_player_interface_quick_v1",Context.MODE_PRIVATE)}
    var skinIndex by remember{mutableIntStateOf(prefs.getInt("cassette_skin",0).coerceIn(0,CassetteSkins.lastIndex))}
    val skin=CassetteSkins[skinIndex]
    val progress=if(state.durationMs>0)(state.positionMs.toFloat()/state.durationMs).coerceIn(0f,1f)else 0f
    val motion=rememberCassetteReels(state.playing,progress)
    Card(modifier,colors=CardDefaults.cardColors(containerColor=Color(0xFF111417)),shape=RoundedCornerShape(22.dp),border=BorderStroke(1.dp,Color.White.copy(alpha=.10f))){
        Column(Modifier.fillMaxSize().padding(if(compact)8.dp else 12.dp),verticalArrangement=Arrangement.spacedBy(if(compact)5.dp else 7.dp)){
            Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
                Column(Modifier.weight(1f)){
                    Text("CASSETTE RETRO",fontSize=10.sp,fontWeight=FontWeight.Black,letterSpacing=1.5.sp,color=Color.White.copy(alpha=.82f))
                    Text("${skin.name} • ${skinIndex+1}/${CassetteSkins.size}",fontSize=10.sp,color=Color.White.copy(alpha=.58f))
                }
                FilledTonalIconButton(onClick={skinIndex=(skinIndex+1)%CassetteSkins.size;prefs.edit().putInt("cassette_skin",skinIndex).apply()},colors=IconButtonDefaults.filledTonalIconButtonColors(containerColor=Color.White.copy(alpha=.08f),contentColor=Color.White)){
                    Icon(Icons.Default.SwapHoriz,"Trocar modelo de fita")
                }
            }
            StereoVu(spectrum,colors,viz,Modifier.fillMaxWidth().height(if(compact)44.dp else 58.dp))
            CassetteBody(item,artwork,accent,skin,motion,progress,Modifier.fillMaxWidth().weight(1f))
            TrackHeader(item,liked,cb.onLike,cb.onStats,Color.White)
            ProgressRow(state,accent,cb.onSeek,cb=cb)
            Transport(state,accent,cb)
            BottomActions(item,pinned,accent,cb)
        }
    }
}

@Composable
private fun StereoVu(valuesState:State<List<Float>>,colors:List<Color>,enabled:Boolean,modifier:Modifier){
    Canvas(modifier.background(Color(0xFF07090B),RoundedCornerShape(9.dp)).border(1.dp,Color.White.copy(alpha=.14f),RoundedCornerShape(9.dp))){
        val values=valuesState.value
        val safe=if(enabled)values else emptyList()
        val palette=colors.ifEmpty { listOf(Color(0xFF83EF43)) }
        fun level(start:Int,end:Int):Float{
            if(safe.isEmpty())return 0f
            val a=start.coerceIn(0,safe.lastIndex);val b=end.coerceIn(a+1,safe.size)
            val slice=safe.subList(a,b)
            val rms=sqrt(slice.map{it*it}.average().toFloat())
            val peak=slice.maxOrNull()?:0f
            return (rms*1.10f+peak*.32f).coerceIn(0f,1f)
        }
        val split=(safe.size/2).coerceAtLeast(1)
        val left=if(safe.isEmpty())0f else level(0,split)
        val right=if(safe.isEmpty())0f else level(split.coerceAtMost(safe.lastIndex),safe.size)
        val meters=listOf(left,right)
        val labels=listOf("L","R")
        val segments=22
        val labelW=size.width*.065f
        val usable=size.width-labelW-size.width*.035f
        val step=usable/segments
        meters.forEachIndexed{row,level->
            val cy=size.height*(if(row==0).34f else .72f)
            // Pequeno traço L/R no lugar de texto evita dependência de Paint/Typeface na Canvas Compose.
            drawLine(Color.White.copy(alpha=.72f),Offset(size.width*.025f,cy-5f),Offset(size.width*.025f,cy+5f),2.2f)
            if(labels[row]=="R")drawLine(Color.White.copy(alpha=.72f),Offset(size.width*.018f,cy-5f),Offset(size.width*.034f,cy-5f),2f)
            repeat(segments){i->
                val active=i < (level*segments).toInt().coerceIn(0,segments)
                val c=when{ i>=19->Color(0xFFFF3D45);i>=15->Color(0xFFFFC02E);else->palette[i%palette.size]}
                drawRoundRect(if(active)c else Color(0xFF22272C),Offset(labelW+i*step,cy-size.height*.055f),Size(step*.70f,size.height*.11f),CornerRadius(2.4f))
            }
            val peakPos=(level*segments).toInt().coerceIn(0,segments-1)
            if(level>.08f)drawRoundRect(Color.White.copy(alpha=.72f),Offset(labelW+peakPos*step,cy-size.height*.073f),Size(step*.54f,2f),CornerRadius(1f))
        }
    }
}

@Composable
private fun CassetteBody(item:PulsePlayerQueueItem,artwork:ImageBitmap?,accent:Color,skin:CassetteSkin,motion:ReelMotion,progress:Float,modifier:Modifier){
    val leftFill=(.12f+(1f-progress)*.82f).coerceIn(.12f,.94f)
    val rightFill=(.12f+progress*.82f).coerceIn(.12f,.94f)
    Box(modifier.background(skin.body,RoundedCornerShape(18.dp)).border(2.dp,skin.frame,RoundedCornerShape(18.dp)),contentAlignment=Alignment.Center){
        // Parafusos e detalhes externos deixam a silhueta reconhecível mesmo nos seis skins.
        Canvas(Modifier.fillMaxSize()){
            val r=size.minDimension*.020f
            listOf(Offset(size.width*.055f,size.height*.07f),Offset(size.width*.945f,size.height*.07f),Offset(size.width*.065f,size.height*.90f),Offset(size.width*.935f,size.height*.90f)).forEach{drawCircle(Color.Black.copy(alpha=.82f),r,it)}
            drawRoundRect(skin.band,Offset(size.width*.055f,size.height*.18f),Size(size.width*.89f,size.height*.12f),CornerRadius(5f))
        }
        Column(Modifier.fillMaxSize().padding(horizontal=12.dp,vertical=10.dp),horizontalAlignment=Alignment.CenterHorizontally){
            Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
                Text("SONUS",fontWeight=FontWeight.Black,color=skin.ink,fontSize=11.sp,letterSpacing=1.1.sp)
                Spacer(Modifier.weight(1f))
                Text("C-90 • SIDE A",fontWeight=FontWeight.Black,color=skin.ink.copy(alpha=.86f),fontSize=9.sp)
            }
            Spacer(Modifier.height(9.dp))
            Surface(color=skin.label,shape=RoundedCornerShape(10.dp),modifier=Modifier.fillMaxWidth().weight(1f),border=BorderStroke(1.dp,skin.frame.copy(alpha=.50f))){
                Column(Modifier.padding(horizontal=8.dp,vertical=7.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(5.dp)){
                    Text(item.title,maxLines=1,overflow=TextOverflow.Ellipsis,color=skin.ink,fontWeight=FontWeight.Black,fontSize=11.sp)
                    Text(item.artist.ifBlank{"SONUS PLAYER"},maxLines=1,overflow=TextOverflow.Ellipsis,color=skin.ink.copy(alpha=.72f),fontWeight=FontWeight.SemiBold,fontSize=9.sp)
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly,verticalAlignment=Alignment.CenterVertically){
                        Reel(motion.left,leftFill,skin,accent,62.dp)
                        // A arte vira parte da etiqueta, grande o bastante para ser reconhecida.
                        Box(Modifier.weight(1f).padding(horizontal=8.dp).height(72.dp).background(skin.window,RoundedCornerShape(10.dp)).border(1.dp,skin.frame.copy(alpha=.7f),RoundedCornerShape(10.dp)),contentAlignment=Alignment.Center){
                            Artwork(artwork,accent,Modifier.fillMaxSize().padding(5.dp),RoundedCornerShape(7.dp))
                        }
                        Reel(motion.right,rightFill,skin,accent,62.dp)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            // Janela/guia inferior típica de fita compacta.
            Canvas(Modifier.fillMaxWidth(.78f).height(44.dp)){
                val p=Path().apply{moveTo(size.width*.10f,size.height);lineTo(size.width*.20f,0f);lineTo(size.width*.80f,0f);lineTo(size.width*.90f,size.height);close()}
                drawPath(p,skin.frame.copy(alpha=.90f))
                drawLine(skin.metal,Offset(size.width*.20f,4f),Offset(size.width*.80f,4f),4f,StrokeCap.Round)
                drawCircle(Color.Black.copy(alpha=.72f),5.5f,Offset(size.width*.28f,size.height*.56f))
                drawCircle(Color.Black.copy(alpha=.72f),5.5f,Offset(size.width*.72f,size.height*.56f))
            }
        }
    }
}

@Composable
private fun Reel(rotation:State<Float>,fill:Float,skin:CassetteSkin,accent:Color,sizeDp:androidx.compose.ui.unit.Dp){
    Canvas(Modifier.size(sizeDp).graphicsLayer { rotationZ=rotation.value }){
        // A massa de fita cresce/diminui junto com o progresso.
        val tapeRadius=size.minDimension*(.27f+.18f*fill.coerceIn(0f,1f))
        drawCircle(Color(0xFF2A211C),radius=tapeRadius)
        drawCircle(skin.metal,radius=size.minDimension*.27f)
        drawCircle(skin.window.copy(alpha=.92f),radius=size.minDimension*.19f)
        repeat(6){i->
            val a=i*PI/3
            val c=Offset(center.x+cos(a).toFloat()*size.minDimension*.135f,center.y+sin(a).toFloat()*size.minDimension*.135f)
            drawCircle(skin.ink.copy(alpha=.78f),size.minDimension*.050f,c)
        }
        drawCircle(accent.copy(alpha=.92f),radius=size.minDimension*.055f)
    }
}

@Composable
private fun TurntablePlayer(item:PulsePlayerQueueItem,state:PulsePlayerPlaybackState,artwork:ImageBitmap?,accent:Color,colors:List<Color>,spectrum:State<List<Float>>,viz:Boolean,liked:Set<String>,pinned:Set<String>,cb:InterfaceCallbacks,compact:Boolean,modifier:Modifier){
    val rotation=rememberRotationState(state.playing,5200)
    val progress=if(state.durationMs>0)(state.positionMs.toFloat()/state.durationMs).coerceIn(0f,1f)else 0f
    Card(modifier,colors=CardDefaults.cardColors(containerColor=Color(0xFF171A1F)),shape=RoundedCornerShape(24.dp)){
        Column(Modifier.fillMaxSize().padding(if(compact)9.dp else 12.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){
            Box(Modifier.fillMaxWidth().weight(1f).background(Brush.linearGradient(listOf(Color(0xFF34291F),Color(0xFFE6DED2),Color(0xFF263342))),RoundedCornerShape(18.dp))){
                Box(Modifier.fillMaxSize().padding(10.dp)){
                    Box(Modifier.fillMaxHeight(.82f).aspectRatio(1f).align(Alignment.CenterStart),contentAlignment=Alignment.Center){
                        Canvas(Modifier.fillMaxSize().graphicsLayer { rotationZ=rotation.value }){drawCircle(Color.Black);repeat(14){i->drawCircle(Color.White.copy(alpha=.025f),radius=size.minDimension*(.16f+i*.022f),style=Stroke(1f))};drawCircle(accent.copy(alpha=.18f),radius=size.minDimension*.48f,style=Stroke(5f))}
                        Artwork(artwork,accent,Modifier.fillMaxSize(.34f).graphicsLayer { rotationZ=rotation.value },CircleShape)
                    }
                    ToneArm(state.current!=null,progress,Modifier.fillMaxHeight(.78f).fillMaxWidth(.42f).align(Alignment.TopEnd))
                    if(viz) StereoVu(spectrum,colors,true,Modifier.fillMaxWidth(.43f).height(if(compact)38.dp else 44.dp).align(Alignment.BottomEnd))
                }
            }
            TrackHeader(item,liked,cb.onLike,cb.onStats);ProgressRow(state,accent,cb.onSeek,cb=cb);Transport(state,accent,cb);BottomActions(item,pinned,accent,cb)
        }
    }
}

@Composable
private fun ToneArm(hasTrack:Boolean,progress:Float,modifier:Modifier){
    // Em Pause o braço permanece sobre o sulco atual; só o prato para.
    val target=if(hasTrack)16f+progress.coerceIn(0f,1f)*10f else 0f
    val angle by androidx.compose.animation.core.animateFloatAsState(targetValue=target,animationSpec=tween(420),label="tonearm")
    Canvas(modifier.graphicsLayer(rotationZ=angle,transformOrigin=TransformOrigin(.82f,.12f))){
        val pivot=Offset(size.width*.82f,size.height*.12f)
        drawCircle(Color(0xFFBFC5CA),size.width*.14f,pivot);drawCircle(Color(0xFF34383D),size.width*.08f,pivot)
        val end=Offset(size.width*.25f,size.height*.85f);drawLine(Color(0xFFD2D5D8),pivot,end,8f,StrokeCap.Round);drawLine(Color(0xFF22262A),end,Offset(end.x-15f,end.y+18f),10f,StrokeCap.Round)
    }
}

private fun clock(ms:Long):String{val total=(ms/1000).coerceAtLeast(0);return "%d:%02d".format(total/60,total%60)}
