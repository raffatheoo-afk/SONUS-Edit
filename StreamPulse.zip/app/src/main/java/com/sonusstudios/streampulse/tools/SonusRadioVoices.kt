package com.sonusstudios.streampulse.tools

import android.content.Context
import android.media.MediaMetadataRetriever
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.Normalizer
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

internal data class SonusRadioVoice(val fileId: Long, val name: String, val file: File, val durationMs: Long) {
    val uri: String get() = android.net.Uri.fromFile(file).toString()
    /** Gêneros citados no nome do arquivo (ex.: "trap_01.mp3"); vazio = locução neutra, vale para qualquer rádio. */
    val allowedGenres: Set<String> get() {
        val n = Normalizer.normalize(name.lowercase(Locale.ROOT), Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")
        return genreKeywords.filter { n.contains(it) }.toSet()
    }
    companion object {
        private val genreKeywords = listOf("trap", "gospel", "catolic", "piseiro", "romantic", "acustic", "funk", "arrocha", "brega", "sertanej", "forro", "pagode", "internacional", "rap", "rock", "pop")
    }
}

/**
 * 0.0.1: locuções da SONUS Rádio vêm EXCLUSIVAMENTE da pasta pública do pCloud (nenhum áudio de locução vai
 * dentro do app). Os arquivos são baixados uma vez para a pasta interna do app e reaproveitados: a rádio nunca
 * espera a rede para começar. Sem internet e sem cache, a rádio toca só música.
 * As locuções NÃO fazem parte do catálogo do Stream (link próprio, nunca listado como música).
 */
internal object SonusRadioVoices {
    const val PUBLIC_CODE = "kZbl6bJZWw28AwFdAI8ScA7H4gU5sSOIrFcX"
    private val audioExt = setOf("mp3", "m4a", "aac", "ogg", "opus", "wav", "flac")
    private const val MAX_BYTES = 15L * 1024 * 1024
    private const val REFRESH_EVERY_MS = 6L * 3_600_000L
    private val syncing = AtomicBoolean(false)
    @Volatile private var lastSyncAt = 0L

    private fun dir(context: Context): File = File(context.applicationContext.filesDir, "sonus_radio_voices").apply { mkdirs() }
    private fun indexFile(context: Context) = File(dir(context), "index.json")

    /** Locuções já salvas no aparelho (leitura rápida do disco, segura para a thread principal). */
    fun cached(context: Context): List<SonusRadioVoice> = runCatching {
        val f = indexFile(context)
        if (!f.exists()) return@runCatching emptyList()
        val arr = JSONArray(f.readText())
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            val file = File(dir(context), o.optString("file"))
            if (!file.exists() || file.length() <= 0L) null
            else SonusRadioVoice(o.optLong("id"), o.optString("name"), file, o.optLong("dur"))
        }
    }.getOrDefault(emptyList())

    /** Sincroniza com a nuvem em segundo plano (no máximo uma vez a cada 6 h, ou sempre que o cache estiver vazio). */
    fun refreshAsync(context: Context, force: Boolean = false) {
        val app = context.applicationContext
        val now = System.currentTimeMillis()
        if (!force && now - lastSyncAt < REFRESH_EVERY_MS && cached(app).isNotEmpty()) return
        if (!syncing.compareAndSet(false, true)) return
        Thread({
            try { sync(app) } catch (_: Throwable) { } finally { syncing.set(false) }
        }, "sonus-radio-voices").start()
    }

    /** Bloqueante (rede): chamar só fora da thread principal. */
    fun sync(context: Context): List<SonusRadioVoice> {
        val nodes = runCatching { SonusPCloudClient.listPublicNodes(PUBLIC_CODE) }.getOrNull() ?: return cached(context)
        val wanted = nodes.filter { n ->
            n.name.substringAfterLast('.', "").lowercase(Locale.ROOT) in audioExt || n.contentType.startsWith("audio/", true)
        }.filter { it.size in 1..MAX_BYTES || it.size == 0L }
        if (wanted.isEmpty()) return cached(context)
        val existing = cached(context).associateBy { it.fileId }
        val result = mutableListOf<SonusRadioVoice>()
        for (n in wanted) {
            existing[n.fileId]?.let { result += it; continue }
            val ext = n.name.substringAfterLast('.', "mp3").lowercase(Locale.ROOT).take(5)
            val target = File(dir(context), "${n.fileId}.$ext")
            val ok = runCatching {
                val tmp = File(dir(context), "${n.fileId}.part")
                val conn = (URL(SonusPCloudClient.publicFileUrl(PUBLIC_CODE, n.fileId)).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 12_000; readTimeout = 25_000; instanceFollowRedirects = true
                }
                try {
                    if (conn.responseCode !in 200..299) return@runCatching false
                    var total = 0L
                    conn.inputStream.use { input -> tmp.outputStream().use { out ->
                        val buf = ByteArray(32 * 1024)
                        while (true) {
                            val r = input.read(buf); if (r <= 0) break
                            total += r; if (total > MAX_BYTES) error("grande demais")
                            out.write(buf, 0, r)
                        }
                    } }
                } finally { conn.disconnect() }
                tmp.renameTo(target) || run { tmp.copyTo(target, true); tmp.delete(); true }
            }.getOrDefault(false)
            if (!ok || !target.exists()) { File(dir(context), "${n.fileId}.part").delete(); continue }
            val duration = runCatching {
                val r = MediaMetadataRetriever()
                try { r.setDataSource(target.absolutePath); r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L } finally { runCatching { r.release() } }
            }.getOrDefault(0L)
            if (duration <= 0L) { target.delete(); continue }
            result += SonusRadioVoice(n.fileId, n.name.substringBeforeLast('.'), target, duration)
        }
        if (result.isEmpty()) return cached(context)
        // Persiste o índice e apaga locuções que saíram da nuvem.
        val arr = JSONArray()
        result.forEach { v -> arr.put(JSONObject().put("id", v.fileId).put("name", v.name).put("file", v.file.name).put("dur", v.durationMs)) }
        indexFile(context).writeText(arr.toString())
        val keep = result.map { it.file.name }.toSet() + "index.json"
        dir(context).listFiles()?.forEach { if (it.name !in keep) it.delete() }
        lastSyncAt = System.currentTimeMillis()
        return result
    }
}
