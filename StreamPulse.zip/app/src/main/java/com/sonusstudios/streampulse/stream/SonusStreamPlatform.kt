package com.sonusstudios.streampulse.stream

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.google.firebase.database.ServerValue
import com.google.firebase.storage.FirebaseStorage
import com.sonusstudios.streampulse.BuildConfig
import com.sonusstudios.streampulse.auth.AccountRole
import com.sonusstudios.streampulse.auth.AuthUser
import com.sonusstudios.streampulse.audio.AudioConversionEngine
import com.sonusstudios.streampulse.audio.AudioTrackTags
import com.sonusstudios.streampulse.core.AudioConversionPreset
import com.sonusstudios.streampulse.core.MembershipTier
import com.sonusstudios.streampulse.core.SonusLyricsImporter
import com.sonusstudios.streampulse.core.SonusMediaStandards
import com.sonusstudios.streampulse.core.commercialTier
import com.sonusstudios.streampulse.core.sonusMusicPublicId
import com.sonusstudios.streampulse.notifications.SonusNotificationCenter
import com.sonusstudios.streampulse.support.sonusPublicId
import com.sonusstudios.streampulse.support.SonusSupportRepository
import com.sonusstudios.streampulse.support.SupportCategory
import com.sonusstudios.streampulse.tools.AudioToolEngine
import com.sonusstudios.streampulse.ui.avatar.SonusAvatarArtwork
import com.sonusstudios.streampulse.ui.avatar.SonusAvatarCatalog
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.util.Locale
import java.util.UUID
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

const val SONUS_STREAM_TERMS_VERSION = 1
const val SONUS_STREAM_MIN_VALID_PLAY_MS = 10_000L
const val SONUS_STREAM_DYNAMIC_VIEW_STEP = 50L
const val SONUS_STREAM_DYNAMIC_VIEW_DROP_MS = 10_000L
const val SONUS_STREAM_VIEW_COOLDOWN_MS = 15L * 60_000L
const val SONUS_STREAM_LISTENING_WINDOW_MS = 24L * 60L * 60_000L
const val SONUS_STREAM_MAX_QUALIFIED_LISTENING_PER_SONG_WINDOW_MS = 60L * 60_000L
const val SONUS_STREAM_UPLOAD_BITRATE_KBPS = 256
val SONUS_STREAM_CANONICAL_GENRES = SonusMediaStandards.genres
const val SONUS_STREAM_UPLOAD_MAX_SOURCE_BYTES = 250L * 1024L * 1024L

enum class StreamSubmissionStatus(val label: String) {
    RECEIVED("Recebida"), REVIEWING("Em análise"), CHANGES_REQUESTED("Alteração solicitada"), APPROVED("Aprovada • preparando publicação"), PUBLISHED("🟢 Ao Vivo"), REJECTED("Rejeitada"), REMOVED("Removida")
}

/** code106: o papel da conta não define sozinho qual interface está aberta. */
enum class StreamCenterMode { CREATOR, MODERATION }

enum class StreamViolationLevel(val label: String, val scorePenalty: Double, val consumesQuota: Boolean) {
    NONE("Sem violação", 0.0, false),
    LIGHT("🟢 Leve", 0.5, false),
    MEDIUM("🟡 Média", 2.0, true),
    SEVERE("🔴 Grave", 3.0, true)
}

data class StreamSubmission(
    val id: String = "",
    val musicId: String = "",
    val uid: String = "",
    val publicUserId: String = "",
    val title: String = "",
    val artistName: String = "",
    val artistId: String = "",
    val genre: String = "",
    val lyrics: String = "",
    val lrc: String = "",
    val aiUsed: Boolean = false,
    val aiImitatesRealPerson: Boolean = false,
    val status: String = StreamSubmissionStatus.RECEIVED.name,
    val audioStoragePath: String = "",
    val coverStoragePath: String = "",
    val audioDownloadUrl: String = "",
    val coverDownloadUrl: String = "",
    val audioOriginalName: String = "audio.mp3",
    val audioMime: String = "audio/mpeg",
    val coverOriginalName: String = "cover.jpg",
    val coverMime: String = "image/jpeg",
    val planAtSubmission: String = "FREE",
    val priority: Int = 0,
    val createdAt: Long = 0L,
    val reviewedAt: Long? = null,
    val violationLevel: String = StreamViolationLevel.NONE.name,
    val violationReason: String? = null,
    val quotaConsumed: Boolean = false,
    val quotaConsumedAt: Long? = null,
    val reviewerUid: String? = null,
    val publishedFileId: Long? = null,
    val pCloudAudioName: String = "",
    val pCloudLyricsName: String = "",
    val telegramMessageId: Long? = null,
    val submissionDestination: String = "",
    val processedBitrateKbps: Int = 0,
    val coverEmbedded: Boolean = false,
    val lyricsFileType: String = "",
    val publishedAt: Long? = null,
    val liveAt: Long? = null,
    val liveNotifiedAt: Long? = null
)

data class StreamArtistProfile(
    val uid: String = "",
    val artistId: String = "",
    val artistName: String = "",
    val photoUrl: String = "",
    val createdAt: Long = 0L,
    val updatedAt: Long = 0L
)

data class StreamTimelineEntry(
    val fileId: Long,
    val playCount: Int,
    val qualifiedAt: Long
)

data class StreamCatalogCandidate(
    val fileId: Long,
    val title: String,
    val artist: String,
    val genre: String = ""
)

data class StreamIntegrityAlert(
    val id: String = "",
    val type: String = "",
    val targetId: String = "",
    val uid: String = "",
    val message: String = "",
    val status: String = "OPEN",
    val countInMinute: Long = 0L,
    val createdAt: Long = 0L
)

data class StreamArtistSongAnalytics(
    val fileId: Long = 0L, val title: String = "", val genre: String = "",
    val validPlays: Long = 0L, val uniqueListeners: Long = 0L, val returningPlays: Long = 0L,
    val listeningMs: Long = 0L, val completions: Long = 0L, val replays: Long = 0L, val skips: Long = 0L,
    val earlySkips: Long = 0L, val retentionSum: Double = 0.0, val retentionSamples: Long = 0L,
    val likes: Long = 0L, val followersGenerated: Long = 0L,
    val shares: Long = 0L, val videoShares: Long = 0L, val videoGenerations: Long = 0L, val videoExports: Long = 0L,
    val organicPlays: Long = 0L, val boostedPlays: Long = 0L, val growthPercent: Double = 0.0,
    val publishedAt: Long = 0L, val sources: Map<String, Long> = emptyMap()
) {
    val retention: Double get() = if (retentionSamples > 0) (retentionSum / retentionSamples).coerceIn(0.0, 1.0) else 0.0
}

data class StreamArtistAnalyticsSnapshot(
    val artistId: String = "", val artistName: String = "",
    val validPlays: Long = 0L, val uniqueListeners: Long = 0L, val newListeners: Long = 0L,
    val returningListeners: Long = 0L, val returningPlays: Long = 0L, val followerListeners: Long = 0L,
    val averageFrequency: Double = 0.0, val listeningMs: Long = 0L,
    val followers: Long = 0L, val newFollowers: Long = 0L, val likes: Long = 0L, val publishedSongs: Long = 0L,
    val shares: Long = 0L, val videoShares: Long = 0L, val videoGenerations: Long = 0L, val videoExports: Long = 0L,
    val organicPlays: Long = 0L, val boostedPlays: Long = 0L, val completions: Long = 0L, val skips: Long = 0L,
    val earlySkips: Long = 0L, val playGrowthPercent: Double = 0.0, val sources: Map<String, Long> = emptyMap(),
    val hourly: Map<Int, Long> = emptyMap(), val daily: Map<String, Long> = emptyMap(),
    val dailyListeningMs: Map<String, Long> = emptyMap(), val dailyFollowers: Map<String, Long> = emptyMap(),
    val heatmap: Map<String, Map<Int, Long>> = emptyMap(), val weekday: Map<String, Long> = emptyMap(),
    val genres: Map<String, Long> = emptyMap(), val songs: List<StreamArtistSongAnalytics> = emptyList(),
    val pendingSubmissions: Long = 0L, val approvedSubmissions: Long = 0L, val rejectedSubmissions: Long = 0L,
    val periodStartMs: Long = 0L, val periodEndMs: Long = 0L
) {
    val listeningHours: Double get() = listeningMs / 3_600_000.0
}

data class StreamCreatorProfile(
    val uid: String,
    val credibilityBase: Double = 10.0,
    val credibilityUpdatedAt: Long = System.currentTimeMillis(),
    val submissionSuspendedUntil: Long? = null,
    val indefiniteSuspension: Boolean = false,
    val activeViolationCount30d: Int = 0
) {
    fun currentCredibility(now: Long = System.currentTimeMillis()): Double {
        val days = ((now - credibilityUpdatedAt).coerceAtLeast(0L) / 86_400_000L).toInt()
        return (credibilityBase + days).coerceIn(0.0, 10.0)
    }
    fun canSubmit(now: Long = System.currentTimeMillis()): Boolean = !indefiniteSuspension && (submissionSuspendedUntil ?: 0L) <= now
}

data class StreamContentReport(
    val id: String = "",
    val reporterUid: String = "",
    val fileId: Long = 0L,
    val title: String = "",
    val artist: String = "",
    val reason: String = "",
    val details: String = "",
    val status: String = "OPEN",
    val createdAt: Long = 0L,
    val reviewedAt: Long? = null,
    val reviewerUid: String? = null
)

data class SubmissionQuota(val daily: Int, val monthly: Int)
fun submissionQuota(tier: MembershipTier): SubmissionQuota = when (commercialTier(tier)) {
    MembershipTier.FREE -> SubmissionQuota(Int.MAX_VALUE, 3)
    MembershipTier.PRATA -> SubmissionQuota(Int.MAX_VALUE, 10)
    MembershipTier.OURO -> SubmissionQuota(Int.MAX_VALUE, 20)
    MembershipTier.DIAMANTE -> SubmissionQuota(Int.MAX_VALUE, 30)
    else -> SubmissionQuota(Int.MAX_VALUE, 10)
}

object SonusStreamRulesText {
    val highlights = listOf(
        "Envie somente músicas, letras, capas e vozes que você tem direito de publicar.",
        "Não envie músicas comerciais de terceiros, samples sem autorização ou imitação de voz/identidade sem permissão.",
        "Não aceitamos conteúdo ilegal, sexual explícito, promoção de facções/crime, ameaças, exposição de áudios privados ou material criado apenas para ofender.",
        "Informe no envio quando a música utilizar IA. Voz que imite uma pessoa real exige autorização.",
        "A análise é manual e o prazo varia conforme o plano e o volume atual de envios."
    )
    val details = listOf(
        "Envios podem ser recusados, devolvidos para correção ou gerar restrição temporária ou permanente para novos envios quando houver violação das regras.",
        "Conteúdo publicado pode ser revisado se surgir denúncia de direitos autorais, identidade, privacidade ou conteúdo proibido.",
        "Evite spam, metadados enganosos e reenvios repetidos para tentar burlar a análise.",
        "Ao enviar, você confirma que possui os direitos e autorizações necessários para disponibilizar o conteúdo no SONUS Stream."
    )
}

class SonusStreamPlatformRepository(context: Context) {
    companion object {
        private val localCounterRevision = MutableStateFlow(0L)
        @Volatile private var playCountsSnapshotCache: Pair<Long, Map<Long, Long>>? = null
    }
    private val appContext = context.applicationContext
    private val db = FirebaseDatabase.getInstance()
    private val storage = FirebaseStorage.getInstance()
    private val auth = FirebaseAuth.getInstance()
    private val termsPrefs = appContext.getSharedPreferences("sonus_stream_terms_v1", Context.MODE_PRIVATE)
    private val counterPrefs = appContext.getSharedPreferences("sonus_stream_counter_v3", Context.MODE_PRIVATE)
    private val publicCounterSyncMutex = Mutex()
    private val localStatePrefs = appContext.getSharedPreferences("sonus_stream_local_state_v108", Context.MODE_PRIVATE)
    /** Hash estável do aparelho usado somente para o cooldown anti-loop por dispositivo. */
    private val deviceMetricKey: String by lazy {
        val raw = Settings.Secure.getString(appContext.contentResolver, Settings.Secure.ANDROID_ID).orEmpty().ifBlank { "sonus-device" }
        MessageDigest.getInstance("SHA-256").digest(raw.toByteArray())
            .joinToString("") { "%02x".format(it) }.take(20)
    }
    private val code108ActivatedAt: Long = localStatePrefs.getLong("code108_activated_at", 0L).takeIf { it > 0L }
        ?: System.currentTimeMillis().also { localStatePrefs.edit().putLong("code108_activated_at", it).apply() }

    private fun hiddenRejectedIds(): Set<String> = localStatePrefs.getStringSet("hidden_rejected_ids", emptySet()) ?: emptySet()
    fun isRejectedLocallyHidden(submissionId: String): Boolean = submissionId.isNotBlank() && submissionId in hiddenRejectedIds()

    fun autoLiveAt(submission: StreamSubmission): Long? {
        if (submission.status == StreamSubmissionStatus.PUBLISHED.name) return submission.liveAt ?: submission.publishedAt ?: submission.reviewedAt ?: submission.createdAt
        if (submission.status != StreamSubmissionStatus.APPROVED.name || submission.id.isBlank()) return null
        val key = "auto_live_at_${submission.id}"
        val existing = localStatePrefs.getLong(key, 0L)
        if (existing > 0L) return existing
        val delayMinutes = kotlin.random.Random.nextInt(1, 61).toLong()
        val now = System.currentTimeMillis()
        val approvalAt = (submission.reviewedAt ?: submission.createdAt).takeIf { it > 0L } ?: now
        // Aprovações feitas já na code108 contam a partir da aprovação. Aprovações antigas
        // recebem uma janela nova na migração, para não surgirem todas Ao Vivo de uma vez.
        val anchor = if (approvalAt >= code108ActivatedAt) approvalAt else now
        val scheduled = anchor + delayMinutes * 60_000L
        localStatePrefs.edit().putLong(key, scheduled).putInt("auto_live_delay_${submission.id}", delayMinutes.toInt()).apply()
        return scheduled
    }

    fun isLocallyLive(submission: StreamSubmission, now: Long = System.currentTimeMillis()): Boolean =
        submission.status == StreamSubmissionStatus.PUBLISHED.name || (submission.status == StreamSubmissionStatus.APPROVED.name && (autoLiveAt(submission) ?: Long.MAX_VALUE) <= now)

    fun localPublicationLabel(submission: StreamSubmission, now: Long = System.currentTimeMillis()): String = when {
        isLocallyLive(submission, now) -> "Ao Vivo 🟢"
        submission.status == StreamSubmissionStatus.APPROVED.name -> "Aprovada • preparando publicação"
        else -> runCatching { StreamSubmissionStatus.valueOf(submission.status).label }.getOrDefault(submission.status)
    }

    /** code106: endpoints administrativos são Functions HTTP independentes.
     *  Se uma variável antiga apontar para .../stream, remove esse sufixo antes
     *  de montar /scanApprovedPublicationNow, /hideRejectedSubmission etc. */
    private fun streamBackendBase(): String = BuildConfig.SONUS_STREAM_PROXY_BASE
        .trim().trimEnd('/').removeSuffix("/stream").trimEnd('/')

    fun acceptedTerms(uid: String): Boolean = termsPrefs.getInt("accepted_${uid}", 0) >= SONUS_STREAM_TERMS_VERSION
    fun acceptTerms(uid: String) { termsPrefs.edit().putInt("accepted_${uid}", SONUS_STREAM_TERMS_VERSION).apply() }

    suspend fun artistProfiles(uid: String): List<StreamArtistProfile> {
        // code99: uma identidade artística única nasce da própria conta SONUS.
        // Estruturas multiartista antigas permanecem no Firebase por compatibilidade, mas não bloqueiam o Stream.
        val legacy = runCatching { db.getReference("streamArtistProfiles").child(uid).get().awaitSnapshot() }.getOrNull()
        if (legacy != null && legacy.exists()) {
            val profile = StreamArtistProfile(
                uid = uid,
                artistId = legacy.child("artistId").getValue(String::class.java).orEmpty().ifBlank { "account_$uid" },
                artistName = legacy.child("artistName").getValue(String::class.java).orEmpty(),
                photoUrl = legacy.child("photoUrl").getValue(String::class.java).orEmpty(),
                createdAt = legacy.child("createdAt").getValue(Long::class.java) ?: 0L,
                updatedAt = legacy.child("updatedAt").getValue(Long::class.java) ?: 0L
            )
            if (profile.artistName.isNotBlank()) return listOf(profile)
        }
        return emptyList()
    }

    suspend fun artistProfile(uid: String): StreamArtistProfile? = artistProfiles(uid).firstOrNull()

    /** code99: o artista do cadastro SONUS é a identidade oficial no Stream. Sem Function/404. */
    suspend fun ensureAccountArtistProfile(user: AuthUser, suggestedArtistName: String): StreamArtistProfile {
        val existing = artistProfile(user.uid)
        if (existing != null && existing.artistName.isNotBlank()) {
            val enriched = existing.copy(photoUrl = user.photoUrl.orEmpty().ifBlank { existing.photoUrl })
            runCatching { publishPublicArtistProfile(enriched) }
            return enriched
        }
        val clean = suggestedArtistName.trim().replace(Regex("\\s+"), " ").take(120)
            .ifBlank { user.displayName?.trim()?.take(120).orEmpty() }
        require(clean.length >= 2) { "Configure um nome de artista na sua conta SONUS antes de enviar músicas." }
        val now = System.currentTimeMillis()
        val profile = StreamArtistProfile(
            uid = user.uid,
            artistId = "account_${user.uid}",
            artistName = clean,
            photoUrl = user.photoUrl.orEmpty(),
            createdAt = now,
            updatedAt = now
        )
        db.getReference("streamArtistProfiles").child(user.uid).setValue(
            mapOf(
                "uid" to profile.uid, "artistId" to profile.artistId, "artistName" to profile.artistName,
                "photoUrl" to profile.photoUrl,
                "createdAt" to profile.createdAt, "updatedAt" to profile.updatedAt, "source" to "SONUS_ACCOUNT"
            )
        ).awaitVoid()
        runCatching { publishPublicArtistProfile(profile) }
        return profile
    }

    private suspend fun publishPublicArtistProfile(profile: StreamArtistProfile) {
        if (profile.artistId.isBlank() || profile.uid.isBlank() || profile.artistName.isBlank()) return
        val currentUid = auth.currentUser?.uid.orEmpty()
        if (currentUid != profile.uid) return
        db.getReference("streamArtistPublicProfiles").child(profile.artistId).setValue(
            mapOf(
                "uid" to profile.uid,
                "artistId" to profile.artistId,
                "artistName" to profile.artistName.take(120),
                "photoUrl" to profile.photoUrl.take(1200),
                "updatedAt" to System.currentTimeMillis()
            )
        ).awaitVoid()
    }

    /** code113: publica apenas os dados visuais mínimos necessários para o card/perfil público. */
    suspend fun syncCurrentArtistPublicProfile(): Result<Unit> = runCatching {
        val firebaseUser = auth.currentUser ?: return@runCatching
        val profile = artistProfiles(firebaseUser.uid).firstOrNull() ?: return@runCatching
        publishPublicArtistProfile(profile.copy(photoUrl = firebaseUser.photoUrl?.toString().orEmpty().ifBlank { profile.photoUrl }))
    }

    suspend fun publicArtistProfile(artistId: String): StreamArtistProfile? {
        if (artistId.isBlank()) return null
        val snap = runCatching { db.getReference("streamArtistPublicProfiles").child(artistId).get().awaitSnapshot() }.getOrNull() ?: return null
        if (!snap.exists()) return null
        return StreamArtistProfile(
            uid = snap.child("uid").getValue(String::class.java).orEmpty(),
            artistId = snap.child("artistId").getValue(String::class.java).orEmpty().ifBlank { artistId },
            artistName = snap.child("artistName").getValue(String::class.java).orEmpty(),
            photoUrl = snap.child("photoUrl").getValue(String::class.java).orEmpty(),
            updatedAt = snap.child("updatedAt").getValue(Long::class.java) ?: 0L
        )
    }

    /** code101: Analytics exclusivo do SONUS Stream, usando buckets horários internos. */
    suspend fun artistAnalytics(artistId: String, periodDays: Int = 7): StreamArtistAnalyticsSnapshot {
        if (artistId.isBlank()) return StreamArtistAnalyticsSnapshot()
        val uid = auth.currentUser?.uid ?: error("Entre na sua conta SONUS para abrir o Analytics.")
        val ownProfiles = artistProfiles(uid)
        val ownProfile = ownProfiles.firstOrNull { it.artistId == artistId } ?: ownProfiles.firstOrNull()
            ?: return StreamArtistAnalyticsSnapshot(artistId = artistId)
        val singleLegacyProfile = ownProfiles.size == 1

        val now = System.currentTimeMillis()
        val zone = java.time.ZoneId.systemDefault()
        val startMs = when {
            periodDays == -1 -> java.time.YearMonth.now(zone).atDay(1).atStartOfDay(zone).toInstant().toEpochMilli()
            periodDays > 0 -> (now - periodDays.toLong() * 86_400_000L).coerceAtLeast(0L)
            else -> 0L
        }
        val periodLength = if (startMs > 0L) (now - startMs).coerceAtLeast(1L) else 0L
        val previousStartMs = if (startMs > 0L) (startMs - periodLength).coerceAtLeast(0L) else 0L

        // code111: use the creator's own published submissions as the primary source of song IDs.
        // This avoids Analytics falling to zero when catalog metadata is delayed or incomplete.
        val ownPublished = runCatching { ownSubmissions(uid) }.getOrDefault(emptyList())
            .asSequence()
            .filter { it.status == StreamSubmissionStatus.PUBLISHED.name && (it.publishedFileId ?: 0L) > 0L }
            .filter { it.artistId == artistId || it.artistName.equals(ownProfile.artistName, ignoreCase = true) || (singleLegacyProfile && it.artistId.isBlank()) }
            .map { item ->
                val fid = item.publishedFileId ?: 0L
                Triple(fid, item.title.ifBlank { "Faixa $fid" }, item.genre)
            }
            .toList()

        // Keep the public publication index as a compatibility/fallback source for older releases.
        val indexedPublished = runCatching { db.getReference("streamPublishedArtists").get().awaitSnapshot() }.getOrNull()
            ?.children?.mapNotNull { n ->
                val fid = n.child("fileId").getValue(Long::class.java) ?: n.key?.toLongOrNull() ?: return@mapNotNull null
                val aid = n.child("artistId").getValue(String::class.java).orEmpty()
                val owner = n.child("uid").getValue(String::class.java).orEmpty()
                val canonicalName = n.child("artistName").getValue(String::class.java).orEmpty()
                if (!(aid == artistId || canonicalName.equals(ownProfile.artistName, true) || (singleLegacyProfile && owner == uid && aid.isBlank()))) return@mapNotNull null
                Triple(fid, n.child("title").getValue(String::class.java).orEmpty().ifBlank { "Faixa $fid" }, n.child("genre").getValue(String::class.java).orEmpty())
            }.orEmpty()

        val published = (ownPublished + indexedPublished).distinctBy { it.first }

        val statsRoot = db.getReference("streamStats").get().awaitSnapshot()

        data class Bucket(
            val hourEpoch: Long,
            val views: Long,
            val uniqueListeners: Long,
            val listeningMs: Long,
            val completions: Long,
            val replays: Long,
            val skips: Long,
            val earlySkips: Long,
            val likes: Long,
            val shares: Long,
            val videoShares: Long,
            val videoGenerations: Long,
            val videoExports: Long,
            val sources: Map<String, Long>
        )

        suspend fun bucketsFor(fileId: Long): List<Bucket> {
            val snap = runCatching { db.getReference("streamMetricBuckets").child(fileId.toString()).get().awaitSnapshot() }.getOrNull()
                ?: return emptyList()
            return snap.children.mapNotNull { b ->
                val hour = b.key?.toLongOrNull() ?: return@mapNotNull null
                val sourceMap = b.child("sources").children.mapNotNull { c ->
                    val key = c.key ?: return@mapNotNull null
                    key to (c.getValue(Long::class.java) ?: 0L)
                }.toMap()
                Bucket(
                    hourEpoch = hour,
                    views = b.child("views").getValue(Long::class.java) ?: 0L,
                    uniqueListeners = b.child("uniqueListeners").getValue(Long::class.java) ?: 0L,
                    listeningMs = b.child("listeningMs").getValue(Long::class.java) ?: 0L,
                    completions = b.child("completions").getValue(Long::class.java) ?: 0L,
                    replays = b.child("replays").getValue(Long::class.java) ?: 0L,
                    skips = b.child("skips").getValue(Long::class.java) ?: 0L,
                    earlySkips = b.child("earlySkips").getValue(Long::class.java) ?: 0L,
                    likes = b.child("likes").getValue(Long::class.java) ?: 0L,
                    shares = b.child("shares").getValue(Long::class.java) ?: 0L,
                    videoShares = b.child("videoShares").getValue(Long::class.java) ?: 0L,
                    videoGenerations = b.child("videoGenerations").getValue(Long::class.java) ?: 0L,
                    videoExports = b.child("videoExports").getValue(Long::class.java) ?: 0L,
                    sources = sourceMap
                )
            }
        }

        val daily = linkedMapOf<String, Long>()
        val dailyListening = linkedMapOf<String, Long>()
        val hourly = linkedMapOf<Int, Long>()
        val heatmapMutable = linkedMapOf<String, MutableMap<Int, Long>>()
        val weekday = linkedMapOf<String, Long>()
        val sourceTotals = linkedMapOf<String, Long>()
        val weekdayNames = mapOf(1 to "Seg", 2 to "Ter", 3 to "Qua", 4 to "Qui", 5 to "Sex", 6 to "Sáb", 7 to "Dom")
        var previousPeriodViews = 0L

        val songs = published.map { (fid, title, genre) ->
            val stat = statsRoot.child(fid.toString())
            val allBuckets = bucketsFor(fid)
            val currentBuckets = if (startMs <= 0L) allBuckets else allBuckets.filter { it.hourEpoch * 3_600_000L >= startMs && it.hourEpoch * 3_600_000L <= now }
            if (startMs > 0L) {
                previousPeriodViews += allBuckets.filter {
                    val ms = it.hourEpoch * 3_600_000L
                    ms >= previousStartMs && ms < startMs
                }.sumOf { it.views }
            }

            currentBuckets.forEach { bucket ->
                val dt = java.time.Instant.ofEpochMilli(bucket.hourEpoch * 3_600_000L).atZone(zone)
                val dateKey = dt.toLocalDate().toString()
                daily[dateKey] = (daily[dateKey] ?: 0L) + bucket.views
                dailyListening[dateKey] = (dailyListening[dateKey] ?: 0L) + bucket.listeningMs
                hourly[dt.hour] = (hourly[dt.hour] ?: 0L) + bucket.views
                val hm = heatmapMutable.getOrPut(dateKey) { linkedMapOf() }
                hm[dt.hour] = (hm[dt.hour] ?: 0L) + bucket.views
                val wd = weekdayNames[dt.dayOfWeek.value] ?: dt.dayOfWeek.name.take(3)
                weekday[wd] = (weekday[wd] ?: 0L) + bucket.views
                bucket.sources.forEach { (key, value) -> sourceTotals[key] = (sourceTotals[key] ?: 0L) + value }
            }

            val useBuckets = startMs > 0L && allBuckets.isNotEmpty()
            val plays = if (useBuckets) currentBuckets.sumOf { it.views } else stat.child("playCount").getValue(Long::class.java) ?: 0L
            val unique = if (useBuckets) currentBuckets.sumOf { it.uniqueListeners } else stat.child("uniqueListeners").getValue(Long::class.java) ?: 0L
            val listening = if (useBuckets) currentBuckets.sumOf { it.listeningMs } else stat.child("listeningMs").getValue(Long::class.java) ?: 0L
            val completions = if (useBuckets) currentBuckets.sumOf { it.completions } else stat.child("completions").getValue(Long::class.java) ?: 0L
            val replays = if (useBuckets) currentBuckets.sumOf { it.replays } else stat.child("replayCount").getValue(Long::class.java) ?: 0L
            val skips = if (useBuckets) currentBuckets.sumOf { it.skips } else stat.child("skips").getValue(Long::class.java) ?: 0L
            val earlySkips = if (useBuckets) currentBuckets.sumOf { it.earlySkips } else stat.child("earlySkips").getValue(Long::class.java) ?: 0L
            val likes = if (useBuckets) currentBuckets.sumOf { it.likes }.coerceAtLeast(0L) else stat.child("likes").getValue(Long::class.java) ?: 0L
            val shares = if (useBuckets) currentBuckets.sumOf { it.shares }.coerceAtLeast(0L) else stat.child("shares").getValue(Long::class.java) ?: 0L
            val videoShares = if (useBuckets) currentBuckets.sumOf { it.videoShares }.coerceAtLeast(0L) else stat.child("videoShares").getValue(Long::class.java) ?: 0L
            val videoGenerations = if (useBuckets) currentBuckets.sumOf { it.videoGenerations }.coerceAtLeast(0L) else stat.child("videoGenerations").getValue(Long::class.java) ?: 0L
            val videoExports = if (useBuckets) currentBuckets.sumOf { it.videoExports }.coerceAtLeast(0L) else stat.child("videoExports").getValue(Long::class.java) ?: 0L
            val samples = stat.child("retentionSamples").getValue(Long::class.java) ?: 0L
            val bpTotal = stat.child("retentionBpTotal").getValue(Long::class.java) ?: 0L

            StreamArtistSongAnalytics(
                fileId = fid,
                title = title,
                genre = genre,
                validPlays = plays,
                uniqueListeners = unique,
                returningPlays = (plays - unique).coerceAtLeast(0L),
                listeningMs = listening,
                completions = completions,
                replays = replays,
                skips = skips,
                earlySkips = earlySkips,
                retentionSum = bpTotal / 10_000.0,
                retentionSamples = samples,
                likes = likes,
                followersGenerated = 0L,
                shares = shares,
                videoShares = videoShares,
                videoGenerations = videoGenerations,
                videoExports = videoExports,
                organicPlays = plays,
                boostedPlays = 0L,
                publishedAt = stat.child("publishedAt").getValue(Long::class.java) ?: 0L,
                sources = currentBuckets.flatMap { it.sources.entries }.groupBy { it.key }.mapValues { (_, values) -> values.sumOf { it.value } }
            )
        }.sortedByDescending { it.validPlays }

        val followers = db.getReference("streamArtistPublicStats").child(artistId).child("followers").get().awaitSnapshot().getValue(Long::class.java) ?: 0L
        val artistBuckets = runCatching { db.getReference("streamArtistMetricBuckets").child(artistId).get().awaitSnapshot() }.getOrNull()
        var newFollowers = 0L
        val dailyFollowers = linkedMapOf<String, Long>()
        artistBuckets?.children?.forEach { b ->
            val hour = b.key?.toLongOrNull() ?: return@forEach
            val ms = hour * 3_600_000L
            if (startMs <= 0L || ms >= startMs) {
                val value = b.child("followers").getValue(Long::class.java) ?: 0L
                newFollowers += value
                val dateKey = java.time.Instant.ofEpochMilli(ms).atZone(zone).toLocalDate().toString()
                dailyFollowers[dateKey] = (dailyFollowers[dateKey] ?: 0L) + value
            }
        }

        val ownSubmissions = ownSubmissions(uid).filter { it.artistId == artistId || it.artistName.equals(ownProfile.artistName, true) }
        val pending = ownSubmissions.count { it.status in setOf(StreamSubmissionStatus.RECEIVED.name, StreamSubmissionStatus.REVIEWING.name, StreamSubmissionStatus.CHANGES_REQUESTED.name) }.toLong()
        val approved = ownSubmissions.count { it.status in setOf(StreamSubmissionStatus.APPROVED.name, StreamSubmissionStatus.PUBLISHED.name) }.toLong()
        val rejected = ownSubmissions.count { it.status == StreamSubmissionStatus.REJECTED.name }.toLong()

        val totalPlays = songs.sumOf { it.validPlays }
        val totalUnique = songs.sumOf { it.uniqueListeners }
        val growth = if (startMs > 0L && previousPeriodViews > 0L) ((totalPlays - previousPeriodViews).toDouble() / previousPeriodViews.toDouble()) * 100.0 else 0.0
        return StreamArtistAnalyticsSnapshot(
            artistId = artistId,
            artistName = ownProfile.artistName,
            validPlays = totalPlays,
            uniqueListeners = totalUnique,
            newListeners = totalUnique,
            returningListeners = songs.sumOf { it.returningPlays },
            returningPlays = songs.sumOf { it.returningPlays },
            averageFrequency = if (totalUnique > 0L) totalPlays.toDouble() / totalUnique else 0.0,
            listeningMs = songs.sumOf { it.listeningMs },
            followers = followers,
            newFollowers = newFollowers.coerceAtLeast(0L),
            likes = songs.sumOf { it.likes },
            publishedSongs = songs.size.toLong(),
            shares = songs.sumOf { it.shares },
            videoShares = songs.sumOf { it.videoShares },
            videoGenerations = songs.sumOf { it.videoGenerations },
            videoExports = songs.sumOf { it.videoExports },
            organicPlays = totalPlays,
            completions = songs.sumOf { it.completions },
            skips = songs.sumOf { it.skips },
            earlySkips = songs.sumOf { it.earlySkips },
            playGrowthPercent = growth,
            sources = sourceTotals,
            hourly = hourly,
            daily = daily,
            dailyListeningMs = dailyListening,
            dailyFollowers = dailyFollowers,
            heatmap = heatmapMutable.mapValues { it.value.toMap() },
            weekday = weekday,
            genres = songs.groupBy { it.genre.ifBlank { "Outros" } }.mapValues { (_, values) -> values.sumOf { it.validPlays } },
            songs = songs,
            pendingSubmissions = pending,
            approvedSubmissions = approved,
            rejectedSubmissions = rejected,
            periodStartMs = startMs,
            periodEndMs = now
        )
    }

    suspend fun artistMilestones(artistId: String): List<String> {
        val a = artistAnalytics(artistId, 0)
        val out = mutableListOf<String>()
        listOf(50L,100L,250L,500L,1000L).filter { a.followers >= it }.forEach { out += "$it seguidores" }
        listOf(500.0,1000.0,2500.0,5000.0).filter { a.listeningHours >= it }.forEach { out += "${it.toInt()} horas ouvidas" }
        return out
    }

    suspend fun ownerStreamHealth(): Map<String,Boolean> {
        val databaseOk = runCatching { db.getReference("streamStats").limitToFirst(1).get().awaitSnapshot(); true }.getOrDefault(false)
        val telegramUploadOk = withContext(Dispatchers.IO) {
            runCatching {
                val base = BuildConfig.SONUS_TELEGRAM_UPLOAD_BASE.trim().trimEnd('/')
                if (!base.startsWith("https://")) return@runCatching false
                val c = (URL("$base/health").openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"; connectTimeout = 6_000; readTimeout = 6_000
                    setRequestProperty("Accept", "application/json")
                }
                try {
                    val code = c.responseCode
                    val body = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
                    code in 200..299 && runCatching { JSONObject(body).optBoolean("ok", false) }.getOrDefault(false)
                } finally { c.disconnect() }
            }.getOrDefault(false)
        }
        return mapOf("audio" to true, "catalog" to true, "counter" to databaseOk, "artists" to databaseOk, "database" to databaseOk, "storage" to true, "telegramUpload" to telegramUploadOk, "analytics" to databaseOk, "notifications" to true)
    }

    suspend fun followArtist(artistId: String, following: Boolean): Result<Pair<Boolean,Long>> = runCatching {
        val uid = auth.currentUser?.uid ?: error("Entre na sua conta SONUS para seguir artistas.")
        require(artistId.isNotBlank()) { "Artista inválido." }
        val root = db.reference
        val current = root.child("streamFollowingByUser").child(uid).child(artistId).get().awaitSnapshot().exists()
        if (current == following) {
            val count = root.child("streamArtistPublicStats").child(artistId).child("followers").get().awaitSnapshot().getValue(Long::class.java) ?: 0L
            return@runCatching following to count
        }
        val delta = if (following) 1L else -1L
        val now = System.currentTimeMillis()
        val updates = mutableMapOf<String, Any?>()
        updates["streamFollowingByUser/$uid/$artistId"] = if (following) mapOf("following" to true, "followedAt" to now) else null
        updates["streamArtistFollowers/$artistId/users/$uid"] = if (following) mapOf("following" to true, "followedAt" to now) else null
        updates["streamArtistFollowers/$artistId/count"] = ServerValue.increment(delta)
        updates["streamArtistPublicStats/$artistId/followers"] = ServerValue.increment(delta)
        updates["streamArtistPublicStats/$artistId/updatedAt"] = now
        root.updateChildren(updates).awaitVoid()
        if (following) {
            recordTrafficAndMaybeAlert("FOLLOWERS", artistId, 100L)
            recordArtistMetricBucket(artistId, 1L)
        }
        val count = root.child("streamArtistPublicStats").child(artistId).child("followers").get().awaitSnapshot().getValue(Long::class.java) ?: 0L
        following to count.coerceAtLeast(0L)
    }

    suspend fun artistFavoriteState(artistId: String): Boolean {
        val uid = auth.currentUser?.uid ?: return false
        if (artistId.isBlank()) return false
        return runCatching {
            db.getReference("streamArtistFavoritesByUser").child(uid).child(artistId).get().awaitSnapshot().exists()
        }.getOrDefault(false)
    }

    suspend fun favoriteArtist(artistId: String, liked: Boolean): Result<Boolean> = runCatching {
        val uid = auth.currentUser?.uid ?: error("Entre na sua conta SONUS para favoritar artistas.")
        require(artistId.isNotBlank()) { "Artista inválido." }
        val ref = db.getReference("streamArtistFavoritesByUser").child(uid).child(artistId)
        if (liked) ref.setValue(mapOf("liked" to true, "likedAt" to System.currentTimeMillis())).awaitVoid()
        else ref.removeValue().awaitVoid()
        liked
    }

    suspend fun requestArtistNameChange(user: AuthUser, artistId: String, currentName: String, requestedName: String): Result<String> = runCatching {
        val clean = requestedName.trim().take(120)
        require(clean.length >= 2 && !clean.equals(currentName, true)) { "Informe um novo nome artístico." }
        val now = System.currentTimeMillis()
        val profileSnap = db.getReference("streamArtistProfiles").child(user.uid).get().awaitSnapshot()
        val lastApproved = profileSnap.child("lastNameChangeAt").getValue(Long::class.java) ?: 0L
        require(lastApproved <= 0L || now - lastApproved >= 30L * 86_400_000L) { "Uma alteração de nome já foi aprovada nos últimos 30 dias." }
        val ref = db.getReference("supportTickets").push()
        val id = ref.key ?: UUID.randomUUID().toString()
        val body = "Solicito alteração do nome artístico no SONUS Stream. Nome atual: $currentName. Novo nome solicitado: $clean."
        ref.setValue(mapOf(
            "id" to id, "ownerUid" to user.uid, "publicUserId" to sonusPublicId(user.uid),
            "category" to "STREAM_SUBMISSION", "status" to "NEW", "subject" to "Alterar nome do artista",
            "lastMessage" to body.take(240), "createdAt" to now, "updatedAt" to now,
            "unreadForUser" to false, "unreadForTeam" to true,
            "technical" to mapOf("requestType" to "ARTIST_NAME_CHANGE", "artistId" to artistId, "currentArtistName" to currentName, "requestedArtistName" to clean)
        )).awaitVoid()
        ref.child("messages").push().setValue(mapOf("senderUid" to user.uid,"senderRole" to "USER","body" to body,"createdAt" to now)).awaitVoid()
        SonusNotificationCenter.add(appContext,"Solicitação enviada","O suporte recebeu seu pedido de alteração do nome artístico.","SUPPORT","SUPPORT",false)
        id
    }


    suspend fun profile(uid: String): StreamCreatorProfile {
        val now = System.currentTimeMillis()
        val s = db.getReference("streamCreatorProfiles").child(uid).get().awaitSnapshot()
        val since30d = now - 30L * 86_400_000L
        val recentQualified = runCatching {
            db.getReference("streamViolations").child(uid).get().awaitSnapshot().children.count { n ->
                val created = n.child("createdAt").getValue(Long::class.java) ?: 0L
                val level = n.child("level").getValue(String::class.java).orEmpty()
                created >= since30d && level in setOf(StreamViolationLevel.MEDIUM.name, StreamViolationLevel.SEVERE.name)
            }
        }.getOrDefault(s.child("activeViolationCount30d").getValue(Long::class.java)?.toInt() ?: 0)
        return StreamCreatorProfile(
            uid = uid,
            credibilityBase = s.child("credibilityBase").getValue(Double::class.java) ?: s.child("credibilityBase").getValue(Long::class.java)?.toDouble() ?: 10.0,
            credibilityUpdatedAt = s.child("credibilityUpdatedAt").getValue(Long::class.java) ?: now,
            submissionSuspendedUntil = s.child("submissionSuspendedUntil").getValue(Long::class.java),
            indefiniteSuspension = s.child("indefiniteSuspension").getValue(Boolean::class.java) == true,
            activeViolationCount30d = recentQualified
        )
    }

    suspend fun ownSubmissions(uid: String): List<StreamSubmission> {
        val s = db.getReference("streamSubmissions").orderByChild("uid").equalTo(uid).get().awaitSnapshot()
        return s.children.mapNotNull(::submissionFrom).sortedByDescending { it.createdAt }
    }

    suspend fun allSubmissions(): List<StreamSubmission> {
        val s = db.getReference("streamSubmissions").get().awaitSnapshot()
        return s.children.mapNotNull(::submissionFrom).sortedByDescending { it.createdAt }
    }

    fun submissionFlow(uid: String?, team: Boolean): Flow<List<StreamSubmission>> = callbackFlow {
        val query: Query = if (team) db.getReference("streamSubmissions") else db.getReference("streamSubmissions").orderByChild("uid").equalTo(uid.orEmpty())
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val nodes = if (team) snapshot.children.toList() else snapshot.children.filter { (it.child("userHiddenAt").getValue(Long::class.java) ?: 0L) <= 0L }
                val list = nodes.mapNotNull(::submissionFrom)
                trySend(if(team) list.sortedWith(compareByDescending<StreamSubmission>{it.priority}.thenBy{it.createdAt}) else list.sortedByDescending { it.createdAt })
            }
            override fun onCancelled(error: DatabaseError) { trySend(emptyList()) }
        }
        query.addValueEventListener(listener)
        awaitClose { query.removeEventListener(listener) }
    }

    suspend fun bonusUploads(uid: String): Int {
        val key=YearMonth.now().toString()
        return runCatching { db.getReference("streamCreatorBonuses").child(uid).child("uploads").child(key).get().awaitSnapshot().getValue(Long::class.java)?.toInt() ?: 0 }.getOrDefault(0)
    }

    suspend fun quotaUsage(uid: String, tier: MembershipTier): Pair<Int, Int> {
        val list = ownSubmissions(uid)
        val now = LocalDate.now()
        val ym = YearMonth.from(now)
        fun consumes(s: StreamSubmission): Boolean = s.quotaConsumed || s.status == StreamSubmissionStatus.APPROVED.name || s.status == StreamSubmissionStatus.PUBLISHED.name
        fun quotaAt(s: StreamSubmission): Long = s.quotaConsumedAt ?: s.reviewedAt ?: s.createdAt
        val day = list.count { consumes(it) && Instant.ofEpochMilli(quotaAt(it)).atZone(java.time.ZoneId.systemDefault()).toLocalDate() == now }
        val month = list.count { consumes(it) && YearMonth.from(Instant.ofEpochMilli(quotaAt(it)).atZone(java.time.ZoneId.systemDefault()).toLocalDate()) == ym }
        return day to month
    }

    suspend fun submit(
        user: AuthUser,
        tier: MembershipTier,
        title: String,
        artist: String,
        genre: String,
        lyricsFile: Uri?,
        aiUsed: Boolean,
        aiImitatesRealPerson: Boolean,
        audio: Uri,
        cover: Uri,
        onProgress: (Int, String) -> Unit = { _, _ -> }
    ): Result<String> = runCatching {
        require(acceptedTerms(user.uid)) { "Aceite as regras do SONUS Stream antes de enviar." }
        require(title.trim().isNotBlank() && artist.trim().isNotBlank() && genre.trim().isNotBlank()) { "Preencha título, artista e gênero." }
        require(genre in SONUS_STREAM_CANONICAL_GENRES) { "Selecione um gênero válido." }
        val selectedArtist = artistProfiles(user.uid).firstOrNull() ?: ensureAccountArtistProfile(user, artist)
        val fixedArtist = selectedArtist.artistName
        require(!aiImitatesRealPerson) { "Envios que imitam pessoa real precisam de autorização e revisão especial." }
        val profile = profile(user.uid)
        require(profile.canSubmit()) { "Sua conta está temporariamente suspensa para novos envios." }
        val quota = submissionQuota(tier)
        val (usedDay, usedMonth) = quotaUsage(user.uid, tier)
        val extraUploads = bonusUploads(user.uid)
        val ownerUnlimited = user.role == AccountRole.OWNER
        if (!ownerUnlimited) {
            require(usedDay < quota.daily && usedMonth < quota.monthly + extraUploads) { "Você atingiu o limite de envios do seu plano neste período." }
        }
        val commercial = commercialTier(tier)
        val pendingLimit = when (commercial) { MembershipTier.FREE -> 2; MembershipTier.PRATA -> 4; MembershipTier.OURO -> 8; MembershipTier.DIAMANTE -> 12; else -> 4 }
        val pending = ownSubmissions(user.uid).count { it.status in setOf(StreamSubmissionStatus.RECEIVED.name, StreamSubmissionStatus.REVIEWING.name, StreamSubmissionStatus.CHANGES_REQUESTED.name) }
        if (!ownerUnlimited) {
            require(pending < pendingLimit) { "Você já tem $pending envio(s) aguardando análise. Aguarde uma revisão antes de enviar mais." }
        }

        val audioMeta = uriMeta(audio)
        val coverMeta = uriMeta(cover)
        val audioExt = audioMeta.name.substringAfterLast('.', "").lowercase(Locale.US)
        require(audioExt in setOf("mp3", "wav") || audioMeta.mime in setOf("audio/mpeg", "audio/mp3", "audio/wav", "audio/x-wav", "audio/wave")) {
            "Envie um arquivo de áudio MP3 ou WAV."
        }
        require(audioMeta.size <= 0L || audioMeta.size <= SONUS_STREAM_UPLOAD_MAX_SOURCE_BYTES) { "O arquivo de áudio é grande demais para processamento no aparelho." }
        require(coverMeta.mime.startsWith("image/") || coverMeta.name.substringAfterLast('.', "").lowercase(Locale.US) in setOf("jpg","jpeg","png","webp")) { "Selecione uma capa em formato de imagem." }
        require(coverMeta.size <= 0L || coverMeta.size <= 20L * 1024L * 1024L) { "A capa é grande demais." }
        requireSquareCover(cover)

        var lyrics = ""
        var lrc = ""
        var lyricsFileType = ""
        var lyricsOriginalName = ""
        if (lyricsFile != null) {
            val meta = uriMeta(lyricsFile)
            require(meta.size <= 0L || meta.size <= 512L * 1024L) { "O arquivo de letra é grande demais." }
            val document = withContext(Dispatchers.IO) { SonusLyricsImporter.read(appContext, lyricsFile, 80_000).getOrThrow() }
            if (document.format == "LRC") lrc = document.text else lyrics = document.text
            lyricsFileType = document.format
            lyricsOriginalName = document.name
        }

        val id = db.getReference("streamSubmissions").push().key ?: UUID.randomUUID().toString()
        val musicId = sonusMusicPublicId(id)
        val remoteBase = "${safe(musicId)}_${safe(fixedArtist)}_${safe(title.trim())}"
        val remoteAudioName = "$remoteBase.mp3"
        val workDir = File(appContext.cacheDir, "sonus_stream_submit/$id").apply { mkdirs() }
        val processedFile = File(workDir, remoteAudioName)
        val standaloneLyricsFile = if (lyricsFileType == "LRC" && lrc.isNotBlank() && lyricsFile != null) {
            // Preserve os bytes do LRC selecionado para o arquivo separado de segurança.
            // A versão textual validada continua sendo usada para incorporar a letra ao MP3.
            withContext(Dispatchers.IO) {
                File(workDir, "${safe(musicId)}.lrc").apply {
                    appContext.contentResolver.openInputStream(lyricsFile)?.use { input ->
                        outputStream().use { output -> input.copyTo(output, 16 * 1024) }
                    } ?: error("Não foi possível reabrir o LRC selecionado.")
                }
            }
        } else null
        try {
            onProgress(2,"Processando...")
            val conversion = withContext(Dispatchers.IO) {
                AudioConversionEngine.convert(
                    context = appContext,
                    inputUri = audio,
                    outputUri = Uri.fromFile(processedFile),
                    preset = AudioConversionPreset(
                        format = "MP3",
                        sampleRateHz = 44_100,
                        bitDepth = 16,
                        bitrateKbps = SONUS_STREAM_UPLOAD_BITRATE_KBPS,
                        channels = 2,
                        genre = genre.trim().take(80)
                    ),
                    tags = AudioTrackTags(
                        title = title.trim().take(120),
                        artist = fixedArtist,
                        albumArtist = fixedArtist,
                        genre = genre.trim().take(80),
                        lyrics = if (lyrics.isNotBlank()) lyrics else lrc,
                        sonusLrc = lrc,
                        sonusMusicId = musicId
                    ),
                    artworkUri = cover
                )
            }
            require(conversion.success && processedFile.exists() && processedFile.length() > 0L) { conversion.message.ifBlank { "Não foi possível processar o áudio." } }
            onProgress(58,"Validando arquivo final...")
            withContext(Dispatchers.IO) {
                val finalUri = Uri.fromFile(processedFile)
                val finalMetadata = AudioToolEngine.readMetadata(appContext, finalUri)
                require(finalMetadata.title.trim().equals(title.trim(), ignoreCase = true)) { "Falha ao confirmar o título incorporado no MP3." }
                require(finalMetadata.artist.trim().equals(fixedArtist.trim(), ignoreCase = true)) { "Falha ao confirmar o artista incorporado no MP3." }
                require(SonusMediaStandards.canonicalGenre(finalMetadata.genre) == SonusMediaStandards.canonicalGenre(genre)) { "Falha ao confirmar o gênero incorporado no MP3." }
                require(AudioToolEngine.readEmbeddedArtwork(appContext, finalUri) != null) { "Falha ao confirmar a capa incorporada no MP3." }
                if (lyrics.isNotBlank() || lrc.isNotBlank()) {
                    require(finalMetadata.lyrics.isNotBlank()) { "Falha ao confirmar a letra incorporada no MP3." }
                }
            }
            onProgress(65,"Enviando...")
            // code105: mantém a letra incorporada no MP3 e envia o LRC original separado como segurança operacional.
            val telegramMessageId = withContext(Dispatchers.IO) {
                uploadSubmissionToTelegramWorker(
                    audioFile = processedFile,
                    audioRemoteName = remoteAudioName,
                    lyricsFile = standaloneLyricsFile,
                    title = title.trim().take(120),
                    artist = fixedArtist,
                    genre = genre.trim().take(80),
                    submissionId = id,
                    musicId = musicId,
                    usesAi = aiUsed
                ) { sent,total ->
                    val pct = 65 + ((sent * 28L) / total.coerceAtLeast(1L)).toInt().coerceIn(0,28)
                    onProgress(pct,"Enviando...")
                }
            }

            onProgress(95,"Finalizando...")
            val now = System.currentTimeMillis()
            db.getReference("streamSubmissions").child(id).setValue(
                mapOf(
                    "id" to id,
                    "musicId" to musicId,
                    "uid" to user.uid,
                    "publicUserId" to sonusPublicId(user.uid),
                    "title" to title.trim().take(120),
                    "artistName" to fixedArtist,
                    "artistId" to selectedArtist.artistId,
                    "genre" to genre.trim().take(80),
                    "lyrics" to lyrics.take(20_000),
                    "lrc" to lrc.take(40_000),
                    "lyricsFileType" to lyricsFileType,
                    "lyricsOriginalName" to lyricsOriginalName,
                    "aiUsed" to aiUsed,
                    "aiImitatesRealPerson" to aiImitatesRealPerson,
                    "status" to StreamSubmissionStatus.RECEIVED.name,
                    "audioStoragePath" to "",
                    "coverStoragePath" to "",
                    "audioDownloadUrl" to "",
                    "coverDownloadUrl" to "",
                    "audioOriginalName" to remoteAudioName,
                    "sourceAudioName" to audioMeta.name,
                    "audioMime" to "audio/mpeg",
                    "coverOriginalName" to coverMeta.name,
                    "coverMime" to coverMeta.mime,
                    "pCloudAudioName" to "",
                    "pCloudLyricsName" to "",
                    "telegramMessageId" to telegramMessageId,
                    "processedBitrateKbps" to SONUS_STREAM_UPLOAD_BITRATE_KBPS,
                    "coverEmbedded" to true,
                    "submissionDestination" to "TELEGRAM_SONUS_ARTISTAS",
                    "planAtSubmission" to commercial.name,
                    "priority" to when (commercial) { MembershipTier.DIAMANTE -> 2; MembershipTier.OURO -> 1; else -> 0 },
                    "createdAt" to now,
                    "quotaConsumed" to false,
                    "termsVersion" to SONUS_STREAM_TERMS_VERSION
                )
            ).awaitVoid()
            val estimate = analysisEstimate(commercial, pending + 1)
            SonusNotificationCenter.add(appContext, "Música recebida", "${title.trim()} entrou na fila de análise manual. Prazo estimado atual: $estimate.", "STREAM", "STREAM_CREATOR", false)
            onProgress(100,"Finalizando...")
            runCatching { workDir.deleteRecursively() }
            id
        } catch (t:Throwable) {
            // Preserva o arquivo processado para retry/diagnóstico em vez de apagá-lo na falha.
            throw t
        }
    }

    suspend fun deleteRejectedSubmission(user: AuthUser, submission: StreamSubmission): Result<Unit> = runCatching {
        require(user.uid.isNotBlank() && submission.uid == user.uid) { "Você só pode remover seus próprios envios." }
        require(submission.status == StreamSubmissionStatus.REJECTED.name) { "Somente envios rejeitados podem ser removidos da lista." }
        val updated = hiddenRejectedIds().toMutableSet().apply { add(submission.id) }
        localStatePrefs.edit().putStringSet("hidden_rejected_ids", updated).apply()
    }


    /**
     * code108: cria/atualiza o vínculo técnico faixa↔artista diretamente no Realtime Database.
     * Não altera o status visual Ao Vivo e não chama Cloud Functions. Só OWNER/SUPPORT consegue
     * escrever em streamPublishedArtists pelas regras atuais.
     */
    suspend fun syncApprovedCatalogLinks(candidates: List<StreamCatalogCandidate>, reviewer: AuthUser): Result<Int> = runCatching {
        require(reviewer.role == AccountRole.OWNER || reviewer.role == AccountRole.SUPPORT) { "Sem permissão para vincular catálogo." }
        if (candidates.isEmpty()) return@runCatching 0
        val approved = allSubmissions().filter { it.status == StreamSubmissionStatus.APPROVED.name || it.status == StreamSubmissionStatus.PUBLISHED.name }
        fun norm(v: String) = java.text.Normalizer.normalize(v.lowercase(Locale.ROOT).trim(), java.text.Normalizer.Form.NFD)
            .replace("\\p{Mn}+".toRegex(), "").replace("[^a-z0-9]+".toRegex(), " ").trim()
        var linked = 0
        for (track in candidates.distinctBy { it.fileId }) {
            if (track.fileId <= 0L) continue
            val existing = runCatching { db.getReference("streamPublishedArtists").child(track.fileId.toString()).get().awaitSnapshot() }.getOrNull()
            if (existing?.exists() == true && existing.child("uid").getValue(String::class.java).orEmpty().isNotBlank()) continue
            val titleN = norm(track.title)
            val artistN = norm(track.artist)
            val matches = approved.filter { norm(it.title) == titleN && norm(it.artistName) == artistN }
            val match = matches.singleOrNull() ?: continue
            val now = System.currentTimeMillis()
            db.getReference("streamPublishedArtists").child(track.fileId.toString()).setValue(mapOf(
                "fileId" to track.fileId, "uid" to match.uid, "artistId" to match.artistId,
                "artistName" to match.artistName, "title" to track.title, "genre" to track.genre,
                "submissionId" to match.id, "musicId" to match.musicId, "linkedAt" to now
            )).awaitVoid()
            db.getReference("streamSubmissions").child(match.id).updateChildren(mapOf(
                "publishedFileId" to track.fileId, "catalogLinkedAt" to now
            )).awaitVoid()
            linked++
        }
        linked
    }

    suspend fun requestPublishedRemoval(user: AuthUser, submission: StreamSubmission, reason: String): Result<String> = runCatching {
        require(user.uid.isNotBlank() && submission.uid == user.uid) { "Esta música não pertence à sua conta." }
        require(submission.status == StreamSubmissionStatus.APPROVED.name || submission.status == StreamSubmissionStatus.PUBLISHED.name) { "A solicitação de remoção é usada para músicas aprovadas ou publicadas." }
        val cleanReason = reason.trim().take(1000)
        require(cleanReason.isNotBlank()) { "Explique brevemente o motivo da remoção." }
        val technical = linkedMapOf(
            "requestType" to "STREAM_REMOVAL",
            "musicId" to submission.musicId.ifBlank { sonusMusicPublicId(submission.id) },
            "submissionId" to submission.id,
            "title" to submission.title,
            "artist" to submission.artistName,
            "artistId" to submission.artistId,
            "ownerUid" to submission.uid,
            "publishedFileId" to (submission.publishedFileId?.toString() ?: ""),
            "status" to submission.status
        )
        SonusSupportRepository(appContext).createTicket(
            user = user,
            category = SupportCategory.STREAM_SUBMISSION,
            text = "Solicito a remoção da música ${submission.title} (${technical["musicId"]}). Motivo: $cleanReason",
            technical = technical
        ).getOrThrow()
    }

    suspend fun contactSupportAboutSubmission(user: AuthUser, submission: StreamSubmission, message: String): Result<String> = runCatching {
        require(user.uid.isNotBlank() && submission.uid == user.uid) { "Esta música não pertence à sua conta." }
        val clean = message.trim().take(2000)
        require(clean.isNotBlank()) { "Escreva uma mensagem para o suporte." }
        SonusSupportRepository(appContext).createTicket(
            user = user,
            category = SupportCategory.STREAM_SUBMISSION,
            text = clean,
            technical = linkedMapOf(
                "musicId" to submission.musicId.ifBlank { sonusMusicPublicId(submission.id) },
                "submissionId" to submission.id,
                "title" to submission.title,
                "artist" to submission.artistName,
                "artistId" to submission.artistId,
                "fileId" to (submission.publishedFileId?.toString() ?: ""),
                "status" to submission.status
            )
        ).getOrThrow()
    }

    suspend fun review(
        submission: StreamSubmission,
        reviewer: AuthUser,
        approve: Boolean,
        violation: StreamViolationLevel = StreamViolationLevel.NONE,
        reason: String = "",
        suspendDays: Int? = null,
        indefinite: Boolean = false
    ): Result<Unit> = runCatching {
        require(reviewer.role == AccountRole.OWNER || reviewer.role == AccountRole.SUPPORT) { "Sem permissão para moderar." }
        val now = System.currentTimeMillis()
        val status = if (approve) StreamSubmissionStatus.APPROVED else StreamSubmissionStatus.REJECTED
        val consumes = approve || violation.consumesQuota
        db.getReference("streamSubmissions").child(submission.id).updateChildren(
            mapOf(
                "status" to status.name,
                "reviewedAt" to now,
                "reviewerUid" to reviewer.uid,
                "violationLevel" to violation.name,
                "violationReason" to reason.trim().take(1000),
                "quotaConsumed" to consumes,
                "quotaConsumedAt" to (if (consumes) now else null)
            )
        ).awaitVoid()

        if (!approve && violation != StreamViolationLevel.NONE) applyViolation(submission.uid, submission.id, reviewer.uid, violation, reason, suspendDays, indefinite)
        db.getReference("streamUserNotifications").child(submission.uid).push().setValue(
            mapOf(
                "type" to if (approve) "SUBMISSION_APPROVED" else "SUBMISSION_REJECTED",
                "submissionId" to submission.id,
                "title" to if (approve) "Música aprovada" else "Revisão concluída",
                "message" to if (approve) "${submission.title} foi aprovada e seguirá para publicação." else violationNotificationText(violation, reason),
                "createdAt" to now,
                "read" to false
            )
        ).awaitVoid()
    }

    suspend fun requestChanges(submission: StreamSubmission, reviewer: AuthUser, message: String): Result<Unit> = runCatching {
        require(reviewer.role == AccountRole.OWNER || reviewer.role == AccountRole.SUPPORT) { "Sem permissão para moderar." }
        val clean = message.trim().take(1000)
        require(clean.isNotBlank()) { "Explique o que precisa ser corrigido." }
        val now = System.currentTimeMillis()
        db.getReference("streamSubmissions").child(submission.id).updateChildren(
            mapOf(
                "status" to StreamSubmissionStatus.CHANGES_REQUESTED.name,
                "reviewedAt" to now,
                "reviewerUid" to reviewer.uid,
                "changeRequest" to clean,
                "quotaConsumed" to false,
                "quotaConsumedAt" to null
            )
        ).awaitVoid()
        db.getReference("streamUserNotifications").child(submission.uid).push().setValue(
            mapOf(
                "type" to "SUBMISSION_CHANGES_REQUESTED",
                "submissionId" to submission.id,
                "title" to "Ajuste solicitado",
                "message" to "Sua música ${submission.title} precisa de um ajuste antes de continuar: $clean",
                "route" to "STREAM_CREATOR",
                "createdAt" to now,
                "read" to false
            )
        ).awaitVoid()
    }

    suspend fun rewardContributor(
        submission: StreamSubmission,
        reviewer: AuthUser,
        tier: MembershipTier,
        bonusDays: Int,
        reason: String = "Contribuição aprovada no SONUS Stream"
    ): Result<Unit> = runCatching {
        require(reviewer.role == AccountRole.OWNER) { "Somente OWNER pode conceder recompensa Premium." }
        require(tier == MembershipTier.OURO || tier == MembershipTier.DIAMANTE) { "Plano de recompensa inválido." }
        require(bonusDays in 1..365) { "Dias de recompensa inválidos." }
        val base = streamBackendBase()
        if (base.isBlank()) {
            val id = UUID.randomUUID().toString()
            db.getReference("supportAdminActions").child(id).setValue(
                mapOf(
                    "id" to id, "ticketId" to "STREAM_${submission.id}", "targetUid" to submission.uid,
                    "actorUid" to reviewer.uid, "actorRole" to reviewer.role.name,
                    "action" to "GRANT_PREMIUM",
                    "payload" to mapOf("tier" to tier.name, "paidDays" to 0, "bonusDays" to bonusDays, "reason" to reason.take(240)),
                    "status" to "PENDING_BACKEND", "createdAt" to System.currentTimeMillis()
                )
            ).awaitVoid()
            return@runCatching
        }
        val token = auth.currentUser?.getIdToken(false)?.awaitStreamToken()?.token ?: error("Sessão expirada. Entre novamente.")
        val body = JSONObject().apply {
            put("ticketId", "STREAM_${submission.id}")
            put("targetUid", submission.uid)
            put("action", "GRANT_PREMIUM")
            put("payload", JSONObject().apply {
                put("tier", tier.name); put("paidDays", 0); put("bonusDays", bonusDays); put("reason", reason.take(240))
            })
        }
        withContext(Dispatchers.IO) {
            val c = (URL("$base/supportAction").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"; connectTimeout = 12_000; readTimeout = 20_000; doOutput = true
                setRequestProperty("Authorization", "Bearer $token")
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
            }
            try {
                c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = c.responseCode
                val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
                if (code !in 200..299) error("Servidor recusou a recompensa ($code): ${text.take(180)}")
            } finally { c.disconnect() }
        }
    }

    private suspend fun applyViolation(uid: String, submissionId: String, reviewerUid: String, level: StreamViolationLevel, reason: String, suspendDays: Int?, indefinite: Boolean) {
        val ref = db.getReference("streamCreatorProfiles").child(uid)
        val current = profile(uid)
        val now = System.currentTimeMillis()
        val recovered = current.currentCredibility(now)
        val newScore = (recovered - level.scorePenalty).coerceIn(0.0, 10.0)
        val since30d = now - 30L * 86_400_000L
        val violationRoot = db.getReference("streamViolations").child(uid)
        val existing = violationRoot.get().awaitSnapshot().children.count { (it.child("createdAt").getValue(Long::class.java) ?: 0L) >= since30d && (it.child("level").getValue(String::class.java) in setOf(StreamViolationLevel.MEDIUM.name, StreamViolationLevel.SEVERE.name)) }
        val qualifiedCount = existing + if (level == StreamViolationLevel.MEDIUM || level == StreamViolationLevel.SEVERE) 1 else 0
        val automaticSuspend = qualifiedCount >= 3
        val until = when {
            indefinite -> null
            suspendDays != null -> now + suspendDays.coerceAtLeast(1) * 86_400_000L
            automaticSuspend -> now + 30L * 86_400_000L
            level == StreamViolationLevel.SEVERE -> now + 30L * 86_400_000L
            else -> current.submissionSuspendedUntil
        }
        ref.updateChildren(
            mapOf(
                "uid" to uid,
                "credibilityBase" to newScore,
                "credibilityUpdatedAt" to now,
                "activeViolationCount30d" to qualifiedCount,
                "indefiniteSuspension" to (current.indefiniteSuspension || indefinite),
                "submissionSuspendedUntil" to until
            )
        ).awaitVoid()
        violationRoot.push().setValue(
            mapOf(
                "submissionId" to submissionId,
                "level" to level.name,
                "reason" to reason.trim().take(1000),
                "pointsLost" to level.scorePenalty,
                "createdAt" to now,
                "reviewerUid" to reviewerUid,
                "expiresAt" to (if (level == StreamViolationLevel.LIGHT) now + 30L * 86_400_000L else until),
                "active" to true
            )
        ).awaitVoid()
        if (level == StreamViolationLevel.MEDIUM || level == StreamViolationLevel.SEVERE) {
            val published = ownSubmissions(uid).filter { it.status == StreamSubmissionStatus.PUBLISHED.name && (it.publishedFileId ?: 0L) > 0L }
            val expires = until ?: (now + 30L * 86_400_000L)
            published.forEach { item ->
                val fid = item.publishedFileId ?: return@forEach
                db.getReference("streamRecommendationRestrictions").child(fid.toString()).setValue(
                    mapOf("uid" to uid, "fileId" to fid, "level" to level.name, "multiplier" to if(level == StreamViolationLevel.SEVERE) 0.0 else 0.55, "reason" to reason.trim().take(240), "createdAt" to now, "expiresAt" to expires)
                ).awaitVoid()
            }
        }
    }

    suspend fun scanPublicationNow(submission: StreamSubmission): Result<Boolean> = runCatching {
        require(submission.status == StreamSubmissionStatus.APPROVED.name || submission.status == StreamSubmissionStatus.PUBLISHED.name) {
            "A música precisa estar aprovada antes da verificação."
        }
        if (submission.status == StreamSubmissionStatus.PUBLISHED.name) return@runCatching true
        val base = streamBackendBase()
        require(base.isNotBlank()) { "Backend SONUS Stream não configurado." }
        val response = postStreamBackend(
            "$base/scanApprovedPublicationNow",
            JSONObject().put("submissionId", submission.id)
        )
        require(response.optBoolean("ok", false)) { "Não foi possível atualizar o catálogo agora." }
        response.optBoolean("found", false) || response.optBoolean("alreadyLive", false)
    }

    suspend fun setManualPublicationStatus(submission: StreamSubmission, reviewer: AuthUser, live: Boolean, fileId: Long? = null): Result<Unit> = runCatching {
        require(reviewer.role == AccountRole.OWNER || reviewer.role == AccountRole.SUPPORT) { "Sem permissão para alterar publicação." }
        val base = streamBackendBase()
        require(base.isNotBlank()) { "Backend SONUS Stream não configurado." }
        val payload = JSONObject().put("submissionId", submission.id).put("live", live)
        fileId?.takeIf { it > 0L }?.let { payload.put("fileId", it) }
        val response = postStreamBackend("$base/setManualPublicationStatus", payload)
        require(response.optBoolean("ok", false)) { response.optString("error").ifBlank { "Não foi possível alterar o status de publicação." } }
    }

    suspend fun setManualPublicationByFile(fileId: Long, reviewer: AuthUser): Result<String> = runCatching {
        require(reviewer.role == AccountRole.OWNER || reviewer.role == AccountRole.SUPPORT) { "Sem permissão para alterar publicação." }
        require(fileId > 0L) { "Música inválida." }
        val base = streamBackendBase()
        require(base.isNotBlank()) { "Backend SONUS Stream não configurado." }
        val response = postStreamBackend("$base/setManualPublicationByFile", JSONObject().put("fileId", fileId))
        require(response.optBoolean("ok", false)) { response.optString("error").ifBlank { "Não foi possível localizar um envio aprovado para esta faixa." } }
        response.optString("submissionId").ifBlank { "publicada" }
    }

    fun contentReportFlow(team: Boolean): Flow<List<StreamContentReport>> = callbackFlow {
        if (!team) { trySend(emptyList()); close(); return@callbackFlow }
        val ref = db.getReference("streamContentReports")
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val reports = snapshot.children.mapNotNull { n ->
                    val id = n.child("id").getValue(String::class.java) ?: n.key ?: return@mapNotNull null
                    StreamContentReport(
                        id = id,
                        reporterUid = n.child("reporterUid").getValue(String::class.java).orEmpty(),
                        fileId = n.child("fileId").getValue(Long::class.java) ?: 0L,
                        title = n.child("title").getValue(String::class.java).orEmpty(),
                        artist = n.child("artist").getValue(String::class.java).orEmpty(),
                        reason = n.child("reason").getValue(String::class.java).orEmpty(),
                        details = n.child("details").getValue(String::class.java).orEmpty(),
                        status = n.child("status").getValue(String::class.java) ?: "OPEN",
                        createdAt = n.child("createdAt").getValue(Long::class.java) ?: 0L,
                        reviewedAt = n.child("reviewedAt").getValue(Long::class.java),
                        reviewerUid = n.child("reviewerUid").getValue(String::class.java)
                    )
                }.sortedWith(compareBy<StreamContentReport> { it.status != "OPEN" }.thenByDescending { it.createdAt })
                trySend(reports)
            }
            override fun onCancelled(error: DatabaseError) { trySend(emptyList()) }
        }
        ref.addValueEventListener(listener)
        awaitClose { ref.removeEventListener(listener) }
    }

    fun integrityAlertFlow(team: Boolean): Flow<List<StreamIntegrityAlert>> = callbackFlow {
        if (!team) { trySend(emptyList()); close(); return@callbackFlow }
        val ref = db.getReference("streamIntegrityAlerts")
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val alerts = snapshot.children.mapNotNull { n ->
                    val id = n.child("id").getValue(String::class.java) ?: n.key ?: return@mapNotNull null
                    StreamIntegrityAlert(
                        id = id, type = n.child("type").getValue(String::class.java).orEmpty(),
                        targetId = n.child("targetId").getValue(String::class.java).orEmpty(),
                        uid = n.child("uid").getValue(String::class.java).orEmpty(),
                        message = n.child("message").getValue(String::class.java).orEmpty(),
                        status = n.child("status").getValue(String::class.java) ?: "OPEN",
                        countInMinute = n.child("countInMinute").getValue(Long::class.java) ?: 0L,
                        createdAt = n.child("createdAt").getValue(Long::class.java) ?: 0L
                    )
                }.sortedWith(compareBy<StreamIntegrityAlert> { it.status != "OPEN" }.thenByDescending { it.createdAt })
                trySend(alerts)
            }
            override fun onCancelled(error: DatabaseError) { trySend(emptyList()) }
        }
        ref.addValueEventListener(listener)
        awaitClose { ref.removeEventListener(listener) }
    }

    suspend fun reviewIntegrityAlert(id: String, reviewer: AuthUser): Result<Unit> = runCatching {
        require(reviewer.role == AccountRole.OWNER || reviewer.role == AccountRole.SUPPORT) { "Acesso restrito à equipe SONUS." }
        require(id.isNotBlank())
        db.getReference("streamIntegrityAlerts").child(id).updateChildren(mapOf(
            "status" to "REVIEWED", "reviewedAt" to System.currentTimeMillis(), "reviewerUid" to reviewer.uid
        )).awaitVoid()
    }

    suspend fun reportPublishedTrack(fileId: Long, title: String, artist: String, reason: String, details: String = ""): Result<String> = runCatching {
        val uid = auth.currentUser?.uid ?: error("Entre na sua conta para enviar uma denúncia.")
        require(fileId > 0L) { "Faixa inválida." }
        val cleanReason = reason.trim().take(120)
        require(cleanReason.isNotBlank()) { "Escolha o motivo da denúncia." }
        val id = db.getReference("streamContentReports").push().key ?: UUID.randomUUID().toString()
        db.getReference("streamContentReports").child(id).setValue(
            mapOf(
                "id" to id, "reporterUid" to uid, "fileId" to fileId,
                "title" to title.take(160), "artist" to artist.take(160),
                "reason" to cleanReason, "details" to details.trim().take(1200),
                "status" to "OPEN", "createdAt" to System.currentTimeMillis()
            )
        ).awaitVoid()
        id
    }

    suspend fun reviewContentReport(report: StreamContentReport, reviewer: AuthUser, suspendDays: Int? = null, dismiss: Boolean = false): Result<Unit> = runCatching {
        require(reviewer.role == AccountRole.OWNER) { "Somente OWNER pode aplicar ou encerrar uma revisão de catálogo." }
        val now = System.currentTimeMillis()
        if (!dismiss && suspendDays != null && suspendDays > 0 && report.fileId > 0L) {
            db.getReference("streamRecommendationRestrictions").child(report.fileId.toString()).setValue(
                mapOf(
                    "fileId" to report.fileId, "level" to "REPORT_REVIEW", "multiplier" to 0.0,
                    "reason" to "Faixa em revisão após denúncia", "createdAt" to now,
                    "expiresAt" to now + suspendDays.coerceIn(1, 90) * 86_400_000L
                )
            ).awaitVoid()
        }
        db.getReference("streamContentReports").child(report.id).updateChildren(
            mapOf(
                "status" to if (dismiss) "RESOLVED" else "SUSPENDED_REVIEW",
                "reviewedAt" to now, "reviewerUid" to reviewer.uid
            )
        ).awaitVoid()
    }

    suspend fun createBoostRequest(uid: String, fileId: Long, genre: String, days: Int, priceBrl: Double): Result<String> = runCatching {
        val id = UUID.randomUUID().toString()
        db.getReference("streamBoosts").child(id).setValue(
            mapOf(
                "id" to id, "uid" to uid, "fileId" to fileId, "genre" to genre.take(80),
                "days" to days, "priceBrl" to priceBrl, "status" to "PENDING_PAYMENT",
                "createdAt" to System.currentTimeMillis(), "label" to "Patrocinada"
            )
        ).awaitVoid()
        id
    }

    suspend fun playCounts(fileIds: List<Long>): Map<Long, Long> {
        val ids = fileIds.filter { it > 0L }.distinct()
        if (ids.isEmpty()) return emptyMap()

        val now = System.currentTimeMillis()
        playCountsSnapshotCache?.takeIf { now - it.first < 10_000L }?.second?.let { cached ->
            return ids.associateWith { cached[it] ?: 0L }
        }

        // Para um catálogo de ~200 músicas é muito mais barato um snapshot único do que
        // centenas de GETs independentes. Se o root falhar, mantém o fallback exato por ID.
        val root = runCatching { db.getReference("streamStats").get().awaitSnapshot() }.getOrNull()
        if (root != null) {
            val all = root.children.mapNotNull { child ->
                val id = child.key?.toLongOrNull() ?: return@mapNotNull null
                id to (child.child("playCount").getValue(Long::class.java) ?: 0L)
            }.toMap()
            playCountsSnapshotCache = now to all
            return ids.associateWith { all[it] ?: 0L }
        }

        return coroutineScope {
            ids.chunked(24).flatMap { chunk ->
                chunk.map { id ->
                    async {
                        val count = runCatching {
                            db.getReference("streamStats").child(id.toString()).child("playCount")
                                .get().awaitSnapshot().getValue(Long::class.java) ?: 0L
                        }.getOrDefault(0L)
                        id to count
                    }
                }.map { it.await() }
            }.toMap()
        }
    }

    suspend fun activeBoostFileIds(preferredGenre: String? = null): List<Long> {
        val now = System.currentTimeMillis()
        val snap = db.getReference("streamBoosts").orderByChild("status").equalTo("ACTIVE").limitToFirst(250).get().awaitSnapshot()
        return snap.children.mapNotNull { b ->
            val status=b.child("status").getValue(String::class.java).orEmpty()
            val start=b.child("startsAt").getValue(Long::class.java) ?: b.child("createdAt").getValue(Long::class.java) ?: 0L
            val end=b.child("endsAt").getValue(Long::class.java) ?: 0L
            val genre=b.child("genre").getValue(String::class.java).orEmpty()
            val id=b.child("fileId").getValue(Long::class.java) ?: return@mapNotNull null
            id.takeIf { status=="ACTIVE" && start<=now && end>now && (preferredGenre.isNullOrBlank() || genre.equals(preferredGenre,true)) }
        }.distinct()
    }

    suspend fun recommendationMultipliers(fileIds: List<Long>): Map<Long, Double> {
        if(fileIds.isEmpty()) return emptyMap()
        val now=System.currentTimeMillis()
        val snap=db.getReference("streamRecommendationRestrictions").orderByChild("expiresAt").startAt(now.toDouble()).limitToFirst(250).get().awaitSnapshot()
        val active=snap.children.mapNotNull { n ->
            val id=n.key?.toLongOrNull() ?: return@mapNotNull null
            val expires=n.child("expiresAt").getValue(Long::class.java) ?: 0L
            if(expires<=now) return@mapNotNull null
            val multiplier=n.child("multiplier").getValue(Double::class.java) ?: n.child("multiplier").getValue(Long::class.java)?.toDouble() ?: 1.0
            id to multiplier
        }.toMap()
        return fileIds.distinct().associateWith { id -> active[id] ?: 1.0 }
    }

    private fun pendingPublicPrefix(uid:String,fileId:Long)="pending_public_${uid}_${fileId}_"
    private fun pendingPublicKey(uid:String,fileId:Long,sessionId:String):String {
        val digest=java.security.MessageDigest.getInstance("SHA-256").digest(sessionId.toByteArray())
            .take(10).joinToString(""){"%02x".format(it)}
        return pendingPublicPrefix(uid,fileId)+digest
    }

    private fun rememberPendingPublicPlay(uid:String,fileId:Long,sessionId:String,firstEver:Boolean,replay:Boolean,qualifiedAt:Long,source:String){
        val json=JSONObject()
            .put("sessionId",sessionId.take(120))
            .put("firstEver",firstEver)
            .put("replay",replay)
            .put("qualifiedAt",qualifiedAt)
            .put("source",source.take(80))
        counterPrefs.edit().putString(pendingPublicKey(uid,fileId,sessionId),json.toString()).apply()
    }

    private fun markQualifiedPlayLocally(uid: String, fileId: Long, sessionId: String) {
        if (uid.isBlank() || fileId <= 0L || sessionId.isBlank()) return
        val digest = java.security.MessageDigest.getInstance("SHA-256").digest(sessionId.toByteArray())
            .take(10).joinToString("") { "%02x".format(it) }
        val sessionKey = "shadow_qualified_${uid}_${fileId}_$digest"
        if (counterPrefs.getBoolean(sessionKey, false)) return
        val shadowKey = "shadow_$fileId"
        val next = counterPrefs.getLong(shadowKey, 0L).coerceAtLeast(0L) + 1L
        counterPrefs.edit().putLong(shadowKey, next).putBoolean(sessionKey, true).apply()
        localCounterRevision.value = localCounterRevision.value + 1L
    }

    private suspend fun commitPublicPlayCore(
        uid:String,
        fileId:Long,
        sessionId:String,
        firstEver:Boolean,
        replay:Boolean,
        qualifiedAt:Long
    ):Boolean = publicCounterSyncMutex.withLock {
        val root = db.reference
        val digest = java.security.MessageDigest.getInstance("SHA-256").digest(sessionId.toByteArray())
            .take(16).joinToString("") { "%02x".format(it) }
        val claimRef = root.child("streamPublicPlayClaims").child(uid).child(fileId.toString()).child(digest)
        val already = runCatching { claimRef.get().awaitSnapshot().exists() }.getOrDefault(false)
        if (already) {
            val remote = runCatching { root.child("streamStats").child(fileId.toString()).child("playCount").get().awaitSnapshot().getValue(Long::class.java) ?: 0L }.getOrDefault(0L)
            val shadowKey = "shadow_$fileId"
            if (remote > counterPrefs.getLong(shadowKey, 0L)) {
                counterPrefs.edit().putLong(shadowKey, remote).apply()
                localCounterRevision.value = localCounterRevision.value + 1L
            }
            return@withLock true
        }

        val syncedAt = System.currentTimeMillis()
        val updates = linkedMapOf<String, Any?>(
            "streamPublicPlayClaims/$uid/$fileId/$digest" to qualifiedAt,
            "streamStats/$fileId/playCount" to ServerValue.increment(1L),
            "streamStats/$fileId/updatedAt" to syncedAt
        )
        if (firstEver) updates["streamStats/$fileId/uniqueListeners"] = ServerValue.increment(1L)
        if (replay) updates["streamStats/$fileId/replayCount"] = ServerValue.increment(1L)

        val commitResult = runCatching { root.updateChildren(updates).awaitVoid() }
        val committedOrAlready = commitResult.isSuccess || runCatching { claimRef.get().awaitSnapshot().exists() }.getOrDefault(false)
        val diagnosticKey = "public_commit_error_$fileId"
        if (committedOrAlready) {
            playCountsSnapshotCache = null
            counterPrefs.edit().remove(diagnosticKey).apply()
            val remote = runCatching { root.child("streamStats").child(fileId.toString()).child("playCount").get().awaitSnapshot().getValue(Long::class.java) ?: 0L }.getOrDefault(0L)
            val shadowKey = "shadow_$fileId"
            val previous = counterPrefs.getLong(shadowKey, 0L)
            counterPrefs.edit().putLong(shadowKey, maxOf(previous, remote)).apply()
            localCounterRevision.value = localCounterRevision.value + 1L
        } else {
            counterPrefs.edit().putString(diagnosticKey, commitResult.exceptionOrNull()?.let { "${it.javaClass.simpleName}: ${it.message.orEmpty()}" }?.take(280).orEmpty()).apply()
        }
        committedOrAlready
    }

    private suspend fun retryPendingPublicPlaysForFile(fileId:Long){
        val uid=auth.currentUser?.uid ?: return
        if(fileId<=0L) return
        val entries=counterPrefs.all.filterKeys{it.startsWith(pendingPublicPrefix(uid,fileId))}
        entries.forEach{(key,value)->
            val json=runCatching{JSONObject(value as? String ?: return@forEach)}.getOrNull() ?: run{
                counterPrefs.edit().remove(key).apply();return@forEach
            }
            val session=json.optString("sessionId")
            if(session.isBlank()){counterPrefs.edit().remove(key).apply();return@forEach}
            val ok=commitPublicPlayCore(
                uid=uid,fileId=fileId,sessionId=session,
                firstEver=json.optBoolean("firstEver",false),
                replay=json.optBoolean("replay",false),
                qualifiedAt=json.optLong("qualifiedAt",System.currentTimeMillis())
            )
            if(ok) counterPrefs.edit().remove(key).apply()
        }
    }

    fun playCountFlow(fileId: Long): Flow<Long> = callbackFlow {
        val ref = db.getReference("streamStats").child(fileId.toString()).child("playCount")
        val shadowKey = "shadow_$fileId"
        // Mostra imediatamente o último valor qualificado neste aparelho e reconcilia com o remoto.
        // Se o Firebase estiver temporariamente bloqueado/offline, a sessão fica pendente e sincroniza depois.
        trySend(counterPrefs.getLong(shadowKey, 0L))
        val localRevisionJob = launch {
            localCounterRevision.collect { trySend(counterPrefs.getLong(shadowKey, 0L)) }
        }
        // retries são session-aware e deduplicados por streamPublicPlayClaims.
        launch(Dispatchers.IO) { retryPendingPublicPlaysForFile(fileId) }

        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                playCountsSnapshotCache = null
                val remote = snapshot.getValue(Long::class.java) ?: 0L
                val shadow = counterPrefs.getLong(shadowKey, 0L)
                if (remote > shadow) counterPrefs.edit().putLong(shadowKey, remote).apply()
                trySend(maxOf(remote, shadow))
            }
            override fun onCancelled(error: DatabaseError) {
                trySend(counterPrefs.getLong(shadowKey, 0L))
            }
        }
        ref.addValueEventListener(listener)
        awaitClose {
            ref.removeEventListener(listener)
            localRevisionJob.cancel()
        }
    }

    private fun streamSourceKey(source: String): String = source
        .trim().lowercase(Locale.US)
        .replace(Regex("[^a-z0-9_-]+"), "_")
        .trim('_')
        .take(48)
        .ifBlank { "sonus_stream" }

    private suspend fun recordSongMetricBucket(
        fileId: Long,
        views: Long = 0L,
        uniqueListeners: Long = 0L,
        listeningMs: Long = 0L,
        completions: Long = 0L,
        replays: Long = 0L,
        skips: Long = 0L,
        earlySkips: Long = 0L,
        likes: Long = 0L,
        source: String = ""
    ) {
        if (fileId <= 0L) return
        val hour = System.currentTimeMillis() / 3_600_000L
        val base = "streamMetricBuckets/$fileId/$hour"
        val updates = mutableMapOf<String, Any?>()
        if (views > 0L) updates["$base/views"] = ServerValue.increment(views.coerceAtMost(1L))
        if (uniqueListeners > 0L) updates["$base/uniqueListeners"] = ServerValue.increment(uniqueListeners.coerceAtMost(1L))
        if (listeningMs > 0L) updates["$base/listeningMs"] = ServerValue.increment(listeningMs.coerceAtMost(1_800_000L))
        if (completions > 0L) updates["$base/completions"] = ServerValue.increment(completions.coerceAtMost(3L))
        if (replays > 0L) updates["$base/replays"] = ServerValue.increment(replays.coerceAtMost(2L))
        if (skips > 0L) updates["$base/skips"] = ServerValue.increment(1L)
        if (earlySkips > 0L) updates["$base/earlySkips"] = ServerValue.increment(1L)
        if (likes > 0L) updates["$base/likes"] = ServerValue.increment(1L)
        if (views > 0L && source.isNotBlank()) updates["$base/sources/${streamSourceKey(source)}"] = ServerValue.increment(1L)
        if (updates.isNotEmpty()) runCatching { db.reference.updateChildren(updates).awaitVoid() }
    }

    private suspend fun recordArtistMetricBucket(artistId: String, followers: Long) {
        if (artistId.isBlank() || followers <= 0L) return
        val hour = System.currentTimeMillis() / 3_600_000L
        runCatching {
            db.reference.updateChildren(mapOf(
                "streamArtistMetricBuckets/$artistId/$hour/followers" to ServerValue.increment(1L)
            )).awaitVoid()
        }
    }

    private suspend fun recordTrafficAndMaybeAlert(type: String, targetId: String, thresholdPerMinute: Long) {
        val uid = auth.currentUser?.uid ?: return
        val minute = System.currentTimeMillis() / 60_000L
        val bucket = db.getReference("streamTrafficBuckets").child(type).child(targetId).child(minute.toString())
        runCatching { bucket.setValue(ServerValue.increment(1)).awaitVoid() }
        val value = runCatching { bucket.get().awaitSnapshot().getValue(Long::class.java) ?: 0L }.getOrDefault(0L)
        if (value >= thresholdPerMinute) {
            val id = "${type}_${targetId}_$minute"
            val ref = db.getReference("streamIntegrityAlerts").child(id)
            if (!runCatching { ref.get().awaitSnapshot().exists() }.getOrDefault(true)) {
                runCatching {
                    ref.setValue(mapOf(
                        "id" to id, "type" to type, "targetId" to targetId, "countInMinute" to value,
                        "minuteBucket" to minute, "status" to "OPEN", "createdAt" to System.currentTimeMillis(),
                        "reportedByUid" to uid, "message" to "Pico atípico detectado automaticamente. Revisão humana recomendada."
                    )).awaitVoid()
                }
            }
        }
    }

    /** code108: sessão analítica local/direta; não depende de Cloud Function. */
    suspend fun startPlaySession(fileId: Long, sessionId: String, source: String = "SONUS Stream"): Result<Unit> = runCatching {
        require(auth.currentUser != null) { "Entre na sua conta SONUS para usar o Stream." }
        require(fileId > 0L && sessionId.isNotBlank()) { "Sessão de reprodução inválida." }
        // code113 counter fix: não esperar o contador estar visível para recuperar uma view
        // já qualificada que ficou pendente por rede/regra temporariamente indisponível.
        runCatching { retryPendingPublicPlaysForFile(fileId) }
    }

    /**
     * code108 build-fix1: registra localmente cada reprodução válida usada pela Linha do Tempo.
     * A Linha do Tempo não depende de Cloud Function nem de regra adicional do Firebase.
     */
    private fun recordTimelineValidPlay(uid: String, fileId: Long, qualifiedAt: Long) {
        if (uid.isBlank() || fileId <= 0L || qualifiedAt <= 0L) return
        val year = Instant.ofEpochMilli(qualifiedAt).atZone(java.time.ZoneId.systemDefault()).year
        val baseKey = "timeline_${uid}_${year}_${fileId}"
        synchronized(localStatePrefs) {
            val current = localStatePrefs.getInt("${baseKey}_count", 0)
            localStatePrefs.edit()
                .putInt("${baseKey}_count", (current + 1).coerceAtMost(Int.MAX_VALUE))
                .putLong("${baseKey}_last", qualifiedAt)
                .apply()
        }
    }

    /**
     * code108 build-fix1: devolve a Linha do Tempo do ano atual a partir dos eventos
     * locais persistidos. Ordena primeiro pelas faixas mais ouvidas e, em empate,
     * pela reprodução válida mais recente.
     */
    suspend fun timelineForYear(year: Int = LocalDate.now().year): Result<List<StreamTimelineEntry>> = runCatching {
        val uid = auth.currentUser?.uid ?: return@runCatching emptyList()
        val prefix = "timeline_${uid}_${year}_"
        val suffix = "_count"
        val values = localStatePrefs.all
        values.keys.asSequence()
            .filter { it.startsWith(prefix) && it.endsWith(suffix) }
            .mapNotNull { key ->
                val fileId = key.removePrefix(prefix).removeSuffix(suffix).toLongOrNull() ?: return@mapNotNull null
                val count = (values[key] as? Number)?.toInt()?.coerceAtLeast(0) ?: 0
                if (count <= 0) return@mapNotNull null
                val last = (values["timeline_${uid}_${year}_${fileId}_last"] as? Number)?.toLong() ?: 0L
                StreamTimelineEntry(fileId = fileId, playCount = count, qualifiedAt = last)
            }
            .sortedWith(compareByDescending<StreamTimelineEntry> { it.playCount }.thenByDescending { it.qualifiedAt })
            .take(100)
            .toList()
    }

    private data class LocalPublicQualification(val firstEver: Boolean, val replay: Boolean, val uniqueThisHour: Boolean)

    private fun reserveLocalPublicQualification(uid: String, fileId: Long, sessionId: String, now: Long): LocalPublicQualification? {
        val digest = java.security.MessageDigest.getInstance("SHA-256").digest(sessionId.toByteArray())
            .take(10).joinToString("") { "%02x".format(it) }
        val sessionKey = "public_local_session_${uid}_${fileId}_$digest"
        if (counterPrefs.getBoolean(sessionKey, false)) {
            val count = counterPrefs.getLong("public_local_count_${uid}_$fileId", 0L)
            return LocalPublicQualification(firstEver = count <= 1L, replay = count > 1L, uniqueThisHour = false)
        }
        val cooldownKey = "public_local_last_${uid}_${fileId}_$deviceMetricKey"
        val last = counterPrefs.getLong(cooldownKey, 0L)
        if (last > 0L && now - last < SONUS_STREAM_VIEW_COOLDOWN_MS) return null
        val countKey = "public_local_count_${uid}_$fileId"
        val previous = counterPrefs.getLong(countKey, 0L).coerceAtLeast(0L)
        val hour = now / 3_600_000L
        val hourKey = "public_local_hour_${uid}_$fileId"
        val lastHour = counterPrefs.getLong(hourKey, -1L)
        counterPrefs.edit()
            .putBoolean(sessionKey, true)
            .putLong(cooldownKey, now)
            .putLong(countKey, previous + 1L)
            .putLong(hourKey, hour)
            .apply()
        return LocalPublicQualification(firstEver = previous == 0L, replay = previous > 0L, uniqueThisHour = lastHour != hour)
    }

    suspend fun validPlayThresholdMs(fileId: Long, durationMs: Long): Long {
        // code121: regra única e previsível — 50% de tempo realmente ouvido.
        // Não depende do contador remoto nem reduz o limiar conforme a popularidade.
        val safeDuration = durationMs.coerceAtLeast(1_000L)
        return ((safeDuration + 1L) / 2L).coerceIn(1_000L, safeDuration)
    }

    /**
     * code121: valida a reprodução em 50% exatos de tempo realmente ouvido.
     * Mantém cooldown de 15 minutos por UID+música+aparelho.
     * Reprodução da própria música é válida; o anti-abuso é feito pelo cooldown, não pelo dono da faixa.
     */
    suspend fun claimValidPlay(fileId: Long, sessionId: String, listenedMs: Long, durationMs: Long, source: String = "SONUS Stream"): Result<Boolean> = runCatching {
        if (fileId <= 0L || sessionId.isBlank()) return@runCatching false
        val uid = auth.currentUser?.uid ?: error("Entre na sua conta SONUS para usar o Stream.")
        val threshold = validPlayThresholdMs(fileId, durationMs)
        if (listenedMs < threshold) return@runCatching false
        val now = System.currentTimeMillis()
        val root = db.reference
        val userRef = root.child("streamUserSongStats").child(uid).child(fileId.toString())
        val hour = now / 3_600_000L
        var firstEver=false
        var replay=false
        var uniqueThisHour=false
        var alreadyThisSession=false
        val transactionAttempt=runCatching { runTransactionAwait(userRef){data->
            val lastSession=data.child("lastSessionId").getValue(String::class.java).orEmpty()
            if(lastSession==sessionId){
                alreadyThisSession=true
                return@runTransactionAwait Transaction.abort()
            }
            val deviceNode = data.child("deviceCooldowns").child(deviceMetricKey)
            val lastViewAt=deviceNode.child("lastViewAt").getValue(Long::class.java)?:0L
            if(lastViewAt>0L && now-lastViewAt<SONUS_STREAM_VIEW_COOLDOWN_MS) return@runTransactionAwait Transaction.abort()
            val plays=data.child("playCount").getValue(Long::class.java)?:0L
            firstEver=plays<=0L
            replay=!firstEver
            val lastUnique=data.child("lastUniqueHour").getValue(Long::class.java)?:-1L
            uniqueThisHour=lastUnique!=hour
            data.child("playCount").value=plays+1L
            // code120: cooldown efetivo fica no nó do aparelho; não usamos mais o
            // lastViewAt legado como bloqueio global entre celulares diferentes.
            deviceNode.child("lastViewAt").value=now
            deviceNode.child("lastSessionId").value=sessionId.take(120)
            data.child("lastQualifiedAt").value=now
            data.child("lastSessionId").value=sessionId.take(120)
            data.child("lastSource").value=source.take(80)
            data.child("lastValidThresholdMs").value=threshold
            data.child("lastUniqueHour").value=hour
            data.child("updatedAt").value=now
            if(firstEver) data.child("firstQualifiedAt").value=now
            if(replay){
                val replays=data.child("replayCount").getValue(Long::class.java)?:0L
                data.child("replayCount").value=replays+1L
            }
            Transaction.success(data)
        } }
        val committed = transactionAttempt.getOrNull()
        if(alreadyThisSession) return@runCatching true
        if (committed == false) return@runCatching false
        if (transactionAttempt.isFailure) {
            val local = reserveLocalPublicQualification(uid, fileId, sessionId, now) ?: return@runCatching false
            firstEver = local.firstEver
            replay = local.replay
            uniqueThisHour = local.uniqueThisHour
        } else {
            reserveLocalPublicQualification(uid, fileId, sessionId, now)
        }

        // code121: assim que a sessão atinge 50% e passa pelo cooldown, o contador
        // visível sai de zero imediatamente. A sincronização pública continua sendo
        // enviada ao Firebase e é deduplicada pelo sessionId.
        markQualifiedPlayLocally(uid, fileId, sessionId)

        // code120: self-play deixa de ser descartado. Uma reprodução real pode surgir
        // involuntariamente em playlist/Rádio/Stream ou ser escolhida pelo próprio artista.
        // O bloqueio anti-fraude é o cooldown de 15 min por aparelho+conta+faixa acima.
        val publicOk=commitPublicPlayCore(uid,fileId,sessionId,firstEver,replay,now)
        if(publicOk){
            counterPrefs.edit().remove(pendingPublicKey(uid,fileId,sessionId)).apply()
            runCatching{
                recordSongMetricBucket(
                    fileId=fileId,
                    views=1L,
                    uniqueListeners=if(uniqueThisHour)1L else 0L,
                    replays=if(replay)1L else 0L,
                    source=source
                )
            }
        }else{
            rememberPendingPublicPlay(uid,fileId,sessionId,firstEver,replay,now,source)
        }
        recordTimelineValidPlay(uid, fileId, now)
        runCatching { recordTrafficAndMaybeAlert("PLAYS", fileId.toString(), 180L) }
        true
    }

    suspend fun finishValidPlay(fileId:Long,sessionId:String,listenedMs:Long,durationMs:Long,completed:Boolean,skipped:Boolean): Result<Boolean> = runCatching {
        if(fileId<=0L||sessionId.isBlank()) return@runCatching false
        val uid = auth.currentUser?.uid ?: error("Entre na sua conta SONUS para usar o Stream.")
        val now = System.currentTimeMillis()
        val root = db.reference
        val userRef = root.child("streamUserSongStats").child(uid).child(fileId.toString())
        val snap = userRef.get().awaitSnapshot()
        if (snap.child("lastFinishedSessionId").getValue(String::class.java) == sessionId) return@runCatching true
        val safeListening = listenedMs.coerceIn(0L, 1_800_000L)
        val validDuration = durationMs.coerceAtLeast(1L)
        val retentionBp = ((listenedMs.toDouble() / validDuration.toDouble()).coerceIn(0.0, 1.0) * 10_000.0).toLong()
        val early = skipped && !completed && listenedMs < minOf(30_000L, validDuration / 4L)
        val hour = now / 3_600_000L
        val bucketBase = "streamMetricBuckets/$fileId/$hour"
        val updates = linkedMapOf<String, Any?>(
            "streamUserSongStats/$uid/$fileId/totalListeningMs" to ServerValue.increment(safeListening),
            "streamUserSongStats/$uid/$fileId/lastFinishedSessionId" to sessionId.take(120),
            "streamUserSongStats/$uid/$fileId/updatedAt" to now,
            "streamStats/$fileId/listeningMs" to ServerValue.increment(safeListening),
            "streamStats/$fileId/retentionBpTotal" to ServerValue.increment(retentionBp),
            "streamStats/$fileId/retentionSamples" to ServerValue.increment(1L),
            "streamStats/$fileId/updatedAt" to now,
            "$bucketBase/listeningMs" to ServerValue.increment(safeListening)
        )
        if (completed) {
            updates["streamUserSongStats/$uid/$fileId/completions"] = ServerValue.increment(1L)
            updates["streamStats/$fileId/completions"] = ServerValue.increment(1L)
            updates["$bucketBase/completions"] = ServerValue.increment(1L)
        } else if (skipped) {
            updates["streamUserSongStats/$uid/$fileId/skips"] = ServerValue.increment(1L)
            updates["streamStats/$fileId/skips"] = ServerValue.increment(1L)
            updates["$bucketBase/skips"] = ServerValue.increment(1L)
            if (early) {
                updates["streamUserSongStats/$uid/$fileId/earlySkips"] = ServerValue.increment(1L)
                updates["streamStats/$fileId/earlySkips"] = ServerValue.increment(1L)
                updates["$bucketBase/earlySkips"] = ServerValue.increment(1L)
            }
        }
        root.updateChildren(updates).awaitVoid()
        true
    }

    /** code111: sharing is a separate artist metric; it never counts as a play. */
    suspend fun recordShare(fileId: Long, video: Boolean): Result<Unit> = runCatching {
        require(fileId > 0L) { "Música inválida para compartilhamento." }
        val uid = auth.currentUser?.uid ?: error("Entre na sua conta SONUS para compartilhar músicas.")
        val now = System.currentTimeMillis()
        val hour = now / 3_600_000L
        val updates = linkedMapOf<String, Any?>(
            "streamStats/$fileId/shares" to ServerValue.increment(1L),
            "streamStats/$fileId/updatedAt" to now,
            "streamMetricBuckets/$fileId/$hour/shares" to ServerValue.increment(1L),
            "streamUserSongStats/$uid/$fileId/shares" to ServerValue.increment(1L),
            "streamUserSongStats/$uid/$fileId/lastShareAt" to now
        )
        if (video) {
            updates["streamStats/$fileId/videoShares"] = ServerValue.increment(1L)
            updates["streamMetricBuckets/$fileId/$hour/videoShares"] = ServerValue.increment(1L)
            updates["streamUserSongStats/$uid/$fileId/videoShares"] = ServerValue.increment(1L)
        }
        db.reference.updateChildren(updates).awaitVoid()
    }

    /** code111: generation/export are recorded when the automatic share video is rendered successfully,
     * independently from whether the Android share sheet is ultimately used. */
    suspend fun recordGeneratedShareVideo(fileId: Long): Result<Unit> = runCatching {
        require(fileId > 0L) { "Música inválida para vídeo compartilhável." }
        val uid = auth.currentUser?.uid ?: error("Entre na sua conta SONUS para criar vídeos de compartilhamento.")
        val now = System.currentTimeMillis()
        val hour = now / 3_600_000L
        val updates = linkedMapOf<String, Any?>(
            "streamStats/$fileId/videoGenerations" to ServerValue.increment(1L),
            "streamStats/$fileId/videoExports" to ServerValue.increment(1L),
            "streamStats/$fileId/updatedAt" to now,
            "streamMetricBuckets/$fileId/$hour/videoGenerations" to ServerValue.increment(1L),
            "streamMetricBuckets/$fileId/$hour/videoExports" to ServerValue.increment(1L),
            "streamUserSongStats/$uid/$fileId/videoGenerations" to ServerValue.increment(1L),
            "streamUserSongStats/$uid/$fileId/videoExports" to ServerValue.increment(1L),
            "streamUserSongStats/$uid/$fileId/lastVideoExportAt" to now
        )
        db.reference.updateChildren(updates).awaitVoid()
    }

    /**
     * code111: one valid SONUS Stream usage is credited only after a project export.
     * The transaction key is UID + projectId + musicId, so repeated exports cannot inflate usage.
     */
    suspend fun setSongLike(fileId:Long,liked:Boolean): Result<Long> = runCatching {
        if(fileId<=0L) return@runCatching 0L
        val uid = auth.currentUser?.uid ?: error("Entre na sua conta SONUS para curtir músicas.")
        val root = db.reference
        val publicRef = root.child("streamStats").child(fileId.toString())
        val privateRef = root.child("streamUserSongStats").child(uid).child(fileId.toString())
        val publicSnap = publicRef.get().awaitSnapshot()
        val userSnap = privateRef.get().awaitSnapshot()
        val hasValidPlay = (userSnap.child("playCount").getValue(Long::class.java) ?: 0L) > 0L || (userSnap.child("firstQualifiedAt").getValue(Long::class.java) ?: 0L) > 0L
        require(!liked || hasValidPlay) { "Ouça a música antes de curtir." }
        val current = userSnap.child("liked").getValue(Boolean::class.java) == true
        val currentCount = publicSnap.child("likes").getValue(Long::class.java) ?: 0L
        if (current == liked) return@runCatching currentCount
        val delta = if (liked) 1L else -1L
        val now = System.currentTimeMillis()
        root.updateChildren(mapOf(
            "streamStats/$fileId/likes" to ServerValue.increment(delta),
            "streamUserSongStats/$uid/$fileId/liked" to liked,
            "streamUserSongStats/$uid/$fileId/likedAt" to if (liked) now else null,
            "streamUserSongStats/$uid/$fileId/updatedAt" to now,
            "streamStats/$fileId/updatedAt" to now
        )).awaitVoid()
        if (liked) {
            recordTrafficAndMaybeAlert("LIKES", fileId.toString(), 80L)
            recordSongMetricBucket(fileId = fileId, likes = 1L)
            val fresh = publicRef.get().awaitSnapshot()
            val likes = fresh.child("likes").getValue(Long::class.java) ?: 0L
            val plays = fresh.child("playCount").getValue(Long::class.java) ?: 0L
            if (likes > plays && likes >= 5L) {
                val alertId = "LIKE_RATIO_${fileId}_${now / 60_000L}"
                runCatching { db.getReference("streamIntegrityAlerts").child(alertId).setValue(mapOf(
                    "id" to alertId, "type" to "LIKE_RATIO", "targetId" to fileId.toString(), "likes" to likes, "views" to plays,
                    "reportedByUid" to uid, "status" to "OPEN", "createdAt" to now, "message" to "Curtidas acima das reproduções válidas. Revisão recomendada."
                )).awaitVoid() }
            }
            likes
        } else (currentCount - 1L).coerceAtLeast(0L)
    }

    private suspend fun postStreamBackend(url: String, body: JSONObject): JSONObject {
        val token = auth.currentUser?.getIdToken(false)?.awaitStreamToken()?.token ?: error("Entre na sua conta para contabilizar a reprodução.")
        val text = withContext(Dispatchers.IO) {
            val c = (URL(url).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"; connectTimeout = 10_000; readTimeout = 15_000; doOutput = true
                setRequestProperty("Authorization", "Bearer $token")
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
            }
            try {
                c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = c.responseCode
                val result = (if(code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
                if(code !in 200..299) {
                    val remoteError = runCatching { JSONObject(result).optString("error") }.getOrDefault("").ifBlank { "HTTP_$code" }
                    error("Servidor SONUS respondeu $code • $remoteError")
                }
                result
            } finally { c.disconnect() }
        }
        return if (text.isBlank()) JSONObject() else JSONObject(text)
    }

    private fun requireSquareCover(uri: Uri) {
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        appContext.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
        require(options.outWidth > 0 && options.outHeight > 0) { "Não foi possível ler as dimensões da capa." }
        require(options.outWidth == options.outHeight) { "A capa precisa estar no formato 1:1 (quadrada)." }
    }

    private suspend fun uploadSubmissionToTelegramWorker(
        audioFile: File,
        audioRemoteName: String,
        lyricsFile: File?,
        title: String,
        artist: String,
        genre: String,
        submissionId: String,
        musicId: String,
        usesAi: Boolean,
        onBytes: (Long, Long) -> Unit
    ): Long {
        val base = BuildConfig.SONUS_TELEGRAM_UPLOAD_BASE.trim().trimEnd('/')
        require(base.startsWith("https://")) { "Destino seguro de envio do SONUS Stream não configurado." }
        require(audioFile.exists() && audioFile.length() > 0L) { "Arquivo processado inválido." }
        require(audioFile.length() <= 45L * 1024L * 1024L) { "O áudio processado ultrapassa o limite de 45 MB para análise." }
        val token = auth.currentUser?.getIdToken(false)?.awaitStreamToken()?.token
            ?: error("Sessão expirada. Entre novamente.")
        val boundary = "----SONUS${UUID.randomUUID().toString().replace("-", "")}" 
        val crlf = "\r\n"
        fun field(name: String, value: String): ByteArray = buildString {
            append("--$boundary$crlf")
            append("Content-Disposition: form-data; name=\"").append(name).append("\"$crlf$crlf")
            append(value).append(crlf)
        }.toByteArray(Charsets.UTF_8)
        fun fileHeader(name: String, filename: String, contentType: String): ByteArray = buildString {
            append("--$boundary$crlf")
            append("Content-Disposition: form-data; name=\"").append(name).append("\"; filename=\"").append(filename.replace("\"", "")).append("\"$crlf")
            append("Content-Type: ").append(contentType).append("$crlf$crlf")
        }.toByteArray(Charsets.UTF_8)
        val connection = (URL("$base/upload").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 20_000
            readTimeout = 180_000
            setRequestProperty("Authorization", "Bearer $token")
            setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            setRequestProperty("Accept", "application/json")
            setChunkedStreamingMode(64 * 1024)
        }
        return try {
            connection.outputStream.buffered(64 * 1024).use { output ->
                output.write(field("title", title))
                output.write(field("artist", artist))
                output.write(field("genre", genre))
                output.write(field("submissionId", submissionId))
                output.write(field("musicId", musicId))
                output.write(field("usesAi", usesAi.toString()))
                output.write(fileHeader("audio", audioRemoteName, "audio/mpeg"))
                audioFile.inputStream().buffered(64 * 1024).use { input ->
                    val buffer = ByteArray(64 * 1024)
                    var sent = 0L
                    while (true) {
                        val n = input.read(buffer)
                        if (n <= 0) break
                        output.write(buffer, 0, n)
                        sent += n
                        onBytes(sent, audioFile.length())
                    }
                }
                output.write(crlf.toByteArray(Charsets.UTF_8))
                if (lyricsFile != null && lyricsFile.exists() && lyricsFile.length() > 0L) {
                    val ct = if (lyricsFile.extension.equals("lrc", true)) "text/plain; charset=utf-8" else "text/plain; charset=utf-8"
                    output.write(fileHeader("lyrics", lyricsFile.name, ct))
                    lyricsFile.inputStream().use { it.copyTo(output, 16 * 1024) }
                    output.write(crlf.toByteArray(Charsets.UTF_8))
                }
                output.write("--$boundary--$crlf".toByteArray(Charsets.UTF_8))
                output.flush()
            }
            val http = connection.responseCode
            val body = (if (http in 200..299) connection.inputStream else connection.errorStream)
                ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            val json = runCatching { JSONObject(body) }.getOrElse { JSONObject() }
            if (http !in 200..299 || !json.optBoolean("ok", false)) {
                val reason = json.optString("error").ifBlank { json.optString("telegram") }.ifBlank { "HTTP $http" }
                throw IOException("Não foi possível entregar a música ao grupo de análise ($reason).")
            }
            if (lyricsFile != null && lyricsFile.exists() && lyricsFile.length() > 0L && !json.optBoolean("lyricsSent", false)) {
                throw IOException("O MP3 foi enviado, mas o LRC separado não foi confirmado pelo Telegram. Tente novamente para não perder a letra sincronizada.")
            }
            json.optLong("telegramMessageId", 0L).takeIf { it > 0L } ?: 0L
        } finally {
            connection.disconnect()
        }
    }

    suspend fun exportSubmissionBundle(submission: StreamSubmission): Result<File> = runCatching {
        require(submission.audioDownloadUrl.isNotBlank() || submission.audioStoragePath.isNotBlank()) { "Este envio foi entregue diretamente ao grupo 🔴 SONUS ARTISTAS no Telegram. Use o arquivo recebido pelo bot para a revisão." }
        val dir = File(appContext.cacheDir, "sonus_stream_exports").apply { mkdirs() }
        val zip = File(dir, "${submission.id}_${safe(submission.title)}.zip")
        ZipOutputStream(FileOutputStream(zip)).use { out ->
            fun addText(name: String, text: String) {
                out.putNextEntry(ZipEntry(name)); out.write(text.toByteArray(Charsets.UTF_8)); out.closeEntry()
            }
            val audio = File(dir, "${submission.id}_${safe(submission.audioOriginalName)}")
            if (submission.audioDownloadUrl.isNotBlank()) downloadUrlToFile(submission.audioDownloadUrl, audio) else storage.reference.child(submission.audioStoragePath).getFile(audio).awaitFile()
            out.putNextEntry(ZipEntry(submission.audioOriginalName.ifBlank { "audio.mp3" })); audio.inputStream().use { it.copyTo(out) }; out.closeEntry(); audio.delete()
            if (submission.coverStoragePath.isNotBlank() || submission.coverDownloadUrl.isNotBlank()) {
                val cover = File(dir, "${submission.id}_cover")
                runCatching { if (submission.coverDownloadUrl.isNotBlank()) downloadUrlToFile(submission.coverDownloadUrl, cover) else storage.reference.child(submission.coverStoragePath).getFile(cover).awaitFile() }.onSuccess {
                    out.putNextEntry(ZipEntry(submission.coverOriginalName.ifBlank { "cover.jpg" })); cover.inputStream().use { it.copyTo(out) }; out.closeEntry(); cover.delete()
                }
            }
            addText("lyrics.txt", submission.lyrics)
            addText("lyrics.lrc", submission.lrc)
            addText("metadata.json", """{"id":"${submission.id}","title":"${escapeJson(submission.title)}","artist":"${escapeJson(submission.artistName)}","genre":"${escapeJson(submission.genre)}","uid":"${submission.publicUserId}","aiUsed":${submission.aiUsed}}""")
        }
        zip
    }

    private data class UriMeta(val name:String,val mime:String,val size:Long)
    private fun uriMeta(uri:Uri):UriMeta {
        val resolver=appContext.contentResolver
        var name="file"; var size=-1L
        resolver.query(uri,arrayOf(OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE),null,null,null)?.use { c ->
            if(c.moveToFirst()) { c.getColumnIndex(OpenableColumns.DISPLAY_NAME).takeIf{it>=0}?.let{name=c.getString(it)?:name}; c.getColumnIndex(OpenableColumns.SIZE).takeIf{it>=0}?.let{size=c.getLong(it)} }
        }
        val mime=resolver.getType(uri).orEmpty().ifBlank { if(name.endsWith(".mp3",true)||name.endsWith(".wav",true)||name.endsWith(".m4a",true)) "audio/*" else if(name.endsWith(".jpg",true)||name.endsWith(".png",true)||name.endsWith(".webp",true)) "image/*" else "application/octet-stream" }
        return UriMeta(name.take(180),mime.take(120),size)
    }

    fun analysisEstimate(tier:MembershipTier,pending:Int):String {
        val base=when(commercialTier(tier)){MembershipTier.DIAMANTE->1 to 2;MembershipTier.OURO->1 to 4;else->2 to 7}
        val extra=when { pending>=40->3;pending>=20->2;pending>=8->1;else->0 }
        return "${base.first}–${base.second+extra} dia(s) • análise manual"
    }

    private fun submissionFrom(s: DataSnapshot): StreamSubmission? {
        val id = s.child("id").getValue(String::class.java) ?: s.key ?: return null
        return StreamSubmission(
            id = id,
            musicId = s.child("musicId").getValue(String::class.java).orEmpty().ifBlank { sonusMusicPublicId(id) },
            uid = s.child("uid").getValue(String::class.java).orEmpty(),
            publicUserId = s.child("publicUserId").getValue(String::class.java).orEmpty(),
            title = s.child("title").getValue(String::class.java).orEmpty(),
            artistName = s.child("artistName").getValue(String::class.java).orEmpty(),
            artistId = s.child("artistId").getValue(String::class.java).orEmpty(),
            genre = s.child("genre").getValue(String::class.java).orEmpty(),
            lyrics = s.child("lyrics").getValue(String::class.java).orEmpty(),
            lrc = s.child("lrc").getValue(String::class.java).orEmpty(),
            aiUsed = s.child("aiUsed").getValue(Boolean::class.java) == true,
            aiImitatesRealPerson = s.child("aiImitatesRealPerson").getValue(Boolean::class.java) == true,
            status = s.child("status").getValue(String::class.java) ?: StreamSubmissionStatus.RECEIVED.name,
            audioStoragePath = s.child("audioStoragePath").getValue(String::class.java).orEmpty(),
            coverStoragePath = s.child("coverStoragePath").getValue(String::class.java).orEmpty(),
            audioDownloadUrl = s.child("audioDownloadUrl").getValue(String::class.java).orEmpty(),
            coverDownloadUrl = s.child("coverDownloadUrl").getValue(String::class.java).orEmpty(),
            audioOriginalName = s.child("audioOriginalName").getValue(String::class.java) ?: "audio.mp3",
            audioMime = s.child("audioMime").getValue(String::class.java) ?: "audio/mpeg",
            coverOriginalName = s.child("coverOriginalName").getValue(String::class.java) ?: "cover.jpg",
            coverMime = s.child("coverMime").getValue(String::class.java) ?: "image/jpeg",
            planAtSubmission = s.child("planAtSubmission").getValue(String::class.java) ?: "FREE",
            priority = s.child("priority").getValue(Long::class.java)?.toInt() ?: 0,
            createdAt = s.child("createdAt").getValue(Long::class.java) ?: 0L,
            reviewedAt = s.child("reviewedAt").getValue(Long::class.java),
            violationLevel = s.child("violationLevel").getValue(String::class.java) ?: StreamViolationLevel.NONE.name,
            violationReason = s.child("violationReason").getValue(String::class.java),
            quotaConsumed = s.child("quotaConsumed").getValue(Boolean::class.java) == true,
            quotaConsumedAt = s.child("quotaConsumedAt").getValue(Long::class.java),
            reviewerUid = s.child("reviewerUid").getValue(String::class.java),
            publishedFileId = s.child("publishedFileId").getValue(Long::class.java),
            pCloudAudioName = s.child("pCloudAudioName").getValue(String::class.java).orEmpty(),
            pCloudLyricsName = s.child("pCloudLyricsName").getValue(String::class.java).orEmpty(),
            telegramMessageId = s.child("telegramMessageId").getValue(Long::class.java),
            submissionDestination = s.child("submissionDestination").getValue(String::class.java).orEmpty(),
            processedBitrateKbps = s.child("processedBitrateKbps").getValue(Long::class.java)?.toInt() ?: 0,
            coverEmbedded = s.child("coverEmbedded").getValue(Boolean::class.java) == true,
            lyricsFileType = s.child("lyricsFileType").getValue(String::class.java).orEmpty(),
            publishedAt = s.child("publishedAt").getValue(Long::class.java),
            liveAt = s.child("liveAt").getValue(Long::class.java),
            liveNotifiedAt = s.child("liveNotifiedAt").getValue(Long::class.java)
        )
    }

    private fun violationNotificationText(level: StreamViolationLevel, reason: String): String {
        val consequence = when(level) {
            StreamViolationLevel.LIGHT -> "Perda de 0,5 ponto de credibilidade; a cota não foi consumida e você pode corrigir e reenviar."
            StreamViolationLevel.MEDIUM -> "Perda de 2 pontos de credibilidade; a cota foi consumida e recomendações podem ser reduzidas durante a sanção."
            StreamViolationLevel.SEVERE -> "Perda de 3 pontos de credibilidade; a cota foi consumida e novos envios podem ser suspensos."
            else -> "Envio revisado pela equipe."
        }
        val recurrence = if(level == StreamViolationLevel.LIGHT) "" else " Se houver mais 2 violações qualificadas nos próximos 30 dias, sua conta poderá ficar suspensa para novos envios."
        return "Verificamos cuidadosamente seu envio ao SONUS Stream e constatamos uma violação das nossas regras: ${reason.ifBlank { level.label }}. ${level.label}. $consequence$recurrence"
    }

    private fun downloadUrlToFile(url: String, file: File) {
        val conn = java.net.URL(url).openConnection() as java.net.HttpURLConnection
        conn.connectTimeout = 15_000
        conn.readTimeout = 60_000
        conn.instanceFollowRedirects = true
        conn.inputStream.use { input -> file.outputStream().use { output -> input.copyTo(output) } }
        conn.disconnect()
    }

    private fun safe(v: String) = v.replace(Regex("[^A-Za-z0-9._-]"), "_").take(60).ifBlank { "track" }
    private fun escapeJson(v: String) = v.replace("\\", "\\\\").replace("\"", "\\\"")
}

@Composable
private fun SonusArtistMark(modifier: Modifier = Modifier) {
    Surface(modifier=modifier.size(46.dp),shape=RoundedCornerShape(15.dp),color=Color(0xFF103D49),border=BorderStroke(1.dp,Color(0xFF63E2C2).copy(alpha=.55f))) {
        Box(contentAlignment=Alignment.Center) {
            Icon(Icons.Default.MusicNote,null,tint=Color(0xFF63E2C2),modifier=Modifier.size(27.dp))
            Icon(Icons.Default.AutoAwesome,null,tint=Color.White,modifier=Modifier.size(13.dp).align(Alignment.TopEnd).offset((-5).dp,5.dp))
        }
    }
}

@Composable
private fun SonusArtistAvatarPreview(user: AuthUser, avatarId: String, modifier: Modifier = Modifier) {
    val googleBitmap by produceState<android.graphics.Bitmap?>(initialValue = null, user.photoUrl, avatarId) {
        val photoUrl = user.photoUrl.orEmpty()
        value = if (avatarId.isBlank() && photoUrl.isNotBlank()) withContext(Dispatchers.IO) {
            runCatching {
                val conn = URL(photoUrl).openConnection().apply { connectTimeout = 5_000; readTimeout = 8_000 }
                conn.getInputStream().use { BitmapFactory.decodeStream(it) }
            }.getOrNull()
        } else null
    }
    when {
        avatarId.isNotBlank() && SonusAvatarCatalog.byId(avatarId) != null -> SonusAvatarArtwork(avatarId, modifier.clip(CircleShape))
        googleBitmap != null -> Image(googleBitmap!!.asImageBitmap(), "Avatar do artista", modifier.clip(CircleShape), contentScale = ContentScale.Crop)
        else -> SonusAvatarArtwork(SonusAvatarCatalog.instruments.first().id, modifier.clip(CircleShape))
    }
}

@Composable
fun SonusStreamCreatorCenter(
    user: AuthUser,
    tier: MembershipTier,
    suggestedArtistName: String = "",
    mode: StreamCenterMode = StreamCenterMode.CREATOR,
    onBack: () -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val repo = remember { SonusStreamPlatformRepository(context) }
    val moderationMode = mode == StreamCenterMode.MODERATION && (user.role == AccountRole.OWNER || user.role == AccountRole.SUPPORT)
    val submissions by remember(user.uid, moderationMode) { repo.submissionFlow(user.uid, moderationMode) }.collectAsState(initial = emptyList())
    val contentReports by remember(moderationMode) { repo.contentReportFlow(moderationMode) }.collectAsState(initial = emptyList())
    val integrityAlerts by remember(moderationMode) { repo.integrityAlertFlow(moderationMode) }.collectAsState(initial = emptyList())
    var showTerms by remember { mutableStateOf(!repo.acceptedTerms(user.uid)) }
    var showUpload by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<StreamSubmission?>(null) }
    var profile by remember { mutableStateOf<StreamCreatorProfile?>(null) }
    var artistProfile by remember { mutableStateOf<StreamArtistProfile?>(null) }
    var artistProfiles by remember { mutableStateOf<List<StreamArtistProfile>>(emptyList()) }
    var showArtistChange by remember { mutableStateOf(false) }
    var showAvatarPicker by remember { mutableStateOf(false) }
    var deleteCandidate by remember { mutableStateOf<StreamSubmission?>(null) }
    var deleteRejectedBusy by remember { mutableStateOf(false) }
    var creatorFeedback by remember { mutableStateOf<String?>(null) }
    var creatorTab by rememberSaveable { mutableStateOf("APROVADAS") }
    var moderationTab by rememberSaveable { mutableStateOf("RECEBIDAS") }
    val moderationHistoryPrefs = remember { context.getSharedPreferences("sonus_stream_moderation_history_v1", Context.MODE_PRIVATE) }
    var moderationHiddenRevision by remember { mutableIntStateOf(0) }
    var clearModerationHistoryTab by remember { mutableStateOf<String?>(null) }
    var localHiddenRevision by remember { mutableIntStateOf(0) }
    var localClock by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val avatarPrefs = remember(user.uid) { context.getSharedPreferences("sonus_artist_avatar_v1", Context.MODE_PRIVATE) }
    var artistAvatarId by remember(user.uid) { mutableStateOf(avatarPrefs.getString("avatar_${user.uid}", "").orEmpty()) }
    val scope = rememberCoroutineScope()
    var quotaUsed by remember { mutableStateOf(0 to 0) }
    var bonusUploads by remember { mutableIntStateOf(0) }
    val quota = submissionQuota(tier)
    LaunchedEffect(user.uid, tier, submissions.size, moderationMode) {
        if (!moderationMode) {
            profile = runCatching { repo.profile(user.uid) }.getOrNull()
            val ensuredArtist = runCatching { repo.ensureAccountArtistProfile(user, suggestedArtistName) }.getOrNull()
            artistProfiles = ensuredArtist?.let { listOf(it) }.orEmpty()
            artistProfile = ensuredArtist
            quotaUsed = runCatching { repo.quotaUsage(user.uid, tier) }.getOrDefault(0 to 0)
            bonusUploads = runCatching { repo.bonusUploads(user.uid) }.getOrDefault(0)
        }
    }
    LaunchedEffect(moderationMode) {
        if (!moderationMode) while (true) {
            localClock = System.currentTimeMillis()
            delay(15_000L)
        }
    }
    fun moderationHiddenIds(tab: String): Set<String> =
        moderationHistoryPrefs.getStringSet("hidden_$tab", emptySet())?.toSet().orEmpty()

    fun matchesModerationTab(submission: StreamSubmission, tab: String): Boolean = when (tab) {
        "RECEBIDAS" -> submission.status in setOf(
            StreamSubmissionStatus.RECEIVED.name,
            StreamSubmissionStatus.REVIEWING.name,
            StreamSubmissionStatus.CHANGES_REQUESTED.name
        )
        "APROVADAS" -> submission.status in setOf(StreamSubmissionStatus.APPROVED.name, StreamSubmissionStatus.PUBLISHED.name)
        "REJEITADAS" -> submission.status == StreamSubmissionStatus.REJECTED.name
        else -> false
    }

    val moderationVisibleSubmissions = remember(submissions, moderationTab, moderationHiddenRevision, moderationMode) {
        if (!moderationMode) emptyList() else {
            val hidden = if (moderationTab == "RECEBIDAS") emptySet() else moderationHiddenIds(moderationTab)
            submissions.filter { matchesModerationTab(it, moderationTab) && it.id !in hidden }
        }
    }
    val moderationCounts = remember(submissions, moderationHiddenRevision, moderationMode) {
        if (!moderationMode) emptyMap() else listOf("RECEBIDAS", "APROVADAS", "REJEITADAS").associateWith { tab ->
            val hidden = if (tab == "RECEBIDAS") emptySet() else moderationHiddenIds(tab)
            submissions.count { matchesModerationTab(it, tab) && it.id !in hidden }
        }
    }
    val creatorVisibleSubmissions = remember(submissions, creatorTab, localHiddenRevision, localClock, moderationMode) {
        if (moderationMode) emptyList()
        else submissions.filterNot { it.status == StreamSubmissionStatus.REJECTED.name && repo.isRejectedLocallyHidden(it.id) }
            .filter { submission ->
                if (creatorTab == "REJEITADAS") submission.status == StreamSubmissionStatus.REJECTED.name
                else submission.status != StreamSubmissionStatus.REJECTED.name && submission.status != StreamSubmissionStatus.REMOVED.name
            }
    }
    val visibleSubmissions = if (moderationMode) moderationVisibleSubmissions else creatorVisibleSubmissions

    selected?.let { submission ->
        SonusSubmissionDetail(repo, submission, user, moderationMode, onBack = { selected = null })
        return
    }

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(top=12.dp,bottom=30.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Voltar") }
                Column(Modifier.weight(1f)) {
                    Text(if (moderationMode) "Moderação SONUS Stream" else "Para artistas", fontWeight = FontWeight.Black, fontSize = 24.sp)
                    Text(if (moderationMode) "Fila interna de análise e publicação" else "Envie sua música para análise do catálogo", style = MaterialTheme.typography.bodySmall)
                }
                if (!moderationMode) FilledTonalIconButton(onClick={showUpload=true}) { SonusArtistMark(Modifier.size(38.dp)) }
            }
        }
        if (moderationMode) {
            item {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .28f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .10f))
                ) {
                    Column(Modifier.fillMaxWidth().padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            listOf("RECEBIDAS" to "Recebidas", "APROVADAS" to "Aprovadas", "REJEITADAS" to "Rejeitadas").forEach { (key, label) ->
                                FilterChip(
                                    selected = moderationTab == key,
                                    onClick = { moderationTab = key },
                                    label = { Text("$label (${moderationCounts[key] ?: 0})", fontSize = 9.sp) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                        if (moderationTab != "RECEBIDAS") {
                            TextButton(
                                onClick = { if (moderationVisibleSubmissions.isNotEmpty()) clearModerationHistoryTab = moderationTab },
                                enabled = moderationVisibleSubmissions.isNotEmpty(),
                                modifier = Modifier.align(Alignment.End)
                            ) {
                                Icon(Icons.Default.CleaningServices, null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(5.dp))
                                Text("Limpar histórico")
                            }
                        }
                    }
                }
            }
        }
        if (!moderationMode) {
        item {
            Surface(shape=RoundedCornerShape(18.dp),color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.28f),border=BorderStroke(1.dp,MaterialTheme.colorScheme.outline.copy(alpha=.10f))) {
                Column(Modifier.fillMaxWidth().padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        SonusArtistAvatarPreview(user,artistAvatarId,Modifier.size(46.dp));Spacer(Modifier.width(9.dp))
                        Column(Modifier.weight(1f)) { Text(artistProfile?.artistName ?: suggestedArtistName.ifBlank { user.displayName ?: "Artista SONUS" },fontWeight=FontWeight.ExtraBold);Text("Este é o artista da sua conta SONUS e é usado automaticamente no Stream.",style=MaterialTheme.typography.labelSmall) }
                    }
                    if(artistProfiles.size>1) LazyRow(horizontalArrangement=Arrangement.spacedBy(6.dp)){items(artistProfiles,key={it.artistId}){profileItem->FilterChip(selected=artistProfile?.artistId==profileItem.artistId,onClick={artistProfile=profileItem},label={Text(profileItem.artistName,maxLines=1,fontSize=9.sp)})}}
                    Row(horizontalArrangement=Arrangement.spacedBy(9.dp)) {
                        TextButton(enabled=artistProfile!=null,onClick={showArtistChange=true},modifier=Modifier.weight(1f)){Text("Alterar nome")}
                        OutlinedButton(enabled=artistProfile!=null,onClick={showAvatarPicker=true},modifier=Modifier.weight(1f)){Icon(Icons.Default.Face,null,modifier=Modifier.size(17.dp));Spacer(Modifier.width(5.dp));Text("Avatar")}
                    }
                }
            }
        }
        item {
            Surface(modifier=Modifier.fillMaxWidth().clickable{showUpload=true},shape=RoundedCornerShape(20.dp),color=Color(0xFF0E3A46),border=BorderStroke(1.dp,Color(0xFF63E2C2).copy(alpha=.45f))) {
                Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically) {
                    SonusArtistMark();Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)){Text("Enviar para o SONUS Stream",color=Color.White,fontWeight=FontWeight.Black,fontSize=17.sp);Text("Música • capa • letra • gênero",color=Color.White.copy(alpha=.68f),style=MaterialTheme.typography.labelSmall)}
                    Icon(Icons.Default.ArrowForwardIos,null,tint=Color(0xFF63E2C2),modifier=Modifier.size(17.dp))
                }
            }
        }
        }
        if (!moderationMode) item {
            val ownerUnlimited = user.role == AccountRole.OWNER
            val usedText = if (ownerUnlimited) "0" else quotaUsed.second.coerceAtLeast(0).toString().padStart(2, '0')
            val limitText = if (ownerUnlimited) "∞" else (quota.monthly + bonusUploads).coerceAtLeast(0).toString().padStart(2, '0')
            Surface(
                shape=RoundedCornerShape(18.dp),
                color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.58f),
                border=BorderStroke(1.dp,MaterialTheme.colorScheme.outline.copy(alpha=.10f))
            ) {
                Row(Modifier.fillMaxWidth().padding(horizontal=14.dp,vertical=12.dp),verticalAlignment=Alignment.CenterVertically) {
                    Text("Seu limite",fontWeight=FontWeight.ExtraBold,modifier=Modifier.weight(1f))
                    Text("$usedText / $limitText",fontWeight=FontWeight.Black,fontSize=18.sp)
                }
            }
        }
        if (!moderationMode) item {
            Surface(
                shape=RoundedCornerShape(16.dp),
                color=Color(0xFF090A0F),
                border=BorderStroke(1.dp,Color.White.copy(alpha=.08f))
            ) {
                Row(Modifier.fillMaxWidth().padding(horizontal=13.dp,vertical=12.dp),verticalAlignment=Alignment.CenterVertically) {
                    Icon(Icons.Default.Schedule,null,tint=Color.White.copy(alpha=.72f));Spacer(Modifier.width(9.dp))
                    Column(Modifier.weight(1f)){
                        Text("Análise manual",fontWeight=FontWeight.ExtraBold,color=Color.White)
                        Text("O prazo varia conforme seu plano e o volume de envios.",style=MaterialTheme.typography.labelSmall,color=Color.White.copy(alpha=.58f))
                    }
                }
            }
        }
        if (!moderationMode) item {
            Surface(shape=RoundedCornerShape(18.dp),color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.22f),border=BorderStroke(1.dp,MaterialTheme.colorScheme.outline.copy(alpha=.08f))) {
                Row(Modifier.fillMaxWidth().padding(6.dp),horizontalArrangement=Arrangement.spacedBy(6.dp),verticalAlignment=Alignment.CenterVertically) {
                    Button(
                        onClick={creatorTab="APROVADAS"},
                        modifier=Modifier.weight(1f),
                        colors=ButtonDefaults.buttonColors(containerColor=if(creatorTab=="APROVADAS") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                    ){Text("MÚSICAS APROVADAS",fontSize=10.sp,fontWeight=FontWeight.Black)}
                    TextButton(onClick={creatorTab="REJEITADAS"},modifier=Modifier.weight(.56f)) {
                        Text("REJEITADAS",fontSize=9.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=if(creatorTab=="REJEITADAS").90f else .55f))
                    }
                }
            }
        }
        if (moderationMode && integrityAlerts.any { it.status == "OPEN" }) {
            item { Text("Integridade do Stream", fontWeight = FontWeight.Black, fontSize = 18.sp) }
            items(integrityAlerts.filter { it.status == "OPEN" }.take(20), key={"integrity_${it.id}"}) { alert ->
                Surface(shape=RoundedCornerShape(17.dp), color=Color(0xFF3A2810).copy(alpha=.34f), border=BorderStroke(1.dp,Color(0xFFFFC857).copy(alpha=.30f))) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement=Arrangement.spacedBy(6.dp)) {
                        Text("${alert.type} • ${alert.targetId}", fontWeight=FontWeight.ExtraBold)
                        Text(alert.message.ifBlank { "Comportamento incomum detectado. Revisão recomendada." }, style=MaterialTheme.typography.bodySmall)
                        if (alert.countInMinute > 0) Text("Eventos no minuto: ${alert.countInMinute}", style=MaterialTheme.typography.labelSmall)
                        TextButton(onClick={scope.launch{repo.reviewIntegrityAlert(alert.id,user)}}) { Text("Marcar como revisado") }
                    }
                }
            }
        }
        if (moderationMode && contentReports.any { it.status == "OPEN" }) {
            item { Text("Denúncias do catálogo", fontWeight = FontWeight.Black, fontSize = 18.sp) }
            items(contentReports.filter { it.status == "OPEN" }.take(20), key={"report_${it.id}"}) { report ->
                Surface(shape=RoundedCornerShape(17.dp),color=MaterialTheme.colorScheme.errorContainer.copy(alpha=.18f),border=BorderStroke(1.dp,MaterialTheme.colorScheme.error.copy(alpha=.18f))) {
                    Column(Modifier.fillMaxWidth().padding(12.dp),verticalArrangement=Arrangement.spacedBy(6.dp)) {
                        Text(report.title.ifBlank { "Faixa ${report.fileId}" },fontWeight=FontWeight.ExtraBold,maxLines=1,overflow=TextOverflow.Ellipsis)
                        Text("${report.artist.ifBlank { "Artista não informado" }} • ${report.reason}",style=MaterialTheme.typography.labelSmall)
                        if(report.details.isNotBlank()) Text(report.details,style=MaterialTheme.typography.bodySmall,maxLines=3,overflow=TextOverflow.Ellipsis)
                        if(user.role==AccountRole.OWNER) Row(horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                            OutlinedButton(onClick={scope.launch{repo.reviewContentReport(report,user,suspendDays=7)}},modifier=Modifier.weight(1f)){Text("Revisar 7 dias",fontSize=10.sp)}
                            TextButton(onClick={scope.launch{repo.reviewContentReport(report,user,dismiss=true)}},modifier=Modifier.weight(1f)){Text("Arquivar",fontSize=10.sp)}
                        } else Text("Aguardando decisão do OWNER.",style=MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
        if (visibleSubmissions.isEmpty()) item {
            Text(
                if (moderationMode) when (moderationTab) {
                    "RECEBIDAS" -> "Nenhum envio aguardando análise."
                    "APROVADAS" -> "Nenhum registro no histórico de aprovadas."
                    "REJEITADAS" -> "Nenhum registro no histórico de rejeitadas."
                    else -> "Nenhum registro nesta área."
                }
                else if(creatorTab=="REJEITADAS") "Nenhuma música rejeitada nesta lista."
                else "Você ainda não possui músicas nesta área.",
                style=MaterialTheme.typography.bodySmall
            )
        }
        items(visibleSubmissions,key={it.id}) { s ->
            val userAnalysisAvailable = s.status in setOf(
                StreamSubmissionStatus.REJECTED.name,
                StreamSubmissionStatus.APPROVED.name,
                StreamSubmissionStatus.PUBLISHED.name
            )
            val userAdjustmentAvailable = s.status == StreamSubmissionStatus.CHANGES_REQUESTED.name
            val cardModifier = if (moderationMode) Modifier.fillMaxWidth().clickable { selected = s } else Modifier.fillMaxWidth()
            Surface(modifier=cardModifier,shape=RoundedCornerShape(17.dp),color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.30f),border=BorderStroke(1.dp,MaterialTheme.colorScheme.outline.copy(alpha=.10f))) {
                Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically){
                        Icon(Icons.Default.AudioFile,null,tint=MaterialTheme.colorScheme.primary);Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(s.title.ifBlank{"Sem título"},fontWeight=FontWeight.ExtraBold,maxLines=1,overflow=TextOverflow.Ellipsis);Text("${s.artistName} • ${s.genre}",style=MaterialTheme.typography.labelSmall,maxLines=1);if(moderationMode){Text("Canal: ${s.publicUserId.ifBlank { s.uid.take(10) }}",style=MaterialTheme.typography.labelSmall);val receivedAt=runCatching{Instant.ofEpochMilli(s.createdAt).atZone(java.time.ZoneId.systemDefault()).toLocalDateTime()}.getOrNull();receivedAt?.let{Text("Recebida: ${it.toLocalDate()} ${String.format(Locale.ROOT,"%02d:%02d",it.hour,it.minute)}",style=MaterialTheme.typography.labelSmall)}}};Text(if(moderationMode) when(s.status){StreamSubmissionStatus.RECEIVED.name,StreamSubmissionStatus.REVIEWING.name,StreamSubmissionStatus.CHANGES_REQUESTED.name->"Aguardando análise";StreamSubmissionStatus.APPROVED.name,StreamSubmissionStatus.PUBLISHED.name->"Aprovada";StreamSubmissionStatus.REJECTED.name->"Rejeitada";else->runCatching{StreamSubmissionStatus.valueOf(s.status).label}.getOrDefault(s.status)} else repo.localPublicationLabel(s,localClock),fontSize=9.sp,fontWeight=FontWeight.Bold,color=if(!moderationMode&&repo.isLocallyLive(s,localClock))Color(0xFF67E77D) else LocalContentColor.current)
                    }
                    if (!moderationMode && userAnalysisAvailable) {
                        if (s.status == StreamSubmissionStatus.REJECTED.name) {
                            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick={selected=s},modifier=Modifier.weight(1f)) {
                                    Icon(Icons.Default.Analytics,null,modifier=Modifier.size(16.dp));Spacer(Modifier.width(5.dp));Text("Análise")
                                }
                                OutlinedButton(onClick={deleteCandidate=s},modifier=Modifier.weight(1f),colors=ButtonDefaults.outlinedButtonColors(contentColor=MaterialTheme.colorScheme.error)) {
                                    Icon(Icons.Default.DeleteOutline,null,modifier=Modifier.size(16.dp));Spacer(Modifier.width(5.dp));Text("Remover registro")
                                }
                            }
                        } else {
                            OutlinedButton(onClick={selected=s},modifier=Modifier.fillMaxWidth()) {
                                Icon(Icons.Default.Analytics,null,modifier=Modifier.size(17.dp));Spacer(Modifier.width(6.dp));Text("Análise")
                            }
                        }
                    } else if (!moderationMode && userAdjustmentAvailable) {
                        OutlinedButton(onClick={selected=s},modifier=Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.EditNote,null,modifier=Modifier.size(17.dp));Spacer(Modifier.width(6.dp));Text("Ver ajuste solicitado")
                        }
                    }
                }
            }
        }
        if (!moderationMode) item { TextButton(onClick={showTerms=true},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Gavel,null);Spacer(Modifier.width(6.dp));Text("Regras para envio") } }
    }

    clearModerationHistoryTab?.let { tab ->
        val label = if (tab == "APROVADAS") "aprovadas" else "rejeitadas"
        AlertDialog(
            onDismissRequest = { clearModerationHistoryTab = null },
            title = { Text("Limpar histórico de $label?") },
            text = { Text("Isso remove apenas os registros desta lista de moderação neste aparelho. Catálogo, música publicada, storage, arquivos e estatísticas permanecem intactos.") },
            confirmButton = {
                Button(onClick = {
                    val existing = moderationHiddenIds(tab).toMutableSet()
                    existing.addAll(submissions.filter { matchesModerationTab(it, tab) }.map { it.id })
                    moderationHistoryPrefs.edit().putStringSet("hidden_$tab", existing).apply()
                    moderationHiddenRevision++
                    clearModerationHistoryTab = null
                }) { Text("Limpar histórico") }
            },
            dismissButton = { TextButton(onClick = { clearModerationHistoryTab = null }) { Text("Cancelar") } }
        )
    }

    deleteCandidate?.let { candidate ->
        AlertDialog(
            onDismissRequest={if(!deleteRejectedBusy) deleteCandidate=null},
            title={Text("Remover registro da lista?",fontWeight=FontWeight.Black)},
            text={Text("${candidate.title} será ocultada apenas neste aparelho. Se o app for reinstalado, ela pode voltar a aparecer na guia Rejeitadas.")},
            confirmButton={
                Button(
                    enabled=!deleteRejectedBusy,
                    onClick={scope.launch{
                        deleteRejectedBusy=true
                        val r=repo.deleteRejectedSubmission(user,candidate)
                        deleteRejectedBusy=false
                        creatorFeedback=if(r.isSuccess) "Envio rejeitado removido da sua lista." else "Não foi possível remover: ${r.exceptionOrNull()?.message ?: "erro desconhecido"}"
                        Toast.makeText(context,creatorFeedback,Toast.LENGTH_LONG).show()
                        if(r.isSuccess) { localHiddenRevision++; deleteCandidate=null }
                    }},
                    colors=ButtonDefaults.buttonColors(containerColor=MaterialTheme.colorScheme.error)
                 ){Text(if(deleteRejectedBusy) "Removendo…" else "Remover registro")}
            },
            dismissButton={TextButton(enabled=!deleteRejectedBusy,onClick={deleteCandidate=null}){Text("Cancelar")}}
        )
    }

    if (showAvatarPicker) {
        val owner = user.role == AccountRole.OWNER
        val available = SonusAvatarCatalog.all.filter { SonusAvatarCatalog.unlocked(it, tier, owner) }
        AlertDialog(
            onDismissRequest={showAvatarPicker=false},
            title={Text("Avatar do artista",fontWeight=FontWeight.Black)},
            text={Column(verticalArrangement=Arrangement.spacedBy(10.dp)){
                if(!user.photoUrl.isNullOrBlank()) OutlinedButton(onClick={artistAvatarId="";avatarPrefs.edit().remove("avatar_${user.uid}").apply();showAvatarPicker=false},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.AccountCircle,null);Spacer(Modifier.width(6.dp));Text("Usar foto da conta Google")}
                Text("Avatares SONUS",fontWeight=FontWeight.Bold)
                LazyRow(horizontalArrangement=Arrangement.spacedBy(10.dp)){
                    items(available,key={it.id}){spec->
                        Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.width(70.dp).clickable{artistAvatarId=spec.id;avatarPrefs.edit().putString("avatar_${user.uid}",spec.id).apply();showAvatarPicker=false}){
                            SonusAvatarArtwork(spec.id,Modifier.size(58.dp));Text(spec.title,fontSize=8.sp,maxLines=1,overflow=TextOverflow.Ellipsis)
                        }
                    }
                }
                Text("A escolha fica no aparelho e não envia imagem para servidor.",style=MaterialTheme.typography.labelSmall)
            }},
            confirmButton={TextButton(onClick={showAvatarPicker=false}){Text("Fechar")}}
        )
    }

    if (showTerms) SonusStreamTermsDialog(user.uid, repo, requireAcceptance = !repo.acceptedTerms(user.uid), onClose = { showTerms = false })
    if (showUpload) SonusStreamUploadDialog(user, tier, repo, fixedArtistName=artistProfile?.artistName.orEmpty(), onClose={showUpload=false})
    if (showArtistChange) SonusArtistNameChangeDialog(user,repo,artistProfile?.artistId.orEmpty(),artistProfile?.artistName.orEmpty(),onClose={showArtistChange=false})
}

@Composable
private fun SonusArtistStudio(
    repo: SonusStreamPlatformRepository,
    user: AuthUser,
    tier: MembershipTier,
    artists: List<StreamArtistProfile>,
    onBack: () -> Unit,
    onUpload: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var selected by remember(artists) { mutableStateOf(artists.firstOrNull()) }
    var analytics by remember { mutableStateOf<StreamArtistAnalyticsSnapshot?>(null) }
    var monthAnalytics by remember { mutableStateOf<StreamArtistAnalyticsSnapshot?>(null) }
    val studioSubmissions by remember(user.uid) { repo.submissionFlow(user.uid, false) }.collectAsState(initial = emptyList())
    var milestones by remember { mutableStateOf<List<String>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var period by remember { mutableStateOf("7 dias") }
    var sort by remember { mutableStateOf("Mais tocadas") }
    var analyticsError by remember { mutableStateOf<String?>(null) }
    var accountSummary by remember { mutableStateOf<StreamArtistAnalyticsSnapshot?>(null) }
    var selectedSong by remember { mutableStateOf<StreamArtistSongAnalytics?>(null) }

    fun periodDays() = when (period) {
        "48h" -> 2
        "7 dias" -> 7
        "15 dias" -> 15
        "30 dias" -> 30
        "90 dias" -> 90
        "180 dias" -> 180
        "365 dias" -> 365
        "Total" -> 0
        else -> 7
    }
    fun reload() {
        val artist = selected ?: return
        scope.launch {
            loading = true
            analyticsError = null
            val result = runCatching { repo.artistAnalytics(artist.artistId, periodDays()) }
            analytics = result.getOrNull()
            analyticsError = result.exceptionOrNull()?.message
            monthAnalytics = if (periodDays() == -1) analytics else runCatching { repo.artistAnalytics(artist.artistId, -1) }.getOrNull()
            milestones = runCatching { repo.artistMilestones(artist.artistId) }.getOrDefault(emptyList())
            loading = false
        }
    }
    LaunchedEffect(selected?.artistId, period) {
        reload()
        // Métricas do artista vêm de outros aparelhos/ouvintes; atualize enquanto o Studio
        // estiver aberto sem tocar no motor local da aba “Você”.
        while (true) {
            delay(60_000L)
            reload()
        }
    }
    LaunchedEffect(artists.map { it.artistId }) {
        if (artists.size > 1) {
            val values = artists.mapNotNull { artist -> runCatching { repo.artistAnalytics(artist.artistId, 0) }.getOrNull() }
            if (values.isNotEmpty()) {
                accountSummary = StreamArtistAnalyticsSnapshot(
                    validPlays = values.sumOf { it.validPlays }, uniqueListeners = values.sumOf { it.uniqueListeners },
                    returningPlays = values.sumOf { it.returningPlays }, listeningMs = values.sumOf { it.listeningMs },
                    followers = values.sumOf { it.followers }, likes = values.sumOf { it.likes }, publishedSongs = values.sumOf { it.publishedSongs },
                    shares = values.sumOf { it.shares }, videoShares = values.sumOf { it.videoShares },
                    videoGenerations = values.sumOf { it.videoGenerations }, videoExports = values.sumOf { it.videoExports }
                )
            }
        } else accountSummary = null
    }

    val a = analytics
    val songs = remember(a, sort) {
        when (sort) {
            "Retenção" -> a?.songs?.sortedByDescending { it.retention }
            "Horas" -> a?.songs?.sortedByDescending { it.listeningMs }
            "Curtidas" -> a?.songs?.sortedByDescending { it.likes }
            "Seguidores" -> a?.songs?.sortedByDescending { it.followersGenerated }
            "Recentes" -> a?.songs?.sortedByDescending { it.publishedAt }
            else -> a?.songs?.sortedByDescending { it.validPlays }
        }.orEmpty()
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 32.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Voltar") }
                Column(Modifier.weight(1f)) {
                    Text("SONUS Artist Studio", fontWeight = FontWeight.Black, fontSize = 24.sp)
                    Text("Desempenho, público e crescimento do seu artista", style = MaterialTheme.typography.bodySmall)
                }
                IconButton(onClick = { reload() }) { Icon(Icons.Default.Refresh, "Atualizar") }
            }
        }
        if (artists.size > 1) item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                items(artists, key = { it.artistId }) { p ->
                    FilterChip(selected = selected?.artistId == p.artistId, onClick = { selected = p }, label = { Text(p.artistName, maxLines = 1) })
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onUpload, enabled = selected != null, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.Upload, null, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(5.dp)); Text("Enviar música")
                }
            }
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(listOf("48h", "7 dias", "15 dias", "30 dias", "90 dias", "180 dias", "365 dias", "Total")) { v ->
                    FilterChip(selected = period == v, onClick = { period = v }, label = { Text(v, fontSize = 8.sp) })
                }
            }
        }
        if (loading) item { StudioLoadingSkeleton() }
        analyticsError?.let { message ->
            item {
                Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.errorContainer.copy(alpha = .18f)) {
                    Text("Analytics indisponível agora. ${message.take(140)}", Modifier.padding(10.dp), style = MaterialTheme.typography.labelSmall)
                }
            }
        }
        if (artists.size > 1 && accountSummary != null) item {
            Surface(shape = RoundedCornerShape(16.dp), color = Color(0xFF0E2630), border = BorderStroke(1.dp, Color(0xFF63E2C2).copy(alpha = .12f))) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Resumo da conta • ${artists.size} artistas", fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        StudioMetric(Modifier.weight(1f), "${accountSummary?.validPlays ?: 0}", "Plays")
                        StudioMetric(Modifier.weight(1f), "%.1f h".format(accountSummary?.listeningHours ?: 0.0), "Horas")
                        StudioMetric(Modifier.weight(1f), "${accountSummary?.followers ?: 0}", "Seguidores")
                        StudioMetric(Modifier.weight(1f), "${accountSummary?.publishedSongs ?: 0}", "Músicas")
                    }
                }
            }
        }
        item {
            Surface(shape = RoundedCornerShape(20.dp), color = Color(0xFF101D28), border = BorderStroke(1.dp, Color(0xFF63E2C2).copy(alpha = .18f))) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(selected?.artistName ?: "Artista", fontWeight = FontWeight.Black, fontSize = 19.sp)
                            Text("Visão geral • $period", style = MaterialTheme.typography.labelSmall)
                        }
                        Text(formatGrowth(a?.playGrowthPercent ?: 0.0), fontWeight = FontWeight.Black, color = if ((a?.playGrowthPercent ?: 0.0) >= 0) Color(0xFF63E2C2) else MaterialTheme.colorScheme.error)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StudioMetric(Modifier.weight(1f), "${a?.validPlays ?: 0}", "Reproduções")
                        StudioMetric(Modifier.weight(1f), "${a?.uniqueListeners ?: 0}", "Ouvintes")
                        StudioMetric(Modifier.weight(1f), "%.1f h".format(a?.listeningHours ?: 0.0), "Tempo ouvido")
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StudioMetric(Modifier.weight(1f), "${a?.followers ?: 0}", "Seguidores")
                        StudioMetric(Modifier.weight(1f), "+${a?.newFollowers ?: 0}", "Novos seguidores")
                        StudioMetric(Modifier.weight(1f), "${a?.publishedSongs ?: 0}", "Músicas")
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StudioMetric(Modifier.weight(1f), "${a?.likes ?: 0}", "Curtidas")
                        StudioMetric(Modifier.weight(1f), "${a?.pendingSubmissions ?: 0}", "Em análise")
                        StudioMetric(Modifier.weight(1f), "${a?.completions ?: 0}", "Conclusões")
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StudioMetric(Modifier.weight(1f), "${a?.shares ?: 0}", "Compartilhamentos")
                        StudioMetric(Modifier.weight(1f), "${a?.videoGenerations ?: 0}", "Vídeos gerados")
                        StudioMetric(Modifier.weight(1f), "${a?.videoExports ?: 0}", "Exportações")
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StudioMetric(Modifier.weight(1f), "${a?.videoShares ?: 0}", "Vídeos compartilhados")
                        StudioMetric(Modifier.weight(1f), "${a?.validPlays ?: 0}", "Reproduções")
                    }
                }
            }
        }

        item { Text(if (period == "48h") "Reproduções por hora" else "Evolução de reproduções", fontWeight = FontWeight.Black, fontSize = 17.sp) }
        item {
            when {
                period == "48h" && !a?.hourly.isNullOrEmpty() -> StudioHourlyMetricChart(a!!.hourly)
                !a?.daily.isNullOrEmpty() -> DailyTrendChart(a!!.daily)
                else -> StudioEmptyTrendChart("As reproduções externas válidas aparecerão aqui assim que houver dados neste período.")
            }
        }
        if (!a?.dailyListeningMs.isNullOrEmpty()) {
            item { Text("Tempo ouvido", fontWeight = FontWeight.Black, fontSize = 17.sp) }
            item { StudioDailyMetricChart(a!!.dailyListeningMs.mapValues { it.value / 60_000L }, "min") }
        }
        if (!a?.dailyFollowers.isNullOrEmpty()) {
            item { Text("Crescimento de seguidores", fontWeight = FontWeight.Black, fontSize = 17.sp) }
            item { StudioDailyMetricChart(a!!.dailyFollowers, "novos") }
        }

        item { Text("Previsão", fontWeight = FontWeight.Black, fontSize = 17.sp) }
        item { StudioForecastCard(monthAnalytics) }

        val selectedArtistId = selected?.artistId.orEmpty()
        val selectedArtistName = selected?.artistName.orEmpty()
        val analysisQueue = studioSubmissions.filter {
            (it.artistId == selectedArtistId || it.artistName.equals(selectedArtistName, true)) &&
                it.status in setOf(StreamSubmissionStatus.RECEIVED.name, StreamSubmissionStatus.REVIEWING.name, StreamSubmissionStatus.CHANGES_REQUESTED.name)
        }
        if (analysisQueue.isNotEmpty()) {
            item { Text("Músicas em análise", fontWeight = FontWeight.Black, fontSize = 17.sp) }
            items(analysisQueue.take(12), key = { "studio_pending_${it.id}" }) { submission ->
                Surface(shape = RoundedCornerShape(16.dp), color = Color(0xFF101D28), border = BorderStroke(1.dp, Color(0xFF63E2C2).copy(alpha = .14f))) {
                    Row(Modifier.fillMaxWidth().padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.HourglassTop, null, tint = Color(0xFF63E2C2))
                        Spacer(Modifier.width(9.dp))
                        Column(Modifier.weight(1f)) {
                            Text(submission.title.ifBlank { "Sem título" }, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(runCatching { StreamSubmissionStatus.valueOf(submission.status).label }.getOrDefault(submission.status), style = MaterialTheme.typography.labelSmall)
                        }
                        Text(java.time.Instant.ofEpochMilli(submission.createdAt).atZone(java.time.ZoneId.systemDefault()).toLocalDate().toString(), fontSize = 8.sp)
                    }
                }
            }
        }

        item { Text("Público", fontWeight = FontWeight.Black, fontSize = 17.sp) }
        item {
            Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .22f)) {
                Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StudioMetric(Modifier.weight(1f), "${a?.newListeners ?: 0}", "Ouvintes novos")
                        StudioMetric(Modifier.weight(1f), "${a?.returningListeners ?: 0}", "Recorrentes")
                        StudioMetric(Modifier.weight(1f), "${a?.followerListeners ?: 0}", "Seguidores ouvindo")
                    }
                    Text("Frequência média: %.2f reprodução(ões) por ouvinte no período.".format(a?.averageFrequency ?: 0.0), style = MaterialTheme.typography.labelSmall)
                }
            }
        }

        item { Text("Origem das reproduções", fontWeight = FontWeight.Black, fontSize = 17.sp) }
        item {
            Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .22f)) {
                Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    val total = (a?.sources?.values?.sum() ?: 0L).coerceAtLeast(1)
                    if (a?.sources.isNullOrEmpty()) Text("Ainda não há dados suficientes.", style = MaterialTheme.typography.bodySmall)
                    else a!!.sources.entries.sortedByDescending { it.value }.forEach { e ->
                        Column {
                            Row {
                                Text(sourceLabel(e.key), Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                Text("${e.value} • ${e.value * 100 / total}%", fontSize = 10.sp)
                            }
                            LinearProgressIndicator(progress = { e.value.toFloat() / total.toFloat() }, modifier = Modifier.fillMaxWidth().height(5.dp))
                        }
                    }
                }
            }
        }

        item { Text("Quando seu público ouve", fontWeight = FontWeight.Black, fontSize = 17.sp) }
        item {
            Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .22f)) {
                Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (a?.heatmap.isNullOrEmpty()) Text("Ainda não há dados suficientes para dias e horários.", style = MaterialTheme.typography.bodySmall)
                    else StudioAudienceHeatmap(a!!.heatmap)
                    val topHour = a?.hourly?.maxByOrNull { it.value }
                    val topDays = a?.weekday?.entries?.sortedByDescending { it.value }?.take(3).orEmpty()
                    topHour?.let { Text("Seus ouvintes aparecem mais por volta de ${"%02d".format(it.key)}h.", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold) }
                    if (topDays.isNotEmpty()) Text("Dias mais fortes: ${topDays.joinToString(" • ") { "${it.key} ${it.value}" }}", style = MaterialTheme.typography.labelSmall)
                }
            }
        }

        if (!a?.genres.isNullOrEmpty()) {
            item { Text("Gêneros que mais movimentam seu perfil", fontWeight = FontWeight.Black, fontSize = 17.sp) }
            item {
                Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .22f)) {
                    Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        val max = (a?.genres?.values?.maxOrNull() ?: 1L).coerceAtLeast(1L)
                        a!!.genres.entries.sortedByDescending { it.value }.take(8).forEach { e ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(e.key, Modifier.weight(1f), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                LinearProgressIndicator(progress = { e.value.toFloat() / max.toFloat() }, modifier = Modifier.width(90.dp).height(5.dp))
                                Spacer(Modifier.width(6.dp)); Text("${e.value}", fontSize = 9.sp)
                            }
                        }
                    }
                }
            }
        }

        item { Text("Metas da plataforma", fontWeight = FontWeight.Black, fontSize = 17.sp) }
        item {
            Surface(shape = RoundedCornerShape(18.dp), color = Color(0xFF15182A)) {
                Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    GoalBar("Seguidores", a?.followers?.toDouble() ?: 0.0, 1000.0, "${a?.followers ?: 0} / 1.000")
                    GoalBar("Horas de reprodução", a?.listeningHours ?: 0.0, 5000.0, "%.0f / 5.000 h".format(a?.listeningHours ?: 0.0))
                    if (milestones.isNotEmpty()) Text("Conquistas: ${milestones.joinToString(" • ")}", style = MaterialTheme.typography.labelSmall, color = Color(0xFFFFD66B))
                    else Text("Marcos liberam pequenos benefícios SONUS, sem promessa de monetização.", style = MaterialTheme.typography.labelSmall)
                }
            }
        }

        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Músicas", fontWeight = FontWeight.Black, fontSize = 17.sp, modifier = Modifier.weight(1f))
                var open by remember { mutableStateOf(false) }
                Box {
                    TextButton(onClick = { open = true }) { Text(sort); Icon(Icons.Default.ArrowDropDown, null) }
                    DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                        listOf("Mais tocadas", "Retenção", "Horas", "Curtidas", "Seguidores", "Recentes").forEach { v ->
                            DropdownMenuItem(text = { Text(v) }, onClick = { sort = v; open = false })
                        }
                    }
                }
            }
        }
        if (songs.isEmpty()) item { Text("As análises por música aparecerão depois das primeiras reproduções válidas.", style = MaterialTheme.typography.bodySmall) }
        items(songs, key = { it.fileId }) { song ->
            Surface(
                modifier = Modifier.fillMaxWidth().clickable { selectedSong = song },
                shape = RoundedCornerShape(17.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .24f)
            ) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(song.title, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        Text(formatGrowth(song.growthPercent), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                    Text("${song.validPlays} plays • ${song.uniqueListeners} ouvintes • %.1f h • retenção %.0f%%".format(song.listeningMs / 3600000.0, song.retention * 100), style = MaterialTheme.typography.labelSmall)
                    val avg = if (song.validPlays > 0) song.listeningMs / song.validPlays else 0L
                    val completion = if (song.validPlays > 0) song.completions * 100.0 / song.validPlays else 0.0
                    Text("Média ${formatShortDuration(avg)} • conclusão %.0f%% • replays ${song.replays} • curtidas ${song.likes} • seguidores +${song.followersGenerated}".format(completion), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("Compartilhamentos ${song.shares} • gerados ${song.videoGenerations} • exportações ${song.videoExports} • vídeos compartilhados ${song.videoShares}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    if (song.boostedPlays > 0) Text("Orgânico ${song.organicPlays} • Impulsionamento ${song.boostedPlays}", style = MaterialTheme.typography.labelSmall, color = Color(0xFFFFD66B))
                }
            }
        }
        item { Text("Dados são agregados pelo SONUS e não exibem informações pessoais dos ouvintes ao artista.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .55f)) }
    }

    selectedSong?.let { song -> SonusSongAnalyticsDialog(song = song, onClose = { selectedSong = null }) }
}

@Composable
private fun StudioLoadingSkeleton() {
    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        repeat(3) { Surface(Modifier.fillMaxWidth().height(38.dp), shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .20f)) {} }
    }
}

@Composable
private fun StudioEmptyTrendChart(message: String) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = Color(0xFF101D28),
        border = BorderStroke(1.dp, Color(0xFF63E2C2).copy(alpha = .12f))
    ) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.AutoGraph, null, tint = Color(0xFF63E2C2).copy(alpha = .75f))
            Spacer(Modifier.width(10.dp))
            Column {
                Text("Gráfico do artista", fontWeight = FontWeight.Bold)
                Text(message, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .62f))
            }
        }
    }
}

@Composable
private fun StudioHourlyMetricChart(values: Map<Int, Long>) {
    val entries = (0..23).map { it to (values[it] ?: 0L) }
    val max = (entries.maxOfOrNull { it.second } ?: 1L).coerceAtLeast(1L)
    Surface(shape = RoundedCornerShape(18.dp), color = Color(0xFF101D28), border = BorderStroke(1.dp, Color(0xFF63E2C2).copy(alpha = .12f))) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth().height(82.dp), horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.Bottom) {
                entries.forEach { (_, value) ->
                    val ratio = value.toFloat() / max.toFloat()
                    Box(Modifier.weight(1f).height((4 + 66 * ratio).dp).background(Color(0xFF63E2C2).copy(alpha = .15f + .72f * ratio), RoundedCornerShape(topStart = 3.dp, topEnd = 3.dp)))
                }
            }
            Row(Modifier.fillMaxWidth()) { listOf("00h","06h","12h","18h","23h").forEach { Text(it, Modifier.weight(1f), fontSize = 8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) } }
        }
    }
}

@Composable
private fun StudioForecastCard(month: StreamArtistAnalyticsSnapshot?) {
    val today = java.time.LocalDate.now()
    val elapsed = today.dayOfMonth.coerceAtLeast(1)
    val daysInMonth = today.lengthOfMonth()
    val enough = month != null && month.validPlays >= 3L && elapsed >= 2
    Surface(shape = RoundedCornerShape(18.dp), color = Color(0xFF11192A), border = BorderStroke(1.dp, Color(0xFF8A7CFF).copy(alpha = .28f))) {
        Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AutoGraph, null, tint = Color(0xFF9B91FF)); Spacer(Modifier.width(7.dp)); Text("Projeção deste mês", fontWeight = FontWeight.ExtraBold)
            }
            if (!enough || month == null) {
                Text("Sem dados suficientes para previsão.", style = MaterialTheme.typography.bodySmall)
            } else {
                val projectedPlays = kotlin.math.round(month.validPlays.toDouble() / elapsed.toDouble() * daysInMonth.toDouble()).toLong().coerceAtLeast(month.validPlays)
                val projectedHours = (month.listeningHours / elapsed.toDouble() * daysInMonth.toDouble()).coerceAtLeast(month.listeningHours)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StudioMetric(Modifier.weight(1f), "~$projectedPlays", "Reproduções")
                    StudioMetric(Modifier.weight(1f), "~%.1f h".format(projectedHours), "Horas ouvidas")
                }
                Text("Estimativa baseada somente na atividade interna do SONUS Stream no mês atual. É uma projeção, não uma garantia.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .62f))
            }
        }
    }
}

@Composable
private fun StudioDailyMetricChart(values: Map<String, Long>, suffix: String) {
    val entries = values.toSortedMap().entries.toList().takeLast(28)
    val max = (entries.maxOfOrNull { it.value } ?: 1L).coerceAtLeast(1L)
    Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .22f)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth().height(70.dp), horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.Bottom) {
                entries.forEach { e ->
                    val ratio = e.value.toFloat() / max.toFloat()
                    Box(Modifier.weight(1f).height((5 + 54 * ratio).dp).background(MaterialTheme.colorScheme.primary.copy(alpha = .22f + .68f * ratio), RoundedCornerShape(topStart = 3.dp, topEnd = 3.dp)))
                }
            }
            entries.maxByOrNull { it.value }?.let { Text("Pico: ${it.key} • ${it.value} $suffix", style = MaterialTheme.typography.labelSmall) }
        }
    }
}

@Composable
private fun StudioAudienceHeatmap(values: Map<String, Map<Int, Long>>) {
    val rows = values.toSortedMap().entries.toList().takeLast(7)
    val max = (rows.flatMap { it.value.values }.maxOrNull() ?: 1L).coerceAtLeast(1L)
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text("Mapa de calor • últimos dias do período", fontWeight = FontWeight.Bold, fontSize = 10.sp)
        Row(Modifier.fillMaxWidth()) { Spacer(Modifier.width(40.dp)); listOf(0, 6, 12, 18, 23).forEach { h -> Text("${h}h", Modifier.weight(1f), fontSize = 7.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) } }
        rows.forEach { row ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(row.key.takeLast(5), Modifier.width(40.dp), fontSize = 7.sp)
                (0..23).forEach { h ->
                    val ratio = (row.value[h] ?: 0L).toFloat() / max.toFloat()
                    Box(Modifier.weight(1f).height(9.dp).padding(0.5.dp).background(MaterialTheme.colorScheme.primary.copy(alpha = .06f + .88f * ratio), RoundedCornerShape(2.dp)))
                }
            }
        }
    }
}

@Composable
private fun SonusSongAnalyticsDialog(song: StreamArtistSongAnalytics, onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        title = { Column { Text(song.title, fontWeight = FontWeight.Black); Text(song.genre.ifBlank { "SONUS Stream" }, style = MaterialTheme.typography.labelSmall) } },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.heightIn(max = 480.dp)) {
                item { Text("Desempenho", fontWeight = FontWeight.ExtraBold) }
                item { Text("${song.validPlays} reproduções válidas • ${song.uniqueListeners} ouvintes únicos • ${song.returningPlays} retornos") }
                item { Text("Tempo ouvido %.1f h • média ${formatShortDuration(if (song.validPlays > 0) song.listeningMs / song.validPlays else 0L)}".format(song.listeningMs / 3600000.0)) }
                item { Text("Retenção média %.0f%% • conclusões ${song.completions} • pulos ${song.skips} • pulos precoces ${song.earlySkips}".format(song.retention * 100)) }
                item { Text("Curtidas ${song.likes} • seguidores gerados ${song.followersGenerated} • crescimento ${formatGrowth(song.growthPercent)}") }
                item { Text("Compartilhamentos ${song.shares} • vídeos gerados ${song.videoGenerations} • exportações ${song.videoExports} • vídeos compartilhados ${song.videoShares}") }
                if (song.organicPlays > 0 || song.boostedPlays > 0) item {
                    Surface(shape = RoundedCornerShape(12.dp), color = Color(0xFFFFD66B).copy(alpha = .10f)) {
                        Text("Orgânico ${song.organicPlays} • Impulsionamento ${song.boostedPlays}. Impulsionamento aumenta descoberta; não compra reproduções.", Modifier.padding(9.dp), style = MaterialTheme.typography.labelSmall)
                    }
                }
                if (song.sources.isNotEmpty()) {
                    item { Text("Origem", fontWeight = FontWeight.ExtraBold) }
                    items(song.sources.entries.sortedByDescending { it.value }) { e -> Row { Text(sourceLabel(e.key), Modifier.weight(1f)); Text("${e.value}") } }
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Fechar") } }
    )
}

private fun formatGrowth(value:Double):String=when{value>999->">+999%";value>0->"+%.0f%%".format(value);value<0->"%.0f%%".format(value);else->"0%"}
private fun formatShortDuration(ms:Long):String{val total=(ms/1000).coerceAtLeast(0);return if(total<60)"${total}s" else "${total/60}m ${total%60}s"}
@Composable private fun DailyTrendChart(values:Map<String,Long>){
    val entries=values.toSortedMap().entries.toList().takeLast(28);val max=(entries.maxOfOrNull{it.value}?:1L).coerceAtLeast(1L)
    Surface(shape=RoundedCornerShape(18.dp),color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.22f)){Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){Row(Modifier.fillMaxWidth().height(82.dp),horizontalArrangement=Arrangement.spacedBy(2.dp),verticalAlignment=Alignment.Bottom){entries.forEach{e->val ratio=e.value.toFloat()/max.toFloat();Box(Modifier.weight(1f).height((5+65*ratio).dp).background(MaterialTheme.colorScheme.primary.copy(alpha=.25f+.65f*ratio),RoundedCornerShape(topStart=3.dp,topEnd=3.dp)))}};if(entries.isNotEmpty()){val strongest=entries.maxByOrNull{it.value};Text("Pico do período: ${strongest?.key.orEmpty()} • ${strongest?.value?:0} reproduções",style=MaterialTheme.typography.labelSmall)}}}
}
@Composable private fun StudioMetric(modifier:Modifier,value:String,label:String){Surface(modifier=modifier,shape=RoundedCornerShape(13.dp),color=Color.White.copy(alpha=.05f)){Column(Modifier.padding(9.dp)){Text(value,fontWeight=FontWeight.Black,fontSize=15.sp);Text(label,fontSize=8.sp,color=Color.White.copy(alpha=.55f))}}}
@Composable private fun GoalBar(label:String,value:Double,target:Double,text:String){Column(verticalArrangement=Arrangement.spacedBy(4.dp)){Row{Text(label,Modifier.weight(1f),fontWeight=FontWeight.Bold,fontSize=11.sp);Text(text,fontSize=9.sp)};LinearProgressIndicator(progress={(value/target).coerceIn(0.0,1.0).toFloat()},modifier=Modifier.fillMaxWidth().height(6.dp))}}
private fun sourceLabel(v:String)=when(v){"RADIO"->"SONUS Rádio";"FOR_YOU"->"Pra Você Hoje";"SEARCH"->"Busca";"PLAYLIST"->"Playlist";"GENRE"->"Gênero";"BOOST"->"Impulsionamento";"ARTIST_PROFILE"->"Perfil do artista";"DIRECT"->"Link direto";else->"SONUS Stream"}

@Composable
private fun SonusStreamTermsDialog(uid:String,repo:SonusStreamPlatformRepository,requireAcceptance:Boolean,onClose:()->Unit){
    AlertDialog(onDismissRequest={if(!requireAcceptance)onClose()},title={Text("Regras do SONUS Stream",fontWeight=FontWeight.Black)},text={LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.heightIn(max=480.dp)){item{Text("Pontos principais",fontWeight=FontWeight.ExtraBold)};items(SonusStreamRulesText.highlights){Text("• $it",style=MaterialTheme.typography.bodySmall)};item{HorizontalDivider()};items(SonusStreamRulesText.details){Text("• $it",style=MaterialTheme.typography.labelSmall)}}},confirmButton={Button(onClick={repo.acceptTerms(uid);onClose()}){Text(if(requireAcceptance)"Li e aceito" else "Fechar")}},dismissButton={if(!requireAcceptance)TextButton(onClick=onClose){Text("Voltar")}})
}

@Composable
private fun SonusArtistNameChangeDialog(user:AuthUser,repo:SonusStreamPlatformRepository,artistId:String,currentName:String,onClose:()->Unit){
    var requested by remember{mutableStateOf("")};var busy by remember{mutableStateOf(false)};var sent by remember{mutableStateOf(false)};var error by remember{mutableStateOf<String?>(null)};val scope=rememberCoroutineScope()
    AlertDialog(onDismissRequest={if(!busy)onClose()},title={Text("Alterar nome do artista",fontWeight=FontWeight.Black)},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Text("Atual: $currentName",fontWeight=FontWeight.Bold);Text("A alteração é analisada pelo suporte. Quando aprovada, o perfil central do artista pode refletir o novo nome nas músicas vinculadas ao mesmo artista.",style=MaterialTheme.typography.bodySmall);if(!sent)OutlinedTextField(requested,{requested=it.take(120)},label={Text("Novo nome solicitado")},singleLine=true,modifier=Modifier.fillMaxWidth()) else Text("Solicitação enviada ao suporte.",color=MaterialTheme.colorScheme.primary,fontWeight=FontWeight.Bold);error?.let{Text(it,color=MaterialTheme.colorScheme.error)}}},confirmButton={if(sent) TextButton(onClick=onClose){Text("Fechar")} else Button(enabled=!busy&&requested.trim().length>=2,onClick={scope.launch{busy=true;val r=repo.requestArtistNameChange(user,artistId,currentName,requested);busy=false;if(r.isSuccess)sent=true else error=r.exceptionOrNull()?.message}}){Text(if(busy)"Enviando…" else "Enviar ao suporte")}},dismissButton={if(!sent)TextButton(enabled=!busy,onClick=onClose){Text("Cancelar")}})
}

@Composable
private fun SonusStreamUploadDialog(
    user: AuthUser,
    tier: MembershipTier,
    repo: SonusStreamPlatformRepository,
    fixedArtistName: String,
    onClose: () -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var title by remember { mutableStateOf("") }
    val artist = fixedArtistName
    val uploadPrefs=remember{context.getSharedPreferences("sonus_stream_upload_v2",Context.MODE_PRIVATE)}
    var genre by remember { mutableStateOf(uploadPrefs.getString("last_genre","Piseiro").orEmpty().takeIf{it in SONUS_STREAM_CANONICAL_GENRES}?:"Piseiro") }
    var genreExpanded by remember{mutableStateOf(false)}
    var progress by remember{mutableIntStateOf(0)}
    var progressLabel by remember{mutableStateOf("")}
    var success by remember{mutableStateOf(false)}
    var audio by remember { mutableStateOf<Uri?>(null) }
    var cover by remember { mutableStateOf<Uri?>(null) }
    var lyricsFile by remember { mutableStateOf<Uri?>(null) }
    var audioName by remember { mutableStateOf("") }
    var coverName by remember { mutableStateOf("") }
    var lyricsName by remember { mutableStateOf("") }
    var ai by remember { mutableStateOf(false) }
    var imitate by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    fun displayName(uri: Uri?): String = uri?.let { target ->
        runCatching {
            context.contentResolver.query(target, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0).orEmpty() else ""
            }.orEmpty()
        }.getOrDefault("")
    }.orEmpty()

    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        audio = uri
        audioName = displayName(uri)
        error = null
    }
    val coverPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        cover = uri
        coverName = displayName(uri)
        error = null
    }
    val lyricsPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        lyricsFile = uri
        lyricsName = displayName(uri)
        error = null
    }

    AlertDialog(
        onDismissRequest = { if (!busy) onClose() },
        title = {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = RoundedCornerShape(14.dp), color = Color(0xFF35D7C1).copy(alpha = .12f), border = BorderStroke(1.dp, Color(0xFF35D7C1).copy(alpha = .26f))) {
                    Icon(Icons.Default.MusicNote, null, tint = Color(0xFF63E2C2), modifier = Modifier.padding(9.dp).size(22.dp))
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("Enviar música", fontWeight = FontWeight.Black, fontSize = 22.sp)
                    Text("SONUS Stream • envio para análise", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .62f))
                }
            }
        },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.heightIn(max = 580.dp)) {
                item {
                    OutlinedTextField(
                        title, { title = it.take(120) }, label = { Text("Título da música") },
                        modifier = Modifier.fillMaxWidth(), singleLine = true,
                        shape = RoundedCornerShape(15.dp)
                    )
                }
                item {
                    Surface(shape = RoundedCornerShape(16.dp), color = Color(0xFF63E2C2).copy(alpha = .07f), border = BorderStroke(1.dp, Color(0xFF63E2C2).copy(alpha = .18f))) {
                        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Surface(shape = CircleShape, color = Color(0xFF63E2C2).copy(alpha = .13f)) {
                                Icon(Icons.Default.Person, null, tint = Color(0xFF63E2C2), modifier = Modifier.padding(8.dp).size(20.dp))
                            }
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(artist, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("Artista oficial da conta", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .58f))
                            }
                            Surface(shape = RoundedCornerShape(50), color = Color(0xFF63E2C2).copy(alpha = .12f)) {
                                Text("OFICIAL", modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), color = Color(0xFF63E2C2), fontSize = 8.sp, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }
                item {
                    Box {
                        Surface(
                            modifier = Modifier.fillMaxWidth().clickable { genreExpanded = true },
                            shape = RoundedCornerShape(15.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .24f),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .32f))
                        ) {
                            Row(Modifier.padding(horizontal = 14.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.GraphicEq, null, tint = Color(0xFF8FAEFF)); Spacer(Modifier.width(9.dp))
                                Column(Modifier.weight(1f)) { Text("Gênero", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .54f)); Text(genre, fontWeight = FontWeight.Bold) }
                                Icon(Icons.Default.KeyboardArrowDown, null)
                            }
                        }
                        DropdownMenu(expanded=genreExpanded,onDismissRequest={genreExpanded=false}) {
                            SONUS_STREAM_CANONICAL_GENRES.forEach { g ->
                                DropdownMenuItem(text={Text(g)},onClick={genre=g;genreExpanded=false;uploadPrefs.edit().putString("last_genre",g).apply()},leadingIcon={if(g==genre)Icon(Icons.Default.Check,null,tint=Color(0xFF63E2C2))})
                            }
                        }
                    }
                }
                item { StreamUploadPickCard(if (audio == null) "Selecionar áudio" else audioName.ifBlank { "Áudio selecionado" }, "MP3 ou WAV", Icons.Default.AudioFile, audio != null) { audioPicker.launch("audio/*") } }
                item { StreamUploadPickCard(if (cover == null) "Selecionar capa obrigatória" else coverName.ifBlank { "Capa selecionada" }, "Capa 1:1", Icons.Default.Image, cover != null) { coverPicker.launch("image/*") } }
                item { StreamUploadPickCard(if (lyricsFile == null) "Letra / LRC (opcional)" else lyricsName.ifBlank { "Arquivo de letra selecionado" }, ".LRC sincronizado • .TXT comum", Icons.Default.Lyrics, lyricsFile != null) { lyricsPicker.launch(SonusLyricsImporter.pickerMimeTypes()) } }
                if(busy)item{Column(verticalArrangement=Arrangement.spacedBy(6.dp)){Text(progressLabel.ifBlank{"Processando..."},fontWeight=FontWeight.Black,fontSize=14.sp);LinearProgressIndicator(progress=progress/100f,modifier=Modifier.fillMaxWidth());Text("$progress%",fontSize=10.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.65f))}}
                if(success)item{Surface(shape=RoundedCornerShape(16.dp),color=Color(0xFF071A12),border=BorderStroke(1.dp,Color(0xFF35E18B))){Column(Modifier.fillMaxWidth().padding(14.dp)){Text("Música enviada com sucesso.",color=Color(0xFF6FF0A8),fontWeight=FontWeight.Black,fontSize=17.sp);Text("Aguarde a análise.",color=Color.White,fontWeight=FontWeight.Bold)}}}
                item {
                    Surface(shape = RoundedCornerShape(15.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .20f)) {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AutoAwesome, null, tint = Color(0xFFB498FF)); Spacer(Modifier.width(8.dp))
                            Text("Esta música utiliza IA", modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                            Switch(checked = ai, onCheckedChange = { ai = it; if (!it) imitate = false })
                        }
                    }
                }
                if (ai) item {
                    Surface(shape = RoundedCornerShape(15.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .16f)) {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("A voz imita uma pessoa real", modifier = Modifier.weight(1f), fontSize = 11.sp)
                            Switch(checked = imitate, onCheckedChange = { imitate = it })
                        }
                    }
                }
                item { Text("Ao enviar, você confirma que possui os direitos necessários. A publicação só acontece após análise.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .56f)) }
                error?.let { message -> item { Surface(shape=RoundedCornerShape(16.dp),color=Color(0xFF241014),border=BorderStroke(1.dp,Color(0xFFFF536A))){Column(Modifier.fillMaxWidth().padding(14.dp)){Text("Não foi possível enviar.",color=Color(0xFFFF7388),fontWeight=FontWeight.Black,fontSize=17.sp);Text(message,color=Color.White.copy(alpha=.82f),fontSize=11.sp)}} } }
            }
        },
        confirmButton = {
            Button(
                enabled = !busy && (success || (audio != null && cover != null && title.isNotBlank() && artist.isNotBlank() && genre.isNotBlank())),
                onClick = {
                    if(success){onClose();return@Button}
                    busy = true; error = null
                    scope.launch {
                        progress=1;progressLabel="Processando..."
                        val result = repo.submit(user, tier, title, artist, genre, lyricsFile, ai, imitate, audio!!, cover!!){pct,label->progress=pct;progressLabel=label}
                        busy = false
                        if (result.isSuccess) { success=true;progress=100;progressLabel="Finalizando..." } else error = result.exceptionOrNull()?.message ?: "Não foi possível concluir o envio."
                    }
                }
            ) { Text(if(success) "Concluir" else if (busy) "Processando…" else if(error!=null) "Tentar novamente" else "Enviar para análise") }
        },
        dismissButton = { TextButton(enabled = !busy, onClick = onClose) { Text("Cancelar") } }
    )
}

@Composable
private fun StreamUploadPickCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        color = if (selected) Color(0xFF63E2C2).copy(alpha = .075f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .20f),
        border = BorderStroke(1.dp, if (selected) Color(0xFF63E2C2).copy(alpha = .38f) else MaterialTheme.colorScheme.outline.copy(alpha = .25f))
    ) {
        Row(Modifier.padding(horizontal = 13.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = RoundedCornerShape(11.dp), color = Color.White.copy(alpha = .045f)) {
                Icon(icon, null, tint = if (selected) Color(0xFF63E2C2) else MaterialTheme.colorScheme.onSurface.copy(alpha = .78f), modifier = Modifier.padding(8.dp).size(21.dp))
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .55f))
            }
            Icon(if (selected) Icons.Default.CheckCircle else Icons.Default.ChevronRight, null, tint = if (selected) Color(0xFF63E2C2) else MaterialTheme.colorScheme.onSurface.copy(alpha = .40f))
        }
    }
}

@Composable
private fun SonusSubmissionDetail(repo:SonusStreamPlatformRepository,s:StreamSubmission,user:AuthUser,moderationMode:Boolean,onBack:()->Unit){
    val context=androidx.compose.ui.platform.LocalContext.current
    val scope=rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    val musicPublicId = s.musicId.ifBlank { sonusMusicPublicId(s.id) }
    var showDeleteRejected by remember { mutableStateOf(false) }
    var showSupportDialog by remember { mutableStateOf(false) }
    var supportMessage by remember { mutableStateOf("") }
    var reason by remember{mutableStateOf("")}
    var level by remember{mutableStateOf(StreamViolationLevel.LIGHT)}
    var sanctionDays by remember{mutableIntStateOf(30)}
    var indefiniteSanction by remember{mutableStateOf(false)}
    var busy by remember{mutableStateOf(false)}
    var exportMessage by remember{mutableStateOf<String?>(null)}
    var preparedBundle by remember{mutableStateOf<File?>(null)}
    var showBoost by remember{mutableStateOf(false)}
    var targetProfile by remember(s.uid){mutableStateOf<StreamCreatorProfile?>(null)}
    var showReward by remember{mutableStateOf(false)}
    var rewardDays by remember{mutableIntStateOf(7)}
    var rewardCustom by remember{mutableStateOf("")}
    var rewardTier by remember{mutableStateOf(MembershipTier.OURO)}
    var detailClock by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(s.uid,moderationMode){if(moderationMode) targetProfile=runCatching{repo.profile(s.uid)}.getOrNull()}
    LaunchedEffect(s.id, moderationMode) {
        if (!moderationMode) while (true) { detailClock = System.currentTimeMillis(); delay(15_000L) }
    }
    val saveBundleLauncher=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")){uri->
        val file=preparedBundle
        if(uri!=null&&file!=null){
            scope.launch{
                runCatching{ context.contentResolver.openOutputStream(uri)?.use{out->file.inputStream().use{it.copyTo(out)}} ?: error("Não foi possível salvar o pacote") }
                    .onSuccess{exportMessage="Pacote salvo com sucesso."}
                    .onFailure{exportMessage="Falha ao salvar: ${it.message}"}
            }
        }
    }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp),contentPadding=PaddingValues(bottom=30.dp)){
        item{Row(verticalAlignment=Alignment.CenterVertically){IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,"Voltar")};Column{Text(s.title,fontWeight=FontWeight.Black,fontSize=22.sp);Text("${s.artistName} • ${s.genre}",style=MaterialTheme.typography.bodySmall)}}}
        item{Surface(shape=RoundedCornerShape(16.dp),color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.30f)){Column(Modifier.padding(13.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){
            Text("Status: ${if (!moderationMode) repo.localPublicationLabel(s, detailClock) else runCatching { StreamSubmissionStatus.valueOf(s.status).label }.getOrDefault(s.status)}",fontWeight=FontWeight.Bold)
            Text("IA: ${if(s.aiUsed)"Sim" else "Não"} • ID ${s.publicUserId}",style=MaterialTheme.typography.labelSmall)
            Row(verticalAlignment=Alignment.CenterVertically){
                Column(Modifier.weight(1f)){Text("Music ID SONUS",fontSize=9.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.55f));Text(musicPublicId,fontWeight=FontWeight.ExtraBold,fontSize=12.sp)}
                IconButton(onClick={clipboard.setText(AnnotatedString(musicPublicId))}){Icon(Icons.Default.ContentCopy,"Copiar Music ID",modifier=Modifier.size(18.dp))}
            }
            if(moderationMode) targetProfile?.let { p ->
                Text("Credibilidade: ${"%.1f".format(p.currentCredibility())}/10 • Violações qualificadas (30d): ${p.activeViolationCount30d}",style=MaterialTheme.typography.labelSmall,color=if(p.canSubmit()) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.error)
                if(!p.canSubmit()) Text("Conta marcada: novos envios suspensos${p.submissionSuspendedUntil?.let{until->" até ${java.time.Instant.ofEpochMilli(until).atZone(java.time.ZoneId.systemDefault()).toLocalDate()}"}?:" por tempo indeterminado"}.",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.error)
            }
            if(s.publishedFileId!=null) SonusRealtimePlayCount(s.publishedFileId)
            if(s.lyrics.isNotBlank())Text(s.lyrics.take(800),style=MaterialTheme.typography.bodySmall)
        }}}
        if(moderationMode && (s.submissionDestination == "TELEGRAM_SONUS_ARTISTAS" || s.telegramMessageId != null || s.pCloudAudioName.isNotBlank())) item {
            Surface(shape=RoundedCornerShape(14.dp),color=Color(0xFF103D49).copy(alpha=.40f),border=BorderStroke(1.dp,Color(0xFF63E2C2).copy(alpha=.20f))){
                Column(Modifier.fillMaxWidth().padding(11.dp),verticalArrangement=Arrangement.spacedBy(4.dp)){
                    Text("Entrega para análise",fontWeight=FontWeight.ExtraBold)
                    Text("🔴 SONUS ARTISTAS",style=MaterialTheme.typography.labelSmall)
                    Text("Destino: Telegram • 🔴 SONUS ARTISTAS",style=MaterialTheme.typography.labelSmall)
                    if(s.telegramMessageId!=null) Text("Mensagem: ${s.telegramMessageId}",style=MaterialTheme.typography.labelSmall)
                    Text("${s.processedBitrateKbps.coerceAtLeast(SONUS_STREAM_UPLOAD_BITRATE_KBPS)} kbps • capa incorporada: ${if(s.coverEmbedded) "sim" else "não"}",style=MaterialTheme.typography.labelSmall)
                }
            }
        }
        if(moderationMode && s.submissionDestination != "TELEGRAM_SONUS_ARTISTAS" && s.telegramMessageId == null && s.pCloudAudioName.isBlank()) item{
            OutlinedButton(onClick={scope.launch{busy=true;val r=repo.exportSubmissionBundle(s);r.onSuccess{file->preparedBundle=file;saveBundleLauncher.launch("${s.title.replace(Regex("[^A-Za-z0-9._-]"),"_").take(50)}_SONUS.zip")}.onFailure{exportMessage=it.message};busy=false}},modifier=Modifier.fillMaxWidth(),enabled=!busy){Icon(Icons.Default.Download,null);Spacer(Modifier.width(6.dp));Text("Baixar tudo")}
        }
        exportMessage?.let{item{Text(it,style=MaterialTheme.typography.labelSmall)}}
        if(!moderationMode&&s.status==StreamSubmissionStatus.PUBLISHED.name&&s.publishedFileId!=null){item{Button(onClick={showBoost=true},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.RocketLaunch,null);Spacer(Modifier.width(6.dp));Text("Impulsionar esta música")}}}
        if(!moderationMode && s.status==StreamSubmissionStatus.REJECTED.name){
            item{OutlinedButton(onClick={showDeleteRejected=true},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.outlinedButtonColors(contentColor=MaterialTheme.colorScheme.error)){Icon(Icons.Default.DeleteOutline,null);Spacer(Modifier.width(6.dp));Text("Remover registro")}}
        }
        if(!moderationMode && s.status in listOf(StreamSubmissionStatus.APPROVED.name,StreamSubmissionStatus.PUBLISHED.name)){
            item{OutlinedButton(onClick={showSupportDialog=true},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.SupportAgent,null);Spacer(Modifier.width(6.dp));Text("Suporte")}}
        }
        if(moderationMode&&s.status in listOf(StreamSubmissionStatus.RECEIVED.name,StreamSubmissionStatus.REVIEWING.name,StreamSubmissionStatus.CHANGES_REQUESTED.name)){
            item{Button(onClick={scope.launch{busy=true;repo.review(s,user,true);busy=false;onBack()}},modifier=Modifier.fillMaxWidth(),enabled=!busy){Icon(Icons.Default.CheckCircle,null);Spacer(Modifier.width(6.dp));Text("Aprovar")}}
            item{OutlinedButton(onClick={scope.launch{busy=true;val r=repo.requestChanges(s,user,reason.ifBlank{"Ajuste necessário antes da publicação."});busy=false;exportMessage=if(r.isSuccess)"Solicitação de ajuste enviada." else r.exceptionOrNull()?.message;if(r.isSuccess)onBack()}},modifier=Modifier.fillMaxWidth(),enabled=!busy){Icon(Icons.Default.EditNote,null);Spacer(Modifier.width(6.dp));Text("Solicitar alteração")}}
            item{
                Column(verticalArrangement=Arrangement.spacedBy(7.dp)){
                    Text("Recusar / registrar violação",fontWeight=FontWeight.Bold)
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){listOf(StreamViolationLevel.LIGHT,StreamViolationLevel.MEDIUM,StreamViolationLevel.SEVERE).forEach{v->FilterChip(selected=level==v,onClick={level=v},label={Text(v.label,fontSize=9.sp)})}}
                    OutlinedTextField(reason,{reason=it.take(1000)},label={Text("Motivo")},modifier=Modifier.fillMaxWidth())
                    Text("🟢 corrigível e sem consumo de cota • 🟡 -2 pontos • 🔴 -3 pontos e pode suspender envios",style=MaterialTheme.typography.labelSmall)
                    if(level != StreamViolationLevel.LIGHT) {
                        Text("Duração da sanção",fontWeight=FontWeight.Bold,fontSize=10.sp)
                        LazyRow(horizontalArrangement=Arrangement.spacedBy(5.dp)){items(listOf(7,15,30,90)){d->FilterChip(selected=!indefiniteSanction&&sanctionDays==d,onClick={indefiniteSanction=false;sanctionDays=d},label={Text("$d dias",fontSize=8.sp)})};item{FilterChip(selected=indefiniteSanction,onClick={indefiniteSanction=true},label={Text("Indeterminado",fontSize=8.sp)})}}
                    }
                    Button(onClick={scope.launch{busy=true;repo.review(s,user,false,level,reason,suspendDays=if(level==StreamViolationLevel.LIGHT)null else sanctionDays,indefinite=level!=StreamViolationLevel.LIGHT&&indefiniteSanction);busy=false;onBack()}},enabled=!busy&&reason.isNotBlank(),colors=ButtonDefaults.buttonColors(containerColor=MaterialTheme.colorScheme.error),modifier=Modifier.fillMaxWidth()){Text("Recusar e notificar")}
                }
            }
        }
        if(moderationMode && s.status in listOf(StreamSubmissionStatus.APPROVED.name,StreamSubmissionStatus.PUBLISHED.name)){
            item{Surface(shape=RoundedCornerShape(17.dp),color=MaterialTheme.colorScheme.primaryContainer.copy(alpha=.20f)){Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                Text("Publicação",fontWeight=FontWeight.ExtraBold)
                Text("Na code108 o selo Ao Vivo é controlado internamente pelo SONUS após a aprovação. Não há botão manual nem chamada de Function para esse estado.",style=MaterialTheme.typography.labelSmall)
                if(user.role==AccountRole.OWNER) OutlinedButton(onClick={showReward=true},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.CardGiftcard,null);Spacer(Modifier.width(6.dp));Text("Recompensar contribuição") }
            }}}
        }
    }
    if(showDeleteRejected){
        AlertDialog(
            onDismissRequest={showDeleteRejected=false},
            title={Text("Remover registro da lista?")},
            text={Text("${s.title} será ocultada somente neste aparelho e continuará separada na guia Rejeitadas caso reapareça após uma reinstalação.")},
            confirmButton={Button(onClick={scope.launch{busy=true;val r=repo.deleteRejectedSubmission(user,s);busy=false;showDeleteRejected=false;exportMessage=if(r.isSuccess)"Registro rejeitado removido da lista." else r.exceptionOrNull()?.message;if(r.isSuccess)onBack()}},colors=ButtonDefaults.buttonColors(containerColor=MaterialTheme.colorScheme.error),enabled=!busy){Text("Remover registro")}},
            dismissButton={TextButton(onClick={showDeleteRejected=false},enabled=!busy){Text("Cancelar")}}
        )
    }
    if(showSupportDialog){
        AlertDialog(
            onDismissRequest={if(!busy)showSupportDialog=false},
            title={Text("Suporte desta música",fontWeight=FontWeight.Black)},
            text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Text("O suporte receberá automaticamente título, artista, Music ID, submissionId, status e fileId quando houver.",style=MaterialTheme.typography.bodySmall);OutlinedTextField(supportMessage,{supportMessage=it.take(2000)},label={Text("Mensagem")},minLines=3,modifier=Modifier.fillMaxWidth());Text(musicPublicId,style=MaterialTheme.typography.labelSmall)}},
            confirmButton={Button(onClick={scope.launch{busy=true;val r=repo.contactSupportAboutSubmission(user,s,supportMessage);busy=false;exportMessage=if(r.isSuccess)"Mensagem enviada ao suporte." else r.exceptionOrNull()?.message;if(r.isSuccess){showSupportDialog=false;supportMessage=""}}},enabled=!busy&&supportMessage.isNotBlank()){Text("Enviar")}},
            dismissButton={TextButton(onClick={showSupportDialog=false},enabled=!busy){Text("Cancelar")}}
        )
    }
    if(showReward){
        AlertDialog(onDismissRequest={showReward=false},title={Text("Recompensar artista",fontWeight=FontWeight.Black)},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
            Text("A recompensa é opcional e fica separada dos dias pagos.",style=MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){FilterChip(selected=rewardTier==MembershipTier.OURO,onClick={rewardTier=MembershipTier.OURO},label={Text("Ouro")});FilterChip(selected=rewardTier==MembershipTier.DIAMANTE,onClick={rewardTier=MembershipTier.DIAMANTE},label={Text("Diamante")})}
            LazyRow(horizontalArrangement=Arrangement.spacedBy(5.dp)){items(listOf(3,7,15,30)){d->FilterChip(selected=rewardDays==d&&rewardCustom.isBlank(),onClick={rewardDays=d;rewardCustom=""},label={Text("+$d dias")})}}
            OutlinedTextField(rewardCustom,{value->rewardCustom=value.filter(Char::isDigit).take(3);value.filter(Char::isDigit).toIntOrNull()?.coerceIn(1,365)?.let{rewardDays=it}},label={Text("Personalizado • dias")},singleLine=true,modifier=Modifier.fillMaxWidth())
        }},confirmButton={Button(onClick={scope.launch{busy=true;val r=repo.rewardContributor(s,user,rewardTier,rewardDays);busy=false;exportMessage=if(r.isSuccess)"Recompensa enviada/registrada." else r.exceptionOrNull()?.message;showReward=false}}){Text("Confirmar")}},dismissButton={TextButton(onClick={showReward=false}){Text("Cancelar")}})
    }
    if(showBoost&&s.publishedFileId!=null){
        AlertDialog(onDismissRequest={showBoost=false},title={Text("Impulsionar música",fontWeight=FontWeight.Black)},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
            Text("A música ganha exposição dentro do próprio gênero. O impulsionamento nunca cria reproduções falsas.",style=MaterialTheme.typography.bodySmall)
            Text("Escolha o período. A solicitação fica vinculada à sua conta e só entra em rotação após confirmação do pagamento.",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
            listOf(Triple(1,"1 dia",0.49),Triple(7,"7 dias",2.99),Triple(15,"15 dias",4.99),Triple(30,"30 dias",7.99)).forEach{(days,label,price)->
                OutlinedButton(onClick={scope.launch{busy=true;val r=repo.createBoostRequest(user.uid,s.publishedFileId?:0L,s.genre,days,price);busy=false;exportMessage=if(r.isSuccess)"Impulsionamento solicitado • $label. Ativação após confirmação do pagamento." else r.exceptionOrNull()?.message;showBoost=false}},enabled=!busy,modifier=Modifier.fillMaxWidth()){Text("$label • R$ ${"%.2f".format(price).replace('.',',')}")}
            }
        }},confirmButton={},dismissButton={TextButton(onClick={showBoost=false}){Text("Fechar")}})
    }
}

@Composable
fun SonusRealtimePlayCount(fileId:Long,modifier:Modifier=Modifier){
    val context=androidx.compose.ui.platform.LocalContext.current;val repo=remember{SonusStreamPlatformRepository(context)};val count by remember(fileId){repo.playCountFlow(fileId)}.collectAsState(initial=0L)
    Row(modifier,verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.PlayCircle,null,modifier=Modifier.size(14.dp),tint=MaterialTheme.colorScheme.primary);Spacer(Modifier.width(4.dp));Text("$count reproduções",fontSize=9.sp,fontWeight=FontWeight.SemiBold)}
}

private suspend fun com.google.android.gms.tasks.Task<com.google.firebase.auth.GetTokenResult>.awaitStreamToken():com.google.firebase.auth.GetTokenResult=suspendCancellableCoroutine{c->addOnCompleteListener{if(!c.isActive)return@addOnCompleteListener;if(it.isSuccessful)c.resume(it.result)else c.resumeWithException(it.exception?:IllegalStateException("Falha ao renovar sessão"))}}
private suspend fun com.google.android.gms.tasks.Task<Void>.awaitVoid(){suspendCancellableCoroutine<Unit>{c->addOnCompleteListener{if(!c.isActive)return@addOnCompleteListener;if(it.isSuccessful)c.resume(Unit)else c.resumeWithException(it.exception?:IllegalStateException("Falha Firebase"))}}}
private suspend fun com.google.android.gms.tasks.Task<DataSnapshot>.awaitSnapshot():DataSnapshot=suspendCancellableCoroutine{c->addOnCompleteListener{if(!c.isActive)return@addOnCompleteListener;if(it.isSuccessful)c.resume(it.result)else c.resumeWithException(it.exception?:IllegalStateException("Falha Firebase"))}}
private suspend fun com.google.android.gms.tasks.Task<Uri>.awaitUri():Uri=suspendCancellableCoroutine{c->addOnCompleteListener{if(!c.isActive)return@addOnCompleteListener;if(it.isSuccessful)c.resume(it.result)else c.resumeWithException(it.exception?:IllegalStateException("Falha URL"))}}
private suspend fun com.google.android.gms.tasks.Task<com.google.firebase.storage.FileDownloadTask.TaskSnapshot>.awaitFile(){suspendCancellableCoroutine<Unit>{c->addOnCompleteListener{if(!c.isActive)return@addOnCompleteListener;if(it.isSuccessful)c.resume(Unit)else c.resumeWithException(it.exception?:IllegalStateException("Falha download"))}}}
private suspend fun runTransactionAwait(ref: DatabaseReference, transform: (MutableData) -> Transaction.Result): Boolean = suspendCancellableCoroutine { c ->
    ref.runTransaction(object : Transaction.Handler {
        override fun doTransaction(currentData: MutableData): Transaction.Result = transform(currentData)
        override fun onComplete(error: DatabaseError?, committed: Boolean, currentData: DataSnapshot?) {
            if (!c.isActive) return
            if (error != null) c.resumeWithException(error.toException()) else c.resume(committed)
        }
    })
}

