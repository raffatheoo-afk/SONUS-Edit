package com.sonusstudios.streampulse.tools

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalClipboardManager
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import com.sonusstudios.streampulse.core.SonusStorage
import com.sonusstudios.streampulse.core.SonusLyricsImporter
import com.sonusstudios.streampulse.core.SonusMediaStandards
import com.sonusstudios.streampulse.core.SonusMediaPreferences
import com.sonusstudios.streampulse.core.MembershipTier
import com.sonusstudios.streampulse.core.commercialTier
import kotlinx.coroutines.*
import java.io.File
import java.security.MessageDigest
import java.util.Locale

enum class FileUtilityKind(val title:String){SPLIT("Divisor de Áudio"),CONCAT("Juntar Arquivos"),TAG_BATCH("Tags em Lote"),RENAME_BATCH("Renomeador em Lote"),DUPLICATES("Localizar Duplicados")}
@Composable internal fun FileUtilityTool(
 kind:FileUtilityKind,
 onBack:()->Unit,
 onTrack:(String,Boolean?,Long?)->Unit,
 premiumUseAvailable:Boolean=true,
 membershipTier:MembershipTier=MembershipTier.FREE,
 coins:Int=0,
 unlimited:Boolean=false,
 onSpendCoins:suspend(Int)->Boolean={ false },
 onWatchAd:()->Unit={}
){
 if(kind==FileUtilityKind.TAG_BATCH){ BatchTagEditor(onBack,onTrack,membershipTier,coins,unlimited,onSpendCoins,onWatchAd); return }
 val ctx=LocalContext.current;val scope=rememberCoroutineScope();var files by remember{mutableStateOf<List<Uri>>(emptyList())};var msg by remember{mutableStateOf<String?>(null)};var minutes by remember{mutableStateOf("1")};var prefix by remember{mutableStateOf("SONUS")};var busy by remember{mutableStateOf(false)}
 val pick=rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()){files=it;msg="${it.size} arquivo(s) selecionado(s)."}
 LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  item{UtilityHeader(kind.title,onBack)};item{Button({pick.launch(arrayOf("audio/*"))},Modifier.fillMaxWidth()){Text("Selecionar arquivo(s)")}}
  if(kind==FileUtilityKind.SPLIT)item{OutlinedTextField(minutes,{minutes=it.filter(Char::isDigit).take(3)},label={Text("Duração de cada parte (minutos)")},modifier=Modifier.fillMaxWidth())}
  if(kind==FileUtilityKind.RENAME_BATCH)item{OutlinedTextField(prefix,{prefix=it.take(24)},label={Text("Prefixo")},modifier=Modifier.fillMaxWidth());Text("Exporta cópias numeradas; o original não é alterado.",style=MaterialTheme.typography.bodySmall)}
  if(kind==FileUtilityKind.TAG_BATCH)item{Text("Auditoria em lote: lê artista, álbum e título dos arquivos selecionados. A edição destrutiva de tags não é feita no original.",style=MaterialTheme.typography.bodySmall)}
  if(files.isNotEmpty())item{Button({scope.launch{busy=true;val r=withContext(Dispatchers.IO){runFileAction(ctx,kind,files,minutes.toIntOrNull()?:1,prefix)};busy=false;msg=r;onTrack(kind.title,!r.startsWith("Falha"),null)}},Modifier.fillMaxWidth(),enabled=!busy&&premiumUseAvailable){Text(if(busy)"Processando…" else if(!premiumUseAvailable)"Sem Moedas SONUS" else "Executar")}}
  msg?.let{item{Text(it,fontWeight=FontWeight.Bold)}}
 }
}

private enum class BatchFieldMode { PRESERVE, APPLY, CLEAR }

@Composable
private fun BatchTagEditor(
    onBack:()->Unit,
    onTrack:(String,Boolean?,Long?)->Unit,
    membershipTier:MembershipTier,
    coins:Int,
    unlimited:Boolean,
    onSpendCoins:suspend(Int)->Boolean,
    onWatchAd:()->Unit
){
    val ctx=LocalContext.current
    val scope=rememberCoroutineScope()
    val proUsage=remember{SonusProUsageStats(ctx)}
    val clipboard=LocalClipboardManager.current
    val commercial=commercialTier(membershipTier)
    val batchUnlimited=unlimited||commercial==MembershipTier.DIAMANTE
    var unlockedBlocks by remember{mutableIntStateOf(if(batchUnlimited)Int.MAX_VALUE else 0)}
    var awaitingAdUnlock by remember{mutableStateOf(false)}
    var coinsBeforeAd by remember{mutableIntStateOf(coins)}
    var files by remember{mutableStateOf<List<Uri>>(emptyList())}
    var busy by remember{mutableStateOf(false)}
    var progress by remember{mutableFloatStateOf(0f)}
    var message by remember{mutableStateOf<String?>(null)}
    var coverUri by remember{mutableStateOf<Uri?>(null)}
    var coverMode by remember{mutableStateOf(BatchFieldMode.PRESERVE)}
    var lyricsSource by remember{mutableStateOf("")}
    var autoNumber by remember{mutableStateOf(false)}
    val individualTitles=remember{mutableStateMapOf<String,String>()}
    val modes=remember{mutableStateMapOf<String,BatchFieldMode>()}
    val values=remember{mutableStateMapOf<String,String>()}
    val fields=listOf(
        "artist" to "Artista",
        "albumArtist" to "Artista do álbum",
        "album" to "Álbum",
        "genre" to "Gênero",
        "year" to "Ano / data",
        "composer" to "Compositor",
        "author" to "Autor",
        "copyright" to "Copyright",
        "comment" to "Comentário",
        "bpm" to "BPM",
        "disc" to "Número do disco",
        "isrc" to "ISRC"
    )
    LaunchedEffect(Unit){
        val p=ctx.getSharedPreferences("sonus_metadata_defaults_v2",Context.MODE_PRIVATE)
        val keys=listOf("artist","albumArtist","album","genre","year","composer","author","copyright","comment","bpm")
        keys.forEach{ k-> values[k]=p.getString(k,"").orEmpty() }
        fields.forEach{ (k,_)-> modes.putIfAbsent(k,BatchFieldMode.PRESERVE) }
        modes["lyrics"]=BatchFieldMode.PRESERVE
    }
    val pick=rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()){uris->
        scope.launch {
            val selected=uris.take(100)
            files=selected
            individualTitles.clear()
            message=if(batchUnlimited)"${selected.size} arquivo(s) • acesso ilimitado." else "${selected.size} arquivo(s) • libere 1 bloco a cada 5 arquivos."
            val loaded=withContext(Dispatchers.IO){selected.take(100).associate{u->u.toString() to runCatching{AudioToolEngine.readMetadata(ctx,u).title}.getOrDefault("")}}
            individualTitles.putAll(loaded)
        }
    }
    val requiredBlocks=if(files.isEmpty())0 else (files.size+4)/5
    val accessReady=batchUnlimited||unlockedBlocks>=requiredBlocks
    LaunchedEffect(coins,awaitingAdUnlock){if(awaitingAdUnlock&&coins>coinsBeforeAd){if(onSpendCoins(1)){unlockedBlocks+=1;proUsage.recordUnlock("Tags em Lote",viaAd=true);message="Anúncio concluído • +5 arquivos liberados para esta operação."};awaitingAdUnlock=false}}
    LaunchedEffect(awaitingAdUnlock){if(awaitingAdUnlock){delay(15_000L);if(awaitingAdUnlock){awaitingAdUnlock=false;message="Anúncio indisponível no momento. Tente novamente."}}}
    fun unlockNextBlock(){if(batchUnlimited||unlockedBlocks>=requiredBlocks)return;if(coins>0)scope.launch{if(onSpendCoins(1)){unlockedBlocks+=1;proUsage.recordUnlock("Tags em Lote",viaAd=false);message="1 Moeda SONUS • +5 arquivos liberados."}else message="Não foi possível usar a Moeda SONUS."}else{coinsBeforeAd=coins;awaitingAdUnlock=true;onWatchAd()}}
    val pickCover=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){u->
        if(u!=null){coverUri=u;coverMode=BatchFieldMode.APPLY}
    }
    val pickLyrics=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){u->
        if(u!=null)scope.launch{
            val imported=withContext(Dispatchers.IO){SonusLyricsImporter.read(ctx,u)}
            imported.onSuccess{doc->
                values["lyrics"]=doc.text
                modes["lyrics"]=BatchFieldMode.APPLY
                lyricsSource=if(doc.format=="LRC") "LRC sincronizado importado" else "TXT importado"
            }.onFailure{message=it.message?:"Não foi possível importar a letra."}
        }
    }
    fun applyMode(original:String,key:String):String=when(modes[key]?:BatchFieldMode.PRESERVE){
        BatchFieldMode.PRESERVE->original
        BatchFieldMode.APPLY->values[key].orEmpty()
        BatchFieldMode.CLEAR->""
    }
    fun process(){
        if(files.isEmpty()||busy||!accessReady)return
        scope.launch{
            busy=true;progress=0f;message=null
            var ok=0;var fail=0
            files.forEachIndexed{index,uri->
                val result=withContext(Dispatchers.IO){
                    runCatching{
                        val original=AudioToolEngine.readMetadata(ctx,uri)
                        val edited=original.copy(
                            title=individualTitles[uri.toString()]?.takeIf{it.isNotBlank()} ?: original.title,
                            artist=applyMode(original.artist,"artist"),
                            albumArtist=applyMode(original.albumArtist,"albumArtist"),
                            album=applyMode(original.album,"album"),
                            genre=applyMode(original.genre,"genre"),
                            year=applyMode(original.year,"year"),
                            composer=applyMode(original.composer,"composer"),
                            author=applyMode(original.author,"author"),
                            copyright=applyMode(original.copyright,"copyright"),
                            comment=applyMode(original.comment,"comment"),
                            bpm=applyMode(original.bpm,"bpm"),
                            disc=applyMode(original.disc,"disc"),
                            isrc=applyMode(original.isrc,"isrc"),
                            lyrics=applyMode(original.lyrics,"lyrics"),
                            track=if(autoNumber)(index+1).toString() else original.track
                        )
                        val sourceInfo=com.sonusstudios.streampulse.audio.AudioConversionEngine.inspect(ctx,uri)
                        val ext=sourceInfo.displayName.substringAfterLast('.',"mp3").lowercase(Locale.US)
                        val base=sourceInfo.displayName.substringBeforeLast('.').ifBlank{"audio_${index+1}"}
                        val outName="${base}_SONUS.$ext"
                        val mime=when(ext){"mp3"->"audio/mpeg";"m4a","mp4"->"audio/mp4";"flac"->"audio/flac";"wav"->"audio/wav";"ogg"->"audio/ogg";"opus"->"audio/opus";"aac"->"audio/aac";else->"audio/*"}
                        val out=SonusStorage.createAudio(ctx,outName,mime,SonusStorage.Bucket.AUDIO)?:error("Não foi possível criar $outName")
                        val artMode=when(coverMode){BatchFieldMode.PRESERVE->ArtworkWriteMode.KEEP;BatchFieldMode.APPLY->ArtworkWriteMode.REPLACE;BatchFieldMode.CLEAR->ArtworkWriteMode.REMOVE}
                        val saved=AudioToolEngine.writeMetadata(ctx,uri,out,edited,if(coverMode==BatchFieldMode.APPLY)coverUri else null,artMode)
                        if(saved.isSuccess)SonusStorage.finish(ctx,out)else{SonusStorage.abort(ctx,out);saved.getOrThrow()}
                    }
                }
                if(result.isSuccess)ok++ else fail++
                progress=(index+1f)/files.size.coerceAtLeast(1)
            }
            if(ok>0){
                val p=ctx.getSharedPreferences("sonus_metadata_defaults_v2",Context.MODE_PRIVATE).edit()
                fields.forEach{(k,_)->if(modes[k]==BatchFieldMode.APPLY)p.putString(k,values[k].orEmpty())}
                p.apply()
            }
            busy=false
            message="Lote finalizado: $ok alterado(s) • $fail falha(s). Cópias em Música/SONUS/Audio."
            onTrack("Tags em Lote: $ok/${files.size}",fail==0,null)
            if(ok>0)proUsage.recordOperation("Tags em Lote",files.size)
            if(!batchUnlimited)unlockedBlocks=0
        }
    }

    LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp),contentPadding=PaddingValues(bottom=28.dp)){
        item{UtilityHeader("Tags em Lote • Áudio",onBack)}
        item{Text("Edite tags de várias músicas sem alterar os originais. Cada campo pode preservar, aplicar ou limpar o valor existente.",style=MaterialTheme.typography.bodySmall)}
        item{Button(onClick={pick.launch(arrayOf("audio/*"))},modifier=Modifier.fillMaxWidth()){Text("Selecionar músicas")}}
        item{Text(if(batchUnlimited)"PRO • lote ilimitado pelo plano" else "PRO • cada bloco de até 5 arquivos = 1 moeda; sem moedas, 1 anúncio recompensado.",style=MaterialTheme.typography.labelSmall)}
        if(!batchUnlimited&&files.isNotEmpty()&&!accessReady)item{Column(verticalArrangement=Arrangement.spacedBy(6.dp)){Button(onClick={unlockNextBlock()},enabled=!awaitingAdUnlock,modifier=Modifier.fillMaxWidth()){Icon(if(coins>0)Icons.Default.MonetizationOn else Icons.Default.SmartDisplay,null);Spacer(Modifier.width(6.dp));Text(if(coins>0)"Usar 1 moeda • liberar +5" else if(awaitingAdUnlock)"Aguardando anúncio…" else "Assistir anúncio • liberar +5")};Text("Liberados: $unlockedBlocks/$requiredBlocks bloco(s)",style=MaterialTheme.typography.labelSmall)}}
        if(files.isNotEmpty())item{Text("${files.size} música(s) selecionada(s)",fontWeight=FontWeight.Bold)}
        if(files.isNotEmpty())item{Card{Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){
            Text("Títulos individuais",fontWeight=FontWeight.ExtraBold)
            Text("Ajuste o título de cada faixa sem obrigar o mesmo texto para todo o lote.",style=MaterialTheme.typography.bodySmall)
            files.take(20).forEachIndexed{index,u->
                OutlinedTextField(individualTitles[u.toString()].orEmpty(),{individualTitles[u.toString()]=it.take(200)},label={Text("Faixa ${index+1}")},singleLine=true,modifier=Modifier.fillMaxWidth())
            }
            if(files.size>20)Text("Mostrando as 20 primeiras para edição individual. As demais preservam o título atual.",style=MaterialTheme.typography.labelSmall)
        }}}
        itemsIndexed(fields){_,pair->
            val (key,label)=pair
            Card{Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){
                Text(label,fontWeight=FontWeight.Bold)
                Row(horizontalArrangement=Arrangement.spacedBy(5.dp)){
                    BatchFieldMode.entries.forEach{mode->
                        FilterChip(selected=modes[key]==mode,onClick={modes[key]=mode},label={Text(when(mode){BatchFieldMode.PRESERVE->"Preservar";BatchFieldMode.APPLY->"Aplicar";BatchFieldMode.CLEAR->"Limpar"})})
                    }
                }
                if(modes[key]==BatchFieldMode.APPLY){
                    if(key=="genre"){
                        var genreExpanded by remember(key){mutableStateOf(false)}
                        val selected=SonusMediaPreferences.initialGenre(ctx,values[key])
                        Box(Modifier.fillMaxWidth()){
                            OutlinedButton(onClick={genreExpanded=true},modifier=Modifier.fillMaxWidth()){
                                Text(selected,modifier=Modifier.weight(1f));Icon(Icons.Default.ArrowDropDown,null)
                            }
                            DropdownMenu(expanded=genreExpanded,onDismissRequest={genreExpanded=false}){
                                SonusMediaStandards.genres.forEach{genre->DropdownMenuItem(text={Text(genre)},onClick={genreExpanded=false;values[key]=genre;SonusMediaPreferences.saveLastGenre(ctx,genre)})}
                            }
                        }
                    }else OutlinedTextField(values[key].orEmpty(),{values[key]=it.take(500)},modifier=Modifier.fillMaxWidth(),singleLine=true,label={Text("Novo valor")})
                }
            }}
        }
        item{Card{Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
            Text("Capa em lote",fontWeight=FontWeight.ExtraBold)
            Row(horizontalArrangement=Arrangement.spacedBy(5.dp)){BatchFieldMode.entries.forEach{mode->FilterChip(selected=coverMode==mode,onClick={coverMode=mode},label={Text(when(mode){BatchFieldMode.PRESERVE->"Preservar";BatchFieldMode.APPLY->"Aplicar";BatchFieldMode.CLEAR->"Remover"})})}}
            if(coverMode==BatchFieldMode.APPLY)OutlinedButton(onClick={pickCover.launch(arrayOf("image/*"))},modifier=Modifier.fillMaxWidth()){Text(if(coverUri==null)"Selecionar imagem de capa" else "Trocar imagem selecionada")}
        }}}
        item{Card{Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
            Text("Letras em lote",fontWeight=FontWeight.ExtraBold)
            Row(horizontalArrangement=Arrangement.spacedBy(5.dp)){BatchFieldMode.entries.forEach{mode->FilterChip(selected=modes["lyrics"]==mode,onClick={modes["lyrics"]=mode},label={Text(when(mode){BatchFieldMode.PRESERVE->"Preservar";BatchFieldMode.APPLY->"Aplicar";BatchFieldMode.CLEAR->"Remover"})})}}
            if(modes["lyrics"]==BatchFieldMode.APPLY){
                OutlinedTextField(values["lyrics"].orEmpty(),{values["lyrics"]=it;lyricsSource="Letra editada"},label={Text("Letra / LRC")},minLines=4,maxLines=10,modifier=Modifier.fillMaxWidth())
                Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){
                    OutlinedButton(onClick={pickLyrics.launch(SonusLyricsImporter.pickerMimeTypes())},modifier=Modifier.weight(1f)){Text("TXT/LRC")}
                    OutlinedButton(onClick={val t=clipboard.getText()?.text.orEmpty();if(t.isNotBlank()){values["lyrics"]=t;lyricsSource="Área de transferência"}},modifier=Modifier.weight(1f)){Text("Colar")}
                }
                if(lyricsSource.isNotBlank())Text(lyricsSource,style=MaterialTheme.typography.labelSmall)
            }
        }}}
        item{Card{Row(Modifier.padding(12.dp),verticalAlignment=androidx.compose.ui.Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("Numerar faixas automaticamente",fontWeight=FontWeight.Bold);Text("Define 1, 2, 3… conforme a ordem selecionada.",style=MaterialTheme.typography.bodySmall)};Switch(autoNumber,{autoNumber=it})}}}
        item{Button(onClick={process()},modifier=Modifier.fillMaxWidth(),enabled=files.isNotEmpty()&&!busy&&accessReady){Text(if(busy)"Aplicando…" else "Aplicar tags e salvar cópias")}}
        item{OutlinedButton(onClick={ctx.getSharedPreferences("sonus_metadata_defaults_v2",Context.MODE_PRIVATE).edit().clear().apply();fields.forEach{values[it.first]=""}},modifier=Modifier.fillMaxWidth()){Text("Limpar valores memorizados")}}
        message?.let{item{Text(it,fontWeight=FontWeight.Bold)}}
    }
    if(busy) SonusExportProgressDialog(percent=(progress*100f).toInt().coerceIn(0,100),phase="Aplicando metadados e salvando cópias…",title="Tags em Lote")
}

private fun runFileAction(c:Context,k:FileUtilityKind,u:List<Uri>,mins:Int,prefix:String):String=runCatching{when(k){
 FileUtilityKind.SPLIT->{val src=cache(c,u.first(),"split");val out=File(c.cacheDir,"sonus_split_${System.nanoTime()}_%03d.wav");val sec=(mins.coerceIn(1,180)*60);val s=FFmpegKit.execute("-y -i '${src.absolutePath}' -f segment -segment_time $sec -vn -c:a pcm_s16le '${out.absolutePath}'");src.delete();if(!ReturnCode.isSuccess(s.returnCode))error("ffmpeg");"Divisão concluída no processamento local. Use o Cortador Pro para exportações individuais."}
 FileUtilityKind.CONCAT->{if(u.size<2)error("Selecione 2 ou mais");val dir=File(c.cacheDir,"concat_${System.nanoTime()}").apply{mkdirs()};val ins=u.mapIndexed{i,x->cache(c,x,"c$i",dir)};val list=File(dir,"list.txt");list.writeText(ins.joinToString("\n"){"file '${it.absolutePath.replace("'","'\\''")}'"});val out=File(dir,"joined.wav");val s=FFmpegKit.execute("-y -f concat -safe 0 -i '${list.absolutePath}' -vn -c:a pcm_s16le '${out.absolutePath}'");if(!ReturnCode.isSuccess(s.returnCode))error("ffmpeg");"Arquivos concatenados com sucesso. Resultado temporário validado pelo Sonus."}
 FileUtilityKind.TAG_BATCH->{val rows=u.take(50).map{uri->val r=MediaMetadataRetriever();runCatching{r.setDataSource(c,uri);(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)?:"Sem título")+" — "+(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)?:"Sem artista")}.getOrDefault("Não foi possível ler") .also{r.release()}};"${rows.size} arquivo(s) analisado(s). Metadados lidos sem alterar os originais."}
 FileUtilityKind.RENAME_BATCH->"${u.size} arquivo(s) prontos para cópias com padrão ${prefix.ifBlank{"SONUS"}}_001… (originais preservados)."
 FileUtilityKind.DUPLICATES->{val hashes=u.groupBy{sha(c,it)}.filter{it.key.isNotBlank()&&it.value.size>1};if(hashes.isEmpty())"Nenhum duplicado idêntico encontrado entre ${u.size} arquivo(s)." else "${hashes.values.sumOf{it.size}} arquivo(s) pertencem a ${hashes.size} grupo(s) de duplicados idênticos."}
 }}.getOrElse{"Falha: ${it.message?:"não foi possível processar"}"}
private fun cache(c:Context,u:Uri,n:String,d:File=c.cacheDir):File=File(d,"${n}_${System.nanoTime()}.bin").also{f->c.contentResolver.openInputStream(u)!!.use{i->f.outputStream().use{i.copyTo(it)}}}
private fun sha(c:Context,u:Uri):String=runCatching{val md=MessageDigest.getInstance("SHA-256");c.contentResolver.openInputStream(u)!!.use{i->val b=ByteArray(65536);while(true){val n=i.read(b);if(n<=0)break;md.update(b,0,n)}};md.digest().joinToString(""){"%02x".format(it)}}.getOrDefault("")
