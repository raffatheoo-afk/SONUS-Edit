package com.sonusstudios.streampulse.notifications

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.sonusstudios.streampulse.BuildConfig
import com.sonusstudios.streampulse.MainActivity
import com.sonusstudios.streampulse.R
import com.sonusstudios.streampulse.core.AppState
import com.sonusstudios.streampulse.data.AppRepository
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.YearMonth
import java.util.Locale
import java.util.UUID
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@Serializable
data class SonusNotificationItem(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val body: String,
    val category: String,
    val route: String? = null,
    val createdAtEpochMillis: Long = System.currentTimeMillis(),
    val read: Boolean = false
)

@Serializable
data class PremiumUsageEvent(
    val id: String = UUID.randomUUID().toString(),
    val toolName: String,
    val createdAtEpochMillis: Long = System.currentTimeMillis()
)

data class SonusNotificationPreferences(
    val externalEnabled: Boolean,
    val premiumUsage: Boolean,
    val tools: Boolean,
    val backupSafety: Boolean,
    val sonusUpdates: Boolean,
    val streamArtists: Boolean,
    val quietHours: Boolean,
    val quietStart: Int,
    val quietEnd: Int
)

object SonusNotificationCenter {
    private const val PREFS = "sonus_notification_center_v1"
    private const val ITEMS = "items_json"
    private const val USAGE_ITEMS = "premium_usage_json"
    private const val CHANNEL_IMPORTANT = "sonus_important"
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private var appContext: Context? = null
    private val _items = MutableStateFlow<List<SonusNotificationItem>>(emptyList())
    val items: StateFlow<List<SonusNotificationItem>> = _items.asStateFlow()
    private val _usageEvents = MutableStateFlow<List<PremiumUsageEvent>>(emptyList())
    val usageEvents: StateFlow<List<PremiumUsageEvent>> = _usageEvents.asStateFlow()

    fun initialize(context: Context) {
        val app = context.applicationContext
        appContext = app
        createChannel(app)
        reload(app)
        reloadUsage(app)
        notifyAppUpdatedIfNeeded(app)
    }

    fun preferences(context: Context): SonusNotificationPreferences {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return SonusNotificationPreferences(
            externalEnabled = p.getBoolean("external_enabled", false),
            premiumUsage = p.getBoolean("cat_premium", true),
            tools = p.getBoolean("cat_tools", true),
            backupSafety = p.getBoolean("cat_backup", true),
            sonusUpdates = p.getBoolean("cat_updates", true),
            streamArtists = p.getBoolean("cat_stream", true),
            quietHours = p.getBoolean("quiet_enabled", false),
            quietStart = p.getInt("quiet_start", 23).coerceIn(0,23),
            quietEnd = p.getInt("quiet_end", 8).coerceIn(0,23)
        )
    }

    fun setExternalEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("external_enabled", enabled).apply()
    }

    fun setCategory(context: Context, key: String, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(key, enabled).apply()
    }

    fun setQuietHours(context: Context, enabled:Boolean, start:Int, end:Int) { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("quiet_enabled",enabled).putInt("quiet_start",start.coerceIn(0,23)).putInt("quiet_end",end.coerceIn(0,23)).apply() }


    fun add(
        context: Context,
        title: String,
        body: String,
        category: String,
        route: String? = null,
        importantExternal: Boolean = false
    ) {
        if (!categoryEnabled(preferences(context), category)) return
        val item = SonusNotificationItem(title = title, body = body, category = category, route = route)
        val current = load(context)
        persist(context, (listOf(item) + current).take(150))
        if (importantExternal && shouldSendExternal(context, category)) postSystem(context, item)
    }

    fun recordPremiumUse(context: Context, toolName: String) {
        val clean = toolName.trim().take(80)
        if (clean.isBlank()) return
        val current = loadUsage(context)
        persistUsage(context, (listOf(PremiumUsageEvent(toolName = clean)) + current).take(100))
        val period = YearMonth.now().toString()
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val key = premiumUsageCountKey(period)
        prefs.edit().putInt(key, prefs.getInt(key, 0) + 1).apply()
    }

    fun premiumUsageCount(context: Context, period: String = YearMonth.now().toString()): Int {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getInt(premiumUsageCountKey(period), 0)
            .coerceAtLeast(0)
    }

    fun clearPremiumUsageHistory(context: Context) = persistUsage(context, emptyList())

    fun markRead(context: Context, id: String) = update(context) { list -> list.map { if (it.id == id) it.copy(read = true) else it } }
    fun markAllRead(context: Context) = update(context) { list -> list.map { it.copy(read = true) } }
    fun delete(context: Context, id: String) = update(context) { list -> list.filterNot { it.id == id } }
    fun clear(context: Context) = persist(context, emptyList())

    fun notifyUsageThreshold(context: Context, before: Int, after: Int, allowance: Int, planName: String) {
        if (allowance <= 0 || allowance == Int.MAX_VALUE || after >= before) return
        val pctBefore = before.toDouble() / allowance.toDouble()
        val pctAfter = after.toDouble() / allowance.toDouble()
        val cycle = YearMonth.now().toString()
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        fun firstTime(tag: String): Boolean {
            val key = "usage_notice_${cycle}_${planName.uppercase(Locale.ROOT)}_$tag"
            if (p.getBoolean(key, false)) return false
            p.edit().putBoolean(key, true).apply()
            return true
        }
        val crossed = listOf(.50 to "50%", .20 to "20%", .10 to "10%").firstOrNull { (v, _) -> pctBefore > v && pctAfter <= v }
        if (crossed != null && firstTime(crossed.second.removeSuffix("%"))) {
            add(context, "Moedas SONUS • ${crossed.second} restantes", "Seu plano $planName está com $after de $allowance moedas disponíveis.", "PREMIUM", "PREMIUM", false)
        }
        if (after == 0 && before > 0 && firstTime("ZERO")) {
            add(context, "Suas Moedas SONUS acabaram", "A franquia deste ciclo chegou a zero. Confira as opções do seu plano ou as formas de obter moedas extras.", "PREMIUM", "PREMIUM", true)
        }
    }


    private fun premiumUsageCountKey(period: String): String = "premium_usage_count_${period.replace("-", "_")}"

    private fun categoryEnabled(pref: SonusNotificationPreferences, category: String): Boolean = when (category) {
        "PREMIUM" -> pref.premiumUsage
        "FERRAMENTAS" -> pref.tools
        "BACKUP" -> pref.backupSafety
        "SONUS" -> pref.sonusUpdates
        "STREAM", "ARTIST" -> pref.streamArtists
        "SUPPORT", "SECURITY" -> true
        else -> true
    }

    private fun shouldSendExternal(context: Context, category: String): Boolean {
        val pref = preferences(context)
        val mandatory = category == "SUPPORT" || category == "SECURITY"
        if ((!pref.externalEnabled && !mandatory) || !categoryEnabled(pref, category)) return false
        if (pref.quietHours && !mandatory) {
            val h = LocalTime.now().hour
            val inside = if (pref.quietStart < pref.quietEnd) h in pref.quietStart until pref.quietEnd else h >= pref.quietStart || h < pref.quietEnd
            if (inside) return false
        }
        return Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    }

    private fun postSystem(context: Context, item: SonusNotificationItem) {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("sonus_notification_route", item.route)
        }
        val pending = PendingIntent.getActivity(context, item.id.hashCode(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(context, CHANNEL_IMPORTANT)
            .setSmallIcon(R.drawable.ic_sonus_notification)
            .setLargeIcon(BitmapFactory.decodeResource(context.resources, R.drawable.sonus_symbol_official))
            .setContentTitle(item.title)
            .setContentText(item.body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(item.body))
            .setAutoCancel(true)
            .setContentIntent(pending)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
        NotificationManagerCompat.from(context).notify(item.id.hashCode(), n)
    }

    private fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_IMPORTANT, "SONUS • avisos importantes", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "Avisos importantes do SONUS"
            }
            context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }


    private fun notifyAppUpdatedIfNeeded(context: Context) {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val lastVersion = p.getInt("last_seen_version_code", -1)
        val currentVersion = BuildConfig.VERSION_CODE
        if (lastVersion == -1) {
            // Primeira instalação: apenas registra a versão para não gerar aviso artificial.
            p.edit().putInt("last_seen_version_code", currentVersion).apply()
            return
        }
        if (lastVersion == currentVersion) return
        p.edit().putInt("last_seen_version_code", currentVersion).apply()
        add(
            context,
            "SONUS atualizado • v${BuildConfig.VERSION_NAME}",
            "A nova versão foi instalada. Confira as novidades em Sobre o SONUS.",
            "SONUS",
            route = null,
            importantExternal = false
        )
    }

    private fun reload(context: Context) { _items.value = load(context) }
    private fun reloadUsage(context: Context) { _usageEvents.value = loadUsage(context) }
    private fun loadUsage(context: Context): List<PremiumUsageEvent> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(USAGE_ITEMS, null) ?: return emptyList()
        return runCatching { json.decodeFromString<List<PremiumUsageEvent>>(raw) }.getOrDefault(emptyList())
    }
    private fun persistUsage(context: Context, list: List<PremiumUsageEvent>) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(USAGE_ITEMS, json.encodeToString(list)).apply()
        _usageEvents.value = list
    }
    private fun load(context: Context): List<SonusNotificationItem> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(ITEMS, null) ?: return emptyList()
        return runCatching { json.decodeFromString<List<SonusNotificationItem>>(raw) }.getOrDefault(emptyList())
    }
    private fun persist(context: Context, list: List<SonusNotificationItem>) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(ITEMS, json.encodeToString(list)).apply()
        _items.value = list
    }
    private fun update(context: Context, transform: (List<SonusNotificationItem>) -> List<SonusNotificationItem>) = persist(context, transform(load(context)))
}


