package com.sonusstudios.streampulse.notifications

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.sonusstudios.streampulse.BuildConfig
import com.sonusstudios.streampulse.MainActivity
import com.sonusstudios.streampulse.R
import com.sonusstudios.streampulse.core.AppState
import com.sonusstudios.streampulse.core.DistributorRules
import com.sonusstudios.streampulse.core.RoyaltyEngine
import com.sonusstudios.streampulse.data.AppRepository
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.YearMonth
import java.util.Locale
import java.util.UUID
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@Serializable
data class SonusNotificationItem(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val body: String,
    val category: String,
    val route: String? = null,
    val createdAtEpochMillis: Long = System.currentTimeMillis(),
    val read: Boolean = false
)

@Serializable
data class PremiumUsageEvent(
    val id: String = UUID.randomUUID().toString(),
    val toolName: String,
    val createdAtEpochMillis: Long = System.currentTimeMillis()
)

data class SonusNotificationPreferences(
    val externalEnabled: Boolean,
    val financial: Boolean,
    val forecasts: Boolean,
    val premiumUsage: Boolean,
    val tools: Boolean,
    val backupSafety: Boolean,
    val sonusUpdates: Boolean,
    val streamArtists: Boolean,
    val quietHours: Boolean,
    val quietStart: Int,
    val quietEnd: Int,
    val forecastHour: Int
)

object SonusNotificationCenter {
    private const val PREFS = "sonus_notification_center_v1"
    private const val ITEMS = "items_json"
    private const val USAGE_ITEMS = "premium_usage_json"
    private const val CHANNEL_IMPORTANT = "sonus_important"
    private const val WORK_NAME = "sonus_daily_finance_forecast"
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private var appContext: Context? = null
    private val _items = MutableStateFlow<List<SonusNotificationItem>>(emptyList())
    val items: StateFlow<List<SonusNotificationItem>> = _items.asStateFlow()
    private val _usageEvents = MutableStateFlow<List<PremiumUsageEvent>>(emptyList())
    val usageEvents: StateFlow<List<PremiumUsageEvent>> = _usageEvents.asStateFlow()

    fun initialize(context: Context) {
        val app = context.applicationContext
        appContext = app
        createChannel(app)
        reload(app)
        reloadUsage(app)
        notifyAppUpdatedIfNeeded(app)
        scheduleDailyForecast(app)
    }

    fun preferences(context: Context): SonusNotificationPreferences {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return SonusNotificationPreferences(
            externalEnabled = p.getBoolean("external_enabled", false),
            financial = p.getBoolean("cat_financial", true),
            forecasts = p.getBoolean("cat_forecasts", true),
            premiumUsage = p.getBoolean("cat_premium", true),
            tools = p.getBoolean("cat_tools", true),
            backupSafety = p.getBoolean("cat_backup", true),
            sonusUpdates = p.getBoolean("cat_updates", true),
            streamArtists = p.getBoolean("cat_stream", true),
            quietHours = p.getBoolean("quiet_enabled", false),
            quietStart = p.getInt("quiet_start", 23).coerceIn(0,23),
            quietEnd = p.getInt("quiet_end", 8).coerceIn(0,23),
            forecastHour = p.getInt("forecast_hour", 23).coerceIn(0, 23)
        )
    }

    fun setExternalEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("external_enabled", enabled).apply()
    }

    fun setCategory(context: Context, key: String, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(key, enabled).apply()
    }

    fun setQuietHours(context: Context, enabled:Boolean, start:Int, end:Int) { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("quiet_enabled",enabled).putInt("quiet_start",start.coerceIn(0,23)).putInt("quiet_end",end.coerceIn(0,23)).apply() }

    fun setForecastHour(context: Context, hour: Int) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt("forecast_hour", hour.coerceIn(0, 23)).apply()
        scheduleDailyForecast(context.applicationContext, replace = true)
    }

    fun add(
        context: Context,
        title: String,
        body: String,
        category: String,
        route: String? = null,
        importantExternal: Boolean = false
    ) {
        if (!categoryEnabled(preferences(context), category)) return
        val item = SonusNotificationItem(title = title, body = body, category = category, route = route)
        val current = load(context)
        persist(context, (listOf(item) + current).take(150))
        if (importantExternal && shouldSendExternal(context, category)) postSystem(context, item)
    }

    fun recordPremiumUse(context: Context, toolName: String) {
        val clean = toolName.trim().take(80)
        if (clean.isBlank()) return
        val current = loadUsage(context)
        persistUsage(context, (listOf(PremiumUsageEvent(toolName = clean)) + current).take(100))
        val period = YearMonth.now().toString()
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val key = premiumUsageCountKey(period)
        prefs.edit().putInt(key, prefs.getInt(key, 0) + 1).apply()
    }

    fun premiumUsageCount(context: Context, period: String = YearMonth.now().toString()): Int {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getInt(premiumUsageCountKey(period), 0)
            .coerceAtLeast(0)
    }

    fun clearPremiumUsageHistory(context: Context) = persistUsage(context, emptyList())

    fun markRead(context: Context, id: String) = update(context) { list -> list.map { if (it.id == id) it.copy(read = true) else it } }
    fun markAllRead(context: Context) = update(context) { list -> list.map { it.copy(read = true) } }
    fun delete(context: Context, id: String) = update(context) { list -> list.filterNot { it.id == id } }
    fun clear(context: Context) = persist(context, emptyList())

    fun notifyUsageThreshold(context: Context, before: Int, after: Int, allowance: Int, planName: String) {
        if (allowance <= 0 || allowance == Int.MAX_VALUE || after >= before) return
        val pctBefore = before.toDouble() / allowance.toDouble()
        val pctAfter = after.toDouble() / allowance.toDouble()
        val cycle = YearMonth.now().toString()
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        fun firstTime(tag: String): Boolean {
            val key = "usage_notice_${cycle}_${planName.uppercase(Locale.ROOT)}_$tag"
            if (p.getBoolean(key, false)) return false
            p.edit().putBoolean(key, true).apply()
            return true
        }
        val crossed = listOf(.50 to "50%", .20 to "20%", .10 to "10%").firstOrNull { (v, _) -> pctBefore > v && pctAfter <= v }
        if (crossed != null && firstTime(crossed.second.removeSuffix("%"))) {
            add(context, "Moedas SONUS • ${crossed.second} restantes", "Seu plano $planName está com $after de $allowance moedas disponíveis.", "PREMIUM", "PREMIUM", false)
        }
        if (after == 0 && before > 0 && firstTime("ZERO")) {
            add(context, "Suas Moedas SONUS acabaram", "A franquia deste ciclo chegou a zero. Confira as opções do seu plano ou as formas de obter moedas extras.", "PREMIUM", "PREMIUM", true)
        }
    }

    fun evaluateFinancialMilestones(context: Context, state: AppState) {
        if (!preferences(context).financial) return
        val groups = financialRollups(state)
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        groups.forEach { rollup ->
            val milestone = (rollup.currentBrl / 50.0).toInt() * 50
            if (milestone < 50) return@forEach
            val key = "milestone_${rollup.name}_${rollup.cycleKey}"
            val previous = p.getInt(key, 0)
            if (milestone > previous) {
                p.edit().putInt(key, milestone).apply()
                val projection = rollup.projectedBrl.coerceAtLeast(rollup.currentBrl)
                add(
                    context,
                    "PARABÉNS! 🎉🥳 • ${rollup.name}",
                    "Seus ganhos estimados ultrapassaram ${money(milestone.toDouble())}. Mantendo o ritmo atual, a projeção do ciclo está próxima de ${money(projection)}.",
                    "FINANCEIRO",
                    "DISTRIBUTION",
                    true
                )
            }
        }
    }

    fun evaluateForecastMovement(context: Context, state: AppState) {
        if (!preferences(context).forecasts) return
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val today = LocalDate.now().toString()
        val noticeKey = "forecast_move_notice_day"
        val alreadyNotifiedToday = p.getString(noticeKey, null) == today
        var candidate: Triple<FinanceRollup, Double, Double>? = null

        financialRollups(state).forEach { rollup ->
            val safeKey = (rollup.name + "_" + rollup.cycleKey).replace(Regex("[^A-Za-z0-9_-]"), "_")
            val valueKey = "forecast_value_cents_$safeKey"
            val currentCents = (rollup.projectedBrl.coerceAtLeast(0.0) * 100.0).toLong()
            val previousCents = p.getLong(valueKey, -1L)
            p.edit().putLong(valueKey, currentCents).apply()
            if (alreadyNotifiedToday || previousCents <= 0L || currentCents <= 0L) return@forEach
            if (rollup.confidence.equals("Baixa", ignoreCase = true)) return@forEach

            val previous = previousCents / 100.0
            val current = currentCents / 100.0
            val difference = kotlin.math.abs(current - previous)
            val relative = if (previous > 0.0) difference / previous else 0.0
            // Mudanças fortes entram só na Central interna. A previsão externa continua
            // limitada ao resumo diário, evitando várias notificações no celular.
            if (difference < 50.0 || relative < 0.20) return@forEach

            val currentCandidate = candidate
            if (currentCandidate == null || difference > kotlin.math.abs(currentCandidate.third - currentCandidate.second)) {
                candidate = Triple(rollup, previous, current)
            }
        }

        candidate?.let { (rollup, previous, current) ->
            p.edit().putString(noticeKey, today).apply()
            val direction = if (current > previous) "subiu" else "caiu"
            add(
                context,
                "Previsão mudou • ${rollup.name}",
                "Sua projeção $direction de ${money(previous)} para cerca de ${money(current)}. É uma estimativa baseada no ritmo atual • confiança ${rollup.confidence}.",
                "PREVISAO",
                "DISTRIBUTION",
                false
            )
        }
    }

    fun addDailyForecast(context: Context, state: AppState) {
        if (!preferences(context).forecasts) return
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val today = LocalDate.now().toString()
        if (p.getString("last_forecast_day", null) == today) return
        val rollups = financialRollups(state).filter { it.projectedBrl > 0.0 }
        if (rollups.isEmpty()) return

        val projectedTotal = rollups.sumOf { it.projectedBrl }
        val confidence = when {
            rollups.any { it.confidence.equals("Baixa", true) } -> "Baixa"
            rollups.any { it.confidence.equals("Média", true) } -> "Média"
            else -> "Alta"
        }
        val leader = rollups.maxByOrNull { it.projectedBrl }
        val body = if (rollups.size == 1 && leader != null) {
            "Mantendo o ritmo atual, ${leader.name} pode fechar o ciclo perto de ${money(projectedTotal)}. Esta é uma projeção • confiança $confidence."
        } else {
            val leaderText = leader?.let { " ${it.name} lidera com cerca de ${money(it.projectedBrl)}." }.orEmpty()
            "Somando suas distribuidoras, a projeção atual está perto de ${money(projectedTotal)}.$leaderText Estimativa baseada no ritmo atual • confiança $confidence."
        }

        p.edit().putString("last_forecast_day", today).apply()
        add(
            context,
            "Previsão financeira do dia",
            body,
            "PREVISAO",
            "DISTRIBUTION",
            true
        )
    }

    private data class FinanceRollup(val name: String, val cycleKey: String, val currentBrl: Double, val projectedBrl: Double, val confidence: String)

    private fun financialRollups(state: AppState): List<FinanceRollup> {
        val rows = state.artists.mapNotNull { artist ->
            runCatching {
                val today = LocalDate.now()
                val cycle = DistributorRules.cycleFor(artist, today)
                val start = LocalDate.parse(cycle.startIso)
                val end = LocalDate.parse(cycle.endIso)
                val snapshots = state.snapshots.filter { it.artistId == artist.id && dateInside(it.dateIso, start, end) }
                val daily = state.dailyStreamRecords.filter { it.artistId == artist.id && dateInside(it.dateIso, start, end) }
                val payments = state.payments.filter { it.artistId == artist.id }
                val rpm = RoyaltyEngine.personalizedRpm(artist, payments)
                val forecast = RoyaltyEngine.forecast(snapshots, daily, start, end, today, rpm)
                val name = DistributorRules.displayName(artist.distributor, artist.customDistributorName)
                Triple(name to "${cycle.startIso}_${cycle.endIso}", forecast, artist.id)
            }.getOrNull()
        }
        return rows.groupBy { it.first }.map { (identity, list) ->
            val name = identity.first
            val cycleKey = identity.second
            val forecasts = list.map { it.second }
            val confidence = when {
                forecasts.any { it.confidence.equals("Baixa", true) } -> "Baixa"
                forecasts.any { it.confidence.equals("Média", true) } -> "Média"
                else -> "Alta"
            }
            FinanceRollup(name, cycleKey, forecasts.sumOf { it.estimatedCurrentBrl }, forecasts.sumOf { it.projectedBrl }, confidence)
        }
    }

    private fun dateInside(iso: String, start: LocalDate, end: LocalDate): Boolean = runCatching {
        val d = LocalDate.parse(iso); !d.isBefore(start) && !d.isAfter(end)
    }.getOrDefault(false)

    private fun money(v: Double): String = "R$ " + String.format(Locale("pt", "BR"), "%,.2f", v)

    private fun premiumUsageCountKey(period: String): String = "premium_usage_count_${period.replace("-", "_")}"

    private fun categoryEnabled(pref: SonusNotificationPreferences, category: String): Boolean = when (category) {
        "FINANCEIRO" -> pref.financial
        "PREVISAO" -> pref.forecasts
        "PREMIUM" -> pref.premiumUsage
        "FERRAMENTAS" -> pref.tools
        "BACKUP" -> pref.backupSafety
        "SONUS" -> pref.sonusUpdates
        "STREAM", "ARTIST" -> pref.streamArtists
        "SUPPORT", "SECURITY" -> true
        else -> true
    }

    private fun shouldSendExternal(context: Context, category: String): Boolean {
        val pref = preferences(context)
        val mandatory = category == "SUPPORT" || category == "SECURITY"
        if ((!pref.externalEnabled && !mandatory) || !categoryEnabled(pref, category)) return false
        if (pref.quietHours && !mandatory) {
            val h = LocalTime.now().hour
            val inside = if (pref.quietStart < pref.quietEnd) h in pref.quietStart until pref.quietEnd else h >= pref.quietStart || h < pref.quietEnd
            if (inside) return false
        }
        return Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    }

    private fun postSystem(context: Context, item: SonusNotificationItem) {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("sonus_notification_route", item.route)
        }
        val pending = PendingIntent.getActivity(context, item.id.hashCode(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(context, CHANNEL_IMPORTANT)
            .setSmallIcon(R.drawable.ic_sonus_notification)
            .setLargeIcon(BitmapFactory.decodeResource(context.resources, R.drawable.sonus_symbol_official))
            .setContentTitle(item.title)
            .setContentText(item.body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(item.body))
            .setAutoCancel(true)
            .setContentIntent(pending)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
        NotificationManagerCompat.from(context).notify(item.id.hashCode(), n)
    }

    private fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_IMPORTANT, "SONUS • avisos importantes", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "Marcos financeiros, previsões e avisos importantes do SONUS"
            }
            context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun scheduleDailyForecast(context: Context, replace: Boolean = false) {
        val now = LocalDateTime.now()
        val hour = preferences(context).forecastHour
        var next = LocalDateTime.of(now.toLocalDate(), LocalTime.of(hour, 0))
        if (!next.isAfter(now)) next = next.plusDays(1)
        val delayMinutes = Duration.between(now, next).toMinutes().coerceAtLeast(1)
        val request = PeriodicWorkRequestBuilder<SonusDailyForecastWorker>(24, TimeUnit.HOURS)
            .setInitialDelay(delayMinutes, TimeUnit.MINUTES)
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            WORK_NAME,
            if (replace) ExistingPeriodicWorkPolicy.REPLACE else ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }


    private fun notifyAppUpdatedIfNeeded(context: Context) {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val lastVersion = p.getInt("last_seen_version_code", -1)
        val currentVersion = BuildConfig.VERSION_CODE
        if (lastVersion == -1) {
            // Primeira instalação: apenas registra a versão para não gerar aviso artificial.
            p.edit().putInt("last_seen_version_code", currentVersion).apply()
            return
        }
        if (lastVersion == currentVersion) return
        p.edit().putInt("last_seen_version_code", currentVersion).apply()
        add(
            context,
            "SONUS atualizado • v${BuildConfig.VERSION_NAME}",
            "A nova versão foi instalada. Confira as novidades em Sobre o SONUS.",
            "SONUS",
            route = null,
            importantExternal = false
        )
    }

    private fun reload(context: Context) { _items.value = load(context) }
    private fun reloadUsage(context: Context) { _usageEvents.value = loadUsage(context) }
    private fun loadUsage(context: Context): List<PremiumUsageEvent> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(USAGE_ITEMS, null) ?: return emptyList()
        return runCatching { json.decodeFromString<List<PremiumUsageEvent>>(raw) }.getOrDefault(emptyList())
    }
    private fun persistUsage(context: Context, list: List<PremiumUsageEvent>) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(USAGE_ITEMS, json.encodeToString(list)).apply()
        _usageEvents.value = list
    }
    private fun load(context: Context): List<SonusNotificationItem> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(ITEMS, null) ?: return emptyList()
        return runCatching { json.decodeFromString<List<SonusNotificationItem>>(raw) }.getOrDefault(emptyList())
    }
    private fun persist(context: Context, list: List<SonusNotificationItem>) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(ITEMS, json.encodeToString(list)).apply()
        _items.value = list
    }
    private fun update(context: Context, transform: (List<SonusNotificationItem>) -> List<SonusNotificationItem>) = persist(context, transform(load(context)))
}

class SonusDailyForecastWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result = runCatching {
        SonusNotificationCenter.initialize(applicationContext)
        val state = AppRepository(applicationContext).state.first()
        SonusNotificationCenter.addDailyForecast(applicationContext, state)
        Result.success()
    }.getOrElse { Result.retry() }
}
