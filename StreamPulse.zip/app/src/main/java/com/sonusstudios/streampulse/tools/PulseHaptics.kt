package com.sonusstudios.streampulse.tools

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import com.sonusstudios.streampulse.core.UserPreferences

internal enum class PulseHapticEvent { TAP, SUCCESS, WARNING, TUNED }

internal object PulseHaptics {
    fun perform(context: Context, prefs: UserPreferences, event: PulseHapticEvent, forPlayer: Boolean = false, forTuner: Boolean = false) {
        if (!prefs.hapticsEnabled) return
        if (forPlayer && !prefs.hapticsPlayer) return
        if (!forPlayer && !forTuner && !prefs.hapticsTools) return
        if (forTuner && !prefs.hapticsTuner) return

        val vibrator = if (Build.VERSION.SDK_INT >= 31) {
            context.getSystemService(VibratorManager::class.java)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        } ?: return
        if (!vibrator.hasVibrator()) return

        val scale = when (prefs.hapticsIntensity.coerceIn(0, 2)) { 0 -> .55f; 2 -> 1f; else -> .78f }
        val amp = { base: Int -> (base * scale).toInt().coerceIn(1, 255) }
        runCatching {
            if (Build.VERSION.SDK_INT >= 26) {
                when (event) {
                    PulseHapticEvent.TAP -> vibrator.vibrate(VibrationEffect.createOneShot(18, amp(90)))
                    PulseHapticEvent.SUCCESS -> vibrator.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 18, 42, 14), intArrayOf(0, amp(100), 0, amp(70)), -1))
                    PulseHapticEvent.WARNING -> vibrator.vibrate(VibrationEffect.createOneShot(42, amp(175)))
                    PulseHapticEvent.TUNED -> vibrator.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 20, 34, 16), intArrayOf(0, amp(120), 0, amp(88)), -1))
                }
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(if (event == PulseHapticEvent.WARNING) 42L else 20L)
            }
        }
    }
}
