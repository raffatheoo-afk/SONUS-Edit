package com.sonusstudios.streampulse.tools

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import com.sonusstudios.streampulse.core.UserPreferences

internal enum class PulseHapticEvent { TAP, SUCCESS, WARNING, TUNED }

internal object PulseHaptics {
    fun perform(context: Context, prefs: UserPreferences, event: PulseHapticEvent, forPlayer: Boolean = false, forTuner: Boolean = false) {
        if (!prefs.hapticsEnabled) return
        if (forPlayer && !prefs.hapticsPlayer) return
        if (!forPlayer && !forTuner && !prefs.hapticsTools) return
        if (forTuner && !prefs.hapticsTuner) return
        val vibrator = vibratorOf(context) ?: return
        if (!vibrator.hasVibrator()) return
        runCatching { vibrator.vibrate(effectFor(vibrator, event, prefs.hapticsIntensity.coerceIn(0, 2))) }
    }

    /** Botão "Testar vibração" das configurações. Retorna false se o aparelho não informa vibração. */
    fun preview(context: Context, prefs: UserPreferences): Boolean {
        val vibrator = vibratorOf(context) ?: return false
        if (!vibrator.hasVibrator()) return false
        return runCatching { vibrator.vibrate(effectFor(vibrator, PulseHapticEvent.SUCCESS, prefs.hapticsIntensity.coerceIn(0, 2))) }.isSuccess
    }

    private fun vibratorOf(context: Context): Vibrator? =
        if (Build.VERSION.SDK_INT >= 31) {
            context.getSystemService(VibratorManager::class.java)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }

    /**
     * code133: antes o toque era um pulso de 18 ms com amplitude ~70/255, curto e fraco demais para o motor da
     * maioria dos aparelhos (praticamente imperceptível). Agora usa os efeitos nativos do próprio aparelho
     * (TICK / CLICK / DOUBLE_CLICK / HEAVY_CLICK), que já vêm calibrados pelo fabricante, e, quando não houver
     * suporte, pulsos longos o bastante para serem sentidos.
     */
    private fun effectFor(vibrator: Vibrator, event: PulseHapticEvent, intensity: Int): VibrationEffect {
        if (Build.VERSION.SDK_INT >= 29) {
            val id = when (event) {
                PulseHapticEvent.TAP -> intArrayOf(VibrationEffect.EFFECT_TICK, VibrationEffect.EFFECT_CLICK, VibrationEffect.EFFECT_HEAVY_CLICK)[intensity]
                PulseHapticEvent.SUCCESS, PulseHapticEvent.TUNED -> intArrayOf(VibrationEffect.EFFECT_CLICK, VibrationEffect.EFFECT_DOUBLE_CLICK, VibrationEffect.EFFECT_DOUBLE_CLICK)[intensity]
                PulseHapticEvent.WARNING -> intArrayOf(VibrationEffect.EFFECT_CLICK, VibrationEffect.EFFECT_HEAVY_CLICK, VibrationEffect.EFFECT_HEAVY_CLICK)[intensity]
            }
            val supported = Build.VERSION.SDK_INT < 30 ||
                vibrator.areAllEffectsSupported(id) == Vibrator.VIBRATION_EFFECT_SUPPORT_YES
            if (supported) return VibrationEffect.createPredefined(id)
        }
        val scale = when (intensity) { 0 -> .6f; 2 -> 1f; else -> .8f }
        val amp = { base: Int -> (base * scale).toInt().coerceIn(1, 255) }
        return when (event) {
            PulseHapticEvent.TAP -> VibrationEffect.createOneShot(35, amp(150))
            PulseHapticEvent.SUCCESS -> VibrationEffect.createWaveform(longArrayOf(0, 35, 60, 28), intArrayOf(0, amp(170), 0, amp(120)), -1)
            PulseHapticEvent.WARNING -> VibrationEffect.createOneShot(70, amp(230))
            PulseHapticEvent.TUNED -> VibrationEffect.createWaveform(longArrayOf(0, 40, 50, 30), intArrayOf(0, amp(180), 0, amp(130)), -1)
        }
    }
}
