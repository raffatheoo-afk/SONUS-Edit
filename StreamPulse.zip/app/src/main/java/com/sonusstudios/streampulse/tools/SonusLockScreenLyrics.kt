package com.sonusstudios.streampulse.tools

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Uma linha de letra. [timeMs] < 0 indica letra sem sincronização. */
internal data class SonusLockLyricLine(val timeMs: Long, val text: String)

internal data class SonusLockLyrics(val lines: List<SonusLockLyricLine>, val synced: Boolean, val source: String)

/**
 * code132: carregador de letras independente de tela, usado pela tela de bloqueio.
 *
 * Reaproveita as mesmas fontes do Player, na mesma ordem de prioridade:
 *  - SONUS Stream: letra do catálogo / comunidade / LRCLIB via [SonusOnlineMusicRepository.lyricsForFileIdAuto];
 *  - música local: LRCLIB (cache positivo/negativo em disco já existente) e, como fallback offline,
 *    letra incorporada nos metadados do arquivo.
 *
 * Nunca é chamado em massa: só roda sob demanda para a faixa atual e guarda poucas faixas em memória.
 */
internal object SonusLockScreenLyricsLoader {
    private const val MEMORY_LIMIT = 12
    private val timeRegex = Regex("\\[(\\d{1,3}):(\\d{2})(?:[.,](\\d{1,3}))?]")
    private val sectionTagRegex = Regex("^\\[[^\\]]*]$")
    private val offsetRegex = Regex("\\[offset:([+-]?\\d+)]", RegexOption.IGNORE_CASE)

    private val memory = object : LinkedHashMap<String, SonusLockLyrics?>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, SonusLockLyrics?>?): Boolean = size > MEMORY_LIMIT
    }

    suspend fun load(context: Context, item: PulsePlayerQueueItem, durationMs: Long): SonusLockLyrics? {
        // Só a locução da rádio não tem letra; música da rádio tem.
        if (item.kind == PulseQueueKind.RADIO_VOICE) return null
        val key = item.uri
        synchronized(memory) { if (memory.containsKey(key)) return memory[key] }
        val app = context.applicationContext
        val resolved: SonusLockLyrics? = withContext(Dispatchers.IO) {
            runCatching { resolve(app, item, durationMs) }.getOrNull()
        }
        // Só letras encontradas ficam em memória. "Sem letra" é decidido pelo cache negativo em disco
        // (SonusLyricsResolver), que já distingue resposta vazia de falha de rede/limite do serviço.
        if (resolved != null) synchronized(memory) { memory[key] = resolved }
        return resolved
    }

    private suspend fun resolve(context: Context, item: PulsePlayerQueueItem, durationMs: Long): SonusLockLyrics? {
        val online = SonusOnlineRef.parse(item.uri)
        if (online != null) {
            val repo = SonusOnlineMusicRepository(context)
            runCatching { repo.refreshTrackOverrides() }
            val lyrics = repo.lyricsForFileIdAuto(online.fileId) ?: return null
            return parse(lyrics.first, lyrics.second, "SONUS Stream")
        }
        val duration = durationMs.takeIf { it > 0L } ?: item.durationMs
        SonusLyricsResolver.lrclib(context, SonusLyricsQuery(item.title, item.artist, item.album, duration))?.let {
            parse(it.text, it.format, it.source)?.let { parsed -> return parsed }
        }
        val embedded = runCatching { AudioToolEngine.readMetadata(context, Uri.parse(item.uri)).lyrics }.getOrDefault("").orEmpty().trim()
        if (embedded.isNotBlank()) {
            val format = if (timeRegex.containsMatchIn(embedded)) "LRC" else "TEXT"
            return parse(embedded, format, "Arquivo")
        }
        return null
    }

    /** Converte LRC (com vários timestamps por linha e tag [offset:]) ou texto simples em linhas. */
    fun parse(text: String, format: String, source: String): SonusLockLyrics? {
        val raw = text.trim()
        if (raw.isBlank()) return null
        val looksSynced = format.equals("LRC", ignoreCase = true) || timeRegex.containsMatchIn(raw)
        if (looksSynced) {
            val offsetMs = offsetRegex.find(raw)?.groupValues?.getOrNull(1)?.toLongOrNull() ?: 0L
            val out = ArrayList<SonusLockLyricLine>()
            raw.lineSequence().forEach { line ->
                val stamps = timeRegex.findAll(line).toList()
                if (stamps.isEmpty()) return@forEach
                val lyric = line.replace(timeRegex, "").trim()
                if (lyric.isBlank() || lyric.matches(sectionTagRegex)) return@forEach
                stamps.forEach { m ->
                    val minutes = m.groupValues[1].toLongOrNull() ?: 0L
                    val seconds = m.groupValues[2].toLongOrNull() ?: 0L
                    val fraction = m.groupValues[3].padEnd(3, '0').take(3).toLongOrNull() ?: 0L
                    val at = ((minutes * 60L + seconds) * 1000L + fraction + offsetMs).coerceAtLeast(0L)
                    out += SonusLockLyricLine(at, lyric)
                }
            }
            if (out.isNotEmpty()) return SonusLockLyrics(out.sortedBy { it.timeMs }, synced = true, source = source)
        }
        val plain = raw.lineSequence().map { it.trim() }.filter { it.isNotBlank() && !it.startsWith("[") }.map { SonusLockLyricLine(-1L, it) }.toList()
        return if (plain.isEmpty()) null else SonusLockLyrics(plain, synced = false, source = source)
    }

    /** Índice da linha atual para [positionMs] (busca binária); -1 antes da primeira linha. */
    fun indexAt(lyrics: SonusLockLyrics, positionMs: Long): Int {
        if (!lyrics.synced || lyrics.lines.isEmpty()) return -1
        var lo = 0
        var hi = lyrics.lines.lastIndex
        var best = -1
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            if (lyrics.lines[mid].timeMs <= positionMs) { best = mid; lo = mid + 1 } else hi = mid - 1
        }
        return best
    }
}
