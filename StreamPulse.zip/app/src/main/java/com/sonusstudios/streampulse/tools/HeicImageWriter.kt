package com.sonusstudios.streampulse.tools

import android.graphics.Bitmap
import androidx.annotation.RequiresApi
import androidx.heifwriter.HeifWriter
import java.io.File

/**
 * Encapsula toda referência ao androidx.heifwriter em uma classe que só pode
 * ser carregada em Android 9 (API 28) ou superior.
 */
@RequiresApi(28)
internal object HeicImageWriter {
    fun write(bitmap: Bitmap, quality: Int, output: File) {
        val writer = HeifWriter.Builder(
            output.absolutePath,
            bitmap.width,
            bitmap.height,
            HeifWriter.INPUT_MODE_BITMAP
        )
            .setQuality(quality.coerceIn(10, 100))
            .build()

        try {
            writer.start()
            writer.addBitmap(bitmap)
            writer.stop(15_000)
        } finally {
            writer.close()
        }
    }
}
