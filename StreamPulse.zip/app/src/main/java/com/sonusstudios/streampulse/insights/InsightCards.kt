package com.sonusstudios.streampulse.insights

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonusstudios.streampulse.core.*
import java.text.NumberFormat
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToLong
import kotlinx.coroutines.delay

private val brl = NumberFormat.getCurrencyInstance(Locale("pt", "BR"))
private val intFmt = NumberFormat.getIntegerInstance(Locale("pt", "BR"))

private fun inCycle(dateIso: String, cycle: CycleWindow): Boolean = runCatching {
    val d=LocalDate.parse(dateIso); !d.isBefore(LocalDate.parse(cycle.startIso)) && !d.isAfter(LocalDate.parse(cycle.endIso))
}.getOrDefault(false)

/** Série única para os cards de insight, igual ao motor do Saldo/Pulso. */
private fun unifiedEntries(state: AppState, artist: Artist, referenceDate: LocalDate = LocalDate.now()): List<DailyStreamEntry> {
    val snapshots = state.snapshots.filter { it.artistId == artist.id }
    val dailyRecords = state.dailyStreamRecords.filter { it.artistId == artist.id }
    val windows = linkedMapOf<String, CycleWindow>()
    snapshots.forEach { snapshot ->
        windows["${snapshot.cycleStartIso}|${snapshot.cycleEndIso}"] = CycleWindow(snapshot.cycleStartIso, snapshot.cycleEndIso, "Histórico")
    }
    val current = DistributorRules.cycleFor(artist, referenceDate)
    windows["${current.startIso}|${current.endIso}"] = current
    dailyRecords.forEach { record ->
        val date = runCatching { LocalDate.parse(record.dateIso) }.getOrNull() ?: return@forEach
        if (windows.values.none { inCycle(record.dateIso, it) }) {
            val derived = DistributorRules.cycleFor(artist, date)
            windows["${derived.startIso}|${derived.endIso}"] = derived
        }
    }
    return windows.values.sortedBy { it.startIso }.flatMap { window ->
        val start = runCatching { LocalDate.parse(window.startIso) }.getOrNull() ?: return@flatMap emptyList()
        val end = runCatching { LocalDate.parse(window.endIso) }.getOrNull() ?: return@flatMap emptyList()
        StreamMetricsEngine.cycleMetrics(
            snapshots.filter { inCycle(it.dateIso, window) },
            dailyRecords.filter { inCycle(it.dateIso, window) },
            start,
            end,
            minOf(referenceDate, end)
        ).dailyEntries
    }.groupBy { it.dateIso }.map { (_, rows) -> rows.last() }.sortedBy { it.dateIso }
}

@Composable
fun LivePulseCard(state: AppState, artist: Artist, tier: MembershipTier, owner: Boolean) {
    val today = LocalDate.now()
    val cycle = DistributorRules.cycleFor(artist, today)
    val snapshots = state.snapshots.filter { it.artistId == artist.id }
    val cycleSnapshots = snapshots.filter { inCycle(it.dateIso, cycle) }
    val payments = state.payments.filter { it.artistId == artist.id }
    val rpm = RoyaltyEngine.personalizedRpm(artist, payments)

    // Fonte única: exatamente o mesmo motor que alimenta "O que mudou?" / Ritmo recente.
    // O Pulso apenas transforma o ritmo diário em uma estimativa proporcional ao horário,
    // evitando uma segunda fórmula concorrente e números fora da curva.
    val cycleDailyRecords = state.dailyStreamRecords.filter { it.artistId == artist.id && inCycle(it.dateIso, cycle) }
    val forecast = RoyaltyEngine.forecast(
        cycleSnapshots,
        cycleDailyRecords,
        LocalDate.parse(cycle.startIso),
        LocalDate.parse(cycle.endIso),
        today,
        rpm
    )
    val recentDailyRate = forecast.projectedDailyRate.coerceAtLeast(0.0)

    val midnight = remember(today) {
        System.currentTimeMillis() - java.time.LocalTime.now().toSecondOfDay() * 1_000L
    }
    val now by produceState(System.currentTimeMillis()) {
        while (true) { value = System.currentTimeMillis(); delay(1_000) }
    }
    val elapsedFraction = ((now - midnight).coerceAtLeast(0L) / 86_400_000.0).coerceIn(0.0, 1.0)
    val estimatedToday = recentDailyRate * elapsedFraction
    val estimatedRevenue = RoyaltyEngine.estimateBrl(estimatedToday.roundToLong(), rpm)

    val daily = StreamMetricsEngine.cycleMetrics(
        cycleSnapshots,
        cycleDailyRecords,
        LocalDate.parse(cycle.startIso),
        LocalDate.parse(cycle.endIso),
        today
    ).dailyEntries.sortedBy { it.dateIso }
    val latestWindow = daily.takeLast(3).map { it.streams.toDouble() }
    val previousWindow = daily.dropLast(minOf(3, daily.size)).takeLast(3).map { it.streams.toDouble() }
    val oldAvg = previousWindow.takeIf { it.isNotEmpty() }?.average()
    val newAvg = latestWindow.takeIf { it.isNotEmpty() }?.average() ?: 0.0
    val delta = if (oldAvg != null && oldAvg > 0.0) (newAvg - oldAvg) / oldAvg * 100.0 else 0.0

    val pulse = rememberInfiniteTransition(label = "live-pulse")
    val alpha by pulse.animateFloat(
        0.35f, 1f,
        androidx.compose.animation.core.infiniteRepeatable(
            androidx.compose.animation.core.tween(900),
            androidx.compose.animation.core.RepeatMode.Reverse
        ),
        label = "pulse-alpha"
    )
    Surface(shape = RoundedCornerShape(18.dp), color = Color.Transparent, border = BorderStroke(1.dp, Color(0xFF5688D8).copy(alpha = .38f))) {
        Column(Modifier.background(Brush.linearGradient(listOf(Color(0xFF081D36), Color(0xFF173865), Color(0xFF10213E)))).padding(horizontal = 13.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(9.dp).background(Color(0xFF65C8FF).copy(alpha = alpha), androidx.compose.foundation.shape.CircleShape))
                Spacer(Modifier.width(7.dp))
                Text("PULSO AO VIVO", color = Color.White, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.weight(1f))
                Text("Precisão", color = Color.White.copy(alpha = .72f), fontSize = 9.sp)
                Spacer(Modifier.width(5.dp))
                val precisionColor = when (forecast.confidence) {
                    "Alta" -> Color(0xFF42D77D)
                    "Média" -> Color(0xFFFFC83D)
                    else -> Color(0xFFFF4D5E)
                }
                Box(Modifier.size(8.dp).background(precisionColor, androidx.compose.foundation.shape.CircleShape))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                PulseMini(Modifier.weight(1f), "Ritmo", if (recentDailyRate > 0.0) "${intFmt.format((recentDailyRate / 24.0).roundToLong())}/h" else "—")
                PulseMini(Modifier.weight(1f), "Receita hoje", brl.format(estimatedRevenue))
                PulseMini(Modifier.weight(1f), "Tendência", String.format(Locale.US, "%+.1f%%", delta))
            }
        }
    }
}
@Composable private fun PulseMini(m:Modifier,label:String,value:String){Surface(m,shape=RoundedCornerShape(14.dp),color=Color.White.copy(alpha=.08f)){Column(Modifier.padding(9.dp)){Text(label,color=Color.White.copy(alpha=.58f),fontSize=9.sp);Text(value,color=Color.White,fontWeight=FontWeight.Bold,fontSize=12.sp)}}}

@Composable
fun WhatChangedCard(state: AppState, artist: Artist) {
    val daily=unifiedEntries(state,artist).sortedBy{it.dateIso}
    if(daily.size<2) return
    val last=daily.last();val prev=daily[daily.lastIndex-1];val pct=if(prev.streams>0)(last.streams-prev.streams)*100.0/prev.streams else 0.0
    val cycle=DistributorRules.cycleFor(artist,LocalDate.now());val snaps=state.snapshots.filter{it.artistId==artist.id&&inCycle(it.dateIso,cycle)};val dailyRecords=state.dailyStreamRecords.filter{it.artistId==artist.id&&inCycle(it.dateIso,cycle)};val rpm=RoyaltyEngine.personalizedRpm(artist,state.payments.filter{it.artistId==artist.id});val forecast=RoyaltyEngine.forecast(snaps,dailyRecords,LocalDate.parse(cycle.startIso),LocalDate.parse(cycle.endIso),LocalDate.now(),rpm)
    Card{Column(Modifier.padding(15.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){Row(verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.ChangeCircle,null,tint=MaterialTheme.colorScheme.primary);Spacer(Modifier.width(7.dp));Text("O que mudou?",fontWeight=FontWeight.ExtraBold)};Text("• Último dia: ${intFmt.format(last.streams)} streams (${String.format(Locale.US,"%+.1f%%",pct)} vs. registro anterior)");Text("• Projeção atual: ${intFmt.format(forecast.projectedStreams)} streams • ${brl.format(forecast.projectedBrl)}");Text("O ritmo usado pelo Pulso ao Vivo vem desta mesma projeção.",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.55f))}}
}

@Composable
fun HistoryRecordHighlights(state:AppState,artist:Artist){
    val daily=unifiedEntries(state,artist).sortedBy{it.dateIso};if(daily.isEmpty())return
    val best=daily.maxByOrNull{it.streams};val worst=daily.minByOrNull{it.streams};val payments=state.payments.filter{it.artistId==artist.id};val biggest=payments.maxByOrNull{it.amountBrl}
    Card{Column(Modifier.padding(15.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){Text("Recordes do projeto",fontWeight=FontWeight.ExtraBold);Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxWidth()){RecordMini(Modifier.weight(1f),"🏆 Melhor dia",best?.streams?.let{intFmt.format(it)}?:"—");RecordMini(Modifier.weight(1f),"📉 Menor dia",worst?.streams?.let{intFmt.format(it)}?:"—")};Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxWidth()){RecordMini(Modifier.weight(1f),"💰 Maior pagamento",biggest?.amountBrl?.let{brl.format(it)}?:"—");RecordMini(Modifier.weight(1f),"📚 Registros",daily.size.toString())}}}
}
@Composable private fun RecordMini(m:Modifier,label:String,value:String){Surface(m,shape=RoundedCornerShape(14.dp),color=MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.55f)){Column(Modifier.padding(10.dp)){Text(label,fontSize=9.sp,color=MaterialTheme.colorScheme.onSurface.copy(alpha=.58f));Text(value,fontWeight=FontWeight.ExtraBold)}}}

data class DistributorRollup(val name:String,val streams:Long,val revenue:Double,val artists:Int,val trend:Double)
private fun rollups(state:AppState):List<DistributorRollup>{return state.artists.groupBy{it.distributor to it.customDistributorName}.map{(key,artists)->
    var streams=0L;var revenue=0.0;val changes=mutableListOf<Double>()
    artists.forEach{a->
        val today=LocalDate.now();val cycle=DistributorRules.cycleFor(a,today)
        val snaps=state.snapshots.filter{it.artistId==a.id&&inCycle(it.dateIso,cycle)}
        val dailyRecords=state.dailyStreamRecords.filter{it.artistId==a.id&&inCycle(it.dateIso,cycle)}
        val metrics=StreamMetricsEngine.cycleMetrics(snaps,dailyRecords,LocalDate.parse(cycle.startIso),LocalDate.parse(cycle.endIso),today)
        streams+=metrics.currentStreams
        val rpm=RoyaltyEngine.personalizedRpm(a,state.payments.filter{it.artistId==a.id})
        revenue+=RoyaltyEngine.estimateBrl(metrics.currentStreams,rpm)
        val d=metrics.dailyEntries.takeLast(6)
        if(d.size>=2){val half=d.size/2;val old=d.take(half).map{it.streams}.average();val new=d.drop(half).map{it.streams}.average();if(old>0)changes+=(new-old)*100/old}
    }
    DistributorRollup(DistributorRules.displayName(key.first,key.second),streams,revenue,artists.size,changes.takeIf{it.isNotEmpty()}?.average()?:0.0)
}.sortedByDescending{it.revenue}}

@Composable
fun DistributorIntelligenceSection(state:AppState,selected:Artist,tier:MembershipTier,owner:Boolean){
    val rows=remember(state){rollups(state)};if(rows.isEmpty())return
    Column(verticalArrangement=Arrangement.spacedBy(10.dp)){
        Text("Central das distribuidoras",fontWeight=FontWeight.ExtraBold,fontSize=18.sp)
        rows.forEachIndexed{idx,r->Card{Column(Modifier.padding(13.dp),verticalArrangement=Arrangement.spacedBy(4.dp)){Row{Text("${idx+1}. ${r.name}",fontWeight=FontWeight.ExtraBold,modifier=Modifier.weight(1f));Text(String.format(Locale.US,"%+.1f%%",r.trend),color=if(r.trend>=0)Color(0xFF4CAF79)else Color(0xFFCC4B4B),fontWeight=FontWeight.Bold)};Text("${intFmt.format(r.streams)} streams • ${brl.format(r.revenue)} • ${r.artists} artista(s)",style=MaterialTheme.typography.bodySmall);if((tier.ordinal >= MembershipTier.PRATA.ordinal || owner)&&rows.size>1){val share=if(rows.sumOf{it.revenue}>0)r.revenue/rows.sumOf{it.revenue}*100 else 0.0;LinearProgressIndicator(progress={(share/100).toFloat().coerceIn(0f,1f)},modifier=Modifier.fillMaxWidth());Text("Participação estimada: ${String.format(Locale.US,"%.1f%%",share)}",style=MaterialTheme.typography.labelSmall)}}}
        }
        if(rows.size>1){val top=rows.maxByOrNull{it.revenue};val total=rows.sumOf{it.revenue};val concentration=if(total>0)(top?.revenue?:0.0)/total*100 else 0.0;Card{Column(Modifier.padding(14.dp)){Text("Dependência de receita",fontWeight=FontWeight.Bold);Text(if(concentration>=70)"Concentração alta: ${String.format(Locale.US,"%.0f%%",concentration)} da estimativa está em ${top?.name}." else "Receita relativamente distribuída entre as fontes cadastradas.",style=MaterialTheme.typography.bodySmall)}}}
    }
}

@Composable
fun FinanceReconciliationInsights(state:AppState,artist:Artist){
    val payments=state.payments.filter{it.artistId==artist.id && !it.isRetroactive && it.cycleStreams>0}.sortedBy{it.paidDateIso};if(payments.isEmpty())return
    val latest=payments.last();val est=latest.estimatedBrlBeforeCalibration;val diff=if(est!=null&&est!=0.0)(latest.amountBrl-est)/est*100 else null
    val errors=payments.mapNotNull{p->p.estimatedBrlBeforeCalibration?.takeIf{it>0}?.let{e->kotlin.math.abs(p.amountBrl-e)/e*100}};val accuracy=errors.takeIf{it.isNotEmpty()}?.let{(100-it.average()).coerceIn(0.0,100.0)}
    Card{Column(Modifier.padding(15.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){Text("Conciliação financeira",fontWeight=FontWeight.ExtraBold);Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxWidth()){RecordMini(Modifier.weight(1f),"Estimado",est?.let{brl.format(it)}?:"—");RecordMini(Modifier.weight(1f),"Recebido",brl.format(latest.amountBrl));RecordMini(Modifier.weight(1f),"Diferença",diff?.let{String.format(Locale.US,"%+.1f%%",it)}?:"—")};accuracy?.let{Text("Precisão média das previsões registradas: ${String.format(Locale.US,"%.1f%%",it)}",style=MaterialTheme.typography.bodySmall)}}}
}
