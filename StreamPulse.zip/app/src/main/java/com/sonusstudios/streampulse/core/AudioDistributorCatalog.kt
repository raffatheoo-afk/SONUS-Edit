package com.sonusstudios.streampulse.core

import androidx.compose.runtime.Immutable

@Immutable
data class AudioDistributorProfile(
    val distributor: DistributorId,
    val formats: List<String>,
    val recommendedFormat: String,
    val allowedSampleRates: List<Int>,
    val allowedBitDepths: List<Int>,
    val stereoOnly: Boolean = true,
    val maxFileSizeMb: Int? = null,
    val maxDurationMinutes: Int? = null,
    val minDurationSeconds: Int? = null,
    val notes: List<String> = emptyList()
)

object AudioDistributorCatalog {
    private val profiles = mapOf(
        DistributorId.SOUNDON to AudioDistributorProfile(
            DistributorId.SOUNDON, listOf("WAV", "FLAC"), "WAV", listOf(44100, 48000, 88200, 96000, 192000), listOf(16, 24),
            maxFileSizeMb = 200,
            notes = listOf("WAV é recomendado; outros tipos podem ser convertidos pela plataforma para FLAC.", "Singles de uma faixa devem ter pelo menos 60 s.")
        ),
        DistributorId.DITTO to AudioDistributorProfile(
            DistributorId.DITTO, listOf("WAV", "MP3", "FLAC"), "WAV", listOf(44100, 48000, 88200, 96000, 192000), listOf(16, 24),
            notes = listOf("Use áudio estéreo e qualidade de estúdio.", "FLAC incluído com base na interface atual da Ditto informada pelo usuário.")
        ),
        DistributorId.DISTROKID to AudioDistributorProfile(
            DistributorId.DISTROKID, listOf("WAV", "MP3", "FLAC"), "WAV", listOf(44100, 48000, 88200, 96000, 176400, 192000), listOf(16, 24),
            maxFileSizeMb = 1024,
            notes = listOf("A DistroKid aceita também M4A e AIFF; o Conversor Pro permite formatos adicionais mesmo quando não fazem parte do perfil recomendado.")
        ),
        DistributorId.TUNECORE to AudioDistributorProfile(
            DistributorId.TUNECORE, listOf("WAV"), "WAV", listOf(44100, 48000, 88200, 96000, 176400, 192000), listOf(16, 24),
            notes = listOf("16-bit/44,1 kHz é aceito; a documentação também recomenda alta resolução.", "O SONUS não força 1.411 kbps em 24-bit/192 kHz, pois esse valor é documentalmente inconsistente.")
        ),
        DistributorId.FRESHTUNES to AudioDistributorProfile(
            DistributorId.FRESHTUNES, listOf("WAV", "FLAC"), "FLAC", listOf(44100, 48000, 88200, 96000), listOf(16, 24),
            notes = listOf("Somente estéreo.", "Evite clipping acima de 0 dBFS e mantenha silêncio inicial/final curto.")
        ),
        DistributorId.ROUTENOTE to AudioDistributorProfile(
            DistributorId.ROUTENOTE, listOf("FLAC", "MP3", "WAV"), "FLAC", listOf(44100, 88200, 96000, 176400, 192000), listOf(16, 24),
            notes = listOf("Fluxo padrão: FLAC ou MP3 320 kbps, 16-bit/44,1 kHz.", "WAV/FLAC Hi-Res usa 24-bit e, para selo Apple Hi-Res Lossless, 88,2 kHz ou mais.")
        ),
        DistributorId.CDBABY to AudioDistributorProfile(
            DistributorId.CDBABY, listOf("WAV", "FLAC", "MP3"), "WAV", listOf(44100), listOf(16),
            notes = listOf("WAV ou FLAC são preferidos; MP3 320 kbps é aceito, mas não recomendado.", "Perfil padrão: estéreo 16-bit/44,1 kHz.")
        ),
        DistributorId.ONERPM to AudioDistributorProfile(
            DistributorId.ONERPM, listOf("WAV", "FLAC"), "WAV", listOf(44100, 48000, 88200, 96000, 176400, 192000), listOf(16, 24),
            notes = listOf("Dolby Atmos segue fluxo próprio; 48 kHz/24-bit é recomendado para esse caso.")
        ),
        DistributorId.UNITEDMASTERS to AudioDistributorProfile(
            DistributorId.UNITEDMASTERS, listOf("WAV", "FLAC", "MP3"), "WAV", listOf(44100, 48000, 96000, 176400, 192000), listOf(16, 24),
            notes = listOf("MP3 pode ser aceito e convertido internamente; WAV/FLAC preservam melhor o master.")
        ),
        DistributorId.AMUSE to AudioDistributorProfile(
            DistributorId.AMUSE, listOf("WAV", "FLAC"), "WAV", listOf(44100, 48000, 88200, 96000, 176400, 192000), listOf(16, 24),
            maxDurationMinutes = 90,
            notes = listOf("Somente estéreo.", "Hi-Res pode depender do plano.")
        ),
        DistributorId.LANDR to AudioDistributorProfile(
            DistributorId.LANDR, listOf("WAV", "FLAC"), "WAV", listOf(44100, 48000, 88200, 96000, 176400, 192000), listOf(16, 24),
            notes = listOf("Faixa documentada entre 16-bit/44,1 kHz e 24-bit/192 kHz.")
        ),
        DistributorId.SYMPHONIC to AudioDistributorProfile(
            DistributorId.SYMPHONIC, listOf("WAV", "FLAC"), "WAV", listOf(44100, 48000, 88200, 96000, 176400, 192000), listOf(16, 24),
            notes = listOf("Somente estéreo.", "A documentação recomenda atenção a dithering em arquivos 24-bit e metadados incorporados.")
        ),
        DistributorId.TOOLOST to AudioDistributorProfile(
            DistributorId.TOOLOST, listOf("WAV", "FLAC", "MP3"), "WAV", listOf(44100, 48000, 88200, 96000, 176400, 192000), listOf(16, 24),
            minDurationSeconds = 5,
            notes = listOf("WAV/FLAC 24-bit/44,1 kHz é uma boa opção HD; padrão 16-bit/44,1 kHz.")
        ),
        DistributorId.OTHER to AudioDistributorProfile(
            DistributorId.OTHER, listOf("WAV", "FLAC", "MP3"), "WAV", listOf(44100, 48000, 96000, 192000), listOf(16, 24),
            notes = listOf("Distribuidora personalizada: confirme as especificações oficiais antes do envio.")
        )
    )

    fun profile(distributor: DistributorId): AudioDistributorProfile = profiles.getValue(distributor)

    fun defaultPreset(distributor: DistributorId): AudioConversionPreset {
        val p = profile(distributor)
        val format = p.recommendedFormat
        val hiResPreferred = distributor in setOf(DistributorId.LANDR, DistributorId.AMUSE, DistributorId.SYMPHONIC)
        return AudioConversionPreset(
            format = format,
            sampleRateHz = if (hiResPreferred && 96000 in p.allowedSampleRates) 96000 else 44100,
            bitDepth = if (hiResPreferred && 24 in p.allowedBitDepths) 24 else p.allowedBitDepths.minOrNull() ?: 16,
            bitrateKbps = 320,
            channels = 2
        )
    }
}
