package com.sonusstudios.streampulse.core

import java.text.Normalizer
import java.util.Locale

/**
 * Fonte única para padrões de mídia compartilhados por todo o SONUS.
 * Evita listas divergentes de gênero/bitrate e centraliza a validação de letras.
 */
object SonusMediaStandards {
    /** Catálogo único, em ordem alfabética, compartilhado por Stream, Rádio e editores. */
    val genres: List<String> = listOf(
        "Arrocha",
        "Axé",
        "Bossa Nova / MPB",
        "Brega / Tecnobrega",
        "Católico / Gospel",
        "Eletrônica",
        "Forró / Piseiro / Xote",
        "Funk",
        "Internacional",
        "Pagode / Samba",
        "Pop",
        "Rap / Hip-hop / Trap",
        "Reggae",
        "Rock",
        "Romântico / Acústico",
        "Sertanejo",
        "Sofrência",
        "Triste / Depressão / Melancólico"
    )

    val mp3Bitrates: List<Int> = listOf(32, 48, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320)
    val aacBitrates: List<Int> = listOf(32, 48, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320)
    val opusBitrates: List<Int> = listOf(48, 64, 80, 96, 112, 128, 160, 192, 224, 256)

    fun bitratePresets(format: String): List<Int> = when (format.trim().uppercase(Locale.ROOT)) {
        "MP3" -> mp3Bitrates
        "M4A", "AAC", "M4A/AAC" -> aacBitrates
        "OPUS", "WEBM", "WEBM/OPUS" -> opusBitrates
        else -> emptyList()
    }

    fun nearestBitrate(format: String, value: Int): Int {
        val presets = bitratePresets(format)
        if (presets.isEmpty()) return value
        return presets.minByOrNull { kotlin.math.abs(it - value) } ?: presets.first()
    }

    /**
     * Normaliza grafia e aliases históricos sem apagar metadados do catálogo.
     * Rótulos de humor (Sofrência/Triste) só são atribuídos quando vierem
     * explicitamente no metadado; andamento lento não implica tristeza.
     */
    fun canonicalGenre(raw: String): String {
        val clean = raw.trim()
        if (clean.isBlank()) return ""
        val n = normalize(clean).replace(Regex("\\s+"), " ")
        return when {
            n.contains("arrocha") -> "Arrocha"
            n.contains("axe") -> "Axé"
            n.contains("bossa") || n == "mpb" || n.contains("musica popular brasileira") -> "Bossa Nova / MPB"
            n.contains("brega") || n.contains("tecnobrega") -> "Brega / Tecnobrega"
            n.contains("catol") || n.contains("gospel") || n.contains("religios") -> "Católico / Gospel"
            n.contains("eletronic") || n.contains("electronic") || n.contains("dance") || n.contains("house") || n.contains("techno") -> "Eletrônica"
            n.contains("forro") || n.contains("piseiro") || n.contains("xote") || n.contains("xaxado") || n.contains("baiao") -> "Forró / Piseiro / Xote"
            n.contains("funk") -> "Funk"
            n.contains("internacional") || n == "international" || n == "foreign" -> "Internacional"
            n.contains("pagode") || n.contains("samba") -> "Pagode / Samba"
            n == "pop" || n.startsWith("pop ") -> "Pop"
            n.contains("rap") || n.contains("hip hop") || n.contains("hip-hop") || n.contains("trap") -> "Rap / Hip-hop / Trap"
            n.contains("reggae") -> "Reggae"
            n.contains("rock") || n.contains("metal") || n.contains("punk") -> "Rock"
            n.contains("sofrencia") -> "Sofrência"
            n.contains("triste") || n.contains("depress") || n.contains("melancol") -> "Triste / Depressão / Melancólico"
            n.contains("romant") || n.contains("acust") || n.contains("modinha") -> "Romântico / Acústico"
            n.contains("sertanejo") -> "Sertanejo"
            // Frevo saiu das opções principais, mas permanece reconhecível como dado legado.
            n.contains("frevo") -> "Frevo"
            else -> genres.firstOrNull { normalize(it) == n } ?: clean
        }
    }

    fun isLyricsFileName(name: String): Boolean {
        val lower = name.trim().lowercase(Locale.ROOT)
        return lower.endsWith(".lrc") || lower.endsWith(".txt")
    }

    fun isSyncedLrc(text: String): Boolean =
        Regex("""(?m)^\s*\[\d{1,3}:\d{2}(?:[.,:]\d{1,3})?]""").containsMatchIn(text)

    fun lyricsFormat(fileName: String, text: String): String =
        if (fileName.lowercase(Locale.ROOT).endsWith(".lrc") || isSyncedLrc(text)) "LRC" else "TEXT"

    /**
     * Remove apenas sufixos técnicos típicos de arquivos baixados/convertidos.
     * Nunca renomeia o arquivo original; serve somente para apresentação.
     */
    fun cleanDisplayTitle(metadataTitle: String, fileName: String, artist: String = ""): String {
        val fallback = fileName.substringBeforeLast('.').trim()
        var value = metadataTitle.trim().ifBlank { fallback }
        if (value.equals(fileName, ignoreCase = true)) value = fallback

        // Exemplos aceitos: (MP3_128K), [mp3-320kbps], MP3 160K, _128kbps, - MP3.
        val technicalSuffix = Regex(
            """(?ix)
            (?:\s*[-_–—]?\s*)
            (?:[\(\[\{]\s*)?
            (?:mp3\s*[-_ ]*)?
            (?:32|48|64|80|96|112|128|160|192|224|256|320)
            \s*(?:k|kbps|kb/s|kbit/s|kbs|kpbs)
            (?:\s*[\)\]\}])?
            \s*$
            """.trimIndent()
        )
        val formatSuffix = Regex("""(?i)(?:\s*[-_–—]?\s*)(?:[\(\[\{]\s*)?(?:mp3)(?:\s*[\)\]\}])?\s*$""")

        var previous: String
        do {
            previous = value
            value = value.replace(technicalSuffix, "").replace(formatSuffix, "").trim()
        } while (value != previous)

        // Se o metadado ainda for um filename técnico, faça uma segunda limpeza do fallback.
        if (value.isBlank()) value = fallback
        value = value.replace(Regex("_+"), " ")
        value = value.replace(Regex("\\s+"), " ").trim(' ', '-', '_', '.', '(', ')', '[', ']')

        // Remove artista apenas do fallback quando veio colado como prefixo/sufixo de filename.
        if (metadataTitle.isBlank() && artist.isNotBlank()) {
            val artistWords = artist.trim().split(Regex("[-_\\s]+")).filter { it.isNotBlank() }
            if (artistWords.isNotEmpty()) {
                val pattern = artistWords.joinToString("[-_\\s]+") { Regex.escape(it) }
                value = value.replace(Regex("(?i)(?:^|[-_\\s]+)$pattern(?:$|[-_\\s]+)"), " ")
                    .replace(Regex("\\s+"), " ").trim()
            }
        }
        return value.ifBlank { fallback.ifBlank { "Sem título" } }
    }

    private fun normalize(value: String): String = Normalizer.normalize(
        value.trim().lowercase(Locale.ROOT), Normalizer.Form.NFD
    ).replace(Regex("\\p{M}+"), "")
}
