package com.sonusstudios.streampulse.core

import java.text.Normalizer
import java.util.Locale

/**
 * Fonte única para padrões de mídia compartilhados por todo o SONUS.
 * Evita listas divergentes de gênero/bitrate e centraliza a validação de letras.
 */
object SonusMediaStandards {
    val genres: List<String> = listOf(
        "Axé", "Baile Funk", "Bossa Nova", "Brega", "Forró", "Frevo", "Maracatu", "Modinha",
        "MPB (Música Popular Brasileira)", "Pagode", "Piseiro", "Samba", "Sertanejo Antigo",
        "Sertanejo Universitário", "Tecnobrega", "Xaxado", "Xote", "Arrocha", "Católica", "Gospel",
        "Pop", "Rap / Hip-Hop", "Reggae", "Rock", "Trap", "Eletrônica", "Romântico / Acústico"
    )

    val mp3Bitrates: List<Int> = listOf(32, 48, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320)
    val aacBitrates: List<Int> = listOf(32, 48, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320)
    val opusBitrates: List<Int> = listOf(48, 64, 80, 96, 112, 128, 160, 192, 224, 256)

    fun bitratePresets(format: String): List<Int> = when (format.trim().uppercase(Locale.ROOT)) {
        "MP3" -> mp3Bitrates
        "M4A", "AAC", "M4A/AAC" -> aacBitrates
        "OPUS", "WEBM", "WEBM/OPUS" -> opusBitrates
        else -> emptyList()
    }

    fun nearestBitrate(format: String, value: Int): Int {
        val presets = bitratePresets(format)
        if (presets.isEmpty()) return value
        return presets.minByOrNull { kotlin.math.abs(it - value) } ?: presets.first()
    }

    fun canonicalGenre(raw: String): String {
        val clean = raw.trim()
        if (clean.isBlank()) return ""
        val n = normalize(clean)
        return when {
            n.contains("piseiro") -> "Piseiro"
            n.contains("trap") -> "Trap"
            n.contains("romant") || n.contains("acust") -> "Romântico / Acústico"
            n.contains("catol") -> "Católica"
            n.contains("gospel") -> "Gospel"
            n.contains("sertanejo antigo") -> "Sertanejo Antigo"
            n.contains("sertanejo universit") -> "Sertanejo Universitário"
            n.contains("baile") && n.contains("funk") -> "Baile Funk"
            n == "mpb" || n.contains("musica popular brasileira") -> "MPB (Música Popular Brasileira)"
            else -> genres.firstOrNull { normalize(it) == n } ?: clean
        }
    }

    fun isLyricsFileName(name: String): Boolean {
        val lower = name.trim().lowercase(Locale.ROOT)
        return lower.endsWith(".lrc") || lower.endsWith(".txt")
    }

    fun isSyncedLrc(text: String): Boolean =
        Regex("""(?m)^\s*\[\d{1,3}:\d{2}(?:[.,:]\d{1,3})?]""").containsMatchIn(text)

    fun lyricsFormat(fileName: String, text: String): String =
        if (fileName.lowercase(Locale.ROOT).endsWith(".lrc") || isSyncedLrc(text)) "LRC" else "TEXT"

    /**
     * Remove apenas sufixos técnicos típicos de arquivos baixados/convertidos.
     * Nunca renomeia o arquivo original; serve somente para apresentação.
     */
    fun cleanDisplayTitle(metadataTitle: String, fileName: String, artist: String = ""): String {
        val fallback = fileName.substringBeforeLast('.').trim()
        var value = metadataTitle.trim().ifBlank { fallback }
        if (value.equals(fileName, ignoreCase = true)) value = fallback

        // Exemplos aceitos: (MP3_128K), [mp3-320kbps], MP3 160K, _128kbps, - MP3.
        val technicalSuffix = Regex(
            """(?ix)
            (?:\s*[-_–—]?\s*)
            (?:[\(\[\{]\s*)?
            (?:mp3\s*[-_ ]*)?
            (?:32|48|64|80|96|112|128|160|192|224|256|320)
            \s*(?:k|kbps|kb/s|kbit/s|kbs|kpbs)
            (?:\s*[\)\]\}])?
            \s*$
            """.trimIndent()
        )
        val formatSuffix = Regex("""(?i)(?:\s*[-_–—]?\s*)(?:[\(\[\{]\s*)?(?:mp3)(?:\s*[\)\]\}])?\s*$""")

        var previous: String
        do {
            previous = value
            value = value.replace(technicalSuffix, "").replace(formatSuffix, "").trim()
        } while (value != previous)

        // Se o metadado ainda for um filename técnico, faça uma segunda limpeza do fallback.
        if (value.isBlank()) value = fallback
        value = value.replace(Regex("_+"), " ")
        value = value.replace(Regex("\\s+"), " ").trim(' ', '-', '_', '.', '(', ')', '[', ']')

        // Remove artista apenas do fallback quando veio colado como prefixo/sufixo de filename.
        if (metadataTitle.isBlank() && artist.isNotBlank()) {
            val artistWords = artist.trim().split(Regex("[-_\\s]+")).filter { it.isNotBlank() }
            if (artistWords.isNotEmpty()) {
                val pattern = artistWords.joinToString("[-_\\s]+") { Regex.escape(it) }
                value = value.replace(Regex("(?i)(?:^|[-_\\s]+)$pattern(?:$|[-_\\s]+)"), " ")
                    .replace(Regex("\\s+"), " ").trim()
            }
        }
        return value.ifBlank { fallback.ifBlank { "Sem título" } }
    }

    private fun normalize(value: String): String = Normalizer.normalize(
        value.trim().lowercase(Locale.ROOT), Normalizer.Form.NFD
    ).replace(Regex("\\p{M}+"), "")
}
