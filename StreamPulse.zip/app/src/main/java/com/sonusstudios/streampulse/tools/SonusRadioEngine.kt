package com.sonusstudios.streampulse.tools

import android.content.Context
import com.sonusstudios.streampulse.R
import java.util.Locale
import kotlin.math.absoluteValue
import kotlin.random.Random

internal data class SonusRadioStart(
    val queue: List<PulsePlayerQueueItem>,
    val index: Int,
    val startPositionMs: Long,
    val stationId: String,
    val stationTitle: String
)

/**
 * SONUS Radio Engine (code98).
 *
 * Esta classe SOMENTE monta a fila e calcula a posição virtual da estação.
 * O áudio continua sendo reproduzido pelo PulsePlayerService já estável.
 */
internal object SonusRadioEngine {
    private const val PREFS = "sonus_radio_clock_v1"
    private const val DEFAULT_TRACK_MS = 210_000L
    const val MAX_REWIND_MS = 600_000L

    /**
     * code103: cada locução declara explicitamente em quais rádios pode entrar.
     * allowedGenres vazio = locução realmente neutra/global.
     * A seleção é feita ANTES do sorteio para impedir vazamento de nicho entre estações.
     */
    private data class VoiceClip(
        val resId: Int,
        val title: String,
        val durationMs: Long,
        val allowedGenres: Set<String> = emptySet()
    )

    private val voices = listOf(
        // Neutras: podem ser usadas naturalmente em qualquer rádio.
        VoiceClip(R.raw.radio_01_sonus_radio_aumente_volume, "SONUS Rádio", 8664),
        VoiceClip(R.raw.radio_02_musica_continua_sonus_stream, "SONUS Stream", 7968),
        VoiceClip(R.raw.radio_03_mais_musica_menos_pausa, "SONUS Stream", 7704),
        VoiceClip(R.raw.radio_04_seu_som_seus_momentos, "SONUS", 6312),
        VoiceClip(R.raw.radio_05_fica_por_aqui, "SONUS Rádio", 8976),
        // Relato real do teste: uma fala de música internacional vazou para Piseiro.
        // Até uma futura troca de locução, esta fala fica estritamente restrita ao nicho internacional.
        VoiceClip(R.raw.radio_06_melhor_da_musica, "SONUS • Internacional", 7704, setOf("internacional", "international")),
        VoiceClip(R.raw.radio_07_volume_no_maximo, "SONUS Stream", 9576),
        VoiceClip(R.raw.radio_08_se_bateu_forte, "SONUS Rádio", 8232),
        VoiceClip(R.raw.radio_09_musica_nao_para, "SONUS", 7104),
        VoiceClip(R.raw.radio_10_mais_uma_na_sequencia, "SONUS Rádio", 9648),

        // Nichadas.
        VoiceClip(R.raw.radio_11_trap_gospel_aumente_volume, "SONUS • Trap Gospel", 10584, setOf("trap gospel", "gospel", "católica", "catolica")),
        VoiceClip(R.raw.radio_12_trap_gospel_fe_peso_mensagem, "SONUS • Trap Gospel", 8616, setOf("trap gospel", "gospel", "católica", "catolica")),
        VoiceClip(R.raw.radio_13_melhor_do_trap, "SONUS • Trap", 9048, setOf("trap")),
        VoiceClip(R.raw.radio_14_momento_de_piseiro, "SONUS • Piseiro", 7392, setOf("piseiro")),
        VoiceClip(R.raw.radio_15_romanticas_ate_o_fim, "SONUS • Romântico", 7584, setOf("romântico", "romantico", "acústico", "acustico")),

        // Multi-gênero: não entram no pool global.
        VoiceClip(R.raw.radio_16_se_bateu_saudade, "SONUS Rádio", 7848, setOf("piseiro", "brega", "arrocha", "sertanejo", "romântico", "romantico", "pagode")),
        VoiceClip(R.raw.radio_17_descobrir_musica_nova, "SONUS", 8976),
        VoiceClip(R.raw.radio_18_mais_som_coracaozinho, "SONUS", 11712, setOf("piseiro", "brega", "arrocha", "sertanejo", "romântico", "romantico", "pagode")),
        VoiceClip(R.raw.radio_19_sequencia_de_milhoes, "SONUS", 9384),
        VoiceClip(R.raw.radio_20_trilha_proxima_escolhida, "SONUS Rádio", 11712),
        VoiceClip(R.raw.radio_21_outra_historia_comeca, "SONUS", 8544),
        VoiceClip(R.raw.radio_22_a_proxima_esta_chegando, "SONUS", 8064),
        VoiceClip(R.raw.radio_23_fluxo_sonus_radio, "SONUS Rádio", 7704),
        VoiceClip(R.raw.radio_24_essa_pedrada, "SONUS", 11784, setOf("trap", "rap", "hip-hop", "hip hop", "baile funk", "funk", "piseiro")),
        VoiceClip(R.raw.radio_25_sequencia_continua, "SONUS Rádio", 7560)
    )

    fun prepare(
        context: Context,
        stationId: String,
        stationTitle: String,
        tracks: List<SonusOnlineTrack>,
        repository: SonusOnlineMusicRepository,
        boostedIds: Set<Long> = emptySet(),
        genreHint: String = ""
    ): SonusRadioStart? {
        if (tracks.isEmpty()) return null
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val savedStation = prefs.getString("station", null)
        val sameStation = savedStation == stationId && prefs.contains("seed") && prefs.contains("epoch")
        val seed = if (sameStation) prefs.getLong("seed", 0L) else (now xor stationId.hashCode().toLong() xor tracks.size.toLong())
        val random = Random(seed)

        val orderedTracks = smartShuffle(tracks, boostedIds, random)
        val eligibleVoices = voicesFor(genreHint)
        val lastVoiceUri = prefs.getString("last_voice_uri_$stationId", null)
        val voicePool = eligibleVoices.shuffled(random).toMutableList().apply {
            if (size > 1 && lastVoiceUri != null && "android.resource://${context.packageName}/${first().resId}" == lastVoiceUri) {
                add(removeAt(0))
            }
        }
        val queue = buildProgram(context, stationId, orderedTracks, repository, voicePool)
        if (queue.isEmpty()) return null

        val firstMusicDuration = queue.firstOrNull()?.durationMs?.takeIf { it > 10_000L } ?: DEFAULT_TRACK_MS
        val initialRandomPosition = ((firstMusicDuration * (5 + random.nextInt(76))) / 100L)
            .coerceIn(5_000L, (firstMusicDuration - 5_000L).coerceAtLeast(5_000L))
        val epoch = if (sameStation) prefs.getLong("epoch", now) else now - initialRandomPosition
        if (!sameStation) {
            prefs.edit().putString("station", stationId).putLong("seed", seed).putLong("epoch", epoch).apply()
        }

        val cycleMs = queue.sumOf { it.durationMs.takeIf { d -> d > 0L } ?: DEFAULT_TRACK_MS }.coerceAtLeast(1L)
        var offset = Math.floorMod(now - epoch, cycleMs)
        var index = 0
        var position = 0L
        for ((i, item) in queue.withIndex()) {
            val duration = item.durationMs.takeIf { it > 0L } ?: DEFAULT_TRACK_MS
            if (offset < duration) { index = i; position = offset; break }
            offset -= duration
        }
        return SonusRadioStart(queue, index, position, stationId, stationTitle)
    }


    /**
     * Calcula um ponto da programação virtual sem tocar no motor de áudio.
     * delayMs=0 representa AO VIVO; valores positivos voltam no máximo 10 minutos.
     */
    fun targetForDelay(context: Context, queue: List<PulsePlayerQueueItem>, delayMs: Long): Pair<Int, Long>? {
        if (queue.isEmpty()) return null
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!prefs.contains("epoch")) return null
        val epoch = prefs.getLong("epoch", System.currentTimeMillis())
        val cycleMs = queue.sumOf { it.durationMs.takeIf { d -> d > 0L } ?: DEFAULT_TRACK_MS }.coerceAtLeast(1L)
        val allowedDelay = delayMs.coerceIn(0L, minOf(MAX_REWIND_MS, (cycleMs - 1L).coerceAtLeast(0L)))
        var offset = Math.floorMod(System.currentTimeMillis() - epoch - allowedDelay, cycleMs)
        queue.forEachIndexed { index, item ->
            val duration = item.durationMs.takeIf { it > 0L } ?: DEFAULT_TRACK_MS
            if (offset < duration) return index to offset
            offset -= duration
        }
        return 0 to 0L
    }

    /** Quanto a reprodução atual está atrás do ponto virtual AO VIVO. */
    fun delayFromLive(context: Context, queue: List<PulsePlayerQueueItem>, index: Int, positionMs: Long): Long {
        if (queue.isEmpty() || index !in queue.indices) return 0L
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!prefs.contains("epoch")) return 0L
        val epoch = prefs.getLong("epoch", System.currentTimeMillis())
        val durations = queue.map { it.durationMs.takeIf { d -> d > 0L } ?: DEFAULT_TRACK_MS }
        val cycleMs = durations.sum().coerceAtLeast(1L)
        val liveOffset = Math.floorMod(System.currentTimeMillis() - epoch, cycleMs)
        val currentOffset = (durations.take(index).sum() + positionMs.coerceIn(0L, durations[index])).let { Math.floorMod(it, cycleMs) }
        val behind = Math.floorMod(liveOffset - currentOffset, cycleMs)
        return if (behind > MAX_REWIND_MS || behind > cycleMs / 2L) 0L else behind
    }

    fun rewindWindowMs(queue: List<PulsePlayerQueueItem>): Long {
        val cycleMs = queue.sumOf { it.durationMs.takeIf { d -> d > 0L } ?: DEFAULT_TRACK_MS }.coerceAtLeast(1L)
        return minOf(MAX_REWIND_MS, (cycleMs - 1L).coerceAtLeast(1L))
    }

    private fun smartShuffle(tracks: List<SonusOnlineTrack>, boostedIds: Set<Long>, random: Random): List<SonusOnlineTrack> {
        val unique = tracks.distinctBy { it.fileId }.shuffled(random).toMutableList()
        val boosted = unique.filter { it.fileId in boostedIds }.shuffled(random)
        unique.removeAll { it.fileId in boostedIds }
        val result = mutableListOf<SonusOnlineTrack>()
        // Impulsionada entra cedo, mas nunca cria reprodução falsa: é só prioridade de posição.
        boosted.firstOrNull()?.let { result += it }
        val pending = (unique + boosted.drop(1)).toMutableList()
        while (pending.isNotEmpty()) {
            val lastArtist = result.lastOrNull()?.artist?.trim()?.lowercase(Locale.ROOT)
            val idx = pending.indexOfFirst { it.artist.trim().lowercase(Locale.ROOT) != lastArtist }.takeIf { it >= 0 } ?: 0
            result += pending.removeAt(idx)
        }
        return result
    }

    private fun buildProgram(
        context: Context,
        stationId: String,
        tracks: List<SonusOnlineTrack>,
        repository: SonusOnlineMusicRepository,
        voices: List<VoiceClip>
    ): List<PulsePlayerQueueItem> {
        if (tracks.isEmpty()) return emptyList()
        val voiceDeck = if (voices.isNotEmpty()) voices else return tracks.map {
            repository.queueItem(it).copy(source = "SONUS Rádio", kind = PulseQueueKind.RADIO_MUSIC, radioStationId = stationId)
        }
        // Um deck inteiro = nenhuma locução se repete até todas as elegíveis tocarem.
        // Cada bloco contém exatamente duas músicas e uma locução. Catálogos pequenos
        // atravessam o ciclo normalmente sem eliminar a regra 2 -> 1.
        val out = mutableListOf<PulsePlayerQueueItem>()
        var trackIndex = 0
        voiceDeck.forEach { clip ->
            repeat(2) {
                val track = tracks[trackIndex % tracks.size]
                trackIndex++
                out += repository.queueItem(track).copy(
                    source = "SONUS Rádio",
                    kind = PulseQueueKind.RADIO_MUSIC,
                    radioStationId = stationId
                )
            }
            out += PulsePlayerQueueItem(
                uri = "android.resource://${context.packageName}/${clip.resId}",
                title = clip.title,
                artist = "SONUS",
                album = "SONUS Rádio",
                genre = "Locução",
                durationMs = clip.durationMs,
                source = "SONUS Rádio • Locução",
                kind = PulseQueueKind.RADIO_VOICE,
                radioStationId = stationId
            )
        }
        return out
    }

    fun recordVoicePlayed(context: Context, stationId: String?, uri: String) {
        if (stationId.isNullOrBlank() || uri.isBlank()) return
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString("last_voice_uri_$stationId", uri).apply()
    }

    private fun voicesFor(genre: String): List<VoiceClip> {
        val g = genre.trim().lowercase(Locale.ROOT)
        return voices.filter { clip ->
            clip.allowedGenres.isEmpty() || clip.allowedGenres.any { token -> g.contains(token) }
        }
    }
}
