package com.sonusstudios.streampulse.tools

import android.content.Context
import java.util.Locale
import kotlin.math.absoluteValue
import kotlin.random.Random

internal data class SonusRadioStart(
    val queue: List<PulsePlayerQueueItem>,
    val index: Int,
    val startPositionMs: Long,
    val stationId: String,
    val stationTitle: String
)

/**
 * SONUS Radio Engine (code98).
 *
 * Esta classe SOMENTE monta a fila e calcula a posição virtual da estação.
 * O áudio continua sendo reproduzido pelo PulsePlayerService já estável.
 */
internal object SonusRadioEngine {
    private const val PREFS = "sonus_radio_clock_v1"
    private const val DEFAULT_TRACK_MS = 210_000L
    const val MAX_REWIND_MS = 600_000L

    /**
     * 0.0.1: as locuções vêm da pasta pública do pCloud ([SonusRadioVoices]); nada de áudio de locução vai no app.
     * Nome do arquivo com um gênero (ex.: "trap_02.mp3") restringe a locução àquela rádio; sem gênero = neutra.
     */
    private const val TRACKS_PER_VOICE = 4

    fun prepare(
        context: Context,
        stationId: String,
        stationTitle: String,
        tracks: List<SonusOnlineTrack>,
        repository: SonusOnlineMusicRepository,
        boostedIds: Set<Long> = emptySet(),
        genreHint: String = ""
    ): SonusRadioStart? {
        if (tracks.isEmpty()) return null
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val savedStation = prefs.getString("station", null)
        val sameStation = savedStation == stationId && prefs.contains("seed") && prefs.contains("epoch")
        val seed = if (sameStation) prefs.getLong("seed", 0L) else (now xor stationId.hashCode().toLong() xor tracks.size.toLong())
        val random = Random(seed)

        val orderedTracks = smartShuffle(tracks, boostedIds, random)
        val eligibleVoices = voicesFor(context, genreHint)
        val lastVoiceUri = prefs.getString("last_voice_uri_$stationId", null)
        val voicePool = eligibleVoices.shuffled(random).toMutableList().apply {
            if (size > 1 && lastVoiceUri != null && first().uri == lastVoiceUri) {
                add(removeAt(0))
            }
        }
        val queue = buildProgram(stationId, orderedTracks, repository, voicePool)
        if (queue.isEmpty()) return null

        val firstMusicDuration = queue.firstOrNull()?.durationMs?.takeIf { it > 10_000L } ?: DEFAULT_TRACK_MS
        val initialRandomPosition = ((firstMusicDuration * (5 + random.nextInt(76))) / 100L)
            .coerceIn(5_000L, (firstMusicDuration - 5_000L).coerceAtLeast(5_000L))
        val epoch = if (sameStation) prefs.getLong("epoch", now) else now - initialRandomPosition
        if (!sameStation) {
            prefs.edit().putString("station", stationId).putLong("seed", seed).putLong("epoch", epoch).apply()
        }

        val cycleMs = queue.sumOf { it.durationMs.takeIf { d -> d > 0L } ?: DEFAULT_TRACK_MS }.coerceAtLeast(1L)
        var offset = Math.floorMod(now - epoch, cycleMs)
        var index = 0
        var position = 0L
        for ((i, item) in queue.withIndex()) {
            val duration = item.durationMs.takeIf { it > 0L } ?: DEFAULT_TRACK_MS
            if (offset < duration) { index = i; position = offset; break }
            offset -= duration
        }
        return SonusRadioStart(queue, index, position, stationId, stationTitle)
    }


    /**
     * Calcula um ponto da programação virtual sem tocar no motor de áudio.
     * delayMs=0 representa AO VIVO; valores positivos voltam no máximo 10 minutos.
     */
    fun targetForDelay(context: Context, queue: List<PulsePlayerQueueItem>, delayMs: Long): Pair<Int, Long>? {
        if (queue.isEmpty()) return null
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!prefs.contains("epoch")) return null
        val epoch = prefs.getLong("epoch", System.currentTimeMillis())
        val cycleMs = queue.sumOf { it.durationMs.takeIf { d -> d > 0L } ?: DEFAULT_TRACK_MS }.coerceAtLeast(1L)
        val allowedDelay = delayMs.coerceIn(0L, minOf(MAX_REWIND_MS, (cycleMs - 1L).coerceAtLeast(0L)))
        var offset = Math.floorMod(System.currentTimeMillis() - epoch - allowedDelay, cycleMs)
        queue.forEachIndexed { index, item ->
            val duration = item.durationMs.takeIf { it > 0L } ?: DEFAULT_TRACK_MS
            if (offset < duration) return index to offset
            offset -= duration
        }
        return 0 to 0L
    }

    /** Quanto a reprodução atual está atrás do ponto virtual AO VIVO. */
    fun delayFromLive(context: Context, queue: List<PulsePlayerQueueItem>, index: Int, positionMs: Long): Long {
        if (queue.isEmpty() || index !in queue.indices) return 0L
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!prefs.contains("epoch")) return 0L
        val epoch = prefs.getLong("epoch", System.currentTimeMillis())
        val durations = queue.map { it.durationMs.takeIf { d -> d > 0L } ?: DEFAULT_TRACK_MS }
        val cycleMs = durations.sum().coerceAtLeast(1L)
        val liveOffset = Math.floorMod(System.currentTimeMillis() - epoch, cycleMs)
        val currentOffset = (durations.take(index).sum() + positionMs.coerceIn(0L, durations[index])).let { Math.floorMod(it, cycleMs) }
        val behind = Math.floorMod(liveOffset - currentOffset, cycleMs)
        return if (behind > MAX_REWIND_MS || behind > cycleMs / 2L) 0L else behind
    }

    fun rewindWindowMs(queue: List<PulsePlayerQueueItem>): Long {
        val cycleMs = queue.sumOf { it.durationMs.takeIf { d -> d > 0L } ?: DEFAULT_TRACK_MS }.coerceAtLeast(1L)
        return minOf(MAX_REWIND_MS, (cycleMs - 1L).coerceAtLeast(1L))
    }

    private fun smartShuffle(tracks: List<SonusOnlineTrack>, boostedIds: Set<Long>, random: Random): List<SonusOnlineTrack> {
        val unique = tracks.distinctBy { it.fileId }.shuffled(random).toMutableList()
        val boosted = unique.filter { it.fileId in boostedIds }.shuffled(random)
        unique.removeAll { it.fileId in boostedIds }
        val result = mutableListOf<SonusOnlineTrack>()
        // Impulsionada entra cedo, mas nunca cria reprodução falsa: é só prioridade de posição.
        boosted.firstOrNull()?.let { result += it }
        val pending = (unique + boosted.drop(1)).toMutableList()
        while (pending.isNotEmpty()) {
            val lastArtist = result.lastOrNull()?.artist?.trim()?.lowercase(Locale.ROOT)
            val idx = pending.indexOfFirst { it.artist.trim().lowercase(Locale.ROOT) != lastArtist }.takeIf { it >= 0 } ?: 0
            result += pending.removeAt(idx)
        }
        return result
    }

    private fun buildProgram(
        stationId: String,
        tracks: List<SonusOnlineTrack>,
        repository: SonusOnlineMusicRepository,
        voices: List<SonusRadioVoice>
    ): List<PulsePlayerQueueItem> {
        if (tracks.isEmpty()) return emptyList()
        val voiceDeck = if (voices.isNotEmpty()) voices else return tracks.map {
            repository.queueItem(it).copy(source = "SONUS Rádio", kind = PulseQueueKind.RADIO_MUSIC, radioStationId = stationId)
        }
        // Um deck inteiro = nenhuma locução se repete até todas as elegíveis tocarem.
        // 0.0.1: cada bloco contém quatro músicas e uma locução (regra 4 -> 1). Catálogos pequenos
        // atravessam o ciclo normalmente.
        val out = mutableListOf<PulsePlayerQueueItem>()
        var trackIndex = 0
        voiceDeck.forEach { clip ->
            repeat(TRACKS_PER_VOICE) {
                val track = tracks[trackIndex % tracks.size]
                trackIndex++
                out += repository.queueItem(track).copy(
                    source = "SONUS Rádio",
                    kind = PulseQueueKind.RADIO_MUSIC,
                    radioStationId = stationId
                )
            }
            out += PulsePlayerQueueItem(
                uri = clip.uri,
                title = "SONUS Rádio",
                artist = "SONUS",
                album = "SONUS Rádio",
                genre = "Locução",
                durationMs = clip.durationMs,
                source = "SONUS Rádio • Locução",
                kind = PulseQueueKind.RADIO_VOICE,
                radioStationId = stationId
            )
        }
        return out
    }

    fun recordVoicePlayed(context: Context, stationId: String?, uri: String) {
        if (stationId.isNullOrBlank() || uri.isBlank()) return
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString("last_voice_uri_$stationId", uri).apply()
    }

    private fun voicesFor(context: Context, genre: String): List<SonusRadioVoice> {
        val cached = SonusRadioVoices.cached(context)
        // Primeira vez (ou cache vazio): busca na nuvem em segundo plano; esta rádio toca só música e as próximas já têm locução.
        SonusRadioVoices.refreshAsync(context, force = cached.isEmpty())
        val g = genre.trim().lowercase(Locale.ROOT)
        return cached.filter { clip -> clip.allowedGenres.isEmpty() || clip.allowedGenres.any { token -> g.contains(token) } }
    }
}
