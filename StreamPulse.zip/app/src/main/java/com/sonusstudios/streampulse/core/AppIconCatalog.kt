package com.sonusstudios.streampulse.core

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import androidx.annotation.DrawableRes
import com.sonusstudios.streampulse.R

data class AppIconSpec(
    val id: String,
    val title: String,
    val tier: MembershipTier,
    @DrawableRes val previewRes: Int,
    val aliasClassName: String
)

object AppIconCatalog {
    private const val PREFS = "pulse_studio_app_icon_v1"
    private const val KEY = "selected"

    val icons = listOf(
        AppIconSpec("classic_blue", "Clássico", MembershipTier.FREE, R.mipmap.ic_launcher_classic_blue, ".LauncherClassicBlue"),
        AppIconSpec("violet_neon", "Lilás", MembershipTier.FREE, R.mipmap.ic_launcher_violet_neon, ".LauncherVioletNeon"),
        AppIconSpec("white_minimal", "Branco", MembershipTier.FREE, R.mipmap.ic_launcher_white_minimal, ".LauncherWhiteMinimal"),
        AppIconSpec("crimson", "Vermelho", MembershipTier.FREE, R.mipmap.ic_launcher_crimson, ".LauncherCrimson"),
        AppIconSpec("neon_green", "Verde", MembershipTier.FREE, R.mipmap.ic_launcher_neon_green, ".LauncherNeonGreen"),
        AppIconSpec("ice", "Ice", MembershipTier.FREE, R.mipmap.ic_launcher_ice, ".LauncherIce"),
        AppIconSpec("magenta", "Magenta", MembershipTier.FREE, R.mipmap.ic_launcher_magenta, ".LauncherMagenta"),
        AppIconSpec("amber", "Âmbar", MembershipTier.FREE, R.mipmap.ic_launcher_amber, ".LauncherAmber"),
        AppIconSpec("sunset", "Amarelo", MembershipTier.FREE, R.mipmap.ic_launcher_sunset, ".LauncherSunset"),
        AppIconSpec("bronze_copper", "Cobre", MembershipTier.FREE, R.mipmap.ic_launcher_bronze_copper, ".LauncherBronzeCopper"),
        AppIconSpec("silver", "Cinza", MembershipTier.PRATA, R.mipmap.ic_launcher_silver, ".LauncherSilver"),
        AppIconSpec("carbon", "Marrom", MembershipTier.PRATA, R.mipmap.ic_launcher_carbon, ".LauncherCarbon"),
        AppIconSpec("cosmic", "Arco-íris", MembershipTier.PRATA, R.mipmap.ic_launcher_cosmic, ".LauncherCosmic"),
        AppIconSpec("emerald", "Esmeralda", MembershipTier.PRATA, R.mipmap.ic_launcher_emerald, ".LauncherEmerald"),
        AppIconSpec("gold", "Dourado", MembershipTier.OURO, R.mipmap.ic_launcher_gold, ".LauncherGold"),
        AppIconSpec("electric_blue", "3D azul", MembershipTier.OURO, R.mipmap.ic_launcher_electric_blue, ".LauncherElectricBlue"),
        AppIconSpec("cyan", "Ciano", MembershipTier.OURO, R.mipmap.ic_launcher_cyan, ".LauncherCyan"),
        AppIconSpec("rose", "Rosa", MembershipTier.OURO, R.mipmap.ic_launcher_rose, ".LauncherRose"),
        AppIconSpec("teal_pulse", "Matrix", MembershipTier.OURO, R.mipmap.ic_launcher_teal_pulse, ".LauncherTealPulse"),
        AppIconSpec("diamond_ice", "Azul oceano", MembershipTier.DIAMANTE, R.mipmap.ic_launcher_diamond_ice, ".LauncherDiamondIce"),
        AppIconSpec("pulse_signature", "Diamante", MembershipTier.DIAMANTE, R.mipmap.ic_launcher_pulse_signature, ".LauncherPulseSignature"),
        AppIconSpec("royal_purple", "Neon", MembershipTier.DIAMANTE, R.mipmap.ic_launcher_royal_purple, ".LauncherRoyalPurple"),
        AppIconSpec("aurora", "Aurora", MembershipTier.DIAMANTE, R.mipmap.ic_launcher_aurora, ".LauncherAurora"),
        AppIconSpec("galaxy", "Galáxia", MembershipTier.DIAMANTE, R.mipmap.ic_launcher_galaxy, ".LauncherGalaxy"),
        AppIconSpec("black_premium", "Floresta", MembershipTier.DIAMANTE, R.mipmap.ic_launcher_black_premium, ".LauncherBlackPremium"),
        AppIconSpec("sunset2", "Sunset", MembershipTier.DIAMANTE, R.mipmap.ic_launcher_sunset2, ".LauncherSunset2"),
        AppIconSpec("violet_liquid", "Neon violeta", MembershipTier.DIAMANTE, R.mipmap.ic_launcher_violet_liquid, ".LauncherVioletLiquid"),
        AppIconSpec("liquid_neon", "Liquid Neon", MembershipTier.DIAMANTE, R.mipmap.ic_launcher_liquid_neon, ".LauncherLiquidNeon"),
    )

    fun splashColors(id: String): Pair<androidx.compose.ui.graphics.Color, androidx.compose.ui.graphics.Color> {
        val spec = when(id) {
            "classic_blue" -> 0xFF14A0FFL to 0xFF46DCFFL
            "violet_neon" -> 0xFFAA5AFFL to 0xFFE6AAFFL
            "white_minimal" -> 0xFFEBEBF0L to 0xFFFFFFFFL
            "crimson" -> 0xFFFF3746L to 0xFFFF7878L
            "neon_green" -> 0xFF28DC78L to 0xFF64FFAAL
            "ice" -> 0xFF82DCFFL to 0xFFE6FAFFL
            "magenta" -> 0xFFFF2DB4L to 0xFFFF82D2L
            "amber" -> 0xFFFF9114L to 0xFFFFD25AL
            "sunset" -> 0xFFFFCD1EL to 0xFFFFF582L
            "bronze_copper" -> 0xFFBE6937L to 0xFFF5AF64L
            "silver" -> 0xFF96A0AFL to 0xFFE1E6EBL
            "carbon" -> 0xFF7D4E37L to 0xFFCD915FL
            "cosmic" -> 0xFFFF5096L to 0xFF46DCFFL
            "emerald" -> 0xFF14BE7DL to 0xFF64FFC3L
            "gold" -> 0xFFE1A519L to 0xFFFFEB6EL
            "electric_blue" -> 0xFF1450DCL to 0xFF50D2FFL
            "cyan" -> 0xFF00DCF0L to 0xFF64FFFFL
            "rose" -> 0xFFFF55A0L to 0xFFFFB4D7L
            "teal_pulse" -> 0xFF00FF50L to 0xFF5AFF82L
            "diamond_ice" -> 0xFF005AD2L to 0xFF00E6FFL
            "pulse_signature" -> 0xFFAAEBFFL to 0xFFFFFFFFL
            "royal_purple" -> 0xFFAA1EFFL to 0xFF28DCFFL
            "aurora" -> 0xFF32FFB4L to 0xFFB450FFL
            "galaxy" -> 0xFF643CFFL to 0xFFFF50D2L
            "black_premium" -> 0xFF147846L to 0xFF50E68CL
            "sunset2" -> 0xFFFF5050L to 0xFFFFBE32L
            "violet_liquid" -> 0xFF781EFFL to 0xFFF550FFL
            "liquid_neon" -> 0xFF00F0FFL to 0xFFFF28DCL
            else -> 0xFF149FFF to 0xFF46DCFF
        }
        return androidx.compose.ui.graphics.Color(spec.first) to androidx.compose.ui.graphics.Color(spec.second)
    }

    fun selectedId(context: Context): String = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getString(KEY, "classic_blue") ?: "classic_blue"

    fun apply(context: Context, spec: AppIconSpec): Result<Unit> = runCatching {
        val pm = context.packageManager
        icons.forEach { item ->
            val state = if (item.id == spec.id) PackageManager.COMPONENT_ENABLED_STATE_ENABLED
            else PackageManager.COMPONENT_ENABLED_STATE_DISABLED
            pm.setComponentEnabledSetting(
                ComponentName(context.packageName, context.packageName + item.aliasClassName),
                state,
                PackageManager.DONT_KILL_APP
            )
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, spec.id).apply()
    }
}
