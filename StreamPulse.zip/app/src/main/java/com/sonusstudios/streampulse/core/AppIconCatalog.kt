package com.sonusstudios.streampulse.core

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import androidx.annotation.DrawableRes
import com.sonusstudios.streampulse.R

data class AppIconSpec(
    val id: String,
    val title: String,
    val tier: MembershipTier,
    @DrawableRes val previewRes: Int,
    val aliasClassName: String
)

object AppIconCatalog {
    private const val PREFS = "pulse_studio_app_icon_v1"
    private const val KEY = "selected"

    val icons = listOf(
        // FREE: oito cores sobre o mesmo fundo navy.
        AppIconSpec("rose", "Rosa", MembershipTier.FREE, R.drawable.icon_preview_rose, ".LauncherRose"),
        AppIconSpec("neon_green", "Verde", MembershipTier.FREE, R.drawable.icon_preview_neon_green, ".LauncherNeonGreen"),
        AppIconSpec("amber", "Laranja", MembershipTier.FREE, R.drawable.icon_preview_amber, ".LauncherAmber"),
        AppIconSpec("cyan", "Ciano", MembershipTier.FREE, R.drawable.icon_preview_cyan, ".LauncherCyan"),
        AppIconSpec("crimson", "Vermelho", MembershipTier.FREE, R.drawable.icon_preview_crimson, ".LauncherCrimson"),
        AppIconSpec("white_minimal", "Branco", MembershipTier.FREE, R.drawable.icon_preview_white_minimal, ".LauncherWhiteMinimal"),
        AppIconSpec("sunset", "Amarelo", MembershipTier.FREE, R.drawable.icon_preview_sunset, ".LauncherSunset"),
        AppIconSpec("silver", "Cinza", MembershipTier.FREE, R.drawable.icon_preview_silver, ".LauncherSilver"),
        // PRATA: quatro gradientes, sem alterar o fundo.
        AppIconSpec("ice", "Prata Aurora", MembershipTier.PRATA, R.drawable.icon_preview_ice, ".LauncherIce"),
        AppIconSpec("carbon", "Prata Grafite", MembershipTier.PRATA, R.drawable.icon_preview_carbon, ".LauncherCarbon"),
        AppIconSpec("cosmic", "Prata Cristal", MembershipTier.PRATA, R.drawable.icon_preview_cosmic, ".LauncherCosmic"),
        AppIconSpec("magenta", "Prata Violeta", MembershipTier.PRATA, R.drawable.icon_preview_magenta, ".LauncherMagenta"),
        // OURO: cinco acabamentos premium.
        AppIconSpec("gold", "Dourado", MembershipTier.OURO, R.drawable.icon_preview_gold, ".LauncherGold"),
        AppIconSpec("electric_blue", "Prata", MembershipTier.OURO, R.drawable.icon_preview_electric_blue, ".LauncherElectricBlue"),
        AppIconSpec("emerald", "Esmeralda", MembershipTier.OURO, R.drawable.icon_preview_emerald, ".LauncherEmerald"),
        AppIconSpec("bronze_copper", "Bronze", MembershipTier.OURO, R.drawable.icon_preview_bronze_copper, ".LauncherBronzeCopper"),
        AppIconSpec("teal_pulse", "Verde Matrix", MembershipTier.OURO, R.drawable.icon_preview_teal_pulse, ".LauncherTealPulse"),
        // DIAMANTE: nove artes exclusivas.
        AppIconSpec("diamond_ice", "Azul oceano", MembershipTier.DIAMANTE, R.drawable.icon_preview_diamond_ice, ".LauncherDiamondIce"),
        AppIconSpec("pulse_signature", "Diamante", MembershipTier.DIAMANTE, R.drawable.icon_preview_pulse_signature, ".LauncherPulseSignature"),
        AppIconSpec("aurora", "Aurora", MembershipTier.DIAMANTE, R.drawable.icon_preview_aurora, ".LauncherAurora"),
        AppIconSpec("royal_purple", "Neon", MembershipTier.DIAMANTE, R.drawable.icon_preview_royal_purple, ".LauncherRoyalPurple"),
        AppIconSpec("galaxy", "Galáxia", MembershipTier.DIAMANTE, R.drawable.icon_preview_galaxy, ".LauncherGalaxy"),
        AppIconSpec("black_premium", "Floresta", MembershipTier.DIAMANTE, R.drawable.icon_preview_black_premium, ".LauncherBlackPremium"),
        AppIconSpec("sunset2", "Sunset", MembershipTier.DIAMANTE, R.drawable.icon_preview_sunset2, ".LauncherSunset2"),
        AppIconSpec("violet_liquid", "Neon violeta", MembershipTier.DIAMANTE, R.drawable.icon_preview_violet_liquid, ".LauncherVioletLiquid"),
        AppIconSpec("liquid_neon", "Glass", MembershipTier.DIAMANTE, R.drawable.icon_preview_liquid_neon, ".LauncherLiquidNeon")
    )

    fun splashColors(id: String): Pair<androidx.compose.ui.graphics.Color, androidx.compose.ui.graphics.Color> {
        val spec = when(id) {
            "classic_blue" -> 0xFF14A0FFL to 0xFF46DCFFL
            "violet_neon" -> 0xFFAA5AFFL to 0xFFE6AAFFL
            "white_minimal" -> 0xFFEBEBF0L to 0xFFFFFFFFL
            "crimson" -> 0xFFFF3746L to 0xFFFF7878L
            "neon_green" -> 0xFF28DC78L to 0xFF64FFAAL
            "ice" -> 0xFF82DCFFL to 0xFFE6FAFFL
            "magenta" -> 0xFFFF2DB4L to 0xFFFF82D2L
            "amber" -> 0xFFFF9114L to 0xFFFFD25AL
            "sunset" -> 0xFFFFCD1EL to 0xFFFFF582L
            "bronze_copper" -> 0xFFBE6937L to 0xFFF5AF64L
            "silver", "electric_blue", "carbon", "cosmic" -> 0xFF96A0AFL to 0xFFE1E6EBL
            "emerald" -> 0xFF14BE7DL to 0xFF64FFC3L
            "gold" -> 0xFFE1A519L to 0xFFFFEB6EL
            "cyan" -> 0xFF00DCF0L to 0xFF64FFFFL
            "rose" -> 0xFFFF55A0L to 0xFFFFB4D7L
            "teal_pulse" -> 0xFF00FF50L to 0xFF5AFF82L
            "diamond_ice" -> 0xFF005AD2L to 0xFF00E6FFL
            "pulse_signature" -> 0xFFAAEBFFL to 0xFFFFFFFFL
            "royal_purple" -> 0xFFAA1EFFL to 0xFF28DCFFL
            "aurora" -> 0xFF32FFB4L to 0xFFB450FFL
            "galaxy" -> 0xFF643CFFL to 0xFFFF50D2L
            "black_premium" -> 0xFF147846L to 0xFF50E68CL
            "sunset2" -> 0xFFFF5050L to 0xFFFFBE32L
            "violet_liquid" -> 0xFF781EFFL to 0xFFF550FFL
            "liquid_neon" -> 0xFF00F0FFL to 0xFFFF28DCL
            else -> 0xFF149FFF to 0xFF46DCFF
        }
        return androidx.compose.ui.graphics.Color(spec.first) to androidx.compose.ui.graphics.Color(spec.second)
    }

    fun selectedId(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val stored = prefs.getString(KEY, null)
        if (stored != null && icons.any { it.id == stored }) return stored
        // Instalações antigas podem manter um ícone removido (Clássico/Lilás).
        // Migra para a marca rosa e desativa os aliases antigos sem apagar dados.
        val fallback = icons.first { it.id == "rose" }
        runCatching { apply(context, fallback) }
        return fallback.id
    }

    fun apply(context: Context, spec: AppIconSpec): Result<Unit> = runCatching {
        val pm = context.packageManager
        icons.forEach { item ->
            val state = if (item.id == spec.id) PackageManager.COMPONENT_ENABLED_STATE_ENABLED
            else PackageManager.COMPONENT_ENABLED_STATE_DISABLED
            pm.setComponentEnabledSetting(
                ComponentName(context.packageName, context.packageName + item.aliasClassName),
                state,
                PackageManager.DONT_KILL_APP
            )
        }
        listOf(".LauncherClassicBlue", ".LauncherVioletNeon").forEach { legacyAlias ->
            pm.setComponentEnabledSetting(
                ComponentName(context.packageName, context.packageName + legacyAlias),
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP
            )
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, spec.id).apply()
    }
}
