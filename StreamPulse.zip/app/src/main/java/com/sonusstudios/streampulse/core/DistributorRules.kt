package com.sonusstudios.streampulse.core

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth

data class DistributorFinancialProfile(
    val entryMode: String,
    val dataDelayDays: Int,
    val expectedPayoutDay: Int?
)

object DistributorRules {
    private val fixedRuleDistributors = setOf(
        DistributorId.SOUNDON,
        DistributorId.FRESHTUNES,
        DistributorId.ROUTENOTE,
        DistributorId.LANDR,
        DistributorId.SYMPHONIC
    )

    fun displayName(distributor: DistributorId, customName: String? = null): String = when (distributor) {
        DistributorId.SOUNDON -> "SoundOn"
        DistributorId.DITTO -> "Ditto Music"
        DistributorId.DISTROKID -> "DistroKid"
        DistributorId.TUNECORE -> "TuneCore"
        DistributorId.FRESHTUNES -> "FreshTunes"
        DistributorId.ROUTENOTE -> "RouteNote"
        DistributorId.CDBABY -> "CD Baby"
        DistributorId.ONERPM -> "ONErpm"
        DistributorId.UNITEDMASTERS -> "UnitedMasters"
        DistributorId.AMUSE -> "Amuse"
        DistributorId.LANDR -> "LANDR"
        DistributorId.SYMPHONIC -> "Symphonic"
        DistributorId.TOOLOST -> "Too Lost"
        DistributorId.OTHER -> customName?.takeIf { it.isNotBlank() } ?: "Outra"
    }

    fun needsManualPayoutDate(distributor: DistributorId): Boolean = distributor !in fixedRuleDistributors

    fun financialProfile(distributor: DistributorId): DistributorFinancialProfile = when (distributor) {
        DistributorId.SOUNDON -> DistributorFinancialProfile("TOTAL", 2, 25)
        // Existing cycle dates remain the default expectation, but only SoundOn has a
        // documented built-in reporting delay in the migration checklist. Other delays
        // are user-adjustable in the stream-entry screen and must not be invented here.
        DistributorId.FRESHTUNES -> DistributorFinancialProfile("TOTAL", 0, 20)
        DistributorId.ROUTENOTE -> DistributorFinancialProfile("TOTAL", 0, 20)
        DistributorId.LANDR -> DistributorFinancialProfile("TOTAL", 0, 7)
        DistributorId.SYMPHONIC -> DistributorFinancialProfile("TOTAL", 0, 5)
        else -> DistributorFinancialProfile("TOTAL", 0, null)
    }

    fun financialProfile(artist: Artist): DistributorFinancialProfile {
        val base = financialProfile(artist.distributor)
        return base.copy(
            expectedPayoutDay = artist.financialExpectedPayoutDayOverride?.coerceIn(1, 31) ?: base.expectedPayoutDay
        )
    }

    /**
     * Active data window. After a real payment, the financial cycle starts on the payment date,
     * while delayed distributor data continues from the first date that was not consumed yet.
     */
    fun cycleFor(artist: Artist, today: LocalDate = LocalDate.now()): CycleWindow {
        val financialStart = artist.financialCycleStartIso?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
        val dataStart = artist.nextUnconsumedDataDateIso?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
        // The active financial cycle becomes authoritative from the earliest of:
        // - the real payment date (financial boundary), or
        // - the first delayed data day that was intentionally carried into the new cycle.
        // This also covers zero-delay distributors: right after a payment, dataStart can be
        // tomorrow, but today's financial balance must already be zero instead of falling back
        // to the old standard cycle.
        val activeBoundary = listOfNotNull(financialStart, dataStart).minOrNull()
        if (financialStart != null && dataStart != null && activeBoundary != null && !today.isBefore(activeBoundary)) {
            val expectedEnd = nextExpectedPayoutDate(artist, financialStart)
            val safeEnd = if (expectedEnd.isBefore(dataStart)) dataStart.plusMonths(1).minusDays(1) else expectedEnd
            val distributorName = displayName(artist.distributor, artist.customDistributorName)
            return CycleWindow(
                dataStart.toString(),
                safeEnd.toString(),
                "Novo ciclo financeiro iniciado em ${financialStart}. Dados deste ciclo a partir de ${dataStart}. $distributorName mantém a data esperada separada da data real do pagamento.",
                true
            )
        }
        return standardCycleFor(artist, today)
    }

    /** Window based only on distributor rules, ignoring a payment-closed active cursor. */
    fun standardCycleFor(artist: Artist, today: LocalDate = LocalDate.now()): CycleWindow {
        return when (artist.distributor) {
            DistributorId.SOUNDON -> fixedStartDay(
                today = today,
                startDay = 26,
                description = "Referência SoundOn: consulte os streams do dia 26 até a data atual. O fechamento mensal de referência ocorre por volta do dia 25."
            )

            DistributorId.FRESHTUNES -> fixedStartDay(
                today = today,
                startDay = 21,
                description = "Referência FreshTunes: a janela mensal de crédito costuma ficar entre os dias 15 e 20; por isso a nova consulta começa no dia 21.",
                estimated = true
            )

            DistributorId.ROUTENOTE -> fixedStartDay(
                today = today,
                startDay = 21,
                description = "Referência RouteNote: após a janela mensal de pagamento de 15 a 20, a nova consulta começa no dia 21.",
                estimated = true
            )

            DistributorId.LANDR -> fixedStartDay(
                today = today,
                startDay = 8,
                description = "Referência LANDR: como a renda costuma ficar disponível na primeira semana, a nova consulta começa no dia 8.",
                estimated = true
            )

            DistributorId.SYMPHONIC -> fixedStartDay(
                today = today,
                startDay = 6,
                description = "Referência Symphonic: como relatório e saldo costumam ser postados entre os dias 1 e 5, a nova consulta começa no dia 6.",
                estimated = true
            )

            DistributorId.DITTO,
            DistributorId.DISTROKID,
            DistributorId.TUNECORE,
            DistributorId.CDBABY,
            DistributorId.ONERPM,
            DistributorId.UNITEDMASTERS,
            DistributorId.AMUSE,
            DistributorId.TOOLOST,
            DistributorId.OTHER -> manualCycle(artist, today)
        }
    }

    fun expectedPayoutDateForCurrentCycle(artist: Artist, today: LocalDate = LocalDate.now()): LocalDate {
        val stored = artist.nextExpectedPayoutDateIso?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
        if (stored != null && !stored.isBefore(today.minusDays(45))) return stored
        val profile = financialProfile(artist)
        return profile.expectedPayoutDay?.let { day ->
            val ym = YearMonth.from(today)
            val candidate = ym.atDay(day.coerceAtMost(ym.lengthOfMonth()))
            if (!candidate.isBefore(today)) candidate else ym.plusMonths(1).atDay(day.coerceAtMost(ym.plusMonths(1).lengthOfMonth()))
        } ?: LocalDate.parse(standardCycleFor(artist, today).endIso)
    }

    /** Expected date of the *next* cycle after a payment that happened on [paymentDate]. */
    fun nextExpectedPayoutDate(artist: Artist, paymentDate: LocalDate): LocalDate {
        val profile = financialProfile(artist)
        profile.expectedPayoutDay?.let { day ->
            val next = YearMonth.from(paymentDate).plusMonths(1)
            return next.atDay(day.coerceAtMost(next.lengthOfMonth()))
        }
        artist.customCycleStartDay?.coerceIn(1, 28)?.let { day ->
            val next = YearMonth.from(paymentDate).plusMonths(1)
            return next.atDay(day.coerceAtMost(next.lengthOfMonth())).minusDays(1)
        }
        return paymentDate.plusMonths(1)
    }

    private fun fixedStartDay(
        today: LocalDate,
        startDay: Int,
        description: String,
        estimated: Boolean = false
    ): CycleWindow {
        val safeStartDay = startDay.coerceAtMost(today.lengthOfMonth())
        val thisMonthStart = LocalDate.of(today.year, today.month, safeStartDay)
        val start = if (!today.isBefore(thisMonthStart)) thisMonthStart else {
            val previous = YearMonth.from(today).minusMonths(1)
            previous.atDay(startDay.coerceAtMost(previous.lengthOfMonth()))
        }
        val nextMonth = YearMonth.from(start).plusMonths(1)
        val nextStart = nextMonth.atDay(startDay.coerceAtMost(nextMonth.lengthOfMonth()))
        val end = nextStart.minusDays(1)
        return CycleWindow(start.toString(), end.toString(), description, estimated)
    }

    private fun manualCycle(artist: Artist, today: LocalDate): CycleWindow {
        val parsedPayout = artist.lastPayoutDateIso?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
        // Para orientar o ciclo atual, uma referência com mais de 12 meses (ou no futuro)
        // quase sempre indica erro de digitação. Não deixamos uma data antiga contaminar
        // saúde, previsão e período recomendado.
        val payout = parsedPayout?.takeIf { !it.isAfter(today) && !it.isBefore(today.minusDays(366)) }
        val staleReference = parsedPayout != null && payout == null
        val customDay = artist.customCycleStartDay?.coerceIn(1, 28)
        val start = when {
            payout != null -> payout.plusDays(1)
            customDay != null -> {
                val current = YearMonth.from(today).atDay(customDay)
                if (!today.isBefore(current)) current else current.minusMonths(1)
            }
            else -> today.withDayOfMonth(1)
        }

        val end = when {
            customDay != null -> start.plusMonths(1).minusDays(1)
            payout != null && artist.distributor == DistributorId.CDBABY -> nextWeekStartAfter(payout).minusDays(1)
            payout != null && artist.distributor == DistributorId.DISTROKID -> nextDistroKidProcessingDay(payout).minusDays(1)
            payout != null -> start.plusMonths(1).minusDays(1)
            else -> YearMonth.from(today).atEndOfMonth()
        }.let { if (it.isBefore(start)) start else it }

        val distributorName = displayName(artist.distributor, artist.customDistributorName)
        val description = if (staleReference) {
            "⚠️ A última referência informada parece antiga ou futura. Por segurança, o SONUS está usando o início deste mês. Atualize a data em Ajustes."
        } else {
            "$distributorName não tem uma janela mensal fixa confiável para este cálculo. Use o dia seguinte ao último crédito/pagamento informado até hoje como período recomendado."
        }

        return CycleWindow(
            start.toString(),
            end.toString(),
            description,
            true
        )
    }

    private fun nextWeekStartAfter(date: LocalDate): LocalDate {
        var cursor = date.plusDays(1)
        while (cursor.dayOfWeek != DayOfWeek.MONDAY) cursor = cursor.plusDays(1)
        return cursor
    }

    private fun nextDistroKidProcessingDay(date: LocalDate): LocalDate {
        var cursor = date.plusDays(1)
        while (cursor.dayOfWeek != DayOfWeek.TUESDAY && cursor.dayOfWeek != DayOfWeek.THURSDAY) {
            cursor = cursor.plusDays(1)
        }
        return cursor
    }
}
