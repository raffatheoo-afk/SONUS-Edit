package com.sonusstudios.streampulse.core

/**
 * Contrato preparado para Google Play Billing.
 * Nenhuma compra real é disparada pelo code86; os IDs ficam centralizados para a etapa
 * de cadastro dos produtos no Play Console e futura validação de entitlement.
 */
object SonusBillingCatalog {
    const val OURO_MONTHLY = "sonus_ouro_monthly"
    const val OURO_ANNUAL = "sonus_ouro_annual"
    const val DIAMANTE_MONTHLY = "sonus_diamante_monthly"
    const val DIAMANTE_ANNUAL = "sonus_diamante_annual"
}

enum class BillingEntitlementStatus {
    INACTIVE,
    ACTIVE,
    CANCELED,
    EXPIRED,
    GRACE_PERIOD,
    PENDING
}

data class BillingEntitlement(
    val tier: MembershipTier = MembershipTier.FREE,
    val productId: String? = null,
    val status: BillingEntitlementStatus = BillingEntitlementStatus.INACTIVE,
    val expiresAtEpochMillis: Long? = null,
    val autoRenewing: Boolean = false
)
