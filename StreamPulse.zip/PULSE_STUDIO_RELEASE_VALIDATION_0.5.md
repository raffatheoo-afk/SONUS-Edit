# Pulse Studio — Validação 0.5 (27)

## Base
- Base funcional de partida: **StreamPulse v1.9.5-beta code26**, confirmada pelo usuário após GitHub Actions.
- Nova marca pública: **Pulse Studio**.
- `applicationId`: `com.sonusstudios.streampulse` (preservado).
- `versionName`: `0.5`.
- `versionCode`: `27`.

## Validação estática realizada
- 36 arquivos Kotlin: scanner estrutural sem desequilíbrios.
- 36 arquivos Kotlin: parser PSI Kotlin sem erros sintáticos.
- 4 arquivos XML: parse válido.
- 6 arquivos JSON: parse válido.
- Nenhum literal público inesperado `StreamPulse`; a string antiga permanece apenas na compatibilidade de importação de backups e em identificadores técnicos internos.
- Logo mestre oficial: **4096×4096**; launcher adaptado às densidades Android.
- `google-services.json`: byte a byte idêntico à base code26.
- Varredura de código/documentação: nenhuma chave YouTube literal, Owner UID/e-mail privilegiado ou private key nova encontrada.
- Configuração de assinatura permanece idêntica à base code26.

## Assinatura
SHA-256 do `beta-debug.keystore`:

`8022cbfa0df8120aba76d113054670604854323e0433de9ba29f27da8f1b7aa6`

O hash é idêntico ao keystore da base code26 confirmada.

## Firebase
As regras não foram alteradas. Os três arquivos ativos de Rules têm SHA-256:

`b8488cbc50743d30a2a760a7f99760e2dabd20786b1e1770ba4c85cc8ef13328`

Esse é o mesmo hash das regras v1.9.4 já publicadas. **Não é necessário republicar Firebase Rules para a 0.5.**

## Mudanças sensíveis validadas
- Conversor de Áudio funciona sem artista/distribuidora em **Modo livre**; recomendações específicas só aparecem quando existe perfil de distribuição.
- Backups Pulse Studio continuam aceitando backups antigos identificados como StreamPulse.
- Benefícios Premium/Owner não são restaurados de backup como autoridade.
- Passe Pulse 24h é um entitlement por função e não promove a conta para outro plano.
- Pulse Player Service valida acesso ao PulseLift/PulseOrbit para que a notificação não contorne bloqueios.
- YouTube continua usando player oficial incorporado, sem extração de áudio ou reprodução oculta.

## Limite desta validação
Este ambiente não possui Android SDK/classpath completo para confirmar um build Android real. Portanto o pacote é considerado **validado estaticamente e empacotado**, mas o APK **só deve ser considerado compilado quando o GitHub Actions concluir com sucesso**.
