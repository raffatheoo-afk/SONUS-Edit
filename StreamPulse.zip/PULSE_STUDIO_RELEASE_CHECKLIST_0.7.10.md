# PULSE STUDIO 0.7.10 — code 42

Pacote de estabilização autorizado em 26/08/2026.

## Implementado neste pacote
- Exportação: dimensões calculadas pelo canvas/proporção; presets 360p–4K tratados como lado curto; dimensões pares para encoder.
- Validação: rotação 90/270 normalizada antes de comparar largura/altura, evitando falso erro 9:16 vs 16:9.
- Containers: MP4 direto; MOV/MKV/3GP por empacotamento; WEBM/AVI tentam conversão e falham claramente se o pacote FFmpeg do aparelho não suportar.
- Timeline: camada de texto passa a ser selecionável individualmente; toque fora desmarca sem ripple cinza da área vazia.
- Painéis: removido scroll vertical do inspector principal; cabeçalho fixo com X, confirmação individual e duplo check para aplicar a todos quando aplicável.
- Áudio: Arquivos/Extrair/Volume/Fade In/Fade Out/Split/Delete na navegação horizontal; um parâmetro por vez.
- Texto: fontes/cores/animações só aparecem ao tocar na categoria; nada fica expandido por padrão.
- Ajustes: sliders compactados e navegação horizontal preservada.
- Overlay: Escala/Rotação/Opacidade em subpainéis horizontais, um slider por vez.
- Visualizer: categorias Modelo/Áudio/Aparência/Centro/Partículas; eliminado painel vertical longo.
- Pulse Transcribe / Legendas: removido bloqueio explícito Android 13; Android 13+ usa contrato oficial e Android anterior tenta modo compatível do serviço de reconhecimento instalado.
- Pulse Player: removido bloqueio visual de geração de letra somente em API 33+.

## Validação ainda necessária no aparelho/GitHub Actions
- Compilação Kotlin/Android pelo GitHub Actions.
- Exportação 9:16 em 1080p/2K/4K e demais proporções.
- Containers alternativos conforme codecs/muxers presentes no dispositivo.
- Transcrição de arquivo em Android 11/12 depende do serviço de voz instalado; confirmar em aparelhos reais.
