# StreamPulse — Roadmap

## 1.0 local — em construção
- [x] Identidade e applicationId.
- [x] Cadastro de artistas e distribuidoras.
- [x] Ciclos de referência.
- [x] Estimativa de royalties.
- [x] Previsão de fechamento.
- [x] Saúde do Projeto.
- [x] Histórico.
- [x] Pagamento real e aprendizado do RPM.
- [x] Persistência local.
- [x] Suporte a múltiplos artistas.
- [ ] Compilar no Android Studio e testar em aparelho real.
- [ ] Corrigir qualquer problema visual encontrado no teste real.

## 1.0 pública
- [ ] Firebase Authentication / Google Sign-In.
- [ ] Firestore e sincronização/restauração.
- [ ] Regras de segurança do Firestore.
- [ ] App Check / Play Integrity.
- [ ] Política de privacidade.
- [ ] Chave de assinatura de produção e backup seguro.
- [ ] Testes de atualização 1.0 -> 1.1 preservando dados.
- [ ] AAB para Google Play.

## 1.1+
- [ ] Gráficos avançados.
- [ ] Edição/exclusão individual de registros.
- [ ] Importação CSV/XLSX de relatórios.
- [ ] Notificações de atualização/fechamento.
- [ ] Exportação de relatórios.
- [ ] Integrações oficiais quando disponíveis.


## 1.2 Beta
- Meta financeira e progresso visual.
- Dashboard orgânico colorido por estado.
- Foto local do artista.
- Saúde diária corrigida e proteção contra referências de data inválidas.
- Atividade recente com variação percentual.
