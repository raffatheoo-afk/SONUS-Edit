# Checklist interno — SONUS 0.0.8 / CODE08

## Escopo aprovado
- [x] Alterar somente LIVE (exibição da letra), abertura dos gêneros do Stream, lista de músicas no painel e identificação da versão.
- [x] Preservar cartões de gênero, gradientes, ícones, favoritos e ordenação da tela Stream.
- [x] Preservar a LIVE fora da área de letra.
- [x] Manter Rádio e Linha do Tempo fora do novo fluxo de popup.
- [x] Não tentar corrigir a classificação de faixas por metadados nesta versão.

## LIVE — auditoria e implementação
- [x] Confirmado no vídeo enviado: a seleção do Stream/Arrocha inicia a transmissão, mas a tela “No ar” não exibe letra.
- [x] Identificada a lacuna: `LiveNowPlaying` mostrava título/artista sem buscar ou renderizar a letra.
- [x] Consultar `lyricsForFileIdAuto` usando o `fileId` retirado de `SonusOnlineRef` da faixa atual.
- [x] Priorizar a letra já cadastrada no catálogo/overrides; manter as fontes existentes de comunidade e LRCLIB como fallback.
- [x] Resolver a letra fora da thread principal e com tempo limite.
- [x] Reutilizar `sonusLrcLineAt` do Player para a sincronização LRC, em vez de criar um parser divergente.
- [x] Mostrar a linha atual no bloco de identificação da música em retrato e paisagem.
- [ ] Teste no aparelho: iniciar LIVE com gênero Arrocha e confirmar a primeira linha, avanço de linhas e troca de faixa.
- [ ] Teste no aparelho: confirmar que uma faixa sem letra não interrompe a LIVE nem causa travamento.

## Stream — popup de gênero
- [x] Cartão de gênero abre um painel próprio em vez de deixar a lista escondida no fim da página.
- [x] Fundo da tela recebe blur enquanto o painel está aberto.
- [x] Botão de fechar vermelho posicionado no canto inferior direito.
- [x] Fechar remove o painel e o blur.
- [x] Abertura por resultado de busca de gênero também inicializa a lista no primeiro lote.
- [ ] Teste em aparelho pequeno: conferir altura, rolagem, botões superiores e botão inferior com uma mão.
- [ ] Teste de acessibilidade: confirmar que o botão Fechar está acessível e que o Back do Android fecha o painel.

## Stream — lista e reprodução
- [x] Remover botões de playlist, compartilhar e denunciar das linhas da lista.
- [x] Manter coração de favorito e play individual.
- [x] Dar destaque visual ao play.
- [x] Adicionar “Tocar tudo” no topo do painel.
- [x] Adicionar “Aleatório” no topo do painel.
- [x] Play individual inicia a fila do gênero na faixa selecionada.
- [x] Cursor de cache JSON por popup, mantendo posição de leitura entre páginas para não reprocessar as faixas anteriores.
- [x] Leitura paginada do cache JSON do gênero: mantém no máximo 20 faixas no lote solicitado, mais uma faixa de antecipação.
- [x] Prefetch do próximo lote quando a rolagem se aproxima das últimas 8 faixas visíveis/carregadas.
- [x] Não cria `JSONArray` nem desserializa todas as faixas do gênero ao abrir o painel.
- [x] A busca do cache e a desserialização rodam em `Dispatchers.IO`; o trabalho da lista/arte é incremental.
- [x] Ações que exigem fila completa (Tocar tudo, Aleatório e play individual com sequência) carregam todos os metadados daquele gênero sob demanda, em lotes de 100, fora da thread principal.
- [x] Resolver letra da LIVE por `fileId` lê apenas a faixa atual do cache, evitando materializar todo o catálogo em cada troca.
- [ ] Testar gênero com mais de 100 faixas e rolar até o fim, verificando lotes contínuos sem saltos ou itens duplicados.
- [ ] Testar “Tocar tudo”, “Aleatório” e play individual, inclusive a sequência após a faixa selecionada.
- [ ] Testar favoritar/desfavoritar dentro do painel e confirmar persistência ao reabrir.
- [ ] Monitorar ANR/“app parou de responder” em aparelho real e observar uso de memória.

## Preservação e integridade
- [x] Não alterar Rádio, Linha do Tempo, LiveMediaStage, fluxo de locução, regras de estações automáticas ou limites de mais de 15 faixas únicas.
- [x] Não alterar a lista oficial de gêneros nem as regras de metadados.
- [x] `AudioToolEngine.kt` mantido no hash protegido aprovado.
- [x] `PulsePlayerService.kt` mantido no hash protegido aprovado.
- [x] `SonusStreamPlatform.kt` mantido no hash protegido aprovado.
- [x] `applicationId` preservado.
- [x] `versionName=0.0.8` e `versionCode=8`.
- [x] `codemagic.yaml` declara e valida CODE08.
- [ ] Compilação Android no Codemagic.
- [ ] Instalação e teste funcional do APK gerado.

## Observação técnica sobre paginação e desempenho
Quando o snapshot completo já foi carregado por outra área do Stream na sessão atual, o painel reaproveita esse snapshot e só expõe 20 itens por vez. Sem snapshot completo, abre um cursor no cache local das fontes publicadas para percorrer sequencialmente os registros JSON do gênero selecionado. O cursor mantém a posição entre as páginas, sem reiniciar a varredura de cada fonte, e mantém 20 faixas no lote, mais uma faixa de antecipação para descobrir se há próxima página. Ao chegar perto das últimas 8 faixas carregadas, consulta mais 20. O valor JSON completo ainda é obtido do SharedPreferences como uma `String` por fonte; portanto, esta implementação evita `JSONArray`/listas completas e limita os objetos retidos no painel, mas não é streaming remoto direto do pCloud nem elimina a leitura da string persistida. A reprodução completa carrega sob demanda os metadados do gênero em páginas de 100; o áudio continua sendo resolvido somente para tocar, sem pré-carregamento de faixas de áudio.

## Correção do primeiro log de compilação CODE08
- [x] Import `Surface` do Material 3 em `SonusLiveStudio.kt`.
- [x] Import `TextAlign` em `SonusOnlineMusic.kt`.
- [x] Import `CircleShape` em `SonusOnlineMusic.kt`.
- [x] Import da extensão `Modifier.border` em `SonusOnlineMusic.kt`.
- [ ] Executar novamente `assembleDebug` no Codemagic e verificar se surgem novos erros além dos apontados no log anterior.
- [ ] Instalar e testar LIVE, popup de gênero, paginação e ações de reprodução no aparelho.
