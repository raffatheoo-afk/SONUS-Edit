# SONUS 0.8.20 • code65 • hotfix 1

Correções de compilação apontadas pelo GitHub Actions:

- `MainActivity.kt`: `SettingsToggleRow` da Central de Notificações agora informa explicitamente `onCheckedChange`, evitando que a lambda seja interpretada como o parâmetro `enabled`.
- `ToolSuiteScreen.kt`: `ToolHub` passa a usar corretamente seu parâmetro local `coins` nas cinco referências de saldo; removidas referências inválidas a `pulseCoins` nesse escopo.
- `versionName` permanece `0.8.20` e `versionCode` permanece `65`, conforme política de hotfix.

Validação local realizada: integridade do pacote, referências corrigidas e checagens estáticas. A compilação Android final deve ser confirmada pelo GitHub Actions.
