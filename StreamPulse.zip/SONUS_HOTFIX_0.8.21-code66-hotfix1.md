# SONUS v0.8.21 code66 — hotfix 1

Correção de compilação identificada pelo GitHub Actions em `PulsePlayerService.kt`.

- Corrigido tipo anulável `Long?` enviado a `Media3SpectrumEngine.sync`, que exige `Long`.
- Mantidos `versionName 0.8.21` e `versionCode 66`.
- Nenhuma outra função do pacote code66 foi removida ou redesenhada neste hotfix.
