# SONUS 0.8.16 • code61

- Distribuição: cabeçalho compacto, seletor recolhível de artista e abas sem rolagem horizontal.
- Comunidade removida da interface comum; permanece apenas na administração.
- Pulso ao Vivo compacto, sem textos explicativos; estado [calibrando] discreto.
- Ações Atualizar dados e Recebi pagamento movidas para logo abaixo do Pulso.
- Cards de saldo/meta e Financeiro compactados; calibração financeira simplificada.
- SONUS BOOST removido da interface e desativado no pipeline de reprodução/conversão.
- Mantidas as correções e recursos da 0.8.15/code60 (MP3→MP3, conversor/redimensionador de imagens e registro flexível de streams).
