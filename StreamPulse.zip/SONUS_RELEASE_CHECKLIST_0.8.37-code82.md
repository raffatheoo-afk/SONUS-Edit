# SONUS 0.8.37 — code82

## Release
- versionName 0.8.37
- versionCode 82
- Java 17 / Gradle 8.13
- APK esperado: SONUS-v0.8.37-code82.apk

## Implementado
- Sonus Music concluído no código e integrado ao Player de Música.
- Diagnóstico Sonus Music no Painel Desenvolvedor.
- Metadados de áudio ampliado com capas e letras.
- Conversor de Áudio com capa/letras/metadados ampliados.
- Tags em Lote para áudio, com edição em massa completa.
- Sobre o SONUS reduzido às novidades da versão atual.
- Destaques preservados, exceto Tags em Lote conforme aprovado.

## Codemagic
O ZIP de compilação deve conter somente:
1. codemagic.yaml
2. StreamPulse-CodeMagic-code82.zip

Para ativar Sonus Music no APK, o ambiente Codemagic precisa:
- DROPBOX_APP_KEY
- DROPBOX_APP_SECRET

## Hotfix
Falhas deste build permanecem v0.8.37/code82.
