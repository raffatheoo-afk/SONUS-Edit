# StreamPulse — Checklist de entrega v1.9.5-beta (26)

## Identidade
- [x] Base: v1.9.4-beta (25) oficial.
- [x] applicationId preservado: `com.sonusstudios.streampulse`.
- [x] versionName: `1.9.5-beta`.
- [x] versionCode: `26`.
- [x] Keystore beta preservado.
- [x] Nenhuma credencial Owner/API administrativa adicionada ao código.

## Ferramentas
- [x] Pulse Player em primeiro destaque.
- [x] Karaokê em segundo destaque, sem reescrita de seu núcleo estável.
- [x] Conversor de Áudio em terceiro destaque.
- [x] Vídeo → Áudio.
- [x] Mesclar Áudio.
- [x] Alterar Tom.
- [x] Removedor Vocal local (DSP) + denoise + PulseLift opcional.
- [x] Cards secundários compactos.
- [x] Operações concluídas relevantes integradas ao Histórico 360°.

## Pulse Player
- [x] Pasta raiz persistente e varredura automática.
- [x] Reprodução em segundo plano + MediaSession/notificação.
- [x] Músicas, pastas, álbuns, artistas, gêneros, playlists, curtidas, fixadas, recentes, top, Smart Mix.
- [x] Fila editável/reordenável.
- [x] Busca universal da biblioteca.
- [x] Reprodução encadeada sem lacuna quando compatível, crossfade, shuffle/repeat e sleep timer.
- [x] Letras locais `.lrc`.
- [x] Creator Mode.
- [x] Estatísticas internas locais de reprodução.
- [x] EQ com presets + Graves/Médios/Agudos + 10 bandas.
- [x] PulseLift™.
- [x] PulseOrbit™ 3D/8D + presets próprios ligados à interface.
- [x] 38 temas: 8 Free, 5 Plus, 10 Studio, 15 Max.
- [x] Fundo neon/visualizador em Compose; nenhum asset visual novo necessário.

## Temas gerais
- [x] +3 Free.
- [x] +3 Plus.
- [x] +3 Studio.
- [x] +5 Max.

## Firebase e segurança
- [x] Regras Firebase não alteradas em relação à v1.9.4.
- [x] Hash das regras conferido com a base oficial.
- [x] Não é necessária republicação das Rules para esta atualização.

## Limitações declaradas
- Removedor Vocal v1.9.5 usa DSP estéreo/centro; não é anunciado como separação neural perfeita.
- PulseOrbit v1.9.5 não se apresenta como HRTF universal/personalizado nem como tecnologia de terceiros.
- Compatibilidade de formatos depende dos codecs/filtros presentes no FFmpeg embarcado e do Android.

## Validação de entrega
- [x] `StreamPulse-GitHub.zip` criado.
- [x] Backup versionado `StreamPulse-GitHub-v1.9.5-beta-code26.zip` criado.
- [x] Estrutura raiz dos dois ZIPs = `StreamPulse/`.
- [x] `unzip -t` aprovado nos dois ZIPs.
- [x] SHA-256 dos ZIPs calculado na entrega final.

## Build
Não marcar como compilado até o GitHub Actions confirmar a build.
