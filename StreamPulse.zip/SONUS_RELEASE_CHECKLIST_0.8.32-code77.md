# SONUS v0.8.32 — code77

Pacote consolidado da fase de reorganização do SONUS.

## Incluído
- Splash: correção do clipping lateral do nome Sonus, preservando símbolo e animação aprovada.
- Equalizador: curvas visualmente mais expressivas, com animação suave, sem alterar os valores reais de EQ.
- Estatísticas: Smart Mix local incorporado como coleções inteligentes; cards modernos, gráfico diário, SONUS Insight, rankings separados, origens e limpeza em vermelho.
- Player de música: atalho de Estatísticas e nova entrada Nuvem.
- Nuvem: Drive, OneDrive, Dropbox, pCloud e MEGA via provedores de documentos do Android, acesso persistente quando concedido, favoritos, recentes e pasta favorita.
- Studio SONUS descontinuado como aba principal.
- DESTAQUES SONUS: nova grade compacta, nomes resumidos, ferramentas essenciais migradas e bloco REDES.
- Vídeo Player: nova aba principal com vídeo local, nuvem, YouTube incorporado, Karaokê, favoritos, histórico, continuar assistindo, velocidade, legendas, proporção, gestos, tela cheia e PiP.
- Continuar assistindo: posição salva para vídeo local/nuvem e timestamp para YouTube.
- Navegação principal: Música, Vídeo, Destaques e Ajustes, preservando recursos opcionais fixados pelos Ajustes.

## Versão
- versionCode: 77
- versionName: 0.8.32
