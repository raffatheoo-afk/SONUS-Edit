# RELEASE STATUS — SONUS 1.0 / CODE10

## Estado desta entrega
**Candidato de código-fonte CODE10 preparado; build Android ainda não validado.**

- Versão: `1.0`
- Código: `10`
- Pacote de origem: `StreamPulse.zip`
- Workflow: `sonus-code10-only-20261125`
- Identificador Android: `com.sonusstudios.streampulse`

## Validações executadas neste ambiente
- `codemagic.yaml` parseado com PyYAML.
- Todos os blocos shell do workflow passaram por `bash -n`.
- SHA-256 do JKS embutido no YAML confere com o hash permanente registrado no projeto.
- Arquivos protegidos `AudioToolEngine.kt` e `SonusStreamPlatform.kt` permanecem idênticos à base CODE09.
- `PulsePlayerService.kt` possui hash fixado no workflow CODE10.
- Catálogo contém 43 presets públicos e quatro curvas internas de compatibilidade/migração, todos com 10 bandas e sem curvas duplicadas.
- Arquivos de referência visual não foram adicionados ao código/APK.
- ZIP final precisa passar pelo teste de integridade e pelo script de validação do próprio workflow antes do envio ao Codemagic.

## Validações não executadas
- `:app:assembleDebug` não foi executado: este ambiente não possui Gradle instalado, Gradle Wrapper ou Android SDK configurado.
- Não foi gerado APK nesta sessão.
- Não foram executados testes instrumentados nem testes em aparelho Android.
- Não foi possível confirmar instalação CODE10 por cima da CODE09.
- A senha do keystore não foi fornecida ao ambiente; o Codemagic deve validar a abertura do JKS e o certificado usando o Secret `SONUS_KEYSTORE_PASSWORD` do grupo `sonus_signing`.
- O modelo YAMNet será baixado pelo Gradle durante a preparação do build e validado por SHA-256; essa etapa ainda depende de rede no Codemagic.

## Próximos passos obrigatórios no Codemagic
1. Manter o repositório GitHub privado.
2. Confirmar o grupo `sonus_signing` na nova conta.
3. Configurar `SONUS_KEYSTORE_PASSWORD` como Secret; `SONUS_KEY_PASSWORD` somente se diferente; `SONUS_KEY_ALIAS=sonusedit`.
4. Substituir no repositório os arquivos `StreamPulse.zip` e `codemagic.yaml` pelos entregues juntos.
5. Executar `sonus-code10-only-20261125`.
6. Conferir no log a versão 1.0 / code 10, download do YAMNet, compilação e fingerprint oficial do APK.
7. Instalar o APK por cima da CODE09 sem desinstalar; testar player, EQ, ferramentas de exportação, permissões de microfone e os perfis Auto Volume.

## Limitações funcionais que exigem teste real
- O volume extra está limitado a +12 dB na interface. O resultado audível e a distorção variam por dispositivo, saída e efeito de áudio; não há garantia de SPL acima da capacidade física do hardware.
- Os modos ambientais dependem do classificador YAMNet e do microfone disponível. Um microfone único não determina com precisão direção/distância de veículos; Pedestre/Rua e Bicicleta são auxiliares de consciência ambiental, não garantias de segurança.
- O EQ Auto gera uma curva a partir de gênero/metadados e análise espectral local; a qualidade percebida deve ser avaliada com faixas de teste e comparação em loudness equivalente.
- As interfaces visuais do player e a tela compacta do equalizador precisam de validação visual em telas pequenas e grandes. O equalizador mantém uma única estrutura; CORES altera apenas a paleta.

**Não considerar esta entrega uma release compilada ou aprovada para distribuição até o build Codemagic e os testes em aparelho serem concluídos.**

## Correção após o primeiro build Codemagic (25/11/2026)
- O log recebido apontou falha de compilação do script Kotlin DSL em `app/build.gradle.kts` nas referências `java.security` e `java.net`, antes da compilação dos fontes Kotlin do aplicativo.
- Corrigido com imports explícitos de `MessageDigest`, `URL`, `URLConnection` e `InputStream`, além de tipagem explícita do fluxo e dos bytes SHA-256.
- O aviso de depreciação de `kotlinOptions.jvmTarget` não foi a causa da falha; permaneceu como aviso não fatal.
- O arquivo `StreamPulse.zip` foi atualizado com o script corrigido. O `codemagic.yaml` não precisou de alteração funcional porque o erro estava dentro do projeto Gradle compactado; a cópia externa e a cópia incluída no ZIP permanecem sincronizadas.
- É necessário executar novamente o workflow `sonus-code10-only-20261125` para confirmar se a configuração Gradle passa e revelar eventuais erros posteriores de compilação Kotlin/Android. Essa nova compilação ainda não foi executada nesta sessão.


## Manutenção corretiva R1 — 25/11/2026
**Escopo:** corrigir somente o layout do Player e a apresentação do Equalizador; manter a versão 1.0 / `versionCode` 10.

### Alterações realizadas
- Player: faixa de letras no slot central do cabeçalho (42 dp, até duas linhas); nenhuma faixa de letras sobre a área da capa/controles.
- Player: removido o recuo superior interno de 50 dp; o player volta a preencher sua área, como na estrutura base CODE09.
- Player: ações inferiores Biblioteca e Equalizador preservadas; botão circular Download continua entre EDIT LITE e LIVE.
- Equalizador: removido seletor TEMAS e bloco decorativo; CORES permanece.
- Equalizador: Bass Boost e Liga/Desliga lado a lado; card grande removido.
- Equalizador: curva reduzida a 66 dp sem remover o gráfico, bandas ou rótulos; duplicidade do título AJUSTE FINO removida.
- Presets, EQ Auto, Grave/Médio/Agudo e Volume Extra preservados no código.

### Verificações locais
- `versionName`/`versionCode` permanecem 1.0/10.
- `applicationId` permanece `com.sonusstudios.streampulse`.
- `codemagic.yaml` não recebeu mudança funcional; workflow, assinatura permanente e verificação do certificado foram preservados.
- Foi feita inspeção estática dos trechos alterados e verificação de referências antigas de TEMAS/layout do equalizador e overlay de letras.
- Não foi possível executar `assembleDebug` neste ambiente: não há Gradle, Gradle Wrapper nem Android SDK disponíveis. O build final precisa ser executado no Codemagic.

### Atenção para o teste no aparelho
1. Confirmar a faixa de letras centrada no espaço do antigo título e limitada a duas linhas.
2. Confirmar que o player conserva dimensões/controles da referência original.
3. Confirmar Biblioteca e Equalizador na fileira inferior e Download no botão circular entre EDIT LITE e LIVE.
4. Abrir Equalizador: conferir ausência de TEMAS/card grande, Bass Boost e Liga/Desliga lado a lado, curva funcional e CORES disponível.
5. Testar o toque na curva, presets, EQ Auto, ajustes finos e Volume Extra.

**Status:** pacote-fonte candidato à manutenção R1; compilação Android e teste visual em dispositivo ainda pendentes. Não distribuir como build confirmado antes da validação Codemagic.


## Manutenção corretiva R2 — 26/11/2026
**Causa do bloqueio:** o passo `Preparar e validar SONUS 1.0` ainda exigia a string `SONUS ONDA AZUL` dentro da tela do equalizador. Essa exigência pertencia ao desenho anterior com dez layouts, mas ficou obsoleta após a manutenção R1, quando o usuário decidiu remover o seletor TEMAS do equalizador e manter somente CORES. O código da tela estava alinhado ao pedido; o validador do YAML não estava.

### Correção realizada
- Removida a exigência obsoleta de nomes de layouts do equalizador.
- Substituída por verificações coerentes com o layout compacto: presença de `CURVA EQ`, `CORES`, `BASS BOOST` e `LIGA / DESLIGA`; rejeita o retorno do seletor antigo TEMAS e do card grande `Equalizador SONUS`.
- Atualizada a mensagem de validação da paleta CORES para se referir ao layout compacto.
- Atualizados comentários internos da tela para não sugerirem que ainda existem layouts alternativos no equalizador.
- `codemagic.yaml` externo e cópia incluída no `StreamPulse.zip` permanecem idênticos.

### Teste executado
- Executado localmente o script completo da etapa `Preparar e validar SONUS 1.0` extraído do `codemagic.yaml`, usando o `StreamPulse.zip` corrigido: **passou até `Validação estática 1.0 concluída.`**
- O teste confirmou versionName `1.0`, versionCode `10`, applicationId `com.sonusstudios.streampulse`, catálogo de 43 presets públicos e validação Firebase.
- Teste de integridade do ZIP: aprovado.
- YAML parseado com sucesso.
- Os scripts do workflow serão verificados com `bash -n` antes da entrega.

### Ainda pendente
- O teste acima valida a etapa estática; não executa `assembleDebug`. A compilação Android completa continua a cargo do Codemagic.
- Não alterar versão, versionCode, senha ou keystore.
