# SONUS 0.0.7 / CODE07 — estado da entrega

**Identidade Android:** `com.sonusstudios.streampulse`  
**Versão:** `versionName = 0.0.7` • `versionCode = 7`  
**Base:** pacote corrigido `StreamPulse 0.0.6 / CODE06`.

## Implementado no código-fonte
- Stream Home leve, com 18 cartões de gêneros oficiais, ilustrações vetoriais por ícone, gradientes próprios e favoritos persistentes.
- Ordenação de gêneros favoritos primeiro e demais categorias em ordem alfabética.
- Identificadores internos das três bibliotecas pCloud mantidos somente como fontes técnicas e rótulos amigáveis no painel OWNER.
- Projeção das músicas em categorias oficiais usando gênero de metadados/subpasta e fallback pelo catálogo local de artistas.
- Índice local `recent_tracks_index` com até 80 músicas para acelerar “Adicionadas recentemente”.
- Preferências de atualização (abertura, 30 min, 1/2/3/6/12/24 h e Manual), sem remover o botão de atualização manual.
- Preservação dos dados já exibidos durante a sincronização.
- Rádio com os 18 gêneros oficiais sempre disponíveis como opções leves; consulta de catálogo e preparação somente após a escolha da estação.
- Estações automáticas por gênero passam a validar pelo menos 16 faixas únicas depois do toque; a regra não reduz a lista de gêneros da LIVE.
- LIVE alinhada à lista oficial, sem alterações no fluxo de palco.
- “Sobre o SONUS” atualizado com as novidades da CODE07.

## Integridade da base
Os três arquivos protegidos permanecem idênticos à CODE06:
- `AudioToolEngine.kt` — `6e787082a16a6f040abd61f72dc8fe0d7bfa3e1bac184fc1c2b4c5a96cf0eedd`
- `PulsePlayerService.kt` — `a8e1af905eeb57c91bdcd32cf7558f0f6c08b6b5b9f8052e57c026df78298c1f`
- `SonusStreamPlatform.kt` — `69288d3b8fd3b147295861e0aca640b0e355785e30714872e38a8ccaa0ba7179`

## Observação técnica do catálogo
As fontes públicas pCloud são consultadas como árvores de metadados das bibliotecas; o endpoint utilizado não oferece uma consulta paginada por gênero nesta implementação. Por isso, na primeira interação que exige faixas, o app pode ler os metadados das três fontes e então projetá-los nos 18 gêneros virtuais. Isso não resolve URL de áudio nem baixa conteúdo de música. As URLs de reprodução continuam sendo solicitadas no caminho de reprodução. Faixas sem gênero reconhecível e sem correspondência no catálogo de artistas são omitidas dos cartões de gênero em vez de aparecerem sob um gênero inventado ou sob o nome da pasta interna.

## Validações
- Versão e `applicationId` conferidos no Gradle.
- Hashes dos três arquivos protegidos conferidos contra a base CODE06.
- YAML do Codemagic e scripts shell embutidos validados estaticamente.
- JSONs do projeto verificados.
- Integridade do ZIP verificada com `unzip -t`.

**Build Android:** não executado neste ambiente. O projeto não inclui Gradle Wrapper e este ambiente não possui Gradle nem Android SDK instalados. Portanto, a CODE07 é entregue como pacote-fonte e workflow Codemagic preparado; a compilação/assinatura do APK deve ser confirmada na execução do Codemagic com o grupo seguro de assinatura existente.

**Status:** pacote-fonte CODE07 preparado; build remoto e testes em aparelho pendentes.
