# SONUS 0.0.4 — CODE 04

## Novidades para quem usa o SONUS

- O player mantém o acesso ao download de músicas de forma discreta.
- As ferramentas ficam organizadas em Imagens, Áudio, Vídeos e Outros.
- O Stream reúne três coleções de músicas, com identificação separada das fontes.
- A Rádio passa a criar estações de gêneros que tenham pelo menos 16 músicas disponíveis.
- A conversão de vídeo para áudio apresenta o andamento informado pelo processamento.
- O conversor de vídeo permite rolar a tela quando o equalizador aumenta o conteúdo.
- O monitor de áudio atualiza os dispositivos conectados e permite alcançar os controles de iniciar e parar.
- A LIVE horizontal usa fundo desfocado da própria imagem e preserva a imagem principal inteira.
- A LIVE usa cinco estilos de transição e uma apresentação alternativa quando a música não possui letra.
- As chamadas de interação permanecem na tela por sete segundos antes de alternar.
- Slides curtos alternam entre SONUS e SONUS EDIT na LIVE e nas locuções da Rádio.
- O pedido de Premium abre uma conversa individual com plano, código da solicitação e ID da conta quando disponível.
- O compartilhamento foi direcionado para uma página HTTPS do SONUS.

## Observações de compatibilidade

- O retorno de áudio exige fone compatível; Bluetooth pode acrescentar latência.
- O comportamento de volume Bluetooth precisa ser confirmado em aparelhos reais. O player deixou de aplicar redução automática de ganho em eventos `CAN_DUCK` e registra eventos de foco de áudio para diagnóstico.
- A página de compartilhamento e a função HTTPS precisam ser publicadas no Firebase Hosting/Functions. O Codemagic faz essa publicação quando `FIREBASE_SERVICE_ACCOUNT_JSON_B64` estiver configurada como variável segura.
- A divulgação no TikTok deve respeitar as regras da plataforma; os efeitos visuais não são destinados a disfarçar conteúdo pré-gravado.

## Manutenção corretiva adicional — LIVE, Stream e edição em lote

- A seleção de gêneros da LIVE deixou de exigir mais de 15 faixas; agora apresenta todos os gêneros não vazios disponíveis nas pastas publicadas, incluindo arrocha, brega e estilos novos.
- A seleção da LIVE compara o nome das pastas publicadas sem diferenciar maiúsculas/minúsculas e atualiza o catálogo periodicamente para reconhecer novas músicas e gêneros.
- A preparação da fila de Rádio/Stream/arquivos locais foi movida para tarefas fora da thread principal; contagem regressiva da LIVE reduzida de cinco para três segundos.
- As chamadas de interação da LIVE passaram a alternar a cada sete segundos, sem a pausa longa anterior.
- O painel sem letra foi refinado para exibir identificação da música e convite de interação, em vez de ficar apenas com uma mensagem genérica.
- O carregamento de imagens da LIVE foi otimizado com decodificação menor (até 1440 px), transições mais curtas e fundo desfocado menos pesado. A busca de mídia possui limite de espera por item e reserva segura de imagens não religiosas para gêneros seculares quando não há arquivo específico do subgênero.
- Novo tópico OWNER: **Edição de música em lote**. Permite escolher uma das pastas, pesquisar/marcar várias faixas e aplicar gênero, artista, álbum e ano em uma única operação.
- A edição em lote reutiliza artistas já cadastrados, faz comparação sem diferenciar maiúsculas/minúsculas ou acentos e preserva metadados não editados, incluindo letras TXT/LRC, formato da letra e capas.
- Gravação em lote usa atualização multi-localização do catálogo público e do registro administrativo.
- Versão mantida em `0.0.4`, `versionCode = 4`.
