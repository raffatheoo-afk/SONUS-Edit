# SONUS v0.8.33 — code78

## Alterações deste pacote

- Splash: correção do recorte lateral do nome cursivo `Sonus`, sem alterar símbolo ou identidade aprovada.
- Navegação principal: Música → Destaques → Vídeo → Ajustes, preservando abas opcionais configuráveis.
- DESTAQUES SONUS: grade em duas colunas, cards glass/degradê, 20% mais compactos que o visual clássico e ilustrações próprias desenhadas no app.
- Destaques enxugados para as funções aprovadas: Conversor Áudio, Mesclar Áudio, Gravador de Voz, Afinador, AutoMix, Imagem Convert, Tags em Lote, Metadados, Verificar Capa, Vídeo → Áudio, Mesclar Vídeo, Cortador Pro e REDES.
- Removidos dos Destaques: BPM & Tom, Stem Splitter, Voice Cleaner, Normalizador, Detector Clipping e SONUS LAB.
- SONUS VIDEO: consulta automática da galeria via MediaStore, thumbnails, duração e retomada do ponto salvo.
- Continuar assistindo: no máximo 3 cards compactos lado a lado; seção Recentes geral removida da Home.
- Fullscreen de vídeo: navegação do app ocultada, orientação paisagem apenas durante tela cheia, botão explícito de saída e retorno ao retrato.

## Preservação

- Nuvem, Estatísticas, Equalizador e demais recursos já entregues no code77 foram preservados sem reimplementação.
- versionCode: 78
- versionName: 0.8.33
