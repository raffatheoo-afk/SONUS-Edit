# SONUS Stream 0.0.6 / CODE06 — status técnico do pacote-fonte

## Identidade

- `versionName`: `0.0.6`
- `versionCode`: `6`
- `applicationId`: `com.sonusstudios.streampulse`
- Base-fonte: `StreamPulse` 0.0.5 / CODE05.

## Alterações integradas

### LIVE

1. O botão de início não aguarda mais cinco imagens. A condição considera tempo de uso e a disponibilidade da fonte de áudio.
2. A configuração prepara só uma primeira cena, com timeout de 14 segundos.
3. Caso a mídia não esteja pronta, o palco apresenta o cenário oficial SONUS e continua tentando preparar cenas em segundo plano, mantendo até cinco cenas na fila de reposição.
4. A troca de cena mantém a imagem atual enquanto a próxima não foi preparada.
5. Contagem regressiva 10/15/20/30, verificação de reprodução efetiva antes de `ON_AIR`, áudio, microfone, controles, transições e duração original dos vídeos foram preservados.
6. A atualização recorrente do catálogo no Studio foi retirada.

### SONUS Stream

1. Home organizada: Linha do Tempo, SONUS Rádio, Acesso rápido e Gêneros.
2. Barra superior mantém Enviar música, Analytics, Busca e Ajustes, com novo desenho visual.
3. Busca expandida abaixo da barra, consultando localmente músicas, artistas, playlists e gêneros depois da digitação.
4. Acesso rápido prioriza Adicionadas recentemente; em seguida Artistas, Playlists, Últimas tocadas e Favoritas.
5. Gêneros usam cards gráficos e carregam seu conteúdo ao serem abertos.
6. Removidas da Home as prateleiras antigas de recomendação/descoberta e a prateleira promocional PULSE. O Pulse Player e as ferramentas de áudio estão preservados.
7. Catálogo e capas deixam de ser pré-carregados no `Application.onCreate`; reconstrução do snapshot não dispara leitura completa em segundo plano.
8. As locuções da Rádio são atualizadas quando a estação é preparada no motor da Rádio, não no boot do app.
9. Atualização do catálogo fica em Manual por padrão; opções de intervalo são verificadas somente quando o usuário solicita conteúdo do catálogo.
10. Ajustes oferecem política de dados móveis e aviso de uso; limpeza de cache remove capas em disco e em memória sem excluir biblioteca do usuário.
11. A seção Playlists inclui Álbuns do catálogo, agrupados por álbum e artista, com ação de baixar/remover o álbum inteiro para uso offline.

## Integridade e preservação

- `AudioToolEngine.kt`, `PulsePlayerService.kt` e `SonusStreamPlatform.kt` mantidos byte a byte, conforme SHA-256 protegido pela base de CODE05.
- `applicationId` mantido.
- Arquivos Firebase, regras, serviços e fluxo de submissão da base foram mantidos.
- Workflow Codemagic atualizado para CODE06, sem fallback de assinatura debug.
- Checklist de mudanças: `SONUS_CHECKLIST_INTERNO_0.0.6_CODE06.md`.

## Correções após falha de compilação no Codemagic

O log da segunda execução apontou sete erros Kotlin distribuídos em dois arquivos. Foram corrigidos no código-fonte:

1. `SonusLiveMedia.kt`: captura não nula da cena ativa antes de consultar o tipo de mídia dentro do loop.
2. `SonusOnlineMusic.kt`: quatro callbacks de favorito passaram a usar `track.fileId`, respeitando a assinatura `onFavorite: () -> Unit`.
3. `SonusOnlineMusic.kt`: implementado `resolveStreamDurationMs`, que lê a duração do stream com `MediaMetadataRetriever` e persiste o resultado no cache já existente.

O YAML do Codemagic e a identidade CODE06 não precisaram ser alterados. O build deve ser repetido no Codemagic para confirmar a compilação completa; este ambiente não tem Gradle Wrapper/Gradle nem Android SDK instalados.

## Verificações executadas no pacote

- Estrutura e CRC do ZIP (`unzip -t`).
- Leitura/parse YAML e sintaxe shell (`bash -n`) dos scripts embutidos no Codemagic.
- Parse JSON dos arquivos JSON do projeto.
- Conferência de versão, applicationId e três arquivos protegidos.
- Verificação da presença real da ação de download de álbum exigida pelo workflow Codemagic.
- Comparação de integridade dos arquivos de áudio/player/plataforma protegidos com a base.

## Limitações e pendências

Este ambiente não dispõe de Gradle instalado, Gradle Wrapper no projeto nem Android SDK. Portanto, não foi executado um `assembleDebug` e não é correto afirmar que o APK CODE06 já compilou. A compilação/assinatura final depende da execução do workflow atualizado no Codemagic com as variáveis seguras originais. Também estão pendentes testes em aparelho real para ANR, tempo de resposta, telas de tamanhos diferentes, rede lenta/indisponível, reprodução com dados móveis, transições de LIVE, captura de áudio e regressão completa das ferramentas.

**Status:** pacote-fonte e Codemagic preparados para CODE06; build Android oficial e aceite de dispositivo ainda pendentes.
