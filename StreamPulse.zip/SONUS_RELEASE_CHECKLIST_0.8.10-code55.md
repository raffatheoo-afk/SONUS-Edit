# SONUS v0.8.10 • code55 — checklist de correção

Base: v0.8.9 code54 confirmada pelo usuário. Esta versão preserva crossfade aprovado, cache offline de plano/admin, limpeza de estatísticas, Bluetooth pause, Firebase, assinatura e applicationId.

## Correções e entregas
- Conversor: seleção em lote preservada; saída automática via MediaStore; stream de capa/attached picture é ignorado com `-map 0:a:0 -vn -sn -dn`; retry limpo; logs ampliados.
- Armazenamento SONUS: camada central `SonusStorage`; saídas automáticas em pastas SONUS (Audio, Visualizer, Images, Recordings, AutoMix, Masters) e recriação no próximo uso se a pasta/arquivo for removido.
- SONUS BOOST™ / SONUS SPATIAL™: acesso livre no player e conversor, sem anúncio, plano ou SONUS COINS.
- Dynamic Island SONUS: overlay Android opt-in, explicação antes da permissão, posição arrastável, tentativa de alinhamento ao cutout, tamanho, transparência, estilos Standard/Glow/Glass, player, gravador, progresso e aviso offline contextual.
- Offline: acesso Premium/admin continua cacheado; avisos temporários; YouTube/Karaokê avisam ao tentar recurso online sem conexão.
- Studio: ordem FREE → Bronze → Prata → Ouro → Diamante; Redes Sociais 100% FREE; 3 Premium em Áudio, 2 em Edição/Arquivo, 2 em Imagem/Capa.
- SONUS COINS: identidade pública corrigida; recursos Free não consomem moedas; ferramentas Studio Premium podem ser usadas avulsamente por Coins; Master, Match, AutoMix e exportação Visualizer acima do plano também têm uso avulso.
- SONUS LAB: Teste de Som Free; Match básico Free e completo Prata+/Coins; Master análise/prévia Free e exportação Ouro+/Coins.
- SONUS AUTOMIX: até 3 faixas no Free; até 20 + modo personalizado no Prata+/Coins; saída automática SONUS/AutoMix.
- SONUS MUSIC Estatísticas: Hoje, 7 dias, Mês, 90 dias, 6 meses, 1 ano, Total e calendário personalizado; histórico temporal passa a ser acumulado nesta versão; limpeza independente preservada.
- SONUS Visualizer: exportação MP4 real, 16:9/9:16/1:1, fundo/capa/waveform/áudio, controles visuais aplicados, progresso FFmpeg real, cancelamento, fallback 1080p, 1080p Free, 2K Prata+/Coins, 4K Ouro+/Coins e saída SONUS/Visualizer.
- Destaques: grade de 2 cards por linha preservada.
- Premium Catalog: Bronze=produtividade; Prata=Creator; Ouro=produção profissional; Diamante=experiência máxima. BOOST/SPATIAL removidos dos benefícios pagos.

## Auditoria estática feita
- versionName 0.8.10 / versionCode 55.
- applicationId `com.sonusstudios.streampulse` preservado.
- Manifest XML válido e overlay/FGS declarados.
- Delimitadores `{}`, `()` balanceados nos fontes Kotlin.
- Arquivos novos e rotas revisados.
- Sem referências públicas a “Pulse Coin(s)” ou “Passe Pulse”.
- Sem texto público cobrando/anunciando SONUS BOOST™ ou SONUS SPATIAL™.
- Crossfade de code54 não foi alterado; apenas integração passiva da Dynamic Island no serviço do player.
- Filtro FFmpeg principal do Visualizer validado em execução local com waveform + capa circular/rotacionada; fallback simplificado mantido.

> Compilação Android final deve ser confirmada pelo GitHub Actions; este pacote não possui Gradle Wrapper local.
