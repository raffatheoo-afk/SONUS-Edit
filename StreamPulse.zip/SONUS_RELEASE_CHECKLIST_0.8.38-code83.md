# SONUS v0.8.38 — code83

## Release
- `versionName`: 0.8.38
- `versionCode`: 83
- Build: Codemagic / `sonus-code83-debug`
- APK esperado: `SONUS-v0.8.38-code83.apk`

## Entregas principais
- SONUS PLAYER como player principal.
- Sonus Music usando catálogo público pCloud.
- Streaming contextual/contínuo, cache, gêneros, recentes, favoritas e playlists.
- Publicação de gêneros pelo Painel Desenvolvedor.
- Painel Desenvolvedor modular com dashboards e preservação das funções administrativas existentes.
- Sobre o SONUS apenas com novidades da versão atual.

## Validação antes do pacote
- Versão/code conferidos.
- Configuração pública pCloud presente.
- Segredos Dropbox removidos do build.
- JSON de regras Firebase válido.
- Delimitadores dos principais Kotlin verificados.
- Workflow Codemagic atualizado para code83.

## Observação
A compilação Android final é executada pelo Codemagic. Qualquer erro de build desta entrega deve ser corrigido como HOTFIX do code83.
