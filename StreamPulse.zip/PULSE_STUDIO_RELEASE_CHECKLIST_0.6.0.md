# PULSE STUDIO 0.6.0 — CHECKLIST DE ENTREGA

- versionName: `0.6.0`
- versionCode: `30`
- applicationId preservado: `com.sonusstudios.streampulse`
- Firebase Rules preservadas em v1.9.4

## Player
- cache persistente da biblioteca + atualização em segundo plano
- player pausado permanece pausado ao trocar/voltar de abas
- visualizador com FFT + waveform fallback e parâmetros adaptativos
- swipe horizontal para alternar visualizadores + dica automática de primeiro uso
- capa/área do visualizador ampliadas e controles reposicionados
- letras locais com Pulse Transcribe e cache por faixa
- assinatura tátil Pulse nas ações principais

## Destaques
- PulseTune™ Bronze+: AudioRecord local, YIN, cromático/violão, Standard/Drop D/Eb/Drop C/Open G, A4 e painel próprio
- Pulse Transcribe Prata+: importação local, preparação PCM e reconhecedor Android sem chave externa

## Ferramentas
- hub organizado por categorias, cards centralizados e legíveis
- Stem Splitter
- Voice Cleaner
- Metrônomo Pro
- Detector BPM & Tom

## Sistema
- assinatura tátil Pulse configurável nos Ajustes
- permissão VIBRATE adicionada
- interfaces novas desenhadas especificamente para cada mini app

## Validação antes da publicação
- [x] estrutura/versionamento revisados
- [x] ZIP deve conter raiz `StreamPulse/`
- [ ] GitHub Actions `assembleDebug` aprovado
- [ ] teste em Galaxy S10e
- [ ] teste de espectro em Galaxy S10+
- [ ] teste de espectro em Moto E22
- [ ] teste de biblioteca com 500+ músicas
- [ ] teste de PulseTune em pelo menos 3 fabricantes
- [ ] teste de Pulse Transcribe em aparelhos Android 13+

> Não considerar compilação confirmada até o GitHub Actions finalizar com sucesso.
