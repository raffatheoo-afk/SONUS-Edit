# SONUS 0.8.5 code50

- Player: transição automática com uma única fonte de verdade; preload gapless nativo desativado para evitar reinício de faixa em firmwares incompatíveis.
- Visualizer: preservado fallback por análise local do arquivo quando AudioFX retorna dados zerados.
- Pastas: Tocar tudo, Aleatório, Extremos e Inteligente (evita artista consecutivo quando possível).
- Splash: escrita mais fluida; restauração remota continua em background sem segunda tela “Restaurando seus dados”.
- Studio: categorias horizontais sem alterar o desenho dos cards.
- Afinador: leitura suavizada e última nota mantida durante o decaimento do som.
- Karaokê: botão Tela cheia abre superfície fullscreen em paisagem, com saída dedicada.
- Removedor vocal/Pulse Transcribe não foram reintroduzidos nas áreas públicas.
- versionName 0.8.5 / versionCode 50.
- Compilação final deve ser confirmada pelo GitHub Actions.
