# SONUS Edit — 0.2.0 / code02

Android app separado do SONUS principal (`com.sonusstudios.sonusedit`) focado em criação automática de vídeos musicais verticais.

## Fluxo code02

Assinatura + Música → Imagens → Estilo/Letra → Revisão → Exportação automática → Galeria.

## Destaques
- novo ícone oficial sem anel externo;
- SONUS Stream simplificado para seleção de música;
- SONUS MUSIC e Sonus Gallery via catálogos públicos pCloud;
- cache-first + refresh silencioso;
- sugestão de próxima música por histórico/gênero;
- ajuste de trecho horizontal ±1s/±5s/±10s;
- vídeos de 15s a 10min;
- mínimo de 5s por imagem;
- 10 fontes com previews distintos;
- paleta neon por linha para letra;
- revisão final;
- `Criar vídeo` inicia exportação, sem abrir timeline;
- export base Media3 Composition para MP4 H.264 1080x1920;
- salvamento automático via MediaStore em Android 10+.

## LRC do SONUS Stream
Faixas do SONUS Stream **não são redirecionadas para LRCLIB**. A code02 inclui o contrato `SonusLyricsResolver`, mas o resolvedor concreto depende da fonte/módulo real usado hoje por `com.sonusstudios.streampulse`, que não faz parte da base recebida do SONUS Edit.

Leia `CODE02_IMPLEMENTATION.md` para limites conhecidos e itens que exigem build/teste real.
