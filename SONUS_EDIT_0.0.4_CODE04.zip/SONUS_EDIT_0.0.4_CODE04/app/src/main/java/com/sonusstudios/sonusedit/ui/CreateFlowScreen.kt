package com.sonusstudios.sonusedit.ui

import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.sonusstudios.sonusedit.R
import com.sonusstudios.sonusedit.catalog.PCloudAsset
import com.sonusstudios.sonusedit.catalog.PCloudImageRepository
import com.sonusstudios.sonusedit.catalog.PCloudMusicRepository
import com.sonusstudios.sonusedit.catalog.StreamHistoryStore
import com.sonusstudios.sonusedit.catalog.StreamMetadataStore
import com.sonusstudios.sonusedit.create.AudioMetadata
import com.sonusstudios.sonusedit.create.AudioMetadataReader
import com.sonusstudios.sonusedit.create.AudioSource
import com.sonusstudios.sonusedit.create.AutomationPlanner
import com.sonusstudios.sonusedit.create.AutomationPreferences
import com.sonusstudios.sonusedit.create.AutomationSettings
import com.sonusstudios.sonusedit.create.EffectIntensity
import com.sonusstudios.sonusedit.create.CreateProjectDraft
import com.sonusstudios.sonusedit.create.DurationPreset
import com.sonusstudios.sonusedit.create.EditPreferences
import com.sonusstudios.sonusedit.create.ExportResolution
import com.sonusstudios.sonusedit.create.FilterPresetId
import com.sonusstudios.sonusedit.create.FontPresetId
import com.sonusstudios.sonusedit.create.LyricsPolicy
import com.sonusstudios.sonusedit.create.MediaDistributionPlanner
import com.sonusstudios.sonusedit.create.SavedEditPreferences
import com.sonusstudios.sonusedit.create.UriPermissionHelper
import com.sonusstudios.sonusedit.designsystem.SonusEditColors
import com.sonusstudios.sonusedit.integration.IncomingIntentRouter
import com.sonusstudios.sonusedit.lyrics.LrclibLyricsProvider
import com.sonusstudios.sonusedit.lyrics.LyricsMatch
import com.sonusstudios.sonusedit.lyrics.LyricsMetadata
import com.sonusstudios.sonusedit.lyrics.SonusLyricsResolver
import com.sonusstudios.sonusedit.lyrics.FirebaseSonusLyricsResolver
import com.sonusstudios.sonusedit.media.AutomaticEffectSelector
import com.sonusstudios.sonusedit.media.EffectIds
import com.sonusstudios.sonusedit.media.SmartStartResolver
import java.net.HttpURLConnection
import java.net.URI
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private enum class CreateStep(val label: String) {
    MUSIC("Música"), IMAGES("Imagens"), STYLE("Estilo"), REVIEW("Revisão")
}

private val musicExt = setOf("mp3", "wav", "flac", "m4a", "aac", "ogg", "opus")
private val imageExt = setOf("jpg", "jpeg", "png", "webp")

@Composable
fun CreateFlowScreen(
    incomingRoute: IncomingIntentRouter.Route?,
    preselectedStreamAsset: PCloudAsset? = null,
    onBack: () -> Unit,
    onCreateDraft: (CreateProjectDraft) -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    val preferences = remember { EditPreferences(context.applicationContext) }
    val savedPreferences by preferences.values.collectAsState(initial = SavedEditPreferences())
    val automationPreferences = remember { AutomationPreferences(context.applicationContext) }
    val automationSettings by automationPreferences.values.collectAsState(initial = AutomationSettings())
    val musicRepo = remember { PCloudMusicRepository(context.applicationContext) }
    val imageRepo = remember { PCloudImageRepository(context.applicationContext) }
    val metadataStore = remember { StreamMetadataStore(context.applicationContext) }
    val historyStore = remember { StreamHistoryStore(context.applicationContext) }
    val lrclib = remember { LrclibLyricsProvider() }
    val sonusLyrics = remember { FirebaseSonusLyricsResolver() }
    val effectSelector = remember { AutomaticEffectSelector(context.applicationContext) }

    var step by remember { mutableStateOf(CreateStep.MUSIC) }
    var signatureText by remember { mutableStateOf("") }
    var signaturePhotoUri by remember { mutableStateOf<Uri?>(null) }
    var saveSignatureDefault by remember { mutableStateOf(true) }

    var audioUri by remember { mutableStateOf<Uri?>(null) }
    var audioSource by remember { mutableStateOf(AudioSource.LOCAL) }
    var selectedStreamAsset by remember { mutableStateOf<PCloudAsset?>(null) }
    var metadata by remember { mutableStateOf<AudioMetadata?>(null) }
    var selectedDuration by remember { mutableStateOf(DurationPreset.all[1]) }
    var segmentStartMs by remember { mutableStateOf(0L) }
    var manualStartOverride by remember { mutableStateOf(false) }
    var durationManuallyEdited by remember { mutableStateOf(false) }
    var smartStartLoading by remember { mutableStateOf(false) }
    var isPlaying by remember { mutableStateOf(false) }

    var syncedLyrics by remember { mutableStateOf<String?>(null) }
    var lyricsLoading by remember { mutableStateOf(false) }
    var showLyricsSearch by remember { mutableStateOf(false) }
    var lyricsSearchTitle by remember { mutableStateOf("") }
    var lyricsSearchArtist by remember { mutableStateOf("") }
    var lyricsResults by remember { mutableStateOf<List<LyricsMatch>>(emptyList()) }
    var lyricsSearchLoading by remember { mutableStateOf(false) }

    var musicCatalog by remember { mutableStateOf<List<PCloudAsset>>(emptyList()) }
    var imageCatalog by remember { mutableStateOf<List<PCloudAsset>>(emptyList()) }
    var showStreamPicker by remember { mutableStateOf(false) }
    var showSonusGallery by remember { mutableStateOf(true) }
    var musicSearch by remember { mutableStateOf("") }
    var selectedGenre by remember { mutableStateOf("Todos") }
    var catalogsLoading by remember { mutableStateOf(false) }

    var imageUris by remember { mutableStateOf<List<String>>(emptyList()) }
    var selectedRemoteImages by remember { mutableStateOf<Set<Long>>(emptySet()) }
    var remoteImageUrls by remember { mutableStateOf<Map<Long, String>>(emptyMap()) }
    var imagesManuallyEdited by remember { mutableStateOf(false) }
    var fontPreset by remember { mutableStateOf(FontPresetId.DEFAULT) }
    var fontManuallyEdited by remember { mutableStateOf(false) }
    var filterPreset by remember { mutableStateOf(FilterPresetId.ORIGINAL) }
    var filterManuallyEdited by remember { mutableStateOf(false) }
    var automaticEffectId by remember { mutableStateOf(EffectIds.MINIMAL_PARTICLES) }
    var regenerationNonce by remember { mutableStateOf(0) }
    var saveFontDefault by remember { mutableStateOf(true) }

    var exportTitle by remember { mutableStateOf("") }
    var exportArtist by remember { mutableStateOf("") }
    var titleManuallyEdited by remember { mutableStateOf(false) }
    var artistManuallyEdited by remember { mutableStateOf(false) }
    var exportResolution by remember { mutableStateOf(ExportResolution.P1080) }
    var exportFps by remember { mutableStateOf(60) }
    var qualityManuallyEdited by remember { mutableStateOf(false) }

    fun message(text: String) {
        scope.launch { snackbar.showSnackbar(text) }
    }

    fun selectNewAudio() {
        manualStartOverride = false
        syncedLyrics = null
        lyricsResults = emptyList()
        showLyricsSearch = false
        titleManuallyEdited = false
        artistManuallyEdited = false
        durationManuallyEdited = false
        imagesManuallyEdited = false
        filterManuallyEdited = false
        fontManuallyEdited = false
        manualStartOverride = false
        regenerationNonce = 0
    }

    LaunchedEffect(savedPreferences) {
        if (signatureText.isBlank()) signatureText = savedPreferences.signatureText
        if (signaturePhotoUri == null) signaturePhotoUri = savedPreferences.signaturePhotoUri?.let(Uri::parse)
        if (fontPreset == FontPresetId.DEFAULT) fontPreset = savedPreferences.fontPreset
    }

    LaunchedEffect(automationSettings, qualityManuallyEdited) {
        if (!qualityManuallyEdited) {
            if (automationSettings.totalAutomation) {
                exportResolution = ExportResolution.P1080
                exportFps = 60
            } else {
                exportResolution = automationSettings.defaultResolution
                exportFps = automationSettings.defaultFps
            }
        }
    }

    LaunchedEffect(Unit) {
        catalogsLoading = true
        musicCatalog = musicRepo.cached().filter { it.extension in musicExt }
        imageCatalog = imageRepo.cached().filter { it.extension in imageExt }
        val freshMusic = musicRepo.refresh().filter { it.extension in musicExt }
        val freshImages = imageRepo.refresh().filter { it.extension in imageExt }
        if (freshMusic.isNotEmpty()) musicCatalog = freshMusic
        if (freshImages.isNotEmpty()) imageCatalog = freshImages
        catalogsLoading = false
    }

    suspend fun chooseStreamAsset(asset: PCloudAsset) {
        val url = musicRepo.downloadUrl(asset)
        if (url == null) {
            message("Não foi possível abrir esta faixa do Sonus Stream.")
            return
        }
        selectNewAudio()
        selectedStreamAsset = asset
        audioSource = AudioSource.SONUS_STREAM
        metadata = metadataStore.resolve(asset, musicRepo)
        audioUri = Uri.parse(url)
        showStreamPicker = false
    }

    LaunchedEffect(preselectedStreamAsset) {
        val asset = preselectedStreamAsset ?: return@LaunchedEffect
        if (audioUri == null) chooseStreamAsset(asset)
    }

    LaunchedEffect(incomingRoute, musicCatalog) {
        when (val route = incomingRoute) {
            is IncomingIntentRouter.Route.SharedMedia -> {
                if (audioUri == null) {
                    route.uris.firstOrNull { context.contentResolver.getType(it)?.startsWith("audio/") == true }?.let { audio ->
                        UriPermissionHelper.persistRead(context, audio)
                        selectNewAudio()
                        audioSource = AudioSource.SHARED
                        selectedStreamAsset = null
                        audioUri = audio
                    }
                }
                val images = route.uris.filter { context.contentResolver.getType(it)?.startsWith("image/") == true }
                images.forEach { UriPermissionHelper.persistRead(context, it) }
                imageUris = (imageUris + images.map { it.toString() }).distinct()
                if (images.isNotEmpty()) imagesManuallyEdited = true
            }
            is IncomingIntentRouter.Route.SonusTrack -> {
                if (audioUri == null && musicCatalog.isNotEmpty()) {
                    val asset = route.trackId.toLongOrNull()?.let { id -> musicCatalog.firstOrNull { it.fileId == id } }
                    if (asset != null) chooseStreamAsset(asset)
                    route.startMs?.let { segmentStartMs = it.coerceAtLeast(0L) }
                }
            }
            else -> Unit
        }
    }

    val player = remember { ExoPlayer.Builder(context).build() }
    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY && player.duration > 0) {
                    metadata = metadata?.copy(durationMs = player.duration)
                }
            }
        }
        player.addListener(listener)
        onDispose {
            player.removeListener(listener)
            player.release()
        }
    }

    LaunchedEffect(audioUri) {
        isPlaying = false
        player.stop()
        val uri = audioUri ?: run { metadata = null; return@LaunchedEffect }
        if (audioSource != AudioSource.SONUS_STREAM) {
            metadata = withContext(Dispatchers.IO) { runCatching { AudioMetadataReader.read(context, uri) }.getOrNull() }
        }
        player.setMediaItem(MediaItem.fromUri(uri))
        player.prepare()
        segmentStartMs = 0L
    }

    LaunchedEffect(metadata) {
        val meta = metadata ?: return@LaunchedEffect
        if (!titleManuallyEdited) exportTitle = meta.title
        if (!artistManuallyEdited) exportArtist = meta.artist.orEmpty()
        lyricsSearchTitle = meta.title
        lyricsSearchArtist = meta.artist.orEmpty()
    }

    // Automatic lyrics lookup: the exact public SONUS Stream override source first, LRCLIB second.
    LaunchedEffect(audioUri, metadata?.title, metadata?.artist, automationSettings.totalAutomation, automationSettings.automaticLyrics) {
        val meta = metadata ?: return@LaunchedEffect
        if (audioUri == null || meta.title.isBlank()) return@LaunchedEffect
        if (!automationSettings.totalAutomation && !automationSettings.automaticLyrics) {
            lyricsLoading = false
            return@LaunchedEffect
        }
        lyricsLoading = true
        val streamTrackId = selectedStreamAsset?.fileId?.toString()
            ?: (incomingRoute as? IncomingIntentRouter.Route.SonusTrack)?.trackId
        val fromSonus = if (audioSource == AudioSource.SONUS_STREAM && streamTrackId != null) {
            runCatching { sonusLyrics.syncedLyrics(streamTrackId) }.getOrNull()
        } else null
        syncedLyrics = fromSonus ?: runCatching {
            if (!meta.artist.isNullOrBlank()) {
                lrclib.bestMatch(
                    LyricsMetadata(
                        trackName = meta.title,
                        artistName = meta.artist,
                        albumName = meta.album,
                        durationSeconds = (meta.durationMs / 1_000L).toInt().takeIf { it > 0 },
                    )
                )?.takeIf { it.hasSyncedLyrics }?.syncedLyrics
            } else {
                lrclib.search(meta.title, null).firstOrNull { it.hasSyncedLyrics }?.syncedLyrics
            }
        }.getOrNull()
        lyricsLoading = false
    }

    // Automação Total intentionally starts at 30 seconds. 15s remains manual-only.
    LaunchedEffect(metadata, syncedLyrics, automationSettings.totalAutomation) {
        val meta = metadata ?: return@LaunchedEffect
        if (automationSettings.totalAutomation && !durationManuallyEdited) {
            AutomationPlanner.duration(meta, syncedLyrics)?.let { preset ->
                selectedDuration = preset
                val maxStart = (meta.durationMs - preset.seconds * 1_000L).coerceAtLeast(0L)
                segmentStartMs = segmentStartMs.coerceAtMost(maxStart)
                val max = MediaDistributionPlanner.maxImages(preset.seconds)
                if (imageUris.size > max) imageUris = imageUris.take(max)
            }
        }
    }

    val segmentDurationMs = selectedDuration.seconds * 1_000L
    val imageLimit = MediaDistributionPlanner.maxImages(selectedDuration.seconds)

    LaunchedEffect(metadata, syncedLyrics, automationSettings, regenerationNonce) {
        val meta = metadata ?: return@LaunchedEffect
        if ((automationSettings.totalAutomation || automationSettings.automaticFilter) && !filterManuallyEdited) {
            filterPreset = if (regenerationNonce == 0) {
                AutomationPlanner.filter(meta, syncedLyrics)
            } else {
                AutomationPlanner.alternativeFilter(filterPreset, meta, syncedLyrics, regenerationNonce)
            }
        }
        if (automationSettings.totalAutomation && !fontManuallyEdited) {
            fontPreset = AutomationPlanner.font(meta)
        }
        automaticEffectId = if (automationSettings.totalAutomation || automationSettings.automaticEffects) {
            effectSelector.select(meta.title, meta.genre ?: selectedStreamAsset?.genre, syncedLyrics, regenerationNonce)
        } else EffectIds.NONE
    }

    LaunchedEffect(metadata?.title, imageCatalog, selectedDuration.seconds, automationSettings, regenerationNonce, imagesManuallyEdited) {
        val meta = metadata ?: return@LaunchedEffect
        val shouldAutoImages = automationSettings.totalAutomation || automationSettings.automaticImages
        if (!shouldAutoImages || imagesManuallyEdited || imageCatalog.isEmpty()) return@LaunchedEffect
        val ranked = rankImageAssets(imageCatalog, meta, syncedLyrics)
        if (ranked.isEmpty()) return@LaunchedEffect
        val mode = if (automationSettings.totalAutomation) com.sonusstudios.sonusedit.create.ImageQuantityMode.BALANCED else automationSettings.imageQuantity
        val count = AutomationPlanner.imageCount(selectedDuration.seconds, mode).coerceAtMost(ranked.size)
        val offset = if (ranked.isEmpty()) 0 else (regenerationNonce * count).mod(ranked.size)
        val selected = List(count) { ranked[(offset + it) % ranked.size] }.distinctBy { it.stableKey }
        val resolved = selected.mapNotNull { asset ->
            imageRepo.downloadUrl(asset)?.let { asset to it }
        }
        if (!imagesManuallyEdited && resolved.isNotEmpty()) {
            selectedRemoteImages = resolved.map { it.first.fileId }.toSet()
            remoteImageUrls = resolved.associate { it.first.fileId to it.second }
            imageUris = resolved.map { it.second }
        }
    }

    // Smart Start re-evaluates automatically while the user has not manually moved the start.
    LaunchedEffect(audioUri, metadata?.durationMs, selectedDuration.seconds, syncedLyrics, automationSettings) {
        val uri = audioUri ?: return@LaunchedEffect
        val duration = metadata?.durationMs ?: return@LaunchedEffect
        val enabled = automationSettings.totalAutomation || automationSettings.smartStart
        if (!enabled || duration < segmentDurationMs || manualStartOverride) return@LaunchedEffect
        smartStartLoading = true
        val lyricsForStart = if (automationSettings.totalAutomation || automationSettings.prioritizeChorus) syncedLyrics else null
        val suggested = SmartStartResolver.resolve(context, uri, duration, segmentDurationMs, lyricsForStart)
        if (!manualStartOverride) {
            segmentStartMs = suggested
            player.seekTo(suggested)
        }
        smartStartLoading = false
    }

    LaunchedEffect(isPlaying, segmentStartMs, segmentDurationMs) {
        if (!isPlaying) return@LaunchedEffect
        val end = segmentStartMs + segmentDurationMs
        while (isPlaying) {
            if (player.currentPosition >= end) {
                player.pause()
                player.seekTo(segmentStartMs)
                isPlaying = false
                break
            }
            delay(100)
        }
    }

    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            UriPermissionHelper.persistRead(context, it)
            selectNewAudio()
            audioSource = AudioSource.LOCAL
            selectedStreamAsset = null
            audioUri = it
        }
    }
    val signaturePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { UriPermissionHelper.persistRead(context, it); signaturePhotoUri = it }
    }
    val localImagesPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { UriPermissionHelper.persistRead(context, it) }
        if (uris.isNotEmpty()) imagesManuallyEdited = true
        val merged = (imageUris + uris.map { it.toString() }).distinct()
        if (merged.size > imageLimit) {
            imageUris = merged.take(imageLimit)
            message("Máximo de $imageLimit imagens para ${selectedDuration.label}.")
        } else imageUris = merged
    }

    fun applyDuration(preset: DurationPreset) {
        durationManuallyEdited = true
        val duration = metadata?.durationMs ?: 0L
        if (duration > 0 && preset.seconds * 1_000L > duration) {
            message("A música é menor que ${preset.label}.")
            return
        }
        selectedDuration = preset
        val maxStart = (duration - preset.seconds * 1_000L).coerceAtLeast(0L)
        segmentStartMs = segmentStartMs.coerceAtMost(maxStart)
        val limit = MediaDistributionPlanner.maxImages(preset.seconds)
        if (imageUris.size > limit) imageUris = imageUris.take(limit)
    }

    val musicReady = audioUri != null && (metadata?.durationMs ?: 0L) >= segmentDurationMs
    val imagesReady = imageUris.isNotEmpty() && imageUris.size <= imageLimit
    val canContinue = when (step) {
        CreateStep.MUSIC -> musicReady
        CreateStep.IMAGES -> imagesReady
        CreateStep.STYLE -> true
        CreateStep.REVIEW -> musicReady && imagesReady && exportTitle.isNotBlank()
    }

    Scaffold(
        containerColor = SonusEditColors.Black,
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            if (!showStreamPicker) {
                BottomFlowBar(
                    step = step,
                    canContinue = canContinue,
                    onPrevious = { if (step == CreateStep.MUSIC) onBack() else step = CreateStep.entries[step.ordinal - 1] },
                    onNext = {
                        when (step) {
                            CreateStep.MUSIC -> {
                                if (saveSignatureDefault) scope.launch { preferences.saveSignature(signatureText, signaturePhotoUri?.toString()) }
                                step = CreateStep.IMAGES
                            }
                            CreateStep.IMAGES -> step = CreateStep.STYLE
                            CreateStep.STYLE -> {
                                if (saveFontDefault) scope.launch { preferences.saveFont(fontPreset) }
                                step = CreateStep.REVIEW
                            }
                            CreateStep.REVIEW -> {
                                val meta = metadata
                                val uri = audioUri
                                if (meta != null && uri != null) {
                                    onCreateDraft(
                                        CreateProjectDraft(
                                            audioUri = uri.toString(),
                                            audioTitle = meta.title,
                                            audioArtist = meta.artist,
                                            audioAlbum = meta.album,
                                            audioDurationMs = meta.durationMs,
                                            audioSource = audioSource,
                                            sourceTrackId = selectedStreamAsset?.fileId?.toString()
                                                ?: (incomingRoute as? IncomingIntentRouter.Route.SonusTrack)?.trackId,
                                            sourcePublicCode = selectedStreamAsset?.sourcePublicCode,
                                            sourceGenre = meta.genre ?: selectedStreamAsset?.genre,
                                            segmentStartMs = segmentStartMs,
                                            segmentDurationMs = segmentDurationMs,
                                            signatureText = signatureText.trim(),
                                            signaturePhotoUri = signaturePhotoUri?.toString(),
                                            imageUris = imageUris,
                                            fontPreset = fontPreset,
                                            filterPreset = filterPreset,
                                            lyricsPolicy = LyricsPolicy.AUTO,
                                            syncedLyrics = syncedLyrics,
                                            exportTitle = exportTitle.trim(),
                                            exportArtist = exportArtist.trim(),
                                            automaticEffectId = automaticEffectId,
                                            automaticEffectOpacity = if (automationSettings.totalAutomation) EffectIntensity.BALANCED.opacity else automationSettings.effectIntensity.opacity,
                                            metadataOverlayEnabled = if (automationSettings.totalAutomation) true else automationSettings.metadataOnVideo,
                                            exportResolution = exportResolution,
                                            exportFps = exportFps,
                                        )
                                    )
                                }
                            }
                        }
                    },
                )
            }
        },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            CreateHeader(onBack)
            if (!showStreamPicker) StepTabs(step) { if (it.ordinal <= step.ordinal) step = it }

            if (showStreamPicker) {
                StreamPicker(
                    assets = musicCatalog,
                    loading = catalogsLoading,
                    search = musicSearch,
                    selectedGenre = selectedGenre,
                    history = historyStore.recent(),
                    repository = musicRepo,
                    metadataStore = metadataStore,
                    lrclib = lrclib,
                    sonusLyrics = sonusLyrics,
                    onSearch = { musicSearch = it },
                    onGenre = { selectedGenre = it },
                    onBack = { showStreamPicker = false },
                    onSelect = { asset -> scope.launch { chooseStreamAsset(asset) } },
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    item {
                        when (step) {
                            CreateStep.MUSIC -> MusicAndSignatureStep(
                                signatureText = signatureText,
                                signaturePhotoUri = signaturePhotoUri,
                                saveSignature = saveSignatureDefault,
                                onSignatureText = { signatureText = it },
                                onSignaturePhoto = { signaturePicker.launch(arrayOf("image/*")) },
                                onRemoveSignaturePhoto = { signaturePhotoUri = null },
                                onSaveSignature = { saveSignatureDefault = it },
                                metadata = metadata,
                                audioSource = audioSource,
                                selectedDuration = selectedDuration,
                                segmentStartMs = segmentStartMs,
                                isPlaying = isPlaying,
                                lyricsAvailable = !syncedLyrics.isNullOrBlank(),
                                lyricsLoading = lyricsLoading,
                                smartStartLoading = smartStartLoading,
                                showLyricsSearch = showLyricsSearch,
                                lyricsSearchTitle = lyricsSearchTitle,
                                lyricsSearchArtist = lyricsSearchArtist,
                                lyricsResults = lyricsResults,
                                lyricsSearchLoading = lyricsSearchLoading,
                                onToggleLyricsSearch = {
                                    showLyricsSearch = !showLyricsSearch
                                    if (showLyricsSearch && lyricsResults.isEmpty()) {
                                        scope.launch {
                                            lyricsSearchLoading = true
                                            lyricsResults = runCatching { lrclib.search(lyricsSearchTitle, lyricsSearchArtist.ifBlank { null }) }
                                                .getOrDefault(emptyList()).filter { it.hasSyncedLyrics }.take(8)
                                            lyricsSearchLoading = false
                                        }
                                    }
                                },
                                onLyricsTitle = { lyricsSearchTitle = it },
                                onLyricsArtist = { lyricsSearchArtist = it },
                                onLyricsSearch = {
                                    scope.launch {
                                        lyricsSearchLoading = true
                                        lyricsResults = runCatching { lrclib.search(lyricsSearchTitle, lyricsSearchArtist.ifBlank { null }) }
                                            .getOrDefault(emptyList()).filter { it.hasSyncedLyrics }.take(8)
                                        lyricsSearchLoading = false
                                    }
                                },
                                onLyricsPick = { match -> syncedLyrics = match.syncedLyrics; showLyricsSearch = false },
                                onStream = { showStreamPicker = true },
                                onLocal = { audioPicker.launch(arrayOf("audio/*")) },
                                onDuration = ::applyDuration,
                                onStartChange = { value ->
                                    manualStartOverride = true
                                    val duration = metadata?.durationMs ?: 0L
                                    val maxStart = (duration - segmentDurationMs).coerceAtLeast(0L)
                                    segmentStartMs = value.coerceIn(0L, maxStart)
                                    player.seekTo(segmentStartMs)
                                },
                                onFine = { seconds ->
                                    manualStartOverride = true
                                    val duration = metadata?.durationMs ?: 0L
                                    val maxStart = (duration - segmentDurationMs).coerceAtLeast(0L)
                                    segmentStartMs = (segmentStartMs + seconds * 1_000L).coerceIn(0L, maxStart)
                                    player.seekTo(segmentStartMs)
                                },
                                onPlayPause = {
                                    if (audioUri != null) {
                                        if (isPlaying) { player.pause(); isPlaying = false }
                                        else { player.seekTo(segmentStartMs); player.play(); isPlaying = true }
                                    }
                                },
                            )
                            CreateStep.IMAGES -> ImagesStep(
                                localOrRemoteUris = imageUris,
                                selectedRemoteIds = selectedRemoteImages,
                                remoteAssets = rankImageAssets(imageCatalog, metadata, syncedLyrics),
                                remoteMode = showSonusGallery,
                                limit = imageLimit,
                                loading = catalogsLoading,
                                imageRepo = imageRepo,
                                onRemoteMode = { showSonusGallery = it },
                                onLocal = { imagesManuallyEdited = true; localImagesPicker.launch(arrayOf("image/*")) },
                                onRemoteToggle = { asset ->
                                    imagesManuallyEdited = true
                                    scope.launch {
                                        if (asset.fileId in selectedRemoteImages) {
                                            selectedRemoteImages = selectedRemoteImages - asset.fileId
                                            remoteImageUrls[asset.fileId]?.let { stored -> imageUris = imageUris - stored }
                                            remoteImageUrls = remoteImageUrls - asset.fileId
                                        } else if (imageUris.size < imageLimit) {
                                            val url = imageRepo.downloadUrl(asset)
                                            if (url != null) {
                                                selectedRemoteImages = selectedRemoteImages + asset.fileId
                                                remoteImageUrls = remoteImageUrls + (asset.fileId to url)
                                                imageUris = imageUris + url
                                            }
                                        } else message("Máximo de $imageLimit imagens para ${selectedDuration.label}.")
                                    }
                                },
                                onRemoveUri = { imagesManuallyEdited = true; imageUris = imageUris - it },
                            )
                            CreateStep.STYLE -> StyleStep(
                                fontPreset = fontPreset,
                                filterPreset = filterPreset,
                                saveFont = saveFontDefault,
                                previewImageUri = imageUris.firstOrNull(),
                                lyricsAvailable = !syncedLyrics.isNullOrBlank(),
                                onFont = { fontManuallyEdited = true; fontPreset = it },
                                onFilter = { filterManuallyEdited = true; filterPreset = it },
                                onSaveFont = { saveFontDefault = it },
                            )
                            CreateStep.REVIEW -> ReviewStep(
                                metadata = metadata,
                                selectedDuration = selectedDuration,
                                segmentStartMs = segmentStartMs,
                                imageCount = imageUris.size,
                                signatureText = signatureText,
                                signaturePhoto = signaturePhotoUri != null,
                                font = fontPreset,
                                filter = filterPreset,
                                lyricsAvailable = !syncedLyrics.isNullOrBlank(),
                                exportTitle = exportTitle,
                                exportArtist = exportArtist,
                                exportResolution = exportResolution,
                                exportFps = exportFps,
                                onTitle = { titleManuallyEdited = true; exportTitle = it },
                                onArtist = { artistManuallyEdited = true; exportArtist = it },
                                onResolution = { qualityManuallyEdited = true; exportResolution = it },
                                onFps = { qualityManuallyEdited = true; exportFps = it },
                                onRegenerate = {
                                    imagesManuallyEdited = false
                                    filterManuallyEdited = false
                                    regenerationNonce += 1
                                    message("Nova combinação automática gerada.")
                                },
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CreateHeader(onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar") }
        Image(painterResource(R.drawable.sonus_edit_logo), "Sonus Edit", Modifier.size(46.dp).clip(RoundedCornerShape(12.dp)))
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text("Sonus Edit", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold)
            Text("automático • 9:16", color = SonusEditColors.TextMuted, fontSize = 11.sp)
        }
        Text("0.0.4", color = SonusEditColors.Cyan, fontWeight = FontWeight.Bold, fontSize = 11.sp)
    }
}

@Composable
private fun StepTabs(current: CreateStep, onSelect: (CreateStep) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        CreateStep.entries.forEachIndexed { index, step ->
            val active = current == step
            Card(
                Modifier.weight(1f).clickable(enabled = step.ordinal <= current.ordinal) { onSelect(step) },
                colors = CardDefaults.cardColors(containerColor = if (active) SonusEditColors.Violet else SonusEditColors.SurfaceRaised),
                shape = RoundedCornerShape(12.dp),
            ) {
                Text("${index + 1} ${step.label}", Modifier.padding(vertical = 7.dp).align(Alignment.CenterHorizontally), fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun Section(title: String, subtitle: String? = null, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = SonusEditColors.Surface)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            subtitle?.takeIf { it.isNotBlank() }?.let { Text(it, color = SonusEditColors.TextMuted, fontSize = 11.sp) }
            content()
        }
    }
}

@Composable
private fun MusicAndSignatureStep(
    signatureText: String,
    signaturePhotoUri: Uri?,
    saveSignature: Boolean,
    onSignatureText: (String) -> Unit,
    onSignaturePhoto: () -> Unit,
    onRemoveSignaturePhoto: () -> Unit,
    onSaveSignature: (Boolean) -> Unit,
    metadata: AudioMetadata?,
    audioSource: AudioSource,
    selectedDuration: DurationPreset,
    segmentStartMs: Long,
    isPlaying: Boolean,
    lyricsAvailable: Boolean,
    lyricsLoading: Boolean,
    smartStartLoading: Boolean,
    showLyricsSearch: Boolean,
    lyricsSearchTitle: String,
    lyricsSearchArtist: String,
    lyricsResults: List<LyricsMatch>,
    lyricsSearchLoading: Boolean,
    onToggleLyricsSearch: () -> Unit,
    onLyricsTitle: (String) -> Unit,
    onLyricsArtist: (String) -> Unit,
    onLyricsSearch: () -> Unit,
    onLyricsPick: (LyricsMatch) -> Unit,
    onStream: () -> Unit,
    onLocal: () -> Unit,
    onDuration: (DurationPreset) -> Unit,
    onStartChange: (Long) -> Unit,
    onFine: (Int) -> Unit,
    onPlayPause: () -> Unit,
) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = SonusEditColors.Surface)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Assinatura", Modifier.weight(1f), fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("Salvar padrão", fontSize = 10.sp, color = SonusEditColors.TextMuted)
                Spacer(Modifier.width(7.dp))
                Switch(checked = saveSignature, onCheckedChange = onSaveSignature, modifier = Modifier.size(width = 48.dp, height = 28.dp))
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(58.dp).clip(CircleShape).background(SonusEditColors.SurfaceRaised).clickable(onClick = onSignaturePhoto),
                    contentAlignment = Alignment.Center,
                ) {
                    if (signaturePhotoUri != null) UriThumbnail(signaturePhotoUri, Modifier.fillMaxSize(), ContentScale.Crop)
                    else Icon(Icons.Default.AddPhotoAlternate, "Selecionar imagem", tint = SonusEditColors.Cyan)
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    OutlinedTextField(signatureText, onSignatureText, Modifier.fillMaxWidth(), label = { Text("Nome / usuário") }, singleLine = true)
                    if (signaturePhotoUri != null) {
                        Text("Remover imagem", Modifier.clickable(onClick = onRemoveSignaturePhoto).padding(top = 3.dp), color = SonusEditColors.Cyan, fontSize = 10.sp)
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Warning, null, Modifier.size(13.dp), tint = Color(0xFFFFCC45))
                Text("  PNG sem fundo oferece melhor resultado.", color = SonusEditColors.TextMuted, fontSize = 10.sp)
            }
        }
    }

    Spacer(Modifier.height(10.dp))
    Section("Música") {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onStream, Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = SonusEditColors.Violet)) {
                Icon(Icons.Default.MusicNote, null); Text(" Stream")
            }
            OutlinedButton(onClick = onLocal, Modifier.weight(1f)) { Text("Local") }
        }

        if (metadata != null) {
            Card(colors = CardDefaults.cardColors(containerColor = SonusEditColors.SurfaceRaised), shape = RoundedCornerShape(14.dp)) {
                Column(Modifier.fillMaxWidth().padding(10.dp)) {
                    Text(metadata.title, fontWeight = FontWeight.Bold, maxLines = 1)
                    Text(listOfNotNull(metadata.artist, metadata.genre, sourceLabel(audioSource)).joinToString(" • "), color = SonusEditColors.TextMuted, fontSize = 11.sp, maxLines = 1)
                }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            val statusColor = if (lyricsAvailable) Color(0xFF20C86B) else Color(0xFFE94F64)
            Card(colors = CardDefaults.cardColors(containerColor = statusColor.copy(alpha = .16f)), shape = RoundedCornerShape(50)) {
                Row(Modifier.padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(8.dp).background(statusColor, CircleShape))
                    Text(if (lyricsAvailable) "  COM LETRA" else if (lyricsLoading) "  BUSCANDO…" else "  SEM LETRA", color = statusColor, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
            IconButton(onClick = onToggleLyricsSearch, modifier = Modifier.size(36.dp)) { Icon(Icons.Default.Search, "Buscar letra", tint = SonusEditColors.Cyan) }
            Spacer(Modifier.weight(1f))
            if (smartStartLoading) Text("Smart Start…", color = SonusEditColors.TextMuted, fontSize = 10.sp)
        }

        if (showLyricsSearch) {
            Card(colors = CardDefaults.cardColors(containerColor = SonusEditColors.SurfaceRaised), shape = RoundedCornerShape(14.dp)) {
                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("Buscar letra sincronizada", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    OutlinedTextField(lyricsSearchTitle, onLyricsTitle, Modifier.fillMaxWidth(), label = { Text("Música") }, singleLine = true)
                    OutlinedTextField(lyricsSearchArtist, onLyricsArtist, Modifier.fillMaxWidth(), label = { Text("Artista") }, singleLine = true)
                    Button(onClick = onLyricsSearch, enabled = !lyricsSearchLoading, modifier = Modifier.fillMaxWidth()) {
                        Text(if (lyricsSearchLoading) "Buscando…" else "Buscar no LRCLIB")
                    }
                    lyricsResults.forEach { result ->
                        Row(
                            Modifier.fillMaxWidth().clickable { onLyricsPick(result) }.padding(vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Box(Modifier.size(7.dp).background(Color(0xFF20C86B), CircleShape))
                            Spacer(Modifier.width(7.dp))
                            Column(Modifier.weight(1f)) {
                                Text(result.trackName, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 1)
                                Text("${result.artistName}${result.duration?.let { " • ${formatTime((it * 1000).toLong())}" }.orEmpty()}", color = SonusEditColors.TextMuted, fontSize = 10.sp, maxLines = 1)
                            }
                        }
                    }
                }
            }
        }

        Text("Duração", fontWeight = FontWeight.Bold, fontSize = 13.sp)
        DurationPreset.all.chunked(4).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                row.forEach { preset ->
                    val selected = selectedDuration == preset
                    Button(
                        onClick = { onDuration(preset) },
                        modifier = Modifier.weight(1f).height(40.dp),
                        contentPadding = PaddingValues(2.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (selected) Color(0xFF18B866) else SonusEditColors.SurfaceRaised,
                            contentColor = Color.White,
                        ),
                        shape = RoundedCornerShape(11.dp),
                    ) { Text(preset.label, fontSize = 11.sp, fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.Medium) }
                }
                repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }

        val duration = metadata?.durationMs ?: 0L
        val maxStart = (duration - selectedDuration.seconds * 1_000L).coerceAtLeast(0L)
        Slider(
            value = segmentStartMs.toFloat().coerceIn(0f, maxStart.toFloat().coerceAtLeast(0f)),
            onValueChange = { onStartChange(it.toLong()) },
            valueRange = 0f..maxStart.toFloat().coerceAtLeast(1f),
            modifier = Modifier.fillMaxWidth().height(26.dp),
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onPlayPause, Modifier.size(38.dp)) { Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = SonusEditColors.Cyan) }
            Text("${formatTime(segmentStartMs)} → ${formatTime(segmentStartMs + selectedDuration.seconds * 1_000L)}", fontSize = 11.sp, color = SonusEditColors.TextMuted)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            listOf(-10, -5, -1, 1, 5, 10).forEach { sec ->
                OutlinedButton(onClick = { onFine(sec) }, Modifier.weight(1f).height(36.dp), contentPadding = PaddingValues(0.dp)) {
                    Text(if (sec > 0) "+$sec" else "$sec", fontSize = 10.sp)
                }
            }
        }
    }
}

@Composable
private fun ColumnScope.StreamPicker(
    assets: List<PCloudAsset>,
    loading: Boolean,
    search: String,
    selectedGenre: String,
    history: List<StreamHistoryStore.Entry>,
    repository: PCloudMusicRepository,
    metadataStore: StreamMetadataStore,
    lrclib: LrclibLyricsProvider,
    sonusLyrics: SonusLyricsResolver,
    onSearch: (String) -> Unit,
    onGenre: (String) -> Unit,
    onBack: () -> Unit,
    onSelect: (PCloudAsset) -> Unit,
) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar") }
        Text("Sonus Stream", fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
    OutlinedTextField(
        search,
        onSearch,
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 5.dp),
        label = { Text("Buscar música, artista ou gênero") },
        leadingIcon = { Icon(Icons.Default.Search, null) },
        singleLine = true,
    )
    val cachedMeta = assets.associateWith { metadataStore.cached(it) }
    val genres = listOf("Todos") + assets.map { cachedMeta[it]?.genre ?: it.genre }.filter { it.isNotBlank() }.distinct().sorted()
    genres.chunked(4).take(3).forEach { row ->
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            row.forEach { genre ->
                FilterChip(selected = genre == selectedGenre, onClick = { onGenre(genre) }, label = { Text(genre, fontSize = 9.sp, maxLines = 1) }, modifier = Modifier.weight(1f))
            }
            repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
        }
    }

    val recentKeys = history.take(8).map { it.stableKey }.toSet()
    val filtered = assets.filter { asset ->
        val meta = cachedMeta[asset]
        val genre = meta?.genre ?: asset.genre
        val genreOk = selectedGenre == "Todos" || genre.equals(selectedGenre, true)
        val haystack = listOf(asset.name, asset.folderPath, meta?.title.orEmpty(), meta?.artist.orEmpty(), meta?.genre.orEmpty()).joinToString(" ").lowercase()
        genreOk && (search.isBlank() || haystack.contains(search.lowercase()))
    }.sortedBy { if (it.stableKey in recentKeys) 1 else 0 }

    if (loading && filtered.isEmpty()) Text("Atualizando catálogo…", Modifier.padding(16.dp), color = SonusEditColors.TextMuted)
    LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        items(filtered.size, key = { filtered[it].stableKey }) { index ->
            val asset = filtered[index]
            StreamAssetRow(asset, repository, metadataStore, lrclib, sonusLyrics, onSelect)
        }
    }
}

@Composable
private fun StreamAssetRow(
    asset: PCloudAsset,
    repository: PCloudMusicRepository,
    metadataStore: StreamMetadataStore,
    lrclib: LrclibLyricsProvider,
    sonusLyrics: SonusLyricsResolver,
    onSelect: (PCloudAsset) -> Unit,
) {
    val metadata by produceState<AudioMetadata?>(metadataStore.cached(asset), asset.stableKey) {
        value = runCatching { metadataStore.resolve(asset, repository) }.getOrNull()
    }
    val lyricAvailable by produceState<Boolean?>(null, asset.stableKey, metadata?.title, metadata?.artist) {
        val meta = metadata ?: return@produceState
        value = runCatching {
            val fromSonus = sonusLyrics.syncedLyrics(asset.fileId.toString())
            if (!fromSonus.isNullOrBlank()) true
            else if (!meta.artist.isNullOrBlank()) {
                lrclib.bestMatch(
                    LyricsMetadata(
                        trackName = meta.title,
                        artistName = meta.artist,
                        albumName = meta.album,
                        durationSeconds = (meta.durationMs / 1_000L).toInt().takeIf { it > 0 },
                    )
                )?.hasSyncedLyrics == true
            } else {
                lrclib.search(meta.title, null).any { it.hasSyncedLyrics }
            }
        }.getOrDefault(false)
    }
    Card(
        Modifier.fillMaxWidth().clickable { onSelect(asset) },
        colors = CardDefaults.cardColors(containerColor = SonusEditColors.Surface),
        shape = RoundedCornerShape(14.dp),
    ) {
        Row(Modifier.padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.MusicNote, null, tint = SonusEditColors.Cyan)
            Spacer(Modifier.width(9.dp))
            Column(Modifier.weight(1f)) {
                Text(metadata?.title ?: "Lendo metadados…", fontWeight = FontWeight.Bold, maxLines = 1)
                Text(listOfNotNull(metadata?.artist, metadata?.genre ?: asset.genre).joinToString(" • "), color = SonusEditColors.TextMuted, fontSize = 10.sp, maxLines = 1)
            }
            val dot = when (lyricAvailable) { true -> Color(0xFF20C86B); false -> Color(0xFFE94F64); null -> SonusEditColors.TextMuted }
            Box(Modifier.size(9.dp).background(dot, CircleShape))
        }
    }
}

@Composable
private fun ImagesStep(
    localOrRemoteUris: List<String>,
    selectedRemoteIds: Set<Long>,
    remoteAssets: List<PCloudAsset>,
    remoteMode: Boolean,
    limit: Int,
    loading: Boolean,
    imageRepo: PCloudImageRepository,
    onRemoteMode: (Boolean) -> Unit,
    onLocal: () -> Unit,
    onRemoteToggle: (PCloudAsset) -> Unit,
    onRemoveUri: (String) -> Unit,
) {
    Section("Escolher imagens") {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("${localOrRemoteUris.size}/$limit selecionadas", color = SonusEditColors.Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            OutlinedButton(onClick = { onRemoteMode(true) }) { Text("Sonus Gallery", fontSize = 10.sp) }
            Spacer(Modifier.width(5.dp))
            OutlinedButton(onClick = { onRemoteMode(false); onLocal() }) { Text("Local", fontSize = 10.sp) }
        }

        if (!remoteMode) {
            localOrRemoteUris.chunked(3).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    row.forEach { uriString ->
                        Box(Modifier.weight(1f).aspectRatio(1f).clip(RoundedCornerShape(12.dp))) {
                            AnyThumbnail(uriString, Modifier.fillMaxSize())
                            Icon(Icons.Default.Close, "Remover", Modifier.align(Alignment.TopEnd).padding(4.dp).background(Color.Black.copy(alpha=.55f), CircleShape).clickable { onRemoveUri(uriString) }, tint = Color.White)
                        }
                    }
                    repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        } else {
            if (loading && remoteAssets.isEmpty()) Text("Atualizando Sonus Gallery…", color = SonusEditColors.TextMuted)
            remoteAssets.take(45).chunked(3).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    row.forEach { asset ->
                        val selected = asset.fileId in selectedRemoteIds
                        Box(
                            Modifier.weight(1f).aspectRatio(1f).clip(RoundedCornerShape(12.dp))
                                .border(if (selected) 3.dp else 1.dp, if (selected) SonusEditColors.Cyan else SonusEditColors.SurfaceRaised, RoundedCornerShape(12.dp))
                                .clickable { onRemoteToggle(asset) }
                        ) {
                            RemoteAssetThumbnail(asset, imageRepo, Modifier.fillMaxSize())
                            if (selected) Icon(Icons.Default.CheckCircle, "Selecionada", Modifier.align(Alignment.TopEnd).padding(4.dp), tint = SonusEditColors.Cyan)
                        }
                    }
                    repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
    }
}

@Composable
private fun StyleStep(
    fontPreset: FontPresetId,
    filterPreset: FilterPresetId,
    saveFont: Boolean,
    previewImageUri: String?,
    lyricsAvailable: Boolean,
    onFont: (FontPresetId) -> Unit,
    onFilter: (FilterPresetId) -> Unit,
    onSaveFont: (Boolean) -> Unit,
) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = SonusEditColors.Surface)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Fonte da letra", Modifier.weight(1f), fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("Salvar padrão", fontSize = 10.sp, color = SonusEditColors.TextMuted)
                Spacer(Modifier.width(7.dp))
                Switch(checked = saveFont, onCheckedChange = onSaveFont, modifier = Modifier.size(width = 48.dp, height = 28.dp))
            }
            FontPresetId.entries.chunked(4).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    row.forEach { preset -> FontPreviewCard(preset, fontPreset == preset, Modifier.weight(1f)) { onFont(preset) } }
                }
            }
        }
    }
    Spacer(Modifier.height(10.dp))
    Section("Letra sincronizada") {
        Row(verticalAlignment = Alignment.CenterVertically) {
            val c = if (lyricsAvailable) Color(0xFF20C86B) else Color(0xFFE94F64)
            Box(Modifier.size(8.dp).background(c, CircleShape))
            Text(if (lyricsAvailable) "  Sincronizada" else "  Sem letra sincronizada", color = c, fontWeight = FontWeight.Bold, fontSize = 11.sp)
        }
        NeonLyricsPreview(fontPreset)
    }
    Spacer(Modifier.height(10.dp))
    Section("Filtro") {
        FilterPresetId.entries.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                row.forEach { preset ->
                    FilterPreviewCard(preset, filterPreset == preset, previewImageUri, Modifier.weight(1f)) { onFilter(preset) }
                }
                repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
private fun FontPreviewCard(preset: FontPresetId, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Card(
        modifier.clickable(onClick = onClick).border(if (selected) 2.dp else 0.dp, SonusEditColors.Cyan, RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = SonusEditColors.SurfaceRaised),
        shape = RoundedCornerShape(12.dp),
    ) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Aa", style = fontPreviewStyle(preset), maxLines = 1)
            Text(preset.label, fontSize = 8.sp, color = SonusEditColors.TextMuted, maxLines = 1)
        }
    }
}

private fun fontPreviewStyle(preset: FontPresetId): TextStyle = when (preset) {
    FontPresetId.DEFAULT -> TextStyle(fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
    FontPresetId.MODERN -> TextStyle(fontSize = 16.sp, fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Light)
    FontPresetId.ELEGANT -> TextStyle(fontSize = 17.sp, fontFamily = FontFamily.Serif, fontStyle = FontStyle.Italic)
    FontPresetId.IMPACT -> TextStyle(fontSize = 17.sp, fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Black)
    FontPresetId.HANDWRITTEN -> TextStyle(fontSize = 18.sp, fontFamily = FontFamily.Cursive, fontStyle = FontStyle.Italic)
    FontPresetId.MINIMAL -> TextStyle(fontSize = 15.sp, fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Thin)
    FontPresetId.NEON -> TextStyle(fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.Cyan, shadow = Shadow(Color.Magenta, Offset.Zero, 8f))
    FontPresetId.RETRO -> TextStyle(fontSize = 16.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
}

@Composable
private fun NeonLyricsPreview(font: FontPresetId) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF050711))) {
        Column(Modifier.fillMaxWidth().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            listOf("Seu vídeo encontra a música" to Color.Cyan, "cada linha ganha vida" to Color(0xFFFF4FA3)).forEach { (line, color) ->
                Text(line, color = color, style = fontPreviewStyle(font).copy(shadow = Shadow(color, Offset.Zero, 8f)))
            }
        }
    }
}

@Composable
private fun FilterPreviewCard(preset: FilterPresetId, selected: Boolean, imageUri: String?, modifier: Modifier, onClick: () -> Unit) {
    val tint = filterPreviewTint(preset)
    Card(
        modifier.clickable(onClick = onClick).border(if (selected) 2.dp else 0.dp, SonusEditColors.Cyan, RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = SonusEditColors.SurfaceRaised),
        shape = RoundedCornerShape(12.dp),
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.fillMaxWidth().aspectRatio(2.05f).clip(RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp))) {
                if (imageUri != null) AnyThumbnail(imageUri, Modifier.fillMaxSize())
                else Box(Modifier.fillMaxSize().background(Color(0xFF39445C)))
                if (tint.alpha > 0f) Box(Modifier.fillMaxSize().background(tint))
            }
            Text(preset.label, Modifier.padding(horizontal = 3.dp, vertical = 2.dp), fontSize = 7.sp, maxLines = 1)
        }
    }
}

private fun filterPreviewTint(preset: FilterPresetId): Color = when (preset) {
    FilterPresetId.ORIGINAL -> Color.Transparent
    FilterPresetId.CINEMATIC -> Color(0x44213B5A)
    FilterPresetId.SUNSET -> Color(0x55FF6E32)
    FilterPresetId.VINTAGE_FILM -> Color(0x55C7A26A)
    FilterPresetId.NIGHT_CITY -> Color(0x55224B9A)
    FilterPresetId.NATURAL_PLUS -> Color(0x223CFF8E)
    FilterPresetId.SOFT_LIGHT -> Color(0x44FFFFFF)
    FilterPresetId.WARM_NATURAL -> Color(0x33FFB25A)
    FilterPresetId.COOL_NATURAL -> Color(0x332A8FFF)
    FilterPresetId.SOFT_CONTRAST -> Color(0x22000000)
    FilterPresetId.CINEMA_CLEAN -> Color(0x223A6D84)
    FilterPresetId.GOLDEN -> Color(0x55E8B13C)
    FilterPresetId.CLEAN_NIGHT -> Color(0x44213A72)
    FilterPresetId.PASTEL_NATURAL -> Color(0x33FFD0D9)
    FilterPresetId.CLARITY_PLUS -> Color(0x2239D1FF)
}

@Composable
private fun ReviewStep(
    metadata: AudioMetadata?,
    selectedDuration: DurationPreset,
    segmentStartMs: Long,
    imageCount: Int,
    signatureText: String,
    signaturePhoto: Boolean,
    font: FontPresetId,
    filter: FilterPresetId,
    lyricsAvailable: Boolean,
    exportTitle: String,
    exportArtist: String,
    exportResolution: ExportResolution,
    exportFps: Int,
    onTitle: (String) -> Unit,
    onArtist: (String) -> Unit,
    onResolution: (ExportResolution) -> Unit,
    onFps: (Int) -> Unit,
    onRegenerate: () -> Unit,
) {
    Section("Revisão") {
        Text("Textos do vídeo", color = SonusEditColors.TextMuted, fontSize = 10.sp)
        OutlinedTextField(
            exportTitle,
            onTitle,
            Modifier.fillMaxWidth().background(Color(0x18FFD83D), RoundedCornerShape(12.dp)),
            label = { Text("🟡 Nome da música") },
            singleLine = true,
        )
        OutlinedTextField(
            exportArtist,
            onArtist,
            Modifier.fillMaxWidth().background(Color(0x14FFFFFF), RoundedCornerShape(12.dp)),
            label = { Text("🤍 Nome do artista") },
            singleLine = true,
        )
        ReviewLine("Original", listOfNotNull(metadata?.title, metadata?.artist).joinToString(" • ").ifBlank { "—" })
        ReviewLine("Trecho", "${formatTime(segmentStartMs)} → ${formatTime(segmentStartMs + selectedDuration.seconds * 1_000L)}")
        ReviewLine("Imagens", imageCount.toString())
        ReviewLine("Letra", if (lyricsAvailable) "Sincronizada" else "Sem letra")
        ReviewLine("Fonte", font.label)
        ReviewLine("Filtro", filter.label)
        ReviewLine("Efeito", "Automático contextual")
        ReviewLine("Assinatura", if (signatureText.isNotBlank() || signaturePhoto) "Ativa" else "Sem assinatura")
        ReviewLine("Formato", "9:16")

        OutlinedButton(
            onClick = onRegenerate,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
        ) {
            Text("🔄  Gerar outra combinação", color = SonusEditColors.Cyan, fontWeight = FontWeight.Bold)
        }

        Text("Qualidade", fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            ExportResolution.entries.forEach { resolution ->
                QualityButton(resolution.label, exportResolution == resolution, Modifier.weight(1f)) { onResolution(resolution) }
            }
        }
        Text("FPS", fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            listOf(30, 60, 90).forEach { fps ->
                QualityButton("$fps", exportFps == fps, Modifier.weight(1f)) { onFps(fps) }
            }
        }
        Text("A resolução e o FPS selecionados são validados no arquivo final. Se o aparelho não entregar o perfil real, a exportação é interrompida em vez de simular qualidade.", color = SonusEditColors.TextMuted, fontSize = 9.sp)
    }
}

@Composable
private fun QualityButton(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val green = if (selected) Color(0xFF22F47A) else Color(0xFF174F31)
    Button(
        onClick = onClick,
        modifier = modifier.height(42.dp),
        colors = ButtonDefaults.buttonColors(containerColor = green, contentColor = Color.White),
        contentPadding = PaddingValues(horizontal = 2.dp),
        shape = RoundedCornerShape(12.dp),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = if (selected) 5.dp else 0.dp),
    ) {
        Text(label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
    }
}

@Composable
private fun ReviewLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Text(label, Modifier.weight(1f), color = SonusEditColors.TextMuted, fontSize = 11.sp)
        Text(value, fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
    }
}

@Composable
private fun BottomFlowBar(step: CreateStep, canContinue: Boolean, onPrevious: () -> Unit, onNext: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(SonusEditColors.Surface).padding(horizontal = 12.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedButton(onClick = onPrevious) { Text(if (step == CreateStep.MUSIC) "Voltar" else "Anterior") }
        Spacer(Modifier.weight(1f))
        Button(onClick = onNext, enabled = canContinue, colors = ButtonDefaults.buttonColors(containerColor = SonusEditColors.Violet)) {
            Text(if (step == CreateStep.REVIEW) "CRIAR VÍDEO" else "AVANÇAR")
        }
    }
}

@Composable
private fun UriThumbnail(uri: Uri, modifier: Modifier, contentScale: ContentScale) {
    val context = LocalContext.current
    val bitmap by produceState<ImageBitmap?>(null, uri) {
        value = withContext(Dispatchers.IO) {
            runCatching { context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it)?.asImageBitmap() } }.getOrNull()
        }
    }
    if (bitmap != null) Image(bitmap!!, null, modifier, contentScale = contentScale)
    else Box(modifier.background(SonusEditColors.SurfaceRaised), contentAlignment = Alignment.Center) { Icon(Icons.Default.Image, null, tint = SonusEditColors.Cyan) }
}

@Composable
private fun AnyThumbnail(uriString: String, modifier: Modifier) {
    val context = LocalContext.current
    val bitmap by produceState<ImageBitmap?>(null, uriString) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                val uri = Uri.parse(uriString)
                if (uri.scheme == "http" || uri.scheme == "https") {
                    val connection = URI.create(uriString).toURL().openConnection() as HttpURLConnection
                    connection.connectTimeout = 7_000; connection.readTimeout = 10_000
                    try { connection.inputStream.use { BitmapFactory.decodeStream(it)?.asImageBitmap() } } finally { connection.disconnect() }
                } else {
                    context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it)?.asImageBitmap() }
                }
            }.getOrNull()
        }
    }
    if (bitmap != null) Image(bitmap!!, null, modifier, contentScale = ContentScale.Crop)
    else Box(modifier.background(SonusEditColors.SurfaceRaised), contentAlignment = Alignment.Center) { Icon(Icons.Default.Image, null, tint = SonusEditColors.Cyan) }
}

@Composable
private fun RemoteAssetThumbnail(asset: PCloudAsset, repository: PCloudImageRepository, modifier: Modifier) {
    val bitmap by produceState<ImageBitmap?>(null, asset.stableKey) {
        value = withContext(Dispatchers.IO) {
            val url = repository.thumbnailUrl(asset) ?: return@withContext null
            runCatching {
                val connection = URI.create(url).toURL().openConnection() as HttpURLConnection
                connection.connectTimeout = 7_000; connection.readTimeout = 10_000
                try { connection.inputStream.use { BitmapFactory.decodeStream(it)?.asImageBitmap() } } finally { connection.disconnect() }
            }.getOrNull()
        }
    }
    if (bitmap != null) Image(bitmap!!, asset.name, modifier, contentScale = ContentScale.Crop)
    else Box(modifier.background(SonusEditColors.SurfaceRaised), contentAlignment = Alignment.Center) { Icon(Icons.Default.Image, null, tint = SonusEditColors.Cyan) }
}

private fun rankImageAssets(assets: List<PCloudAsset>, metadata: AudioMetadata?, lyrics: String?): List<PCloudAsset> {
    val query = listOfNotNull(metadata?.title, metadata?.artist, metadata?.genre, lyrics?.take(600)).joinToString(" ").lowercase()
    val terms = query.split(Regex("[^\\p{L}\\p{N}]+"))
        .filter { it.length >= 4 }
        .toSet()
    return assets.sortedByDescending { asset ->
        val haystack = "${asset.name} ${asset.folderPath}".lowercase()
        var score = terms.count { haystack.contains(it) } * 3
        if (query.contains("nossa senhora") && (haystack.contains("nossa senhora") || haystack.contains("maria") || haystack.contains("aparecida"))) score += 12
        if ((query.contains("católic") || query.contains("catholic")) && (haystack.contains("cat") || haystack.contains("maria") || haystack.contains("jesus"))) score += 8
        score
    }
}

private fun sourceLabel(source: AudioSource): String = when (source) {
    AudioSource.LOCAL -> "Local"
    AudioSource.SONUS_STREAM -> "Sonus Stream"
    AudioSource.SHARED -> "Compartilhada"
}

private fun formatTime(ms: Long): String {
    val total = (ms.coerceAtLeast(0L) / 1_000L)
    return "%02d:%02d".format(total / 60, total % 60)
}
