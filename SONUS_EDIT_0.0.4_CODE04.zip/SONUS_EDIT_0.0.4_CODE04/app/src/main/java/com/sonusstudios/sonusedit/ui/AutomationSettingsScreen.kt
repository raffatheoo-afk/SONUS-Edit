package com.sonusstudios.sonusedit.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.FilterVintage
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VideoSettings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonusstudios.sonusedit.create.AutomationPreferences
import com.sonusstudios.sonusedit.create.AutomationSettings
import com.sonusstudios.sonusedit.create.EffectIntensity
import com.sonusstudios.sonusedit.create.ExportResolution
import com.sonusstudios.sonusedit.create.ImageQuantityMode
import com.sonusstudios.sonusedit.designsystem.SonusEditColors
import kotlinx.coroutines.launch

private val AutomationGreen = Color(0xFF2BEA76)
private val AutomationGreenDark = Color(0xFF123C27)

@Composable
fun AutomationSettingsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { AutomationPreferences(context.applicationContext) }
    val current by prefs.values.collectAsState(initial = AutomationSettings())
    val scope = rememberCoroutineScope()

    fun update(block: (AutomationSettings) -> AutomationSettings) {
        scope.launch { prefs.save(block(current)) }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(SonusEditColors.Black),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar", tint = Color.White)
                }
                Column(Modifier.weight(1f)) {
                    Text("Automação do editor", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Escolha até onde o Sonus Edit decide por você.", color = SonusEditColors.TextMuted, fontSize = 11.sp)
                }
                Icon(Icons.Default.Tune, contentDescription = null, tint = AutomationGreen, modifier = Modifier.size(26.dp))
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF10271B)),
                shape = RoundedCornerShape(24.dp),
            ) {
                Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AutoAwesome, null, tint = AutomationGreen, modifier = Modifier.size(28.dp))
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text("AUTOMAÇÃO TOTAL", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Black)
                            Text("Música, trecho, duração, imagens, filtro e efeito escolhidos automaticamente.", color = SonusEditColors.TextMuted, fontSize = 10.sp)
                        }
                        Switch(
                            checked = current.totalAutomation,
                            onCheckedChange = { checked -> update { it.copy(totalAutomation = checked) } },
                            colors = automationSwitchColors(),
                        )
                    }
                    if (current.totalAutomation) {
                        Text("Ativa • as opções individuais ficam bloqueadas, mas o projeto continua editável.", color = AutomationGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        item { GroupTitle("Música") }
        item {
            SettingsCard {
                ToggleSetting(
                    icon = { Icon(Icons.Default.MusicNote, null, tint = SonusEditColors.Cyan) },
                    title = "Smart Start automático",
                    subtitle = "Encontra rapidamente um bom ponto de entrada.",
                    checked = current.totalAutomation || current.smartStart,
                    enabled = !current.totalAutomation,
                ) { value -> update { it.copy(smartStart = value) } }
                DividerSpace()
                ToggleSetting(
                    icon = { Icon(Icons.Default.Subtitles, null, tint = Color(0xFFFFD54F)) },
                    title = "Priorizar refrão",
                    subtitle = "Usa refrão/estrutura da letra quando houver confiança.",
                    checked = current.totalAutomation || current.prioritizeChorus,
                    enabled = !current.totalAutomation,
                ) { value -> update { it.copy(prioritizeChorus = value) } }
                DividerSpace()
                ToggleSetting(
                    icon = { Icon(Icons.Default.Subtitles, null, tint = AutomationGreen) },
                    title = "Busca automática de letra",
                    subtitle = "SONUS primeiro no Stream e LRCLIB como fallback.",
                    checked = current.totalAutomation || current.automaticLyrics,
                    enabled = !current.totalAutomation,
                ) { value -> update { it.copy(automaticLyrics = value) } }
            }
        }

        item { GroupTitle("Visual") }
        item {
            SettingsCard {
                ToggleSetting(
                    icon = { Icon(Icons.Default.FilterVintage, null, tint = Color(0xFFFF6FB1)) },
                    title = "Efeitos automáticos",
                    subtitle = "Escolhe um dos efeitos contextuais para a música.",
                    checked = current.totalAutomation || current.automaticEffects,
                    enabled = !current.totalAutomation,
                ) { value -> update { it.copy(automaticEffects = value) } }
                ChoiceRow(
                    title = "Intensidade",
                    enabled = !current.totalAutomation && current.automaticEffects,
                    entries = EffectIntensity.entries.map { it.label to ((if (current.totalAutomation) EffectIntensity.BALANCED else current.effectIntensity) == it) },
                ) { index -> update { it.copy(effectIntensity = EffectIntensity.entries[index]) } }
                DividerSpace()
                ToggleSetting(
                    icon = { Icon(Icons.Default.Image, null, tint = SonusEditColors.Cyan) },
                    title = "Sugestão automática de imagens",
                    subtitle = "Usa título, gênero e letra para montar a seleção.",
                    checked = current.totalAutomation || current.automaticImages,
                    enabled = !current.totalAutomation,
                ) { value -> update { it.copy(automaticImages = value) } }
                ChoiceRow(
                    title = "Quantidade",
                    enabled = !current.totalAutomation && current.automaticImages,
                    entries = ImageQuantityMode.entries.map { it.label to ((if (current.totalAutomation) ImageQuantityMode.BALANCED else current.imageQuantity) == it) },
                ) { index -> update { it.copy(imageQuantity = ImageQuantityMode.entries[index]) } }
                DividerSpace()
                ToggleSetting(
                    icon = { Icon(Icons.Default.FilterVintage, null, tint = Color(0xFFA78BFA)) },
                    title = "Filtro automático",
                    subtitle = "Seleciona um filtro compatível com o perfil da música.",
                    checked = current.totalAutomation || current.automaticFilter,
                    enabled = !current.totalAutomation,
                ) { value -> update { it.copy(automaticFilter = value) } }
                DividerSpace()
                ToggleSetting(
                    icon = { Icon(Icons.Default.VideoSettings, null, tint = Color(0xFFFFD54F)) },
                    title = "Metadados no vídeo",
                    subtitle = "Mostra nome da música e artista no rodapé do vídeo.",
                    checked = current.totalAutomation || current.metadataOnVideo,
                    enabled = !current.totalAutomation,
                ) { value -> update { it.copy(metadataOnVideo = value) } }
            }
        }

        item { GroupTitle("Exportação") }
        item {
            SettingsCard {
                Text("Qualidade padrão", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(Modifier.height(6.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    ExportResolution.entries.forEach { resolution ->
                        val selected = (if (current.totalAutomation) ExportResolution.P1080 else current.defaultResolution) == resolution
                        FilterChip(
                            selected = selected,
                            onClick = { if (!current.totalAutomation) update { it.copy(defaultResolution = resolution) } },
                            label = { Text(resolution.label, fontSize = 10.sp) },
                            enabled = !current.totalAutomation,
                            modifier = Modifier.weight(1f),
                            colors = automationChipColors(),
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("FPS padrão", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(Modifier.height(6.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    listOf(30, 60, 90).forEach { fps ->
                        FilterChip(
                            selected = (if (current.totalAutomation) 60 else current.defaultFps) == fps,
                            onClick = { if (!current.totalAutomation) update { it.copy(defaultFps = fps) } },
                            label = { Text("$fps", fontSize = 10.sp) },
                            enabled = !current.totalAutomation,
                            modifier = Modifier.weight(1f),
                            colors = automationChipColors(),
                        )
                    }
                }
                if (current.totalAutomation) {
                    Spacer(Modifier.height(6.dp))
                    Text("Automação Total usa 1080p • 60 FPS como perfil recomendado.", color = AutomationGreen, fontSize = 9.sp)
                }
            }
        }

        item {
            Button(
                onClick = { scope.launch { prefs.restoreDefaults() } },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = SonusEditColors.SurfaceRaised, contentColor = Color.White),
                shape = RoundedCornerShape(16.dp),
            ) {
                Icon(Icons.Default.Refresh, null)
                Spacer(Modifier.width(8.dp))
                Text("Restaurar automação padrão")
            }
        }

        item {
            Text(
                "by SONUS STUDIOS - RΛFΛ亗",
                color = SonusEditColors.TextMuted.copy(alpha = .65f),
                fontSize = 9.sp,
                modifier = Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 14.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            )
        }
    }
}

@Composable
private fun GroupTitle(title: String) {
    Text(title.uppercase(), color = SonusEditColors.Cyan, fontWeight = FontWeight.Black, fontSize = 10.sp, modifier = Modifier.padding(start = 4.dp, top = 2.dp))
}

@Composable
private fun SettingsCard(content: @Composable () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SonusEditColors.Surface),
        shape = RoundedCornerShape(22.dp),
    ) {
        Column(Modifier.fillMaxWidth().padding(15.dp)) { content() }
    }
}

@Composable
private fun ToggleSetting(
    icon: @Composable () -> Unit,
    title: String,
    subtitle: String,
    checked: Boolean,
    enabled: Boolean,
    onChange: (Boolean) -> Unit,
) {
    Row(
        Modifier.fillMaxWidth().clickable(enabled = enabled) { onChange(!checked) },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        icon()
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = if (enabled) Color.White else SonusEditColors.TextMuted, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(subtitle, color = SonusEditColors.TextMuted, fontSize = 9.sp, lineHeight = 12.sp)
        }
        Spacer(Modifier.width(8.dp))
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled, colors = automationSwitchColors())
    }
}

@Composable
private fun ChoiceRow(title: String, enabled: Boolean, entries: List<Pair<String, Boolean>>, onSelect: (Int) -> Unit) {
    Spacer(Modifier.height(8.dp))
    Text(title, color = SonusEditColors.TextMuted, fontSize = 9.sp)
    Spacer(Modifier.height(4.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        entries.forEachIndexed { index, (label, selected) ->
            FilterChip(
                selected = selected,
                onClick = { onSelect(index) },
                label = { Text(label, fontSize = 9.sp, maxLines = 1) },
                enabled = enabled,
                modifier = Modifier.weight(1f),
                colors = automationChipColors(),
            )
        }
    }
}

@Composable
private fun DividerSpace() {
    Spacer(Modifier.height(12.dp))
    Spacer(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = .06f)))
    Spacer(Modifier.height(12.dp))
}


@Composable
private fun automationSwitchColors() = SwitchDefaults.colors(
    checkedThumbColor = Color.White,
    checkedTrackColor = AutomationGreen,
    uncheckedThumbColor = SonusEditColors.TextMuted,
    uncheckedTrackColor = AutomationGreenDark.copy(alpha = .55f),
    disabledCheckedTrackColor = AutomationGreen.copy(alpha = .42f),
)

@Composable
private fun automationChipColors() = FilterChipDefaults.filterChipColors(
    selectedContainerColor = AutomationGreenDark,
    selectedLabelColor = AutomationGreen,
    containerColor = SonusEditColors.SurfaceRaised,
    labelColor = Color.White,
    disabledSelectedContainerColor = AutomationGreenDark.copy(alpha = .55f),
    disabledSelectedLabelColor = AutomationGreen.copy(alpha = .55f),
)
